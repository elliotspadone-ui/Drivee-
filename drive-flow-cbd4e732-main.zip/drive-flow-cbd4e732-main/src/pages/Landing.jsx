import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Search, MapPin, Car, Star, CheckCircle, Calendar, TrendingUp, Shield, Clock,
  Award, ChevronRight, Bike, Zap, Users, ArrowRight, Briefcase, Facebook, Twitter,
  Instagram, Linkedin, SlidersHorizontal, X, Play, GraduationCap, MapPinned,
  MessageSquare, Sparkles, BadgeCheck, DollarSign, Package, Menu,
  ChevronDown, ArrowUpRight, Quote, Heart, ThumbsUp, Globe, BookOpen
} from "lucide-react";
import { motion, AnimatePresence, useScroll, useTransform, useInView } from "framer-motion";
import LocaleSelector from "@/components/common/LocaleSelector";
import LocaleSuggestionBanner from "@/components/common/LocaleSuggestionBanner";
import CookieBanner from "@/components/common/CookieBanner";
import {
  getInitialMarketingLocale, detectBrowserLocale, getLocaleById,
  saveLocalePreference, getSavedLocalePreference
} from "@/components/utils/localisation";
import { useTranslation, changeLanguage } from "@/components/utils/i18n";
import SEOHead from "@/components/common/SEOHead";

// ============================================================================
// CONSTANTS & CONFIGURATION
// ============================================================================

const LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691b056345d5788acbd4e732/8bd9d7a47_ChatGPTImageNov29202511_47_17PM.png";
const HERO_ILLUSTRATION_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691b056345d5788acbd4e732/56647de3b_bc1772a0-2cf2-46f2-9e73-ba64ef278d5d-Photoroom.png";

// Design tokens for consistent styling
const tokens = {
  colors: {
    primary: { base: "#1e3a5f", light: "#2d5a8a", lighter: "#e8f1f8", accent: "#3b82c4" },
    secondary: { base: "#0d4f3c", light: "#16a34a", lighter: "#dcfce7" },
    accent: { amber: "#f59e0b", purple: "#7c3aed", coral: "#f43f5e" },
    neutral: { 50: "#fafafa", 100: "#f4f4f5", 200: "#e4e4e7", 800: "#27272a", 900: "#18181b" }
  },
  easing: {
    smooth: [0.25, 0.1, 0.25, 1],
    bounce: [0.34, 1.56, 0.64, 1],
    premium: [0.22, 1, 0.36, 1]
  },
  shadows: {
    soft: "0 2px 8px -2px rgba(0,0,0,0.08), 0 4px 16px -4px rgba(0,0,0,0.12)",
    medium: "0 4px 12px -2px rgba(0,0,0,0.08), 0 8px 24px -4px rgba(0,0,0,0.14)",
    strong: "0 8px 24px -4px rgba(0,0,0,0.12), 0 16px 48px -8px rgba(0,0,0,0.18)"
  }
};

// Animation variants
const variants = {
  fadeUp: {
    hidden: { opacity: 0, y: 32 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: tokens.easing.premium } }
  },
  fadeIn: {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.5 } }
  },
  scaleIn: {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.5, ease: tokens.easing.premium } }
  },
  stagger: {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.15 } }
  },
  slideIn: {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.5, ease: tokens.easing.smooth } }
  }
};

// Data constants
const CATEGORIES = [
  { icon: Car, label: "Car License (B)", gradient: "from-slate-800 to-slate-950", count: "2,500+", popular: true },
  { icon: Bike, label: "Motorcycle (A)", gradient: "from-amber-500 to-orange-600", count: "850+" },
  { icon: Zap, label: "Automatic", gradient: "from-emerald-500 to-teal-600", count: "1,200+", trending: true },
  { icon: Users, label: "Intensive", gradient: "from-violet-600 to-purple-700", count: "600+" },
  { icon: GraduationCap, label: "Theory", gradient: "from-sky-500 to-blue-600", count: "1,800+" },
  { icon: Package, label: "Full Package", gradient: "from-rose-500 to-pink-600", count: "2,100+" }
];

const CITIES = [
  { name: "London", schools: 450, flag: "🇬🇧", color: "bg-rose-50 hover:bg-rose-100 border-rose-200" },
  { name: "Paris", schools: 320, flag: "🇫🇷", color: "bg-blue-50 hover:bg-blue-100 border-blue-200" },
  { name: "Berlin", schools: 280, flag: "🇩🇪", color: "bg-amber-50 hover:bg-amber-100 border-amber-200" },
  { name: "Brussels", schools: 150, flag: "🇧🇪", color: "bg-yellow-50 hover:bg-yellow-100 border-yellow-200" },
  { name: "Amsterdam", schools: 200, flag: "🇳🇱", color: "bg-orange-50 hover:bg-orange-100 border-orange-200" },
  { name: "Dublin", schools: 120, flag: "🇮🇪", color: "bg-emerald-50 hover:bg-emerald-100 border-emerald-200" },
  { name: "Madrid", schools: 190, flag: "🇪🇸", color: "bg-red-50 hover:bg-red-100 border-red-200" },
  { name: "Rome", schools: 160, flag: "🇮🇹", color: "bg-green-50 hover:bg-green-100 border-green-200" }
];

const TESTIMONIALS = [
  {
    name: "Sophie Martinez",
    location: "Paris, France",
    text: "I booked all my lessons from my phone — no more calling ten schools. The progress tracking feature kept me motivated throughout!",
    avatar: "SM",
    rating: 5,
    verified: true,
    course: "Intensive Course",
    passedIn: "6 weeks",
    gradient: "from-rose-500 to-pink-600"
  },
  {
    name: "Marco Rossi",
    location: "Berlin, Germany",
    text: "Compared prices instantly and saved €150. The instructor was professional and the car was brand new. Highly recommend!",
    avatar: "MR",
    rating: 5,
    verified: true,
    course: "Standard Package",
    passedIn: "8 weeks",
    gradient: "from-sky-500 to-blue-600"
  },
  {
    name: "Emma Kowalski",
    location: "Amsterdam, Netherlands",
    text: "The progress tracking kept me motivated. Passed my test first try with only 2 minor faults! The app made everything seamless.",
    avatar: "EK",
    rating: 5,
    verified: true,
    course: "10-Lesson Package",
    passedIn: "5 weeks",
    gradient: "from-emerald-500 to-teal-600"
  },
  {
    name: "James O'Brien",
    location: "London, UK",
    text: "Found a 5-star instructor near my office with flexible scheduling. As someone with a busy job, this was exactly what I needed.",
    avatar: "JO",
    rating: 5,
    verified: true,
    course: "Manual Transmission",
    passedIn: "10 weeks",
    gradient: "from-violet-600 to-purple-700"
  },
  {
    name: "Lisa Thompson",
    location: "Dublin, Ireland",
    text: "As a nervous driver, DRIVEE helped me find someone patient and experienced. My instructor changed my whole perspective on driving!",
    avatar: "LT",
    rating: 5,
    verified: true,
    course: "Beginner Package",
    passedIn: "12 weeks",
    gradient: "from-amber-500 to-orange-600"
  },
  {
    name: "Ahmed Samir",
    location: "Brussels, Belgium",
    text: "Found an English-speaking instructor easily and completed my course in just 6 weeks. The booking system is incredibly smooth.",
    avatar: "AS",
    rating: 5,
    verified: true,
    course: "Automatic Intensive",
    passedIn: "6 weeks",
    gradient: "from-cyan-500 to-sky-600"
  }
];

const STATS = [
  { value: "25,000", suffix: "+", label: "Students passed", icon: CheckCircle, color: "text-emerald-600", bg: "bg-emerald-50" },
  { value: "4.9", suffix: "/5", label: "Average rating", icon: Star, color: "text-amber-500", bg: "bg-amber-50" },
  { value: "850", suffix: "+", label: "Verified schools", icon: Shield, color: "text-violet-600", bg: "bg-violet-50" },
  { value: "24/7", suffix: "", label: "Online booking", icon: Clock, color: "text-sky-600", bg: "bg-sky-50" }
];

// ============================================================================
// UTILITY COMPONENTS
// ============================================================================

// Animated counter for statistics
const AnimatedCounter = ({ value, suffix = "", duration = 2000 }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    if (!isInView) return;
    
    const numericValue = parseFloat(value.replace(/[^0-9.]/g, ''));
    const isDecimal = value.includes('.');
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = 1 - Math.pow(1 - progress, 4);
      const currentValue = numericValue * easeProgress;
      
      setDisplayValue(isDecimal ? currentValue.toFixed(1) : Math.floor(currentValue));

      if (progress < 1) requestAnimationFrame(animate);
    };

    requestAnimationFrame(animate);
  }, [isInView, value, duration]);

  return (
    <span ref={ref} className="tabular-nums font-bold">
      {typeof displayValue === 'number' ? displayValue.toLocaleString() : displayValue}{suffix}
    </span>
  );
};

// Section wrapper with scroll-triggered animations
const Section = ({ children, className = "", id = "", delay = 0 }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <motion.section
      ref={ref}
      id={id}
      initial={{ opacity: 0, y: 48 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 48 }}
      transition={{ duration: 0.8, ease: tokens.easing.premium, delay }}
      className={className}
    >
      {children}
    </motion.section>
  );
};

// Section header component for consistency
const SectionHeader = ({ eyebrow, title, description, centered = true, light = false }) => (
  <div className={`${centered ? 'text-center' : ''} mb-12 md:mb-16`}>
    {eyebrow && (
      <motion.p
        variants={variants.fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className={`text-xs font-bold uppercase tracking-[0.2em] mb-4 ${light ? 'text-sky-300' : 'text-sky-600'}`}
      >
        {eyebrow}
      </motion.p>
    )}
    <motion.h2
      variants={variants.fadeUp}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      className={`text-3xl md:text-4xl lg:text-5xl font-extrabold tracking-tight mb-4 ${light ? 'text-white' : 'text-slate-900'}`}
    >
      {title}
    </motion.h2>
    {description && (
      <motion.p
        variants={variants.fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className={`text-lg md:text-xl max-w-2xl ${centered ? 'mx-auto' : ''} ${light ? 'text-slate-300' : 'text-slate-600'}`}
      >
        {description}
      </motion.p>
    )}
  </div>
);

// Floating notification card
const FloatingCard = ({ children, className = "", delay = 0, position = {} }) => (
  <motion.div
    initial={{ opacity: 0, y: 20, scale: 0.9 }}
    animate={{ opacity: 1, y: 0, scale: 1 }}
    transition={{ delay, duration: 0.6, ease: tokens.easing.premium }}
    className={`absolute bg-white rounded-2xl shadow-xl border border-slate-100 ${className}`}
    style={position}
  >
    {children}
  </motion.div>
);

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export default function Landing() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  
  // State
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [localeSelectorOpen, setLocaleSelectorOpen] = useState(false);
  const [currentLocale, setCurrentLocale] = useState(() => getInitialMarketingLocale());
  const [suggestedLocale, setSuggestedLocale] = useState(null);
  const [showSuggestionBanner, setShowSuggestionBanner] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState(null);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [filters, setFilters] = useState({
    location: "",
    school: "",
    vehicleType: "all"
  });

  // Scroll detection for navbar transformation
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Locale initialization
  useEffect(() => {
    changeLanguage(currentLocale.languageCode);
    const savedPref = getSavedLocalePreference();
    if (!savedPref) {
      const browserLocale = detectBrowserLocale();
      if (browserLocale.id !== currentLocale.id) {
        setSuggestedLocale(browserLocale);
        setShowSuggestionBanner(true);
      }
    }
  }, []);

  // Auto-rotate testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Handlers
  const handleLocaleChange = useCallback((localeId) => {
    const newLocale = getLocaleById(localeId);
    setCurrentLocale(newLocale);
    saveLocalePreference(localeId);
    changeLanguage(newLocale.languageCode);
    setLocaleSelectorOpen(false);
    setShowSuggestionBanner(false);
  }, []);

  const handleSearch = useCallback(() => {
    const params = new URLSearchParams({
      location: filters.location,
      school: filters.school,
      vehicleType: filters.vehicleType
    });
    navigate(`${createPageUrl("Marketplace")}?${params.toString()}`);
  }, [filters, navigate]);

  const updateFilter = useCallback((key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  }, []);

  // Memoized data
  const quickFilters = useMemo(() => [
    { label: t("landing.quickFilters.topRated"), value: "top-rated", icon: Star },
    { label: t("landing.quickFilters.bestValue"), value: "best-value", icon: DollarSign },
    { label: t("landing.quickFilters.availableThisWeek"), value: "available", icon: Calendar },
    { label: t("landing.quickFilters.beginnerFriendly"), value: "beginner", icon: GraduationCap }
  ], [t]);

  const steps = useMemo(() => [
    { 
      icon: Search, 
      title: t("landing.howItWorks.step1Title"), 
      description: t("landing.howItWorks.step1Desc"),
      color: "from-sky-500 to-blue-600"
    },
    { 
      icon: Calendar, 
      title: t("landing.howItWorks.step2Title"), 
      description: t("landing.howItWorks.step2Desc"),
      color: "from-violet-500 to-purple-600"
    },
    { 
      icon: Car, 
      title: t("landing.howItWorks.step3Title"), 
      description: t("landing.howItWorks.step3Desc"),
      color: "from-emerald-500 to-teal-600"
    }
  ], [t]);

  const faqs = useMemo(() => [
    { question: t("landing.faq.q1"), answer: t("landing.faq.a1") },
    { question: t("landing.faq.q2"), answer: t("landing.faq.a2") },
    { question: t("landing.faq.q3"), answer: t("landing.faq.a3") },
    { question: t("landing.faq.q4"), answer: t("landing.faq.a4") },
    { question: t("landing.faq.q5"), answer: t("landing.faq.a5") },
    { question: t("landing.faq.q6"), answer: t("landing.faq.a6") }
  ], [t]);

  const benefits = useMemo(() => [
    { icon: Search, title: "Compare & Save", desc: "Find the best prices from verified schools", stat: "€150+ saved" },
    { icon: Star, title: "Verified Reviews", desc: "Real reviews from real students", stat: "4.9★ average" },
    { icon: Calendar, title: "Book Instantly", desc: "No more phone calls—book 24/7", stat: "24/7 available" },
    { icon: TrendingUp, title: "Track Progress", desc: "See your improvement every lesson", stat: "100% visibility" },
    { icon: Shield, title: "Quality Guaranteed", desc: "All schools verified and certified", stat: "850+ schools" },
    { icon: Clock, title: "Flexible Schedule", desc: "Find slots that fit your life", stat: "Any time" }
  ], []);

  // SEO handled via SEOHead component now

  return (
    <div className="min-h-screen bg-white antialiased overflow-x-hidden">
      <SEOHead
        title="DRIVEE - Find Your Perfect Driving School | Compare & Book Online"
        description="Compare driving schools, read verified reviews, and book lessons online across Europe. Join 25,000+ students who found their perfect instructor. 100% free to use."
        keywords="driving school, driving lessons, book driving lessons online, driving instructor, learn to drive, driving test, theory test, practical exam"
        canonical={window.location.href}
      />
      
      {/* Global Styles */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
        
        * {
          font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
        }
        
        /* Text gradient */
        .text-gradient {
          background: linear-gradient(135deg, #3b82c4 0%, #a9d5ed 50%, #6c376f 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        
        body {
          -webkit-font-smoothing: antialiased;
        }
        
        /* Custom gradient text - keeping for backward compatibility */
        .gradient-text {
          background: linear-gradient(135deg, #1e3a5f 0%, #3b82c4 50%, #0d4f3c 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        
        /* Premium shadow system */
        .shadow-soft {
          box-shadow: 0 2px 8px -2px rgba(0,0,0,0.08), 0 4px 16px -4px rgba(0,0,0,0.12);
        }
        
        .shadow-elevated {
          box-shadow: 0 4px 12px -2px rgba(0,0,0,0.08), 0 8px 24px -4px rgba(0,0,0,0.14);
        }
        
        .shadow-dramatic {
          box-shadow: 0 8px 24px -4px rgba(0,0,0,0.12), 0 16px 48px -8px rgba(0,0,0,0.18);
        }
        
        /* Glass morphism */
        .glass {
          background: rgba(255, 255, 255, 0.85);
          backdrop-filter: blur(20px) saturate(180%);
          -webkit-backdrop-filter: blur(20px) saturate(180%);
        }
        
        /* Floating animation */
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-12px); }
        }
        
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) rotate(-1deg); }
          50% { transform: translateY(-8px) rotate(1deg); }
        }
        
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        
        .animate-float-slow {
          animation: float-slow 8s ease-in-out infinite;
        }
        
        /* Gradient border */
        .gradient-border {
          position: relative;
          background: white;
        }
        
        .gradient-border::before {
          content: '';
          position: absolute;
          inset: 0;
          padding: 2px;
          background: linear-gradient(135deg, #3b82c4, #16a34a, #7c3aed);
          border-radius: inherit;
          mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          mask-composite: exclude;
          -webkit-mask-composite: xor;
          pointer-events: none;
        }
        
        /* Smooth scrolling */
        html {
          scroll-behavior: smooth;
        }
        
        /* Hide scrollbar but keep functionality */
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        
        /* Noise texture overlay */
        .noise-overlay::after {
          content: '';
          position: absolute;
          inset: 0;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
          opacity: 0.03;
          pointer-events: none;
        }
      `}</style>

      {/* Locale Components */}
      <LocaleSelector 
        isOpen={localeSelectorOpen} 
        onClose={() => setLocaleSelectorOpen(false)} 
        onSelectLocale={handleLocaleChange} 
        currentLocaleId={currentLocale.id} 
      />
      <LocaleSuggestionBanner 
        suggestedLocale={suggestedLocale} 
        currentLocale={currentLocale} 
        onAccept={() => suggestedLocale && handleLocaleChange(suggestedLocale.id)} 
        onDismiss={() => { setShowSuggestionBanner(false); saveLocalePreference(currentLocale.id); }} 
        isVisible={showSuggestionBanner} 
      />
      <CookieBanner />

      {/* ========== NAVBAR ========== */}
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: tokens.easing.premium }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled ? 'glass border-b border-slate-200/60 shadow-soft' : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <Link to={createPageUrl("Landing")} className="flex items-center">
              <motion.img
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.2 }}
                src={LOGO_URL}
                alt="DRIVEE"
                className="h-16 lg:h-20 object-contain"
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              <Link
                to={createPageUrl("TheoryTestPrep")}
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-sky-700 hover:text-sky-800 hover:bg-sky-50 rounded-xl transition-all duration-200"
              >
                <GraduationCap className="w-4 h-4" />
                Theory Test Prep
              </Link>
              <Link
                to={createPageUrl("BusinessSolutions")}
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all duration-200"
              >
                <Briefcase className="w-4 h-4" />
                {t("landing.navbar.forSchools")}
              </Link>
              <Link
                to={createPageUrl("SchoolLogin")}
                className="px-4 py-2.5 text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all duration-200"
              >
                {t("landing.navbar.signIn")}
              </Link>
              <button
                onClick={() => setLocaleSelectorOpen(true)}
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all duration-200"
              >
                <span className="text-lg">{currentLocale.flag}</span>
                <span>{currentLocale.languageCode.toUpperCase()}</span>
              </button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleSearch}
                className="ml-2 px-6 py-2.5 bg-[#1e3a5f] hover:bg-[#162d4a] text-white text-sm font-semibold rounded-xl shadow-sm hover:shadow-md transition-all duration-300"
              >
                Get Started
              </motion.button>
            </div>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2.5 hover:bg-slate-100 rounded-xl transition-colors"
              aria-label="Toggle menu"
            >
              <AnimatePresence mode="wait">
                {mobileMenuOpen ? (
                  <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.2 }}>
                    <X className="w-6 h-6 text-slate-700" />
                  </motion.div>
                ) : (
                  <motion.div key="menu" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.2 }}>
                    <Menu className="w-6 h-6 text-slate-700" />
                  </motion.div>
                )}
              </AnimatePresence>
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: tokens.easing.premium }}
            className="fixed inset-0 z-40 bg-white pt-20 md:hidden overflow-y-auto"
          >
            <motion.div
              variants={variants.stagger}
              initial="hidden"
              animate="visible"
              className="p-6 space-y-3"
            >
              {[
                { to: createPageUrl("TheoryTestPrep"), icon: GraduationCap, label: "Theory Test Prep" },
                { to: createPageUrl("BusinessSolutions"), icon: Briefcase, label: t("landing.navbar.forSchools") },
                { to: createPageUrl("SchoolLogin"), icon: Users, label: t("landing.navbar.signIn") }
              ].map((item, i) => (
                <motion.div key={i} variants={variants.slideIn}>
                  <Link
                    to={item.to}
                    onClick={() => {
                      if (item.onClick) item.onClick();
                      setMobileMenuOpen(false);
                    }}
                    className="flex items-center gap-4 p-4 text-lg font-semibold text-slate-700 hover:bg-slate-50 rounded-2xl transition-colors"
                  >
                    <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
                      <item.icon className="w-5 h-5 text-slate-600" />
                    </div>
                    {item.label}
                  </Link>
                </motion.div>
              ))}
              <motion.div variants={variants.slideIn}>
                <button
                  onClick={() => { setLocaleSelectorOpen(true); setMobileMenuOpen(false); }}
                  className="flex items-center gap-4 w-full p-4 text-lg font-semibold text-slate-700 hover:bg-slate-50 rounded-2xl transition-colors"
                >
                  <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
                    <Globe className="w-5 h-5 text-slate-600" />
                  </div>
                  Change Region ({currentLocale.flag})
                </button>
              </motion.div>
              <motion.div variants={variants.slideIn} className="pt-4">
                <button
                  onClick={() => { handleSearch(); setMobileMenuOpen(false); }}
                  className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl text-lg shadow-elevated"
                >
                  Find Your Instructor
                </button>
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========== HERO SECTION ========== */}
      <section className="relative min-h-screen overflow-hidden pt-20 lg:pt-24">
        {/* Background Elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-slate-50 via-white to-[#f0f4f8]" />
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 0.5, scale: 1 }}
            transition={{ duration: 1.5 }}
            className="absolute top-20 right-0 w-[600px] h-[600px] bg-gradient-to-bl from-[#e8f1f8]/60 via-[#f0e8f4]/40 to-transparent rounded-full blur-3xl"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 0.3, scale: 1 }}
            transition={{ duration: 1.5, delay: 0.3 }}
            className="absolute bottom-0 left-1/4 w-[400px] h-[400px] bg-gradient-to-tr from-[#e8f4f0]/30 to-transparent rounded-full blur-3xl"
          />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-16">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
            {/* Left Column - Content */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: tokens.easing.premium }}
              className="text-center lg:text-left z-10"
            >
              {/* Trust Badge */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.6 }}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-white border border-slate-200/80 rounded-full text-sm text-slate-600 mb-8 shadow-sm"
              >
                <div className="flex items-center gap-1.5">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="text-amber-500 font-semibold">4.9</span>
                </div>
                <span className="w-px h-4 bg-slate-200" />
                <span className="font-medium">Trusted by 25,000+ students across Europe</span>
              </motion.div>

              {/* Main Headline */}
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.8 }}
                className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-extrabold text-slate-900 mb-6 leading-[1.05] tracking-tight"
              >
                {t("landing.hero.title")}
                <br />
                <span className="relative inline-block">
                  <span className="text-gradient">
                    {t("landing.hero.titleHighlight")}
                  </span>
                  <motion.svg
                    initial={{ pathLength: 0, opacity: 0 }}
                    animate={{ pathLength: 1, opacity: 1 }}
                    transition={{ delay: 1.2, duration: 0.8, ease: "easeOut" }}
                    className="absolute -bottom-2 left-0 w-full h-3"
                    viewBox="0 0 200 12"
                    preserveAspectRatio="none"
                  >
                    <motion.path
                      d="M2 10 Q100 2 198 10"
                      stroke="url(#underline-gradient)"
                      strokeWidth="4"
                      fill="none"
                      strokeLinecap="round"
                      initial={{ pathLength: 0 }}
                      animate={{ pathLength: 1 }}
                      transition={{ delay: 1.2, duration: 0.8 }}
                    />
                    <defs>
                      <linearGradient id="underline-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#3b82c4" />
                        <stop offset="50%" stopColor="#a9d5ed" />
                        <stop offset="100%" stopColor="#6c376f" />
                      </linearGradient>
                    </defs>
                  </motion.svg>
                </span>
              </motion.h1>

              {/* Subheadline */}
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.7 }}
                className="text-lg md:text-xl text-slate-600 mb-10 max-w-xl mx-auto lg:mx-0 leading-relaxed"
              >
                {t("landing.hero.subtitle")}
              </motion.p>

              {/* Search Card */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.7 }}
                className="bg-white rounded-2xl shadow-lg p-2 mb-6 border border-slate-100"
              >
                <div className="flex flex-col sm:flex-row gap-2">
                  {/* Location Input */}
                  <div className="flex-1 flex items-center gap-3 px-4 py-3 rounded-xl">
                    <MapPin className="w-5 h-5 text-slate-400 flex-shrink-0" />
                    <input
                      type="text"
                      placeholder={t("landing.hero.searchPlaceholder")}
                      value={filters.location}
                      onChange={(e) => updateFilter("location", e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                      className="w-full bg-transparent border-none focus:outline-none text-slate-700 placeholder-slate-400"
                    />
                  </div>

                  <div className="hidden sm:block w-px bg-slate-200 my-2" />

                  {/* School Input */}
                  <div className="flex-1 flex items-center gap-3 px-4 py-3 rounded-xl">
                    <Search className="w-5 h-5 text-slate-400 flex-shrink-0" />
                    <input
                      type="text"
                      placeholder={t("landing.hero.schoolPlaceholder")}
                      value={filters.school}
                      onChange={(e) => updateFilter("school", e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                      className="w-full bg-transparent border-none focus:outline-none text-slate-700 placeholder-slate-400"
                    />
                  </div>

                  {/* Search Button */}
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleSearch}
                    className="flex items-center justify-center gap-2 px-6 py-3 bg-[#3b82c4] hover:bg-[#2d6aa3] text-white rounded-xl transition-all duration-300 font-semibold"
                  >
                    <span className="hidden sm:inline">{t("landing.hero.searchButton")}</span>
                    <Search className="w-5 h-5 sm:hidden" />
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>
                </div>
              </motion.div>

              {/* Quick Filters */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="flex flex-wrap justify-center lg:justify-start gap-2.5 mb-10"
              >
                {quickFilters.map((filter, idx) => {
                  const Icon = filter.icon;
                  return (
                    <motion.button
                      key={filter.value}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.9 + idx * 0.05 }}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleSearch}
                      className="px-4 py-2.5 bg-white border border-slate-200 rounded-full text-slate-600 text-sm font-medium hover:border-slate-300 hover:shadow-sm transition-all duration-200 flex items-center gap-2"
                    >
                      <Icon className="w-4 h-4 text-slate-400" />
                      {filter.label}
                    </motion.button>
                  );
                })}
              </motion.div>

              {/* Trust Indicators */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="flex flex-wrap items-center justify-center lg:justify-start gap-6"
              >
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-500" />
                  <span className="text-sm font-medium text-slate-600">{t("landing.hero.freeToUse")}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#3b82c4]" />
                  <span className="text-sm font-medium text-slate-600">{t("landing.hero.verifiedSchools")}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-500" />
                  <span className="text-sm font-medium text-slate-600">{t("landing.hero.bestPrices")}</span>
                </div>
              </motion.div>
            </motion.div>

            {/* Right Column - Hero Visual */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, x: 40 }}
              animate={{ opacity: 1, scale: 1, x: 0 }}
              transition={{ duration: 0.9, delay: 0.3, ease: tokens.easing.premium }}
              className="relative hidden lg:flex justify-center items-center"
            >
              <div className="relative w-full max-w-lg">
                {/* Floating Card - Lesson Completed (Top Left) */}
                <motion.div
                  initial={{ opacity: 0, x: -30, y: 20 }}
                  animate={{ opacity: 1, x: 0, y: 0 }}
                  transition={{ delay: 1.2, duration: 0.7, ease: tokens.easing.premium }}
                  className="absolute -left-20 top-0 bg-white rounded-2xl p-4 shadow-lg border border-slate-100 z-20"
                  style={{ animation: 'float 6s ease-in-out infinite' }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-emerald-500" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Lesson completed</p>
                      <p className="text-sm font-bold text-slate-900">Highway driving ✓</p>
                    </div>
                  </div>
                </motion.div>

                {/* Floating Card - New Review (Top Right) */}
                <motion.div
                  initial={{ opacity: 0, x: 30, y: 20 }}
                  animate={{ opacity: 1, x: 0, y: 0 }}
                  transition={{ delay: 1.4, duration: 0.7, ease: tokens.easing.premium }}
                  className="absolute -right-16 top-8 bg-white rounded-2xl p-4 shadow-lg border border-slate-100 z-20"
                  style={{ animation: 'float 6s ease-in-out infinite', animationDelay: '1s' }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
                      <Star className="w-5 h-5 fill-amber-500 text-amber-500" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">New review</p>
                      <p className="text-sm font-bold text-slate-900">5.0 — "Amazing!"</p>
                    </div>
                  </div>
                </motion.div>

                {/* Floating Card - Next Lesson (Bottom) */}
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.6, duration: 0.7, ease: tokens.easing.premium }}
                  className="absolute right-4 -bottom-4 bg-[#1e3a5f] rounded-2xl p-4 text-white shadow-xl z-20"
                  style={{ animation: 'float 6s ease-in-out infinite', animationDelay: '2s' }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-xs text-white/70">Next lesson</p>
                      <p className="text-sm font-bold">Tomorrow, 10:00 AM</p>
                    </div>
                  </div>
                </motion.div>

                {/* Glow Effect */}
                <div className="absolute inset-0 bg-gradient-to-t from-sky-200/30 via-transparent to-transparent blur-3xl scale-125" />

                {/* Main Illustration */}
                <div className="relative bg-gradient-to-br from-[#e8f4fa] via-[#f0f7fc] to-[#f5e8f7] rounded-[40px] p-8 border border-slate-200/50 shadow-lg">
                  <img
                    src={HERO_ILLUSTRATION_URL}
                    alt="Learn to drive with DRIVEE"
                    className="w-full h-auto drop-shadow-xl"
                    loading="eager"
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Wave Divider */}
        <div className="absolute bottom-0 left-0 right-0 pointer-events-none">
          <svg viewBox="0 0 1440 100" fill="none" preserveAspectRatio="none" className="w-full h-16 md:h-24">
            <path d="M0 100L60 91.7C120 83.3 240 66.7 360 58.3C480 50 600 50 720 55C840 60 960 70 1080 75C1200 80 1320 76.7 1380 75L1440 73.3V100H0Z" fill="white" />
          </svg>
        </div>
      </section>

      {/* ========== STATS BAR ========== */}
      <Section className="py-12 md:py-16 bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center text-xs font-bold text-slate-400 uppercase tracking-[0.2em] mb-10"
          >
            Trusted by 25,000+ students across Europe
          </motion.p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {STATS.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className={`w-12 h-12 ${stat.bg} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                <p className="text-3xl md:text-4xl font-extrabold text-slate-900 mb-1">
                  {stat.value === "24/7" ? "24/7" : <AnimatedCounter value={stat.value} suffix={stat.suffix} />}
                </p>
                <p className="text-sm text-slate-500 font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>

      {/* ========== BENEFITS SECTION ========== */}
      <Section className="py-20 md:py-28 bg-slate-50/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            eyebrow="Why Students Love Us"
            title={t("landing.categories.title")}
            description="Compare prices, read reviews, and book lessons online in minutes."
          />

          <motion.div
            variants={variants.stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20"
          >
            {benefits.map((benefit, i) => (
              <motion.div
                key={i}
                variants={variants.fadeUp}
                whileHover={{ y: -6, transition: { duration: 0.2 } }}
                className="group bg-white rounded-2xl p-6 shadow-soft hover:shadow-elevated transition-all duration-300 border border-slate-100"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-sky-100 to-sky-50 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <benefit.icon className="w-7 h-7 text-sky-600" />
                  </div>
                  <span className="px-3 py-1.5 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-full border border-emerald-100">
                    {benefit.stat}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{benefit.title}</h3>
                <p className="text-slate-600 text-sm leading-relaxed">{benefit.desc}</p>
              </motion.div>
            ))}
          </motion.div>

          {/* Categories */}
          <div className="text-center mb-12">
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-xs font-bold text-sky-600 uppercase tracking-[0.2em] mb-4"
            >
              {t("landing.categories.subtitle")}
            </motion.p>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight"
            >
              Browse by Category
            </motion.h2>
          </div>

          <motion.div
            variants={variants.stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4"
          >
            {CATEGORIES.map((cat, i) => (
              <motion.button
                key={i}
                variants={variants.fadeUp}
                whileHover={{ y: -8, scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleSearch}
                className="group relative bg-white rounded-2xl p-6 text-center shadow-soft hover:shadow-elevated transition-all duration-300 border border-slate-100"
              >
                {cat.popular && (
                  <span className="absolute -top-2.5 -right-2 px-3 py-1 bg-emerald-500 text-white text-[10px] font-bold rounded-full shadow-lg">
                    Popular
                  </span>
                )}
                {cat.trending && (
                  <span className="absolute -top-2.5 -right-2 px-3 py-1 bg-gradient-to-r from-violet-500 to-purple-600 text-white text-[10px] font-bold rounded-full shadow-lg flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />Hot
                  </span>
                )}
                <div className={`w-14 h-14 bg-gradient-to-br ${cat.gradient} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300 shadow-lg`}>
                  <cat.icon className="w-7 h-7 text-white" />
                </div>
                <p className="text-sm font-bold text-slate-900 mb-1">{cat.label}</p>
                <p className="text-xs text-slate-500 font-medium">{cat.count} schools</p>
              </motion.button>
            ))}
          </motion.div>
        </div>
      </Section>

      {/* ========== HOW IT WORKS ========== */}
      <Section className="py-24 md:py-32 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            eyebrow="Simple Process"
            title={t("landing.howItWorks.title")}
            description={t("landing.howItWorks.subtitle")}
          />

          <div className="grid md:grid-cols-3 gap-8 lg:gap-12 mb-16">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: i * 0.15, duration: 0.6, ease: tokens.easing.premium }}
                className="relative text-center"
              >
                {/* Connector Line */}
                {i < steps.length - 1 && (
                  <div className="hidden md:block absolute top-16 left-[calc(50%+4rem)] w-[calc(100%-8rem)] h-0.5">
                    <div className="w-full h-full bg-gradient-to-r from-slate-200 via-slate-300 to-transparent rounded-full" />
                    <motion.div
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.5 + i * 0.2, duration: 0.8 }}
                      className="absolute inset-0 bg-gradient-to-r from-sky-400 to-transparent rounded-full origin-left"
                    />
                  </div>
                )}

                {/* Step Icon */}
                <div className="relative inline-block mb-8">
                  <motion.div
                    whileHover={{ scale: 1.05, rotate: 3 }}
                    className={`w-28 h-28 bg-gradient-to-br ${step.color} rounded-[32px] flex items-center justify-center mx-auto shadow-elevated`}
                  >
                    <step.icon className="w-12 h-12 text-white" />
                  </motion.div>
                  <div className="absolute -top-3 -right-3 w-10 h-10 bg-slate-900 text-white rounded-2xl flex items-center justify-center text-lg font-bold shadow-lg">
                    {i + 1}
                  </div>
                </div>

                <h3 className="text-xl md:text-2xl font-bold text-slate-900 mb-4">{step.title}</h3>
                <p className="text-slate-600 max-w-xs mx-auto leading-relaxed">{step.description}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={handleSearch}
              className="inline-flex items-center gap-3 px-10 py-5 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-bold shadow-elevated hover:shadow-dramatic transition-all text-lg group"
            >
              {t("landing.howItWorks.cta")}
              <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </motion.button>
          </motion.div>
        </div>
      </Section>

      {/* ========== CITIES SECTION ========== */}
      <Section className="py-20 md:py-28 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            eyebrow={t("landing.locations.subtitle")}
            title={t("landing.locations.title")}
          />

          <motion.div
            variants={variants.stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4"
          >
            {CITIES.map((city, i) => (
              <motion.button
                key={city.name}
                variants={variants.scaleIn}
                whileHover={{ y: -4, scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleSearch}
                className={`p-5 ${city.color} rounded-2xl text-left transition-all duration-300 border group`}
              >
                <div className="flex items-center gap-4">
                  <span className="text-4xl group-hover:scale-110 transition-transform duration-300">{city.flag}</span>
                  <div>
                    <p className="font-bold text-slate-900">{city.name}</p>
                    <p className="text-sm text-slate-600 font-medium">{city.schools} schools</p>
                  </div>
                </div>
              </motion.button>
            ))}
          </motion.div>
        </div>
      </Section>

      {/* ========== TESTIMONIALS ========== */}
      <Section className="py-24 md:py-32 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-4 mb-6"
            >
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-8 h-8 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <span className="text-4xl md:text-5xl font-extrabold text-slate-900">4.9/5</span>
            </motion.div>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-lg text-slate-600 mb-2"
            >
              {t("landing.testimonials.basedOn")}
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-sm text-slate-500"
            >
              {t("landing.testimonials.real")}
            </motion.p>
          </div>

          <motion.div
            variants={variants.stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {TESTIMONIALS.map((test, i) => (
              <motion.div
                key={i}
                variants={variants.fadeUp}
                whileHover={{ y: -6 }}
                className="bg-white rounded-2xl p-7 shadow-soft hover:shadow-elevated transition-all duration-300 border border-slate-100 relative"
              >
                {/* Quote Icon */}
                <div className="absolute top-6 right-6 w-10 h-10 bg-sky-50 rounded-full flex items-center justify-center">
                  <Quote className="w-5 h-5 text-sky-300" />
                </div>

                {/* Rating */}
                <div className="flex gap-0.5 mb-5">
                  {[...Array(test.rating)].map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                {/* Quote Text */}
                <p className="text-slate-700 mb-6 leading-relaxed">"{test.text}"</p>

                {/* Success Badge */}
                <div className="mb-6 p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                  <div className="flex items-center gap-2 text-emerald-700">
                    <CheckCircle className="w-4 h-4" />
                    <span className="text-sm font-semibold">Passed in {test.passedIn}</span>
                  </div>
                </div>

                {/* Author */}
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${test.gradient} rounded-full flex items-center justify-center shadow-lg`}>
                    <span className="text-white font-bold text-sm">{test.avatar}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-bold text-slate-900 truncate">{test.name}</p>
                      {test.verified && <BadgeCheck className="w-4 h-4 text-sky-500 flex-shrink-0" />}
                    </div>
                    <p className="text-sm text-slate-500 truncate">{test.location}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mt-12"
          >
            <motion.button
              whileHover={{ x: 4 }}
              onClick={handleSearch}
              className="inline-flex items-center gap-2 text-sky-600 font-bold hover:text-sky-700 transition-all"
            >
              {t("landing.testimonials.readAll")}
              <ArrowUpRight className="w-5 h-5" />
            </motion.button>
          </motion.div>
        </div>
      </Section>

      {/* ========== FAQ SECTION ========== */}
      <Section className="py-24 md:py-32 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            eyebrow="Got Questions?"
            title={t("landing.faq.title")}
            description={t("landing.faq.subtitle")}
          />

          <motion.div
            variants={variants.stagger}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            className="space-y-4 mb-12"
          >
            {faqs.map((faq, i) => (
              <motion.div
                key={i}
                variants={variants.fadeUp}
                className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-soft"
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}
                  className="w-full px-7 py-6 flex items-center justify-between text-left hover:bg-slate-50 transition-colors"
                >
                  <h3 className="font-bold text-slate-900 pr-4 text-base md:text-lg">{faq.question}</h3>
                  <motion.div
                    animate={{ rotate: expandedFaq === i ? 180 : 0 }}
                    transition={{ duration: 0.3, ease: tokens.easing.smooth }}
                    className="flex-shrink-0 w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center"
                  >
                    <ChevronDown className="w-5 h-5 text-slate-500" />
                  </motion.div>
                </button>
                <AnimatePresence>
                  {expandedFaq === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: tokens.easing.smooth }}
                    >
                      <div className="px-7 pb-6 text-slate-600 leading-relaxed border-t border-slate-100 pt-4">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <p className="text-slate-600 font-medium mb-5">{t("landing.faq.stillHaveQuestions")}</p>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center gap-2 px-7 py-4 bg-white border-2 border-slate-200 rounded-2xl font-bold text-slate-800 hover:border-slate-300 hover:shadow-elevated transition-all"
            >
              <MessageSquare className="w-5 h-5" />
              {t("landing.faq.contactSupport")}
            </motion.button>
          </motion.div>
        </div>
      </Section>

      {/* ========== FINAL CTA ========== */}
      <Section className="py-28 md:py-36 bg-gradient-to-b from-white to-slate-50 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-br from-sky-100/50 to-violet-100/30 rounded-full blur-3xl" />
        </div>
        
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: tokens.easing.premium }}
          >
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-slate-900 mb-8 tracking-tight leading-[1.1]"
            >
              {t("landing.cta.readyTitle")}
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-xl md:text-2xl text-slate-600 mb-12 max-w-3xl mx-auto leading-relaxed"
            >
              {t("landing.cta.readyDesc")}
            </motion.p>

            <motion.button
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={handleSearch}
              className="inline-flex items-center gap-3 px-14 py-6 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xl font-bold shadow-dramatic hover:shadow-xl transition-all group"
            >
              {t("landing.cta.findSchool")}
              <ChevronRight className="w-7 h-7 group-hover:translate-x-1 transition-transform" />
            </motion.button>

            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="text-sm text-slate-500 mt-8 font-medium"
            >
              {t("landing.cta.noCard")}
            </motion.p>
          </motion.div>
        </div>
      </Section>

      {/* ========== FOOTER ========== */}
      <footer className="py-20 md:py-24 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            {/* Brand */}
            <div className="lg:col-span-1">
              <img src={LOGO_URL} alt="DRIVEE" className="h-12 w-auto brightness-0 invert mb-6" />
              <p className="text-slate-400 text-sm leading-relaxed mb-8">
                {t("landing.footer.description")}
              </p>
              <div className="flex gap-3">
                {[Facebook, Twitter, Instagram, Linkedin].map((Icon, i) => (
                  <motion.a
                    key={i}
                    whileHover={{ scale: 1.1, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    href="#"
                    className="w-11 h-11 bg-slate-800 hover:bg-slate-700 rounded-xl flex items-center justify-center transition-all"
                  >
                    <Icon className="w-5 h-5 text-slate-400" />
                  </motion.a>
                ))}
              </div>
            </div>

            {/* Links */}
            {[
              {
                title: t("landing.footer.forStudents"),
                links: [
                  { to: createPageUrl("Marketplace"), label: t("landing.footer.findSchools") },
                  { label: t("landing.footer.howItWorks") }
                ]
              },
              {
                title: t("landing.footer.forSchools"),
                links: [
                  { to: createPageUrl("BusinessSolutions"), label: t("landing.footer.businessSolutions") },
                  { to: createPageUrl("SchoolLogin"), label: t("landing.footer.schoolLogin") }
                ]
              },
              {
                title: t("landing.footer.support"),
                links: [
                  { label: t("landing.footer.helpCenter") },
                  { label: t("landing.footer.contactUs") }
                ]
              }
            ].map((section, i) => (
              <div key={i}>
                <h3 className="font-bold text-sm mb-6 text-slate-300 uppercase tracking-wider">
                  {section.title}
                </h3>
                <ul className="space-y-4 text-sm">
                  {section.links.map((link, j) => (
                    <li key={j}>
                      {link.to ? (
                        <Link
                          to={link.to}
                          className="text-slate-400 hover:text-white transition-colors inline-flex items-center gap-1 group"
                        >
                          {link.label}
                          <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </Link>
                      ) : (
                        <button className="text-slate-400 hover:text-white transition-colors inline-flex items-center gap-1 group">
                          {link.label}
                          <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </button>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Bottom Bar */}
          <div className="pt-10 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6 text-sm">
            <p className="text-slate-500 font-medium">{t("landing.footer.copyright")}</p>
            <div className="flex gap-8">
              <button className="text-slate-500 hover:text-white transition-colors font-medium">
                {t("landing.footer.privacyPolicy")}
              </button>
              <button className="text-slate-500 hover:text-white transition-colors font-medium">
                {t("landing.footer.termsOfService")}
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}