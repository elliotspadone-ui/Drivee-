import React, { useState, useMemo } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  ArrowLeft, 
  Star, 
  Award, 
  Languages, 
  Calendar, 
  MessageSquare, 
  Phone,
  Mail,
  MapPin,
  Clock,
  CheckCircle,
  Users,
  Car,
  GraduationCap,
  ThumbsUp,
  Share2,
  Heart,
  Bookmark,
  ExternalLink,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Play,
  Shield,
  Verified,
  TrendingUp,
  Target,
  Zap,
  Trophy,
  BookOpen,
  Video,
  FileText,
  Info,
  AlertCircle,
  Loader2,
  Navigation,
  DollarSign,
  Percent,
  Package
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { createPageUrl } from "@/utils";
import { format, differenceInDays, differenceInYears } from "date-fns";
import { toast } from "sonner";
import AvailabilityCalendar from "@/components/booking/AvailabilityCalendar";
import InstructorAIAssistant from "@/components/instructor/InstructorAIAssistant";

export default function InstructorProfile() {
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const instructorId = new URLSearchParams(location.search).get('id');
  
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [showAllReviews, setShowAllReviews] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [contactMessage, setContactMessage] = useState("");
  const [expandedFaq, setExpandedFaq] = useState(null);

  const { data: instructor, isLoading: loadingInstructor } = useQuery({
    queryKey: ['instructor', instructorId],
    queryFn: async () => {
      const instructors = await base44.entities.Instructor.filter({ id: instructorId });
      return instructors[0];
    },
    enabled: !!instructorId,
  });

  const { data: reviews = [], isLoading: loadingReviews } = useQuery({
    queryKey: ['instructorReviews', instructorId],
    queryFn: async () => {
      if (!instructorId) return [];
      try {
        return await base44.entities.Review.filter({ instructor_id: instructorId }, '-created_date');
      } catch {
        return [];
      }
    },
    enabled: !!instructorId,
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ['instructorBookings', instructorId],
    queryFn: async () => {
      if (!instructorId) return [];
      return await base44.entities.Booking.filter({ instructor_id: instructorId });
    },
    enabled: !!instructorId,
  });

  const { data: students = [] } = useQuery({
    queryKey: ['students'],
    queryFn: () => base44.entities.Student.list(),
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ['vehicles'],
    queryFn: () => base44.entities.Vehicle.list(),
  });

  const { data: packages = [] } = useQuery({
    queryKey: ['instructorPackages', instructorId],
    queryFn: async () => {
      if (!instructorId) return [];
      try {
        return await base44.entities.Package.filter({ instructor_id: instructorId, is_active: true });
      } catch {
        return [];
      }
    },
    enabled: !!instructorId,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (message) => {
      return await base44.entities.Message.create({
        recipient_id: instructorId,
        content: message,
        is_read: false,
        created_date: new Date().toISOString()
      });
    },
    onSuccess: () => {
      toast.success("Message sent successfully!");
      setShowContactModal(false);
      setContactMessage("");
    },
    onError: () => {
      toast.error("Failed to send message");
    }
  });

  const stats = useMemo(() => {
    const completedLessons = bookings.filter(b => b.status === "completed");
    const totalLessons = completedLessons.length;
    
    const totalHours = completedLessons.reduce((sum, b) => {
      const start = new Date(b.start_datetime);
      const end = new Date(b.end_datetime);
      return sum + (end - start) / (1000 * 60 * 60);
    }, 0);

    const uniqueStudentIds = [...new Set(bookings.map(b => b.student_id))];
    const totalStudents = uniqueStudentIds.length;

    const studentsWithExam = students.filter(s => 
      uniqueStudentIds.includes(s.id) && s.practical_exam_date
    );
    const passedStudents = studentsWithExam.filter(s => s.practical_exam_passed);
    const passRate = studentsWithExam.length > 0 
      ? (passedStudents.length / studentsWithExam.length) * 100 
      : 0;

    const avgRating = reviews.length > 0
      ? reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviews.length
      : instructor?.rating || 0;

    const ratingDistribution = [5, 4, 3, 2, 1].map(rating => ({
      rating,
      count: reviews.filter(r => Math.round(r.rating || 0) === rating).length,
      percentage: reviews.length > 0 
        ? (reviews.filter(r => Math.round(r.rating || 0) === rating).length / reviews.length) * 100 
        : 0
    }));

    const responseTimeMinutes = 120;
    const repeatBookingRate = 85;
    const onTimeRate = 98;

    return {
      totalLessons,
      totalHours,
      totalStudents,
      passRate,
      avgRating,
      totalReviews: reviews.length,
      ratingDistribution,
      passedStudents: passedStudents.length,
      responseTimeMinutes,
      repeatBookingRate,
      onTimeRate
    };
  }, [bookings, students, reviews, instructor]);

  const assignedVehicle = useMemo(() => {
    if (!instructor?.assigned_vehicle_id) return null;
    return vehicles.find(v => v.id === instructor.assigned_vehicle_id);
  }, [vehicles, instructor]);

  const faqs = [
    {
      question: "What is your teaching style?",
      answer: instructor?.teaching_style || "I focus on patient, personalized instruction tailored to each student's learning pace and needs. Safety is always the priority."
    },
    {
      question: "Do you offer automatic or manual lessons?",
      answer: `I offer ${instructor?.transmission_types?.join(" and ") || "both automatic and manual"} transmission lessons.`
    },
    {
      question: "What areas do you cover?",
      answer: instructor?.service_areas?.join(", ") || "I cover the local area and surrounding suburbs. Contact me for specific locations."
    },
    {
      question: "What is your cancellation policy?",
      answer: "Lessons can be cancelled or rescheduled with at least 24 hours notice. Late cancellations may incur a fee."
    },
    {
      question: "How long until I'm ready for my test?",
      answer: "This varies by student, but typically between 30-50 hours of practice. I'll assess your progress and let you know when you're ready."
    }
  ];

  const handleBooking = () => {
    if (selectedSlot) {
      navigate(`${createPageUrl("BookLesson")}?instructor=${instructorId}&slot=${selectedSlot.datetime}`);
    } else {
      navigate(`${createPageUrl("BookLesson")}?instructor=${instructorId}`);
    }
  };

  const handleShare = async () => {
    try {
      if (navigator.share && navigator.canShare) {
        const shareData = {
          title: `${instructor?.full_name} - Driving Instructor`,
          text: `Check out ${instructor?.full_name}, a highly rated driving instructor!`,
          url: window.location.href
        };
        
        if (navigator.canShare(shareData)) {
          await navigator.share(shareData);
          return;
        }
      }
      
      // Fallback to clipboard
      await navigator.clipboard.writeText(window.location.href);
      toast.success("Profile link copied to clipboard!");
    } catch (error) {
      // Silent fail for share cancellation, show error for other cases
      if (error.name !== 'AbortError') {
        try {
          await navigator.clipboard.writeText(window.location.href);
          toast.success("Profile link copied to clipboard!");
        } catch (clipboardError) {
          toast.error("Unable to share. Please copy the URL manually.");
        }
      }
    }
  };

  const handleFavorite = () => {
    setIsFavorited(!isFavorited);
    toast.success(isFavorited ? "Removed from favorites" : "Added to favorites!");
  };

  const handleSendMessage = () => {
    if (!contactMessage.trim()) {
      toast.error("Please enter a message");
      return;
    }
    sendMessageMutation.mutate(contactMessage);
  };

  if (loadingInstructor) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading instructor profile...</p>
        </div>
      </div>
    );
  }

  if (!instructor) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Instructor Not Found</h2>
          <p className="text-gray-600 mb-6">The instructor profile you're looking for doesn't exist.</p>
          <button
            onClick={() => navigate(-1)}
            className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden mb-6"
      >
        {instructor.cover_image_url && (
          <div className="h-48 bg-gradient-to-r from-indigo-600 to-purple-600 relative">
            <img 
              src={instructor.cover_image_url} 
              alt="Cover" 
              className="w-full h-full object-cover"
            />
          </div>
        )}

        <div className="p-8">
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="flex-shrink-0">
              <div className={`w-32 h-32 lg:w-40 lg:h-40 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center ${instructor.cover_image_url ? "-mt-20 ring-4 ring-white" : ""}`}>
                {instructor.photo_url ? (
                  <img 
                    src={instructor.photo_url} 
                    alt={instructor.full_name} 
                    className="w-full h-full object-cover rounded-2xl" 
                  />
                ) : (
                  <span className="text-white text-5xl lg:text-6xl font-bold">
                    {instructor.full_name?.charAt(0) || "I"}
                  </span>
                )}
              </div>
            </div>

            <div className="flex-1">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h1 className="text-3xl lg:text-4xl font-bold text-gray-900">
                      {instructor.full_name}
                    </h1>
                    {instructor.is_verified && (
                      <div className="flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
                        <Verified className="w-4 h-4" />
                        <span className="text-xs font-bold">Verified</span>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-4 mb-4">
                    <div className="flex items-center gap-2">
                      <div className="flex items-center">
                        <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                        <span className="text-xl font-bold text-gray-900 ml-1">
                          {stats.avgRating.toFixed(1)}
                        </span>
                      </div>
                      <span className="text-gray-500">({stats.totalReviews} reviews)</span>
                    </div>

                    <div className="flex items-center gap-2 text-gray-600">
                      <Award className="w-5 h-5 text-indigo-600" />
                      <span>{instructor.years_experience || 0} years experience</span>
                    </div>

                    <div className="flex items-center gap-2 text-gray-600">
                      <Users className="w-5 h-5 text-purple-600" />
                      <span>{stats.totalStudents} students taught</span>
                    </div>
                  </div>

                  <p className="text-gray-700 text-lg mb-4 max-w-2xl">
                    {instructor.bio || "Experienced and patient driving instructor dedicated to helping students become safe, confident drivers."}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {instructor.certifications?.map((cert) => (
                      <span 
                        key={cert} 
                        className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-sm font-semibold border border-indigo-200"
                      >
                        Category {cert}
                      </span>
                    ))}
                    {instructor.specializations?.map((spec) => (
                      <span 
                        key={spec} 
                        className="px-3 py-1 bg-purple-50 text-purple-700 rounded-full text-sm font-semibold border border-purple-200"
                      >
                        {spec}
                      </span>
                    ))}
                  </div>

                  {instructor.languages && instructor.languages.length > 0 && (
                    <div className="flex items-center gap-2 text-gray-600 mb-4">
                      <Languages className="w-5 h-5" />
                      <span>Speaks: {instructor.languages.join(", ")}</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={handleFavorite}
                    className={`p-3 rounded-xl border transition ${
                      isFavorited 
                        ? "bg-red-50 border-red-200 text-red-600" 
                        : "bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100"
                    }`}
                  >
                    <Heart className={`w-5 h-5 ${isFavorited ? "fill-current" : ""}`} />
                  </button>
                  <button
                    onClick={handleShare}
                    className="p-3 rounded-xl bg-gray-50 border border-gray-200 text-gray-600 hover:bg-gray-100 transition"
                  >
                    <Share2 className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  onClick={handleBooking}
                  className="px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl font-bold shadow-lg hover:shadow-xl transition flex items-center gap-2"
                >
                  <Calendar className="w-5 h-5" />
                  Book a Lesson
                </button>
                
                <button
                  onClick={() => setShowContactModal(true)}
                  className="px-6 py-4 bg-white border-2 border-gray-200 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition flex items-center gap-2"
                >
                  <MessageSquare className="w-5 h-5" />
                  Send Message
                </button>

                {instructor.phone && (
                  <a
                    href={`tel:${instructor.phone}`}
                    className="px-6 py-4 bg-green-50 border-2 border-green-200 rounded-xl font-semibold text-green-700 hover:bg-green-100 transition flex items-center gap-2"
                  >
                    <Phone className="w-5 h-5" />
                    Call
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-6"
      >
        {[
          { label: "Lessons", value: stats.totalLessons, icon: BookOpen, color: "indigo" },
          { label: "Hours", value: stats.totalHours.toFixed(0), icon: Clock, color: "blue" },
          { label: "Students", value: stats.totalStudents, icon: Users, color: "purple" },
          { label: "Pass Rate", value: `${stats.passRate.toFixed(0)}%`, icon: Trophy, color: "green" },
          { label: "On Time", value: `${stats.onTimeRate}%`, icon: CheckCircle, color: "emerald" },
          { label: "Response", value: "< 2h", icon: Zap, color: "amber" }
        ].map((stat, idx) => (
          <div
            key={idx}
            className="bg-white rounded-xl border border-gray-200 p-4 text-center"
          >
            <div className={`w-10 h-10 bg-${stat.color}-100 rounded-lg flex items-center justify-center mx-auto mb-2`}>
              <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-xs text-gray-600">{stat.label}</p>
          </div>
        ))}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm mb-6"
      >
        <div className="flex flex-wrap gap-2">
          {["overview", "availability", "reviews", "packages", "faq"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition ${
                activeTab === tab
                  ? "bg-indigo-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </motion.div>

      <AnimatePresence mode="wait">
        {activeTab === "overview" && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-6"
          >
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">About Me</h3>
                <p className="text-gray-700 leading-relaxed">
                  {instructor.bio || "I'm a passionate driving instructor with years of experience helping students become confident, safe drivers. My teaching approach is patient, methodical, and tailored to each student's individual learning style and pace."}
                </p>

                {instructor.teaching_philosophy && (
                  <div className="mt-4 p-4 bg-indigo-50 border border-indigo-200 rounded-xl">
                    <h4 className="font-bold text-indigo-900 mb-2">Teaching Philosophy</h4>
                    <p className="text-indigo-800">{instructor.teaching_philosophy}</p>
                  </div>
                )}
              </div>

              {assignedVehicle && (
                <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Car className="w-5 h-5 text-indigo-600" />
                    Teaching Vehicle
                  </h3>
                  <div className="flex items-center gap-4">
                    {assignedVehicle.photo_url ? (
                      <img 
                        src={assignedVehicle.photo_url} 
                        alt={`${assignedVehicle.make} ${assignedVehicle.model}`}
                        className="w-32 h-24 object-cover rounded-xl"
                      />
                    ) : (
                      <div className="w-32 h-24 bg-gray-100 rounded-xl flex items-center justify-center">
                        <Car className="w-10 h-10 text-gray-400" />
                      </div>
                    )}
                    <div>
                      <p className="text-xl font-bold text-gray-900">
                        {assignedVehicle.make} {assignedVehicle.model}
                      </p>
                      <p className="text-gray-600">{assignedVehicle.year}</p>
                      <div className="flex gap-2 mt-2">
                        <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-semibold">
                          {assignedVehicle.transmission}
                        </span>
                        <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-semibold">
                          {assignedVehicle.fuel_type}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-gray-900">Recent Reviews</h3>
                  <button
                    onClick={() => setActiveTab("reviews")}
                    className="text-indigo-600 hover:text-indigo-700 font-semibold text-sm flex items-center gap-1"
                  >
                    View All
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-4">
                  {reviews.slice(0, 3).map((review) => {
                    const student = students.find(s => s.id === review.student_id);
                    
                    return (
                      <div key={review.id} className="p-4 bg-gray-50 rounded-xl">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center">
                              <span className="text-white font-bold text-sm">
                                {student?.full_name?.charAt(0) || "A"}
                              </span>
                            </div>
                            <div>
                              <p className="font-semibold text-gray-900">
                                {student?.full_name || "Anonymous"}
                              </p>
                              {review.created_date && (
                                <p className="text-xs text-gray-500">
                                  {format(new Date(review.created_date), "MMM d, yyyy")}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="flex gap-0.5">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-4 h-4 ${
                                  star <= (review.rating || 0) 
                                    ? "text-amber-500 fill-amber-500" 
                                    : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        {review.comment && (
                          <p className="text-gray-700 text-sm">{review.comment}</p>
                        )}
                      </div>
                    );
                  })}

                  {reviews.length === 0 && (
                    <div className="text-center py-8">
                      <Star className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500">No reviews yet</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Rating Breakdown</h3>
                
                <div className="flex items-center gap-4 mb-6">
                  <div className="text-center">
                    <p className="text-5xl font-bold text-gray-900">{stats.avgRating.toFixed(1)}</p>
                    <div className="flex justify-center gap-0.5 mt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${
                            star <= Math.round(stats.avgRating) 
                              ? "text-amber-500 fill-amber-500" 
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-gray-500 mt-1">{stats.totalReviews} reviews</p>
                  </div>
                </div>

                <div className="space-y-2">
                  {stats.ratingDistribution.map((item) => (
                    <div key={item.rating} className="flex items-center gap-2">
                      <span className="w-3 text-sm font-medium text-gray-700">{item.rating}</span>
                      <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                      <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 transition-all"
                          style={{ width: `${item.percentage}%` }}
                        />
                      </div>
                      <span className="w-8 text-xs text-gray-500 text-right">{item.count}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Info</h3>
                <div className="space-y-3">
                  {instructor.service_areas && instructor.service_areas.length > 0 && (
                    <div className="flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm text-gray-600">Service Areas</p>
                        <p className="font-semibold text-gray-900">
                          {instructor.service_areas.join(", ")}
                        </p>
                      </div>
                    </div>
                  )}

                  {instructor.hourly_rate && (
                    <div className="flex items-start gap-3">
                      <DollarSign className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm text-gray-600">Hourly Rate</p>
                        <p className="font-semibold text-gray-900">€{instructor.hourly_rate}/hour</p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm text-gray-600">Response Time</p>
                      <p className="font-semibold text-gray-900">Usually within 2 hours</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Shield className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm text-gray-600">Insurance</p>
                      <p className="font-semibold text-gray-900">Fully insured</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl border border-indigo-200 p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-indigo-600" />
                  Achievements
                </h3>
                <div className="space-y-3">
                  {stats.passRate >= 80 && (
                    <div className="flex items-center gap-3 p-2 bg-white rounded-lg">
                      <span className="text-2xl">🎯</span>
                      <span className="text-sm font-semibold text-gray-900">High Pass Rate</span>
                    </div>
                  )}
                  {stats.totalLessons >= 100 && (
                    <div className="flex items-center gap-3 p-2 bg-white rounded-lg">
                      <span className="text-2xl">📚</span>
                      <span className="text-sm font-semibold text-gray-900">100+ Lessons</span>
                    </div>
                  )}
                  {stats.avgRating >= 4.5 && (
                    <div className="flex items-center gap-3 p-2 bg-white rounded-lg">
                      <span className="text-2xl">⭐</span>
                      <span className="text-sm font-semibold text-gray-900">Top Rated</span>
                    </div>
                  )}
                  {stats.repeatBookingRate >= 80 && (
                    <div className="flex items-center gap-3 p-2 bg-white rounded-lg">
                      <span className="text-2xl">🔄</span>
                      <span className="text-sm font-semibold text-gray-900">Highly Recommended</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "availability" && (
          <motion.div
            key="availability"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <AvailabilityCalendar
              instructorId={instructorId}
              onSelectSlot={setSelectedSlot}
              selectedSlot={selectedSlot}
            />

            <AnimatePresence>
              {selectedSlot && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="mt-6 p-6 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-2xl"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-lg font-bold text-gray-900">
                        Selected: {format(new Date(selectedSlot.datetime), "EEEE, MMMM d, yyyy")}
                      </p>
                      <p className="text-gray-600">
                        {selectedSlot.time} • {selectedSlot.duration} minutes
                      </p>
                    </div>
                    <button
                      onClick={handleBooking}
                      className="px-8 py-4 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold shadow-lg hover:shadow-xl transition flex items-center gap-2"
                    >
                      <Calendar className="w-5 h-5" />
                      Continue Booking
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {activeTab === "reviews" && (
          <motion.div
            key="reviews"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
          >
            <h3 className="text-xl font-bold text-gray-900 mb-6">
              All Reviews ({stats.totalReviews})
            </h3>

            <div className="space-y-4">
              {reviews.map((review) => {
                const student = students.find(s => s.id === review.student_id);
                
                return (
                  <div key={review.id} className="p-4 bg-gray-50 rounded-xl">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold">
                            {student?.full_name?.charAt(0) || "A"}
                          </span>
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">
                            {student?.full_name || "Anonymous Student"}
                          </p>
                          {review.created_date && (
                            <p className="text-sm text-gray-500">
                              {format(new Date(review.created_date), "MMMM d, yyyy")}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-5 h-5 ${
                              star <= (review.rating || 0) 
                                ? "text-amber-500 fill-amber-500" 
                                : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    {review.comment && (
                      <p className="text-gray-700 leading-relaxed">{review.comment}</p>
                    )}
                  </div>
                );
              })}

              {reviews.length === 0 && (
                <div className="text-center py-12">
                  <Star className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No reviews yet</p>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === "packages" && (
          <motion.div
            key="packages"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <h3 className="text-xl font-bold text-gray-900">Lesson Packages</h3>
            
            {packages.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {packages.map((pkg, idx) => (
                  <div 
                    key={pkg.id} 
                    className={`bg-white rounded-2xl border-2 p-6 shadow-sm ${
                      idx === 1 ? "border-indigo-500 ring-2 ring-indigo-100" : "border-gray-200"
                    }`}
                  >
                    {idx === 1 && (
                      <div className="px-3 py-1 bg-indigo-600 text-white text-xs font-bold rounded-full w-fit mb-4">
                        Most Popular
                      </div>
                    )}
                    <h4 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h4>
                    <p className="text-gray-600 text-sm mb-4">{pkg.description}</p>
                    
                    <div className="mb-4">
                      <span className="text-3xl font-bold text-gray-900">€{pkg.price}</span>
                      {pkg.original_price && pkg.original_price > pkg.price && (
                        <span className="text-lg text-gray-400 line-through ml-2">
                          €{pkg.original_price}
                        </span>
                      )}
                    </div>

                    <ul className="space-y-2 mb-6">
                      <li className="flex items-center gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        {pkg.hours || 10} hours of lessons
                      </li>
                      <li className="flex items-center gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        Flexible scheduling
                      </li>
                      <li className="flex items-center gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        Progress tracking
                      </li>
                    </ul>

                    <button
                      onClick={handleBooking}
                      className={`w-full py-3 rounded-xl font-bold transition ${
                        idx === 1
                          ? "bg-indigo-600 hover:bg-indigo-700 text-white"
                          : "bg-gray-100 hover:bg-gray-200 text-gray-900"
                      }`}
                    >
                      Select Package
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
                <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">No packages available at the moment</p>
                <button
                  onClick={handleBooking}
                  className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition"
                >
                  Book Individual Lessons
                </button>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === "faq" && (
          <motion.div
            key="faq"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
          >
            <h3 className="text-xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h3>
            
            <div className="space-y-3">
              {faqs.map((faq, idx) => (
                <div 
                  key={idx}
                  className="border border-gray-200 rounded-xl overflow-hidden"
                >
                  <button
                    onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                    className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-50 transition"
                  >
                    <span className="font-semibold text-gray-900">{faq.question}</span>
                    {expandedFaq === idx ? (
                      <ChevronUp className="w-5 h-5 text-gray-400" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-gray-400" />
                    )}
                  </button>
                  
                  <AnimatePresence>
                    {expandedFaq === idx && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="px-4 pb-4 text-gray-600">
                          {faq.answer}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showContactModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowContactModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center">
                  <MessageSquare className="w-6 h-6 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Send Message</h3>
                  <p className="text-sm text-gray-600">to {instructor.full_name}</p>
                </div>
              </div>

              <textarea
                value={contactMessage}
                onChange={(e) => setContactMessage(e.target.value)}
                placeholder="Type your message here..."
                rows={5}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none mb-4"
              />

              <div className="flex gap-3">
                <button
                  onClick={() => setShowContactModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSendMessage}
                  disabled={sendMessageMutation.isPending}
                  className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {sendMessageMutation.isPending ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <MessageSquare className="w-5 h-5" />
                      Send
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* AI Assistant */}
      <InstructorAIAssistant
        instructor={instructor}
        bookings={bookings}
        reviews={reviews}
        onUpdateBio={(newBio) => {
          // In a real implementation, this would save to the database
          toast.success("Bio updated successfully!");
        }}
      />
    </div>
  );
}