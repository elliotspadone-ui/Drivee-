import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Clock,
  User,
  Car,
  MapPin,
  Phone,
  Mail,
  Navigation,
  CheckCircle,
  PlayCircle,
  XCircle,
  MessageSquare,
  FileText,
  AlertCircle,
  ArrowLeft,
  Loader2,
  Calendar,
  Target,
  TrendingUp,
  Award,
  ChevronRight,
  ChevronDown,
  Star,
  Coffee,
  Pause,
  StopCircle,
  RotateCcw,
  Edit,
  Trash2,
  Plus,
  Send,
  ExternalLink,
  Camera,
  Mic,
  AlertTriangle,
  Info,
  DollarSign,
  Zap,
  ThumbsUp,
  ThumbsDown,
  Flag,
  ClipboardList,
  ClipboardCheck,
  Timer,
  Eye,
  EyeOff,
  MoreVertical,
  X,
  RefreshCw,
  Sunrise,
  Sun,
  Moon,
  CloudRain,
  Wind,
  Thermometer,
  GraduationCap,
  BookOpen,
  Route,
  Gauge,
  Shield,
  Heart
} from "lucide-react";
import { format, isToday, isBefore, isAfter, differenceInMinutes, addMinutes, parseISO } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const SKILL_CATEGORIES = {
  vehicle_control: {
    label: "Vehicle Control",
    skills: ["Steering", "Gear Changes", "Clutch Control", "Braking", "Acceleration"]
  },
  observations: {
    label: "Observations",
    skills: ["Mirror Usage", "Blind Spot Checks", "Road Scanning", "Hazard Perception"]
  },
  maneuvers: {
    label: "Maneuvers",
    skills: ["Parallel Parking", "Bay Parking", "Reverse Parking", "Turn in Road", "Emergency Stop"]
  },
  road_procedure: {
    label: "Road Procedure",
    skills: ["Roundabouts", "Junctions", "Lane Discipline", "Speed Control", "Following Distance"]
  }
};

const LESSON_OUTCOMES = [
  { value: "excellent", label: "Excellent Progress", icon: Star, color: "green" },
  { value: "good", label: "Good Progress", icon: ThumbsUp, color: "blue" },
  { value: "satisfactory", label: "Satisfactory", icon: Target, color: "amber" },
  { value: "needs_work", label: "Needs More Practice", icon: RefreshCw, color: "orange" },
  { value: "struggling", label: "Struggling", icon: AlertTriangle, color: "red" }
];

export default function InstructorTodayLessons() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  
  const [user, setUser] = useState(null);
  const [instructor, setInstructor] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentLesson, setCurrentLesson] = useState(null);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [showAssessmentModal, setShowAssessmentModal] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showNoShowModal, setShowNoShowModal] = useState(false);
  const [lessonTimer, setLessonTimer] = useState(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [expandedBookingId, setExpandedBookingId] = useState(null);
  const [viewMode, setViewMode] = useState("timeline");

  const [lessonNotes, setLessonNotes] = useState("");
  const [privateNotes, setPrivateNotes] = useState("");
  const [lessonOutcome, setLessonOutcome] = useState("");
  const [skillAssessments, setSkillAssessments] = useState({});
  const [focusAreas, setFocusAreas] = useState([]);
  const [cancellationReason, setCancellationReason] = useState("");

  useEffect(() => {
    const loadUser = async () => {
      try {
        setIsLoading(true);
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        const instructors = await base44.entities.Instructor.filter({ email: currentUser.email });
        if (instructors.length > 0) {
          setInstructor(instructors[0]);
        }
      } catch (error) {
        console.error("Error loading user:", error);
        toast.error("Failed to load user data");
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  useEffect(() => {
    let interval;
    if (currentLesson && lessonTimer) {
      interval = setInterval(() => {
        setElapsedTime(differenceInMinutes(new Date(), lessonTimer));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [currentLesson, lessonTimer]);

  const { data: todayBookings = [], isLoading: loadingBookings, refetch: refetchBookings } = useQuery({
    queryKey: ['instructorTodayBookings', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      const bookings = await base44.entities.Booking.filter(
        { instructor_id: instructor.id },
        'start_datetime'
      );
      return bookings.filter(b => isToday(new Date(b.start_datetime)));
    },
    enabled: !!instructor,
    refetchInterval: 60000
  });

  const { data: students = [] } = useQuery({
    queryKey: ['students'],
    queryFn: () => base44.entities.Student.list(),
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ['vehicles'],
    queryFn: () => base44.entities.Vehicle.list(),
  });

  const { data: lessonTypes = [] } = useQuery({
    queryKey: ['lessonTypes'],
    queryFn: async () => {
      try {
        return await base44.entities.LessonType.list();
      } catch {
        return [];
      }
    },
  });

  const updateBookingMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Booking.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorTodayBookings'] });
    },
    onError: () => {
      toast.error("Failed to update lesson");
    }
  });

  const createLessonRecordMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.LessonRecord.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['lessonRecords'] });
    }
  });

  const updateStudentProgressMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Student.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
    }
  });

  const getStudent = useCallback((id) => students.find(s => s.id === id), [students]);
  const getVehicle = useCallback((id) => vehicles.find(v => v.id === id), [vehicles]);
  const getLessonType = useCallback((id) => lessonTypes.find(lt => lt.id === id), [lessonTypes]);

  const categorizedBookings = useMemo(() => {
    const now = new Date();
    
    return {
      inProgress: todayBookings.filter(b => b.status === "in_progress"),
      upcoming: todayBookings.filter(b => 
        (b.status === "confirmed" || b.status === "pending") && 
        isAfter(new Date(b.start_datetime), now)
      ).sort((a, b) => new Date(a.start_datetime) - new Date(b.start_datetime)),
      completed: todayBookings.filter(b => b.status === "completed"),
      cancelled: todayBookings.filter(b => b.status === "cancelled" || b.status === "no_show"),
      current: todayBookings.find(b => {
        const start = new Date(b.start_datetime);
        const end = new Date(b.end_datetime);
        return b.status === "confirmed" && isBefore(start, now) && isAfter(end, now);
      })
    };
  }, [todayBookings]);

  const stats = useMemo(() => {
    const totalHours = todayBookings.reduce((sum, b) => {
      if (b.status === "completed" || b.status === "in_progress") {
        const duration = differenceInMinutes(new Date(b.end_datetime), new Date(b.start_datetime));
        return sum + duration / 60;
      }
      return sum;
    }, 0);

    const earnings = todayBookings
      .filter(b => b.status === "completed")
      .reduce((sum, b) => sum + (b.instructor_earnings || b.price * 0.3 || 0), 0);

    const nextLesson = categorizedBookings.upcoming[0];
    const timeUntilNext = nextLesson 
      ? differenceInMinutes(new Date(nextLesson.start_datetime), new Date())
      : null;

    return {
      total: todayBookings.length,
      completed: categorizedBookings.completed.length,
      upcoming: categorizedBookings.upcoming.length,
      inProgress: categorizedBookings.inProgress.length,
      cancelled: categorizedBookings.cancelled.length,
      totalHours,
      earnings,
      nextLesson,
      timeUntilNext
    };
  }, [todayBookings, categorizedBookings]);

  const handleStartLesson = (booking) => {
    updateBookingMutation.mutate({
      id: booking.id,
      data: { 
        status: "in_progress",
        actual_start_time: new Date().toISOString()
      }
    }, {
      onSuccess: () => {
        setCurrentLesson(booking);
        setLessonTimer(new Date());
        toast.success("Lesson started!");
      }
    });
  };

  const handlePauseLesson = () => {
    toast.info("Lesson paused");
  };

  const handleCompleteLesson = (booking) => {
    setSelectedBooking(booking);
    setShowAssessmentModal(true);
  };

  const handleSubmitLessonCompletion = () => {
    if (!selectedBooking) return;

    const student = getStudent(selectedBooking.student_id);
    const duration = differenceInMinutes(
      new Date(selectedBooking.end_datetime), 
      new Date(selectedBooking.start_datetime)
    ) / 60;

    updateBookingMutation.mutate({
      id: selectedBooking.id,
      data: { 
        status: "completed",
        attendance_marked: true,
        actual_end_time: new Date().toISOString(),
        instructor_notes: lessonNotes,
        private_notes: privateNotes,
        lesson_outcome: lessonOutcome,
        skill_assessments: skillAssessments,
        focus_areas_next: focusAreas
      }
    }, {
      onSuccess: () => {
        createLessonRecordMutation.mutate({
          booking_id: selectedBooking.id,
          student_id: selectedBooking.student_id,
          instructor_id: instructor.id,
          date: new Date().toISOString(),
          duration_hours: duration,
          notes: lessonNotes,
          outcome: lessonOutcome,
          skills_covered: Object.keys(skillAssessments),
          assessment: skillAssessments
        });

        if (student) {
          const newHours = (student.total_hours_completed || 0) + duration;
          updateStudentProgressMutation.mutate({
            id: student.id,
            data: {
              total_hours_completed: newHours,
              last_lesson_date: new Date().toISOString()
            }
          });
        }

        setShowAssessmentModal(false);
        setCurrentLesson(null);
        setLessonTimer(null);
        setElapsedTime(0);
        resetAssessmentForm();
        toast.success("Lesson completed and recorded!");
      }
    });
  };

  const handleMarkNoShow = (booking) => {
    setSelectedBooking(booking);
    setShowNoShowModal(true);
  };

  const confirmNoShow = () => {
    if (!selectedBooking) return;

    updateBookingMutation.mutate({
      id: selectedBooking.id,
      data: { 
        status: "no_show",
        attendance_marked: true,
        no_show_time: new Date().toISOString()
      }
    }, {
      onSuccess: () => {
        setShowNoShowModal(false);
        setSelectedBooking(null);
        toast.warning("Student marked as no-show");
      }
    });
  };

  const handleCancelLesson = (booking) => {
    setSelectedBooking(booking);
    setShowCancelModal(true);
  };

  const confirmCancellation = () => {
    if (!selectedBooking || !cancellationReason) {
      toast.error("Please provide a cancellation reason");
      return;
    }

    updateBookingMutation.mutate({
      id: selectedBooking.id,
      data: { 
        status: "cancelled",
        cancellation_reason: cancellationReason,
        cancelled_by: "instructor",
        cancelled_at: new Date().toISOString()
      }
    }, {
      onSuccess: () => {
        setShowCancelModal(false);
        setSelectedBooking(null);
        setCancellationReason("");
        toast.info("Lesson cancelled");
      }
    });
  };

  const handleAddQuickNote = (booking) => {
    setSelectedBooking(booking);
    setLessonNotes(booking.instructor_notes || "");
    setShowNotesModal(true);
  };

  const handleSaveQuickNote = () => {
    if (!selectedBooking) return;

    updateBookingMutation.mutate({
      id: selectedBooking.id,
      data: { instructor_notes: lessonNotes }
    }, {
      onSuccess: () => {
        setShowNotesModal(false);
        setSelectedBooking(null);
        setLessonNotes("");
        toast.success("Notes saved");
      }
    });
  };

  const resetAssessmentForm = () => {
    setLessonNotes("");
    setPrivateNotes("");
    setLessonOutcome("");
    setSkillAssessments({});
    setFocusAreas([]);
    setSelectedBooking(null);
  };

  const toggleSkillAssessment = (skill, rating) => {
    setSkillAssessments(prev => ({
      ...prev,
      [skill]: prev[skill] === rating ? null : rating
    }));
  };

  const toggleFocusArea = (area) => {
    setFocusAreas(prev => 
      prev.includes(area) 
        ? prev.filter(a => a !== area)
        : [...prev, area]
    );
  };

  const formatTimeUntil = (minutes) => {
    if (minutes < 0) return "Started";
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  const getTimeOfDayIcon = () => {
    const hour = new Date().getHours();
    if (hour < 12) return Sunrise;
    if (hour < 18) return Sun;
    return Moon;
  };

  const TimeIcon = getTimeOfDayIcon();

  if (isLoading || loadingBookings) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading today's lessons...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Link
          to={createPageUrl("InstructorSchedule")}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Schedule
        </Link>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-2xl flex items-center justify-center">
              <TimeIcon className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Today's Lessons</h1>
              <p className="text-gray-600">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => refetchBookings()}
              className="p-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              <RefreshCw className="w-5 h-5 text-gray-600" />
            </button>
            <div className="flex gap-1 p-1 bg-gray-100 rounded-xl">
              <button
                onClick={() => setViewMode("timeline")}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${
                  viewMode === "timeline" ? "bg-white shadow-sm" : "hover:bg-gray-200"
                }`}
              >
                Timeline
              </button>
              <button
                onClick={() => setViewMode("cards")}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${
                  viewMode === "cards" ? "bg-white shadow-sm" : "hover:bg-gray-200"
                }`}
              >
                Cards
              </button>
            </div>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {[
          { label: "Total", value: stats.total, icon: Calendar, color: "indigo" },
          { label: "Completed", value: stats.completed, icon: CheckCircle, color: "green" },
          { label: "Upcoming", value: stats.upcoming, icon: Clock, color: "blue" },
          { label: "In Progress", value: stats.inProgress, icon: PlayCircle, color: "purple" },
          { label: "Hours", value: stats.totalHours.toFixed(1), icon: Timer, color: "amber" },
          { label: "Earnings", value: `€${stats.earnings.toFixed(0)}`, icon: DollarSign, color: "emerald" }
        ].map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm"
          >
            <div className={`w-10 h-10 bg-${stat.color}-100 rounded-lg flex items-center justify-center mb-2`}>
              <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-xs text-gray-600">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {stats.nextLesson && stats.timeUntilNext !== null && stats.timeUntilNext > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-2xl p-4"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-indigo-600" />
              <div>
                <p className="text-sm text-indigo-900">Next lesson in</p>
                <p className="text-xl font-bold text-indigo-600">
                  {formatTimeUntil(stats.timeUntilNext)}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">
                {format(new Date(stats.nextLesson.start_datetime), "h:mm a")}
              </p>
              <p className="font-semibold text-gray-900">
                {getStudent(stats.nextLesson.student_id)?.full_name}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {categorizedBookings.inProgress.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 border-2 border-indigo-300 rounded-2xl p-6 shadow-lg"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center animate-pulse">
              <PlayCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">Lesson In Progress</h3>
              <p className="text-sm text-gray-600">
                {elapsedTime > 0 && `${elapsedTime} minutes elapsed`}
              </p>
            </div>
          </div>

          {categorizedBookings.inProgress.map(booking => {
            const student = getStudent(booking.student_id);
            const vehicle = getVehicle(booking.vehicle_id);
            const lessonDuration = differenceInMinutes(
              new Date(booking.end_datetime),
              new Date(booking.start_datetime)
            );
            const progress = Math.min((elapsedTime / lessonDuration) * 100, 100);

            return (
              <div key={booking.id} className="bg-white rounded-xl p-6 shadow-sm">
                <div className="flex flex-col lg:flex-row gap-6">
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-2xl flex items-center justify-center">
                        <span className="text-white font-bold text-xl">
                          {student?.full_name?.charAt(0) || "S"}
                        </span>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-gray-900">{student?.full_name}</p>
                        <p className="text-gray-600">
                          {format(new Date(booking.start_datetime), "h:mm a")} - {format(new Date(booking.end_datetime), "h:mm a")}
                        </p>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-600">Progress</span>
                        <span className="font-semibold">{Math.round(progress)}%</span>
                      </div>
                      <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${progress}%` }}
                          className="h-full bg-gradient-to-r from-indigo-500 to-purple-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                      {student?.phone && (
                        <a
                          href={`tel:${student.phone}`}
                          className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl text-sm hover:bg-gray-100 transition"
                        >
                          <Phone className="w-4 h-4 text-gray-600" />
                          <span className="truncate">{student.phone}</span>
                        </a>
                      )}
                      {booking.pickup_location && (
                        <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl text-sm">
                          <MapPin className="w-4 h-4 text-gray-600" />
                          <span className="truncate">{booking.pickup_location}</span>
                        </div>
                      )}
                      {vehicle && (
                        <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl text-sm">
                          <Car className="w-4 h-4 text-gray-600" />
                          <span className="truncate">{vehicle.make} {vehicle.model}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl text-sm">
                        <Timer className="w-4 h-4 text-gray-600" />
                        <span>{lessonDuration} min lesson</span>
                      </div>
                    </div>

                    {booking.notes && (
                      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-4">
                        <p className="text-xs font-bold text-blue-900 mb-1">Student Notes</p>
                        <p className="text-sm text-blue-800">{booking.notes}</p>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col gap-3 lg:w-48">
                    <button
                      onClick={() => handleCompleteLesson(booking)}
                      className="px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                    >
                      <CheckCircle className="w-5 h-5" />
                      Complete
                    </button>

                    <button
                      onClick={() => handleAddQuickNote(booking)}
                      className="px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-xl font-semibold transition flex items-center justify-center gap-2"
                    >
                      <FileText className="w-5 h-5" />
                      Add Notes
                    </button>

                    {booking.pickup_location && (
                      <a
                        href={`https://maps.google.com/?q=${encodeURIComponent(booking.pickup_location)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-6 py-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl font-semibold transition flex items-center justify-center gap-2"
                      >
                        <Navigation className="w-5 h-5" />
                        Navigate
                      </a>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </motion.div>
      )}

      {categorizedBookings.current && categorizedBookings.inProgress.length === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-6"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-amber-600" />
              <div>
                <p className="font-bold text-amber-900">Lesson should have started</p>
                <p className="text-sm text-amber-700">
                  {getStudent(categorizedBookings.current.student_id)?.full_name} - 
                  Started at {format(new Date(categorizedBookings.current.start_datetime), "h:mm a")}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => handleStartLesson(categorizedBookings.current)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-sm transition"
              >
                Start Now
              </button>
              <button
                onClick={() => handleMarkNoShow(categorizedBookings.current)}
                className="px-4 py-2 bg-red-100 hover:bg-red-200 text-red-700 rounded-xl font-semibold text-sm transition"
              >
                No Show
              </button>
            </div>
          </div>
        </motion.div>
      )}

      <div className="space-y-4">
        {todayBookings.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
            <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-900 mb-2">No lessons scheduled</h3>
            <p className="text-gray-600 mb-6">You have a free day! Enjoy your time off.</p>
            <Link
              to={createPageUrl("InstructorSchedule")}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition inline-flex items-center gap-2"
            >
              <Calendar className="w-5 h-5" />
              View Full Schedule
            </Link>
          </div>
        ) : (
          <>
            {categorizedBookings.upcoming.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  Upcoming ({categorizedBookings.upcoming.length})
                </h3>
                <div className="space-y-3">
                  {categorizedBookings.upcoming.map((booking, index) => (
                    <LessonCard
                      key={booking.id}
                      booking={booking}
                      student={getStudent(booking.student_id)}
                      vehicle={getVehicle(booking.vehicle_id)}
                      lessonType={getLessonType(booking.lesson_type_id)}
                      index={index}
                      isExpanded={expandedBookingId === booking.id}
                      onToggleExpand={() => setExpandedBookingId(
                        expandedBookingId === booking.id ? null : booking.id
                      )}
                      onStart={() => handleStartLesson(booking)}
                      onCancel={() => handleCancelLesson(booking)}
                      onAddNote={() => handleAddQuickNote(booking)}
                      variant="upcoming"
                    />
                  ))}
                </div>
              </div>
            )}

            {categorizedBookings.completed.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  Completed ({categorizedBookings.completed.length})
                </h3>
                <div className="space-y-3">
                  {categorizedBookings.completed.map((booking, index) => (
                    <LessonCard
                      key={booking.id}
                      booking={booking}
                      student={getStudent(booking.student_id)}
                      vehicle={getVehicle(booking.vehicle_id)}
                      lessonType={getLessonType(booking.lesson_type_id)}
                      index={index}
                      isExpanded={expandedBookingId === booking.id}
                      onToggleExpand={() => setExpandedBookingId(
                        expandedBookingId === booking.id ? null : booking.id
                      )}
                      onAddNote={() => handleAddQuickNote(booking)}
                      variant="completed"
                    />
                  ))}
                </div>
              </div>
            )}

            {categorizedBookings.cancelled.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <XCircle className="w-5 h-5 text-red-600" />
                  Cancelled / No Show ({categorizedBookings.cancelled.length})
                </h3>
                <div className="space-y-3">
                  {categorizedBookings.cancelled.map((booking, index) => (
                    <LessonCard
                      key={booking.id}
                      booking={booking}
                      student={getStudent(booking.student_id)}
                      vehicle={getVehicle(booking.vehicle_id)}
                      lessonType={getLessonType(booking.lesson_type_id)}
                      index={index}
                      isExpanded={expandedBookingId === booking.id}
                      onToggleExpand={() => setExpandedBookingId(
                        expandedBookingId === booking.id ? null : booking.id
                      )}
                      variant="cancelled"
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <AnimatePresence>
        {showAssessmentModal && selectedBooking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowAssessmentModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Complete Lesson</h3>
                  <p className="text-sm text-gray-600">
                    {getStudent(selectedBooking.student_id)?.full_name}
                  </p>
                </div>
                <button
                  onClick={() => {
                    setShowAssessmentModal(false);
                    resetAssessmentForm();
                  }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-3">Overall Outcome</label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {LESSON_OUTCOMES.map(({ value, label, icon: Icon, color }) => (
                      <button
                        key={value}
                        onClick={() => setLessonOutcome(value)}
                        className={`p-3 rounded-xl border-2 transition flex items-center gap-2 ${
                          lessonOutcome === value
                            ? `border-${color}-500 bg-${color}-50`
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <Icon className={`w-5 h-5 text-${color}-600`} />
                        <span className="text-sm font-semibold">{label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-3">Skills Assessment</label>
                  {Object.entries(SKILL_CATEGORIES).map(([category, { label, skills }]) => (
                    <div key={category} className="mb-4">
                      <p className="text-xs font-semibold text-gray-500 uppercase mb-2">{label}</p>
                      <div className="flex flex-wrap gap-2">
                        {skills.map((skill) => (
                          <div key={skill} className="flex items-center gap-1">
                            <span className="text-sm text-gray-700 mr-1">{skill}:</span>
                            {[1, 2, 3, 4, 5].map((rating) => (
                              <button
                                key={rating}
                                onClick={() => toggleSkillAssessment(skill, rating)}
                                className={`w-6 h-6 rounded-full text-xs font-bold transition ${
                                  skillAssessments[skill] === rating
                                    ? "bg-indigo-600 text-white"
                                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                                }`}
                              >
                                {rating}
                              </button>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Lesson Notes (shared with student)</label>
                  <textarea
                    value={lessonNotes}
                    onChange={(e) => setLessonNotes(e.target.value)}
                    placeholder="What was covered, progress made, areas to focus on..."
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Private Notes (instructor only)</label>
                  <textarea
                    value={privateNotes}
                    onChange={(e) => setPrivateNotes(e.target.value)}
                    placeholder="Personal observations, concerns, strategies..."
                    rows={2}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-3">Focus Areas for Next Lesson</label>
                  <div className="flex flex-wrap gap-2">
                    {Object.values(SKILL_CATEGORIES).flatMap(c => c.skills).slice(0, 10).map((area) => (
                      <button
                        key={area}
                        onClick={() => toggleFocusArea(area)}
                        className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition ${
                          focusAreas.includes(area)
                            ? "bg-indigo-600 text-white"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                        }`}
                      >
                        {area}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowAssessmentModal(false);
                    resetAssessmentForm();
                  }}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmitLessonCompletion}
                  disabled={!lessonOutcome || updateBookingMutation.isPending}
                  className="flex-1 px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {updateBookingMutation.isPending ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <CheckCircle className="w-5 h-5" />
                      Complete Lesson
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showNotesModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowNotesModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Lesson Notes</h3>
                <button
                  onClick={() => setShowNotesModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <textarea
                value={lessonNotes}
                onChange={(e) => setLessonNotes(e.target.value)}
                placeholder="Add notes for this lesson..."
                rows={5}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none mb-4"
              />

              <div className="flex gap-3">
                <button
                  onClick={() => setShowNotesModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveQuickNote}
                  disabled={updateBookingMutation.isPending}
                  className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition disabled:opacity-50"
                >
                  Save Notes
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showNoShowModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowNoShowModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertTriangle className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Mark as No Show?</h3>
                <p className="text-gray-600">
                  This will record that {getStudent(selectedBooking?.student_id)?.full_name} did not show up for their lesson.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowNoShowModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmNoShow}
                  disabled={updateBookingMutation.isPending}
                  className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold transition disabled:opacity-50"
                >
                  Confirm No Show
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCancelModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowCancelModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Cancel Lesson</h3>
                <button
                  onClick={() => setShowCancelModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Reason for cancellation</label>
                <select
                  value={cancellationReason}
                  onChange={(e) => setCancellationReason(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 mb-4"
                >
                  <option value="">Select a reason...</option>
                  <option value="instructor_sick">Instructor unwell</option>
                  <option value="vehicle_issue">Vehicle issue</option>
                  <option value="weather">Weather conditions</option>
                  <option value="emergency">Personal emergency</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowCancelModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Keep Lesson
                </button>
                <button
                  onClick={confirmCancellation}
                  disabled={!cancellationReason || updateBookingMutation.isPending}
                  className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold transition disabled:opacity-50"
                >
                  Cancel Lesson
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function LessonCard({ 
  booking, 
  student, 
  vehicle, 
  lessonType,
  index, 
  isExpanded, 
  onToggleExpand,
  onStart,
  onComplete,
  onCancel,
  onNoShow,
  onAddNote,
  variant = "upcoming"
}) {
  const statusColors = {
    upcoming: "border-indigo-200 bg-white",
    completed: "border-green-200 bg-green-50",
    cancelled: "border-red-200 bg-red-50",
    no_show: "border-red-200 bg-red-50"
  };

  const now = new Date();
  const startTime = new Date(booking.start_datetime);
  const endTime = new Date(booking.end_datetime);
  const minutesUntil = differenceInMinutes(startTime, now);
  const duration = differenceInMinutes(endTime, startTime);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`rounded-xl border-2 shadow-sm overflow-hidden ${statusColors[variant]}`}
    >
      <div 
        className="p-4 cursor-pointer hover:bg-gray-50 transition"
        onClick={onToggleExpand}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="text-center min-w-[60px]">
              <p className="text-lg font-bold text-gray-900">
                {format(startTime, "h:mm")}
              </p>
              <p className="text-xs text-gray-600">{format(startTime, "a")}</p>
            </div>

            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold">
                {student?.full_name?.charAt(0) || "S"}
              </span>
            </div>

            <div>
              <p className="font-bold text-gray-900">{student?.full_name || "Unknown Student"}</p>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <span>{duration} min</span>
                {lessonType && (
                  <>
                    <span>•</span>
                    <span>{lessonType.name}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {variant === "upcoming" && minutesUntil > 0 && minutesUntil <= 30 && (
              <span className="px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-bold">
                In {minutesUntil} min
              </span>
            )}

            {variant === "completed" && booking.lesson_outcome && (
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                booking.lesson_outcome === "excellent" ? "bg-green-100 text-green-700" :
                booking.lesson_outcome === "good" ? "bg-blue-100 text-blue-700" :
                "bg-gray-100 text-gray-700"
              }`}>
                {LESSON_OUTCOMES.find(o => o.value === booking.lesson_outcome)?.label || booking.lesson_outcome}
              </span>
            )}

            {variant === "cancelled" && (
              <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-bold">
                {booking.status === "no_show" ? "No Show" : "Cancelled"}
              </span>
            )}

            {isExpanded ? (
              <ChevronDown className="w-5 h-5 text-gray-400" />
            ) : (
              <ChevronRight className="w-5 h-5 text-gray-400" />
            )}
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 pt-0 border-t border-gray-200">
              <div className="grid md:grid-cols-2 gap-4 mt-4">
                {student?.phone && (
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4 text-gray-400" />
                    <a href={`tel:${student.phone}`} className="text-indigo-600 hover:underline">
                      {student.phone}
                    </a>
                  </div>
                )}
                {booking.pickup_location && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-700">{booking.pickup_location}</span>
                  </div>
                )}
                {vehicle && (
                  <div className="flex items-center gap-2 text-sm">
                    <Car className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-700">{vehicle.make} {vehicle.model}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-sm">
                  <Timer className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-700">{duration} minutes</span>
                </div>
              </div>

              {booking.notes && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-4">
                  <p className="text-xs font-bold text-blue-900 mb-1">Notes</p>
                  <p className="text-sm text-blue-800">{booking.notes}</p>
                </div>
              )}

              {booking.instructor_notes && (
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 mt-2">
                  <p className="text-xs font-bold text-purple-900 mb-1">Instructor Notes</p>
                  <p className="text-sm text-purple-800">{booking.instructor_notes}</p>
                </div>
              )}

              {variant === "upcoming" && (
                <div className="flex flex-wrap gap-2 mt-4">
                  {onStart && (
                    <button
                      onClick={(e) => { e.stopPropagation(); onStart(); }}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-sm transition flex items-center gap-2"
                    >
                      <PlayCircle className="w-4 h-4" />
                      Start
                    </button>
                  )}
                  {student?.phone && (
                    <a
                      href={`tel:${student.phone}`}
                      onClick={(e) => e.stopPropagation()}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-lg font-semibold text-sm transition flex items-center gap-2"
                    >
                      <Phone className="w-4 h-4" />
                      Call
                    </a>
                  )}
                  {booking.pickup_location && (
                    <a
                      href={`https://maps.google.com/?q=${encodeURIComponent(booking.pickup_location)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-lg font-semibold text-sm transition flex items-center gap-2"
                    >
                      <Navigation className="w-4 h-4" />
                      Navigate
                    </a>
                  )}
                  {onAddNote && (
                    <button
                      onClick={(e) => { e.stopPropagation(); onAddNote(); }}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-lg font-semibold text-sm transition flex items-center gap-2"
                    >
                      <FileText className="w-4 h-4" />
                      Notes
                    </button>
                  )}
                  {onCancel && (
                    <button
                      onClick={(e) => { e.stopPropagation(); onCancel(); }}
                      className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 rounded-lg font-semibold text-sm transition flex items-center gap-2"
                    >
                      <XCircle className="w-4 h-4" />
                      Cancel
                    </button>
                  )}
                </div>
              )}

              {variant === "completed" && onAddNote && (
                <div className="flex flex-wrap gap-2 mt-4">
                  <button
                    onClick={(e) => { e.stopPropagation(); onAddNote(); }}
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-lg font-semibold text-sm transition flex items-center gap-2"
                  >
                    <Edit className="w-4 h-4" />
                    Edit Notes
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}