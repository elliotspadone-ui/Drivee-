import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Calendar, 
  Clock, 
  Phone, 
  MessageSquare, 
  User, 
  Car, 
  MapPin, 
  Check, 
  X, 
  FileText, 
  DollarSign, 
  AlertCircle, 
  Navigation,
  ArrowLeft,
  Loader2,
  ChevronLeft,
  ChevronRight,
  Plus,
  Settings,
  RefreshCw,
  Filter,
  Search,
  Eye,
  Edit,
  Trash2,
  Copy,
  ExternalLink,
  CalendarDays,
  CalendarRange,
  LayoutGrid,
  List,
  Zap,
  Target,
  Award,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Pause,
  Play,
  MoreVertical,
  Send,
  Repeat,
  Bell,
  BellOff,
  Sunrise,
  Sunset,
  Coffee,
  Moon,
  Sun,
  CloudRain,
  Wind,
  Thermometer,
  Timer,
  Gauge,
  Flag,
  Star,
  Heart,
  ThumbsUp,
  ThumbsDown,
  BookOpen,
  GraduationCap,
  Route,
  Fuel,
  ParkingCircle,
  CircleDot,
  RotateCcw,
  Download,
  Upload,
  Share2,
  Printer
} from "lucide-react";
import { 
  format, 
  addDays, 
  subDays,
  addWeeks,
  subWeeks,
  addMonths,
  subMonths,
  startOfWeek, 
  endOfWeek,
  startOfMonth,
  endOfMonth,
  startOfDay,
  endOfDay,
  eachDayOfInterval,
  eachHourOfInterval,
  isSameDay,
  isSameMonth,
  isToday,
  isPast,
  isFuture,
  isWithinInterval,
  differenceInMinutes,
  differenceInHours,
  parseISO,
  setHours,
  setMinutes,
  getDay,
  getHours,
  getMinutes
} from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { useInstructorAuth } from "@/components/instructor/useInstructorAuth";
import InstructorOnboarding from "@/components/instructor/InstructorOnboarding";
import QueryErrorBoundary from "@/components/common/QueryErrorBoundary";
import SkeletonLoader from "@/components/common/SkeletonLoader";
import { logger } from "@/components/utils/config";

const LESSON_TYPES = {
  practical_driving: { 
    label: "Practical Driving", 
    color: "indigo", 
    icon: Car,
    description: "Standard driving lesson"
  },
  theory: { 
    label: "Theory", 
    color: "purple", 
    icon: BookOpen,
    description: "Theory instruction"
  },
  test_prep: { 
    label: "Test Preparation", 
    color: "green", 
    icon: Target,
    description: "Driving test preparation"
  },
  highway: { 
    label: "Highway Driving", 
    color: "blue", 
    icon: Route,
    description: "Motorway/highway practice"
  },
  parking: { 
    label: "Parking Practice", 
    color: "amber", 
    icon: ParkingCircle,
    description: "Parking maneuvers"
  },
  night_driving: { 
    label: "Night Driving", 
    color: "slate", 
    icon: Moon,
    description: "Night time driving"
  },
  mock_test: { 
    label: "Mock Test", 
    color: "red", 
    icon: Flag,
    description: "Practice test simulation"
  },
  assessment: { 
    label: "Assessment", 
    color: "cyan", 
    icon: Gauge,
    description: "Skills assessment"
  }
};

const BOOKING_STATUS = {
  pending: { label: "Pending", color: "amber", icon: Clock },
  confirmed: { label: "Confirmed", color: "blue", icon: CheckCircle },
  in_progress: { label: "In Progress", color: "indigo", icon: Play },
  completed: { label: "Completed", color: "green", icon: Check },
  cancelled: { label: "Cancelled", color: "gray", icon: X },
  no_show: { label: "No Show", color: "red", icon: XCircle },
  rescheduled: { label: "Rescheduled", color: "purple", icon: Repeat }
};

const TIME_SLOTS = Array.from({ length: 28 }, (_, i) => {
  const hour = Math.floor(i / 2) + 7;
  const minute = (i % 2) * 30;
  return { hour, minute, label: `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}` };
});

export default function InstructorSchedule() {
  const queryClient = useQueryClient();
  
  const auth = useInstructorAuth();
  const effectiveUser = auth.data?.effectiveUser || null;
  const effectiveInstructor = auth.data?.effectiveInstructor || null;
  const authStatus = auth.data?.status || "loading";
  
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [view, setView] = useState("day");
  const [activeTab, setActiveTab] = useState("schedule");
  
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [showQuickActions, setShowQuickActions] = useState(null);
  
  const [lessonNotes, setLessonNotes] = useState("");
  const [skillRatings, setSkillRatings] = useState({});
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const { data: allBookings = [], isLoading: loadingBookings, error: bookingsError, refetch: refetchBookings } = useQuery({
    queryKey: ['instructorAllBookings', effectiveInstructor?.id, effectiveInstructor?.school_id],
    queryFn: async () => {
      if (!effectiveInstructor) return [];
      return await base44.entities.Booking.filter({ 
        instructor_id: effectiveInstructor.id,
        school_id: effectiveInstructor.school_id 
      }, 'start_datetime', 200);
    },
    enabled: !!effectiveInstructor,
    staleTime: 60000,
  });

  const { data: students = [] } = useQuery({
    queryKey: ['students', effectiveInstructor?.school_id],
    queryFn: () => effectiveInstructor?.school_id ? base44.entities.Student.filter({ school_id: effectiveInstructor.school_id }, "-created_date", 200) : [],
    enabled: !!effectiveInstructor?.school_id,
    staleTime: 300000,
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ['vehicles', effectiveInstructor?.school_id],
    queryFn: () => effectiveInstructor?.school_id ? base44.entities.Vehicle.filter({ school_id: effectiveInstructor.school_id }, "-created_date", 50) : [],
    enabled: !!effectiveInstructor?.school_id,
    staleTime: 300000,
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ['invoices', effectiveInstructor?.id, effectiveInstructor?.school_id],
    queryFn: () => effectiveInstructor ? base44.entities.Invoice.filter({ 
      instructor_id: effectiveInstructor.id,
      school_id: effectiveInstructor.school_id 
    }, "-issue_date", 100) : [],
    enabled: !!effectiveInstructor,
    staleTime: 300000,
  });

  const { data: lessonRecords = [] } = useQuery({
    queryKey: ['lessonRecords', instructor?.id],
    queryFn: async () => {
      try {
        return await base44.entities.LessonRecord.filter({ instructor_id: instructor?.id });
      } catch {
        return [];
      }
    },
    enabled: !!instructor,
  });

  const updateBookingMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Booking.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorAllBookings'] });
      toast.success("Booking updated successfully");
    },
    onError: () => {
      toast.error("Failed to update booking");
    }
  });

  const createLessonRecordMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.LessonRecord.create({
        ...data,
        school_id: effectiveInstructor.school_id
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['lessonRecords'] });
      toast.success("Lesson record saved");
    },
    onError: (err) => {
      logger.error("Failed to save lesson record:", err);
      toast.error("Failed to save lesson record");
    }
  });

  const createInvoiceMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.Invoice.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invoices'] });
      setShowInvoiceModal(false);
      toast.success("Invoice created successfully");
    },
    onError: () => {
      toast.error("Failed to create invoice");
    }
  });

  const getStudent = useCallback((id) => students.find(s => s.id === id), [students]);
  const getVehicle = useCallback((id) => vehicles.find(v => v.id === id), [vehicles]);
  const hasInvoice = useCallback((bookingId) => invoices.some(inv => inv.booking_id === bookingId), [invoices]);

  const getDateRange = useCallback(() => {
    if (view === "day") {
      return { start: startOfDay(selectedDate), end: endOfDay(selectedDate) };
    } else if (view === "week") {
      return { start: startOfWeek(selectedDate), end: endOfWeek(selectedDate) };
    } else {
      return { start: startOfMonth(selectedDate), end: endOfMonth(selectedDate) };
    }
  }, [selectedDate, view]);

  const filteredBookings = useMemo(() => {
    const { start, end } = getDateRange();
    
    let filtered = allBookings.filter(b => {
      const bookingDate = new Date(b.start_datetime);
      return isWithinInterval(bookingDate, { start, end });
    });

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(b => {
        const student = getStudent(b.student_id);
        return student?.full_name?.toLowerCase().includes(query) ||
               b.lesson_type?.toLowerCase().includes(query) ||
               b.pickup_location?.toLowerCase().includes(query);
      });
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(b => b.status === statusFilter);
    }

    if (typeFilter !== "all") {
      filtered = filtered.filter(b => b.lesson_type === typeFilter);
    }

    return filtered.sort((a, b) => new Date(a.start_datetime) - new Date(b.start_datetime));
  }, [allBookings, getDateRange, searchQuery, statusFilter, typeFilter, getStudent]);

  const todayBookings = useMemo(() => {
    return allBookings.filter(b => isToday(new Date(b.start_datetime)));
  }, [allBookings]);

  const upcomingBookings = useMemo(() => {
    const now = new Date();
    const nextWeek = addDays(now, 7);
    return allBookings.filter(b => {
      const date = new Date(b.start_datetime);
      return isFuture(date) && date <= nextWeek && (b.status === "confirmed" || b.status === "pending");
    }).sort((a, b) => new Date(a.start_datetime) - new Date(b.start_datetime));
  }, [allBookings]);

  const stats = useMemo(() => {
    const today = todayBookings;
    const completed = today.filter(b => b.status === "completed").length;
    const pending = today.filter(b => b.status === "pending" || b.status === "confirmed").length;
    const totalHoursToday = today.reduce((sum, b) => {
      return sum + differenceInMinutes(new Date(b.end_datetime), new Date(b.start_datetime)) / 60;
    }, 0);

    const weekStart = startOfWeek(new Date());
    const weekEnd = endOfWeek(new Date());
    const weekBookings = allBookings.filter(b => {
      const date = new Date(b.start_datetime);
      return isWithinInterval(date, { start: weekStart, end: weekEnd });
    });
    const weekCompleted = weekBookings.filter(b => b.status === "completed").length;
    const weekRevenue = weekBookings.filter(b => b.status === "completed").reduce((sum, b) => sum + (b.price || 0), 0);

    return {
      todayLessons: today.length,
      todayCompleted: completed,
      todayPending: pending,
      todayHours: totalHoursToday,
      weekLessons: weekBookings.length,
      weekCompleted,
      weekRevenue,
      upcomingCount: upcomingBookings.length
    };
  }, [todayBookings, allBookings, upcomingBookings]);

  const weekDays = useMemo(() => {
    return eachDayOfInterval({
      start: startOfWeek(selectedDate),
      end: endOfWeek(selectedDate)
    });
  }, [selectedDate]);

  const monthDays = useMemo(() => {
    const start = startOfMonth(selectedDate);
    const end = endOfMonth(selectedDate);
    const monthStart = startOfWeek(start);
    const monthEnd = endOfWeek(end);
    return eachDayOfInterval({ start: monthStart, end: monthEnd });
  }, [selectedDate]);

  const navigateDate = (direction) => {
    if (view === "day") {
      setSelectedDate(prev => direction === "next" ? addDays(prev, 1) : subDays(prev, 1));
    } else if (view === "week") {
      setSelectedDate(prev => direction === "next" ? addWeeks(prev, 1) : subWeeks(prev, 1));
    } else {
      setSelectedDate(prev => direction === "next" ? addMonths(prev, 1) : subMonths(prev, 1));
    }
  };

  const goToToday = () => {
    setSelectedDate(new Date());
  };

  const handleMarkComplete = async (booking) => {
    await updateBookingMutation.mutateAsync({
      id: booking.id,
      data: { status: "completed" }
    });
    setShowQuickActions(null);
    
    const student = getStudent(booking.student_id);
    if (student && (student.total_lessons_completed || 0) + 1 >= 10 && (student.total_lessons_completed || 0) < 10) {
      const { celebrate } = await import("@/components/common/ConfettiCelebration");
      celebrate(`${student.full_name} completed 10 lessons!`, "milestone");
    }
  };

  const handleMarkNoShow = async (booking) => {
    await updateBookingMutation.mutateAsync({
      id: booking.id,
      data: { status: "no_show" }
    });
    setShowQuickActions(null);
  };

  const handleStartLesson = async (booking) => {
    await updateBookingMutation.mutateAsync({
      id: booking.id,
      data: { status: "in_progress", actual_start_time: new Date().toISOString() }
    });
    setShowQuickActions(null);
  };

  const handleCancelBooking = async (booking) => {
    await updateBookingMutation.mutateAsync({
      id: booking.id,
      data: { status: "cancelled" }
    });
    setShowQuickActions(null);
  };

  const openNotesModal = (booking) => {
    setSelectedBooking(booking);
    setLessonNotes(booking.notes || "");
    setSkillRatings({});
    setShowNotesModal(true);
    setShowQuickActions(null);
  };

  const saveNotes = async () => {
    if (!selectedBooking) return;

    await updateBookingMutation.mutateAsync({
      id: selectedBooking.id,
      data: { notes: lessonNotes }
    });

    if (Object.keys(skillRatings).length > 0) {
      await createLessonRecordMutation.mutateAsync({
        booking_id: selectedBooking.id,
        student_id: selectedBooking.student_id,
        instructor_id: instructor.id,
        date: selectedBooking.start_datetime,
        notes: lessonNotes,
        skill_ratings: skillRatings
      });
    }

    setShowNotesModal(false);
    setSelectedBooking(null);
    setLessonNotes("");
    setSkillRatings({});
  };

  const openBookingDetails = (booking) => {
    setSelectedBooking(booking);
    setShowBookingModal(true);
    setShowQuickActions(null);
  };

  const getBookingDuration = (booking) => {
    return differenceInMinutes(new Date(booking.end_datetime), new Date(booking.start_datetime));
  };

  const renderBookingCard = (booking, compact = false) => {
    const student = getStudent(booking.student_id);
    const vehicle = getVehicle(booking.vehicle_id);
    const lessonType = LESSON_TYPES[booking.lesson_type] || LESSON_TYPES.practical_driving;
    const status = BOOKING_STATUS[booking.status] || BOOKING_STATUS.pending;
    const duration = getBookingDuration(booking);
    const isPastLesson = isPast(new Date(booking.end_datetime));
    const canComplete = isPastLesson && booking.status !== "completed" && booking.status !== "cancelled" && booking.status !== "no_show";

    if (compact) {
      return (
        <div
          key={booking.id}
          onClick={() => openBookingDetails(booking)}
          className={`p-2 rounded-lg border-l-4 cursor-pointer transition hover:shadow-md ${
            booking.status === "completed" ? "bg-[#eefbe7] border-[#5cb83a]" :
            booking.status === "no_show" ? "bg-[#fdeeed] border-[#e44138]" :
            booking.status === "cancelled" ? "bg-gray-50 border-gray-400" :
            booking.status === "in_progress" ? "bg-[#e8f4fa] border-[#3b82c4]" :
            "bg-[#e8f4fa] border-[#3b82c4]"
          }`}
        >
          <p className="text-xs font-semibold truncate">{student?.full_name || "Student"}</p>
          <p className="text-xs text-gray-600">
            {format(new Date(booking.start_datetime), "h:mm")} - {format(new Date(booking.end_datetime), "h:mm a")}
          </p>
        </div>
      );
    }

    return (
      <motion.div
        key={booking.id}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`bg-white rounded-2xl border-2 shadow-sm overflow-hidden transition ${
          booking.status === "completed" ? "border-[#d4f4c3]" :
          booking.status === "no_show" ? "border-[#f9d4d2]" :
          booking.status === "cancelled" ? "border-gray-200" :
          booking.status === "in_progress" ? "border-[#a9d5ed] shadow-[#e8f4fa]" :
          "border-gray-200 hover:shadow-md hover:border-[#d4eaf5]"
        }`}
      >
        <div className="p-5">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="bg-white border border-gray-200 rounded-xl px-4 py-3 text-center shadow-sm">
                <p className="text-xs font-medium uppercase tracking-wide text-gray-500 mb-1">Time</p>
                <p className="text-xl font-bold text-gray-900 tabular-nums">
                  {format(new Date(booking.start_datetime), "h:mm")}
                </p>
                <p className="text-xs text-gray-600 tabular-nums">
                  {format(new Date(booking.end_datetime), "h:mm a")}
                </p>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-xl font-bold text-gray-900">{student?.full_name || "Student"}</h3>
                  {booking.status === "in_progress" && (
                    <span className="flex items-center gap-1 px-2 py-0.5 bg-[#e8f4fa] text-[#3b82c4] rounded-full text-xs font-bold animate-pulse">
                      <CircleDot className="w-3 h-3" />
                      In Progress
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 px-2 py-1 bg-[#e8f4fa] text-[#3b82c4] rounded-lg text-xs font-bold">
                    <lessonType.icon className="w-3 h-3" />
                    {lessonType.label}
                  </span>
                  <span className="text-sm text-gray-600">{duration} min</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-3 py-1.5 bg-gray-100 text-gray-700 rounded-full text-xs font-bold">
                <status.icon className="w-3 h-3" />
                {status.label}
              </span>

              <div className="relative">
                <button
                  onClick={() => setShowQuickActions(showQuickActions === booking.id ? null : booking.id)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <MoreVertical className="w-5 h-5 text-gray-600" />
                </button>

                <AnimatePresence>
                  {showQuickActions === booking.id && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl border border-gray-200 shadow-lg z-20"
                    >
                      <div className="p-2 space-y-1">
                        <button
                          onClick={() => openBookingDetails(booking)}
                          className="w-full px-3 py-2 text-left text-sm hover:bg-gray-50 rounded-lg flex items-center gap-2"
                        >
                          <Eye className="w-4 h-4" />
                          View Details
                        </button>
                        <button
                          onClick={() => openNotesModal(booking)}
                          className="w-full px-3 py-2 text-left text-sm hover:bg-gray-50 rounded-lg flex items-center gap-2"
                        >
                          <FileText className="w-4 h-4" />
                          Add Notes
                        </button>
                        {booking.status === "confirmed" && !isPastLesson && (
                          <button
                            onClick={() => handleStartLesson(booking)}
                            className="w-full px-3 py-2 text-left text-sm hover:bg-[#e8f4fa] text-[#3b82c4] rounded-lg flex items-center gap-2 font-medium"
                          >
                            <Play className="w-4 h-4" />
                            Start Lesson
                          </button>
                        )}
                        {canComplete && (
                          <>
                            <button
                              onClick={() => handleMarkComplete(booking)}
                              className="w-full px-3 py-2 text-left text-sm hover:bg-[#eefbe7] text-[#5cb83a] rounded-lg flex items-center gap-2 font-medium"
                            >
                              <Check className="w-4 h-4" />
                              Mark Complete
                            </button>
                            <button
                              onClick={() => handleMarkNoShow(booking)}
                              className="w-full px-3 py-2 text-left text-sm hover:bg-[#fdeeed] text-[#e44138] rounded-lg flex items-center gap-2 font-medium"
                            >
                              <XCircle className="w-4 h-4" />
                              Mark No Show
                            </button>
                          </>
                        )}
                        {!hasInvoice(booking.id) && booking.status === "completed" && (
                          <button
                            onClick={() => {
                              setSelectedBooking(booking);
                              setShowInvoiceModal(true);
                              setShowQuickActions(null);
                            }}
                            className="w-full px-3 py-2 text-left text-sm hover:bg-[#f3e8f4] text-[#6c376f] rounded-lg flex items-center gap-2 font-medium"
                          >
                            <DollarSign className="w-4 h-4" />
                            Create Invoice
                          </button>
                        )}
                        {booking.status !== "completed" && booking.status !== "cancelled" && (
                          <button
                            onClick={() => handleCancelBooking(booking)}
                            className="w-full px-3 py-2 text-left text-sm hover:bg-[#fdeeed] text-[#e44138] rounded-lg flex items-center gap-2 font-medium"
                          >
                            <X className="w-4 h-4" />
                            Cancel Booking
                          </button>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>

          {student && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-gray-400" />
                <a href={`tel:${student.phone}`} className="text-sm text-[#3b82c4] hover:underline">
                  {student.phone || "No phone"}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">
                  {student.total_hours_completed || 0} / {student.total_hours_required || 40} hrs
                </span>
              </div>
              {vehicle && (
                <div className="flex items-center gap-2">
                  <Car className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-600">{vehicle.make} {vehicle.model}</span>
                </div>
              )}
              {booking.pickup_location && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-600 truncate">{booking.pickup_location}</span>
                </div>
              )}
            </div>
          )}

          {booking.pickup_location && (
            <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl mb-4">
              <MapPin className="w-5 h-5 text-pink-600" />
              <div className="flex-1">
                <p className="text-xs text-gray-500">Pickup Location</p>
                <p className="text-sm font-semibold text-gray-900">{booking.pickup_location}</p>
              </div>
              <button
                onClick={() => window.open(`https://maps.google.com/?q=${encodeURIComponent(booking.pickup_location)}`, '_blank')}
                className="px-3 py-2 bg-[#3b82c4] text-white rounded-xl text-sm font-semibold hover:bg-[#2563a3] transition flex items-center gap-1"
              >
                <Navigation className="w-4 h-4" />
                Navigate
              </button>
            </div>
          )}

          {booking.notes && (
            <div className="p-3 bg-[#fdfbe8] border border-[#f9f3c8] rounded-xl mb-4">
              <p className="text-xs font-bold text-[#b8a525] mb-1">Notes</p>
              <p className="text-sm text-gray-700">{booking.notes}</p>
            </div>
          )}

          {canComplete && (
            <div className="flex gap-2">
              <button
                onClick={() => handleMarkComplete(booking)}
                className="flex-1 px-4 py-3 bg-[#81da5a] hover:bg-[#5cb83a] text-white rounded-xl font-semibold transition flex items-center justify-center gap-2 shadow-sm"
              >
                <Check className="w-4 h-4" />
                Complete
              </button>
              <button
                onClick={() => handleMarkNoShow(booking)}
                className="px-4 py-3 bg-[#fdeeed] hover:bg-[#f9d4d2] text-[#c9342c] rounded-xl font-semibold transition flex items-center justify-center gap-2"
              >
                <XCircle className="w-4 h-4" />
                No Show
              </button>
              <button
                onClick={() => openNotesModal(booking)}
                className="px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition flex items-center justify-center gap-2"
              >
                <FileText className="w-4 h-4" />
                Notes
              </button>
            </div>
          )}
        </div>
      </motion.div>
    );
  };

  if (auth.isLoading || loadingBookings) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        <SkeletonLoader count={5} type="card" />
      </div>
    );
  }

  if (authStatus === "unauthenticated" || !effectiveUser) {
    window.location.href = createPageUrl("SchoolLogin");
    return null;
  }

  if (authStatus === "no_instructor" || !effectiveInstructor) {
    return <InstructorOnboarding user={effectiveUser} onComplete={() => window.location.reload()} />;
  }

  if (bookingsError) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12">
        <QueryErrorBoundary 
          error={bookingsError} 
          onRetry={refetchBookings}
          title="Failed to load schedule"
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Link
          to={createPageUrl("InstructorDashboard")}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-[#3b82c4] to-[#6c376f] bg-clip-text text-transparent">
              {effectiveUser?.full_name?.split(' ')[0] || "Instructor"}'s Schedule
            </h1>
            <p className="text-gray-600 mt-1">Manage your lessons and availability</p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => refetchBookings()}
              className="p-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              <RefreshCw className="w-5 h-5 text-gray-600" />
            </button>
            <Link
              to={createPageUrl("InstructorSetAvailability")}
              className="px-4 py-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition flex items-center gap-2 font-semibold text-gray-700"
            >
              <Settings className="w-4 h-4" />
              Availability
            </Link>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
        {[
          { label: "Today", value: stats.todayLessons, icon: Calendar, bgColor: "bg-[#e8f4fa]", iconColor: "text-[#3b82c4]" },
          { label: "Completed", value: stats.todayCompleted, icon: Check, bgColor: "bg-[#eefbe7]", iconColor: "text-[#5cb83a]" },
          { label: "Pending", value: stats.todayPending, icon: Clock, bgColor: "bg-[#fdfbe8]", iconColor: "text-[#e7d356]" },
          { label: "Today's Hours", value: stats.todayHours.toFixed(1), icon: Timer, bgColor: "bg-[#e8f4fa]", iconColor: "text-[#3b82c4]" },
          { label: "This Week", value: stats.weekLessons, icon: CalendarDays, bgColor: "bg-[#f3e8f4]", iconColor: "text-[#6c376f]" },
          { label: "Week Completed", value: stats.weekCompleted, icon: CheckCircle, bgColor: "bg-[#eefbe7]", iconColor: "text-[#5cb83a]" },
          { label: "Week Revenue", value: `€${stats.weekRevenue}`, icon: DollarSign, bgColor: "bg-[#e8f4fa]", iconColor: "text-[#3b82c4]" },
          { label: "Upcoming", value: stats.upcomingCount, icon: TrendingUp, bgColor: "bg-[#f3e8f4]", iconColor: "text-[#6c376f]" }
        ].map((stat, idx) => {
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.03 }}
              className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm hover:shadow-md hover:border-[#d4eaf5] transition-all"
            >
              <div className={`w-10 h-10 ${stat.bgColor} rounded-xl flex items-center justify-center mb-2`}>
                <stat.icon className={`w-5 h-5 ${stat.iconColor}`} />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-xs text-gray-600 font-medium">{stat.label}</p>
            </motion.div>
          );
        })}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-2xl border border-gray-200 p-2 shadow-sm"
      >
        <div className="flex flex-wrap gap-1">
          {[
            { id: "schedule", label: "Schedule", icon: Calendar },
            { id: "upcoming", label: "Upcoming", icon: TrendingUp },
            { id: "availability", label: "Availability", icon: Settings },
            { id: "timeoff", label: "Time Off", icon: Coffee }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm transition ${
              activeTab === tab.id
              ? "bg-[#3b82c4] text-white"
              : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </motion.div>

      {activeTab === "schedule" && (
        <>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm"
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigateDate("prev")}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <ChevronLeft className="w-5 h-5 text-gray-600" />
                </button>
                <button
                  onClick={goToToday}
                  className="px-4 py-2 bg-[#3b82c4] text-white rounded-xl font-semibold hover:bg-[#2563a3] transition"
                >
                  Today
                </button>
                <button
                  onClick={() => navigateDate("next")}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <ChevronRight className="w-5 h-5 text-gray-600" />
                </button>
                <h2 className="text-lg font-bold text-gray-900 ml-2">
                  {view === "day" && format(selectedDate, "EEEE, MMMM d, yyyy")}
                  {view === "week" && `Week of ${format(startOfWeek(selectedDate), "MMM d")} - ${format(endOfWeek(selectedDate), "MMM d, yyyy")}`}
                  {view === "month" && format(selectedDate, "MMMM yyyy")}
                </h2>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative flex-1 lg:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                  />
                </div>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                >
                  <option value="all">All Status</option>
                  {Object.entries(BOOKING_STATUS).map(([key, { label }]) => (
                    <option key={key} value={key}>{label}</option>
                  ))}
                </select>

                <div className="flex gap-1 p-1 bg-gray-100 rounded-lg">
                  {[
                    { id: "day", icon: Calendar },
                    { id: "week", icon: CalendarDays },
                    { id: "month", icon: CalendarRange }
                  ].map(v => (
                    <button
                      key={v.id}
                      onClick={() => setView(v.id)}
                      className={`p-2 rounded-md transition ${view === v.id ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
                    >
                      <v.icon className="w-4 h-4 text-gray-600" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {view !== "month" && (
              <div className="mt-4 grid grid-cols-7 gap-2">
                {weekDays.map((day) => {
                  const isSelected = isSameDay(selectedDate, day);
                  const dayBookings = allBookings.filter(b => isSameDay(new Date(b.start_datetime), day));
                  
                  return (
                    <button
                      key={day.toISOString()}
                      onClick={() => { setSelectedDate(day); setView("day"); }}
                      className={`p-3 rounded-xl text-center transition ${
                        isSelected
                          ? "bg-[#3b82c4] text-white"
                          : isToday(day)
                          ? "bg-[#e8f4fa] border-2 border-[#d4eaf5]"
                          : "bg-gray-50 hover:bg-gray-100 border border-gray-200"
                      }`}
                    >
                      <p className={`text-xs font-medium ${isSelected ? "text-indigo-200" : "text-gray-500"}`}>
                        {format(day, 'EEE')}
                      </p>
                      <p className={`text-xl font-bold ${isSelected ? "text-white" : "text-gray-900"}`}>
                        {format(day, 'd')}
                      </p>
                      {dayBookings.length > 0 && (
                        <div className="flex justify-center gap-1 mt-1">
                          {dayBookings.slice(0, 3).map((_, i) => (
                            <div
                              key={i}
                              className={`w-1.5 h-1.5 rounded-full ${isSelected ? "bg-white" : "bg-[#3b82c4]"}`}
                            />
                          ))}
                          {dayBookings.length > 3 && (
                            <span className={`text-xs ${isSelected ? "text-white" : "text-gray-500"}`}>+</span>
                          )}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </motion.div>

          {view === "day" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              {filteredBookings.length === 0 ? (
                <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
                  <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">No lessons scheduled</h3>
                  <p className="text-gray-600">No lessons scheduled for this day</p>
                </div>
              ) : (
                filteredBookings.map(booking => renderBookingCard(booking))
              )}
            </motion.div>
          )}

          {view === "week" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm overflow-x-auto"
            >
              <div className="min-w-[800px]">
                <div className="grid grid-cols-8 gap-2 border-b border-gray-200 pb-3 mb-3">
                  <div className="text-xs font-bold uppercase text-gray-500">Time</div>
                  {weekDays.map(day => (
                    <div key={day.toISOString()} className="text-center">
                      <p className="text-xs text-gray-500">{format(day, 'EEE')}</p>
                      <p className={`text-lg font-bold ${isToday(day) ? "text-[#3b82c4]" : "text-gray-900"}`}>
                        {format(day, 'd')}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="space-y-1">
                  {TIME_SLOTS.filter((_, i) => i % 2 === 0).map(slot => (
                    <div key={slot.label} className="grid grid-cols-8 gap-2 min-h-[60px]">
                      <div className="text-xs text-gray-500 py-2">{slot.label}</div>
                      {weekDays.map(day => {
                        const dayBookings = filteredBookings.filter(b => {
                          const bookingDate = new Date(b.start_datetime);
                          return isSameDay(bookingDate, day) && getHours(bookingDate) === slot.hour;
                        });

                        return (
                          <div key={day.toISOString()} className="relative min-h-[60px] border-l border-gray-100">
                            {dayBookings.map(booking => renderBookingCard(booking, true))}
                          </div>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {view === "month" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm"
            >
              <div className="grid grid-cols-7 gap-2 mb-3">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="text-center text-xs font-bold uppercase text-gray-500 py-2">
                    {day}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-2">
                {monthDays.map((day, i) => {
                  const isCurrentMonth = isSameMonth(day, selectedDate);
                  const dayBookings = allBookings.filter(b => isSameDay(new Date(b.start_datetime), day));
                  
                  return (
                    <button
                      key={i}
                      onClick={() => { setSelectedDate(day); setView("day"); }}
                      className={`aspect-square p-2 rounded-xl text-sm font-medium transition relative ${
                        !isCurrentMonth ? "text-gray-300" :
                        isSameDay(day, selectedDate) ? "bg-[#3b82c4] text-white" :
                        isToday(day) ? "bg-[#e8f4fa] border-2 border-[#d4eaf5]" :
                        "bg-gray-50 hover:bg-gray-100 border border-gray-200"
                      }`}
                    >
                      {format(day, 'd')}
                      {isCurrentMonth && dayBookings.length > 0 && (
                        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-0.5">
                          {dayBookings.slice(0, 3).map((_, idx) => (
                            <div
                              key={idx}
                              className={`w-1 h-1 rounded-full ${
                                isSameDay(day, selectedDate) ? "bg-white" : "bg-indigo-600"
                              }`}
                            />
                          ))}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </>
      )}

      {activeTab === "upcoming" && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
            <h2 className="text-lg font-bold text-gray-900 mb-4">Upcoming Lessons (Next 7 Days)</h2>
            
            {upcomingBookings.length === 0 ? (
              <div className="text-center py-12">
                <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-600">No upcoming lessons</p>
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingBookings.map(booking => {
                  const student = getStudent(booking.student_id);
                  const lessonType = LESSON_TYPES[booking.lesson_type] || LESSON_TYPES.practical_driving;
                  
                  return (
                    <div
                      key={booking.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition cursor-pointer"
                      onClick={() => { setSelectedDate(new Date(booking.start_datetime)); setActiveTab("schedule"); setView("day"); }}
                    >
                      <div className="flex items-center gap-4">
                        <div className="text-center">
                          <p className="text-sm font-medium text-gray-600">
                            {format(new Date(booking.start_datetime), "MMM")}
                          </p>
                          <p className="text-2xl font-bold text-gray-900">
                            {format(new Date(booking.start_datetime), "d")}
                          </p>
                          <p className="text-xs text-gray-600">
                            {format(new Date(booking.start_datetime), "EEE")}
                          </p>
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">{student?.full_name}</p>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-[#3b82c4]">{lessonType.label}</span>
                            <span className="text-sm text-gray-600">
                              {format(new Date(booking.start_datetime), "h:mm a")}
                            </span>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </motion.div>
      )}

      {activeTab === "availability" && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-gray-900">Availability Settings</h2>
              <p className="text-sm text-gray-600">Manage your working hours and preferences</p>
            </div>
            <Link
              to={createPageUrl("InstructorSetAvailability")}
              className="px-4 py-2 bg-[#3b82c4] text-white rounded-xl font-semibold hover:bg-[#2563a3] transition flex items-center gap-2 shadow-sm"
            >
              <Settings className="w-4 h-4" />
              Configure Availability
            </Link>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-4 bg-gray-50 rounded-xl">
              <h3 className="font-bold text-gray-900 mb-3">Quick Stats</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Weekly Hours</span>
                  <span className="font-semibold">40 hours</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Working Days</span>
                  <span className="font-semibold">6 days</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Earliest Start</span>
                  <span className="font-semibold">7:00 AM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Latest End</span>
                  <span className="font-semibold">8:00 PM</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-gray-50 rounded-xl">
              <h3 className="font-bold text-gray-900 mb-3">Booking Settings</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Min Notice</span>
                  <span className="font-semibold">2 hours</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Max Advance</span>
                  <span className="font-semibold">30 days</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Lesson Duration</span>
                  <span className="font-semibold">60 min</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Buffer Time</span>
                  <span className="font-semibold">15 min</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {activeTab === "timeoff" && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-gray-900">Time Off Requests</h2>
              <p className="text-sm text-gray-600">Manage your vacation and leave</p>
            </div>
            <Link
              to={createPageUrl("InstructorTimeOffRequests")}
              className="px-4 py-2 bg-[#3b82c4] text-white rounded-xl font-semibold hover:bg-[#2563a3] transition flex items-center gap-2 shadow-sm"
            >
              <Plus className="w-4 h-4" />
              Request Time Off
            </Link>
          </div>

          <div className="text-center py-12">
            <Coffee className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-600">View and manage your time off requests</p>
            <Link
              to={createPageUrl("InstructorTimeOffRequests")}
              className="inline-block mt-4 px-6 py-3 bg-[#3b82c4] text-white rounded-xl font-semibold hover:bg-[#2563a3] transition shadow-sm"
            >
              Go to Time Off
            </Link>
          </div>
        </motion.div>
      )}

      <AnimatePresence>
        {showNotesModal && selectedBooking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowNotesModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Lesson Notes</h3>
                  <p className="text-sm text-gray-600">
                    {getStudent(selectedBooking.student_id)?.full_name} - {format(new Date(selectedBooking.start_datetime), "MMM d, yyyy")}
                  </p>
                </div>
                <button
                  onClick={() => setShowNotesModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Lesson Notes</label>
                  <textarea
                    value={lessonNotes}
                    onChange={(e) => setLessonNotes(e.target.value)}
                    placeholder="Enter notes about the lesson, student progress, areas to improve..."
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed] resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">Quick Skill Ratings</label>
                  <div className="space-y-3">
                    {["Steering", "Observations", "Speed Control", "Maneuvers"].map(skill => (
                      <div key={skill} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-700">{skill}</span>
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map(rating => (
                            <button
                              key={rating}
                              onClick={() => setSkillRatings(prev => ({ ...prev, [skill]: rating }))}
                              className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold transition ${
                                skillRatings[skill] === rating
                                  ? "bg-[#3b82c4] text-white"
                                  : "bg-white border border-gray-200 hover:border-[#d4eaf5]"
                              }`}
                            >
                              {rating}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => setShowNotesModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={saveNotes}
                  className="flex-1 px-4 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  Save Notes
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showBookingModal && selectedBooking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowBookingModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Booking Details</h3>
                <button
                  onClick={() => setShowBookingModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              {renderBookingCard(selectedBooking)}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}