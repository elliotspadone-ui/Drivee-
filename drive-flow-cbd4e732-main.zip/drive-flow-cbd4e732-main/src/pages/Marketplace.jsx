import React, { useState, useMemo, useCallback, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import {
  Map,
  List,
  ArrowLeft,
  Briefcase,
  Globe,
  SlidersHorizontal,
  X,
  Star,
  MapPin,
  DollarSign,
  Users,
  Car,
  Calendar,
  TrendingUp,
  Award,
  Filter,
  Search,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  ChevronLeft,
  Grid,
  Heart,
  Share2,
  Phone,
  Mail,
  Clock,
  CheckCircle,
  ArrowUpDown,
  Sparkles,
  Zap,
  Shield,
  MessageSquare,
  Navigation,
  Loader2,
  ArrowUpRight,
  Menu,
  Lightbulb,
  Wand2,
  Languages,
  Target,
  Info,
  RotateCcw,
  GraduationCap,
  Play,
  Pause,
  Eye,
  Flame,
  BadgeCheck,
  ThumbsUp,
  Coffee,
  BookOpen,
  Timer,
  Plus,
  Minus,
  ExternalLink,
} from "lucide-react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence, useScroll, useTransform, useInView } from "framer-motion";

// Import existing components (these would need to be created/updated separately)
import FiltersPanel from "../components/marketplace/FiltersPanel";
import InteractiveMap from "../components/marketplace/InteractiveMap";
import { useAISearch } from "../components/marketplace/useAISearch";
import SkeletonLoader from "@/components/common/SkeletonLoader";
import SEOHead from "@/components/common/SEOHead";
import QueryErrorBoundary from "@/components/common/QueryErrorBoundary";

// ============================================================================
// CONSTANTS & DESIGN TOKENS
// ============================================================================

const LOGO_URL =
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691b056345d5788acbd4e732/8bd9d7a47_ChatGPTImageNov29202511_47_17PM.png";

// Hero background images for carousel
const HERO_IMAGES = [
  "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=1600&auto=format",
  "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=1600&auto=format",
  "https://images.unsplash.com/photo-1593786326112-12b0abfa4d68?w=1600&auto=format",
];

// AI search example queries
const AI_SEARCH_EXAMPLES = [
  {
    query: "Patient instructor for nervous beginners",
    icon: Coffee,
    description: "Find calm, supportive instructors",
  },
  {
    query: "Automatic car lessons on weekends",
    icon: Car,
    description: "Weekend availability with automatic",
  },
  {
    query: "Female instructor who speaks Spanish",
    icon: Users,
    description: "Language and gender preferences",
  },
  {
    query: "Best rated school under €800",
    icon: Award,
    description: "Budget with quality focus",
  },
  {
    query: "Intensive course to pass in 2 weeks",
    icon: Zap,
    description: "Fast-track learning programs",
  },
  {
    query: "Evening classes after 6pm near center",
    icon: Clock,
    description: "Time-based availability search",
  },
];

// Sort options
const SORT_OPTIONS = [
  { value: "recommended", label: "Recommended", icon: Sparkles, description: "Best match for you" },
  { value: "rating", label: "Highest Rated", icon: Star, description: "Top customer reviews" },
  { value: "popular", label: "Most Popular", icon: TrendingUp, description: "Most bookings" },
  { value: "price-asc", label: "Price: Low to High", icon: DollarSign, description: "Budget friendly" },
  { value: "price-desc", label: "Price: High to Low", icon: DollarSign, description: "Premium options" },
  { value: "distance", label: "Nearest First", icon: Navigation, description: "Closest to you" },
  { value: "pass-rate", label: "Best Pass Rate", icon: Award, description: "Highest success" },
];

// Default filter state
const DEFAULT_FILTERS = {
  city: "all",
  transmission: "all",
  priceRange: "all",
  language: "all",
  rating: 0,
  vehicleType: "all",
  availability: "all",
  instructorGender: "all",
  distanceKm: 50,
  features: [],
};

// Quick filter presets
const QUICK_FILTERS = [
  { id: "beginners", label: "For Beginners", icon: Target, query: "patient instructor for beginners" },
  { id: "automatic", label: "Automatic", icon: Car, filter: { transmission: "automatic" } },
  { id: "weekend", label: "Weekends", icon: Calendar, filter: { availability: "weekend" } },
  { id: "female", label: "Female Instructor", icon: Users, filter: { instructorGender: "female" } },
  { id: "high-rated", label: "4.5+ Rating", icon: Star, filter: { rating: 4.5 } },
  { id: "intensive", label: "Intensive", icon: Zap, query: "intensive course fast track" },
];

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export default function Marketplace() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  // Core search state
  const [searchTerm, setSearchTerm] = useState(searchParams.get("q") || "");
  const [searchLocation, setSearchLocation] = useState(searchParams.get("location") || "");
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get("vehicleType") || "all");

  // UI state
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState("split"); // split | list | map
  const [highlightedSchoolId, setHighlightedSchoolId] = useState(null);
  const [sortBy, setSortBy] = useState(searchParams.get("sort") || "recommended");
  const [savedSchools, setSavedSchools] = useState(new Set());
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showAIDiscovery, setShowAIDiscovery] = useState(() => {
    return localStorage.getItem("drivee-ai-discovery-dismissed") !== "true";
  });
  const [activeQuickFilter, setActiveQuickFilter] = useState(null);

  // Map/area search state
  const [areaFilteredSchools, setAreaFilteredSchools] = useState(null);
  const [drawnShape, setDrawnShape] = useState(null);

  // User location
  const { location: userLocation } = useUserLocation();
  const calculateDistance = useDistanceCalculator(userLocation);

  // AI Search
  const {
    isSearching: isAISearching,
    aiFilters,
    error: aiError,
    lastQuery: aiLastQuery,
    performAISearch,
    clearAISearch,
    applyAIFilters,
    isNaturalLanguageQuery,
  } = useAISearch();

  // Filter state
  const [filters, setFilters] = useState(() => ({
    ...DEFAULT_FILTERS,
    city: searchParams.get("city") || "all",
    transmission: searchParams.get("transmission") || "all",
    priceRange: searchParams.get("priceRange") || "all",
    language: searchParams.get("language") || "all",
    rating: Number(searchParams.get("rating")) || 0,
    vehicleType: searchParams.get("vehicleType") || "all",
    availability: searchParams.get("availability") || "all",
    instructorGender: searchParams.get("instructorGender") || "all",
    distanceKm: Number(searchParams.get("distance")) || 50,
    features: searchParams.get("features")?.split(",").filter(Boolean) || [],
  }));

  // ============================================================================
  // DATA FETCHING
  // ============================================================================

  const {
    data: schools = [],
    isLoading: loadingSchools,
    error: schoolsError,
    refetch: refetchSchools,
  } = useQuery({
    queryKey: ["marketplaceSchools"],
    queryFn: () => base44.entities.School.filter({ is_active: true }, "-rating", 100),
    staleTime: 600000,
  });

  const { data: instructors = [], isLoading: loadingInstructors } = useQuery({
    queryKey: ["marketplaceInstructors"],
    queryFn: () => base44.entities.Instructor.filter({ is_active: true }, "-rating", 100),
    staleTime: 600000,
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ["marketplaceVehicles"],
    queryFn: () => base44.entities.Vehicle.filter({ is_available: true }, "-created_date", 100),
    staleTime: 600000,
  });

  const { data: packages = [] } = useQuery({
    queryKey: ["marketplacePackages"],
    queryFn: () => base44.entities.Package.filter({ is_active: true }, "-created_date", 200),
    staleTime: 600000,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["marketplaceReviews"],
    queryFn: () => base44.entities.Review.filter({ is_visible: true }, "-created_date", 200),
    staleTime: 600000,
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ["marketplaceBookingsCount"],
    queryFn: () => base44.entities.Booking.filter({ status: "completed" }, "-created_date", 200),
    staleTime: 600000,
  });

  const isLoading = loadingSchools || loadingInstructors;

  // ============================================================================
  // DERIVED DATA
  // ============================================================================

  const cities = useMemo(
    () => [...new Set(schools.map((s) => s.city).filter(Boolean))].sort(),
    [schools]
  );

  const availableLanguages = useMemo(
    () => [...new Set(schools.flatMap((s) => s.languages || []))].sort(),
    [schools]
  );

  // Enrich schools with computed data
  const enrichedSchools = useMemo(() => {
    return schools.map((school) => {
      const schoolInstructors = instructors.filter((i) => i.school_id === school.id);
      const schoolVehicles = vehicles.filter((v) => v.school_id === school.id);
      const schoolPackages = packages.filter((p) => p.school_id === school.id && p.is_active);
      const schoolReviews = reviews.filter((r) => r.school_id === school.id);
      const schoolBookings = bookings.filter((b) => b.school_id === school.id);

      const avgRating =
        schoolReviews.length > 0
          ? schoolReviews.reduce((sum, r) => sum + (r.rating || 0), 0) / schoolReviews.length
          : school.rating || 0;

      const minPrice =
        schoolPackages.length > 0 ? Math.min(...schoolPackages.map((p) => p.total_price || 0)) : null;

      const completedBookings = schoolBookings.filter((b) => b.status === "completed").length;
      const totalBookings = schoolBookings.length;

      const distance =
        school.latitude && school.longitude
          ? calculateDistance(school.latitude, school.longitude)
          : null;

      const passRate = school.pass_rate || Math.floor(Math.random() * 15) + 85;
      const recentBookings = Math.floor(Math.random() * 12) + 3;

      return {
        ...school,
        instructorCount: schoolInstructors.length,
        vehicleCount: schoolVehicles.length,
        packageCount: schoolPackages.length,
        reviewCount: schoolReviews.length,
        avgRating,
        minPrice,
        distance,
        passRate,
        recentBookings,
        hasOnlineBooking: true,
        hasTheoryTraining: school.features?.includes("Theory Training") || false,
        hasPickupService: school.features?.includes("Pick-up Service") || true,
        instructors: schoolInstructors,
        vehicles: schoolVehicles,
        packages: schoolPackages,
        reviews: schoolReviews,
      };
    });
  }, [schools, instructors, vehicles, packages, reviews, bookings, calculateDistance]);

  // Apply filters and sorting
  const filteredSchools = useMemo(() => {
    return enrichedSchools
      .filter((school) => {
        const matchesSearch =
          !searchTerm ||
          school.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          school.city?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          school.description?.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesLocation =
          !searchLocation ||
          school.city?.toLowerCase().includes(searchLocation.toLowerCase()) ||
          school.address?.toLowerCase().includes(searchLocation.toLowerCase());

        const isActive = school.is_active !== false;

        const schoolInstructors = instructors.filter((i) => i.school_id === school.id);
        const hasCategory =
          selectedCategory === "all" ||
          schoolInstructors.some((i) => i.certifications?.includes(selectedCategory));

        const schoolVehicles = vehicles.filter((v) => v.school_id === school.id);
        const hasTransmission =
          filters.transmission === "all" ||
          schoolVehicles.some(
            (v) => v.transmission?.toLowerCase() === filters.transmission.toLowerCase()
          );

        const matchesCity = filters.city === "all" || school.city === filters.city;

        const schoolPackages = packages.filter((p) => p.school_id === school.id && p.is_active);
        let matchesPrice = true;
        if (filters.priceRange === "low") {
          matchesPrice = schoolPackages.some((p) => (p.total_price || 0) < 500);
        } else if (filters.priceRange === "medium") {
          matchesPrice = schoolPackages.some(
            (p) => (p.total_price || 0) >= 500 && (p.total_price || 0) <= 1000
          );
        } else if (filters.priceRange === "high") {
          matchesPrice = schoolPackages.some((p) => (p.total_price || 0) > 1000);
        }

        const matchesLanguage =
          filters.language === "all" || (school.languages || []).includes(filters.language);

        const matchesRating = filters.rating === 0 || (school.avgRating || 0) >= filters.rating;

        const matchesDistance =
          !filters.distanceKm || !school.distance || school.distance <= filters.distanceKm;

        const matchesFeatures =
          filters.features.length === 0 ||
          filters.features.every((feature) => school.features?.includes(feature));

        const matchesInstructorGender =
          filters.instructorGender === "all" ||
          schoolInstructors.some((i) => i.gender === filters.instructorGender);

        return (
          matchesSearch &&
          matchesLocation &&
          isActive &&
          hasCategory &&
          hasTransmission &&
          matchesCity &&
          matchesPrice &&
          matchesLanguage &&
          matchesRating &&
          matchesDistance &&
          matchesFeatures &&
          matchesInstructorGender
        );
      })
      .sort((a, b) => {
        switch (sortBy) {
          case "rating":
            return (b.avgRating || 0) - (a.avgRating || 0);
          case "reviews":
            return (b.reviewCount || 0) - (a.reviewCount || 0);
          case "price-asc":
            return (a.minPrice || 999999) - (b.minPrice || 999999);
          case "price-desc":
            return (b.minPrice || 0) - (a.minPrice || 0);
          case "distance":
            return (a.distance || 999999) - (b.distance || 999999);
          case "popular":
            return (b.reviewCount || 0) * (b.avgRating || 0) - (a.reviewCount || 0) * (a.avgRating || 0);
          case "pass-rate":
            return (b.passRate || 0) - (a.passRate || 0);
          default:
            return 0;
        }
      });
  }, [
    enrichedSchools,
    searchTerm,
    searchLocation,
    selectedCategory,
    filters,
    sortBy,
    instructors,
    vehicles,
    packages,
  ]);

  const displayedSchools = useMemo(() => {
    return areaFilteredSchools !== null ? areaFilteredSchools : filteredSchools;
  }, [filteredSchools, areaFilteredSchools]);

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filters.city !== "all") count++;
    if (filters.transmission !== "all") count++;
    if (filters.priceRange !== "all") count++;
    if (filters.language !== "all") count++;
    if (filters.rating > 0) count++;
    if (filters.vehicleType !== "all") count++;
    if (filters.instructorGender !== "all") count++;
    if (filters.features.length > 0) count += filters.features.length;
    if (drawnShape) count++;
    if (aiFilters) count++;
    return count;
  }, [filters, drawnShape, aiFilters]);

  // ============================================================================
  // EFFECTS
  // ============================================================================

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const params = new URLSearchParams();
    if (searchTerm) params.set("q", searchTerm);
    if (searchLocation) params.set("location", searchLocation);
    if (selectedCategory !== "all") params.set("vehicleType", selectedCategory);
    if (sortBy !== "recommended") params.set("sort", sortBy);
    if (filters.city !== "all") params.set("city", filters.city);
    if (filters.transmission !== "all") params.set("transmission", filters.transmission);
    if (filters.priceRange !== "all") params.set("priceRange", filters.priceRange);
    if (filters.language !== "all") params.set("language", filters.language);
    if (filters.rating > 0) params.set("rating", filters.rating.toString());
    if (filters.features.length > 0) params.set("features", filters.features.join(","));
    setSearchParams(params, { replace: true });
  }, [searchTerm, searchLocation, selectedCategory, sortBy, filters, setSearchParams]);

  // ============================================================================
  // HANDLERS
  // ============================================================================

  const handleFilterChange = useCallback((key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  }, []);

  const handleResetFilters = useCallback(() => {
    setFilters(DEFAULT_FILTERS);
    setSearchTerm("");
    setSearchLocation("");
    setSelectedCategory("all");
    setSortBy("recommended");
    setDrawnShape(null);
    setAreaFilteredSchools(null);
    setActiveQuickFilter(null);
    clearAISearch();
  }, [clearAISearch]);

  const handleSmartSearch = useCallback(
    async (query) => {
      if (!query.trim()) {
        clearAISearch();
        return;
      }

      if (isNaturalLanguageQuery(query)) {
        setShowAIDiscovery(false);
        localStorage.setItem("drivee-ai-discovery-dismissed", "true");

        const result = await performAISearch(query, cities, availableLanguages);

        if (result) {
          const { suggestedSort } = applyAIFilters(
            result,
            filters,
            setFilters,
            setSearchLocation,
            setSelectedCategory
          );

          if (suggestedSort && suggestedSort !== "recommended") {
            setSortBy(suggestedSort);
          }
        }
      } else {
        clearAISearch();
      }
    },
    [
      isNaturalLanguageQuery,
      performAISearch,
      applyAIFilters,
      clearAISearch,
      cities,
      availableLanguages,
      filters,
    ]
  );

  const handleQuickFilter = useCallback(
    (quickFilter) => {
      if (activeQuickFilter === quickFilter.id) {
        setActiveQuickFilter(null);
        handleResetFilters();
        return;
      }

      setActiveQuickFilter(quickFilter.id);

      if (quickFilter.query) {
        setSearchTerm(quickFilter.query);
        handleSmartSearch(quickFilter.query);
      } else if (quickFilter.filter) {
        setFilters((prev) => ({ ...prev, ...quickFilter.filter }));
      }
    },
    [activeQuickFilter, handleResetFilters, handleSmartSearch]
  );

  const handleSchoolClick = useCallback(
    (school) => {
      navigate(`${createPageUrl("SchoolProfile")}?id=${school.id}`);
    },
    [navigate]
  );

  const handleBookNow = useCallback(
    (school, e) => {
      e.stopPropagation();
      navigate(createPageUrl("BookLesson"), {
        state: {
          schoolId: school.id,
          schoolName: school.name,
          source: "marketplace",
        },
      });
    },
    [navigate]
  );

  const handleAreaSearch = useCallback((shape) => {
    setDrawnShape(shape);
  }, []);

  const handleSchoolsInArea = useCallback((schoolsInArea) => {
    setAreaFilteredSchools(schoolsInArea);
  }, []);

  const clearAreaFilter = useCallback(() => {
    setDrawnShape(null);
    setAreaFilteredSchools(null);
  }, []);

  const scrollToSchool = useCallback((schoolId) => {
    const element = document.getElementById(`school-${schoolId}`);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, []);

  const toggleSaveSchool = useCallback((schoolId, e) => {
    e.stopPropagation();
    setSavedSchools((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(schoolId)) {
        newSet.delete(schoolId);
      } else {
        newSet.add(schoolId);
      }
      return newSet;
    });
  }, []);

  // ============================================================================
  // RENDER: LOADING STATE
  // ============================================================================

  if (isLoading) {
    return <LoadingState />;
  }

  if (schoolsError) {
    return (
      <div className="min-h-screen bg-slate-50/50 flex items-center justify-center">
        <QueryErrorBoundary
          error={schoolsError}
          onRetry={refetchSchools}
          title="Failed to load driving schools"
        />
      </div>
    );
  }

  // ============================================================================
  // RENDER: MAIN
  // ============================================================================

  return (
    <div className="min-h-screen bg-[#fafafa]">
      <SEOHead
        title="Find Driving Schools Near You | Compare & Book Online - DRIVEE"
        description="Browse verified driving schools across Europe. Compare prices, read reviews, check availability and book lessons online."
        keywords="driving schools, find driving school, book driving lessons, driving instructors near me"
        canonical={window.location.href}
      />

      {/* Global Styles */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
        
        * {
          font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
        }
        
        .shadow-premium {
          box-shadow: 
            0 0 0 1px rgba(0, 0, 0, 0.02),
            0 1px 2px rgba(0, 0, 0, 0.03),
            0 4px 8px rgba(0, 0, 0, 0.04),
            0 12px 24px rgba(0, 0, 0, 0.05);
        }
        
        .shadow-premium-lg {
          box-shadow: 
            0 0 0 1px rgba(0, 0, 0, 0.02),
            0 2px 4px rgba(0, 0, 0, 0.02),
            0 8px 16px rgba(0, 0, 0, 0.04),
            0 24px 48px rgba(0, 0, 0, 0.06);
        }
        
        .shadow-premium-xl {
          box-shadow: 
            0 0 0 1px rgba(0, 0, 0, 0.02),
            0 4px 8px rgba(0, 0, 0, 0.03),
            0 16px 32px rgba(0, 0, 0, 0.05),
            0 32px 64px rgba(0, 0, 0, 0.07);
        }
        
        .cta-gradient {
          background: linear-gradient(135deg, #3b82c4 0%, #2563a3 100%);
        }
        
        .cta-gradient:hover {
          background: linear-gradient(135deg, #2563a3 0%, #1e4f8a 100%);
        }
        
        .accent-gradient {
          background: linear-gradient(135deg, #3b82c4 0%, #a9d5ed 50%, #6c376f 100%);
        }
        
        .glass {
          background: rgba(255, 255, 255, 0.85);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
        }
        
        .text-gradient {
          background: linear-gradient(135deg, #3b82c4 0%, #a9d5ed 50%, #6c376f 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
        
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 3px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #cbd5e1; }
      `}</style>

      {/* Scroll Progress */}
      <ScrollProgress />

      {/* Navigation */}
      <NavBar
        isScrolled={isScrolled}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
        navigate={navigate}
      />

      {/* Mobile Menu */}
      <MobileMenu
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        navigate={navigate}
      />

      {/* Hero Section */}
      <HeroSection
        schoolCount={filteredSchools.length}
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        onSearch={handleSmartSearch}
        isSearching={isAISearching}
        clearSearch={() => {
          setSearchTerm("");
          clearAISearch();
        }}
      />

      {/* Quick Filters Bar */}
      <QuickFiltersBar
        quickFilters={QUICK_FILTERS}
        activeFilter={activeQuickFilter}
        onFilterClick={handleQuickFilter}
      />

      {/* Search & Filters Sticky Bar */}
      <SearchFiltersBar
        searchLocation={searchLocation}
        setSearchLocation={setSearchLocation}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        filters={filters}
        handleFilterChange={handleFilterChange}
        sortBy={sortBy}
        setSortBy={setSortBy}
        showSortMenu={showSortMenu}
        setShowSortMenu={setShowSortMenu}
        showFilters={showFilters}
        setShowFilters={setShowFilters}
        activeFilterCount={activeFilterCount}
        handleResetFilters={handleResetFilters}
        cities={cities}
        viewMode={viewMode}
        setViewMode={setViewMode}
        availableLanguages={availableLanguages}
      />

      {/* AI Search Context */}
      <AnimatePresence>
        {aiFilters && (
          <AISearchContext
            aiFilters={aiFilters}
            query={aiLastQuery}
            resultCount={displayedSchools.length}
            onClear={() => {
              clearAISearch();
              handleResetFilters();
            }}
          />
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Area filter indicator */}
        {drawnShape && (
          <AreaFilterBanner count={displayedSchools.length} onClear={clearAreaFilter} />
        )}

        {/* Results Header */}
        <ResultsHeader
          count={displayedSchools.length}
          location={searchLocation}
          aiQuery={aiFilters ? aiLastQuery : null}
        />

        {/* Desktop Split View */}
        {viewMode === "split" ? (
          <div className="hidden lg:grid lg:grid-cols-[1fr_1fr] lg:gap-6 h-[calc(100vh-16rem)]">
            {/* Schools List */}
            <div className="space-y-4 overflow-y-auto pr-2 custom-scrollbar">
              {displayedSchools.map((school, index) => (
                <SchoolCard
                  key={school.id}
                  school={school}
                  index={index}
                  isHighlighted={highlightedSchoolId === school.id}
                  isSaved={savedSchools.has(school.id)}
                  onHover={setHighlightedSchoolId}
                  onClick={handleSchoolClick}
                  onSave={toggleSaveSchool}
                  onBook={handleBookNow}
                />
              ))}

              {displayedSchools.length === 0 && (
                <EmptyState onReset={handleResetFilters} hasAISearch={!!aiFilters} />
              )}
            </div>

            {/* Map */}
            <div className="sticky top-0 h-full rounded-2xl overflow-hidden shadow-elevated border border-gray-200">
              <InteractiveMap
                schools={filteredSchools}
                highlightedSchoolId={highlightedSchoolId}
                onMarkerClick={(schoolId) => {
                  setHighlightedSchoolId(schoolId);
                  scrollToSchool(schoolId);
                }}
                onMarkerHover={setHighlightedSchoolId}
                onAreaSearch={handleAreaSearch}
                onSchoolsInArea={handleSchoolsInArea}
                userLocation={userLocation}
                showDrawTools={true}
              />
            </div>
          </div>
        ) : viewMode === "list" ? (
          /* List/Grid View */
          <div className="hidden lg:block">
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
              {displayedSchools.map((school, index) => (
                <SchoolCard
                  key={school.id}
                  school={school}
                  index={index}
                  isHighlighted={highlightedSchoolId === school.id}
                  isSaved={savedSchools.has(school.id)}
                  onHover={setHighlightedSchoolId}
                  onClick={handleSchoolClick}
                  onSave={toggleSaveSchool}
                  onBook={handleBookNow}
                  viewMode="grid"
                />
              ))}
            </div>

            {displayedSchools.length === 0 && (
              <EmptyState onReset={handleResetFilters} hasAISearch={!!aiFilters} />
            )}
          </div>
        ) : null}

        {/* Mobile View */}
        <MobileView
          viewMode={viewMode}
          setViewMode={setViewMode}
          schools={displayedSchools}
          filteredSchools={filteredSchools}
          highlightedSchoolId={highlightedSchoolId}
          setHighlightedSchoolId={setHighlightedSchoolId}
          savedSchools={savedSchools}
          toggleSaveSchool={toggleSaveSchool}
          handleSchoolClick={handleSchoolClick}
          handleBookNow={handleBookNow}
          handleResetFilters={handleResetFilters}
          hasAISearch={!!aiFilters}
          handleAreaSearch={handleAreaSearch}
          handleSchoolsInArea={handleSchoolsInArea}
          userLocation={userLocation}
        />
      </main>
    </div>
  );
}

// ============================================================================
// CUSTOM HOOKS
// ============================================================================

function useUserLocation() {
  const [location, setLocation] = useState(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!navigator.geolocation) {
      setError("Geolocation not supported");
      return;
    }

    setIsLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        setIsLoading(false);
      },
      (err) => {
        setError(err.message);
        setIsLoading(false);
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
    );
  }, []);

  return { location, error, isLoading };
}

function useDistanceCalculator(userLocation) {
  return useCallback(
    (lat, lng) => {
      if (!userLocation || !lat || !lng) return null;

      const R = 6371;
      const dLat = ((lat - userLocation.lat) * Math.PI) / 180;
      const dLng = ((lng - userLocation.lng) * Math.PI) / 180;
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((userLocation.lat * Math.PI) / 180) *
          Math.cos((lat * Math.PI) / 180) *
          Math.sin(dLng / 2) *
          Math.sin(dLng / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      return R * c;
    },
    [userLocation]
  );
}

// ============================================================================
// SCROLL PROGRESS
// ============================================================================

function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useTransform(scrollYProgress, [0, 1], [0, 1]);

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#0066cc] to-[#4ecdc4] origin-left z-[100]"
      style={{ scaleX }}
    />
  );
}

// ============================================================================
// NAVIGATION
// ============================================================================

function NavBar({ isScrolled, mobileMenuOpen, setMobileMenuOpen, navigate }) {
  return (
    <motion.nav
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? "glass border-b border-slate-200/50 shadow-premium"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          <Link to={createPageUrl("Landing")} className="flex items-center">
            <motion.img
              whileHover={{ scale: 1.02 }}
              src={LOGO_URL}
              alt="DRIVEE"
              className="h-16 lg:h-20 object-contain"
            />
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            <Link
              to={createPageUrl("TheoryTestPrep")}
              className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-[#3b82c4] hover:text-[#2563a3] hover:bg-[#e8f4fa] rounded-xl transition-all duration-200"
            >
              <GraduationCap className="w-4 h-4" />
              Theory Test Prep
            </Link>
            <Link
              to={createPageUrl("BusinessSolutions")}
              className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100/80 rounded-xl transition-all duration-200"
            >
              <Briefcase className="w-4 h-4" />
              For Schools
            </Link>
            <Link
              to={createPageUrl("SchoolLogin")}
              className="px-4 py-2.5 text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100/80 rounded-xl transition-all duration-200"
            >
              Sign In
            </Link>
            <button className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100/80 rounded-xl transition-all duration-200">
              <Globe className="w-4 h-4" />
              EN
            </button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate(createPageUrl("SchoolLogin"))}
              className="ml-2 px-6 py-2.5 cta-gradient text-white text-sm font-semibold rounded-xl shadow-premium hover:shadow-premium-lg transition-all duration-300"
            >
              Get Started
            </motion.button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2.5 hover:bg-gray-100 rounded-xl transition-colors"
          >
            <AnimatePresence mode="wait">
              {mobileMenuOpen ? (
                <motion.div
                  key="close"
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                >
                  <X className="w-6 h-6 text-gray-700" />
                </motion.div>
              ) : (
                <motion.div
                  key="menu"
                  initial={{ rotate: 90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: -90, opacity: 0 }}
                >
                  <Menu className="w-6 h-6 text-gray-700" />
                </motion.div>
              )}
            </AnimatePresence>
          </button>
        </div>
      </div>
    </motion.nav>
  );
}

// ============================================================================
// MOBILE MENU
// ============================================================================

function MobileMenu({ isOpen, onClose, navigate }) {
  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="fixed inset-0 z-40 bg-white pt-20 md:hidden overflow-y-auto"
    >
      <div className="p-6 space-y-2">
        <Link
          to={createPageUrl("BusinessSolutions")}
          onClick={onClose}
          className="flex items-center gap-3 p-4 text-lg font-semibold text-gray-700 hover:bg-gray-50 rounded-2xl transition-colors"
        >
          <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
            <Briefcase className="w-5 h-5 text-gray-600" />
          </div>
          For Schools
        </Link>
        <Link
          to={createPageUrl("SchoolLogin")}
          onClick={onClose}
          className="flex items-center gap-3 p-4 text-lg font-semibold text-gray-700 hover:bg-gray-50 rounded-2xl transition-colors"
        >
          <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
            <Users className="w-5 h-5 text-gray-600" />
          </div>
          Sign In
        </Link>
        <div className="pt-4">
          <button
            onClick={() => {
              navigate(createPageUrl("SchoolLogin"));
              onClose();
            }}
            className="w-full py-4 bg-[#0066cc] text-white font-bold rounded-2xl text-lg shadow-lg"
          >
            Get Started
          </button>
        </div>
      </div>
    </motion.div>
  );
}

// ============================================================================
// HERO SECTION
// ============================================================================

function HeroSection({ schoolCount, searchTerm, setSearchTerm, onSearch, isSearching, clearSearch }) {
  const [currentImage, setCurrentImage] = useState(0);
  const inputRef = useRef(null);
  const [isFocused, setIsFocused] = useState(false);
  const [showExamples, setShowExamples] = useState(false);

  // Rotate hero images
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % HERO_IMAGES.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  // Show examples on focus
  useEffect(() => {
    if (isFocused && !searchTerm.trim()) {
      const timer = setTimeout(() => setShowExamples(true), 200);
      return () => clearTimeout(timer);
    } else {
      setShowExamples(false);
    }
  }, [isFocused, searchTerm]);

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && searchTerm.trim()) {
      onSearch(searchTerm);
      setShowExamples(false);
    }
    if (e.key === "Escape") {
      setShowExamples(false);
      inputRef.current?.blur();
    }
  };

  const handleExampleClick = (query) => {
    setSearchTerm(query);
    onSearch(query);
    setShowExamples(false);
  };

  return (
    <div className="pt-16 lg:pt-20">
      <div className="relative overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <AnimatePresence mode="wait">
            <motion.img
              key={currentImage}
              src={HERO_IMAGES[currentImage]}
              alt=""
              className="w-full h-full object-cover"
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1 }}
            />
          </AnimatePresence>
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />
        </div>

        {/* Content */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          {/* Breadcrumb */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-6"
          >
            <Link
              to={createPageUrl("Landing")}
              className="inline-flex items-center gap-2 text-sm font-medium text-white/80 hover:text-white transition-colors group"
            >
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              Back to Home
            </Link>
          </motion.div>

          {/* Title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white mb-4 leading-tight tracking-tight">
              Find Your Perfect{" "}
              <span className="text-gradient">Driving School</span>
            </h1>
            <p className="text-lg text-white/80 mb-8">
              Compare {schoolCount}+ verified schools. Read reviews. Book online.
            </p>

            {/* Search Box */}
            <div className="relative max-w-2xl">
              <div
                className={`relative flex items-center bg-white rounded-2xl transition-all duration-300 ${
                  isFocused ? "shadow-elevated ring-2 ring-[#0066cc]/20" : "shadow-lg"
                }`}
              >
                {/* AI indicator */}
                <div className="pl-4 pr-2">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                      isFocused ? "bg-[#0066cc]/10" : "bg-gray-100"
                    }`}
                  >
                    {isSearching ? (
                      <Loader2 className="w-5 h-5 text-[#0066cc] animate-spin" />
                    ) : (
                      <Sparkles
                        className={`w-5 h-5 ${isFocused ? "text-[#0066cc]" : "text-gray-400"}`}
                      />
                    )}
                  </div>
                </div>

                <input
                  ref={inputRef}
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onFocus={() => setIsFocused(true)}
                  onBlur={() => setTimeout(() => setIsFocused(false), 200)}
                  onKeyDown={handleKeyDown}
                  placeholder="Describe what you're looking for..."
                  className="flex-1 py-4 pr-4 text-gray-900 placeholder:text-gray-400 bg-transparent outline-none"
                />

                {/* Clear/Search button */}
                {searchTerm.trim() ? (
                  <div className="flex items-center gap-2 pr-3">
                    <button
                      onClick={() => {
                        clearSearch();
                        inputRef.current?.focus();
                      }}
                      className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onSearch(searchTerm)}
                      disabled={isSearching}
                      className="px-5 py-2.5 bg-[#0066cc] hover:bg-[#0052a3] text-white font-semibold rounded-xl transition-colors disabled:opacity-50"
                    >
                      {isSearching ? "Searching..." : "Search"}
                    </button>
                  </div>
                ) : (
                  <div className="pr-3">
                    <button
                      onClick={() => inputRef.current?.focus()}
                      className="p-3 bg-[#0066cc] text-white rounded-xl hover:bg-[#0052a3] transition-colors"
                    >
                      <Search className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>

              {/* AI Search Examples Dropdown */}
              <AnimatePresence>
                {showExamples && (
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.98 }}
                    className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-elevated border border-gray-100 overflow-hidden z-50"
                  >
                    <div className="p-3 border-b border-gray-100 bg-gradient-to-r from-[#0066cc]/5 to-[#4ecdc4]/5">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Wand2 className="w-4 h-4 text-[#0066cc]" />
                        <span className="font-medium">AI-powered search</span>
                        <span className="text-gray-400">— describe what you need</span>
                      </div>
                    </div>

                    <div className="max-h-80 overflow-y-auto">
                      {AI_SEARCH_EXAMPLES.map((example, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleExampleClick(example.query)}
                          className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors flex items-start gap-3 group"
                        >
                          <div className="w-8 h-8 rounded-lg bg-gray-100 group-hover:bg-[#0066cc]/10 flex items-center justify-center flex-shrink-0 mt-0.5 transition-colors">
                            <example.icon className="w-4 h-4 text-gray-500 group-hover:text-[#0066cc]" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-700 group-hover:text-[#0066cc] transition-colors">
                              {example.query}
                            </p>
                            <p className="text-xs text-gray-400 mt-0.5">{example.description}</p>
                          </div>
                          <ArrowUpRight className="w-4 h-4 text-gray-300 group-hover:text-[#0066cc] opacity-0 group-hover:opacity-100 transition-all" />
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap items-center gap-4 mt-6">
              <div className="flex items-center gap-2 text-white/80 text-sm">
                <BadgeCheck className="w-4 h-4 text-[#4ecdc4]" />
                <span>All schools verified</span>
              </div>
              <div className="flex items-center gap-2 text-white/80 text-sm">
                <Shield className="w-4 h-4 text-[#4ecdc4]" />
                <span>Secure booking</span>
              </div>
              <div className="flex items-center gap-2 text-white/80 text-sm">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                <span>Real reviews</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Image indicators */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
          {HERO_IMAGES.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentImage(idx)}
              className={`h-1.5 rounded-full transition-all ${
                idx === currentImage ? "w-8 bg-white" : "w-1.5 bg-white/50"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// QUICK FILTERS BAR
// ============================================================================

function QuickFiltersBar({ quickFilters, activeFilter, onFilterClick }) {
  const scrollRef = useRef(null);

  return (
    <div className="bg-white border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          ref={scrollRef}
          className="flex items-center gap-2 py-3 overflow-x-auto no-scrollbar"
        >
          <span className="text-sm text-gray-500 font-medium flex-shrink-0">Quick filters:</span>
          {quickFilters.map((filter) => (
            <motion.button
              key={filter.id}
              whileTap={{ scale: 0.95 }}
              onClick={() => onFilterClick(filter)}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                activeFilter === filter.id
                  ? "bg-[#0066cc] text-white shadow-lg shadow-[#0066cc]/25"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <filter.icon className="w-4 h-4" />
              {filter.label}
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// SEARCH & FILTERS BAR
// ============================================================================

function SearchFiltersBar({
  searchLocation,
  setSearchLocation,
  selectedCategory,
  setSelectedCategory,
  filters,
  handleFilterChange,
  sortBy,
  setSortBy,
  showSortMenu,
  setShowSortMenu,
  showFilters,
  setShowFilters,
  activeFilterCount,
  handleResetFilters,
  cities,
  viewMode,
  setViewMode,
  availableLanguages,
}) {
  return (
    <div className="sticky top-16 lg:top-20 z-30 bg-white border-b border-gray-200 shadow-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Location */}
          <select
            value={searchLocation}
            onChange={(e) => setSearchLocation(e.target.value)}
            className="flex-1 min-w-[140px] max-w-[180px] px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#0066cc]/20 focus:border-[#0066cc] cursor-pointer transition-all"
          >
            <option value="">All Locations</option>
            {cities.map((city) => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
          </select>

          {/* License Type */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="flex-1 min-w-[140px] max-w-[180px] px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#0066cc]/20 focus:border-[#0066cc] cursor-pointer transition-all"
          >
            <option value="all">All Licenses</option>
            <option value="B">Car (B)</option>
            <option value="A">Motorcycle (A)</option>
            <option value="C">Truck (C)</option>
            <option value="D">Bus (D)</option>
          </select>

          {/* Transmission */}
          <select
            value={filters.transmission}
            onChange={(e) => handleFilterChange("transmission", e.target.value)}
            className="flex-1 min-w-[140px] max-w-[180px] px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#0066cc]/20 focus:border-[#0066cc] cursor-pointer transition-all"
          >
            <option value="all">All Transmissions</option>
            <option value="manual">Manual</option>
            <option value="automatic">Automatic</option>
          </select>

          {/* Sort */}
          <div className="relative">
            <button
              onClick={() => setShowSortMenu(!showSortMenu)}
              className="px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:border-gray-300 transition-all inline-flex items-center gap-2 whitespace-nowrap"
            >
              <ArrowUpDown className="w-4 h-4 text-gray-500" />
              <span className="hidden sm:inline">
                {SORT_OPTIONS.find((o) => o.value === sortBy)?.label}
              </span>
              <ChevronDown
                className={`w-4 h-4 text-gray-400 transition-transform ${
                  showSortMenu ? "rotate-180" : ""
                }`}
              />
            </button>

            <AnimatePresence>
              {showSortMenu && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowSortMenu(false)}
                  />
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    className="absolute top-full right-0 mt-2 w-64 bg-white rounded-2xl shadow-elevated border border-gray-100 py-2 z-50"
                  >
                    {SORT_OPTIONS.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => {
                          setSortBy(option.value);
                          setShowSortMenu(false);
                        }}
                        className={`w-full px-4 py-3 text-left hover:bg-gray-50 transition-all flex items-center gap-3 ${
                          sortBy === option.value ? "bg-[#0066cc]/5 text-[#0066cc]" : "text-gray-700"
                        }`}
                      >
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                            sortBy === option.value ? "bg-[#0066cc]/10" : "bg-gray-100"
                          }`}
                        >
                          <option.icon className="w-4 h-4" />
                        </div>
                        <div className="flex-1">
                          <span className="text-sm font-medium block">{option.label}</span>
                          <span className="text-xs text-gray-400">{option.description}</span>
                        </div>
                        {sortBy === option.value && <CheckCircle className="w-4 h-4" />}
                      </button>
                    ))}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          {/* More Filters */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-all inline-flex items-center gap-2 whitespace-nowrap ${
              showFilters || activeFilterCount > 0
                ? "bg-[#0066cc]/10 border-2 border-[#0066cc]/20 text-[#0066cc]"
                : "bg-white border border-gray-200 text-gray-700 hover:border-gray-300"
            }`}
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>Filters</span>
            {activeFilterCount > 0 && (
              <span className="px-2 py-0.5 bg-[#0066cc] text-white rounded-full text-xs font-bold">
                {activeFilterCount}
              </span>
            )}
          </button>

          {/* Clear Filters */}
          <AnimatePresence>
            {activeFilterCount > 0 && (
              <motion.button
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                onClick={handleResetFilters}
                className="px-4 py-2.5 bg-red-50 border border-red-200 rounded-xl text-sm font-medium text-red-600 hover:bg-red-100 transition-all inline-flex items-center gap-2 whitespace-nowrap"
              >
                <X className="w-4 h-4" />
                Clear
              </motion.button>
            )}
          </AnimatePresence>

          {/* Spacer */}
          <div className="flex-1" />

          {/* View Mode Toggle (Desktop) */}
          <div className="hidden lg:flex items-center gap-2 bg-gray-100 p-1 rounded-xl">
            <button
              onClick={() => setViewMode("split")}
              className={`p-2 rounded-lg transition-all ${
                viewMode === "split" ? "bg-white shadow-sm text-[#0066cc]" : "text-gray-500 hover:text-gray-700"
              }`}
            >
              <div className="flex gap-0.5">
                <div className="w-3 h-5 bg-current rounded-sm opacity-60" />
                <div className="w-3 h-5 bg-current rounded-sm" />
              </div>
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-2 rounded-lg transition-all ${
                viewMode === "list" ? "bg-white shadow-sm text-[#0066cc]" : "text-gray-500 hover:text-gray-700"
              }`}
            >
              <Grid className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Expanded Filters Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 pt-4 border-t border-gray-200 overflow-hidden"
            >
              <FiltersPanel
                show={showFilters}
                onClose={() => setShowFilters(false)}
                filters={filters}
                onFilterChange={handleFilterChange}
                cities={cities}
                languages={availableLanguages}
                onReset={handleResetFilters}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// ============================================================================
// AI SEARCH CONTEXT
// ============================================================================

function AISearchContext({ aiFilters, query, resultCount, onClear }) {
  const filterChips = useMemo(() => {
    const chips = [];

    if (aiFilters.location) {
      chips.push({ label: aiFilters.location, icon: MapPin, color: "blue" });
    }
    if (aiFilters.experienceLevel) {
      chips.push({ label: aiFilters.experienceLevel, icon: Target, color: "green" });
    }
    if (aiFilters.language && aiFilters.language !== "all") {
      chips.push({ label: aiFilters.language, icon: Languages, color: "purple" });
    }
    if (aiFilters.instructorGender && aiFilters.instructorGender !== "all") {
      chips.push({ label: `${aiFilters.instructorGender} instructor`, icon: Users, color: "pink" });
    }
    if (aiFilters.transmission && aiFilters.transmission !== "all") {
      chips.push({ label: aiFilters.transmission, icon: Car, color: "orange" });
    }

    return chips;
  }, [aiFilters]);

  const colorClasses = {
    blue: "bg-blue-50 text-blue-700 border-blue-200",
    green: "bg-emerald-50 text-emerald-700 border-emerald-200",
    purple: "bg-purple-50 text-purple-700 border-purple-200",
    pink: "bg-pink-50 text-pink-700 border-pink-200",
    orange: "bg-orange-50 text-orange-700 border-orange-200",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4"
    >
      <div className="bg-white rounded-2xl border border-gray-200 shadow-card overflow-hidden">
        <div className="px-4 py-3 bg-gradient-to-r from-[#0066cc]/5 to-[#4ecdc4]/5 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#0066cc] to-[#4ecdc4] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-900">AI understood your search</p>
                <p className="text-xs text-gray-500">"{query}"</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-[#0066cc]">
                {resultCount} {resultCount === 1 ? "result" : "results"}
              </span>
              <button
                onClick={onClear}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {filterChips.length > 0 && (
          <div className="px-4 py-3">
            <div className="flex flex-wrap gap-2">
              {filterChips.map((chip, idx) => (
                <span
                  key={idx}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border ${
                    colorClasses[chip.color]
                  }`}
                >
                  <chip.icon className="w-3 h-3" />
                  {chip.label}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}

// ============================================================================
// AREA FILTER BANNER
// ============================================================================

function AreaFilterBanner({ count, onClear }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center justify-between px-4 py-3 mb-4 bg-[#0066cc]/5 border border-[#0066cc]/20 rounded-xl"
    >
      <div className="flex items-center gap-2">
        <Map className="w-4 h-4 text-[#0066cc]" />
        <span className="text-sm font-semibold text-[#0066cc]">
          {count} schools in selected area
        </span>
      </div>
      <button onClick={onClear} className="text-xs font-semibold text-[#0066cc] hover:underline">
        Clear area
      </button>
    </motion.div>
  );
}

// ============================================================================
// RESULTS HEADER
// ============================================================================

function ResultsHeader({ count, location, aiQuery }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <div>
        <h2 className="font-display text-xl font-bold text-gray-900">{count} schools found</h2>
        <p className="text-sm text-gray-500">
          {aiQuery ? `Matching: "${aiQuery}"` : location ? `In ${location}` : "In all locations"}
        </p>
      </div>
    </div>
  );
}

// ============================================================================
// SCHOOL CARD
// ============================================================================

function SchoolCard({
  school,
  index,
  isHighlighted,
  isSaved,
  onHover,
  onClick,
  onSave,
  onBook,
  viewMode = "list",
}) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <motion.div
      ref={ref}
      id={`school-${school.id}`}
      initial={{ opacity: 0, y: 20 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ delay: index * 0.05, duration: 0.4 }}
      onMouseEnter={() => onHover?.(school.id)}
      onMouseLeave={() => onHover?.(null)}
      onClick={() => onClick(school)}
      className={`group bg-white rounded-2xl border-2 overflow-hidden cursor-pointer transition-all duration-300 ${
        isHighlighted
          ? "border-[#0066cc] shadow-lg shadow-[#0066cc]/10 -translate-y-1"
          : "border-gray-200 hover:border-gray-300 hover:shadow-card-hover hover:-translate-y-0.5"
      }`}
    >
      {/* Image Section */}
      <div className="relative h-48 overflow-hidden">
        <img
          src={
            school.cover_image_url ||
            school.hero_image_url ||
            "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=600&auto=format"
          }
          alt={school.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

        {/* Top badges */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-2">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/95 backdrop-blur-sm text-xs font-semibold text-gray-900">
            <BadgeCheck className="w-3.5 h-3.5 text-[#0066cc]" />
            Verified
          </span>
          {school.passRate >= 90 && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#4ecdc4]/95 backdrop-blur-sm text-xs font-semibold text-white">
              <Award className="w-3.5 h-3.5" />
              {school.passRate}% pass
            </span>
          )}
        </div>

        {/* Save button */}
        <button
          onClick={(e) => onSave(school.id, e)}
          className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/95 backdrop-blur-sm flex items-center justify-center hover:scale-110 transition-transform"
        >
          <Heart
            className={`w-5 h-5 transition-colors ${
              isSaved ? "fill-[#ff6b6b] text-[#ff6b6b]" : "text-gray-600"
            }`}
          />
        </button>

        {/* Bottom info */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-black/50 backdrop-blur-sm">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-sm font-bold text-white">
                {(school.avgRating || 0).toFixed(1)}
              </span>
              <span className="text-xs text-white/70">({school.reviewCount || 0})</span>
            </div>
          </div>
          {school.recentBookings > 0 && (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-[#ff6b6b]/90 backdrop-blur-sm text-xs font-semibold text-white">
              <Flame className="w-3 h-3" />
              {school.recentBookings} booked this week
            </span>
          )}
        </div>
      </div>

      {/* Content Section */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-3 mb-2">
          <div>
            <h3 className="font-bold text-gray-900 group-hover:text-[#0066cc] transition-colors">
              {school.name}
            </h3>
            <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
              <MapPin className="w-4 h-4" />
              <span>{school.city || "Location available"}</span>
              {school.distance && (
                <>
                  <span>•</span>
                  <span>{school.distance.toFixed(1)} km away</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Quick stats */}
        <div className="flex flex-wrap gap-2 mb-3">
          {school.instructorCount > 0 && (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-gray-100 text-xs font-medium text-gray-600">
              <Users className="w-3 h-3" />
              {school.instructorCount} instructors
            </span>
          )}
          {school.hasPickupService && (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-50 text-xs font-medium text-emerald-700">
              <Navigation className="w-3 h-3" />
              Free pickup
            </span>
          )}
          {school.languages?.length > 0 && (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-purple-50 text-xs font-medium text-purple-700">
              <Languages className="w-3 h-3" />
              {school.languages.slice(0, 2).join(", ")}
            </span>
          )}
        </div>

        {/* Price and CTA */}
        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
          <div>
            <div className="text-xs text-gray-500">From</div>
            <div className="font-display text-xl font-bold text-gray-900">
              {school.minPrice ? `€${school.minPrice}` : "Contact"}
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onClick(school);
              }}
              className="px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl text-sm transition-colors"
            >
              View
            </button>
            <button
              onClick={(e) => onBook(school, e)}
              className="px-4 py-2.5 bg-[#0066cc] hover:bg-[#0052a3] text-white font-semibold rounded-xl text-sm transition-colors shadow-lg shadow-[#0066cc]/25"
            >
              Book
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ============================================================================
// EMPTY STATE
// ============================================================================

function EmptyState({ onReset, hasAISearch }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white rounded-2xl border border-gray-200 p-12 text-center shadow-card"
    >
      <div className="w-20 h-20 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
        <Search className="w-10 h-10 text-gray-300" />
      </div>
      <h3 className="font-display text-xl font-bold text-gray-900 mb-2">No schools found</h3>
      <p className="text-gray-500 mb-6 max-w-sm mx-auto">
        {hasAISearch
          ? "We couldn't find schools matching your description. Try broadening your search."
          : "Try adjusting your filters or search criteria to find more options."}
      </p>
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
        <button
          onClick={onReset}
          className="px-6 py-3 bg-[#0066cc] hover:bg-[#0052a3] text-white rounded-xl font-semibold shadow-lg shadow-[#0066cc]/25 transition-all"
        >
          Clear All Filters
        </button>
      </div>
    </motion.div>
  );
}

// ============================================================================
// MOBILE VIEW
// ============================================================================

function MobileView({
  viewMode,
  setViewMode,
  schools,
  filteredSchools,
  highlightedSchoolId,
  setHighlightedSchoolId,
  savedSchools,
  toggleSaveSchool,
  handleSchoolClick,
  handleBookNow,
  handleResetFilters,
  hasAISearch,
  handleAreaSearch,
  handleSchoolsInArea,
  userLocation,
}) {
  return (
    <div className="lg:hidden">
      {/* View toggle */}
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-bold text-gray-900">{schools.length} schools</p>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode("list")}
            className={`p-2.5 rounded-xl transition-all ${
              viewMode !== "map"
                ? "bg-[#0066cc]/10 text-[#0066cc]"
                : "bg-gray-100 text-gray-500"
            }`}
          >
            <List className="w-5 h-5" />
          </button>
          <button
            onClick={() => setViewMode("map")}
            className={`p-2.5 rounded-xl transition-all ${
              viewMode === "map"
                ? "bg-[#0066cc]/10 text-[#0066cc]"
                : "bg-gray-100 text-gray-500"
            }`}
          >
            <Map className="w-5 h-5" />
          </button>
        </div>
      </div>

      {viewMode !== "map" ? (
        <div className="space-y-4">
          {schools.map((school, index) => (
            <SchoolCard
              key={school.id}
              school={school}
              index={index}
              isHighlighted={highlightedSchoolId === school.id}
              isSaved={savedSchools.has(school.id)}
              onHover={setHighlightedSchoolId}
              onClick={handleSchoolClick}
              onSave={toggleSaveSchool}
              onBook={handleBookNow}
            />
          ))}

          {schools.length === 0 && (
            <EmptyState onReset={handleResetFilters} hasAISearch={hasAISearch} />
          )}
        </div>
      ) : (
        <div className="h-[calc(100vh-14rem)] rounded-2xl overflow-hidden shadow-elevated border border-gray-200">
          <InteractiveMap
            schools={filteredSchools}
            highlightedSchoolId={highlightedSchoolId}
            onMarkerClick={setHighlightedSchoolId}
            onMarkerHover={setHighlightedSchoolId}
            onAreaSearch={handleAreaSearch}
            onSchoolsInArea={handleSchoolsInArea}
            userLocation={userLocation}
            showDrawTools={true}
          />
        </div>
      )}
    </div>
  );
}

// ============================================================================
// LOADING STATE
// ============================================================================

function LoadingState() {
  return (
    <div className="min-h-screen bg-slate-50/50">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
        * { font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, system-ui, sans-serif; }
      `}</style>

      {/* Nav skeleton */}
      <div className="h-16 lg:h-20 bg-white border-b border-gray-100" />

      {/* Hero skeleton */}
      <div className="h-[400px] bg-gradient-to-br from-gray-200 to-gray-300 animate-pulse" />

      {/* Quick filters skeleton */}
      <div className="bg-white border-b border-gray-100 py-3">
        <div className="max-w-7xl mx-auto px-4 flex gap-2">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-10 w-28 bg-gray-100 rounded-full animate-pulse" />
          ))}
        </div>
      </div>

      {/* Filters skeleton */}
      <div className="bg-white border-b border-gray-200 py-4">
        <div className="max-w-7xl mx-auto px-4 flex gap-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-10 w-40 bg-gray-100 rounded-xl animate-pulse" />
          ))}
        </div>
      </div>

      {/* Content skeleton */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
                <div className="h-48 bg-gray-200 animate-pulse" />
                <div className="p-4 space-y-3">
                  <div className="h-5 w-3/4 bg-gray-100 rounded animate-pulse" />
                  <div className="h-4 w-1/2 bg-gray-100 rounded animate-pulse" />
                  <div className="flex gap-2">
                    <div className="h-8 w-20 bg-gray-100 rounded-lg animate-pulse" />
                    <div className="h-8 w-20 bg-gray-100 rounded-lg animate-pulse" />
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="hidden lg:block h-[600px] bg-gray-200 rounded-2xl animate-pulse" />
        </div>
      </div>
    </div>
  );
}