import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Calendar,
  Clock,
  Plus,
  Trash2,
  Save,
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  Loader2,
  Copy,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  X,
  Eye,
  EyeOff,
  Settings,
  Zap,
  MapPin,
  Car,
  Coffee,
  Moon,
  Sun,
  Sunrise,
  Sunset,
  CalendarDays,
  CalendarRange,
  CalendarOff,
  Timer,
  Target,
  TrendingUp,
  AlertTriangle,
  Info,
  HelpCircle,
  RotateCcw,
  Download,
  Upload,
  Share2,
  Lock,
  Unlock,
  Repeat,
  Bell,
  BellOff,
  Globe
} from "lucide-react";
import { 
  format, 
  addDays, 
  addWeeks, 
  addMonths, 
  startOfWeek, 
  endOfWeek,
  eachDayOfInterval,
  isSameDay,
  isAfter,
  isBefore,
  parseISO,
  differenceInMinutes,
  setHours,
  setMinutes
} from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const DEFAULT_SCHEDULE = {
  monday: [{ start: "09:00", end: "17:00", break: false }],
  tuesday: [{ start: "09:00", end: "17:00", break: false }],
  wednesday: [{ start: "09:00", end: "17:00", break: false }],
  thursday: [{ start: "09:00", end: "17:00", break: false }],
  friday: [{ start: "09:00", end: "17:00", break: false }],
  saturday: [{ start: "09:00", end: "13:00", break: false }],
  sunday: []
};

const PRESET_SCHEDULES = [
  {
    id: "full_time",
    name: "Full-Time (Mon-Fri)",
    description: "Standard 9-5 schedule, weekdays only",
    schedule: {
      monday: [{ start: "09:00", end: "17:00", break: false }],
      tuesday: [{ start: "09:00", end: "17:00", break: false }],
      wednesday: [{ start: "09:00", end: "17:00", break: false }],
      thursday: [{ start: "09:00", end: "17:00", break: false }],
      friday: [{ start: "09:00", end: "17:00", break: false }],
      saturday: [],
      sunday: []
    }
  },
  {
    id: "extended",
    name: "Extended Hours",
    description: "Early morning to evening, 6 days",
    schedule: {
      monday: [{ start: "07:00", end: "20:00", break: false }],
      tuesday: [{ start: "07:00", end: "20:00", break: false }],
      wednesday: [{ start: "07:00", end: "20:00", break: false }],
      thursday: [{ start: "07:00", end: "20:00", break: false }],
      friday: [{ start: "07:00", end: "20:00", break: false }],
      saturday: [{ start: "08:00", end: "16:00", break: false }],
      sunday: []
    }
  },
  {
    id: "split_shift",
    name: "Split Shift",
    description: "Morning and evening sessions with midday break",
    schedule: {
      monday: [
        { start: "07:00", end: "12:00", break: false },
        { start: "16:00", end: "20:00", break: false }
      ],
      tuesday: [
        { start: "07:00", end: "12:00", break: false },
        { start: "16:00", end: "20:00", break: false }
      ],
      wednesday: [
        { start: "07:00", end: "12:00", break: false },
        { start: "16:00", end: "20:00", break: false }
      ],
      thursday: [
        { start: "07:00", end: "12:00", break: false },
        { start: "16:00", end: "20:00", break: false }
      ],
      friday: [
        { start: "07:00", end: "12:00", break: false },
        { start: "16:00", end: "20:00", break: false }
      ],
      saturday: [{ start: "09:00", end: "14:00", break: false }],
      sunday: []
    }
  },
  {
    id: "weekends",
    name: "Weekend Warrior",
    description: "Focus on weekends with some weekday availability",
    schedule: {
      monday: [],
      tuesday: [{ start: "17:00", end: "20:00", break: false }],
      wednesday: [],
      thursday: [{ start: "17:00", end: "20:00", break: false }],
      friday: [{ start: "14:00", end: "20:00", break: false }],
      saturday: [{ start: "08:00", end: "18:00", break: false }],
      sunday: [{ start: "09:00", end: "17:00", break: false }]
    }
  }
];

const DAYS = [
  { key: "monday", label: "Monday", short: "Mon" },
  { key: "tuesday", label: "Tuesday", short: "Tue" },
  { key: "wednesday", label: "Wednesday", short: "Wed" },
  { key: "thursday", label: "Thursday", short: "Thu" },
  { key: "friday", label: "Friday", short: "Fri" },
  { key: "saturday", label: "Saturday", short: "Sat" },
  { key: "sunday", label: "Sunday", short: "Sun" }
];

const TIME_SLOTS = Array.from({ length: 48 }, (_, i) => {
  const hour = Math.floor(i / 2);
  const minute = (i % 2) * 30;
  return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
});

export default function InstructorSetAvailability() {
  const queryClient = useQueryClient();
  
  const [user, setUser] = useState(null);
  const [instructor, setInstructor] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("weekly");
  const [viewMode, setViewMode] = useState("detailed");
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [showPresetModal, setShowPresetModal] = useState(false);
  const [showBlockDateModal, setShowBlockDateModal] = useState(false);
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  const [expandedDays, setExpandedDays] = useState(new Set(DAYS.map(d => d.key)));

  const [weeklySchedule, setWeeklySchedule] = useState(DEFAULT_SCHEDULE);
  
  const [blockedDates, setBlockedDates] = useState([]);
  const [newBlockedDate, setNewBlockedDate] = useState({
    startDate: "",
    endDate: "",
    reason: "",
    recurring: false
  });

  const [availabilitySettings, setAvailabilitySettings] = useState({
    minBookingNotice: 2,
    maxAdvanceBookingDays: 30,
    slotDuration: 60,
    bufferBetweenLessons: 15,
    allowSameDayBookings: true,
    autoAcceptBookings: false,
    breakDuration: 0,
    maxLessonsPerDay: 8,
    preferredAreas: [],
    maxTravelDistance: 15
  });

  useEffect(() => {
    const loadUser = async () => {
      try {
        setIsLoading(true);
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        const instructors = await base44.entities.Instructor.filter({ email: currentUser.email });
        if (instructors.length > 0) {
          const inst = instructors[0];
          setInstructor(inst);
          
          if (inst.availability) {
            setWeeklySchedule(inst.availability);
          }
          
          if (inst.blocked_dates) {
            setBlockedDates(inst.blocked_dates);
          }
          
          if (inst.availability_settings) {
            setAvailabilitySettings(prev => ({ ...prev, ...inst.availability_settings }));
          }
        }
      } catch (error) {
        console.error("Error loading user:", error);
        toast.error("Failed to load availability data");
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  const updateAvailabilityMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.Instructor.update(instructor.id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructor'] });
      setHasUnsavedChanges(false);
      toast.success("Availability updated successfully");
    },
    onError: () => {
      toast.error("Failed to update availability");
    }
  });

  const handleSave = () => {
    updateAvailabilityMutation.mutate({
      availability: weeklySchedule,
      blocked_dates: blockedDates,
      availability_settings: availabilitySettings
    });
  };

  const handleScheduleChange = useCallback((newSchedule) => {
    setWeeklySchedule(newSchedule);
    setHasUnsavedChanges(true);
  }, []);

  const addTimeSlot = (day) => {
    const lastSlot = weeklySchedule[day][weeklySchedule[day].length - 1];
    const newStart = lastSlot ? lastSlot.end : "09:00";
    const newEnd = incrementTime(newStart, 2);
    
    handleScheduleChange({
      ...weeklySchedule,
      [day]: [...weeklySchedule[day], { start: newStart, end: newEnd, break: false }]
    });
  };

  const removeTimeSlot = (day, index) => {
    handleScheduleChange({
      ...weeklySchedule,
      [day]: weeklySchedule[day].filter((_, i) => i !== index)
    });
  };

  const updateTimeSlot = (day, index, field, value) => {
    handleScheduleChange({
      ...weeklySchedule,
      [day]: weeklySchedule[day].map((slot, i) => 
        i === index ? { ...slot, [field]: value } : slot
      )
    });
  };

  const toggleDayEnabled = (day) => {
    if (weeklySchedule[day].length === 0) {
      handleScheduleChange({
        ...weeklySchedule,
        [day]: [{ start: "09:00", end: "17:00", break: false }]
      });
    } else {
      handleScheduleChange({
        ...weeklySchedule,
        [day]: []
      });
    }
  };

  const copyToAllWeekdays = (sourceDay) => {
    const sourceSlots = weeklySchedule[sourceDay];
    handleScheduleChange({
      ...weeklySchedule,
      monday: sourceSlots,
      tuesday: sourceSlots,
      wednesday: sourceSlots,
      thursday: sourceSlots,
      friday: sourceSlots
    });
    toast.success("Schedule copied to all weekdays");
  };

  const copyToAllDays = (sourceDay) => {
    const sourceSlots = weeklySchedule[sourceDay];
    const newSchedule = {};
    DAYS.forEach(d => {
      newSchedule[d.key] = [...sourceSlots];
    });
    handleScheduleChange(newSchedule);
    toast.success("Schedule copied to all days");
  };

  const applyPreset = (preset) => {
    handleScheduleChange(preset.schedule);
    setShowPresetModal(false);
    toast.success(`Applied "${preset.name}" preset`);
  };

  const resetToDefault = () => {
    handleScheduleChange(DEFAULT_SCHEDULE);
    toast.success("Reset to default schedule");
  };

  const clearAllAvailability = () => {
    const emptySchedule = {};
    DAYS.forEach(d => {
      emptySchedule[d.key] = [];
    });
    handleScheduleChange(emptySchedule);
    toast.info("All availability cleared");
  };

  const addBlockedDate = () => {
    if (!newBlockedDate.startDate) {
      toast.error("Please select a start date");
      return;
    }

    const blocked = {
      id: Date.now().toString(),
      startDate: newBlockedDate.startDate,
      endDate: newBlockedDate.endDate || newBlockedDate.startDate,
      reason: newBlockedDate.reason,
      recurring: newBlockedDate.recurring,
      createdAt: new Date().toISOString()
    };

    setBlockedDates(prev => [...prev, blocked]);
    setNewBlockedDate({ startDate: "", endDate: "", reason: "", recurring: false });
    setShowBlockDateModal(false);
    setHasUnsavedChanges(true);
    toast.success("Date blocked");
  };

  const removeBlockedDate = (id) => {
    setBlockedDates(prev => prev.filter(d => d.id !== id));
    setHasUnsavedChanges(true);
    toast.success("Blocked date removed");
  };

  const toggleDayExpanded = (day) => {
    setExpandedDays(prev => {
      const next = new Set(prev);
      if (next.has(day)) {
        next.delete(day);
      } else {
        next.add(day);
      }
      return next;
    });
  };

  const incrementTime = (time, hours) => {
    const [h, m] = time.split(':').map(Number);
    const newH = Math.min(23, h + hours);
    return `${newH.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
  };

  const calculateTotalHours = useMemo(() => {
    let total = 0;
    Object.values(weeklySchedule).forEach(slots => {
      slots.forEach(slot => {
        if (!slot.break) {
          const [startH, startM] = slot.start.split(':').map(Number);
          const [endH, endM] = slot.end.split(':').map(Number);
          const startMinutes = startH * 60 + startM;
          const endMinutes = endH * 60 + endM;
          total += (endMinutes - startMinutes) / 60;
        }
      });
    });
    return total;
  }, [weeklySchedule]);

  const stats = useMemo(() => {
    const workingDays = DAYS.filter(d => weeklySchedule[d.key].length > 0).length;
    const avgHoursPerDay = workingDays > 0 ? calculateTotalHours / workingDays : 0;
    const earliestStart = Math.min(...Object.values(weeklySchedule)
      .flat()
      .filter(s => !s.break && s.start)
      .map(s => parseInt(s.start.split(':')[0])) || [9]);
    const latestEnd = Math.max(...Object.values(weeklySchedule)
      .flat()
      .filter(s => !s.break && s.end)
      .map(s => parseInt(s.end.split(':')[0])) || [17]);

    return {
      totalHours: calculateTotalHours,
      workingDays,
      avgHoursPerDay,
      earliestStart: earliestStart < 24 ? `${earliestStart}:00` : "N/A",
      latestEnd: latestEnd > 0 ? `${latestEnd}:00` : "N/A",
      blockedDatesCount: blockedDates.length
    };
  }, [weeklySchedule, calculateTotalHours, blockedDates]);

  const validateTimeSlot = (slot) => {
    if (!slot.start || !slot.end) return { valid: false, message: "Times required" };
    
    const [startH, startM] = slot.start.split(':').map(Number);
    const [endH, endM] = slot.end.split(':').map(Number);
    const startMinutes = startH * 60 + startM;
    const endMinutes = endH * 60 + endM;
    
    if (endMinutes <= startMinutes) {
      return { valid: false, message: "End time must be after start time" };
    }
    
    if ((endMinutes - startMinutes) < 30) {
      return { valid: false, message: "Minimum slot duration is 30 minutes" };
    }
    
    return { valid: true };
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading availability...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Link
          to={createPageUrl("InstructorSchedule")}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Schedule
        </Link>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Set Availability</h1>
            <p className="text-gray-600 mt-1">Configure your working hours and blocked dates</p>
          </div>

          <div className="flex gap-2">
            {hasUnsavedChanges && (
              <span className="flex items-center gap-2 px-3 py-2 bg-amber-100 text-amber-700 rounded-lg text-sm font-semibold">
                <AlertCircle className="w-4 h-4" />
                Unsaved changes
              </span>
            )}
            <button
              onClick={handleSave}
              disabled={updateAvailabilityMutation.isPending}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl font-semibold hover:shadow-lg transition disabled:opacity-50"
            >
              {updateAvailabilityMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  Save Changes
                </>
              )}
            </button>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {[
          { label: "Weekly Hours", value: stats.totalHours.toFixed(1), icon: Clock, color: "indigo" },
          { label: "Working Days", value: stats.workingDays, icon: Calendar, color: "blue" },
          { label: "Avg Hours/Day", value: stats.avgHoursPerDay.toFixed(1), icon: Target, color: "purple" },
          { label: "Earliest Start", value: stats.earliestStart, icon: Sunrise, color: "amber" },
          { label: "Latest End", value: stats.latestEnd, icon: Sunset, color: "orange" },
          { label: "Blocked Dates", value: stats.blockedDatesCount, icon: CalendarOff, color: "red" }
        ].map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm"
          >
            <div className={`w-10 h-10 bg-${stat.color}-100 rounded-lg flex items-center justify-center mb-2`}>
              <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-xs text-gray-600">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-2xl border border-gray-200 p-2 shadow-sm"
      >
        <div className="flex gap-1 overflow-x-auto">
          {[
            { id: "weekly", label: "Weekly Schedule", icon: Calendar },
            { id: "blocked", label: "Blocked Dates", icon: CalendarOff },
            { id: "settings", label: "Settings", icon: Settings }
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm whitespace-nowrap transition ${
                activeTab === id
                  ? "bg-indigo-600 text-white"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>
      </motion.div>

      <AnimatePresence mode="wait">
        {activeTab === "weekly" && (
          <motion.div
            key="weekly"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowPresetModal(true)}
                    className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl font-semibold text-sm transition flex items-center gap-2"
                  >
                    <Zap className="w-4 h-4" />
                    Use Preset
                  </button>
                  <button
                    onClick={resetToDefault}
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold text-sm transition flex items-center gap-2"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Reset
                  </button>
                  <button
                    onClick={clearAllAvailability}
                    className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl font-semibold text-sm transition flex items-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    Clear All
                  </button>
                </div>

                <div className="flex gap-1 p-1 bg-gray-100 rounded-xl">
                  <button
                    onClick={() => setViewMode("detailed")}
                    className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition ${
                      viewMode === "detailed" ? "bg-white shadow-sm" : "hover:bg-gray-200"
                    }`}
                  >
                    Detailed
                  </button>
                  <button
                    onClick={() => setViewMode("compact")}
                    className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition ${
                      viewMode === "compact" ? "bg-white shadow-sm" : "hover:bg-gray-200"
                    }`}
                  >
                    Compact
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              {DAYS.map((day, dayIndex) => {
                const slots = weeklySchedule[day.key];
                const isEnabled = slots.length > 0;
                const isExpanded = expandedDays.has(day.key);
                const totalHours = slots.reduce((sum, slot) => {
                  if (slot.break) return sum;
                  const [sh, sm] = slot.start.split(':').map(Number);
                  const [eh, em] = slot.end.split(':').map(Number);
                  return sum + ((eh * 60 + em) - (sh * 60 + sm)) / 60;
                }, 0);

                return (
                  <motion.div
                    key={day.key}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: dayIndex * 0.03 }}
                    className={`bg-white rounded-2xl border-2 shadow-sm overflow-hidden ${
                      isEnabled ? "border-gray-200" : "border-gray-100"
                    }`}
                  >
                    <div 
                      className={`flex items-center justify-between p-4 cursor-pointer transition ${
                        isEnabled ? "hover:bg-gray-50" : "bg-gray-50"
                      }`}
                      onClick={() => viewMode === "detailed" && toggleDayExpanded(day.key)}
                    >
                      <div className="flex items-center gap-4">
                        <button
                          onClick={(e) => { e.stopPropagation(); toggleDayEnabled(day.key); }}
                          className={`w-12 h-6 rounded-full transition relative ${
                            isEnabled ? "bg-indigo-600" : "bg-gray-300"
                          }`}
                        >
                          <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition ${
                            isEnabled ? "left-7" : "left-1"
                          }`} />
                        </button>

                        <div>
                          <h3 className={`text-lg font-bold ${isEnabled ? "text-gray-900" : "text-gray-400"}`}>
                            {day.label}
                          </h3>
                          <p className={`text-sm ${isEnabled ? "text-gray-600" : "text-gray-400"}`}>
                            {isEnabled 
                              ? `${slots.length} slot${slots.length !== 1 ? 's' : ''} • ${totalHours.toFixed(1)} hours`
                              : "Not available"
                            }
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {isEnabled && viewMode === "compact" && (
                          <div className="hidden md:flex items-center gap-2 text-sm text-gray-600">
                            {slots.map((slot, i) => (
                              <span key={i} className="px-2 py-1 bg-gray-100 rounded">
                                {slot.start} - {slot.end}
                              </span>
                            ))}
                          </div>
                        )}

                        {isEnabled && (
                          <div className="flex gap-1">
                            <button
                              onClick={(e) => { e.stopPropagation(); copyToAllWeekdays(day.key); }}
                              className="p-2 hover:bg-gray-100 rounded-lg transition"
                              title="Copy to weekdays"
                            >
                              <Copy className="w-4 h-4 text-gray-400" />
                            </button>
                            <button
                              onClick={(e) => { e.stopPropagation(); addTimeSlot(day.key); }}
                              className="p-2 hover:bg-gray-100 rounded-lg transition"
                              title="Add time slot"
                            >
                              <Plus className="w-4 h-4 text-gray-400" />
                            </button>
                          </div>
                        )}

                        {viewMode === "detailed" && isEnabled && (
                          isExpanded ? (
                            <ChevronUp className="w-5 h-5 text-gray-400" />
                          ) : (
                            <ChevronDown className="w-5 h-5 text-gray-400" />
                          )
                        )}
                      </div>
                    </div>

                    <AnimatePresence>
                      {isEnabled && isExpanded && viewMode === "detailed" && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="px-4 pb-4 space-y-3 border-t border-gray-200 pt-4">
                            {slots.map((slot, index) => {
                              const validation = validateTimeSlot(slot);
                              
                              return (
                                <div 
                                  key={index} 
                                  className={`flex items-center gap-3 p-3 rounded-xl ${
                                    slot.break ? "bg-amber-50" : "bg-gray-50"
                                  }`}
                                >
                                  <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
                                    <div>
                                      <label className="block text-xs font-medium text-gray-700 mb-1">
                                        Start Time
                                      </label>
                                      <select
                                        value={slot.start}
                                        onChange={(e) => updateTimeSlot(day.key, index, "start", e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600 text-sm"
                                      >
                                        {TIME_SLOTS.map(time => (
                                          <option key={time} value={time}>{time}</option>
                                        ))}
                                      </select>
                                    </div>
                                    <div>
                                      <label className="block text-xs font-medium text-gray-700 mb-1">
                                        End Time
                                      </label>
                                      <select
                                        value={slot.end}
                                        onChange={(e) => updateTimeSlot(day.key, index, "end", e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600 text-sm"
                                      >
                                        {TIME_SLOTS.map(time => (
                                          <option key={time} value={time}>{time}</option>
                                        ))}
                                      </select>
                                    </div>
                                    <div className="flex items-end">
                                      <label className="flex items-center gap-2 cursor-pointer">
                                        <input
                                          type="checkbox"
                                          checked={slot.break}
                                          onChange={(e) => updateTimeSlot(day.key, index, "break", e.target.checked)}
                                          className="w-4 h-4 text-amber-600 rounded"
                                        />
                                        <span className="text-sm text-gray-700 flex items-center gap-1">
                                          <Coffee className="w-4 h-4" />
                                          Break
                                        </span>
                                      </label>
                                    </div>
                                    <div className="flex items-end justify-end">
                                      {!validation.valid && (
                                        <span className="text-xs text-red-600 mr-2">{validation.message}</span>
                                      )}
                                    </div>
                                  </div>

                                  <button
                                    onClick={() => removeTimeSlot(day.key, index)}
                                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              );
                            })}

                            <button
                              onClick={() => addTimeSlot(day.key)}
                              className="w-full py-2 border-2 border-dashed border-gray-300 rounded-xl text-gray-600 hover:border-indigo-300 hover:text-indigo-600 transition flex items-center justify-center gap-2 text-sm font-semibold"
                            >
                              <Plus className="w-4 h-4" />
                              Add Time Slot
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        )}

        {activeTab === "blocked" && (
          <motion.div
            key="blocked"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">Blocked Dates</h3>
                  <p className="text-sm text-gray-600">Mark dates when you're unavailable</p>
                </div>
                <button
                  onClick={() => setShowBlockDateModal(true)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold text-sm transition flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Block Date
                </button>
              </div>

              {blockedDates.length === 0 ? (
                <div className="text-center py-12">
                  <CalendarOff className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-600">No blocked dates</p>
                  <p className="text-sm text-gray-500">Add dates when you're unavailable for lessons</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {blockedDates.map((blocked) => (
                    <div 
                      key={blocked.id}
                      className="flex items-center justify-between p-4 bg-red-50 border border-red-200 rounded-xl"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                          <CalendarOff className="w-6 h-6 text-red-600" />
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">
                            {format(new Date(blocked.startDate), "MMMM d, yyyy")}
                            {blocked.endDate !== blocked.startDate && (
                              <> - {format(new Date(blocked.endDate), "MMMM d, yyyy")}</>
                            )}
                          </p>
                          {blocked.reason && (
                            <p className="text-sm text-gray-600">{blocked.reason}</p>
                          )}
                          {blocked.recurring && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-100 text-amber-700 rounded text-xs font-semibold mt-1">
                              <Repeat className="w-3 h-3" />
                              Recurring annually
                            </span>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => removeBlockedDate(blocked.id)}
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === "settings" && (
          <motion.div
            key="settings"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Booking Settings</h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Minimum Booking Notice (hours)
                  </label>
                  <input
                    type="number"
                    value={availabilitySettings.minBookingNotice}
                    onChange={(e) => {
                      setAvailabilitySettings(prev => ({ 
                        ...prev, 
                        minBookingNotice: parseInt(e.target.value) || 0 
                      }));
                      setHasUnsavedChanges(true);
                    }}
                    min="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    How much notice students must give when booking
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Maximum Advance Booking (days)
                  </label>
                  <input
                    type="number"
                    value={availabilitySettings.maxAdvanceBookingDays}
                    onChange={(e) => {
                      setAvailabilitySettings(prev => ({ 
                        ...prev, 
                        maxAdvanceBookingDays: parseInt(e.target.value) || 0 
                      }));
                      setHasUnsavedChanges(true);
                    }}
                    min="1"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    How far in advance students can book lessons
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Default Lesson Duration (minutes)
                  </label>
                  <select
                    value={availabilitySettings.slotDuration}
                    onChange={(e) => {
                      setAvailabilitySettings(prev => ({ 
                        ...prev, 
                        slotDuration: parseInt(e.target.value) 
                      }));
                      setHasUnsavedChanges(true);
                    }}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  >
                    <option value={30}>30 minutes</option>
                    <option value={45}>45 minutes</option>
                    <option value={60}>60 minutes</option>
                    <option value={90}>90 minutes</option>
                    <option value={120}>120 minutes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Buffer Between Lessons (minutes)
                  </label>
                  <select
                    value={availabilitySettings.bufferBetweenLessons}
                    onChange={(e) => {
                      setAvailabilitySettings(prev => ({ 
                        ...prev, 
                        bufferBetweenLessons: parseInt(e.target.value) 
                      }));
                      setHasUnsavedChanges(true);
                    }}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  >
                    <option value={0}>No buffer</option>
                    <option value={5}>5 minutes</option>
                    <option value={10}>10 minutes</option>
                    <option value={15}>15 minutes</option>
                    <option value={30}>30 minutes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Maximum Lessons Per Day
                  </label>
                  <input
                    type="number"
                    value={availabilitySettings.maxLessonsPerDay}
                    onChange={(e) => {
                      setAvailabilitySettings(prev => ({ 
                        ...prev, 
                        maxLessonsPerDay: parseInt(e.target.value) || 1 
                      }));
                      setHasUnsavedChanges(true);
                    }}
                    min="1"
                    max="20"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Maximum Travel Distance (km)
                  </label>
                  <input
                    type="number"
                    value={availabilitySettings.maxTravelDistance}
                    onChange={(e) => {
                      setAvailabilitySettings(prev => ({ 
                        ...prev, 
                        maxTravelDistance: parseInt(e.target.value) || 0 
                      }));
                      setHasUnsavedChanges(true);
                    }}
                    min="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>
              </div>

              <div className="mt-6 space-y-3">
                <label className="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer">
                  <div>
                    <p className="font-semibold text-gray-900">Allow Same-Day Bookings</p>
                    <p className="text-sm text-gray-600">Students can book lessons for today</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={availabilitySettings.allowSameDayBookings}
                    onChange={(e) => {
                      setAvailabilitySettings(prev => ({ 
                        ...prev, 
                        allowSameDayBookings: e.target.checked 
                      }));
                      setHasUnsavedChanges(true);
                    }}
                    className="w-6 h-6 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                </label>

                <label className="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer">
                  <div>
                    <p className="font-semibold text-gray-900">Auto-Accept Bookings</p>
                    <p className="text-sm text-gray-600">Automatically confirm new bookings</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={availabilitySettings.autoAcceptBookings}
                    onChange={(e) => {
                      setAvailabilitySettings(prev => ({ 
                        ...prev, 
                        autoAcceptBookings: e.target.checked 
                      }));
                      setHasUnsavedChanges(true);
                    }}
                    className="w-6 h-6 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                </label>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showPresetModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowPresetModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Choose a Preset</h3>
                <button
                  onClick={() => setShowPresetModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-3">
                {PRESET_SCHEDULES.map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => applyPreset(preset)}
                    className="w-full p-4 text-left bg-gray-50 hover:bg-indigo-50 border-2 border-transparent hover:border-indigo-200 rounded-xl transition"
                  >
                    <p className="font-bold text-gray-900">{preset.name}</p>
                    <p className="text-sm text-gray-600">{preset.description}</p>
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showBlockDateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowBlockDateModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Block Date</h3>
                <button
                  onClick={() => setShowBlockDateModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
                  <input
                    type="date"
                    value={newBlockedDate.startDate}
                    onChange={(e) => setNewBlockedDate(prev => ({ ...prev, startDate: e.target.value }))}
                    min={format(new Date(), "yyyy-MM-dd")}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">End Date (optional)</label>
                  <input
                    type="date"
                    value={newBlockedDate.endDate}
                    onChange={(e) => setNewBlockedDate(prev => ({ ...prev, endDate: e.target.value }))}
                    min={newBlockedDate.startDate || format(new Date(), "yyyy-MM-dd")}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Reason (optional)</label>
                  <input
                    type="text"
                    value={newBlockedDate.reason}
                    onChange={(e) => setNewBlockedDate(prev => ({ ...prev, reason: e.target.value }))}
                    placeholder="e.g., Holiday, Training, Personal"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <label className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newBlockedDate.recurring}
                    onChange={(e) => setNewBlockedDate(prev => ({ ...prev, recurring: e.target.checked }))}
                    className="w-5 h-5 rounded border-gray-300 text-indigo-600"
                  />
                  <div>
                    <p className="font-semibold text-gray-900">Recurring annually</p>
                    <p className="text-sm text-gray-600">Block this date every year</p>
                  </div>
                </label>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => setShowBlockDateModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={addBlockedDate}
                  className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold transition"
                >
                  Block Date
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}