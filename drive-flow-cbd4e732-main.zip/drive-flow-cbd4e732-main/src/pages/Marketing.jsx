import React, { useState, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Plus,
  Mail,
  TrendingUp,
  Users,
  Calendar,
  Edit,
  Trash2,
  Play,
  Pause,
  Eye,
  Target,
  Zap,
  BarChart3,
  Search,
  Filter,
  X,
  Check,
  Clock,
  Send,
  MessageSquare,
  Gift,
  Star,
  Bell,
  Settings,
  RefreshCw,
  ChevronRight,
  ChevronDown,
  Copy,
  ExternalLink,
  Download,
  Upload,
  Sparkles,
  Brain,
  Lightbulb,
  Megaphone,
  MousePointer,
  UserPlus,
  UserMinus,
  Award,
  Percent,
  DollarSign,
  PieChart,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  MoreVertical,
  FileText,
  Hash,
  AlertCircle,
  CheckCircle,
  XCircle,
  Info,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format, parseISO, differenceInDays, addDays, subDays, isAfter, isBefore } from "date-fns";
import { toast } from "sonner";

const CAMPAIGN_TEMPLATES = [
  {
    id: "package_sale",
    name: "Package Promotion",
    description: "Promote lesson packages with special discounts",
    type: "package_promotion",
    icon: Gift,
    subject: "🎁 Exclusive Offer: Save on Your Lesson Package!",
    body: `Hi {student_name},

We have an exclusive offer just for you! For a limited time, get 15% off our most popular lesson packages.

Whether you're just starting out or need a few more hours to feel confident, now is the perfect time to book.

Use code SAVE15 at checkout.

Book your lessons today and accelerate your journey to becoming a confident driver!

Best regards,
Your Driving School Team`,
    targetAudience: "active_students",
    color: "from-purple-500 to-pink-500",
  },
  {
    id: "off_peak",
    name: "Off-Peak Slots",
    description: "Fill morning and early afternoon slots",
    type: "off_peak_slots",
    icon: Clock,
    subject: "⏰ Special Morning Rates - Limited Availability!",
    body: `Hi {student_name},

Did you know you can save money by booking during off-peak hours?

Our morning slots (8am-12pm) are now available at a special reduced rate. It's the perfect way to get more driving practice while saving money.

Benefits of morning lessons:
- Quieter roads for nervous learners
- Fresh and alert for better concentration
- Lower prices than peak times

Book your morning lesson today!

Best regards,
Your Driving School Team`,
    targetAudience: "active_students",
    color: "from-amber-500 to-orange-500",
  },
  {
    id: "win_back",
    name: "Win-Back Campaign",
    description: "Re-engage inactive students",
    type: "reactivation",
    icon: UserPlus,
    subject: "We Miss You! 🚗 Come Back & Save 20%",
    body: `Hi {student_name},

We noticed it's been a while since your last lesson, and we wanted to reach out.

Life gets busy, we understand! But don't let your driving goals slip away. We're here to help you get back on track.

As a welcome back gift, here's 20% off your next lesson when you book within the next 7 days.

Use code WELCOME20 when booking.

We'd love to see you back behind the wheel!

Best regards,
Your Driving School Team`,
    targetAudience: "inactive_students",
    color: "from-emerald-500 to-teal-500",
  },
  {
    id: "referral",
    name: "Referral Program",
    description: "Encourage students to refer friends",
    type: "referral",
    icon: Users,
    subject: "🎉 Earn Free Lessons - Refer a Friend!",
    body: `Hi {student_name},

Love your driving lessons? Share the experience with your friends and family!

For every friend you refer who books a package:
- You get a FREE lesson
- They get 10% off their first booking

It's a win-win! Simply share your unique referral code: REF-{student_id}

There's no limit to how many free lessons you can earn. Start sharing today!

Best regards,
Your Driving School Team`,
    targetAudience: "active_students",
    color: "from-blue-500 to-indigo-500",
  },
  {
    id: "milestone",
    name: "Milestone Celebration",
    description: "Celebrate student achievements",
    type: "milestone",
    icon: Award,
    subject: "🏆 Congratulations on Your Progress!",
    body: `Hi {student_name},

Congratulations! You've reached an amazing milestone in your driving journey.

Your dedication and progress have been incredible to witness. Keep up the fantastic work!

As a thank you for your commitment, here's a special gift: 10% off your next booking.

Use code MILESTONE10 at checkout.

Keep pushing forward - you're doing great!

Best regards,
Your Driving School Team`,
    targetAudience: "active_students",
    color: "from-yellow-500 to-amber-500",
  },
  {
    id: "feedback",
    name: "Feedback Request",
    description: "Collect reviews and testimonials",
    type: "feedback_request",
    icon: Star,
    subject: "⭐ How Was Your Experience? We'd Love to Hear!",
    body: `Hi {student_name},

We hope you're enjoying your driving lessons with us!

Your feedback means the world to us and helps us improve our service. Would you mind taking 2 minutes to share your experience?

Click here to leave a review: [Review Link]

As a thank you, everyone who leaves a review this month will be entered into a draw to win a FREE lesson!

Thank you for being part of our driving school family.

Best regards,
Your Driving School Team`,
    targetAudience: "active_students",
    color: "from-rose-500 to-pink-500",
  },
];

const DEFAULT_AUTOMATION_RULES = [
  {
    id: "welcome_email",
    name: "Welcome New Students",
    trigger: "new_student",
    action: "send_email",
    enabled: true,
    conditions: {},
  },
  {
    id: "inactive_reminder",
    name: "Inactive Student Reminder",
    trigger: "inactive_days",
    action: "send_email",
    enabled: true,
    conditions: { days: 14 },
  },
  {
    id: "lesson_followup",
    name: "Post-Lesson Follow-up",
    trigger: "lesson_completed",
    action: "send_email",
    enabled: false,
    conditions: {},
  },
  {
    id: "booking_reminder",
    name: "Booking Reminder (24h)",
    trigger: "booking_reminder",
    action: "send_email",
    enabled: true,
    conditions: { hours: 24 },
  },
  {
    id: "birthday_wish",
    name: "Birthday Greetings",
    trigger: "birthday",
    action: "send_email",
    enabled: true,
    conditions: {},
  },
  {
    id: "test_passed",
    name: "Test Passed Congratulations",
    trigger: "test_passed",
    action: "send_email",
    enabled: true,
    conditions: {},
  },
];

const STATUS_COLORS = {
  draft: { bg: "bg-zinc-100", text: "text-zinc-700", icon: FileText },
  scheduled: { bg: "bg-blue-50", text: "text-blue-700", icon: Clock },
  sending: { bg: "bg-amber-50", text: "text-amber-700", icon: RefreshCw },
  sent: { bg: "bg-emerald-50", text: "text-emerald-700", icon: CheckCircle },
  completed: { bg: "bg-purple-50", text: "text-purple-700", icon: Award },
  paused: { bg: "bg-orange-50", text: "text-orange-700", icon: Pause },
  cancelled: { bg: "bg-red-50", text: "text-red-700", icon: XCircle },
};

const StatCard = React.memo(({ icon, label, value, subValue, trend, color, delay = 0 }) => (
  <motion.div
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay }}
    className="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm"
  >
    <div className="flex items-start justify-between mb-3">
      <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${color}`}>{icon}</div>
      {trend !== undefined && (
        <div
          className={`flex items-center gap-1 text-xs font-medium ${
            trend >= 0 ? "text-emerald-600" : "text-red-600"
          }`}
        >
          {trend >= 0 ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
          {Math.abs(trend).toFixed(1)}%
        </div>
      )}
    </div>
    <p className="text-xs font-medium uppercase tracking-wide text-zinc-500 mb-1">{label}</p>
    <p className="text-2xl font-semibold text-zinc-900 tabular-nums">{value}</p>
    {subValue && <p className="text-xs text-zinc-500 mt-1">{subValue}</p>}
  </motion.div>
));

StatCard.displayName = "StatCard";

const StatusBadge = React.memo(({ status }) => {
  const config = STATUS_COLORS[status];
  const Icon = config.icon;

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}
    >
      <Icon className="w-3.5 h-3.5" />
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
});

StatusBadge.displayName = "StatusBadge";

const CampaignFormModal = React.memo(({ isOpen, campaign, template, students, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    campaign_type: "newsletter",
    target_audience: "all_students",
    email_subject: "",
    email_body: "",
    status: "draft",
    discount_code: "",
    discount_percentage: 0,
    tags: [],
  });

  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("");

  React.useEffect(() => {
    if (campaign) {
      setFormData({ ...campaign });
      if (campaign.schedule_date) {
        const date = parseISO(campaign.schedule_date);
        setScheduleDate(format(date, "yyyy-MM-dd"));
        setScheduleTime(format(date, "HH:mm"));
      }
    } else if (template) {
      setFormData({
        name: template.name,
        description: template.description,
        campaign_type: template.type,
        target_audience: template.targetAudience,
        email_subject: template.subject,
        email_body: template.body,
        status: "draft",
      });
    } else {
      setFormData({
        name: "",
        description: "",
        campaign_type: "newsletter",
        target_audience: "all_students",
        email_subject: "",
        email_body: "",
        status: "draft",
        discount_code: "",
        discount_percentage: 0,
        tags: [],
      });
      setScheduleDate("");
      setScheduleTime("");
    }
  }, [campaign, template, isOpen]);

  const getTargetedCount = useMemo(() => {
    const audience = formData.target_audience;
    if (audience === "all_students") return students.length;
    if (audience === "active_students") return students.filter((s) => s.is_active).length;
    if (audience === "inactive_students") return students.filter((s) => !s.is_active).length;
    if (audience === "new_students") {
      const thirtyDaysAgo = subDays(new Date(), 30);
      return students.filter((s) => isAfter(parseISO(s.created_date), thirtyDaysAgo)).length;
    }
    return students.length;
  }, [formData.target_audience, students]);

  const handleSubmit = (e, sendNow = false) => {
    e.preventDefault();

    if (!formData.name || !formData.email_subject || !formData.email_body) {
      toast.error("Please fill in all required fields");
      return;
    }

    let scheduleDateTime;
    if (scheduleDate && scheduleTime) {
      scheduleDateTime = `${scheduleDate}T${scheduleTime}:00`;
    }

    onSave({
      ...formData,
      status: sendNow ? "sent" : scheduleDateTime ? "scheduled" : "draft",
      schedule_date: scheduleDateTime,
      recipients_count: getTargetedCount,
      sent_date: sendNow ? new Date().toISOString() : undefined,
    });
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between p-6 border-b border-zinc-200">
            <h2 className="text-xl font-semibold text-zinc-900">
              {campaign ? "Edit Campaign" : "Create Campaign"}
            </h2>
            <button onClick={onClose} className="p-2 rounded-lg hover:bg-zinc-100 transition">
              <X className="w-5 h-5 text-zinc-500" />
            </button>
          </div>

          <form onSubmit={(e) => handleSubmit(e)} className="p-6 space-y-5 overflow-y-auto max-h-[calc(90vh-180px)]">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-zinc-700 mb-1.5">Campaign Name *</label>
                <input
                  type="text"
                  value={formData.name || ""}
                  onChange={(e) => setFormData((p) => ({ ...p, name: e.target.value }))}
                  className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                  placeholder="e.g., Summer Sale Campaign"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-700 mb-1.5">Campaign Type</label>
                <select
                  value={formData.campaign_type || "newsletter"}
                  onChange={(e) => setFormData((p) => ({ ...p, campaign_type: e.target.value }))}
                  className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="newsletter">Newsletter</option>
                  <option value="package_promotion">Package Promotion</option>
                  <option value="off_peak_slots">Off-Peak Slots</option>
                  <option value="reactivation">Win-Back / Reactivation</option>
                  <option value="referral">Referral Program</option>
                  <option value="seasonal">Seasonal Campaign</option>
                  <option value="milestone">Milestone Celebration</option>
                  <option value="feedback_request">Feedback Request</option>
                  <option value="announcement">Announcement</option>
                  <option value="custom">Custom</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-700 mb-1.5">Description</label>
              <input
                type="text"
                value={formData.description || ""}
                onChange={(e) => setFormData((p) => ({ ...p, description: e.target.value }))}
                className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Brief description of the campaign..."
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-zinc-700 mb-1.5">Target Audience</label>
                <select
                  value={formData.target_audience || "all_students"}
                  onChange={(e) => setFormData((p) => ({ ...p, target_audience: e.target.value }))}
                  className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all_students">All Students</option>
                  <option value="active_students">Active Students</option>
                  <option value="inactive_students">Inactive Students</option>
                  <option value="new_students">New Students (Last 30 Days)</option>
                  <option value="completing_soon">Completing Soon</option>
                  <option value="no_bookings">No Recent Bookings</option>
                  <option value="high_value">High Value Customers</option>
                </select>
              </div>

              <div className="flex items-end">
                <div className="w-full p-3 rounded-xl bg-[#e8f4fa] border border-[#d4eaf5]">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-[#3b82c4]" />
                    <span className="text-sm font-medium text-[#3b82c4]">
                      {getTargetedCount} recipients
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-700 mb-1.5">Email Subject *</label>
              <input
                type="text"
                value={formData.email_subject || ""}
                onChange={(e) => setFormData((p) => ({ ...p, email_subject: e.target.value }))}
                className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                placeholder="Your attention-grabbing subject line..."
                required
                />
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-700 mb-1.5">Email Body *</label>
              <textarea
                value={formData.email_body || ""}
                onChange={(e) => setFormData((p) => ({ ...p, email_body: e.target.value }))}
                rows={8}
                className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-[#a9d5ed] resize-none font-mono text-sm"
                placeholder="Write your email content here... Use {student_name} for personalization."
                required
                />
              <p className="text-xs text-zinc-500 mt-1">
                Available variables: {"{student_name}"}, {"{student_email}"}, {"{discount_code}"}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-zinc-700 mb-1.5">Discount Code</label>
                <input
                  type="text"
                  value={formData.discount_code || ""}
                  onChange={(e) => setFormData((p) => ({ ...p, discount_code: e.target.value.toUpperCase() }))}
                  className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                  placeholder="e.g., SAVE15"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-700 mb-1.5">Discount %</label>
                <input
                  type="number"
                  value={formData.discount_percentage || ""}
                  onChange={(e) => setFormData((p) => ({ ...p, discount_percentage: Number(e.target.value) }))}
                  className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="15"
                  min="0"
                  max="100"
                />
              </div>
            </div>

            <div className="p-4 rounded-xl bg-zinc-50 border border-zinc-100">
              <h4 className="font-medium text-zinc-900 mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#3b82c4]" />
                Schedule (Optional)
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-zinc-500 mb-1">Date</label>
                  <input
                    type="date"
                    value={scheduleDate}
                    onChange={(e) => setScheduleDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-zinc-500 mb-1">Time</label>
                  <input
                    type="time"
                    value={scheduleTime}
                    onChange={(e) => setScheduleTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                  />
                </div>
              </div>
            </div>
          </form>

          <div className="flex items-center justify-between gap-3 p-6 border-t border-zinc-200">
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl border border-zinc-200 font-medium text-zinc-700 hover:bg-zinc-50 transition"
            >
              Cancel
            </button>
            <div className="flex items-center gap-3">
              <button
                onClick={(e) => handleSubmit(e, false)}
                className="px-6 py-2.5 rounded-xl border border-zinc-200 font-medium text-zinc-700 hover:bg-zinc-50 transition"
              >
                Save as Draft
              </button>
              <button
                onClick={(e) => handleSubmit(e, true)}
                className="px-6 py-2.5 rounded-xl bg-[#3b82c4] text-white font-medium hover:bg-[#2563a3] transition flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                Send Now
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
});

CampaignFormModal.displayName = "CampaignFormModal";

const CampaignCard = React.memo(({ campaign, onEdit, onSend, onPause, onDelete, index }) => {
  const [showMenu, setShowMenu] = useState(false);

  const openRate = campaign.recipients_count > 0 ? ((campaign.opened_count || 0) / campaign.recipients_count) * 100 : 0;
  const clickRate = campaign.opened_count && campaign.opened_count > 0 ? ((campaign.clicked_count || 0) / campaign.opened_count) * 100 : 0;
  const conversionRate = campaign.clicked_count && campaign.clicked_count > 0 ? ((campaign.converted_count || 0) / campaign.clicked_count) * 100 : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm hover:shadow-md transition-all"
    >
      <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4 mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-lg font-semibold text-zinc-900">{campaign.name}</h3>
            <StatusBadge status={campaign.status} />
          </div>
          {campaign.description && (
            <p className="text-sm text-zinc-500 mb-3">{campaign.description}</p>
          )}
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg bg-zinc-100 text-zinc-600 text-xs font-medium capitalize">
              {campaign.campaign_type.replace(/_/g, " ")}
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-zinc-100 text-zinc-600 text-xs font-medium capitalize">
              {campaign.target_audience.replace(/_/g, " ")}
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#e8f4fa] text-[#3b82c4] text-xs font-medium flex items-center gap-1">
              <Users className="w-3 h-3" />
              {campaign.recipients_count} recipients
            </span>
            {campaign.schedule_date && campaign.status === "scheduled" && (
              <span className="px-2.5 py-1 rounded-lg bg-[#e8f4fa] text-[#3b82c4] text-xs font-medium flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {format(parseISO(campaign.schedule_date), "MMM d, h:mm a")}
              </span>
            )}
            {campaign.sent_date && (
              <span className="px-2.5 py-1 rounded-lg bg-[#eefbe7] text-[#5cb83a] text-xs font-medium flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                Sent {format(parseISO(campaign.sent_date), "MMM d")}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {campaign.status === "draft" && (
            <button
              onClick={onSend}
              className="p-2 rounded-lg border border-[#d4f4c3] hover:bg-[#eefbe7] transition"
              title="Send Now"
            >
              <Play className="w-4 h-4 text-[#5cb83a]" />
            </button>
          )}
          {campaign.status === "scheduled" && (
            <button
              onClick={onPause}
              className="p-2 rounded-lg border border-[#f9f3c8] hover:bg-[#fdfbe8] transition"
              title="Pause"
            >
              <Pause className="w-4 h-4 text-[#e7d356]" />
            </button>
          )}
          <button
            onClick={onEdit}
            className="p-2 rounded-lg border border-zinc-200 hover:bg-zinc-50 transition"
            title="Edit"
          >
            <Edit className="w-4 h-4 text-zinc-600" />
          </button>
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 rounded-lg border border-zinc-200 hover:bg-zinc-50 transition"
            >
              <MoreVertical className="w-4 h-4 text-zinc-600" />
            </button>
            <AnimatePresence>
              {showMenu && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="absolute right-0 top-full mt-1 w-40 bg-white rounded-xl shadow-lg border border-zinc-200 py-1 z-10"
                >
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(campaign.email_body);
                      toast.success("Email content copied!");
                      setShowMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left text-sm text-zinc-700 hover:bg-zinc-50 flex items-center gap-2"
                  >
                    <Copy className="w-4 h-4" />
                    Copy Content
                  </button>
                  <button
                    onClick={() => {
                      onDelete();
                      setShowMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {(campaign.status === "sent" || campaign.status === "completed") && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4 border-t border-zinc-100">
          <div className="rounded-xl bg-zinc-50 p-3 text-center">
            <p className="text-lg font-bold text-zinc-900 tabular-nums">{openRate.toFixed(1)}%</p>
            <p className="text-xs text-zinc-500">Open Rate</p>
          </div>
          <div className="rounded-xl bg-zinc-50 p-3 text-center">
            <p className="text-lg font-bold text-zinc-900 tabular-nums">{clickRate.toFixed(1)}%</p>
            <p className="text-xs text-zinc-500">Click Rate</p>
          </div>
          <div className="rounded-xl bg-zinc-50 p-3 text-center">
            <p className="text-lg font-bold text-zinc-900 tabular-nums">{campaign.converted_count || 0}</p>
            <p className="text-xs text-zinc-500">Conversions</p>
          </div>
          <div className="rounded-xl bg-zinc-50 p-3 text-center">
            <p className="text-lg font-bold text-[#5cb83a] tabular-nums">
              €{(campaign.revenue_generated || 0).toFixed(0)}
            </p>
            <p className="text-xs text-zinc-500">Revenue</p>
          </div>
        </div>
      )}
    </motion.div>
  );
});

CampaignCard.displayName = "CampaignCard";

const TemplateCard = React.memo(({ template, onClick, index }) => (
  <motion.button
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.05 }}
    onClick={onClick}
    className="rounded-2xl border border-zinc-200 bg-white p-5 text-left hover:shadow-md hover:border-[#d4eaf5] transition-all group"
  >
    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${template.color} flex items-center justify-center mb-4 shadow-sm`}>
      <template.icon className="w-6 h-6 text-white" />
    </div>
    <h4 className="font-semibold text-zinc-900 mb-1 group-hover:text-[#3b82c4] transition-colors">
      {template.name}
    </h4>
    <p className="text-sm text-zinc-500">{template.description}</p>
  </motion.button>
));

TemplateCard.displayName = "TemplateCard";

const AutomationRuleCard = React.memo(({ rule, onToggle, index }) => {
  const triggerLabels = {
    new_student: "When a new student registers",
    inactive_days: "When a student is inactive",
    lesson_completed: "After a lesson is completed",
    payment_received: "When payment is received",
    birthday: "On student's birthday",
    booking_reminder: "Before a booking",
    test_passed: "When student passes test",
  };

  const actionLabels = {
    send_email: "Send email",
    send_sms: "Send SMS",
    create_task: "Create task",
    apply_discount: "Apply discount",
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -12 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`rounded-xl border p-4 transition-all ${
        rule.enabled ? "border-[#d4eaf5] bg-[#e8f4fa]/50" : "border-zinc-200 bg-white"
      }`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-lg flex items-center justify-center ${
              rule.enabled ? "bg-[#d4eaf5]" : "bg-zinc-100"
            }`}
          >
            <Zap className={`w-5 h-5 ${rule.enabled ? "text-[#3b82c4]" : "text-zinc-400"}`} />
          </div>
          <div>
            <h4 className="font-medium text-zinc-900">{rule.name}</h4>
            <p className="text-xs text-zinc-500">
              {triggerLabels[rule.trigger]} → {actionLabels[rule.action]}
            </p>
          </div>
        </div>
        <button
          onClick={() => onToggle(!rule.enabled)}
          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
            rule.enabled ? "bg-[#3b82c4]" : "bg-zinc-300"
          }`}
        >
          <span
            className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform ${
              rule.enabled ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      </div>
    </motion.div>
  );
});

AutomationRuleCard.displayName = "AutomationRuleCard";

const AISuggestionCard = React.memo(({ suggestion, onUse, index }) => (
  <motion.div
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.1 }}
    className="rounded-2xl border border-zinc-200 bg-white p-5 shadow-sm"
  >
    <div className="flex items-start gap-4 mb-4">
      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6c376f] to-[#e44138] flex items-center justify-center flex-shrink-0">
        <Sparkles className="w-5 h-5 text-white" />
      </div>
      <div className="flex-1">
        <h4 className="font-semibold text-zinc-900 mb-1">{suggestion.title}</h4>
        <p className="text-sm text-zinc-500">{suggestion.description}</p>
      </div>
      <div className="text-right">
        <div className="flex items-center gap-1 text-sm font-medium text-[#5cb83a]">
          <span>{suggestion.confidence}%</span>
          <span className="text-zinc-400">confidence</span>
        </div>
      </div>
    </div>

    <div className="grid grid-cols-3 gap-3 mb-4">
      <div className="rounded-lg bg-zinc-50 p-2 text-center">
        <p className="text-sm font-semibold text-zinc-900 tabular-nums">{suggestion.potentialReach}</p>
        <p className="text-xs text-zinc-500">Reach</p>
      </div>
      <div className="rounded-lg bg-zinc-50 p-2 text-center">
        <p className="text-sm font-semibold text-[#5cb83a] tabular-nums">
          €{suggestion.estimatedRevenue}
        </p>
        <p className="text-xs text-zinc-500">Est. Revenue</p>
      </div>
      <div className="rounded-lg bg-zinc-50 p-2 text-center">
        <p className="text-sm font-semibold text-zinc-900 capitalize">
          {suggestion.targetAudience.replace(/_/g, " ")}
        </p>
        <p className="text-xs text-zinc-500">Audience</p>
      </div>
    </div>

    <div className="p-3 rounded-lg bg-[#f3e8f4] border border-[#e5d0e6] mb-4">
      <p className="text-xs text-[#5a2d5d]">
        <strong>Why this works:</strong> {suggestion.reasoning}
      </p>
    </div>

    <button
      onClick={onUse}
      className="w-full py-2.5 rounded-xl bg-[#3b82c4] text-white font-medium hover:bg-[#2563a3] transition flex items-center justify-center gap-2"
    >
      <Zap className="w-4 h-4" />
      Use This Suggestion
    </button>
  </motion.div>
));

AISuggestionCard.displayName = "AISuggestionCard";

export default function Marketing() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("campaigns");
  const [showCampaignForm, setShowCampaignForm] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [automationRules, setAutomationRules] = useState(DEFAULT_AUTOMATION_RULES);

  const { data: campaigns = [], isLoading: loadingCampaigns } = useQuery({
    queryKey: ["campaigns"],
    queryFn: () => base44.entities.Campaign.list("-created_date"),
    staleTime: 60000,
  });

  const { data: students = [] } = useQuery({
    queryKey: ["students"],
    queryFn: () => base44.entities.Student.list(),
    staleTime: 300000,
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ["bookings"],
    queryFn: () => base44.entities.Booking.list("-start_time"),
    staleTime: 60000,
  });

  const createCampaignMutation = useMutation({
    mutationFn: (data) => base44.entities.Campaign.create(data),
    onSuccess: async (newCampaign) => {
      queryClient.invalidateQueries({ queryKey: ["campaigns"] });

      if (newCampaign.status === "sent") {
        await sendCampaignEmails(newCampaign);
      }

      toast.success("Campaign created successfully");
      setShowCampaignForm(false);
      setSelectedTemplate(null);
    },
    onError: () => {
      toast.error("Failed to create campaign");
    },
  });

  const updateCampaignMutation = useMutation({
    mutationFn: ({ id, data }) =>
      base44.entities.Campaign.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["campaigns"] });
      toast.success("Campaign updated");
      setShowCampaignForm(false);
      setEditingCampaign(null);
    },
    onError: () => {
      toast.error("Failed to update campaign");
    },
  });

  const deleteCampaignMutation = useMutation({
    mutationFn: (id) => base44.entities.Campaign.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["campaigns"] });
      toast.success("Campaign deleted");
    },
    onError: () => {
      toast.error("Failed to delete campaign");
    },
  });

  const getTargetedStudents = useCallback(
    (campaign) => {
      const thirtyDaysAgo = subDays(new Date(), 30);
      const fourteenDaysAgo = subDays(new Date(), 14);

      switch (campaign.target_audience) {
        case "all_students":
          return students;
        case "active_students":
          return students.filter((s) => s.is_active);
        case "inactive_students":
          return students.filter((s) => !s.is_active);
        case "new_students":
          return students.filter((s) => isAfter(parseISO(s.created_date), thirtyDaysAgo));
        case "no_bookings":
          return students.filter((s) => {
            const studentBookings = bookings.filter((b) => b.student_id === s.id);
            if (studentBookings.length === 0) return true;
            const lastBooking = studentBookings.sort(
              (a, b) => new Date(b.start_time).getTime() - new Date(a.start_time).getTime()
            )[0];
            return isBefore(parseISO(lastBooking.start_time), fourteenDaysAgo);
          });
        default:
          return students;
      }
    },
    [students, bookings]
  );

  const sendCampaignEmails = useCallback(
    async (campaign) => {
      const targetedStudents = getTargetedStudents(campaign);
      let successCount = 0;

      for (const student of targetedStudents) {
        const emailBody = campaign.email_body
          .replace(/{student_name}/g, student.full_name)
          .replace(/{student_email}/g, student.email)
          .replace(/{discount_code}/g, campaign.discount_code || "");

        try {
          await base44.integrations.Core.SendEmail({
            to: student.email,
            subject: campaign.email_subject,
            body: emailBody,
          });
          successCount++;
        } catch (error) {
          console.error(`Failed to send email to ${student.email}`);
        }
      }

      toast.success(`Campaign sent to ${successCount} of ${targetedStudents.length} students`);
    },
    [getTargetedStudents]
  );

  const handleSendCampaign = useCallback(
    async (campaign) => {
      await updateCampaignMutation.mutateAsync({
        id: campaign.id,
        data: {
          status: "sent",
          sent_date: new Date().toISOString(),
        },
      });
      await sendCampaignEmails(campaign);
    },
    [updateCampaignMutation, sendCampaignEmails]
  );

  const handlePauseCampaign = useCallback(
    (campaign) => {
      updateCampaignMutation.mutate({
        id: campaign.id,
        data: { status: "paused" },
      });
    },
    [updateCampaignMutation]
  );

  const handleCampaignSave = useCallback(
    (campaignData) => {
      const dataWithSchool = {
        ...campaignData,
        school_id: students[0]?.school_id || "default-school",
      };

      if (editingCampaign) {
        updateCampaignMutation.mutate({ id: editingCampaign.id, data: dataWithSchool });
      } else {
        createCampaignMutation.mutate(dataWithSchool);
      }
    },
    [editingCampaign, students, updateCampaignMutation, createCampaignMutation]
  );

  const handleDeleteCampaign = useCallback(
    (id) => {
      if (window.confirm("Are you sure you want to delete this campaign?")) {
        deleteCampaignMutation.mutate(id);
      }
    },
    [deleteCampaignMutation]
  );

  const handleToggleAutomation = useCallback((ruleId, enabled) => {
    setAutomationRules((prev) =>
      prev.map((r) => (r.id === ruleId ? { ...r, enabled } : r))
    );
    toast.success(`Automation ${enabled ? "enabled" : "disabled"}`);
  }, []);

  const filteredCampaigns = useMemo(() => {
    return campaigns.filter((c) => {
      const matchesStatus = filterStatus === "all" || c.status === filterStatus;
      const matchesSearch =
        c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.description?.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }, [campaigns, filterStatus, searchTerm]);

  const aiSuggestions = useMemo(() => {
    const suggestions = [];

    const inactiveStudents = students.filter((s) => !s.is_active);
    if (inactiveStudents.length > 5) {
      suggestions.push({
        id: "win_back",
        title: "Win-Back Campaign",
        description: `${inactiveStudents.length} students haven't booked recently. Re-engage them with a special offer.`,
        type: "reactivation",
        targetAudience: "inactive_students",
        potentialReach: inactiveStudents.length,
        estimatedRevenue: inactiveStudents.length * 75,
        confidence: 85,
        subject: "We Miss You! 🚗 Come Back & Save 20%",
        body: "Hi {student_name},\n\nWe noticed it's been a while since your last lesson. Life gets busy, we understand!\n\nTo help you get back on track, here's 20% off your next booking. Use code WELCOME20.\n\nWe'd love to see you back behind the wheel!\n\nBest regards,\nYour Driving School Team",
        reasoning: "Inactive students represent potential lost revenue. A discount offer can re-engage them effectively.",
      });
    }

    const newStudents = students.filter((s) =>
      isAfter(parseISO(s.created_date), subDays(new Date(), 30))
    );
    if (newStudents.length > 3) {
      suggestions.push({
        id: "new_student_package",
        title: "New Student Package Promotion",
        description: `${newStudents.length} new students joined recently. Upsell them to a package deal.`,
        type: "package_promotion",
        targetAudience: "new_students",
        potentialReach: newStudents.length,
        estimatedRevenue: newStudents.length * 200,
        confidence: 78,
        subject: "🎁 Special Offer for New Students - Save 15%!",
        body: "Hi {student_name},\n\nWelcome to our driving school! As a new student, we have a special offer for you.\n\nGet 15% off any lesson package when you book within the next 7 days. Use code NEWDRIVER15.\n\nPackages give you better value and help you progress faster!\n\nBest regards,\nYour Driving School Team",
        reasoning: "New students who purchase packages have higher completion rates and lifetime value.",
      });
    }

    if (students.filter((s) => s.is_active).length > 10) {
      suggestions.push({
        id: "referral_program",
        title: "Referral Campaign",
        description: "Encourage active students to refer friends and family.",
        type: "referral",
        targetAudience: "active_students",
        potentialReach: students.filter((s) => s.is_active).length,
        estimatedRevenue: students.filter((s) => s.is_active).length * 50,
        confidence: 72,
        subject: "🎉 Earn Free Lessons - Refer a Friend!",
        body: "Hi {student_name},\n\nLove your driving lessons? Share the experience!\n\nFor every friend you refer who books:\n• You get a FREE lesson\n• They get 10% off\n\nThere's no limit to how many free lessons you can earn!\n\nBest regards,\nYour Driving School Team",
        reasoning: "Referral programs have the highest ROI in education services, with referred students showing better retention.",
      });
    }

    return suggestions;
  }, [students]);

  const stats = useMemo(() => {
    const totalSent = campaigns.filter((c) => c.status === "sent" || c.status === "completed").length;
    const totalRevenue = campaigns.reduce((sum, c) => sum + (c.revenue_generated || 0), 0);
    const totalOpened = campaigns.reduce((sum, c) => sum + (c.opened_count || 0), 0);
    const totalRecipients = campaigns.reduce((sum, c) => sum + (c.recipients_count || 0), 0);
    const avgOpenRate = totalRecipients > 0 ? (totalOpened / totalRecipients) * 100 : 0;

    return {
      total: campaigns.length,
      sent: totalSent,
      revenue: totalRevenue,
      avgOpenRate: avgOpenRate.toFixed(1),
    };
  }, [campaigns]);

  if (loadingCampaigns) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#3b82c4] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-zinc-600 font-medium">Loading marketing hub...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8 space-y-6 pb-24 md:pb-8">
      <motion.header
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col lg:flex-row lg:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed] bg-clip-text text-transparent">Marketing Hub</h1>
          <p className="text-zinc-600 mt-1">AI-powered campaigns and automation</p>
        </div>
        <button
          onClick={() => {
            setEditingCampaign(null);
            setSelectedTemplate(null);
            setShowCampaignForm(true);
          }}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#3b82c4] text-white font-semibold hover:bg-[#2563a3] shadow-sm transition"
        >
          <Plus className="w-5 h-5" />
          Create Campaign
        </button>
      </motion.header>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          icon={<Mail className="w-5 h-5 text-[#3b82c4]" />}
          label="Total Campaigns"
          value={stats.total}
          color="bg-[#e8f4fa]"
          delay={0.05}
        />
        <StatCard
          icon={<Send className="w-5 h-5 text-[#5cb83a]" />}
          label="Campaigns Sent"
          value={stats.sent}
          color="bg-[#eefbe7]"
          delay={0.1}
        />
        <StatCard
          icon={<Eye className="w-5 h-5 text-[#6c376f]" />}
          label="Avg Open Rate"
          value={`${stats.avgOpenRate}%`}
          color="bg-[#f3e8f4]"
          delay={0.15}
        />
        <StatCard
          icon={<TrendingUp className="w-5 h-5 text-[#e7d356]" />}
          label="Revenue Generated"
          value={`€${stats.revenue.toFixed(0)}`}
          color="bg-[#fdfbe8]"
          delay={0.2}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="rounded-2xl border border-zinc-200 bg-white p-2 shadow-sm"
      >
        <div className="flex gap-1 overflow-x-auto">
          {["campaigns", "templates", "ai_suggestions", "automation", "analytics"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-3 px-4 rounded-xl font-medium capitalize whitespace-nowrap transition ${
                activeTab === tab ? "bg-[#3b82c4] text-white" : "text-zinc-600 hover:bg-zinc-100"
              }`}
            >
              {tab.replace(/_/g, " ")}
            </button>
          ))}
        </div>
      </motion.div>

      <AnimatePresence mode="wait">
        {activeTab === "campaigns" && (
          <motion.div
            key="campaigns"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="space-y-6"
          >
            <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  <input
                    type="text"
                    placeholder="Search campaigns..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                  />
                </div>

                <div className="flex flex-wrap gap-2">
                  {["all", "draft", "scheduled", "sent", "completed"].map((status) => (
                    <button
                      key={status}
                      onClick={() => setFilterStatus(status)}
                      className={`px-4 py-2 rounded-xl text-sm font-medium capitalize transition ${
                        filterStatus === status
                          ? "bg-[#3b82c4] text-white"
                          : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200"
                      }`}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {filteredCampaigns.length === 0 ? (
              <div className="rounded-2xl border border-zinc-200 bg-white p-12 text-center">
                <Mail className="w-16 h-16 text-zinc-300 mx-auto mb-4" />
                <p className="text-zinc-600 mb-4">
                  {campaigns.length === 0
                    ? "No campaigns yet. Create your first campaign!"
                    : "No campaigns match your search criteria."}
                </p>
                {campaigns.length === 0 && (
                  <button
                    onClick={() => setShowCampaignForm(true)}
                    className="px-6 py-3 rounded-xl bg-[#3b82c4] text-white font-semibold hover:bg-[#2563a3] transition"
                  >
                    Create Campaign
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredCampaigns.map((campaign, index) => (
                  <CampaignCard
                    key={campaign.id}
                    campaign={campaign}
                    onEdit={() => {
                      setEditingCampaign(campaign);
                      setShowCampaignForm(true);
                    }}
                    onSend={() => handleSendCampaign(campaign)}
                    onPause={() => handlePauseCampaign(campaign)}
                    onDelete={() => handleDeleteCampaign(campaign.id)}
                    index={index}
                  />
                ))}
              </div>
            )}
          </motion.div>
        )}

        {activeTab === "templates" && (
          <motion.div
            key="templates"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
          >
            <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-zinc-900 mb-4">Quick Campaign Templates</h3>
              <p className="text-zinc-500 mb-6">
                Start with a pre-built template and customize it for your needs.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {CAMPAIGN_TEMPLATES.map((template, index) => (
                  <TemplateCard
                    key={template.id}
                    template={template}
                    onClick={() => {
                      setSelectedTemplate(template);
                      setEditingCampaign(null);
                      setShowCampaignForm(true);
                    }}
                    index={index}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "ai_suggestions" && (
          <motion.div
            key="ai_suggestions"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
          >
            <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm mb-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6c376f] to-[#e44138] flex items-center justify-center">
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-zinc-900">AI-Powered Suggestions</h3>
                  <p className="text-sm text-zinc-500">
                    Based on your student data and booking patterns
                  </p>
                </div>
              </div>
            </div>

            {aiSuggestions.length === 0 ? (
              <div className="rounded-2xl border border-zinc-200 bg-white p-12 text-center">
                <Lightbulb className="w-16 h-16 text-zinc-300 mx-auto mb-4" />
                <p className="text-zinc-600">
                  No suggestions available yet. Add more students to get personalized campaign ideas.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {aiSuggestions.map((suggestion, index) => (
                  <AISuggestionCard
                    key={suggestion.id}
                    suggestion={suggestion}
                    onUse={() => {
                      setSelectedTemplate({
                        id: suggestion.id,
                        name: suggestion.title,
                        description: suggestion.description,
                        type: suggestion.type,
                        icon: Sparkles,
                        subject: suggestion.subject,
                        body: suggestion.body,
                        targetAudience: suggestion.targetAudience,
                        color: "from-purple-500 to-pink-500",
                      });
                      setShowCampaignForm(true);
                    }}
                    index={index}
                  />
                ))}
              </div>
            )}
          </motion.div>
        )}

        {activeTab === "automation" && (
          <motion.div
            key="automation"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
          >
            <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold text-zinc-900">Automation Rules</h3>
                  <p className="text-sm text-zinc-500">
                    Set up automated campaigns triggered by student actions
                  </p>
                </div>
                <button className="px-4 py-2 rounded-xl border border-zinc-200 font-medium text-zinc-700 hover:bg-zinc-50 transition flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Add Rule
                </button>
              </div>

              <div className="space-y-3">
                {automationRules.map((rule, index) => (
                  <AutomationRuleCard
                    key={rule.id}
                    rule={rule}
                    onToggle={(enabled) => handleToggleAutomation(rule.id, enabled)}
                    index={index}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "analytics" && (
          <motion.div
            key="analytics"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="space-y-6"
          >
            <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-zinc-900 mb-6">Campaign Performance</h3>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="rounded-xl bg-zinc-50 p-4 text-center">
                  <p className="text-3xl font-bold text-zinc-900 tabular-nums">
                    {campaigns.reduce((sum, c) => sum + (c.recipients_count || 0), 0)}
                  </p>
                  <p className="text-sm text-zinc-500">Total Recipients</p>
                </div>
                <div className="rounded-xl bg-zinc-50 p-4 text-center">
                  <p className="text-3xl font-bold text-zinc-900 tabular-nums">
                    {campaigns.reduce((sum, c) => sum + (c.opened_count || 0), 0)}
                  </p>
                  <p className="text-sm text-zinc-500">Total Opens</p>
                </div>
                <div className="rounded-xl bg-zinc-50 p-4 text-center">
                  <p className="text-3xl font-bold text-zinc-900 tabular-nums">
                    {campaigns.reduce((sum, c) => sum + (c.clicked_count || 0), 0)}
                  </p>
                  <p className="text-sm text-zinc-500">Total Clicks</p>
                </div>
                <div className="rounded-xl bg-zinc-50 p-4 text-center">
                  <p className="text-3xl font-bold text-[#5cb83a] tabular-nums">
                    €{campaigns.reduce((sum, c) => sum + (c.revenue_generated || 0), 0).toFixed(0)}
                  </p>
                  <p className="text-sm text-zinc-500">Total Revenue</p>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-zinc-900 mb-4">Top Performing Campaigns</h3>

              <div className="space-y-3">
                {campaigns
                  .filter((c) => c.status === "sent" || c.status === "completed")
                  .sort((a, b) => (b.revenue_generated || 0) - (a.revenue_generated || 0))
                  .slice(0, 5)
                  .map((campaign, index) => (
                    <div
                      key={campaign.id}
                      className="flex items-center justify-between p-4 rounded-xl bg-zinc-50"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-lg bg-[#e8f4fa] flex items-center justify-center text-[#3b82c4] font-bold text-sm">
                          {index + 1}
                        </span>
                        <div>
                          <p className="font-medium text-zinc-900">{campaign.name}</p>
                          <p className="text-xs text-zinc-500">
                            {campaign.recipients_count} recipients
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-[#5cb83a]">
                          €{(campaign.revenue_generated || 0).toFixed(0)}
                        </p>
                        <p className="text-xs text-zinc-500">revenue</p>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <CampaignFormModal
        isOpen={showCampaignForm}
        campaign={editingCampaign}
        template={selectedTemplate}
        students={students}
        onClose={() => {
          setShowCampaignForm(false);
          setEditingCampaign(null);
          setSelectedTemplate(null);
        }}
        onSave={handleCampaignSave}
      />
    </div>
  );
}