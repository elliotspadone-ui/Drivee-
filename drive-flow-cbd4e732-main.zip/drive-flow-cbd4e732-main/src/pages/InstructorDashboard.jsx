import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Calendar, 
  DollarSign, 
  Car, 
  AlertCircle, 
  MessageSquare, 
  Clock, 
  TrendingUp, 
  Users, 
  CheckCircle, 
  Navigation, 
  Phone,
  MapPin, 
  FileText, 
  Award,
  Bell,
  Target,
  Zap,
  BookOpen,
  Star,
  TrendingDown,
  Activity,
  ArrowRight,
  Plus,
  Edit,
  XCircle,
  PlayCircle,
  PauseCircle,
  Coffee,
  Fuel,
  AlertTriangle,
  CheckCircle2,
  Info,
  Mail,
  Video,
  Sparkles,
  Trophy,
  ThumbsUp,
  MessageCircle,
  Heart,
  BarChart3,
  PieChart,
  Download,
  Share2,
  Settings,
  RefreshCw,
  Loader2,
  ChevronRight,
  ExternalLink,
  MapPinned,
  Route,
  Timer,
  Gauge
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format, isToday, isFuture, isPast, startOfWeek, endOfWeek, differenceInMinutes, addMinutes, isWithinInterval, startOfDay, endOfDay, subDays, formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import RevenueChart from "@/components/finance/RevenueChart";
import { ScrollFadeIn, StaggerFadeIn, ScrollProgress } from "@/components/animations/FadeSections";
import { KPIComparisonCard, AnimatedCounter } from "@/components/charts/KPIComparison";
import { celebrate } from "@/components/common/ConfettiCelebration";
import confetti from 'canvas-confetti';
import QuickLessonActions from "@/components/instructor/QuickLessonActions";
import AvailabilityManager from "@/components/instructor/AvailabilityManager";
import EnhancedLessonNotes from "@/components/instructor/EnhancedLessonNotes";
import { useInstructorAuth } from "@/components/instructor/useInstructorAuth";
import InstructorOnboarding from "@/components/instructor/InstructorOnboarding";
import { logger } from "@/components/utils/config";
import QueryErrorBoundary from "@/components/common/QueryErrorBoundary";
import SkeletonLoader from "@/components/common/SkeletonLoader";

export default function InstructorDashboard() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const auth = useInstructorAuth();
  const effectiveUser = auth.data?.effectiveUser || null;
  const effectiveInstructor = auth.data?.effectiveInstructor || null;
  const authStatus = auth.data?.status || "loading";
  const [activeLesson, setActiveLesson] = useState(null);
  const [showQuickNote, setShowQuickNote] = useState(false);
  const [quickNote, setQuickNote] = useState("");
  const [selectedBookingForNote, setSelectedBookingForNote] = useState(null);
  const [lessonTimer, setLessonTimer] = useState(0);
  const [timerInterval, setTimerInterval] = useState(null);
  const [showAvailability, setShowAvailability] = useState(false);
  const [showEnhancedNotes, setShowEnhancedNotes] = useState(false);

  const { data: bookings = [], isLoading: loadingBookings, error: bookingsError, refetch: refetchBookings } = useQuery({
    queryKey: ['instructorDashboardBookings', effectiveInstructor?.id, effectiveInstructor?.school_id],
    queryFn: async () => {
      if (!effectiveInstructor) return [];
      return await base44.entities.Booking.filter({ 
        instructor_id: effectiveInstructor.id,
        school_id: effectiveInstructor.school_id 
      }, '-start_datetime', 200);
    },
    enabled: !!effectiveInstructor,
    refetchInterval: 60000,
    staleTime: 30000,
  });

  const { data: students = [] } = useQuery({
    queryKey: ['instructorStudents', effectiveInstructor?.school_id],
    queryFn: () => effectiveInstructor?.school_id ? base44.entities.Student.filter({ school_id: effectiveInstructor.school_id }, '-created_date', 100) : [],
    enabled: !!effectiveInstructor,
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ['instructorVehicles', effectiveInstructor?.school_id],
    queryFn: () => effectiveInstructor?.school_id ? base44.entities.Vehicle.filter({ school_id: effectiveInstructor.school_id }, '-created_date', 50) : [],
    enabled: !!effectiveInstructor,
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['instructorMessages', effectiveInstructor?.id],
    queryFn: async () => {
      if (!effectiveInstructor) return [];
      try {
        return await base44.entities.Message.filter({ 
          recipient_id: effectiveInstructor.id 
        }, '-created_date', 50);
      } catch {
        return [];
      }
    },
    enabled: !!effectiveInstructor,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['instructorReviews', effectiveInstructor?.id, effectiveInstructor?.school_id],
    queryFn: async () => {
      if (!effectiveInstructor) return [];
      try {
        return await base44.entities.Review.filter({ 
          instructor_id: effectiveInstructor.id,
          school_id: effectiveInstructor.school_id 
        }, '-created_date', 100);
      } catch {
        return [];
      }
    },
    enabled: !!effectiveInstructor,
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ['instructorInvoices', effectiveInstructor?.id, effectiveInstructor?.school_id],
    queryFn: async () => {
      if (!effectiveInstructor) return [];
      try {
        return await base44.entities.Invoice.filter({ 
          instructor_id: effectiveInstructor.id,
          school_id: effectiveInstructor.school_id 
        }, '-issue_date', 100);
      } catch {
        return [];
      }
    },
    enabled: !!effectiveInstructor,
  });

  const startLessonMutation = useMutation({
    mutationFn: async (bookingId) => {
      return await base44.entities.Booking.update(bookingId, {
        status: "in_progress",
        actual_start_time: new Date().toISOString()
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['instructorDashboardBookings'] });
      setActiveLesson(data);
      toast.success("Lesson started successfully");
      celebrate("Lesson Started! 🚗", "success");
      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
    },
    onError: () => {
      toast.error("Failed to start lesson");
    }
  });

  const completeLessonMutation = useMutation({
    mutationFn: async ({ bookingId, notes }) => {
      return await base44.entities.Booking.update(bookingId, {
        status: "completed",
        actual_end_time: new Date().toISOString(),
        instructor_notes: notes,
        hours_credited: differenceInMinutes(new Date(), new Date(activeLesson.actual_start_time || activeLesson.start_datetime)) / 60
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorDashboardBookings'] });
      setActiveLesson(null);
      setQuickNote("");
      if (timerInterval) {
        clearInterval(timerInterval);
        setTimerInterval(null);
      }
      setLessonTimer(0);
      toast.success("Lesson completed successfully");
      celebrate("Lesson Completed! 🎉", "achievement");
      confetti({ particleCount: 150, spread: 80, origin: { y: 0.6 }, colors: ['#3b82c4', '#81da5a', '#e7d356'] });
    },
    onError: () => {
      toast.error("Failed to complete lesson");
    }
  });

  const addQuickNoteMutation = useMutation({
    mutationFn: async ({ bookingId, note }) => {
      const booking = bookings.find(b => b.id === bookingId);
      const existingNotes = booking.instructor_notes || "";
      const updatedNotes = existingNotes ? `${existingNotes}\n\n${format(new Date(), "MMM d, h:mm a")}: ${note}` : note;
      
      return await base44.entities.Booking.update(bookingId, {
        instructor_notes: updatedNotes
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorDashboardBookings'] });
      setShowQuickNote(false);
      setQuickNote("");
      setSelectedBookingForNote(null);
      toast.success("Note added successfully");
    },
    onError: () => {
      toast.error("Failed to add note");
    }
  });

  useEffect(() => {
    if (activeLesson) {
      const interval = setInterval(() => {
        setLessonTimer(prev => prev + 1);
      }, 1000);
      setTimerInterval(interval);
      
      return () => {
        clearInterval(interval);
      };
    }
  }, [activeLesson]);

  const todayBookings = useMemo(() => {
    return bookings.filter(b => {
      const bookingDate = new Date(b.start_datetime);
      return isToday(bookingDate);
    }).sort((a, b) => new Date(a.start_datetime) - new Date(b.start_datetime));
  }, [bookings]);

  const stats = useMemo(() => {
    const completed = todayBookings.filter(b => b.status === "completed").length;
    const upcoming = todayBookings.filter(b => {
      const now = new Date();
      return isFuture(new Date(b.start_datetime)) && b.status !== "completed" && b.status !== "cancelled";
    }).length;

    const todayEarnings = todayBookings
      .filter(b => b.status === "completed")
      .reduce((sum, b) => sum + ((b.instructor_earnings || b.price * 0.3) || 0), 0);

    const weekStart = startOfWeek(new Date());
    const weekEnd = endOfWeek(new Date());
    const weekBookings = bookings.filter(b => {
      const date = new Date(b.start_datetime);
      return date >= weekStart && date <= weekEnd;
    });

    const weekCompleted = weekBookings.filter(b => b.status === "completed").length;
    const weekEarnings = weekBookings
      .filter(b => b.status === "completed")
      .reduce((sum, b) => sum + ((b.instructor_earnings || b.price * 0.3) || 0), 0);

    const last7Days = bookings.filter(b => {
      const date = new Date(b.start_datetime);
      return date >= subDays(new Date(), 7) && date <= new Date();
    });

    const revenueData = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), 6 - i);
      const dayBookings = last7Days.filter(b => {
        const bookingDate = new Date(b.start_datetime);
        return isToday(bookingDate) || format(bookingDate, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd');
      });
      
      return {
        date: format(date, 'MMM d'),
        revenue: dayBookings
          .filter(b => b.status === "completed")
          .reduce((sum, b) => sum + ((b.instructor_earnings || b.price * 0.3) || 0), 0),
        bookings: dayBookings.filter(b => b.status === "completed").length
      };
    });

    const avgRating = reviews.length > 0
      ? reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviews.length
      : 0;

    const myStudents = [...new Set(bookings.map(b => b.student_id))];
    const activeStudents = myStudents.filter(studentId => {
      const studentBookings = bookings.filter(b => b.student_id === studentId);
      const lastBooking = studentBookings
        .filter(b => b.status === "completed")
        .sort((a, b) => new Date(b.start_datetime) - new Date(a.start_datetime))[0];
      
      if (!lastBooking) return false;
      const daysSinceLastLesson = differenceInMinutes(new Date(), new Date(lastBooking.start_datetime)) / (60 * 24);
      return daysSinceLastLesson <= 30;
    });

    const passRate = bookings.filter(b => b.test_passed === true).length / 
                     Math.max(bookings.filter(b => b.test_taken === true).length, 1) * 100;

    return {
      todayTotal: todayBookings.length,
      todayCompleted: completed,
      todayUpcoming: upcoming,
      todayEarnings,
      weekCompleted,
      weekEarnings,
      weekTarget: 30,
      weekEarningsTarget: 1350,
      revenueData,
      avgRating,
      totalReviews: reviews.length,
      totalStudents: myStudents.length,
      activeStudents: activeStudents.length,
      passRate: isNaN(passRate) ? 0 : passRate
    };
  }, [bookings, todayBookings, reviews]);

  const nextLesson = useMemo(() => {
    const upcoming = bookings.filter(b => {
      const start = new Date(b.start_datetime);
      return isFuture(start) && b.status !== "cancelled" && b.status !== "completed";
    }).sort((a, b) => new Date(a.start_datetime) - new Date(b.start_datetime));
    return upcoming[0];
  }, [bookings]);

  const nextStudent = useMemo(() => 
    students.find(s => s.id === nextLesson?.student_id),
    [students, nextLesson]
  );

  const assignedVehicle = useMemo(() => 
    vehicles.find(v => v.id === effectiveInstructor?.assigned_vehicle_id || bookings[0]?.vehicle_id),
    [vehicles, effectiveInstructor, bookings]
  );

  const unreadMessages = useMemo(() => 
    messages.filter(m => !m.is_read).slice(0, 3),
    [messages]
  );

  const urgentActions = useMemo(() => {
    const actions = [];

    if (nextLesson) {
      const timeUntil = differenceInMinutes(new Date(nextLesson.start_datetime), new Date());
      if (timeUntil > 0 && timeUntil <= 60) {
        actions.push({
          type: "urgent",
          priority: "high",
          message: `Lesson with ${nextStudent?.full_name || "Student"} in ${timeUntil} minutes`,
          icon: Clock,
          color: "red",
          link: createPageUrl("InstructorSchedule"),
          action: () => navigate(createPageUrl("InstructorSchedule"))
        });
      }
    }

    const studentsNeedingFollowup = students.filter(s => {
      const studentBookings = bookings.filter(b => b.student_id === s.id);
      const lastBooking = studentBookings
        .filter(b => b.status === "completed")
        .sort((a, b) => new Date(b.start_datetime) - new Date(a.start_datetime))[0];
      
      if (!lastBooking) return false;
      const daysSinceLastLesson = differenceInMinutes(new Date(), new Date(lastBooking.start_datetime)) / (60 * 24);
      return daysSinceLastLesson > 14 && daysSinceLastLesson < 30;
    });

    if (studentsNeedingFollowup.length > 0) {
      actions.push({
        type: "info",
        priority: "medium",
        message: `${studentsNeedingFollowup.length} student${studentsNeedingFollowup.length > 1 ? 's' : ''} need follow-up`,
        icon: Users,
        color: "blue",
        link: createPageUrl("InstructorStudents"),
        action: () => navigate(createPageUrl("InstructorStudents"))
      });
    }

    const missedBookings = todayBookings.filter(b => {
      const isPastTime = isPast(new Date(b.end_datetime));
      return isPastTime && b.status === "confirmed";
    });

    if (missedBookings.length > 0) {
      actions.push({
        type: "warning",
        priority: "high",
        message: `${missedBookings.length} lesson${missedBookings.length > 1 ? 's' : ''} need${missedBookings.length === 1 ? 's' : ''} status update`,
        icon: AlertTriangle,
        color: "amber",
        link: null,
        action: null
      });
    }

    if (unreadMessages.length > 0) {
      actions.push({
        type: "info",
        priority: "low",
        message: `${unreadMessages.length} unread message${unreadMessages.length > 1 ? 's' : ''}`,
        icon: MessageSquare,
        color: "purple",
        link: createPageUrl("InstructorMessages"),
        action: () => navigate(createPageUrl("InstructorMessages"))
      });
    }

    return actions.sort((a, b) => {
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });
  }, [nextLesson, nextStudent, students, bookings, todayBookings, unreadMessages, navigate]);

  const getTimeUntil = (datetime) => {
    return formatDistanceToNow(new Date(datetime), { addSuffix: true });
  };

  const getStudent = (id) => students.find(s => s.id === id);

  const handleStartLesson = (booking) => {
    startLessonMutation.mutate(booking.id);
  };

  const handleCompleteLesson = () => {
    if (!activeLesson) return;
    
    completeLessonMutation.mutate({
      bookingId: activeLesson.id,
      notes: quickNote
    });
  };

  const handleAddQuickNote = (booking) => {
    setSelectedBookingForNote(booking);
    setShowEnhancedNotes(true);
  };

  const updateBookingStatus = useMutation({
    mutationFn: async ({ bookingId, status }) => {
      return await base44.entities.Booking.update(bookingId, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorDashboardBookings'] });
      toast.success("Lesson status updated");
    }
  });

  const saveQuickNote = () => {
    if (!selectedBookingForNote || !quickNote.trim()) {
      toast.error("Please enter a note");
      return;
    }

    addQuickNoteMutation.mutate({
      bookingId: selectedBookingForNote.id,
      note: quickNote
    });
  };

  const formatTimer = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (auth.isLoading || loadingBookings) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        <SkeletonLoader count={6} type="card" />
      </div>
    );
  }

  if (authStatus === "unauthenticated" || !effectiveUser) {
    window.location.href = createPageUrl("SchoolLogin");
    return null;
  }

  if (authStatus === "no_instructor" || !effectiveInstructor) {
    return <InstructorOnboarding user={effectiveUser} onComplete={() => window.location.reload()} />;
  }

  if (bookingsError) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <QueryErrorBoundary 
          error={bookingsError} 
          onRetry={refetchBookings}
          title="Failed to load dashboard"
        />
      </div>
    );
  }

  const greetingTime = new Date().getHours();
  const greeting = greetingTime < 12 ? "morning" : greetingTime < 18 ? "afternoon" : "evening";
  const greetingEmoji = greetingTime < 12 ? "☀️" : greetingTime < 18 ? "👋" : "🌙";

  return (
    <>
    <ScrollProgress color="#3b82c4" height={3} />
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 pb-24 md:pb-6">
      <ScrollFadeIn direction="up">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-[#3b82c4] via-[#2563a3] to-[#1e4f8a] rounded-3xl p-8 text-white shadow-xl relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">
            Good {greeting}, {effectiveUser?.full_name?.split(' ')[0] || "Instructor"}! {greetingEmoji}
          </h1>
          <p className="text-white/90 text-lg">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
          
          {stats.todayTotal > 0 && (
            <div className="mt-6 flex flex-wrap gap-4">
              <div className="bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2">
                <p className="text-white/80 text-sm">Today's Lessons</p>
                <p className="text-2xl font-bold">{stats.todayTotal}</p>
              </div>
              <div className="bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2">
                <p className="text-white/80 text-sm">Completed</p>
                <p className="text-2xl font-bold">{stats.todayCompleted}</p>
              </div>
              <div className="bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2">
                <p className="text-white/80 text-sm">Earnings</p>
                <p className="text-2xl font-bold">€{stats.todayEarnings.toFixed(0)}</p>
              </div>
            </div>
          )}
        </div>
      </motion.div>
      </ScrollFadeIn>

      {activeLesson && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-r from-[#81da5a] to-[#5cb83a] rounded-2xl p-6 text-white shadow-lg"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center animate-pulse">
                <PlayCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Lesson in Progress</h3>
                <p className="text-white/90">{getStudent(activeLesson.student_id)?.full_name}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold font-mono">{formatTimer(lessonTimer)}</p>
              <p className="text-white/80 text-sm">Duration</p>
            </div>
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={handleCompleteLesson}
              disabled={completeLessonMutation.isPending}
              className="flex-1 px-4 py-3 bg-white text-[#5cb83a] rounded-xl font-semibold hover:bg-gray-100 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {completeLessonMutation.isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <CheckCircle className="w-5 h-5" />
              )}
              Complete Lesson
            </button>
            <button
              onClick={() => setShowQuickNote(!showQuickNote)}
              className="px-4 py-3 bg-white/20 hover:bg-white/30 rounded-xl font-semibold transition"
            >
              <FileText className="w-5 h-5" />
            </button>
          </div>

          {showQuickNote && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="mt-4 pt-4 border-t border-white/20"
            >
              <textarea
                value={quickNote}
                onChange={(e) => setQuickNote(e.target.value)}
                placeholder="Add lesson notes..."
                rows={3}
                className="w-full px-4 py-3 rounded-xl bg-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/40"
              />
            </motion.div>
          )}
        </motion.div>
      )}

      {urgentActions.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[#fdfbe8] border-2 border-[#f9f3c8] rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle className="w-6 h-6 text-[#b8a525]" />
            <h3 className="text-lg font-bold text-gray-900">⚠️ Attention Required</h3>
          </div>
          <div className="space-y-3">
            {urgentActions.map((action, idx) => {
              const colorClasses = {
                red: { bg: 'bg-[#fdeeed]', text: 'text-[#e44138]' },
                blue: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
                amber: { bg: 'bg-[#fdfbe8]', text: 'text-[#b8a525]' },
                purple: { bg: 'bg-[#f3e8f4]', text: 'text-[#6c376f]' }
              };
              const colors = colorClasses[action.color] || colorClasses.blue;
              
              return (
                <div key={idx} className="flex items-center justify-between p-3 bg-white rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 ${colors.bg} rounded-lg flex items-center justify-center`}>
                      <action.icon className={`w-5 h-5 ${colors.text}`} />
                    </div>
                    <p className="text-gray-900 font-medium">{action.message}</p>
                  </div>
                  {action.action && (
                    <button
                      onClick={action.action}
                      className="px-4 py-2 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-lg text-sm font-semibold transition flex items-center gap-2"
                    >
                      View
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            label: "Today's Lessons",
            value: stats.todayTotal,
            icon: Calendar,
            color: "blue",
            subtitle: `${stats.todayCompleted} completed, ${stats.todayUpcoming} upcoming`,
            link: createPageUrl("InstructorSchedule")
          },
          {
            label: "Today's Earnings",
            value: `€${stats.todayEarnings.toFixed(0)}`,
            icon: DollarSign,
            color: "green",
            subtitle: `Commission earned`,
            link: createPageUrl("InstructorEarnings")
          },
          {
            label: "Rating",
            value: stats.avgRating.toFixed(1),
            icon: Star,
            color: "yellow",
            subtitle: `${stats.totalReviews} reviews`,
            link: createPageUrl("InstructorReviews")
          },
          {
            label: "Active Students",
            value: stats.activeStudents,
            icon: Users,
            color: "accent",
            subtitle: `${stats.totalStudents} total students`,
            link: createPageUrl("InstructorStudents")
          }
        ].map((stat, idx) => {
          const colorClasses = {
            blue: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
            green: { bg: 'bg-[#eefbe7]', text: 'text-[#5cb83a]' },
            yellow: { bg: 'bg-[#fdfbe8]', text: 'text-[#b8a525]' },
            accent: { bg: 'bg-[#f3e8f4]', text: 'text-[#6c376f]' }
          };
          const colors = colorClasses[stat.color] || colorClasses.indigo;
          
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + idx * 0.05 }}
            >
              <Link
                to={stat.link}
                className="block bg-white rounded-2xl p-6 shadow-sm border border-gray-200 hover:border-gray-300 hover:shadow-md transition group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 ${colors.bg} rounded-xl flex items-center justify-center group-hover:scale-110 transition`}>
                    <stat.icon className={`w-6 h-6 ${colors.text}`} />
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-gray-600 transition" />
                </div>
                <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                <p className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</p>
                <p className="text-xs text-gray-600">{stat.subtitle}</p>
              </Link>
            </motion.div>
          );
        })}
      </div>

      {nextLesson && nextStudent && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl p-6 shadow-sm border-2 border-[#d4eaf5]"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xl font-bold text-gray-900">🎯 Next Lesson</h3>
              <p className="text-sm text-gray-600">{getTimeUntil(nextLesson.start_datetime)}</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-[#3b82c4]">
                {format(new Date(nextLesson.start_datetime), "h:mm a")}
              </p>
              <p className="text-sm text-gray-600">
                {differenceInMinutes(new Date(nextLesson.end_datetime), new Date(nextLesson.start_datetime))} min
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-[#3b82c4] to-[#2563a3] rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-2xl">
                    {nextStudent.full_name?.charAt(0) || "S"}
                  </span>
                </div>
                <div>
                  <p className="text-xl font-bold text-gray-900">{nextStudent.full_name}</p>
                  <p className="text-sm text-gray-600">
                    Lesson #{bookings.filter(b => b.student_id === nextStudent.id && b.status === "completed").length + 1}
                  </p>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-700">
                    {format(new Date(nextLesson.start_datetime), "h:mm a")} - {format(new Date(nextLesson.end_datetime), "h:mm a")}
                  </span>
                </div>
                {nextLesson.pickup_location && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-700">{nextLesson.pickup_location}</span>
                  </div>
                )}
                {nextLesson.lesson_type && (
                  <div className="flex items-center gap-2 text-sm">
                    <BookOpen className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-700 capitalize">{nextLesson.lesson_type.replace(/_/g, ' ')}</span>
                  </div>
                )}
              </div>

              <div className="flex gap-2 flex-wrap">
                <button
                  onClick={() => handleStartLesson(nextLesson)}
                  disabled={startLessonMutation.isPending}
                  className="px-4 py-2 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-lg text-sm font-semibold transition flex items-center gap-2 disabled:opacity-50"
                >
                  {startLessonMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <PlayCircle className="w-4 h-4" />
                  )}
                  Start Lesson
                </button>
                {nextLesson.pickup_location && (
                  <a
                    href={`https://maps.google.com/?q=${encodeURIComponent(nextLesson.pickup_location)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-[#a9d5ed] hover:bg-[#8bc7e8] text-[#1e3a5f] rounded-lg text-sm font-semibold transition flex items-center gap-2"
                  >
                    <Navigation className="w-4 h-4" />
                    Navigate
                  </a>
                )}
                {nextStudent.phone && (
                  <a
                    href={`tel:${nextStudent.phone}`}
                    className="px-4 py-2 bg-[#81da5a] hover:bg-[#5cb83a] text-white rounded-lg text-sm font-semibold transition flex items-center gap-2"
                  >
                    <Phone className="w-4 h-4" />
                    Call
                  </a>
                )}
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-4">
              <div className="mb-4">
                <p className="text-xs font-bold text-gray-600 uppercase mb-2">Student Progress</p>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Completion</span>
                      <span className="text-gray-900 font-semibold">{nextStudent.progress_percentage || 0}%</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed] transition-all"
                        style={{ width: `${nextStudent.progress_percentage || 0}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {nextLesson.instructor_notes ? (
                <div>
                  <p className="text-xs font-bold text-gray-600 uppercase mb-2">Previous Notes</p>
                  <div className="bg-white rounded-lg p-3 border border-gray-200">
                    <p className="text-sm text-gray-700 leading-relaxed">{nextLesson.instructor_notes}</p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-4">
                  <FileText className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">No previous notes</p>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200"
        >
          <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#3b82c4]" />
            Today's Schedule ({todayBookings.length})
          </h3>
          
          {todayBookings.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600 font-medium">No lessons today</p>
              <p className="text-sm text-gray-500">Enjoy your day off!</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {todayBookings.map((booking) => {
                const student = getStudent(booking.student_id);
                const isCompleted = booking.status === "completed";
                const isInProgress = booking.status === "in_progress";
                const isUpcoming = isFuture(new Date(booking.start_datetime)) && !isCompleted && !isInProgress;
                const isPastIncomplete = isPast(new Date(booking.end_datetime)) && booking.status === "confirmed";

                return (
                  <div
                    key={booking.id}
                    className={`flex items-center justify-between p-4 rounded-xl border-2 transition ${
                      isCompleted ? "bg-[#eefbe7] border-[#d4f4c3]" :
                      isInProgress ? "bg-[#e8f4fa] border-[#d4eaf5]" :
                      isUpcoming ? "bg-[#e8f4fa] border-[#a9d5ed]" :
                      "bg-[#fdfbe8] border-[#f9f3c8]"
                    }`}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="text-center">
                        <p className="text-lg font-bold text-gray-900">
                          {format(new Date(booking.start_datetime), "h:mm")}
                        </p>
                        <p className="text-xs text-gray-600">
                          {format(new Date(booking.start_datetime), "a")}
                        </p>
                      </div>
                      <div className="flex-1">
                        <p className="font-bold text-gray-900">{student?.full_name || "Unknown"}</p>
                        <p className="text-sm text-gray-600">{booking.pickup_location || "No location"}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {isCompleted && (
                        <span className="px-3 py-1 bg-[#eefbe7] text-[#5cb83a] rounded-full text-xs font-bold flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" />
                          Done
                        </span>
                      )}
                      {isInProgress && (
                        <span className="px-3 py-1 bg-[#e8f4fa] text-[#3b82c4] rounded-full text-xs font-bold flex items-center gap-1 animate-pulse">
                          <Activity className="w-3 h-3" />
                          Active
                        </span>
                      )}
                      {isUpcoming && (
                        <button
                          onClick={() => handleStartLesson(booking)}
                          className="px-3 py-1 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-lg text-xs font-bold transition"
                        >
                          Start
                        </button>
                      )}
                      {isPastIncomplete && (
                        <button
                          onClick={() => handleAddQuickNote(booking)}
                          className="px-3 py-1 bg-[#e7d356] hover:bg-[#d4bf2e] text-[#5c4d0a] rounded-lg text-xs font-bold transition"
                        >
                          Update
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200"
        >
          <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#3b82c4]" />
            Weekly Performance
          </h3>
          
          <div className="space-y-4 mb-6">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600 font-medium">Lessons</span>
                <span className="text-gray-900 font-bold">{stats.weekCompleted} / {stats.weekTarget}</span>
              </div>
              <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min((stats.weekCompleted / stats.weekTarget) * 100, 100)}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className="h-full bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed]"
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {Math.max(0, stats.weekTarget - stats.weekCompleted)} more to reach target
              </p>
            </div>

            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600 font-medium">Earnings</span>
                <span className="text-gray-900 font-bold">€{stats.weekEarnings.toFixed(0)} / €{stats.weekEarningsTarget}</span>
              </div>
              <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min((stats.weekEarnings / stats.weekEarningsTarget) * 100, 100)}%` }}
                  transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
                  className="h-full bg-gradient-to-r from-[#81da5a] to-[#5cb83a]"
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                €{Math.max(0, stats.weekEarningsTarget - stats.weekEarnings).toFixed(0)} more to reach target
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-200">
            <div className="text-center p-4 bg-[#fdfbe8] rounded-xl">
              <Star className="w-6 h-6 text-[#b8a525] mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-900">{stats.avgRating.toFixed(1)}</p>
              <p className="text-xs text-gray-600">Avg Rating</p>
            </div>
            <div className="text-center p-4 bg-[#eefbe7] rounded-xl">
              <Trophy className="w-6 h-6 text-[#5cb83a] mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-900">{stats.passRate.toFixed(0)}%</p>
              <p className="text-xs text-gray-600">Pass Rate</p>
            </div>
          </div>
        </motion.div>
      </div>

      {stats.revenueData.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <RevenueChart
            data={stats.revenueData}
            showBookings={true}
            target={stats.weekEarningsTarget / 7}
            title="Weekly Revenue Trend"
            subtitle="Last 7 days performance"
            height={250}
            currency="€"
          />
        </motion.div>
      )}

      {/* Today's Lessons - Mobile Optimized */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#3b82c4]" />
            Today's Lessons ({todayBookings.length})
          </h3>
          <button
            onClick={() => setShowAvailability(!showAvailability)}
            className="px-3 py-1.5 bg-[#e8f4fa] hover:bg-[#d4eaf5] text-[#3b82c4] rounded-lg text-sm font-bold transition"
          >
            Set Availability
          </button>
        </div>

        {todayBookings.length === 0 ? (
          <div className="text-center py-12">
            <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-600 font-medium">No lessons today</p>
            <p className="text-sm text-slate-500">Enjoy your day off!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {todayBookings.map((booking) => (
              <QuickLessonActions
                key={booking.id}
                booking={booking}
                student={getStudent(booking.student_id)}
                onStatusUpdate={(id, status) => updateBookingStatus.mutate({ bookingId: id, status })}
                onAddNote={handleAddQuickNote}
              />
            ))}
          </div>
        )}
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { name: "Full Schedule", icon: Calendar, path: "InstructorSchedule", color: "blue" },
          { name: "My Students", icon: Users, path: "InstructorStudents", color: "accent" },
          { name: "Earnings", icon: DollarSign, path: "InstructorEarnings", color: "green" },
          { name: "Messages", icon: MessageSquare, path: "InstructorMessages", color: "lightblue", badge: unreadMessages.length }
        ].map((action, idx) => {
          const colorClasses = {
            blue: 'text-[#3b82c4]',
            accent: 'text-[#6c376f]',
            green: 'text-[#5cb83a]',
            lightblue: 'text-[#a9d5ed]'
          };
          const iconColor = colorClasses[action.color] || 'text-indigo-600';
          
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.7 + idx * 0.05 }}
            >
              <Link
                to={createPageUrl(action.path)}
                className="relative block bg-white hover:bg-gray-50 rounded-xl p-6 shadow-sm border border-gray-200 text-center transition group"
              >
                {action.badge > 0 && (
                  <span className="absolute top-2 right-2 w-6 h-6 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {action.badge}
                  </span>
                )}
                <action.icon className={`w-8 h-8 ${iconColor} mx-auto mb-2 group-hover:scale-110 transition`} />
                <p className="font-semibold text-gray-900">{action.name}</p>
              </Link>
            </motion.div>
          );
        })}
      </div>

      {/* Availability Manager Modal */}
      <AnimatePresence>
        {showAvailability && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto"
            onClick={() => setShowAvailability(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-5xl my-8"
            >
              <AvailabilityManager 
                instructor={effectiveInstructor}
                onUpdate={() => {
                  setShowAvailability(false);
                  queryClient.invalidateQueries({ queryKey: ['instructorDashboardBookings'] });
                }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Enhanced Lesson Notes Modal */}
      <AnimatePresence>
        {showEnhancedNotes && selectedBookingForNote && (
          <EnhancedLessonNotes
            booking={selectedBookingForNote}
            student={getStudent(selectedBookingForNote.student_id)}
            onClose={() => {
              setShowEnhancedNotes(false);
              setSelectedBookingForNote(null);
            }}
            onSave={() => {
              queryClient.invalidateQueries({ queryKey: ['instructorDashboardBookings'] });
            }}
          />
        )}
      </AnimatePresence>
      </div>
      </>
      );
      }