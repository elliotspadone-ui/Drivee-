import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Plus, 
  Star, 
  TrendingUp, 
  Clock, 
  Award, 
  Phone, 
  Mail, 
  Edit, 
  Calendar, 
  BarChart3, 
  Users,
  Search,
  Filter,
  Download,
  RefreshCw,
  Eye,
  Trash2,
  MoreVertical,
  X,
  Check,
  MapPin,
  DollarSign,
  FileText,
  MessageSquare,
  Send,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  ArrowLeft,
  Loader2,
  AlertCircle,
  CheckCircle,
  XCircle,
  Settings,
  Shield,
  ShieldCheck,
  Target,
  Zap,
  PieChart,
  Activity,
  Globe,
  Flag,
  BookOpen,
  GraduationCap,
  Briefcase,
  Building2,
  UserPlus,
  UserMinus,
  UserCheck,
  Copy,
  ExternalLink,
  Share2,
  Printer,
  Upload,
  Image,
  Camera,
  Hash,
  AtSign,
  CalendarDays,
  CalendarRange,
  Timer,
  Gauge,
  Route,
  Coffee,
  Sun,
  Moon,
  Sunrise,
  Sunset,
  Bell,
  BellOff,
  Lock,
  Unlock,
  Key,
  Fingerprint,
  CreditCard,
  Wallet,
  Receipt,
  Tag,
  Tags,
  Bookmark,
  Heart,
  ThumbsUp,
  ThumbsDown,
  MessageCircle,
  Info,
  HelpCircle,
  AlertTriangle,
  Ban,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Car,
  Navigation,
  Percent
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  format, 
  parseISO, 
  differenceInYears,
  differenceInDays,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  isWithinInterval,
  isFuture,
  isPast,
  addDays,
  subDays
} from "date-fns";
import { toast } from "sonner";
import { ScrollFadeIn, StaggerFadeIn, ScrollProgress } from "@/components/animations/FadeSections";
import { KPIComparisonCard, AnimatedCounter } from "@/components/charts/KPIComparison";
import { getEffectiveSchoolId } from "@/components/utils/schoolContext";
import QueryErrorBoundary from "@/components/common/QueryErrorBoundary";
import SkeletonLoader from "@/components/common/SkeletonLoader";
import { logger } from "@/components/utils/config";

const CERTIFICATIONS = [
  { id: "B", label: "Class B", description: "Standard car license", color: "blue" },
  { id: "A", label: "Class A", description: "Motorcycle license", color: "red" },
  { id: "C", label: "Class C", description: "Heavy vehicle license", color: "amber" },
  { id: "D", label: "Class D", description: "Bus license", color: "purple" },
  { id: "BE", label: "Class BE", description: "Car with trailer", color: "cyan" },
  { id: "CE", label: "Class CE", description: "Heavy vehicle with trailer", color: "orange" },
  { id: "DE", label: "Class DE", description: "Bus with trailer", color: "pink" },
  { id: "ADI", label: "ADI", description: "Approved Driving Instructor", color: "green" },
  { id: "PDI", label: "PDI", description: "Potential Driving Instructor", color: "indigo" }
];

const SPECIALIZATIONS = [
  { id: "manual", label: "Manual", icon: Gauge },
  { id: "automatic", label: "Automatic", icon: Zap },
  { id: "nervous", label: "Nervous Drivers", icon: Heart },
  { id: "intensive", label: "Intensive", icon: Target },
  { id: "refresher", label: "Refresher", icon: RotateCcw },
  { id: "motorway", label: "Motorway", icon: Route },
  { id: "night", label: "Night Driving", icon: Moon },
  { id: "defensive", label: "Defensive", icon: Shield }
];

const LANGUAGES = [
  "English", "German", "French", "Spanish", "Italian", "Portuguese", 
  "Dutch", "Polish", "Turkish", "Arabic", "Chinese", "Hindi", "Russian"
];

export default function Instructors() {
  const queryClient = useQueryClient();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [certificationFilter, setCertificationFilter] = useState("all");
  const [schoolFilter, setSchoolFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [viewMode, setViewMode] = useState("grid");
  
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedInstructor, setSelectedInstructor] = useState(null);
  const [school, setSchool] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);
  const [schoolId, setSchoolId] = useState(null);
  const [loadingAuth, setLoadingAuth] = useState(true);

  const [inviteData, setInviteData] = useState({
    email: "",
    full_name: "",
    phone: "",
    message: ""
  });

  React.useEffect(() => {
    const loadAuth = async () => {
      try {
        const user = await base44.auth.me();
        if (!user || user.role !== "admin") {
          window.location.href = createPageUrl("Unauthorized");
          return;
        }
        const sid = await getEffectiveSchoolId(user);
        setSchoolId(sid);
      } catch (err) {
        logger.error("Failed to load auth:", err);
        window.location.href = createPageUrl("SchoolLogin");
      } finally {
        setLoadingAuth(false);
      }
    };
    loadAuth();
  }, []);

  const { data: instructors = [], isLoading: loadingInstructors, error: instructorsError, refetch } = useQuery({
    queryKey: ['instructors', schoolId],
    queryFn: () => schoolId ? base44.entities.Instructor.filter({ school_id: schoolId }, '-created_date', 100) : [],
    enabled: !!schoolId,
    staleTime: 300000,
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ['bookings', schoolId],
    queryFn: () => schoolId ? base44.entities.Booking.filter({ school_id: schoolId }, '-start_datetime', 200) : [],
    enabled: !!schoolId,
    staleTime: 60000,
  });

  const { data: schools = [] } = useQuery({
    queryKey: ['schools'],
    queryFn: async () => {
      const schoolsList = await base44.entities.School.filter({ id: schoolId }, "-created_date", 1);
      if (schoolsList.length > 0) {
        setSchool(schoolsList[0]);
      }
      return schoolsList;
    },
    enabled: !!schoolId,
    staleTime: 600000,
  });

  const { data: students = [] } = useQuery({
    queryKey: ['students', schoolId],
    queryFn: () => schoolId ? base44.entities.Student.filter({ school_id: schoolId }, "-created_date", 200) : [],
    enabled: !!schoolId,
    staleTime: 300000,
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ['vehicles', schoolId],
    queryFn: () => schoolId ? base44.entities.Vehicle.filter({ school_id: schoolId }, "-created_date", 50) : [],
    enabled: !!schoolId,
    staleTime: 300000,
  });

  const { data: payments = [] } = useQuery({
    queryKey: ['payments', schoolId],
    queryFn: () => schoolId ? base44.entities.Payment.filter({ school_id: schoolId }, '-payment_date', 100) : [],
    enabled: !!schoolId,
    staleTime: 60000,
  });

  const { data: timeOffRequests = [] } = useQuery({
    queryKey: ['timeOffRequests', schoolId],
    queryFn: async () => {
      if (!schoolId) return [];
      try {
        return await base44.entities.TimeOffRequest.filter({ school_id: schoolId }, '-created_date', 100);
      } catch {
        return [];
      }
    },
    enabled: !!schoolId,
    staleTime: 300000,
  });

  const inviteInstructorMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.Instructor.create({
        ...data,
        school_id: school?.id,
        is_active: false,
        status: "pending_invite"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructors'] });
      setShowInviteModal(false);
      setInviteData({ email: "", full_name: "", phone: "", message: "" });
      toast.success("Invitation sent successfully");
    },
    onError: () => {
      toast.error("Failed to send invitation");
    }
  });

  const updateInstructorMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Instructor.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructors'] });
      toast.success("Instructor updated successfully");
    },
    onError: () => {
      toast.error("Failed to update instructor");
    }
  });

  const deleteInstructorMutation = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.Instructor.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructors'] });
      setShowDeleteConfirm(null);
      toast.success("Instructor removed");
    },
    onError: () => {
      toast.error("Failed to remove instructor");
    }
  });

  const getInstructorStats = useCallback((instructorId) => {
    const instructorBookings = bookings.filter(b => b.instructor_id === instructorId);
    const completed = instructorBookings.filter(b => b.status === "completed").length;
    const upcoming = instructorBookings.filter(b => 
      (b.status === "confirmed" || b.status === "pending") && 
      isFuture(new Date(b.start_datetime))
    ).length;
    
    const cancelled = instructorBookings.filter(b => 
      b.status === "cancelled" || b.status === "no_show"
    ).length;

    const assignedStudents = [...new Set(instructorBookings.map(b => b.student_id))].length;

    const thisMonth = { start: startOfMonth(new Date()), end: endOfMonth(new Date()) };
    const monthlyBookings = instructorBookings.filter(b => {
      const date = new Date(b.start_datetime);
      return isWithinInterval(date, thisMonth);
    });

    const monthlyHours = monthlyBookings.reduce((sum, b) => {
      const duration = (new Date(b.end_datetime) - new Date(b.start_datetime)) / (1000 * 60 * 60);
      return sum + duration;
    }, 0);

    const monthlyRevenue = monthlyBookings.reduce((sum, b) => sum + (b.price || 0), 0);

    const thisWeek = { start: startOfWeek(new Date()), end: endOfWeek(new Date()) };
    const weeklyBookings = instructorBookings.filter(b => {
      const date = new Date(b.start_datetime);
      return isWithinInterval(date, thisWeek);
    });

    const weeklyHours = weeklyBookings.reduce((sum, b) => {
      const duration = (new Date(b.end_datetime) - new Date(b.start_datetime)) / (1000 * 60 * 60);
      return sum + duration;
    }, 0);

    const instructorTimeOff = timeOffRequests.filter(t => t.instructor_id === instructorId);
    const pendingTimeOff = instructorTimeOff.filter(t => t.status === "pending").length;
    const approvedTimeOff = instructorTimeOff.filter(t => t.status === "approved").length;

    const utilizationRate = instructorBookings.length > 0 
      ? Math.round((completed / instructorBookings.length) * 100)
      : 0;

    const cancellationRate = instructorBookings.length > 0
      ? Math.round((cancelled / instructorBookings.length) * 100)
      : 0;

    return { 
      total: instructorBookings.length, 
      completed, 
      upcoming, 
      cancelled,
      assignedStudents,
      monthlyHours: Math.round(monthlyHours * 10) / 10,
      monthlyRevenue,
      weeklyHours: Math.round(weeklyHours * 10) / 10,
      weeklyBookings: weeklyBookings.length,
      pendingTimeOff,
      approvedTimeOff,
      utilizationRate,
      cancellationRate
    };
  }, [bookings, timeOffRequests]);

  const enrichedInstructors = useMemo(() => {
    return instructors.map(instructor => ({
      ...instructor,
      stats: getInstructorStats(instructor.id),
      schoolData: schools.find(s => s.id === instructor.school_id)
    }));
  }, [instructors, schools, getInstructorStats]);

  const filteredInstructors = useMemo(() => {
    let filtered = [...enrichedInstructors];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(i =>
        i.full_name?.toLowerCase().includes(query) ||
        i.email?.toLowerCase().includes(query) ||
        i.phone?.includes(searchQuery)
      );
    }

    if (statusFilter !== "all") {
      if (statusFilter === "active") {
        filtered = filtered.filter(i => i.is_active !== false);
      } else if (statusFilter === "inactive") {
        filtered = filtered.filter(i => i.is_active === false);
      }
    }

    if (certificationFilter !== "all") {
      filtered = filtered.filter(i => i.certifications?.includes(certificationFilter));
    }

    if (schoolFilter !== "all") {
      filtered = filtered.filter(i => i.school_id === schoolFilter);
    }

    filtered.sort((a, b) => {
      let comparison = 0;
      
      if (sortBy === "name") {
        comparison = (a.full_name || "").localeCompare(b.full_name || "");
      } else if (sortBy === "lessons") {
        comparison = (a.stats.completed || 0) - (b.stats.completed || 0);
      } else if (sortBy === "rating") {
        comparison = (a.rating || 0) - (b.rating || 0);
      } else if (sortBy === "experience") {
        comparison = (a.years_experience || 0) - (b.years_experience || 0);
      } else if (sortBy === "students") {
        comparison = (a.stats.assignedStudents || 0) - (b.stats.assignedStudents || 0);
      } else if (sortBy === "revenue") {
        comparison = (a.stats.monthlyRevenue || 0) - (b.stats.monthlyRevenue || 0);
      }

      return sortOrder === "asc" ? comparison : -comparison;
    });

    return filtered;
  }, [enrichedInstructors, searchQuery, statusFilter, certificationFilter, schoolFilter, sortBy, sortOrder]);

  const stats = useMemo(() => {
    const active = enrichedInstructors.filter(i => i.is_active !== false).length;
    const totalLessons = enrichedInstructors.reduce((sum, i) => sum + i.stats.completed, 0);
    const totalStudents = enrichedInstructors.reduce((sum, i) => sum + i.stats.assignedStudents, 0);
    const totalRevenue = enrichedInstructors.reduce((sum, i) => sum + i.stats.monthlyRevenue, 0);
    const avgRating = enrichedInstructors.length > 0
      ? enrichedInstructors.reduce((sum, i) => sum + (i.rating || 5), 0) / enrichedInstructors.length
      : 0;
    const avgExperience = enrichedInstructors.length > 0
      ? enrichedInstructors.reduce((sum, i) => sum + (i.years_experience || 0), 0) / enrichedInstructors.length
      : 0;
    const avgUtilization = enrichedInstructors.length > 0
      ? enrichedInstructors.reduce((sum, i) => sum + i.stats.utilizationRate, 0) / enrichedInstructors.length
      : 0;

    return {
      total: enrichedInstructors.length,
      active,
      inactive: enrichedInstructors.length - active,
      totalLessons,
      totalStudents,
      totalRevenue,
      avgRating: Math.round(avgRating * 10) / 10,
      avgExperience: Math.round(avgExperience),
      avgUtilization: Math.round(avgUtilization)
    };
  }, [enrichedInstructors]);

  const viewInstructorDetails = (instructor) => {
    setSelectedInstructor(instructor);
    setActiveTab("overview");
    setShowDetailsModal(true);
  };

  const toggleInstructorStatus = async (instructor) => {
    await updateInstructorMutation.mutateAsync({
      id: instructor.id,
      data: { is_active: !instructor.is_active }
    });
  };

  const handleInvite = () => {
    if (!inviteData.email || !inviteData.full_name) {
      toast.error("Please enter name and email");
      return;
    }
    inviteInstructorMutation.mutate(inviteData);
  };

  const exportInstructors = () => {
    toast.success("Instructor data exported");
  };

  if (loadingAuth || loadingInstructors) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        <SkeletonLoader count={6} type="card" />
      </div>
    );
  }

  if (!schoolId) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
          <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">School Not Found</h3>
          <p className="text-gray-600">Please complete your school setup first.</p>
        </div>
      </div>
    );
  }

  if (instructorsError) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12">
        <QueryErrorBoundary 
          error={instructorsError} 
          onRetry={refetch}
          title="Failed to load instructors"
        />
      </div>
    );
  }

  return (
    <>
    <ScrollProgress color="#3b82c4" height={3} />
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6 space-y-6">
      <ScrollFadeIn direction="up">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed] bg-clip-text text-transparent mb-1">
              Instructor Management
            </h1>
            <p className="text-gray-600">Team performance, certifications, and scheduling</p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => refetch()}
              className="p-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              <RefreshCw className="w-5 h-5 text-gray-600" />
            </button>
            <button
              onClick={exportInstructors}
              className="p-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              <Download className="w-5 h-5 text-gray-600" />
            </button>
            <button
              onClick={() => setShowInviteModal(true)}
              className="px-4 py-2 bg-gradient-to-r from-[#3b82c4] to-[#2563a3] hover:from-[#2563a3] hover:to-[#1e4f8a] text-white rounded-xl font-semibold transition flex items-center gap-2 shadow-lg"
            >
              <UserPlus className="w-5 h-5" />
              Invite Instructor
            </button>
          </div>
        </div>
      </motion.div>
      </ScrollFadeIn>

      <StaggerFadeIn staggerDelay={0.03}>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
        {[
          { label: "Total", value: stats.total, icon: Users, color: "primary" },
          { label: "Active", value: stats.active, icon: CheckCircle, color: "green" },
          { label: "Lessons", value: stats.totalLessons, icon: Calendar, color: "primary" },
          { label: "Students", value: stats.totalStudents, icon: GraduationCap, color: "accent" },
          { label: "Revenue", value: `€${stats.totalRevenue.toLocaleString()}`, icon: DollarSign, color: "primary" },
          { label: "Avg Rating", value: stats.avgRating, icon: Star, color: "amber", suffix: "/5" },
          { label: "Avg Exp", value: stats.avgExperience, icon: Award, color: "accent", suffix: " yrs" },
          { label: "Utilization", value: stats.avgUtilization, icon: Gauge, color: "green", suffix: "%" }
        ].map((stat, idx) => {
          const colorClasses = {
            primary: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
            green: { bg: 'bg-[#eefbe7]', text: 'text-[#5cb83a]' },
            amber: { bg: 'bg-[#fdfbe8]', text: 'text-[#b8a525]' },
            accent: { bg: 'bg-[#f3e8f4]', text: 'text-[#6c376f]' }
          };
          const colors = colorClasses[stat.color] || colorClasses.primary;
          
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.03 }}
              className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm"
            >
              <div className={`w-10 h-10 ${colors.bg} rounded-xl flex items-center justify-center mb-2`}>
                <stat.icon className={`w-5 h-5 ${colors.text}`} />
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}{stat.suffix || ''}</p>
              <p className="text-xs text-gray-600">{stat.label}</p>
            </motion.div>
          );
        })}
      </div>
      </StaggerFadeIn>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm space-y-4"
      >
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name, email, or phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>

            <select
              value={certificationFilter}
              onChange={(e) => setCertificationFilter(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
            >
              <option value="all">All Certifications</option>
              {CERTIFICATIONS.map(cert => (
                <option key={cert.id} value={cert.id}>{cert.label}</option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
            >
              <option value="name">Sort by Name</option>
              <option value="lessons">Sort by Lessons</option>
              <option value="rating">Sort by Rating</option>
              <option value="experience">Sort by Experience</option>
              <option value="students">Sort by Students</option>
              <option value="revenue">Sort by Revenue</option>
            </select>

            <button
              onClick={() => setSortOrder(prev => prev === "asc" ? "desc" : "asc")}
              className="p-3 border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              {sortOrder === "asc" ? (
                <ChevronUp className="w-5 h-5 text-gray-600" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-600" />
              )}
            </button>

            <div className="flex gap-1 p-1 bg-gray-100 rounded-xl">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-lg transition ${viewMode === "grid" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
              >
                <BarChart3 className="w-5 h-5 text-gray-600" />
              </button>
              <button
                onClick={() => setViewMode("table")}
                className={`p-2 rounded-lg transition ${viewMode === "table" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
              >
                <FileText className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>

        <div className="text-sm text-gray-600">
          Showing {filteredInstructors.length} instructor{filteredInstructors.length !== 1 ? 's' : ''}
        </div>
      </motion.div>

      {filteredInstructors.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">No instructors found</h3>
          <p className="text-gray-600 mb-6">
            {searchQuery || statusFilter !== "all" || certificationFilter !== "all"
              ? "Try adjusting your filters"
              : "Get started by inviting your first instructor"
            }
          </p>
          <button
            onClick={() => setShowInviteModal(true)}
            className="px-6 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition inline-flex items-center gap-2"
          >
            <UserPlus className="w-5 h-5" />
            Invite Instructor
          </button>
        </div>
      ) : viewMode === "grid" ? (
        <div className="grid lg:grid-cols-2 gap-6">
          {filteredInstructors.map((instructor, index) => (
            <motion.div
              key={instructor.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.03 }}
              className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#3b82c4] to-[#a9d5ed] rounded-2xl flex items-center justify-center">
                    <span className="text-white text-2xl font-bold">
                      {instructor.full_name?.charAt(0) || "I"}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">{instructor.full_name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-[#e7d356] fill-[#e7d356]" />
                        <span className="text-sm font-semibold text-gray-900">
                          {instructor.rating?.toFixed(1) || "5.0"}
                        </span>
                      </div>
                      <span className="text-xs text-gray-500">
                        ({instructor.total_reviews || 0} reviews)
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-1">
                  <button
                    onClick={() => viewInstructorDetails(instructor)}
                    className="p-2 hover:bg-gray-100 rounded-lg transition"
                  >
                    <Eye className="w-4 h-4 text-gray-600" />
                  </button>
                  <button
                    onClick={() => toggleInstructorStatus(instructor)}
                    className="p-2 hover:bg-gray-100 rounded-lg transition"
                  >
                    {instructor.is_active !== false ? (
                      <Pause className="w-4 h-4 text-[#e7d356]" />
                    ) : (
                      <Play className="w-4 h-4 text-[#81da5a]" />
                    )}
                  </button>
                </div>
              </div>

              <div className="p-3 bg-gray-50 rounded-xl mb-4">
                <div className="flex flex-col gap-2 text-sm">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Mail className="w-4 h-4" />
                    <span className="truncate">{instructor.email}</span>
                  </div>
                  {instructor.phone && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>{instructor.phone}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2 mb-4">
                <div className="p-2 bg-[#e8f4fa] rounded-xl text-center">
                  <p className="text-xl font-bold text-[#3b82c4]">{instructor.stats.completed}</p>
                  <p className="text-xs text-[#2563a3]">Done</p>
                </div>
                <div className="p-2 bg-[#eefbe7] rounded-xl text-center">
                  <p className="text-xl font-bold text-[#5cb83a]">{instructor.stats.upcoming}</p>
                  <p className="text-xs text-[#4a9c2e]">Upcoming</p>
                </div>
                <div className="p-2 bg-[#f3e8f4] rounded-xl text-center">
                  <p className="text-xl font-bold text-[#6c376f]">{instructor.stats.assignedStudents}</p>
                  <p className="text-xs text-[#5a2d5d]">Students</p>
                </div>
                <div className="p-2 bg-[#fdfbe8] rounded-xl text-center">
                  <p className="text-xl font-bold text-[#b8a525]">{instructor.stats.weeklyHours}</p>
                  <p className="text-xs text-[#9a8520]">Hrs/Wk</p>
                </div>
              </div>

              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Utilization Rate</span>
                  <span className="text-sm font-bold text-gray-900">{instructor.stats.utilizationRate}%</span>
                </div>
                <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed] rounded-full transition-all"
                    style={{ width: `${instructor.stats.utilizationRate}%` }}
                  />
                </div>
              </div>

              {instructor.certifications?.length > 0 && (
                <div className="mb-4">
                  <p className="text-xs text-gray-600 mb-2">Certifications</p>
                  <div className="flex flex-wrap gap-1">
                    {instructor.certifications.slice(0, 5).map(cert => (
                      <span key={cert} className="px-2 py-1 bg-[#e8f4fa] text-[#3b82c4] rounded-lg text-xs font-semibold">
                        {cert}
                      </span>
                    ))}
                    {instructor.certifications.length > 5 && (
                      <span className="px-2 py-1 bg-gray-100 rounded-lg text-xs text-gray-500">
                        +{instructor.certifications.length - 5}
                      </span>
                    )}
                  </div>
                </div>
              )}

              {instructor.languages?.length > 0 && (
                <div className="mb-4">
                  <p className="text-xs text-gray-600 mb-2">Languages</p>
                  <div className="flex flex-wrap gap-1">
                    {instructor.languages.slice(0, 3).map(lang => (
                      <span key={lang} className="px-2 py-1 bg-gray-100 rounded-lg text-xs text-gray-700">
                        {lang}
                      </span>
                    ))}
                    {instructor.languages.length > 3 && (
                      <span className="text-xs text-gray-500">+{instructor.languages.length - 3}</span>
                    )}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                  instructor.is_active !== false 
                    ? "bg-[#eefbe7] text-[#5cb83a]" 
                    : "bg-gray-100 text-gray-600"
                }`}>
                  {instructor.is_active !== false ? "Active" : "Inactive"}
                </span>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Award className="w-3 h-3" />
                  <span>{instructor.years_experience || 0} years experience</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Instructor</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Contact</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Stats</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Rating</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Utilization</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
                  <th className="px-6 py-4 text-right text-xs font-bold text-gray-600 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredInstructors.map((instructor, index) => (
                  <motion.tr
                    key={instructor.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: index * 0.02 }}
                    className="hover:bg-gray-50 transition"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-[#3b82c4] to-[#a9d5ed] rounded-xl flex items-center justify-center flex-shrink-0">
                          <span className="text-white font-bold">
                            {instructor.full_name?.charAt(0) || "I"}
                          </span>
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">{instructor.full_name}</p>
                          <p className="text-sm text-gray-600">{instructor.years_experience || 0} years exp.</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-gray-900">{instructor.email}</p>
                      <p className="text-sm text-gray-600">{instructor.phone || "—"}</p>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm">
                        <p className="text-gray-900">{instructor.stats.completed} lessons</p>
                        <p className="text-gray-600">{instructor.stats.assignedStudents} students</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-[#e7d356] fill-[#e7d356]" />
                        <span className="font-semibold text-gray-900">
                          {instructor.rating?.toFixed(1) || "5.0"}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="w-20">
                        <div className="flex justify-between text-xs mb-1">
                          <span>{instructor.stats.utilizationRate}%</span>
                        </div>
                        <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-[#3b82c4] rounded-full"
                            style={{ width: `${instructor.stats.utilizationRate}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                        instructor.is_active !== false 
                          ? "bg-[#eefbe7] text-[#5cb83a]" 
                          : "bg-gray-100 text-gray-600"
                      }`}>
                        {instructor.is_active !== false ? "Active" : "Inactive"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => viewInstructorDetails(instructor)}
                          className="p-2 hover:bg-gray-100 rounded-lg transition"
                        >
                          <Eye className="w-4 h-4 text-gray-600" />
                        </button>
                        <button
                          onClick={() => toggleInstructorStatus(instructor)}
                          className="p-2 hover:bg-gray-100 rounded-lg transition"
                        >
                          {instructor.is_active !== false ? (
                            <Pause className="w-4 h-4 text-[#e7d356]" />
                          ) : (
                            <Play className="w-4 h-4 text-[#81da5a]" />
                          )}
                        </button>
                        <button
                          onClick={() => setShowDeleteConfirm(instructor.id)}
                          className="p-2 hover:bg-[#fdeeed] rounded-lg transition"
                        >
                          <Trash2 className="w-4 h-4 text-[#e44138]" />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <AnimatePresence>
        {showInviteModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowInviteModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-[#e8f4fa] rounded-xl flex items-center justify-center">
                    <UserPlus className="w-6 h-6 text-[#3b82c4]" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">Invite Instructor</h3>
                    <p className="text-sm text-gray-600">Send an invitation to join your team</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowInviteModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                  <input
                    type="text"
                    value={inviteData.full_name}
                    onChange={(e) => setInviteData(prev => ({ ...prev, full_name: e.target.value }))}
                    placeholder="Enter instructor's name"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                  <input
                    type="email"
                    value={inviteData.email}
                    onChange={(e) => setInviteData(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="instructor@email.com"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                  <input
                    type="tel"
                    value={inviteData.phone}
                    onChange={(e) => setInviteData(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="+1 234 567 8900"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Personal Message (optional)</label>
                  <textarea
                    value={inviteData.message}
                    onChange={(e) => setInviteData(prev => ({ ...prev, message: e.target.value }))}
                    placeholder="Add a personal message to your invitation..."
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed] resize-none"
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => setShowInviteModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleInvite}
                  disabled={inviteInstructorMutation.isPending || !inviteData.email || !inviteData.full_name}
                  className="flex-1 px-4 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {inviteInstructorMutation.isPending ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <Send className="w-5 h-5" />
                  )}
                  Send Invitation
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showDetailsModal && selectedInstructor && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => { setShowDetailsModal(false); setSelectedInstructor(null); }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
            >
              <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between z-10">
                <h3 className="text-xl font-bold text-gray-900">Instructor Details</h3>
                <button
                  onClick={() => { setShowDetailsModal(false); setSelectedInstructor(null); }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 bg-gradient-to-br from-[#3b82c4] to-[#a9d5ed] rounded-2xl flex items-center justify-center">
                    <span className="text-white text-3xl font-bold">
                      {selectedInstructor.full_name?.charAt(0) || "I"}
                    </span>
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{selectedInstructor.full_name}</h2>
                    <div className="flex items-center gap-2 mt-1">
                      <Star className="w-5 h-5 text-[#e7d356] fill-[#e7d356]" />
                      <span className="font-bold text-gray-900">{selectedInstructor.rating?.toFixed(1) || "5.0"}</span>
                      <span className="text-gray-600">• {selectedInstructor.years_experience || 0} years experience</span>
                    </div>
                    <span className={`inline-block mt-2 px-3 py-1 rounded-full text-xs font-bold ${
                      selectedInstructor.is_active !== false 
                        ? "bg-[#eefbe7] text-[#5cb83a]" 
                        : "bg-gray-100 text-gray-600"
                    }`}>
                      {selectedInstructor.is_active !== false ? "Active" : "Inactive"}
                    </span>
                  </div>
                </div>

                <div className="flex gap-2 border-b border-gray-200 pb-4">
                  {[
                    { id: "overview", label: "Overview" },
                    { id: "stats", label: "Statistics" },
                    { id: "schedule", label: "Schedule" }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${
                        activeTab === tab.id
                          ? "bg-[#e8f4fa] text-[#3b82c4]"
                          : "text-gray-600 hover:bg-gray-100"
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                {activeTab === "overview" && (
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      {selectedInstructor.email && (
                        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                          <Mail className="w-5 h-5 text-gray-400" />
                          <div>
                            <p className="text-xs text-gray-500">Email</p>
                            <p className="font-semibold text-gray-900">{selectedInstructor.email}</p>
                          </div>
                        </div>
                      )}
                      {selectedInstructor.phone && (
                        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                          <Phone className="w-5 h-5 text-gray-400" />
                          <div>
                            <p className="text-xs text-gray-500">Phone</p>
                            <p className="font-semibold text-gray-900">{selectedInstructor.phone}</p>
                          </div>
                        </div>
                      )}
                    </div>

                    {selectedInstructor.certifications?.length > 0 && (
                      <div>
                        <h4 className="font-bold text-gray-900 mb-3">Certifications</h4>
                        <div className="flex flex-wrap gap-2">
                          {selectedInstructor.certifications.map(cert => (
                            <span key={cert} className="px-3 py-1.5 bg-[#e8f4fa] text-[#3b82c4] rounded-lg text-sm font-semibold">
                              {cert}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {selectedInstructor.languages?.length > 0 && (
                      <div>
                        <h4 className="font-bold text-gray-900 mb-3">Languages</h4>
                        <div className="flex flex-wrap gap-2">
                          {selectedInstructor.languages.map(lang => (
                            <span key={lang} className="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg text-sm">
                              {lang}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {selectedInstructor.bio && (
                      <div>
                        <h4 className="font-bold text-gray-900 mb-2">Bio</h4>
                        <p className="text-gray-600">{selectedInstructor.bio}</p>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === "stats" && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div className="p-4 bg-[#e8f4fa] rounded-xl text-center">
                        <p className="text-3xl font-bold text-[#3b82c4]">{selectedInstructor.stats.completed}</p>
                        <p className="text-xs text-[#2563a3]">Completed</p>
                      </div>
                      <div className="p-4 bg-[#eefbe7] rounded-xl text-center">
                        <p className="text-3xl font-bold text-[#5cb83a]">{selectedInstructor.stats.upcoming}</p>
                        <p className="text-xs text-[#4a9c2e]">Upcoming</p>
                      </div>
                      <div className="p-4 bg-[#f3e8f4] rounded-xl text-center">
                        <p className="text-3xl font-bold text-[#6c376f]">{selectedInstructor.stats.assignedStudents}</p>
                        <p className="text-xs text-[#5a2d5d]">Students</p>
                      </div>
                      <div className="p-4 bg-[#fdfbe8] rounded-xl text-center">
                        <p className="text-3xl font-bold text-[#b8a525]">€{selectedInstructor.stats.monthlyRevenue}</p>
                        <p className="text-xs text-[#9a8520]">This Month</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-bold text-gray-900 mb-3">Performance Metrics</h4>
                      <div className="space-y-3">
                        <div className="p-3 bg-gray-50 rounded-xl">
                          <div className="flex justify-between mb-2">
                            <span className="text-sm text-gray-600">Utilization Rate</span>
                            <span className="font-bold text-gray-900">{selectedInstructor.stats.utilizationRate}%</span>
                          </div>
                          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-[#3b82c4] rounded-full"
                              style={{ width: `${selectedInstructor.stats.utilizationRate}%` }}
                            />
                          </div>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-xl">
                          <div className="flex justify-between mb-2">
                            <span className="text-sm text-gray-600">Cancellation Rate</span>
                            <span className="font-bold text-gray-900">{selectedInstructor.stats.cancellationRate}%</span>
                          </div>
                          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-[#e44138] rounded-full"
                              style={{ width: `${selectedInstructor.stats.cancellationRate}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <h5 className="font-bold text-gray-900 mb-2">Weekly Activity</h5>
                        <p className="text-2xl font-bold text-[#3b82c4]">{selectedInstructor.stats.weeklyHours} hours</p>
                        <p className="text-sm text-gray-600">{selectedInstructor.stats.weeklyBookings} bookings</p>
                      </div>
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <h5 className="font-bold text-gray-900 mb-2">Monthly Activity</h5>
                        <p className="text-2xl font-bold text-[#3b82c4]">{selectedInstructor.stats.monthlyHours} hours</p>
                        <p className="text-sm text-gray-600">€{selectedInstructor.stats.monthlyRevenue} revenue</p>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "schedule" && (
                  <div className="text-center py-8">
                    <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-600">Schedule view coming soon</p>
                  </div>
                )}

                <div className="flex gap-3 pt-4 border-t border-gray-200">
                  <button
                    onClick={() => toggleInstructorStatus(selectedInstructor)}
                    className="flex-1 px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-xl font-semibold transition flex items-center justify-center gap-2"
                  >
                    {selectedInstructor.is_active !== false ? (
                      <>
                        <Pause className="w-4 h-4" />
                        Deactivate
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4" />
                        Activate
                      </>
                    )}
                  </button>
                  {selectedInstructor.phone && (
                    <a
                      href={`tel:${selectedInstructor.phone}`}
                      className="flex-1 px-4 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                    >
                      <Phone className="w-4 h-4" />
                      Call
                    </a>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showDeleteConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowDeleteConfirm(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-[#fdeeed] rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertTriangle className="w-8 h-8 text-[#e44138]" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Remove Instructor</h3>
                <p className="text-gray-600 mb-6">
                  Are you sure you want to remove this instructor? This action cannot be undone.
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowDeleteConfirm(null)}
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => deleteInstructorMutation.mutate(showDeleteConfirm)}
                    disabled={deleteInstructorMutation.isPending}
                    className="flex-1 px-4 py-3 bg-[#e44138] hover:bg-[#c9342c] text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {deleteInstructorMutation.isPending ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <Trash2 className="w-5 h-5" />
                    )}
                    Remove
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
    </>
  );
}