import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Plus, 
  Edit, 
  Star, 
  Award, 
  TrendingUp,
  Search,
  Filter,
  Download,
  RefreshCw,
  Eye,
  Trash2,
  MoreVertical,
  X,
  Check,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Clock,
  Users,
  Car,
  DollarSign,
  FileText,
  MessageSquare,
  Send,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  ArrowLeft,
  Loader2,
  AlertCircle,
  CheckCircle,
  XCircle,
  Settings,
  Shield,
  ShieldCheck,
  Target,
  Zap,
  BarChart3,
  PieChart,
  Activity,
  Globe,
  Flag,
  BookOpen,
  GraduationCap,
  Briefcase,
  Building2,
  UserPlus,
  UserMinus,
  UserCheck,
  Copy,
  ExternalLink,
  Share2,
  Printer,
  Upload,
  Image,
  Camera,
  Hash,
  AtSign,
  CalendarDays,
  CalendarRange,
  Timer,
  Gauge,
  Route,
  Coffee,
  Sun,
  Moon,
  Sunrise,
  Sunset,
  Bell,
  BellOff,
  Lock,
  Unlock,
  Key,
  Fingerprint,
  CreditCard,
  Wallet,
  Receipt,
  Tag,
  Tags,
  Bookmark,
  Heart,
  ThumbsUp,
  ThumbsDown,
  MessageCircle,
  Info,
  HelpCircle,
  AlertTriangle,
  Ban,
  Play,
  Pause,
  RotateCcw,
  Sparkles
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  format, 
  parseISO, 
  differenceInYears,
  differenceInDays,
  startOfMonth,
  endOfMonth,
  isWithinInterval,
  isFuture,
  isPast,
  addDays
} from "date-fns";
import { toast } from "sonner";

const CERTIFICATIONS = [
  { id: "B", label: "Class B", description: "Standard car license" },
  { id: "A", label: "Class A", description: "Motorcycle license" },
  { id: "C", label: "Class C", description: "Heavy vehicle license" },
  { id: "D", label: "Class D", description: "Bus license" },
  { id: "BE", label: "Class BE", description: "Car with trailer" },
  { id: "CE", label: "Class CE", description: "Heavy vehicle with trailer" },
  { id: "DE", label: "Class DE", description: "Bus with trailer" },
  { id: "ADI", label: "ADI", description: "Approved Driving Instructor" },
  { id: "PDI", label: "PDI", description: "Potential Driving Instructor" },
  { id: "ORDIT", label: "ORDIT", description: "Instructor trainer qualification" }
];

const SPECIALIZATIONS = [
  { id: "manual", label: "Manual Transmission", icon: Gauge },
  { id: "automatic", label: "Automatic Transmission", icon: Zap },
  { id: "nervous", label: "Nervous Drivers", icon: Heart },
  { id: "intensive", label: "Intensive Courses", icon: Target },
  { id: "refresher", label: "Refresher Lessons", icon: RotateCcw },
  { id: "motorway", label: "Motorway Driving", icon: Route },
  { id: "night", label: "Night Driving", icon: Moon },
  { id: "defensive", label: "Defensive Driving", icon: Shield },
  { id: "eco", label: "Eco Driving", icon: Sparkles },
  { id: "pass_plus", label: "Pass Plus", icon: Award }
];

const INSTRUCTOR_STATUS = {
  active: { label: "Active", color: "green", icon: CheckCircle },
  inactive: { label: "Inactive", color: "gray", icon: XCircle },
  on_leave: { label: "On Leave", color: "amber", icon: Coffee },
  suspended: { label: "Suspended", color: "red", icon: Ban },
  pending: { label: "Pending Approval", color: "blue", icon: Clock }
};

const LANGUAGES = [
  "English", "German", "French", "Spanish", "Italian", "Portuguese", 
  "Dutch", "Polish", "Turkish", "Arabic", "Chinese", "Hindi", "Urdu",
  "Russian", "Japanese", "Korean", "Vietnamese"
];

export default function ManageInstructors() {
  const queryClient = useQueryClient();
  
  const [showForm, setShowForm] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [editingInstructor, setEditingInstructor] = useState(null);
  const [selectedInstructor, setSelectedInstructor] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [certificationFilter, setCertificationFilter] = useState("all");
  const [schoolFilter, setSchoolFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [viewMode, setViewMode] = useState("grid");
  const [showFilters, setShowFilters] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);

  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    school_id: "",
    bio: "",
    years_experience: 0,
    languages: [],
    certifications: [],
    specializations: [],
    hourly_rate: 0,
    commission_rate: 0,
    max_students: 20,
    max_hours_per_week: 40,
    preferred_areas: "",
    emergency_contact: "",
    emergency_phone: "",
    license_number: "",
    license_expiry: "",
    insurance_number: "",
    insurance_expiry: "",
    background_check_date: "",
    is_active: true,
    accepts_new_students: true,
    available_for_tests: true,
    notes: ""
  });

  const { data: instructors = [], isLoading: loadingInstructors, refetch } = useQuery({
    queryKey: ['instructors'],
    queryFn: () => base44.entities.Instructor.list('-created_date'),
  });

  const { data: schools = [] } = useQuery({
    queryKey: ['schools'],
    queryFn: () => base44.entities.School.list(),
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ['allBookings'],
    queryFn: () => base44.entities.Booking.list('-start_datetime', 1000),
  });

  const { data: students = [] } = useQuery({
    queryKey: ['students'],
    queryFn: () => base44.entities.Student.list(),
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ['vehicles'],
    queryFn: () => base44.entities.Vehicle.list(),
  });

  const { data: payments = [] } = useQuery({
    queryKey: ['payments'],
    queryFn: () => base44.entities.Payment.list('-payment_date', 500),
  });

  const { data: timeOffRequests = [] } = useQuery({
    queryKey: ['timeOffRequests'],
    queryFn: async () => {
      try {
        return await base44.entities.TimeOffRequest.list('-created_date', 100);
      } catch {
        return [];
      }
    },
  });

  const createInstructorMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.Instructor.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructors'] });
      resetForm();
      setShowForm(false);
      toast.success("Instructor created successfully");
    },
    onError: () => {
      toast.error("Failed to create instructor");
    }
  });

  const updateInstructorMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Instructor.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructors'] });
      resetForm();
      setShowForm(false);
      setEditingInstructor(null);
      toast.success("Instructor updated successfully");
    },
    onError: () => {
      toast.error("Failed to update instructor");
    }
  });

  const deleteInstructorMutation = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.Instructor.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructors'] });
      setShowDeleteConfirm(null);
      toast.success("Instructor deleted");
    },
    onError: () => {
      toast.error("Failed to delete instructor");
    }
  });

  const resetForm = () => {
    setFormData({
      full_name: "",
      email: "",
      phone: "",
      school_id: "",
      bio: "",
      years_experience: 0,
      languages: [],
      certifications: [],
      specializations: [],
      hourly_rate: 0,
      commission_rate: 0,
      max_students: 20,
      max_hours_per_week: 40,
      preferred_areas: "",
      emergency_contact: "",
      emergency_phone: "",
      license_number: "",
      license_expiry: "",
      insurance_number: "",
      insurance_expiry: "",
      background_check_date: "",
      is_active: true,
      accepts_new_students: true,
      available_for_tests: true,
      notes: ""
    });
    setEditingInstructor(null);
  };

  const openEditForm = (instructor) => {
    setEditingInstructor(instructor);
    setFormData({
      full_name: instructor.full_name || "",
      email: instructor.email || "",
      phone: instructor.phone || "",
      school_id: instructor.school_id || "",
      bio: instructor.bio || "",
      years_experience: instructor.years_experience || 0,
      languages: instructor.languages || [],
      certifications: instructor.certifications || [],
      specializations: instructor.specializations || [],
      hourly_rate: instructor.hourly_rate || 0,
      commission_rate: instructor.commission_rate || 0,
      max_students: instructor.max_students || 20,
      max_hours_per_week: instructor.max_hours_per_week || 40,
      preferred_areas: instructor.preferred_areas || "",
      emergency_contact: instructor.emergency_contact || "",
      emergency_phone: instructor.emergency_phone || "",
      license_number: instructor.license_number || "",
      license_expiry: instructor.license_expiry || "",
      insurance_number: instructor.insurance_number || "",
      insurance_expiry: instructor.insurance_expiry || "",
      background_check_date: instructor.background_check_date || "",
      is_active: instructor.is_active !== false,
      accepts_new_students: instructor.accepts_new_students !== false,
      available_for_tests: instructor.available_for_tests !== false,
      notes: instructor.notes || ""
    });
    setShowForm(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.full_name.trim()) {
      toast.error("Please enter instructor name");
      return;
    }

    if (!formData.email.trim()) {
      toast.error("Please enter email address");
      return;
    }

    if (!formData.school_id) {
      toast.error("Please select a school");
      return;
    }

    const submitData = {
      ...formData,
      years_experience: parseInt(formData.years_experience) || 0,
      hourly_rate: parseFloat(formData.hourly_rate) || 0,
      commission_rate: parseFloat(formData.commission_rate) || 0,
      max_students: parseInt(formData.max_students) || 20,
      max_hours_per_week: parseInt(formData.max_hours_per_week) || 40
    };

    if (editingInstructor) {
      updateInstructorMutation.mutate({ id: editingInstructor.id, data: submitData });
    } else {
      createInstructorMutation.mutate(submitData);
    }
  };

  const toggleArrayField = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(v => v !== value)
        : [...prev[field], value]
    }));
  };

  const getInstructorStats = useCallback((instructorId) => {
    const instructorBookings = bookings.filter(b => b.instructor_id === instructorId);
    const completedLessons = instructorBookings.filter(b => b.status === "completed").length;
    const upcomingLessons = instructorBookings.filter(b => 
      (b.status === "confirmed" || b.status === "pending") && 
      isFuture(new Date(b.start_datetime))
    ).length;
    
    const assignedStudents = [...new Set(instructorBookings.map(b => b.student_id))].length;
    
    const thisMonth = { start: startOfMonth(new Date()), end: endOfMonth(new Date()) };
    const monthlyBookings = instructorBookings.filter(b => {
      const date = new Date(b.start_datetime);
      return isWithinInterval(date, thisMonth);
    });
    
    const monthlyHours = monthlyBookings.reduce((sum, b) => {
      const duration = (new Date(b.end_datetime) - new Date(b.start_datetime)) / (1000 * 60 * 60);
      return sum + duration;
    }, 0);

    const monthlyRevenue = monthlyBookings.reduce((sum, b) => sum + (b.price || 0), 0);
    
    const cancelledLessons = instructorBookings.filter(b => 
      b.status === "cancelled" || b.status === "no_show"
    ).length;
    
    const cancellationRate = instructorBookings.length > 0 
      ? Math.round((cancelledLessons / instructorBookings.length) * 100)
      : 0;

    const instructorTimeOff = timeOffRequests.filter(t => t.instructor_id === instructorId);
    const pendingTimeOff = instructorTimeOff.filter(t => t.status === "pending").length;

    return {
      completedLessons,
      upcomingLessons,
      totalLessons: instructorBookings.length,
      assignedStudents,
      monthlyHours: Math.round(monthlyHours * 10) / 10,
      monthlyRevenue,
      cancellationRate,
      pendingTimeOff
    };
  }, [bookings, timeOffRequests]);

  const enrichedInstructors = useMemo(() => {
    return instructors.map(instructor => ({
      ...instructor,
      stats: getInstructorStats(instructor.id),
      school: schools.find(s => s.id === instructor.school_id)
    }));
  }, [instructors, schools, getInstructorStats]);

  const filteredInstructors = useMemo(() => {
    let filtered = [...enrichedInstructors];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(i =>
        i.full_name?.toLowerCase().includes(query) ||
        i.email?.toLowerCase().includes(query) ||
        i.phone?.includes(searchQuery)
      );
    }

    if (statusFilter !== "all") {
      if (statusFilter === "active") {
        filtered = filtered.filter(i => i.is_active !== false);
      } else if (statusFilter === "inactive") {
        filtered = filtered.filter(i => i.is_active === false);
      }
    }

    if (certificationFilter !== "all") {
      filtered = filtered.filter(i => i.certifications?.includes(certificationFilter));
    }

    if (schoolFilter !== "all") {
      filtered = filtered.filter(i => i.school_id === schoolFilter);
    }

    filtered.sort((a, b) => {
      let comparison = 0;
      
      if (sortBy === "name") {
        comparison = (a.full_name || "").localeCompare(b.full_name || "");
      } else if (sortBy === "lessons") {
        comparison = (a.stats.completedLessons || 0) - (b.stats.completedLessons || 0);
      } else if (sortBy === "rating") {
        comparison = (a.rating || 0) - (b.rating || 0);
      } else if (sortBy === "experience") {
        comparison = (a.years_experience || 0) - (b.years_experience || 0);
      } else if (sortBy === "students") {
        comparison = (a.stats.assignedStudents || 0) - (b.stats.assignedStudents || 0);
      }

      return sortOrder === "asc" ? comparison : -comparison;
    });

    return filtered;
  }, [enrichedInstructors, searchQuery, statusFilter, certificationFilter, schoolFilter, sortBy, sortOrder]);

  const stats = useMemo(() => {
    const active = enrichedInstructors.filter(i => i.is_active !== false).length;
    const totalLessons = enrichedInstructors.reduce((sum, i) => sum + i.stats.completedLessons, 0);
    const totalStudents = enrichedInstructors.reduce((sum, i) => sum + i.stats.assignedStudents, 0);
    const avgRating = enrichedInstructors.length > 0
      ? enrichedInstructors.reduce((sum, i) => sum + (i.rating || 5), 0) / enrichedInstructors.length
      : 0;
    const avgExperience = enrichedInstructors.length > 0
      ? enrichedInstructors.reduce((sum, i) => sum + (i.years_experience || 0), 0) / enrichedInstructors.length
      : 0;

    return {
      total: enrichedInstructors.length,
      active,
      inactive: enrichedInstructors.length - active,
      totalLessons,
      totalStudents,
      avgRating: Math.round(avgRating * 10) / 10,
      avgExperience: Math.round(avgExperience)
    };
  }, [enrichedInstructors]);

  const viewInstructorDetails = (instructor) => {
    setSelectedInstructor(instructor);
    setShowDetailsModal(true);
  };

  const exportInstructors = () => {
    toast.success("Instructor data exported");
  };

  if (loadingInstructors) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading instructors...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Link
          to={createPageUrl("AdminDashboard")}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Manage Instructors
            </h1>
            <p className="text-gray-600 mt-1">View and manage your instructor team</p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => refetch()}
              className="p-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              <RefreshCw className="w-5 h-5 text-gray-600" />
            </button>
            <button
              onClick={exportInstructors}
              className="p-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              <Download className="w-5 h-5 text-gray-600" />
            </button>
            <button
              onClick={() => {
                resetForm();
                setShowForm(true);
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Add Instructor
            </button>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
        {[
          { label: "Total", value: stats.total, icon: Users, color: "indigo" },
          { label: "Active", value: stats.active, icon: CheckCircle, color: "green" },
          { label: "Inactive", value: stats.inactive, icon: XCircle, color: "gray" },
          { label: "Lessons", value: stats.totalLessons, icon: Calendar, color: "blue" },
          { label: "Students", value: stats.totalStudents, icon: GraduationCap, color: "purple" },
          { label: "Avg Rating", value: stats.avgRating, icon: Star, color: "amber", suffix: "/5" },
          { label: "Avg Experience", value: stats.avgExperience, icon: Award, color: "cyan", suffix: " yrs" }
        ].map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.03 }}
            className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm"
          >
            <div className={`w-10 h-10 bg-${stat.color}-100 rounded-xl flex items-center justify-center mb-2`}>
              <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}{stat.suffix}</p>
            <p className="text-xs text-gray-600">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm space-y-4"
      >
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name, email, or phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          <div className="flex gap-2 flex-wrap">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>

            <select
              value={certificationFilter}
              onChange={(e) => setCertificationFilter(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Certifications</option>
              {CERTIFICATIONS.map(cert => (
                <option key={cert.id} value={cert.id}>{cert.label}</option>
              ))}
            </select>

            <select
              value={schoolFilter}
              onChange={(e) => setSchoolFilter(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Schools</option>
              {schools.map(school => (
                <option key={school.id} value={school.id}>{school.name}</option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="name">Sort by Name</option>
              <option value="lessons">Sort by Lessons</option>
              <option value="rating">Sort by Rating</option>
              <option value="experience">Sort by Experience</option>
              <option value="students">Sort by Students</option>
            </select>

            <button
              onClick={() => setSortOrder(prev => prev === "asc" ? "desc" : "asc")}
              className="p-3 border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              {sortOrder === "asc" ? (
                <ChevronUp className="w-5 h-5 text-gray-600" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-600" />
              )}
            </button>

            <div className="flex gap-1 p-1 bg-gray-100 rounded-xl">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-lg transition ${viewMode === "grid" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
              >
                <BarChart3 className="w-5 h-5 text-gray-600" />
              </button>
              <button
                onClick={() => setViewMode("table")}
                className={`p-2 rounded-lg transition ${viewMode === "table" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
              >
                <FileText className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>

        <div className="text-sm text-gray-600">
          Showing {filteredInstructors.length} instructor{filteredInstructors.length !== 1 ? 's' : ''}
        </div>
      </motion.div>

      {filteredInstructors.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">No instructors found</h3>
          <p className="text-gray-600 mb-6">
            {searchQuery || statusFilter !== "all" || certificationFilter !== "all"
              ? "Try adjusting your filters"
              : "Get started by adding your first instructor"
            }
          </p>
          <button
            onClick={() => {
              resetForm();
              setShowForm(true);
            }}
            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition inline-flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Instructor
          </button>
        </div>
      ) : viewMode === "grid" ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredInstructors.map((instructor, index) => (
            <motion.div
              key={instructor.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.03 }}
              className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-2xl flex items-center justify-center">
                    <span className="text-white text-xl font-bold">
                      {instructor.full_name?.charAt(0) || "I"}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 text-lg">{instructor.full_name}</h3>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                      <span className="font-semibold text-gray-700 text-sm">
                        {instructor.rating?.toFixed(1) || "5.0"}
                      </span>
                      <span className="text-gray-500 text-xs">
                        ({instructor.stats.completedLessons} lessons)
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => viewInstructorDetails(instructor)}
                    className="p-2 hover:bg-gray-100 rounded-lg transition"
                  >
                    <Eye className="w-4 h-4 text-gray-600" />
                  </button>
                  <button
                    onClick={() => openEditForm(instructor)}
                    className="p-2 hover:bg-gray-100 rounded-lg transition"
                  >
                    <Edit className="w-4 h-4 text-gray-600" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-3 bg-indigo-50 rounded-xl text-center">
                  <p className="text-2xl font-bold text-indigo-600">{instructor.stats.completedLessons}</p>
                  <p className="text-xs text-indigo-900">Lessons</p>
                </div>
                <div className="p-3 bg-purple-50 rounded-xl text-center">
                  <p className="text-2xl font-bold text-purple-600">{instructor.stats.assignedStudents}</p>
                  <p className="text-xs text-purple-900">Students</p>
                </div>
                <div className="p-3 bg-green-50 rounded-xl text-center">
                  <p className="text-2xl font-bold text-green-600">{instructor.years_experience || 0}</p>
                  <p className="text-xs text-green-900">Years Exp.</p>
                </div>
                <div className="p-3 bg-amber-50 rounded-xl text-center">
                  <p className="text-2xl font-bold text-amber-600">{instructor.stats.upcomingLessons}</p>
                  <p className="text-xs text-amber-900">Upcoming</p>
                </div>
              </div>

              {instructor.certifications?.length > 0 && (
                <div className="mb-4">
                  <p className="text-xs text-gray-600 mb-2">Certifications</p>
                  <div className="flex flex-wrap gap-1">
                    {instructor.certifications.slice(0, 5).map((cert) => (
                      <span key={cert} className="px-2 py-1 bg-gray-100 rounded-lg text-xs font-semibold text-gray-700">
                        {cert}
                      </span>
                    ))}
                    {instructor.certifications.length > 5 && (
                      <span className="px-2 py-1 bg-gray-100 rounded-lg text-xs text-gray-500">
                        +{instructor.certifications.length - 5}
                      </span>
                    )}
                  </div>
                </div>
              )}

              {instructor.languages?.length > 0 && (
                <div className="mb-4">
                  <p className="text-xs text-gray-600 mb-2">Languages</p>
                  <div className="flex flex-wrap gap-1">
                    {instructor.languages.slice(0, 3).map((lang) => (
                      <span key={lang} className="px-2 py-1 bg-blue-50 rounded-lg text-xs text-blue-700">
                        {lang}
                      </span>
                    ))}
                    {instructor.languages.length > 3 && (
                      <span className="px-2 py-1 bg-gray-100 rounded-lg text-xs text-gray-500">
                        +{instructor.languages.length - 3}
                      </span>
                    )}
                  </div>
                </div>
              )}

              <div className="pt-4 border-t border-gray-200 flex items-center justify-between">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                  instructor.is_active !== false 
                    ? "bg-green-100 text-green-700" 
                    : "bg-gray-100 text-gray-600"
                }`}>
                  {instructor.is_active !== false ? "Active" : "Inactive"}
                </span>
                <span className="text-xs text-gray-500">
                  {instructor.school?.name || "No school"}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Instructor</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Contact</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Certifications</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Stats</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Rating</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
                  <th className="px-6 py-4 text-right text-xs font-bold text-gray-600 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredInstructors.map((instructor, index) => (
                  <motion.tr
                    key={instructor.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: index * 0.02 }}
                    className="hover:bg-gray-50 transition"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center flex-shrink-0">
                          <span className="text-white font-bold">
                            {instructor.full_name?.charAt(0) || "I"}
                          </span>
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">{instructor.full_name}</p>
                          <p className="text-sm text-gray-600">{instructor.years_experience || 0} years exp.</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-gray-900">{instructor.email}</p>
                      <p className="text-sm text-gray-600">{instructor.phone || "—"}</p>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-wrap gap-1">
                        {instructor.certifications?.slice(0, 3).map(cert => (
                          <span key={cert} className="px-2 py-0.5 bg-gray-100 rounded text-xs font-semibold text-gray-700">
                            {cert}
                          </span>
                        ))}
                        {instructor.certifications?.length > 3 && (
                          <span className="text-xs text-gray-500">+{instructor.certifications.length - 3}</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm">
                        <p className="text-gray-900">{instructor.stats.completedLessons} lessons</p>
                        <p className="text-gray-600">{instructor.stats.assignedStudents} students</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                        <span className="font-semibold text-gray-900">
                          {instructor.rating?.toFixed(1) || "5.0"}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                        instructor.is_active !== false 
                          ? "bg-green-100 text-green-700" 
                          : "bg-gray-100 text-gray-600"
                      }`}>
                        {instructor.is_active !== false ? "Active" : "Inactive"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => viewInstructorDetails(instructor)}
                          className="p-2 hover:bg-gray-100 rounded-lg transition"
                        >
                          <Eye className="w-4 h-4 text-gray-600" />
                        </button>
                        <button
                          onClick={() => openEditForm(instructor)}
                          className="p-2 hover:bg-gray-100 rounded-lg transition"
                        >
                          <Edit className="w-4 h-4 text-gray-600" />
                        </button>
                        <button
                          onClick={() => setShowDeleteConfirm(instructor.id)}
                          className="p-2 hover:bg-red-50 rounded-lg transition"
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => { setShowForm(false); resetForm(); }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
            >
              <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between z-10">
                <h2 className="text-xl font-bold text-gray-900">
                  {editingInstructor ? "Edit Instructor" : "Add New Instructor"}
                </h2>
                <button
                  onClick={() => { setShowForm(false); resetForm(); }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-6">
                <div className="flex gap-2 border-b border-gray-200 pb-4">
                  {[
                    { id: "basic", label: "Basic Info" },
                    { id: "qualifications", label: "Qualifications" },
                    { id: "employment", label: "Employment" },
                    { id: "compliance", label: "Compliance" }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setActiveTab(tab.id)}
                      className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${
                        activeTab === tab.id
                          ? "bg-indigo-100 text-indigo-700"
                          : "text-gray-600 hover:bg-gray-100"
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                {activeTab === "basic" && (
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                        <input
                          type="text"
                          value={formData.full_name}
                          onChange={(e) => setFormData(prev => ({ ...prev, full_name: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                        <input
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">School *</label>
                        <select
                          value={formData.school_id}
                          onChange={(e) => setFormData(prev => ({ ...prev, school_id: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          required
                        >
                          <option value="">Select a school</option>
                          {schools.map(school => (
                            <option key={school.id} value={school.id}>{school.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Bio</label>
                      <textarea
                        value={formData.bio}
                        onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                        rows={3}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                        placeholder="Brief description about the instructor..."
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Emergency Contact</label>
                        <input
                          type="text"
                          value={formData.emergency_contact}
                          onChange={(e) => setFormData(prev => ({ ...prev, emergency_contact: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Emergency Phone</label>
                        <input
                          type="tel"
                          value={formData.emergency_phone}
                          onChange={(e) => setFormData(prev => ({ ...prev, emergency_phone: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "qualifications" && (
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Years of Experience</label>
                        <input
                          type="number"
                          value={formData.years_experience}
                          onChange={(e) => setFormData(prev => ({ ...prev, years_experience: e.target.value }))}
                          min="0"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Areas</label>
                        <input
                          type="text"
                          value={formData.preferred_areas}
                          onChange={(e) => setFormData(prev => ({ ...prev, preferred_areas: e.target.value }))}
                          placeholder="e.g., London, Manchester"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-3">Certifications</label>
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                        {CERTIFICATIONS.map(cert => (
                          <button
                            key={cert.id}
                            type="button"
                            onClick={() => toggleArrayField("certifications", cert.id)}
                            className={`p-3 rounded-xl border-2 transition text-center ${
                              formData.certifications.includes(cert.id)
                                ? "border-indigo-500 bg-indigo-50 text-indigo-700"
                                : "border-gray-200 hover:border-gray-300"
                            }`}
                          >
                            <p className="font-bold text-sm">{cert.id}</p>
                            <p className="text-xs text-gray-600">{cert.label}</p>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-3">Specializations</label>
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                        {SPECIALIZATIONS.map(spec => (
                          <button
                            key={spec.id}
                            type="button"
                            onClick={() => toggleArrayField("specializations", spec.id)}
                            className={`p-3 rounded-xl border-2 transition text-center ${
                              formData.specializations.includes(spec.id)
                                ? "border-purple-500 bg-purple-50 text-purple-700"
                                : "border-gray-200 hover:border-gray-300"
                            }`}
                          >
                            <spec.icon className="w-4 h-4 mx-auto mb-1" />
                            <p className="text-xs font-semibold">{spec.label}</p>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-3">Languages</label>
                      <div className="flex flex-wrap gap-2">
                        {LANGUAGES.map(lang => (
                          <button
                            key={lang}
                            type="button"
                            onClick={() => toggleArrayField("languages", lang)}
                            className={`px-3 py-2 rounded-lg text-sm font-semibold transition ${
                              formData.languages.includes(lang)
                                ? "bg-blue-100 text-blue-700 border-2 border-blue-300"
                                : "bg-gray-100 text-gray-700 border-2 border-transparent hover:bg-gray-200"
                            }`}
                          >
                            {lang}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "employment" && (
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Hourly Rate (€)</label>
                        <input
                          type="number"
                          value={formData.hourly_rate}
                          onChange={(e) => setFormData(prev => ({ ...prev, hourly_rate: e.target.value }))}
                          min="0"
                          step="0.01"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Commission Rate (%)</label>
                        <input
                          type="number"
                          value={formData.commission_rate}
                          onChange={(e) => setFormData(prev => ({ ...prev, commission_rate: e.target.value }))}
                          min="0"
                          max="100"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Max Students</label>
                        <input
                          type="number"
                          value={formData.max_students}
                          onChange={(e) => setFormData(prev => ({ ...prev, max_students: e.target.value }))}
                          min="1"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Max Hours/Week</label>
                        <input
                          type="number"
                          value={formData.max_hours_per_week}
                          onChange={(e) => setFormData(prev => ({ ...prev, max_hours_per_week: e.target.value }))}
                          min="1"
                          max="60"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.is_active}
                          onChange={(e) => setFormData(prev => ({ ...prev, is_active: e.target.checked }))}
                          className="w-5 h-5 text-indigo-600 rounded"
                        />
                        <div>
                          <p className="font-semibold text-gray-900">Active Status</p>
                          <p className="text-sm text-gray-600">Instructor is available for bookings</p>
                        </div>
                      </label>

                      <label className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.accepts_new_students}
                          onChange={(e) => setFormData(prev => ({ ...prev, accepts_new_students: e.target.checked }))}
                          className="w-5 h-5 text-indigo-600 rounded"
                        />
                        <div>
                          <p className="font-semibold text-gray-900">Accepts New Students</p>
                          <p className="text-sm text-gray-600">Can be assigned to new students</p>
                        </div>
                      </label>

                      <label className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.available_for_tests}
                          onChange={(e) => setFormData(prev => ({ ...prev, available_for_tests: e.target.checked }))}
                          className="w-5 h-5 text-indigo-600 rounded"
                        />
                        <div>
                          <p className="font-semibold text-gray-900">Available for Tests</p>
                          <p className="text-sm text-gray-600">Can accompany students to driving tests</p>
                        </div>
                      </label>
                    </div>
                  </div>
                )}

                {activeTab === "compliance" && (
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">License Number</label>
                        <input
                          type="text"
                          value={formData.license_number}
                          onChange={(e) => setFormData(prev => ({ ...prev, license_number: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">License Expiry</label>
                        <input
                          type="date"
                          value={formData.license_expiry}
                          onChange={(e) => setFormData(prev => ({ ...prev, license_expiry: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Insurance Number</label>
                        <input
                          type="text"
                          value={formData.insurance_number}
                          onChange={(e) => setFormData(prev => ({ ...prev, insurance_number: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Insurance Expiry</label>
                        <input
                          type="date"
                          value={formData.insurance_expiry}
                          onChange={(e) => setFormData(prev => ({ ...prev, insurance_expiry: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Background Check Date</label>
                      <input
                        type="date"
                        value={formData.background_check_date}
                        onChange={(e) => setFormData(prev => ({ ...prev, background_check_date: e.target.value }))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Internal Notes</label>
                      <textarea
                        value={formData.notes}
                        onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                        rows={3}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                        placeholder="Internal notes about this instructor..."
                      />
                    </div>
                  </div>
                )}

                <div className="flex gap-3 pt-4 border-t border-gray-200">
                  <button
                    type="button"
                    onClick={() => { setShowForm(false); resetForm(); }}
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={createInstructorMutation.isPending || updateInstructorMutation.isPending}
                    className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {(createInstructorMutation.isPending || updateInstructorMutation.isPending) ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <Check className="w-5 h-5" />
                    )}
                    {editingInstructor ? "Update Instructor" : "Create Instructor"}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showDetailsModal && selectedInstructor && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => { setShowDetailsModal(false); setSelectedInstructor(null); }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Instructor Details</h3>
                <button
                  onClick={() => { setShowDetailsModal(false); setSelectedInstructor(null); }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-2xl flex items-center justify-center">
                    <span className="text-white text-3xl font-bold">
                      {selectedInstructor.full_name?.charAt(0) || "I"}
                    </span>
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{selectedInstructor.full_name}</h2>
                    <div className="flex items-center gap-2 mt-1">
                      <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                      <span className="font-bold text-gray-900">{selectedInstructor.rating?.toFixed(1) || "5.0"}</span>
                      <span className="text-gray-600">• {selectedInstructor.years_experience || 0} years experience</span>
                    </div>
                    <span className={`inline-block mt-2 px-3 py-1 rounded-full text-xs font-bold ${
                      selectedInstructor.is_active !== false 
                        ? "bg-green-100 text-green-700" 
                        : "bg-gray-100 text-gray-600"
                    }`}>
                      {selectedInstructor.is_active !== false ? "Active" : "Inactive"}
                    </span>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  {selectedInstructor.email && (
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                      <Mail className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-xs text-gray-500">Email</p>
                        <p className="font-semibold text-gray-900">{selectedInstructor.email}</p>
                      </div>
                    </div>
                  )}
                  {selectedInstructor.phone && (
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                      <Phone className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-xs text-gray-500">Phone</p>
                        <p className="font-semibold text-gray-900">{selectedInstructor.phone}</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="p-4 bg-indigo-50 rounded-xl text-center">
                    <p className="text-3xl font-bold text-indigo-600">{selectedInstructor.stats.completedLessons}</p>
                    <p className="text-xs text-indigo-900">Completed Lessons</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-xl text-center">
                    <p className="text-3xl font-bold text-purple-600">{selectedInstructor.stats.assignedStudents}</p>
                    <p className="text-xs text-purple-900">Students</p>
                  </div>
                  <div className="p-4 bg-green-50 rounded-xl text-center">
                    <p className="text-3xl font-bold text-green-600">{selectedInstructor.stats.monthlyHours}</p>
                    <p className="text-xs text-green-900">Hours This Month</p>
                  </div>
                  <div className="p-4 bg-amber-50 rounded-xl text-center">
                    <p className="text-3xl font-bold text-amber-600">€{selectedInstructor.stats.monthlyRevenue}</p>
                    <p className="text-xs text-amber-900">Revenue This Month</p>
                  </div>
                </div>

                {selectedInstructor.certifications?.length > 0 && (
                  <div>
                    <h4 className="font-bold text-gray-900 mb-2">Certifications</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedInstructor.certifications.map(cert => (
                        <span key={cert} className="px-3 py-1.5 bg-indigo-100 text-indigo-700 rounded-lg text-sm font-semibold">
                          {cert}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {selectedInstructor.languages?.length > 0 && (
                  <div>
                    <h4 className="font-bold text-gray-900 mb-2">Languages</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedInstructor.languages.map(lang => (
                        <span key={lang} className="px-3 py-1.5 bg-blue-50 text-blue-700 rounded-lg text-sm">
                          {lang}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {selectedInstructor.bio && (
                  <div>
                    <h4 className="font-bold text-gray-900 mb-2">Bio</h4>
                    <p className="text-gray-600">{selectedInstructor.bio}</p>
                  </div>
                )}

                <div className="flex gap-3 pt-4 border-t border-gray-200">
                  <button
                    onClick={() => {
                      setShowDetailsModal(false);
                      openEditForm(selectedInstructor);
                    }}
                    className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                  >
                    <Edit className="w-4 h-4" />
                    Edit Instructor
                  </button>
                  {selectedInstructor.phone && (
                    <a
                      href={`tel:${selectedInstructor.phone}`}
                      className="flex-1 px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-xl font-semibold transition flex items-center justify-center gap-2"
                    >
                      <Phone className="w-4 h-4" />
                      Call
                    </a>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showDeleteConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowDeleteConfirm(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertTriangle className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Delete Instructor</h3>
                <p className="text-gray-600 mb-6">
                  Are you sure you want to delete this instructor? This action cannot be undone.
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowDeleteConfirm(null)}
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => deleteInstructorMutation.mutate(showDeleteConfirm)}
                    disabled={deleteInstructorMutation.isPending}
                    className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {deleteInstructorMutation.isPending ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <Trash2 className="w-5 h-5" />
                    )}
                    Delete
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}