import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  DollarSign, 
  TrendingUp, 
  Download, 
  Calendar, 
  User, 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  PieChart, 
  Plus, 
  CreditCard, 
  AlertCircle,
  TrendingDown,
  Target,
  Award,
  FileText,
  Eye,
  Edit,
  Trash2,
  Mail,
  Phone,
  MapPin,
  ArrowLeft,
  Filter,
  Search,
  ChevronDown,
  ChevronUp,
  BarChart3,
  Percent,
  Wallet,
  Receipt,
  Share2,
  Printer,
  RefreshCw,
  Info,
  CheckCircle,
  XCircle,
  Loader2,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  Sparkles,
  Zap,
  Star,
  Users,
  Package
} from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, differenceInDays, isWithinInterval, parseISO, addDays, startOfWeek, endOfWeek, startOfYear } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RechartsChart, Pie, Cell, BarChart, Bar, AreaChart, Area } from "recharts";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";
import InvoiceForm from "@/components/finance/InvoiceForm";

export default function InstructorEarnings() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const [user, setUser] = useState(null);
  const [instructor, setInstructor] = useState(null);
  const [selectedPeriod, setSelectedPeriod] = useState("month");
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [dateRange, setDateRange] = useState("all");
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState("date-desc");
  const [isLoading, setIsLoading] = useState(true);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPaymentInvoice, setSelectedPaymentInvoice] = useState(null);
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [expandedInvoice, setExpandedInvoice] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        setIsLoading(true);
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        const instructors = await base44.entities.Instructor.filter({ email: currentUser.email });
        if (instructors.length > 0) {
          setInstructor(instructors[0]);
        }
      } catch (error) {
        console.error("Error loading user:", error);
        toast.error("Failed to load user data");
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: invoices = [], isLoading: loadingInvoices } = useQuery({
    queryKey: ['instructorInvoices', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      return await base44.entities.Invoice.filter(
        { instructor_id: instructor.id },
        '-issue_date'
      );
    },
    enabled: !!instructor,
  });

  const { data: bookings = [] } = useQuery({
    queryKey: ['instructorBookings', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      return await base44.entities.Booking.filter(
        { instructor_id: instructor.id },
        '-start_datetime'
      );
    },
    enabled: !!instructor,
  });

  const { data: students = [] } = useQuery({
    queryKey: ['students'],
    queryFn: () => base44.entities.Student.list(),
  });

  const { data: payments = [] } = useQuery({
    queryKey: ['instructorPayments', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      try {
        return await base44.entities.Payment.filter(
          { instructor_id: instructor.id },
          '-payment_date'
        );
      } catch {
        return [];
      }
    },
    enabled: !!instructor,
  });

  const createInvoiceMutation = useMutation({
    mutationFn: (data) => base44.entities.Invoice.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorInvoices'] });
      setShowInvoiceForm(false);
      setSelectedInvoice(null);
      toast.success("Invoice created successfully");
    },
    onError: (error) => {
      console.error("Invoice creation error:", error);
      toast.error("Failed to create invoice");
    }
  });

  const updateInvoiceMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Invoice.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorInvoices'] });
      setShowInvoiceForm(false);
      setSelectedInvoice(null);
      toast.success("Invoice updated successfully");
    },
    onError: (error) => {
      console.error("Invoice update error:", error);
      toast.error("Failed to update invoice");
    }
  });

  const recordPaymentMutation = useMutation({
    mutationFn: async ({ invoiceId, amount, method }) => {
      const invoice = invoices.find(inv => inv.id === invoiceId);
      const newAmountPaid = (invoice.amount_paid || 0) + amount;
      const isFullyPaid = newAmountPaid >= invoice.total_amount;
      
      const paymentData = {
        school_id: instructor.school_id,
        student_id: invoice.student_id,
        booking_id: invoice.booking_id,
        amount: amount,
        payment_method: method,
        payment_type: "lesson",
        status: "completed",
        payment_date: new Date().toISOString()
      };
      
      await base44.entities.Payment.create(paymentData);
      
      await base44.entities.Invoice.update(invoiceId, { 
        amount_paid: newAmountPaid,
        status: isFullyPaid ? "paid" : "partially_paid",
        paid_date: isFullyPaid ? new Date().toISOString() : invoice.paid_date
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorInvoices'] });
      queryClient.invalidateQueries({ queryKey: ['instructorPayments'] });
      setShowPaymentModal(false);
      setSelectedPaymentInvoice(null);
      setPaymentAmount("");
      toast.success("Payment recorded successfully");
    },
    onError: (error) => {
      console.error("Payment recording error:", error);
      toast.error("Failed to record payment");
    }
  });

  const assignedStudentIds = useMemo(() => 
    [...new Set(bookings.map(b => b.student_id))],
    [bookings]
  );

  const myStudents = useMemo(() => 
    students.filter(s => assignedStudentIds.includes(s.id)),
    [students, assignedStudentIds]
  );

  const stats = useMemo(() => {
    const totalEarned = invoices
      .filter(inv => inv.status === "paid")
      .reduce((sum, inv) => sum + (inv.instructor_earnings || inv.total_amount || 0), 0);

    const pendingEarnings = invoices
      .filter(inv => inv.status !== "paid" && inv.status !== "cancelled")
      .reduce((sum, inv) => sum + (inv.instructor_earnings || inv.total_amount || 0) - (inv.amount_paid || 0), 0);

    const paidInvoices = invoices.filter(inv => inv.status === "paid");
    const unpaidInvoices = invoices.filter(inv => inv.status !== "paid" && inv.status !== "cancelled");
    const overdueInvoices = invoices.filter(inv => 
      inv.status === "overdue" || 
      (inv.due_date && new Date(inv.due_date) < new Date() && inv.status !== "paid")
    );

    const completedLessons = bookings.filter(b => b.status === "completed").length;
    const upcomingLessons = bookings.filter(b => 
      b.status === "confirmed" && new Date(b.start_datetime) > new Date()
    ).length;

    const conversionRate = invoices.length > 0 
      ? ((paidInvoices.length / invoices.length) * 100) 
      : 0;

    const avgInvoiceValue = invoices.length > 0
      ? invoices.reduce((sum, inv) => sum + (inv.total_amount || 0), 0) / invoices.length
      : 0;

    const thisMonthEarnings = invoices
      .filter(inv => {
        const invoiceDate = new Date(inv.issue_date);
        const monthStart = startOfMonth(new Date());
        const monthEnd = endOfMonth(new Date());
        return inv.status === "paid" && invoiceDate >= monthStart && invoiceDate <= monthEnd;
      })
      .reduce((sum, inv) => sum + (inv.instructor_earnings || inv.total_amount || 0), 0);

    const lastMonthEarnings = invoices
      .filter(inv => {
        const invoiceDate = new Date(inv.issue_date);
        const monthStart = startOfMonth(subMonths(new Date(), 1));
        const monthEnd = endOfMonth(subMonths(new Date(), 1));
        return inv.status === "paid" && invoiceDate >= monthStart && invoiceDate <= monthEnd;
      })
      .reduce((sum, inv) => sum + (inv.instructor_earnings || inv.total_amount || 0), 0);

    const growthRate = lastMonthEarnings > 0
      ? ((thisMonthEarnings - lastMonthEarnings) / lastMonthEarnings) * 100
      : 0;

    return {
      totalEarned,
      pendingEarnings,
      paidCount: paidInvoices.length,
      unpaidCount: unpaidInvoices.length,
      overdueCount: overdueInvoices.length,
      completedLessons,
      upcomingLessons,
      conversionRate,
      avgInvoiceValue,
      thisMonthEarnings,
      lastMonthEarnings,
      growthRate,
      totalInvoices: invoices.length
    };
  }, [invoices, bookings]);

  const revenueByStudent = useMemo(() => {
    const studentRevenue = {};
    invoices.forEach(inv => {
      const studentId = inv.student_id;
      if (!studentRevenue[studentId]) {
        studentRevenue[studentId] = {
          studentId,
          studentName: students.find(s => s.id === studentId)?.full_name || "Unknown",
          revenue: 0,
          invoiceCount: 0
        };
      }
      if (inv.status === "paid") {
        studentRevenue[studentId].revenue += (inv.instructor_earnings || inv.total_amount || 0);
      }
      studentRevenue[studentId].invoiceCount++;
    });

    return Object.values(studentRevenue)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [invoices, students]);

  const revenueByType = useMemo(() => {
    const typeRevenue = {};
    invoices.forEach(inv => {
      if (inv.status !== "paid") return;
      const type = inv.lesson_type || "standard";
      if (!typeRevenue[type]) {
        typeRevenue[type] = 0;
      }
      typeRevenue[type] += (inv.instructor_earnings || inv.total_amount || 0);
    });

    return Object.entries(typeRevenue).map(([type, revenue]) => ({
      name: type.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase()),
      value: revenue,
    }));
  }, [invoices]);

  const monthlyData = useMemo(() => {
    const data = [];
    for (let i = 11; i >= 0; i--) {
      const date = subMonths(new Date(), i);
      const monthStart = startOfMonth(date);
      const monthEnd = endOfMonth(date);
      
      const monthInvoices = invoices.filter(inv => {
        const issueDate = new Date(inv.issue_date);
        return inv.status === "paid" && issueDate >= monthStart && issueDate <= monthEnd;
      });
      
      const revenue = monthInvoices.reduce((sum, inv) => 
        sum + (inv.instructor_earnings || inv.total_amount || 0), 0
      );
      
      const monthLessons = bookings.filter(b => {
        const bookingDate = new Date(b.start_datetime);
        return b.status === "completed" && bookingDate >= monthStart && bookingDate <= monthEnd;
      }).length;
      
      data.push({
        month: format(date, "MMM"),
        revenue: revenue,
        lessons: monthLessons,
        invoices: monthInvoices.length
      });
    }
    return data;
  }, [invoices, bookings]);

  const filteredAndSortedInvoices = useMemo(() => {
    let filtered = invoices;

    if (filterStatus !== "all") {
      filtered = filtered.filter(inv => inv.status === filterStatus);
    }

    if (searchTerm) {
      filtered = filtered.filter(inv => {
        const student = students.find(s => s.id === inv.student_id);
        return (
          inv.invoice_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          student?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          inv.notes?.toLowerCase().includes(searchTerm.toLowerCase())
        );
      });
    }

    if (dateRange !== "all") {
      const now = new Date();
      filtered = filtered.filter(inv => {
        const invoiceDate = new Date(inv.issue_date);
        
        if (dateRange === "month") {
          return differenceInDays(now, invoiceDate) <= 30;
        } else if (dateRange === "quarter") {
          return differenceInDays(now, invoiceDate) <= 90;
        } else if (dateRange === "year") {
          return differenceInDays(now, invoiceDate) <= 365;
        }
        return true;
      });
    }

    filtered.sort((a, b) => {
      if (sortBy === "date-desc") {
        return new Date(b.issue_date).getTime() - new Date(a.issue_date).getTime();
      } else if (sortBy === "date-asc") {
        return new Date(a.issue_date).getTime() - new Date(b.issue_date).getTime();
      } else if (sortBy === "amount-desc") {
        return (b.total_amount || 0) - (a.total_amount || 0);
      } else if (sortBy === "amount-asc") {
        return (a.total_amount || 0) - (b.total_amount || 0);
      } else if (sortBy === "status") {
        return a.status.localeCompare(b.status);
      }
      return 0;
    });

    return filtered;
  }, [invoices, filterStatus, searchTerm, dateRange, sortBy, students]);

  const COLORS = ['#3b82c4', '#6c376f', '#e44138', '#e7d356', '#81da5a', '#a9d5ed'];

  const handleExportEarnings = () => {
    const csvContent = [
      ["Date", "Invoice #", "Student", "Amount", "Paid", "Status", "Lesson Type", "Payment Method"],
      ...invoices.map(inv => {
        const student = students.find(s => s.id === inv.student_id);
        return [
          format(new Date(inv.issue_date), "yyyy-MM-dd"),
          inv.invoice_number || inv.id.slice(0, 8),
          student?.full_name || "Unknown",
          (inv.instructor_earnings || inv.total_amount || 0).toFixed(2),
          (inv.amount_paid || 0).toFixed(2),
          inv.status,
          inv.lesson_type || "N/A",
          inv.payment_method || "N/A"
        ];
      }),
    ].map(row => row.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `earnings_report_${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    toast.success("Earnings report exported successfully");
  };

  const handleSaveInvoice = async (invoiceData) => {
    const completeInvoiceData = {
      ...invoiceData,
      instructor_id: instructor.id,
      school_id: instructor.school_id,
      amount_paid: 0,
      status: "sent"
    };

    if (selectedInvoice) {
      updateInvoiceMutation.mutate({ id: selectedInvoice.id, data: completeInvoiceData });
    } else {
      createInvoiceMutation.mutate(completeInvoiceData);
    }
  };

  const handleRecordPayment = () => {
    if (!selectedPaymentInvoice || !paymentAmount) {
      toast.error("Please enter payment amount");
      return;
    }

    const amount = parseFloat(paymentAmount);
    const amountDue = selectedPaymentInvoice.total_amount - (selectedPaymentInvoice.amount_paid || 0);

    if (amount <= 0) {
      toast.error("Payment amount must be greater than 0");
      return;
    }

    if (amount > amountDue) {
      toast.error("Payment amount cannot exceed amount due");
      return;
    }

    recordPaymentMutation.mutate({
      invoiceId: selectedPaymentInvoice.id,
      amount: amount,
      method: paymentMethod
    });
  };

  const openPaymentModal = (invoice) => {
    setSelectedPaymentInvoice(invoice);
    const amountDue = invoice.total_amount - (invoice.amount_paid || 0);
    setPaymentAmount(amountDue.toString());
    setShowPaymentModal(true);
  };

  const getStatusConfig = (status) => {
    const configs = {
      paid: { label: "Paid", color: "green", icon: CheckCircle2 },
      partially_paid: { label: "Partially Paid", color: "blue", icon: Wallet },
      sent: { label: "Sent", color: "purple", icon: Mail },
      overdue: { label: "Overdue", color: "red", icon: AlertCircle },
      draft: { label: "Draft", color: "gray", icon: FileText },
      cancelled: { label: "Cancelled", color: "gray", icon: XCircle }
    };
    return configs[status] || configs.sent;
  };

  if (isLoading || loadingInvoices) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-[#3b82c4] mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading earnings data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 pb-24 md:pb-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <Link
          to={createPageUrl("InstructorDashboard")}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-[#3b82c4] to-[#6c376f] bg-clip-text text-transparent">Earnings & Finance</h1>
            <p className="text-gray-600 mt-1">Track your income, manage invoices, and monitor performance</p>
          </div>
          
          <div className="flex gap-3 flex-wrap">
            <button
              onClick={() => {
                setSelectedInvoice(null);
                setShowInvoiceForm(true);
              }}
              className="px-4 py-2 bg-gradient-to-r from-[#3b82c4] to-[#2563a3] hover:from-[#2563a3] hover:to-[#1e4f8a] text-white rounded-xl font-semibold transition flex items-center gap-2 shadow-md"
            >
              <Plus className="w-5 h-5" />
              Create Invoice
            </button>
            <button
              onClick={handleExportEarnings}
              className="px-4 py-2 bg-white border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition flex items-center gap-2"
            >
              <Download className="w-5 h-5" />
              Export
            </button>
          </div>
        </div>
      </motion.div>

      <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm">
        <div className="flex items-center gap-2 overflow-x-auto">
          {[
            { id: "overview", label: "Overview", icon: BarChart3 },
            { id: "invoices", label: "Invoices", icon: Receipt },
            { id: "commission", label: "Commission", icon: Percent },
            { id: "goals", label: "Goals", icon: Target }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-[#3b82c4] text-white"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            label: "Total Earned",
            value: `€${stats.totalEarned.toFixed(2)}`,
            icon: DollarSign,
            color: "green",
            subtitle: `${stats.paidCount} paid invoices`,
            trend: stats.growthRate > 0 ? "up" : stats.growthRate < 0 ? "down" : "neutral",
            trendValue: `${Math.abs(stats.growthRate).toFixed(1)}%`
          },
          {
            label: "Pending",
            value: `€${stats.pendingEarnings.toFixed(2)}`,
            icon: Clock,
            color: "yellow",
            subtitle: `${stats.unpaidCount} unpaid`,
            badge: stats.overdueCount > 0 ? `${stats.overdueCount} overdue` : null
          },
          {
            label: "Lessons",
            value: stats.completedLessons,
            icon: BookOpen,
            color: "indigo",
            subtitle: `${stats.upcomingLessons} upcoming`,
            trend: null
          },
          {
            label: "Conversion",
            value: `${stats.conversionRate.toFixed(1)}%`,
            icon: TrendingUp,
            color: "purple",
            subtitle: `Avg: €${stats.avgInvoiceValue.toFixed(2)}`,
            trend: null
          }
        ].map((stat, idx) => {
          const colorClasses = {
            green: { bg: 'bg-[#eefbe7]', text: 'text-[#5cb83a]' },
            yellow: { bg: 'bg-[#fdfbe8]', text: 'text-[#e7d356]' },
            indigo: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
            purple: { bg: 'bg-[#f3e8f4]', text: 'text-[#6c376f]' }
          };
          const colors = colorClasses[stat.color] || colorClasses.indigo;
          
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 ${colors.bg} rounded-xl flex items-center justify-center`}>
                  <stat.icon className={`w-6 h-6 ${colors.text}`} />
                </div>
                {stat.trend && (
                  <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${
                    stat.trend === "up" ? "bg-[#eefbe7] text-[#4a9c2e]" : "bg-[#fdeeed] text-[#c9342c]"
                  }`}>
                    {stat.trend === "up" ? (
                      <ArrowUpRight className="w-4 h-4" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4" />
                    )}
                    <span className="text-xs font-bold">{stat.trendValue}</span>
                  </div>
                )}
              </div>
              <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
              <p className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</p>
              <p className="text-xs text-gray-500">{stat.subtitle}</p>
              {stat.badge && (
                <span className="inline-block mt-2 px-2 py-1 bg-[#fdeeed] text-[#c9342c] rounded-full text-xs font-bold">
                  {stat.badge}
                </span>
              )}
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === "overview" && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Revenue Trend (Last 12 Months)</h2>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={monthlyData}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82c4" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3b82c4" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="month" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#fff', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '0.75rem',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#3b82c4" 
                    strokeWidth={2}
                    fill="url(#colorRevenue)"
                    name="Revenue (€)" 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="lessons" 
                    stroke="#6c376f" 
                    strokeWidth={2} 
                    name="Lessons" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Revenue by Lesson Type</h2>
                {revenueByType.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartsChart>
                      <Pie
                        data={revenueByType}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value }) => `${name}: €${value.toFixed(0)}`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {revenueByType.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `€${value.toFixed(2)}`} />
                    </RechartsChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-64 text-gray-500">
                    <div className="text-center">
                      <PieChart className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <p>No revenue data yet</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Top Students by Revenue</h2>
                <div className="space-y-4">
                  {revenueByStudent.length > 0 ? (
                    revenueByStudent.map((student, index) => (
                      <div key={student.studentId} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-[#3b82c4] to-[#6c376f] rounded-xl flex items-center justify-center">
                            <span className="text-white font-bold text-sm">{index + 1}</span>
                          </div>
                          <div>
                            <p className="font-bold text-gray-900">{student.studentName}</p>
                            <p className="text-sm text-gray-600">{student.invoiceCount} invoices</p>
                          </div>
                        </div>
                        <p className="text-xl font-bold text-[#3b82c4]">€{student.revenue.toFixed(2)}</p>
                      </div>
                    ))
                  ) : (
                    <div className="flex items-center justify-center h-64 text-gray-500">
                      <div className="text-center">
                        <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                        <p>No revenue data yet</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "invoices" && (
          <motion.div
            key="invoices"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search invoices..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                  />
                </div>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                >
                  <option value="date-desc">Newest First</option>
                  <option value="date-asc">Oldest First</option>
                  <option value="amount-desc">Highest Amount</option>
                  <option value="amount-asc">Lowest Amount</option>
                  <option value="status">Status</option>
                </select>

                <select
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                  className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                >
                  <option value="all">All Time</option>
                  <option value="month">Last 30 Days</option>
                  <option value="quarter">Last 90 Days</option>
                  <option value="year">This Year</option>
                </select>
              </div>

              <div className="flex flex-wrap gap-3 mb-6">
                {["all", "sent", "partially_paid", "paid", "overdue", "cancelled"].map((status) => {
                  const count = status === "all" 
                    ? invoices.length 
                    : invoices.filter(inv => inv.status === status).length;

                  return (
                    <button
                      key={status}
                      onClick={() => setFilterStatus(status)}
                      className={`px-4 py-2 rounded-xl font-semibold text-sm transition ${
                        filterStatus === status
                          ? "bg-[#3b82c4] text-white"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      {status === "all" ? "All" : status.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase())}
                      <span className="ml-2 px-2 py-0.5 bg-white/20 rounded-full text-xs font-bold">
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="space-y-3">
                {filteredAndSortedInvoices.length === 0 ? (
                  <div className="text-center py-12">
                    <Receipt className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600 mb-4">No invoices found</p>
                    <button
                      onClick={() => setShowInvoiceForm(true)}
                      className="px-6 py-3 bg-[#3b82c4] text-white rounded-xl font-semibold hover:bg-[#2563a3] transition inline-flex items-center gap-2 shadow-md"
                    >
                      <Plus className="w-5 h-5" />
                      Create Your First Invoice
                    </button>
                  </div>
                ) : (
                  filteredAndSortedInvoices.map((invoice, idx) => {
                    const config = getStatusConfig(invoice.status);
                    const student = students.find(s => s.id === invoice.student_id);
                    const amountDue = invoice.total_amount - (invoice.amount_paid || 0);

                    return (
                      <div
                        key={invoice.id}
                        className="p-4 border border-gray-200 rounded-xl hover:border-gray-300 hover:shadow-sm transition"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gray-50">
                              <config.icon className="w-6 h-6 text-gray-600" />
                            </div>
                            <div>
                              <p className="font-bold text-gray-900">
                                #{invoice.invoice_number || invoice.id.slice(0, 8)}
                              </p>
                              <p className="text-sm text-gray-600">
                                {student?.full_name || "Unknown"} • {format(new Date(invoice.issue_date), "MMM d, yyyy")}
                              </p>
                            </div>
                            </div>

                            <div className="flex items-center gap-4">
                            <div className="text-right">
                              <p className="text-xl font-bold text-gray-900">
                                €{(invoice.instructor_earnings || invoice.total_amount || 0).toFixed(2)}
                              </p>
                              <span className="text-xs font-bold px-2 py-1 rounded-full bg-gray-100 text-gray-700">
                                {config.label}
                              </span>
                            </div>

                            {invoice.status !== "paid" && invoice.status !== "cancelled" && (
                              <button
                                onClick={() => openPaymentModal(invoice)}
                                className="px-4 py-2 bg-[#eefbe7] hover:bg-[#d4f4c3] text-[#5cb83a] rounded-lg font-semibold text-sm transition flex items-center gap-2"
                              >
                                <CreditCard className="w-4 h-4" />
                                Record Payment
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "commission" && (
          <motion.div
            key="commission"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-8 shadow-sm">
              <h2 className="text-2xl font-bold text-gray-900 mb-8">Commission Structure & Breakdown</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="p-6 bg-gradient-to-br from-[#e8f4fa] to-[#d4eaf5] rounded-2xl text-center border border-[#d4eaf5]">
                  <Percent className="w-8 h-8 text-[#3b82c4] mx-auto mb-3" />
                  <p className="text-sm text-[#2563a3] font-medium mb-2">Standard Rate</p>
                  <p className="text-4xl font-bold text-[#3b82c4]">30%</p>
                </div>
                <div className="p-6 bg-gradient-to-br from-[#f3e8f4] to-[#e5d0e6] rounded-2xl text-center border border-[#e5d0e6]">
                  <Package className="w-8 h-8 text-[#6c376f] mx-auto mb-3" />
                  <p className="text-sm text-[#5a2d5d] font-medium mb-2">Package Bonus</p>
                  <p className="text-4xl font-bold text-[#6c376f]">+5%</p>
                </div>
                <div className="p-6 bg-gradient-to-br from-[#eefbe7] to-[#d4f4c3] rounded-2xl text-center border border-[#d4f4c3]">
                  <Award className="w-8 h-8 text-[#5cb83a] mx-auto mb-3" />
                  <p className="text-sm text-[#4a9c2e] font-medium mb-2">Top Performer</p>
                  <p className="text-4xl font-bold text-[#5cb83a]">+€100</p>
                </div>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-4">This Month's Breakdown</h3>
              <div className="space-y-3">
                {[
                  { label: "Base Commission (30%)", amount: stats.thisMonthEarnings * 0.3 },
                  { label: "Package Bonuses", amount: 120 },
                  { label: "Performance Bonus", amount: 100 }
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                    <span className="text-gray-700 font-medium">{item.label}</span>
                    <span className="font-bold text-gray-900 text-lg">€{item.amount.toFixed(2)}</span>
                  </div>
                ))}
                <div className="flex items-center justify-between p-4 bg-[#e8f4fa] rounded-xl border-2 border-[#d4eaf5]">
                  <span className="font-bold text-gray-900 text-lg">Total This Month</span>
                  <span className="font-bold text-[#3b82c4] text-2xl">
                    €{(stats.thisMonthEarnings * 0.3 + 220).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "goals" && (
          <motion.div
            key="goals"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-8 shadow-sm">
              <h2 className="text-2xl font-bold text-gray-900 mb-8">Monthly Goals & Targets</h2>
              <div className="space-y-6">
                {[
                  { 
                    title: "Monthly Revenue Target", 
                    current: stats.thisMonthEarnings, 
                    target: 5000, 
                    unit: "€",
                    icon: DollarSign,
                    color: "indigo"
                  },
                  { 
                    title: "Lessons Goal", 
                    current: stats.completedLessons, 
                    target: 80, 
                    unit: "",
                    icon: BookOpen,
                    color: "purple"
                  },
                  { 
                    title: "New Students", 
                    current: myStudents.length, 
                    target: 10, 
                    unit: "",
                    icon: Users,
                    color: "blue"
                  },
                  { 
                    title: "Conversion Rate", 
                    current: stats.conversionRate, 
                    target: 90, 
                    unit: "%",
                    icon: TrendingUp,
                    color: "green"
                  }
                ].map((goal, idx) => {
                  const progress = (goal.current / goal.target) * 100;
                  const colorClasses = {
                    indigo: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
                    purple: { bg: 'bg-[#f3e8f4]', text: 'text-[#6c376f]' },
                    blue: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
                    green: { bg: 'bg-[#eefbe7]', text: 'text-[#5cb83a]' }
                  };
                  const colors = colorClasses[goal.color] || colorClasses.indigo;
                  
                  return (
                    <div key={idx} className="p-6 bg-gray-50 rounded-2xl">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 ${colors.bg} rounded-xl flex items-center justify-center`}>
                            <goal.icon className={`w-5 h-5 ${colors.text}`} />
                          </div>
                          <h3 className="font-bold text-gray-900">{goal.title}</h3>
                        </div>
                        <span className="text-sm text-gray-600 font-medium">
                          {goal.unit}{goal.current.toFixed(0)} / {goal.unit}{goal.target}
                        </span>
                      </div>
                      <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all ${
                            progress >= 100 ? "bg-[#81da5a]" : 
                            progress >= 75 ? "bg-[#3b82c4]" : 
                            progress >= 50 ? "bg-[#e7d356]" : "bg-[#e44138]"
                          }`}
                          style={{ width: `${Math.min(progress, 100)}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <p className="text-xs text-gray-600">{progress.toFixed(0)}% complete</p>
                        {progress >= 100 && (
                          <span className="flex items-center gap-1 text-xs font-bold text-[#5cb83a]">
                            <CheckCircle className="w-4 h-4" />
                            Goal Achieved!
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showInvoiceForm && (
          <InvoiceForm
            invoice={selectedInvoice}
            students={myStudents}
            onClose={() => {
              setShowInvoiceForm(false);
              setSelectedInvoice(null);
            }}
            onSave={handleSaveInvoice}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showPaymentModal && selectedPaymentInvoice && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowPaymentModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-[#eefbe7] rounded-xl flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-[#5cb83a]" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Record Payment</h3>
                  <p className="text-sm text-gray-600">
                    Invoice #{selectedPaymentInvoice.invoice_number || selectedPaymentInvoice.id.slice(0, 8)}
                  </p>
                </div>
              </div>

              <div className="bg-gray-50 rounded-xl p-4 mb-6">
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-600">Total Amount</span>
                  <span className="font-bold text-gray-900">€{selectedPaymentInvoice.total_amount.toFixed(2)}</span>
                </div>
                {selectedPaymentInvoice.amount_paid > 0 && (
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-gray-600">Already Paid</span>
                    <span className="font-bold text-[#5cb83a]">-€{selectedPaymentInvoice.amount_paid.toFixed(2)}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-gray-200 flex justify-between">
                  <span className="font-bold text-gray-900">Amount Due</span>
                  <span className="font-bold text-[#3b82c4] text-lg">
                    €{(selectedPaymentInvoice.total_amount - (selectedPaymentInvoice.amount_paid || 0)).toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Payment Amount</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-medium">€</span>
                    <input
                      type="number"
                      step="0.01"
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(e.target.value)}
                      className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                  >
                    <option value="cash">Cash</option>
                    <option value="card">Credit/Debit Card</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="online">Online Payment</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowPaymentModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleRecordPayment}
                  disabled={recordPaymentMutation.isPending}
                  className="flex-1 px-4 py-3 bg-[#81da5a] hover:bg-[#5cb83a] text-white rounded-xl font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {recordPaymentMutation.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Recording...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-5 h-5" />
                      Record Payment
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}