import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Car, 
  Fuel, 
  Wrench, 
  AlertCircle, 
  CheckCircle, 
  Calendar, 
  Upload, 
  Camera, 
  Clock, 
  TrendingUp, 
  Download, 
  ArrowLeft,
  Gauge, 
  Settings, 
  MapPin, 
  Shield, 
  FileText, 
  X, 
  Plus,
  Loader2, 
  Info, 
  Droplet, 
  Wind, 
  Battery, 
  Navigation,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Eye,
  Edit,
  Trash2,
  RefreshCw,
  ThermometerSun,
  Zap,
  CircleOff,
  Activity,
  BarChart3,
  PieChart,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  History,
  Bell,
  Star,
  Target,
  Clipboard,
  ClipboardCheck,
  Image as ImageIcon
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format, differenceInDays, isBefore, addDays, subDays, startOfMonth, endOfMonth } from "date-fns";
import { toast } from "sonner";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

export default function InstructorVehicle() {
  const queryClient = useQueryClient();
  
  const [currentUser, setCurrentUser] = useState(null);
  const [instructor, setInstructor] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [showIssueForm, setShowIssueForm] = useState(false);
  const [showInspectionForm, setShowInspectionForm] = useState(false);
  const [issueType, setIssueType] = useState("mechanical");
  const [severity, setSeverity] = useState("medium");
  const [description, setDescription] = useState("");
  const [needsReplacement, setNeedsReplacement] = useState(false);
  const [selectedTimeRange, setSelectedTimeRange] = useState("month");
  const [expandedMaintenanceId, setExpandedMaintenanceId] = useState(null);

  const [inspectionData, setInspectionData] = useState({
    exterior: { clean: true, damage: false, notes: "" },
    interior: { clean: true, damage: false, notes: "" },
    lights: { working: true, notes: "" },
    tires: { condition: "good", pressure: true, notes: "" },
    fluids: { oil: true, coolant: true, washer: true, notes: "" },
    brakes: { condition: "good", notes: "" },
    dualControls: { working: true, notes: "" },
    mirrors: { adjusted: true, clean: true, notes: "" },
    seatbelts: { working: true, notes: "" },
    horn: { working: true, notes: "" },
    wipers: { working: true, notes: "" },
    mileage: ""
  });

  useEffect(() => {
    const loadUser = async () => {
      try {
        setIsLoading(true);
        const user = await base44.auth.me();
        setCurrentUser(user);
        const instructors = await base44.entities.Instructor.filter({ email: user.email });
        if (instructors.length > 0) {
          setInstructor(instructors[0]);
        }
      } catch (error) {
        console.error("Error loading user:", error);
        toast.error("Failed to load user data");
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: bookings = [] } = useQuery({
    queryKey: ['instructorVehicleBookings', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      return await base44.entities.Booking.filter({ instructor_id: instructor.id });
    },
    enabled: !!instructor,
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ['vehicles'],
    queryFn: () => base44.entities.Vehicle.list(),
  });

  const { data: maintenance = [] } = useQuery({
    queryKey: ['vehicleMaintenance'],
    queryFn: async () => {
      try {
        return await base44.entities.VehicleMaintenance.list();
      } catch {
        return [];
      }
    },
  });

  const { data: inspections = [] } = useQuery({
    queryKey: ['vehicleInspections'],
    queryFn: async () => {
      try {
        return await base44.entities.VehicleInspection.list();
      } catch {
        return [];
      }
    },
  });

  const { data: fuelLogs = [] } = useQuery({
    queryKey: ['fuelLogs'],
    queryFn: async () => {
      try {
        return await base44.entities.FuelLog.list();
      } catch {
        return [];
      }
    },
  });

  const assignedVehicle = useMemo(() => {
    if (instructor?.assigned_vehicle_id) {
      return vehicles.find(v => v.id === instructor.assigned_vehicle_id);
    }
    
    const vehicleUsage = {};
    bookings.forEach(b => {
      if (b.vehicle_id) {
        vehicleUsage[b.vehicle_id] = (vehicleUsage[b.vehicle_id] || 0) + 1;
      }
    });
    
    const mostUsedVehicleId = Object.keys(vehicleUsage).sort((a, b) => vehicleUsage[b] - vehicleUsage[a])[0];
    return vehicles.find(v => v.id === mostUsedVehicleId);
  }, [instructor, vehicles, bookings]);

  const vehicleMaintenance = useMemo(() => 
    maintenance.filter(m => m.vehicle_id === assignedVehicle?.id)
      .sort((a, b) => new Date(b.reported_date || b.created_date) - new Date(a.reported_date || a.created_date)),
    [maintenance, assignedVehicle]
  );

  const vehicleInspections = useMemo(() =>
    inspections.filter(i => i.vehicle_id === assignedVehicle?.id)
      .sort((a, b) => new Date(b.inspection_date) - new Date(a.inspection_date)),
    [inspections, assignedVehicle]
  );

  const vehicleFuelLogs = useMemo(() =>
    fuelLogs.filter(f => f.vehicle_id === assignedVehicle?.id)
      .sort((a, b) => new Date(b.date) - new Date(a.date)),
    [fuelLogs, assignedVehicle]
  );

  const usageStats = useMemo(() => {
    const now = new Date();
    let startDate;
    
    if (selectedTimeRange === "week") {
      startDate = subDays(now, 7);
    } else if (selectedTimeRange === "month") {
      startDate = startOfMonth(now);
    } else if (selectedTimeRange === "quarter") {
      startDate = subDays(now, 90);
    } else {
      startDate = subDays(now, 365);
    }

    const filteredBookings = bookings.filter(b => 
      b.vehicle_id === assignedVehicle?.id && 
      new Date(b.start_datetime) >= startDate &&
      b.status === "completed"
    );

    const totalHours = filteredBookings.reduce((sum, b) => {
      const start = new Date(b.start_datetime);
      const end = new Date(b.end_datetime);
      return sum + (end - start) / (1000 * 60 * 60);
    }, 0);

    const estimatedKm = totalHours * 30;
    const estimatedFuelCost = totalHours * 3;
    const lessonsCount = filteredBookings.length;

    const dailyUsage = {};
    filteredBookings.forEach(b => {
      const day = format(new Date(b.start_datetime), "yyyy-MM-dd");
      if (!dailyUsage[day]) {
        dailyUsage[day] = { date: day, hours: 0, lessons: 0 };
      }
      const duration = (new Date(b.end_datetime) - new Date(b.start_datetime)) / (1000 * 60 * 60);
      dailyUsage[day].hours += duration;
      dailyUsage[day].lessons += 1;
    });

    const usageTrend = Object.values(dailyUsage)
      .sort((a, b) => new Date(a.date) - new Date(b.date))
      .slice(-14);

    return {
      totalHours,
      estimatedKm,
      estimatedFuelCost,
      lessonsCount,
      usageTrend,
      avgHoursPerDay: totalHours / Math.max(differenceInDays(now, startDate), 1),
      avgLessonsPerDay: lessonsCount / Math.max(differenceInDays(now, startDate), 1)
    };
  }, [bookings, assignedVehicle, selectedTimeRange]);

  const vehicleHealth = useMemo(() => {
    if (!assignedVehicle) return null;

    const openIssues = vehicleMaintenance.filter(m => 
      m.status !== "completed" && m.status !== "cancelled"
    );
    const criticalIssues = openIssues.filter(m => m.status === "urgent");
    
    const nextService = assignedVehicle.next_service_date 
      ? differenceInDays(new Date(assignedVehicle.next_service_date), new Date())
      : null;
    
    const insuranceExpiry = assignedVehicle.insurance_expiry
      ? differenceInDays(new Date(assignedVehicle.insurance_expiry), new Date())
      : null;

    const motExpiry = assignedVehicle.mot_expiry
      ? differenceInDays(new Date(assignedVehicle.mot_expiry), new Date())
      : null;

    const lastInspection = vehicleInspections[0];
    const daysSinceInspection = lastInspection
      ? differenceInDays(new Date(), new Date(lastInspection.inspection_date))
      : null;

    let healthScore = 100;
    let healthStatus = "excellent";

    if (criticalIssues.length > 0) {
      healthScore -= criticalIssues.length * 20;
    }
    if (openIssues.length > 0) {
      healthScore -= openIssues.length * 5;
    }
    if (nextService !== null && nextService <= 7) {
      healthScore -= 15;
    } else if (nextService !== null && nextService <= 30) {
      healthScore -= 5;
    }
    if (insuranceExpiry !== null && insuranceExpiry <= 30) {
      healthScore -= 10;
    }
    if (daysSinceInspection !== null && daysSinceInspection > 7) {
      healthScore -= 5;
    }

    healthScore = Math.max(0, healthScore);

    if (healthScore >= 90) healthStatus = "excellent";
    else if (healthScore >= 70) healthStatus = "good";
    else if (healthScore >= 50) healthStatus = "fair";
    else healthStatus = "poor";

    return {
      score: healthScore,
      status: healthStatus,
      openIssues: openIssues.length,
      criticalIssues: criticalIssues.length,
      nextService,
      insuranceExpiry,
      motExpiry,
      daysSinceInspection,
      lastInspection
    };
  }, [assignedVehicle, vehicleMaintenance, vehicleInspections]);

  const reportIssueMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.VehicleMaintenance.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vehicleMaintenance'] });
      toast.success("Issue reported successfully");
      setShowIssueForm(false);
      setDescription("");
      setIssueType("mechanical");
      setSeverity("medium");
      setNeedsReplacement(false);
    },
    onError: () => {
      toast.error("Failed to report issue");
    }
  });

  const submitInspectionMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.VehicleInspection.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vehicleInspections'] });
      toast.success("Inspection submitted successfully");
      setShowInspectionForm(false);
      setInspectionData({
        exterior: { clean: true, damage: false, notes: "" },
        interior: { clean: true, damage: false, notes: "" },
        lights: { working: true, notes: "" },
        tires: { condition: "good", pressure: true, notes: "" },
        fluids: { oil: true, coolant: true, washer: true, notes: "" },
        brakes: { condition: "good", notes: "" },
        dualControls: { working: true, notes: "" },
        mirrors: { adjusted: true, clean: true, notes: "" },
        seatbelts: { working: true, notes: "" },
        horn: { working: true, notes: "" },
        wipers: { working: true, notes: "" },
        mileage: ""
      });
    },
    onError: () => {
      toast.error("Failed to submit inspection");
    }
  });

  const handleSubmitIssue = () => {
    if (!assignedVehicle || !description.trim()) {
      toast.error("Please provide issue description");
      return;
    }

    reportIssueMutation.mutate({
      vehicle_id: assignedVehicle.id,
      school_id: instructor?.school_id,
      maintenance_type: issueType,
      description: description,
      status: severity === "critical" ? "urgent" : "scheduled",
      priority: severity,
      cost: 0,
      reported_by: currentUser?.email,
      reported_date: new Date().toISOString(),
      needs_replacement_vehicle: needsReplacement
    });
  };

  const handleSubmitInspection = () => {
    if (!assignedVehicle) return;

    const hasIssues = Object.values(inspectionData).some(section => {
      if (typeof section === "object" && section !== null) {
        return section.damage === true || section.working === false || section.condition === "poor";
      }
      return false;
    });

    submitInspectionMutation.mutate({
      vehicle_id: assignedVehicle.id,
      instructor_id: instructor?.id,
      inspection_date: new Date().toISOString(),
      inspection_type: "daily",
      status: hasIssues ? "issues_found" : "passed",
      checklist: inspectionData,
      mileage: parseInt(inspectionData.mileage) || assignedVehicle.mileage,
      notes: Object.entries(inspectionData)
        .filter(([_, v]) => v.notes)
        .map(([k, v]) => `${k}: ${v.notes}`)
        .join("; ")
    });
  };

  const getHealthColor = (status) => {
    switch (status) {
      case "excellent": return "green";
      case "good": return "blue";
      case "fair": return "amber";
      case "poor": return "red";
      default: return "gray";
    }
  };

  const getSeverityConfig = (severity) => {
    switch (severity) {
      case "critical": return { label: "Critical", color: "red", icon: AlertTriangle };
      case "high": return { label: "High", color: "orange", icon: AlertCircle };
      case "medium": return { label: "Medium", color: "amber", icon: Info };
      case "low": return { label: "Low", color: "green", icon: CheckCircle };
      default: return { label: "Unknown", color: "gray", icon: Info };
    }
  };

  const getStatusConfig = (status) => {
    switch (status) {
      case "completed": return { label: "Completed", color: "green", icon: CheckCircle2 };
      case "in_progress": return { label: "In Progress", color: "blue", icon: RefreshCw };
      case "scheduled": return { label: "Scheduled", color: "purple", icon: Calendar };
      case "urgent": return { label: "Urgent", color: "red", icon: AlertTriangle };
      case "cancelled": return { label: "Cancelled", color: "gray", icon: XCircle };
      default: return { label: status, color: "gray", icon: Info };
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading vehicle information...</p>
        </div>
      </div>
    );
  }

  if (!assignedVehicle) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Link
          to={createPageUrl("InstructorDashboard")}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>
        <div className="bg-white rounded-2xl p-12 text-center shadow-sm border border-gray-200">
          <Car className="w-20 h-20 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">No Vehicle Assigned</h2>
          <p className="text-gray-600 mb-6">You haven't been assigned a vehicle yet.</p>
          <p className="text-sm text-gray-500">Please contact your administrator to get a vehicle assigned.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Link
          to={createPageUrl("InstructorDashboard")}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">My Vehicle</h1>
            <p className="text-gray-600 mt-1">Monitor, inspect, and maintain your assigned vehicle</p>
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => setShowInspectionForm(true)}
              className="px-4 py-2 bg-white border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition flex items-center gap-2"
            >
              <ClipboardCheck className="w-4 h-4" />
              Daily Check
            </button>
            <button
              onClick={() => setShowIssueForm(true)}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold transition flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4" />
              Report Issue
            </button>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-gradient-to-br from-indigo-600 via-purple-600 to-indigo-700 rounded-2xl p-8 text-white shadow-xl"
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-start gap-6">
            {assignedVehicle.photo_url ? (
              <img 
                src={assignedVehicle.photo_url} 
                alt={`${assignedVehicle.make} ${assignedVehicle.model}`}
                className="w-32 h-24 object-cover rounded-xl"
              />
            ) : (
              <div className="w-32 h-24 bg-white/20 rounded-xl flex items-center justify-center">
                <Car className="w-12 h-12 text-white/80" />
              </div>
            )}

            <div>
              <h2 className="text-3xl font-bold mb-2">
                {assignedVehicle.make} {assignedVehicle.model}
              </h2>
              <p className="text-white/90 text-lg">{assignedVehicle.year} • {assignedVehicle.transmission}</p>
              <div className="flex items-center gap-4 mt-2">
                <span className="px-3 py-1 bg-white/20 rounded-full text-sm font-semibold">
                  {assignedVehicle.license_plate}
                </span>
                <span className="px-3 py-1 bg-white/20 rounded-full text-sm font-semibold">
                  Category {assignedVehicle.category}
                </span>
                {assignedVehicle.fuel_type && (
                  <span className="px-3 py-1 bg-white/20 rounded-full text-sm font-semibold">
                    {assignedVehicle.fuel_type}
                  </span>
                )}
              </div>
            </div>
          </div>

          {vehicleHealth && (
            <div className="flex items-center gap-6">
              <div className="text-center">
                <div className={`w-24 h-24 rounded-full border-4 border-white/30 flex items-center justify-center bg-white/10`}>
                  <div className="text-center">
                    <p className="text-3xl font-bold">{vehicleHealth.score}</p>
                    <p className="text-xs text-white/80">Health</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center">
                  <p className="text-2xl font-bold">{(assignedVehicle.mileage || 0).toLocaleString()}</p>
                  <p className="text-xs text-white/80">km</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center">
                  <p className="text-2xl font-bold">{vehicleHealth.openIssues}</p>
                  <p className="text-xs text-white/80">Open Issues</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {vehicleHealth && (vehicleHealth.criticalIssues > 0 || 
        (vehicleHealth.nextService !== null && vehicleHealth.nextService <= 7) ||
        (vehicleHealth.insuranceExpiry !== null && vehicleHealth.insuranceExpiry <= 30) ||
        (vehicleHealth.motExpiry !== null && vehicleHealth.motExpiry <= 30)) && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="space-y-3"
        >
          {vehicleHealth.criticalIssues > 0 && (
            <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4 flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0" />
              <div>
                <p className="font-bold text-red-900">{vehicleHealth.criticalIssues} Critical Issue{vehicleHealth.criticalIssues !== 1 ? 's' : ''}</p>
                <p className="text-sm text-red-700">Requires immediate attention</p>
              </div>
            </div>
          )}

          {vehicleHealth.nextService !== null && vehicleHealth.nextService <= 7 && (
            <div className={`${vehicleHealth.nextService <= 0 ? "bg-red-50 border-red-200" : "bg-amber-50 border-amber-200"} border-2 rounded-xl p-4 flex items-center gap-3`}>
              <Wrench className={`w-6 h-6 ${vehicleHealth.nextService <= 0 ? "text-red-600" : "text-amber-600"} flex-shrink-0`} />
              <div>
                <p className={`font-bold ${vehicleHealth.nextService <= 0 ? "text-red-900" : "text-amber-900"}`}>
                  {vehicleHealth.nextService <= 0 ? "Service Overdue!" : `Service Due in ${vehicleHealth.nextService} Days`}
                </p>
                <p className={`text-sm ${vehicleHealth.nextService <= 0 ? "text-red-700" : "text-amber-700"}`}>
                  Scheduled: {format(new Date(assignedVehicle.next_service_date), "MMMM d, yyyy")}
                </p>
              </div>
            </div>
          )}

          {vehicleHealth.insuranceExpiry !== null && vehicleHealth.insuranceExpiry <= 30 && (
            <div className={`${vehicleHealth.insuranceExpiry <= 7 ? "bg-red-50 border-red-200" : "bg-amber-50 border-amber-200"} border-2 rounded-xl p-4 flex items-center gap-3`}>
              <Shield className={`w-6 h-6 ${vehicleHealth.insuranceExpiry <= 7 ? "text-red-600" : "text-amber-600"} flex-shrink-0`} />
              <div>
                <p className={`font-bold ${vehicleHealth.insuranceExpiry <= 7 ? "text-red-900" : "text-amber-900"}`}>
                  Insurance {vehicleHealth.insuranceExpiry <= 0 ? "Expired!" : `Expiring in ${vehicleHealth.insuranceExpiry} Days`}
                </p>
                <p className={`text-sm ${vehicleHealth.insuranceExpiry <= 7 ? "text-red-700" : "text-amber-700"}`}>
                  Expiry: {format(new Date(assignedVehicle.insurance_expiry), "MMMM d, yyyy")}
                </p>
              </div>
            </div>
          )}

          {vehicleHealth.motExpiry !== null && vehicleHealth.motExpiry <= 30 && (
            <div className={`${vehicleHealth.motExpiry <= 7 ? "bg-red-50 border-red-200" : "bg-amber-50 border-amber-200"} border-2 rounded-xl p-4 flex items-center gap-3`}>
              <FileText className={`w-6 h-6 ${vehicleHealth.motExpiry <= 7 ? "text-red-600" : "text-amber-600"} flex-shrink-0`} />
              <div>
                <p className={`font-bold ${vehicleHealth.motExpiry <= 7 ? "text-red-900" : "text-amber-900"}`}>
                  MOT {vehicleHealth.motExpiry <= 0 ? "Expired!" : `Expiring in ${vehicleHealth.motExpiry} Days`}
                </p>
                <p className={`text-sm ${vehicleHealth.motExpiry <= 7 ? "text-red-700" : "text-amber-700"}`}>
                  Expiry: {format(new Date(assignedVehicle.mot_expiry), "MMMM d, yyyy")}
                </p>
              </div>
            </div>
          )}
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm"
      >
        <div className="flex flex-wrap gap-2">
          {["overview", "usage", "maintenance", "inspections"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition ${
                activeTab === tab
                  ? "bg-indigo-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </motion.div>

      <AnimatePresence mode="wait">
        {activeTab === "overview" && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Fuel Level", value: "3/4", subtitle: "~450km range", icon: Fuel, color: "blue" },
                { label: "Condition", value: vehicleHealth?.status || "Good", icon: CheckCircle, color: getHealthColor(vehicleHealth?.status) },
                { label: "Last Check", value: vehicleHealth?.daysSinceInspection ? `${vehicleHealth.daysSinceInspection}d ago` : "Never", icon: ClipboardCheck, color: "purple" },
                { label: "Open Issues", value: vehicleHealth?.openIssues || 0, icon: AlertCircle, color: vehicleHealth?.openIssues > 0 ? "red" : "green" }
              ].map((stat, idx) => (
                <div key={idx} className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
                  <div className={`w-10 h-10 bg-${stat.color}-100 rounded-lg flex items-center justify-center mb-3`}>
                    <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
                  </div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-xs text-gray-600">{stat.label}</p>
                  {stat.subtitle && <p className="text-xs text-gray-500 mt-1">{stat.subtitle}</p>}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Vehicle Details</h3>
                <div className="space-y-3">
                  {[
                    { label: "VIN", value: assignedVehicle.vin || "N/A" },
                    { label: "Color", value: assignedVehicle.color || "N/A" },
                    { label: "Fuel Type", value: assignedVehicle.fuel_type || "Petrol" },
                    { label: "Engine Size", value: assignedVehicle.engine_size || "N/A" },
                    { label: "Seats", value: assignedVehicle.seats || 5 },
                    { label: "Dual Controls", value: assignedVehicle.has_dual_controls ? "Yes" : "No" }
                  ].map((item, idx) => (
                    <div key={idx} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
                      <span className="text-gray-600">{item.label}</span>
                      <span className="font-semibold text-gray-900">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Upcoming Dates</h3>
                <div className="space-y-3">
                  {assignedVehicle.next_service_date && (
                    <div className={`flex items-center justify-between p-3 rounded-xl ${
                      vehicleHealth?.nextService <= 7 ? "bg-red-50 border border-red-200" :
                      vehicleHealth?.nextService <= 30 ? "bg-amber-50 border border-amber-200" :
                      "bg-gray-50 border border-gray-200"
                    }`}>
                      <div className="flex items-center gap-3">
                        <Wrench className={`w-5 h-5 ${
                          vehicleHealth?.nextService <= 7 ? "text-red-600" :
                          vehicleHealth?.nextService <= 30 ? "text-amber-600" :
                          "text-gray-600"
                        }`} />
                        <div>
                          <p className="font-semibold text-gray-900">Service Due</p>
                          <p className="text-sm text-gray-600">
                            {format(new Date(assignedVehicle.next_service_date), "MMM d, yyyy")}
                          </p>
                        </div>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                        vehicleHealth?.nextService <= 0 ? "bg-red-100 text-red-700" :
                        vehicleHealth?.nextService <= 7 ? "bg-red-100 text-red-700" :
                        vehicleHealth?.nextService <= 30 ? "bg-amber-100 text-amber-700" :
                        "bg-green-100 text-green-700"
                      }`}>
                        {vehicleHealth?.nextService <= 0 ? "Overdue" : `${vehicleHealth?.nextService}d`}
                      </span>
                    </div>
                  )}

                  {assignedVehicle.insurance_expiry && (
                    <div className={`flex items-center justify-between p-3 rounded-xl ${
                      vehicleHealth?.insuranceExpiry <= 30 ? "bg-amber-50 border border-amber-200" : "bg-gray-50 border border-gray-200"
                    }`}>
                      <div className="flex items-center gap-3">
                        <Shield className={`w-5 h-5 ${vehicleHealth?.insuranceExpiry <= 30 ? "text-amber-600" : "text-green-600"}`} />
                        <div>
                          <p className="font-semibold text-gray-900">Insurance</p>
                          <p className="text-sm text-gray-600">
                            {format(new Date(assignedVehicle.insurance_expiry), "MMM d, yyyy")}
                          </p>
                        </div>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                        vehicleHealth?.insuranceExpiry <= 30 ? "bg-amber-100 text-amber-700" : "bg-green-100 text-green-700"
                      }`}>
                        {vehicleHealth?.insuranceExpiry}d
                      </span>
                    </div>
                  )}

                  {assignedVehicle.mot_expiry && (
                    <div className={`flex items-center justify-between p-3 rounded-xl ${
                      vehicleHealth?.motExpiry <= 30 ? "bg-amber-50 border border-amber-200" : "bg-gray-50 border border-gray-200"
                    }`}>
                      <div className="flex items-center gap-3">
                        <FileText className={`w-5 h-5 ${vehicleHealth?.motExpiry <= 30 ? "text-amber-600" : "text-green-600"}`} />
                        <div>
                          <p className="font-semibold text-gray-900">MOT</p>
                          <p className="text-sm text-gray-600">
                            {format(new Date(assignedVehicle.mot_expiry), "MMM d, yyyy")}
                          </p>
                        </div>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                        vehicleHealth?.motExpiry <= 30 ? "bg-amber-100 text-amber-700" : "bg-green-100 text-green-700"
                      }`}>
                        {vehicleHealth?.motExpiry}d
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {vehicleMaintenance.filter(m => m.status !== "completed" && m.status !== "cancelled").length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Active Issues</h3>
                <div className="space-y-3">
                  {vehicleMaintenance
                    .filter(m => m.status !== "completed" && m.status !== "cancelled")
                    .slice(0, 5)
                    .map((issue) => {
                      const statusConfig = getStatusConfig(issue.status);
                      
                      return (
                        <div key={issue.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                          <div className="flex items-center gap-3">
                            <statusConfig.icon className={`w-5 h-5 text-${statusConfig.color}-600`} />
                            <div>
                              <p className="font-semibold text-gray-900 capitalize">{issue.maintenance_type}</p>
                              <p className="text-sm text-gray-600">{issue.description}</p>
                            </div>
                          </div>
                          <span className={`px-3 py-1 bg-${statusConfig.color}-100 text-${statusConfig.color}-700 rounded-full text-xs font-bold`}>
                            {statusConfig.label}
                          </span>
                        </div>
                      );
                    })}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === "usage" && (
          <motion.div
            key="usage"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="flex justify-end">
              <div className="flex gap-2">
                {["week", "month", "quarter", "year"].map((range) => (
                  <button
                    key={range}
                    onClick={() => setSelectedTimeRange(range)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                      selectedTimeRange === range
                        ? "bg-indigo-100 text-indigo-700 border border-indigo-300"
                        : "bg-gray-100 hover:bg-gray-200 text-gray-700"
                    }`}
                  >
                    {range.charAt(0).toUpperCase() + range.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Hours Driven", value: usageStats.totalHours.toFixed(1), icon: Clock, color: "indigo" },
                { label: "Est. Kilometers", value: usageStats.estimatedKm.toFixed(0), icon: Navigation, color: "blue" },
                { label: "Lessons", value: usageStats.lessonsCount, icon: Activity, color: "purple" },
                { label: "Est. Fuel Cost", value: `€${usageStats.estimatedFuelCost.toFixed(0)}`, icon: Fuel, color: "amber" }
              ].map((stat, idx) => (
                <div key={idx} className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
                  <div className={`w-10 h-10 bg-${stat.color}-100 rounded-lg flex items-center justify-center mb-3`}>
                    <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
                  </div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-xs text-gray-600">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Usage Trend</h3>
              {usageStats.usageTrend.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={usageStats.usageTrend}>
                    <defs>
                      <linearGradient id="colorHours" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis 
                      dataKey="date" 
                      stroke="#6b7280" 
                      style={{ fontSize: '12px' }}
                      tickFormatter={(value) => format(new Date(value), "MMM d")}
                    />
                    <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} />
                    <Tooltip 
                      labelFormatter={(value) => format(new Date(value), "EEEE, MMM d")}
                      formatter={(value, name) => [
                        name === "hours" ? `${value.toFixed(1)}h` : value,
                        name === "hours" ? "Hours" : "Lessons"
                      ]}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="hours" 
                      stroke="#6366f1" 
                      strokeWidth={2}
                      fill="url(#colorHours)"
                      name="hours"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="lessons" 
                      stroke="#8b5cf6" 
                      strokeWidth={2}
                      dot={{ fill: '#8b5cf6' }}
                      name="lessons"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center py-12">
                  <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No usage data for selected period</p>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Daily Averages</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Hours per Day</span>
                    <span className="text-xl font-bold text-gray-900">{usageStats.avgHoursPerDay.toFixed(1)}h</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Lessons per Day</span>
                    <span className="text-xl font-bold text-gray-900">{usageStats.avgLessonsPerDay.toFixed(1)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Avg Lesson Duration</span>
                    <span className="text-xl font-bold text-gray-900">
                      {usageStats.lessonsCount > 0 ? (usageStats.totalHours / usageStats.lessonsCount * 60).toFixed(0) : 0} min
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Fuel Economy</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Avg Consumption</span>
                    <span className="text-xl font-bold text-gray-900">6.2 L/100km</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Est. Tank Range</span>
                    <span className="text-xl font-bold text-gray-900">~600 km</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Cost per Lesson</span>
                    <span className="text-xl font-bold text-gray-900">
                      €{usageStats.lessonsCount > 0 ? (usageStats.estimatedFuelCost / usageStats.lessonsCount).toFixed(2) : "0.00"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "maintenance" && (
          <motion.div
            key="maintenance"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-gray-900">Report New Issue</h3>
              </div>

              {!showIssueForm ? (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { type: "mechanical", label: "Mechanical", icon: Wrench, color: "red" },
                    { type: "cleaning", label: "Cleaning", icon: Droplet, color: "blue" },
                    { type: "electrical", label: "Electrical", icon: Zap, color: "amber" },
                    { type: "tires", label: "Tires", icon: CircleOff, color: "purple" },
                    { type: "brakes", label: "Brakes", icon: AlertTriangle, color: "orange" },
                    { type: "fuel", label: "Fuel", icon: Fuel, color: "green" },
                    { type: "body", label: "Body/Paint", icon: Car, color: "indigo" },
                    { type: "other", label: "Other", icon: Info, color: "gray" }
                  ].map((item) => (
                    <button
                      key={item.type}
                      onClick={() => {
                        setShowIssueForm(true);
                        setIssueType(item.type);
                      }}
                      className={`p-4 bg-${item.color}-50 hover:bg-${item.color}-100 border border-${item.color}-200 rounded-xl text-center transition`}
                    >
                      <item.icon className={`w-6 h-6 text-${item.color}-600 mx-auto mb-2`} />
                      <p className="text-sm font-semibold text-gray-900">{item.label}</p>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Issue Type</label>
                      <select
                        value={issueType}
                        onChange={(e) => setIssueType(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                      >
                        <option value="mechanical">Mechanical Problem</option>
                        <option value="electrical">Electrical Issue</option>
                        <option value="tires">Tire Problem</option>
                        <option value="brakes">Brake Issue</option>
                        <option value="cleaning">Cleaning Needed</option>
                        <option value="fuel">Fuel Issue</option>
                        <option value="body">Body/Paint Damage</option>
                        <option value="other">Other</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Severity</label>
                      <div className="grid grid-cols-4 gap-2">
                        {[
                          { value: "critical", label: "Critical", color: "red" },
                          { value: "high", label: "High", color: "orange" },
                          { value: "medium", label: "Medium", color: "amber" },
                          { value: "low", label: "Low", color: "green" }
                        ].map(({ value, label, color }) => (
                          <button
                            key={value}
                            onClick={() => setSeverity(value)}
                            className={`px-3 py-2 rounded-lg border-2 text-sm font-medium transition ${
                              severity === value
                                ? `border-${color}-500 bg-${color}-50 text-${color}-900`
                                : "border-gray-200 bg-white text-gray-700 hover:bg-gray-50"
                            }`}
                          >
                            {label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                    <textarea
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Describe the issue in detail..."
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                  </div>

                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={needsReplacement}
                      onChange={(e) => setNeedsReplacement(e.target.checked)}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="text-sm text-gray-700">I need a replacement vehicle while this is fixed</span>
                  </label>

                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-3">
                    <div className="flex items-start gap-2">
                      <Info className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-blue-800">
                        The office will be notified immediately. Expect response within 30 minutes during business hours.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => {
                        setShowIssueForm(false);
                        setDescription("");
                      }}
                      className="flex-1 px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSubmitIssue}
                      disabled={!description.trim() || reportIssueMutation.isPending}
                      className="flex-1 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                    >
                      {reportIssueMutation.isPending ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <>
                          <AlertCircle className="w-5 h-5" />
                          Submit Report
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Maintenance History</h3>
              
              {vehicleMaintenance.length > 0 ? (
                <div className="space-y-3">
                  {vehicleMaintenance.map((issue) => {
                    const statusConfig = getStatusConfig(issue.status);
                    const isExpanded = expandedMaintenanceId === issue.id;
                    
                    return (
                      <div key={issue.id} className="border border-gray-200 rounded-xl overflow-hidden">
                        <button
                          onClick={() => setExpandedMaintenanceId(isExpanded ? null : issue.id)}
                          className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-50 transition"
                        >
                          <div className="flex items-center gap-3">
                            <statusConfig.icon className={`w-5 h-5 text-${statusConfig.color}-600`} />
                            <div>
                              <p className="font-semibold text-gray-900 capitalize">{issue.maintenance_type}</p>
                              <p className="text-sm text-gray-600 line-clamp-1">{issue.description}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className={`px-3 py-1 bg-${statusConfig.color}-100 text-${statusConfig.color}-700 rounded-full text-xs font-bold`}>
                              {statusConfig.label}
                            </span>
                            {isExpanded ? (
                              <ChevronUp className="w-5 h-5 text-gray-400" />
                            ) : (
                              <ChevronDown className="w-5 h-5 text-gray-400" />
                            )}
                          </div>
                        </button>

                        <AnimatePresence>
                          {isExpanded && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="overflow-hidden"
                            >
                              <div className="px-4 pb-4 pt-0 border-t border-gray-200 bg-gray-50">
                                <div className="grid grid-cols-2 gap-4 mt-4">
                                  <div>
                                    <p className="text-xs text-gray-500">Reported</p>
                                    <p className="font-semibold text-gray-900">
                                      {format(new Date(issue.reported_date || issue.created_date), "MMM d, yyyy")}
                                    </p>
                                  </div>
                                  <div>
                                    <p className="text-xs text-gray-500">Priority</p>
                                    <p className="font-semibold text-gray-900 capitalize">{issue.priority || "Medium"}</p>
                                  </div>
                                  {issue.scheduled_date && (
                                    <div>
                                      <p className="text-xs text-gray-500">Scheduled</p>
                                      <p className="font-semibold text-gray-900">
                                        {format(new Date(issue.scheduled_date), "MMM d, yyyy")}
                                      </p>
                                    </div>
                                  )}
                                  {issue.completed_date && (
                                    <div>
                                      <p className="text-xs text-gray-500">Completed</p>
                                      <p className="font-semibold text-gray-900">
                                        {format(new Date(issue.completed_date), "MMM d, yyyy")}
                                      </p>
                                    </div>
                                  )}
                                  {issue.cost > 0 && (
                                    <div>
                                      <p className="text-xs text-gray-500">Cost</p>
                                      <p className="font-semibold text-gray-900">€{issue.cost.toFixed(2)}</p>
                                    </div>
                                  )}
                                </div>
                                {issue.notes && (
                                  <div className="mt-4">
                                    <p className="text-xs text-gray-500">Notes</p>
                                    <p className="text-sm text-gray-700">{issue.notes}</p>
                                  </div>
                                )}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <CheckCircle className="w-12 h-12 text-green-300 mx-auto mb-3" />
                  <p className="text-gray-500">No maintenance records</p>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === "inspections" && (
          <motion.div
            key="inspections"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">Daily Vehicle Inspection</h3>
                  <p className="text-sm text-gray-600">Complete a quick safety check before your lessons</p>
                </div>
                {!showInspectionForm && (
                  <button
                    onClick={() => setShowInspectionForm(true)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center gap-2"
                  >
                    <ClipboardCheck className="w-4 h-4" />
                    Start Check
                  </button>
                )}
              </div>

              {showInspectionForm && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                        <Car className="w-4 h-4" />
                        Exterior
                      </h4>
                      <div className="space-y-2">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={inspectionData.exterior.clean}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              exterior: { ...inspectionData.exterior, clean: e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">Clean and presentable</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={!inspectionData.exterior.damage}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              exterior: { ...inspectionData.exterior, damage: !e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">No visible damage</span>
                        </label>
                      </div>
                    </div>

                    <div className="p-4 bg-gray-50 rounded-xl">
                      <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                        <Settings className="w-4 h-4" />
                        Interior
                      </h4>
                      <div className="space-y-2">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={inspectionData.interior.clean}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              interior: { ...inspectionData.interior, clean: e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">Clean and tidy</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={!inspectionData.interior.damage}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              interior: { ...inspectionData.interior, damage: !e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">No damage to seats/controls</span>
                        </label>
                      </div>
                    </div>

                    <div className="p-4 bg-gray-50 rounded-xl">
                      <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                        <Zap className="w-4 h-4" />
                        Lights & Signals
                      </h4>
                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={inspectionData.lights.working}
                          onChange={(e) => setInspectionData({
                            ...inspectionData,
                            lights: { ...inspectionData.lights, working: e.target.checked }
                          })}
                          className="rounded border-gray-300 text-indigo-600"
                        />
                        <span className="text-sm">All lights working</span>
                      </label>
                    </div>

                    <div className="p-4 bg-gray-50 rounded-xl">
                      <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                        <CircleOff className="w-4 h-4" />
                        Tires
                      </h4>
                      <div className="space-y-2">
                        <select
                          value={inspectionData.tires.condition}
                          onChange={(e) => setInspectionData({
                            ...inspectionData,
                            tires: { ...inspectionData.tires, condition: e.target.value }
                          })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                        >
                          <option value="good">Good condition</option>
                          <option value="fair">Fair condition</option>
                          <option value="poor">Poor - needs attention</option>
                        </select>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={inspectionData.tires.pressure}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              tires: { ...inspectionData.tires, pressure: e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">Pressure OK</span>
                        </label>
                      </div>
                    </div>

                    <div className="p-4 bg-gray-50 rounded-xl">
                      <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                        <Droplet className="w-4 h-4" />
                        Fluids
                      </h4>
                      <div className="space-y-2">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={inspectionData.fluids.oil}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              fluids: { ...inspectionData.fluids, oil: e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">Oil level OK</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={inspectionData.fluids.coolant}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              fluids: { ...inspectionData.fluids, coolant: e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">Coolant level OK</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={inspectionData.fluids.washer}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              fluids: { ...inspectionData.fluids, washer: e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">Washer fluid OK</span>
                        </label>
                      </div>
                    </div>

                    <div className="p-4 bg-gray-50 rounded-xl">
                      <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                        <Shield className="w-4 h-4" />
                        Safety Equipment
                      </h4>
                      <div className="space-y-2">
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={inspectionData.dualControls.working}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              dualControls: { ...inspectionData.dualControls, working: e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">Dual controls working</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={inspectionData.seatbelts.working}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              seatbelts: { ...inspectionData.seatbelts, working: e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">All seatbelts working</span>
                        </label>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={inspectionData.mirrors.adjusted}
                            onChange={(e) => setInspectionData({
                              ...inspectionData,
                              mirrors: { ...inspectionData.mirrors, adjusted: e.target.checked }
                            })}
                            className="rounded border-gray-300 text-indigo-600"
                          />
                          <span className="text-sm">Mirrors clean & adjusted</span>
                        </label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Current Mileage (optional)</label>
                    <input
                      type="number"
                      value={inspectionData.mileage}
                      onChange={(e) => setInspectionData({ ...inspectionData, mileage: e.target.value })}
                      placeholder={`Last: ${assignedVehicle.mileage || 0} km`}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowInspectionForm(false)}
                      className="flex-1 px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSubmitInspection}
                      disabled={submitInspectionMutation.isPending}
                      className="flex-1 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                    >
                      {submitInspectionMutation.isPending ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <>
                          <CheckCircle className="w-5 h-5" />
                          Submit Inspection
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Inspection History</h3>
              
              {vehicleInspections.length > 0 ? (
                <div className="space-y-3">
                  {vehicleInspections.map((inspection) => (
                    <div 
                      key={inspection.id} 
                      className={`flex items-center justify-between p-4 rounded-xl ${
                        inspection.status === "passed" 
                          ? "bg-green-50 border border-green-200" 
                          : "bg-amber-50 border border-amber-200"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {inspection.status === "passed" ? (
                          <CheckCircle2 className="w-5 h-5 text-green-600" />
                        ) : (
                          <AlertCircle className="w-5 h-5 text-amber-600" />
                        )}
                        <div>
                          <p className="font-semibold text-gray-900">
                            {format(new Date(inspection.inspection_date), "EEEE, MMMM d, yyyy")}
                          </p>
                          <p className="text-sm text-gray-600">
                            {inspection.inspection_type || "Daily"} inspection
                            {inspection.mileage && ` • ${inspection.mileage.toLocaleString()} km`}
                          </p>
                        </div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                        inspection.status === "passed" 
                          ? "bg-green-100 text-green-700" 
                          : "bg-amber-100 text-amber-700"
                      }`}>
                        {inspection.status === "passed" ? "Passed" : "Issues Found"}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Clipboard className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No inspection records yet</p>
                  <button
                    onClick={() => setShowInspectionForm(true)}
                    className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition"
                  >
                    Start First Inspection
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}