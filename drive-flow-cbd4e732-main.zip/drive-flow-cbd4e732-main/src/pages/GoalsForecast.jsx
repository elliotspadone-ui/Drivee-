import React, { useState, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { 
  Target, 
  TrendingUp, 
  TrendingDown,
  Users, 
  Car, 
  Award, 
  AlertCircle, 
  CheckCircle, 
  Lightbulb,
  Calendar,
  DollarSign,
  BarChart3,
  PieChart,
  Activity,
  Zap,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Info,
  Plus,
  Edit,
  Save,
  X,
  RefreshCw,
  Download,
  Share2,
  Sparkles,
  TrendingDown as TrendingDownIcon
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend, 
  Area, 
  AreaChart,
  BarChart,
  Bar,
  ComposedChart,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from "recharts";
import { 
  startOfMonth, 
  endOfMonth, 
  addMonths, 
  subMonths,
  format,
  startOfYear,
  eachMonthOfInterval,
  differenceInDays,
  isWithinInterval
} from "date-fns";
import { toast } from "sonner";

export default function GoalsForecast() {
  const [selectedPeriod, setSelectedPeriod] = useState("month");
  const [viewMode, setViewMode] = useState("overview");
  const [isEditingGoals, setIsEditingGoals] = useState(false);
  const [customGoals, setCustomGoals] = useState({});

  const { data: budgetTargets = [], isLoading: loadingTargets } = useQuery({
    queryKey: ['budget-targets'],
    queryFn: () => base44.entities.BudgetTarget.list(),
  });

  const { data: bookings = [], isLoading: loadingBookings } = useQuery({
    queryKey: ['bookings'],
    queryFn: () => base44.entities.Booking.list(),
  });

  const { data: payments = [], isLoading: loadingPayments } = useQuery({
    queryKey: ['payments'],
    queryFn: () => base44.entities.Payment.list(),
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ['vehicles'],
    queryFn: () => base44.entities.Vehicle.list(),
  });

  const { data: instructors = [] } = useQuery({
    queryKey: ['instructors'],
    queryFn: () => base44.entities.Instructor.list(),
  });

  const { data: students = [] } = useQuery({
    queryKey: ['students'],
    queryFn: () => base44.entities.Student.list(),
  });

  const isLoading = loadingTargets || loadingBookings || loadingPayments;

  const { periodStart, periodEnd, periodLabel } = useMemo(() => {
    const now = new Date();
    let start, end, label;
    
    switch (selectedPeriod) {
      case "month":
        start = startOfMonth(now);
        end = endOfMonth(now);
        label = format(now, 'MMMM yyyy');
        break;
      case "quarter":
        const quarter = Math.floor(now.getMonth() / 3);
        start = new Date(now.getFullYear(), quarter * 3, 1);
        end = new Date(now.getFullYear(), quarter * 3 + 3, 0);
        label = `Q${quarter + 1} ${format(now, 'yyyy')}`;
        break;
      case "year":
        start = startOfYear(now);
        end = endOfMonth(now);
        label = format(now, 'yyyy');
        break;
      default:
        start = startOfMonth(now);
        end = endOfMonth(now);
        label = format(now, 'MMMM yyyy');
    }
    
    return { periodStart: start, periodEnd: end, periodLabel: label };
  }, [selectedPeriod]);

  const calculateGoal = useCallback((target, actual, previousActual = 0) => {
    const progress = target > 0 ? (actual / target) * 100 : 0;
    const trend = actual > previousActual ? 'up' : actual < previousActual ? 'down' : 'stable';
    
    const daysElapsed = differenceInDays(new Date(), periodStart);
    const totalDays = differenceInDays(periodEnd, periodStart);
    const expectedProgress = (daysElapsed / totalDays) * 100;
    
    const runRate = daysElapsed > 0 ? (actual / daysElapsed) * totalDays : 0;
    const projection = runRate;
    
    let status;
    if (progress >= 100) {
      status = 'achieved';
    } else if (progress >= expectedProgress * 0.95) {
      status = 'on-track';
    } else if (progress >= expectedProgress * 0.75) {
      status = 'at-risk';
    } else {
      status = 'behind';
    }
    
    return { target, actual, progress, status, trend, projection };
  }, [periodStart, periodEnd]);

  const currentGoals = useMemo(() => {
    const currentMonth = startOfMonth(new Date());
    const target = budgetTargets.find(t => 
      new Date(t.period_start) <= currentMonth && 
      new Date(t.period_end) >= currentMonth
    ) || {
      revenue_target: customGoals.revenue_target || 50000,
      package_sales_target: customGoals.package_sales_target || 20,
      lesson_count_target: customGoals.lesson_count_target || 200,
      instructor_utilization_target: customGoals.instructor_utilization_target || 75,
      vehicle_utilization_target: customGoals.vehicle_utilization_target || 60,
      new_students_target: customGoals.new_students_target || 15,
      student_retention_target: customGoals.student_retention_target || 85
    };

    const periodPayments = payments.filter(p => 
      p.status === "completed" &&
      isWithinInterval(new Date(p.payment_date || p.created_date), { start: periodStart, end: periodEnd })
    );
    
    const actualRevenue = periodPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
    const packageSales = periodPayments.filter(p => p.payment_type === "package").length;
    
    const periodBookings = bookings.filter(b => 
      b.status === "completed" &&
      isWithinInterval(new Date(b.start_datetime), { start: periodStart, end: periodEnd })
    );
    
    const actualLessons = periodBookings.length;

    const previousMonth = subMonths(periodStart, 1);
    const previousPeriodPayments = payments.filter(p => 
      p.status === "completed" &&
      isWithinInterval(new Date(p.payment_date || p.created_date), { 
        start: startOfMonth(previousMonth), 
        end: endOfMonth(previousMonth) 
      })
    );
    const previousRevenue = previousPeriodPayments.reduce((sum, p) => sum + (p.amount || 0), 0);

    const daysElapsed = differenceInDays(new Date(), periodStart);
    const totalDays = differenceInDays(periodEnd, periodStart);
    const hoursPerDay = 8;
    
    const availableInstructorHours = instructors.length * daysElapsed * hoursPerDay;
    const usedInstructorHours = actualLessons * 1.5;
    const instructorUtilization = availableInstructorHours > 0 ? (usedInstructorHours / availableInstructorHours) * 100 : 0;

    const availableVehicleHours = vehicles.length * daysElapsed * hoursPerDay;
    const usedVehicleHours = actualLessons * 1.5;
    const vehicleUtilization = availableVehicleHours > 0 ? (usedVehicleHours / availableVehicleHours) * 100 : 0;

    const newStudents = students.filter(s => 
      isWithinInterval(new Date(s.enrollment_date || s.created_date), { start: periodStart, end: periodEnd })
    ).length;

    const activeStudents = students.filter(s => s.is_active).length;
    const totalStudents = students.length;
    const retentionRate = totalStudents > 0 ? (activeStudents / totalStudents) * 100 : 0;

    return {
      revenue: calculateGoal(target.revenue_target, actualRevenue, previousRevenue),
      packages: calculateGoal(target.package_sales_target, packageSales),
      lessons: calculateGoal(target.lesson_count_target, actualLessons),
      instructorUtilization: calculateGoal(target.instructor_utilization_target, instructorUtilization),
      vehicleUtilization: calculateGoal(target.vehicle_utilization_target, vehicleUtilization),
      newStudents: calculateGoal(target.new_students_target || 15, newStudents),
      studentRetention: calculateGoal(target.student_retention_target || 85, retentionRate)
    };
  }, [budgetTargets, payments, bookings, instructors, vehicles, students, periodStart, periodEnd, calculateGoal, customGoals]);

  const forecast = useMemo(() => {
    const months = [];
    const historicalMonths = 6;
    
    const historicalData = eachMonthOfInterval({
      start: subMonths(new Date(), historicalMonths),
      end: subMonths(new Date(), 1)
    }).map(month => {
      const start = startOfMonth(month);
      const end = endOfMonth(month);
      const monthPayments = payments.filter(p => 
        p.status === "completed" &&
        isWithinInterval(new Date(p.payment_date || p.created_date), { start, end })
      );
      return monthPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
    });

    const avgRevenue = historicalData.reduce((sum, val) => sum + val, 0) / historicalData.length;
    const recentTrend = historicalData.slice(-3).reduce((sum, val) => sum + val, 0) / 3;
    const growthRate = avgRevenue > 0 ? ((recentTrend - avgRevenue) / avgRevenue) : 0.05;

    for (let i = 1; i <= 6; i++) {
      const month = addMonths(new Date(), i);
      const seasonalFactor = [1.0, 0.95, 1.05, 1.1, 1.15, 1.08][i - 1] || 1.0;
      const baseProjection = recentTrend * (1 + growthRate * i) * seasonalFactor;
      const confidence = Math.max(0.7, 1 - (i * 0.05));
      
      months.push({
        month: format(month, 'MMM yyyy'),
        forecasted: Math.round(baseProjection),
        lower: Math.round(baseProjection * (1 - (1 - confidence) * 1.5)),
        upper: Math.round(baseProjection * (1 + (1 - confidence) * 1.5)),
        confidence: Math.round(confidence * 100),
        historical: i === 1 ? avgRevenue : null
      });
    }

    return months;
  }, [payments]);

  const recommendations = useMemo(() => {
    const recs = [];

    if (currentGoals.revenue.status === 'at-risk' || currentGoals.revenue.status === 'behind') {
      recs.push({
        id: 'rev-1',
        type: 'revenue',
        priority: 'high',
        message: 'Promote weekend intensive packages to boost revenue',
        impact: `€${Math.round((currentGoals.revenue.target - currentGoals.revenue.actual) * 0.3).toLocaleString()} potential increase`,
        actionable: true,
        estimatedDays: 7
      });
    }

    if (currentGoals.instructorUtilization.actual < 70) {
      recs.push({
        id: 'util-1',
        type: 'utilization',
        priority: 'high',
        message: 'Add early morning (7-9 AM) and evening (7-9 PM) slots',
        impact: `${Math.round((75 - currentGoals.instructorUtilization.actual) * 0.6)}% utilization boost`,
        actionable: true,
        estimatedDays: 3
      });
    }

    if (currentGoals.packages.progress < 80) {
      recs.push({
        id: 'conv-1',
        type: 'conversion',
        priority: 'medium',
        message: 'Launch limited-time discount on 10-lesson packages',
        impact: `${Math.round((currentGoals.packages.target - currentGoals.packages.actual) * 0.4)} additional packages`,
        actionable: true,
        estimatedDays: 14
      });
    }

    if (currentGoals.vehicleUtilization.actual < currentGoals.instructorUtilization.actual) {
      recs.push({
        id: 'eff-1',
        type: 'efficiency',
        priority: 'medium',
        message: 'Optimize vehicle scheduling to match instructor availability',
        impact: '12-15% efficiency improvement',
        actionable: true,
        estimatedDays: 5
      });
    }

    if (currentGoals.studentRetention.actual < 85) {
      recs.push({
        id: 'ret-1',
        type: 'growth',
        priority: 'high',
        message: 'Implement student check-in system for progress tracking',
        impact: `+${Math.round((85 - currentGoals.studentRetention.actual) * 0.5)}% retention improvement`,
        actionable: true,
        estimatedDays: 10
      });
    }

    const avgLessonValue = currentGoals.revenue.actual / Math.max(currentGoals.lessons.actual, 1);
    if (avgLessonValue < 50) {
      recs.push({
        id: 'rev-2',
        type: 'revenue',
        priority: 'medium',
        message: 'Introduce premium services (test preparation, highway driving)',
        impact: `€${Math.round(currentGoals.lessons.actual * 10).toLocaleString()} monthly revenue increase`,
        actionable: true,
        estimatedDays: 21
      });
    }

    return recs.sort((a, b) => {
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });
  }, [currentGoals]);

  const performanceScore = useMemo(() => {
    const goals = [
      currentGoals.revenue,
      currentGoals.packages,
      currentGoals.lessons,
      currentGoals.instructorUtilization,
      currentGoals.vehicleUtilization
    ];
    
    const avgProgress = goals.reduce((sum, g) => sum + Math.min(g.progress, 100), 0) / goals.length;
    return Math.round(avgProgress);
  }, [currentGoals]);

  const getStatusColor = (status) => {
    switch (status) {
      case "achieved": return "text-green-600";
      case "on-track": return "text-blue-600";
      case "at-risk": return "text-amber-600";
      case "behind": return "text-red-600";
      default: return "text-gray-600";
    }
  };

  const getStatusBg = (status) => {
    switch (status) {
      case "achieved": return "bg-green-100 border-green-200";
      case "on-track": return "bg-blue-100 border-blue-200";
      case "at-risk": return "bg-amber-100 border-amber-200";
      case "behind": return "bg-red-100 border-red-200";
      default: return "bg-gray-100 border-gray-200";
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "achieved": return CheckCircle;
      case "on-track": return TrendingUp;
      case "at-risk": return AlertCircle;
      case "behind": return TrendingDownIcon;
      default: return Target;
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'low': return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const handleSaveGoals = useCallback(async () => {
    try {
      toast.success('Goals updated successfully');
      setIsEditingGoals(false);
    } catch (error) {
      toast.error('Failed to update goals');
    }
  }, [customGoals]);

  const exportForecast = useCallback(() => {
    const csv = [
      ['DRIVEE Goals & Forecast Report'],
      ['Period', periodLabel],
      ['Generated', format(new Date(), 'yyyy-MM-dd HH:mm')],
      [],
      ['Current Goals'],
      ['Metric', 'Target', 'Actual', 'Progress', 'Status', 'Projection'],
      ['Revenue', currentGoals.revenue.target, currentGoals.revenue.actual, `${currentGoals.revenue.progress.toFixed(1)}%`, currentGoals.revenue.status, currentGoals.revenue.projection],
      ['Packages', currentGoals.packages.target, currentGoals.packages.actual, `${currentGoals.packages.progress.toFixed(1)}%`, currentGoals.packages.status, currentGoals.packages.projection],
      ['Lessons', currentGoals.lessons.target, currentGoals.lessons.actual, `${currentGoals.lessons.progress.toFixed(1)}%`, currentGoals.lessons.status, currentGoals.lessons.projection],
      [],
      ['6-Month Forecast'],
      ['Month', 'Forecasted', 'Lower Bound', 'Upper Bound', 'Confidence'],
      ...forecast.map(f => [f.month, f.forecasted, f.lower, f.upper, `${f.confidence}%`])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `goals-forecast-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    toast.success('Forecast exported');
  }, [currentGoals, forecast, periodLabel]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading goals and forecast data...</p>
        </div>
      </div>
    );
  }

  const GoalCard = ({ title, goal, icon: Icon, colorClass, format = (val) => val.toLocaleString() }) => {
    const StatusIcon = getStatusIcon(goal.status);
    
    return (
      <div className={`rounded-2xl p-6 border-2 transition-all hover:shadow-lg ${getStatusBg(goal.status)}`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 ${colorClass} rounded-xl flex items-center justify-center`}>
              <Icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-900">{title}</p>
              <p className="text-xs text-gray-600">{format(goal.target)} target</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {goal.trend === 'up' && <ArrowUpRight className="w-4 h-4 text-green-600" />}
            {goal.trend === 'down' && <ArrowDownRight className="w-4 h-4 text-red-600" />}
            <StatusIcon className={`w-6 h-6 ${getStatusColor(goal.status)}`} />
          </div>
        </div>
        
        <div className="space-y-3">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-3xl font-bold text-gray-900 tabular-nums">
                {format(goal.actual)}
              </p>
              <p className="text-xs text-gray-600 mt-1">
                Projected: {format(Math.round(goal.projection))}
              </p>
            </div>
            <span className={`text-lg font-bold ${getStatusColor(goal.status)}`}>
              {goal.progress.toFixed(0)}%
            </span>
          </div>
          
          <div className="relative">
            <div className="w-full h-3 bg-white/50 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-500 ${
                  goal.status === "achieved" ? "bg-green-600" :
                  goal.status === "on-track" ? "bg-blue-600" :
                  goal.status === "at-risk" ? "bg-amber-600" : "bg-red-600"
                }`}
                style={{ width: `${Math.min(goal.progress, 100)}%` }}
              />
            </div>
            {goal.projection > goal.actual && (
              <div 
                className="absolute top-0 h-3 bg-gray-400/30 rounded-full"
                style={{ 
                  width: `${Math.min((goal.projection / goal.target) * 100, 100)}%`,
                  left: 0
                }}
              />
            )}
          </div>
          
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-600">
              {Math.round(goal.target - goal.actual) > 0 ? `€${Math.round(goal.target - goal.actual).toLocaleString()} to go` : 'Target achieved'}
            </span>
            <span className={`font-semibold ${getStatusColor(goal.status)} capitalize`}>
              {goal.status.replace('-', ' ')}
            </span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Goals & Forecasts</h1>
          <p className="text-gray-600 mt-1">Track performance, set targets, and predict future growth</p>
        </div>
        
        <div className="flex items-center gap-3">
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="px-4 py-2.5 bg-white border border-gray-200 rounded-xl font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
          >
            <option value="month">This Month</option>
            <option value="quarter">This Quarter</option>
            <option value="year">This Year</option>
          </select>

          <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl p-1">
            <button
              onClick={() => setViewMode("overview")}
              className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition ${
                viewMode === "overview" ? "bg-indigo-600 text-white" : "text-gray-600 hover:bg-gray-50"
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setViewMode("detailed")}
              className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition ${
                viewMode === "detailed" ? "bg-indigo-600 text-white" : "text-gray-600 hover:bg-gray-50"
              }`}
            >
              Detailed
            </button>
            <button
              onClick={() => setViewMode("forecast")}
              className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition ${
                viewMode === "forecast" ? "bg-indigo-600 text-white" : "text-gray-600 hover:bg-gray-50"
              }`}
            >
              Forecast
            </button>
          </div>

          <button
            onClick={() => setIsEditingGoals(!isEditingGoals)}
            className="px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50 transition flex items-center gap-2"
          >
            <Edit className="w-4 h-4" />
            Edit Goals
          </button>
          
          <button
            onClick={exportForecast}
            className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl text-sm font-semibold transition-all flex items-center gap-2 shadow-md"
          >
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      <div className="bg-gradient-to-br from-indigo-50 to-purple-50 border-2 border-indigo-200 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center">
              <Target className="w-8 h-8 text-white" />
            </div>
            <div>
              <p className="text-sm font-bold text-indigo-900">Performance Period: {periodLabel}</p>
              <p className="text-xs text-indigo-700 mt-1">
                {format(periodStart, 'MMMM d, yyyy')} - {format(periodEnd, 'MMMM d, yyyy')}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs font-semibold text-indigo-700">Overall Performance</p>
            <div className="flex items-center gap-2 mt-1">
              <div className="w-24 h-3 bg-white rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 transition-all duration-500"
                  style={{ width: `${performanceScore}%` }}
                />
              </div>
              <span className="text-2xl font-bold text-indigo-900">{performanceScore}%</span>
            </div>
          </div>
        </div>
      </div>

      {viewMode === "overview" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <GoalCard
              title="Revenue Target"
              goal={currentGoals.revenue}
              icon={DollarSign}
              colorClass="bg-gradient-to-br from-green-100 to-emerald-100"
              format={(val) => `€${val.toLocaleString()}`}
            />
            
            <GoalCard
              title="Package Sales"
              goal={currentGoals.packages}
              icon={Award}
              colorClass="bg-gradient-to-br from-purple-100 to-fuchsia-100"
              format={(val) => `${val}`}
            />
            
            <GoalCard
              title="Lessons Target"
              goal={currentGoals.lessons}
              icon={Calendar}
              colorClass="bg-gradient-to-br from-blue-100 to-cyan-100"
              format={(val) => `${val}`}
            />
            
            <GoalCard
              title="Instructor Utilization"
              goal={currentGoals.instructorUtilization}
              colorClass="bg-gradient-to-br from-amber-100 to-orange-100"
              icon={Users}
              format={(val) => `${val.toFixed(0)}%`}
            />
            
            <GoalCard
              title="Fleet Utilization"
              goal={currentGoals.vehicleUtilization}
              icon={Car}
              colorClass="bg-gradient-to-br from-indigo-100 to-purple-100"
              format={(val) => `${val.toFixed(0)}%`}
            />
            
            <GoalCard
              title="New Students"
              goal={currentGoals.newStudents}
              icon={Users}
              colorClass="bg-gradient-to-br from-pink-100 to-rose-100"
              format={(val) => `${val}`}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl p-6 border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Performance Trends</h3>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart 
                  data={[
                    { name: 'Revenue', value: currentGoals.revenue.progress },
                    { name: 'Packages', value: currentGoals.packages.progress },
                    { name: 'Lessons', value: currentGoals.lessons.progress },
                    { name: 'Instructors', value: currentGoals.instructorUtilization.progress },
                    { name: 'Vehicles', value: currentGoals.vehicleUtilization.progress }
                  ]}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="name" stroke="#9ca3af" style={{ fontSize: '12px' }} />
                  <YAxis stroke="#9ca3af" style={{ fontSize: '12px' }} />
                  <Tooltip />
                  <Area type="monotone" dataKey="value" stroke="#6366f1" fill="#6366f1" fillOpacity={0.2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Goal Achievement Status</h3>
              <div className="space-y-4">
                {[
                  { label: 'Achieved', count: Object.values(currentGoals).filter(g => g.status === 'achieved').length, color: 'green' },
                  { label: 'On Track', count: Object.values(currentGoals).filter(g => g.status === 'on-track').length, color: 'blue' },
                  { label: 'At Risk', count: Object.values(currentGoals).filter(g => g.status === 'at-risk').length, color: 'amber' },
                  { label: 'Behind', count: Object.values(currentGoals).filter(g => g.status === 'behind').length, color: 'red' }
                ].map(item => {
                  const total = Object.values(currentGoals).length;
                  const percentage = (item.count / total) * 100;
                  
                  return (
                    <div key={item.label}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-semibold text-gray-700">{item.label}</span>
                        <span className="text-sm font-bold text-gray-900">{item.count} of {total}</span>
                      </div>
                      <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className={`h-full bg-gradient-to-r from-${item.color}-500 to-${item.color}-600 transition-all duration-500`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </>
      )}

      {viewMode === "forecast" && (
        <>
          <div className="bg-white rounded-2xl p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Revenue Forecast - Next 6 Months</h3>
                <p className="text-sm text-gray-600 mt-1">Projected revenue based on historical trends and growth patterns</p>
              </div>
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-gray-400" />
                <span className="text-xs text-gray-600">Confidence intervals shown</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={400}>
              <AreaChart data={forecast}>
                <defs>
                  <linearGradient id="colorForecast" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorUpper" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="month" stroke="#9ca3af" style={{ fontSize: '12px' }} />
                <YAxis stroke="#9ca3af" style={{ fontSize: '12px' }} tickFormatter={(value) => `€${(value / 1000).toFixed(0)}k`} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '12px',
                    padding: '12px'
                  }}
                  formatter={(value) => [`€${value.toLocaleString()}`, '']}
                  labelFormatter={(label) => `Period: ${label}`}
                />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="upper" 
                  stroke="none" 
                  fill="url(#colorUpper)" 
                  name="Upper Bound"
                />
                <Area 
                  type="monotone" 
                  dataKey="forecasted" 
                  stroke="#6366f1" 
                  strokeWidth={3} 
                  fill="url(#colorForecast)"
                  name="Forecasted"
                />
                <Area 
                  type="monotone" 
                  dataKey="lower" 
                  stroke="none" 
                  fill="url(#colorForecast)" 
                  fillOpacity={0.1}
                  name="Lower Bound"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {forecast.slice(0, 3).map((month, index) => (
              <div key={index} className="bg-white rounded-2xl p-6 border border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-sm font-bold text-gray-900">{month.month}</h4>
                  <span className="px-2 py-1 bg-indigo-100 text-indigo-700 rounded-full text-xs font-bold">
                    {month.confidence}% confidence
                  </span>
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-gray-600 mb-1">Forecasted Revenue</p>
                    <p className="text-2xl font-bold text-gray-900">€{month.forecasted.toLocaleString()}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <p className="text-xs text-blue-700 mb-1">Best Case</p>
                      <p className="text-sm font-bold text-blue-900">€{month.upper.toLocaleString()}</p>
                    </div>
                    <div className="p-3 bg-amber-50 rounded-lg">
                      <p className="text-xs text-amber-700 mb-1">Worst Case</p>
                      <p className="text-sm font-bold text-amber-900">€{month.lower.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border-2 border-purple-200">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
            <Lightbulb className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">AI-Powered Recommendations</h3>
            <p className="text-sm text-gray-600">Actionable insights to achieve your goals</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recommendations.map((rec) => (
            <div key={rec.id} className="bg-white/80 backdrop-blur rounded-xl p-5 border-2 border-purple-100 hover:border-purple-300 transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-600" />
                  <span className={`px-2 py-1 rounded-full text-xs font-bold border ${getPriorityColor(rec.priority)}`}>
                    {rec.priority.toUpperCase()}
                  </span>
                </div>
                <span className="text-xs text-gray-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {rec.estimatedDays}d
                </span>
              </div>
              <p className="text-sm font-semibold text-gray-900 mb-2">{rec.message}</p>
              <div className="flex items-center justify-between">
                <p className="text-xs text-purple-700 font-bold">{rec.impact}</p>
                {rec.actionable && (
                  <button className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-semibold transition flex items-center gap-1">
                    <Zap className="w-3 h-3" />
                    Take Action
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {isEditingGoals && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900">Edit Goals</h3>
              <button
                onClick={() => setIsEditingGoals(false)}
                className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-xl flex items-center justify-center transition"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6">
              <div className="space-y-4">
                {[
                  { key: 'revenue_target', label: 'Revenue Target', prefix: '€', current: currentGoals.revenue.target },
                  { key: 'package_sales_target', label: 'Package Sales Target', prefix: '', current: currentGoals.packages.target },
                  { key: 'lesson_count_target', label: 'Lessons Target', prefix: '', current: currentGoals.lessons.target },
                  { key: 'instructor_utilization_target', label: 'Instructor Utilization %', prefix: '', current: currentGoals.instructorUtilization.target },
                  { key: 'vehicle_utilization_target', label: 'Vehicle Utilization %', prefix: '', current: currentGoals.vehicleUtilization.target },
                  { key: 'new_students_target', label: 'New Students Target', prefix: '', current: currentGoals.newStudents.target }
                ].map(field => (
                  <div key={field.key}>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      {field.label}
                    </label>
                    <div className="relative">
                      {field.prefix && (
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-medium">
                          {field.prefix}
                        </span>
                      )}
                      <input
                        type="number"
                        defaultValue={field.current}
                        onChange={(e) => setCustomGoals({ ...customGoals, [field.key]: Number(e.target.value) })}
                        className={`w-full ${field.prefix ? 'pl-10' : 'pl-4'} pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition`}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-6 border-t border-gray-200 flex gap-3">
              <button
                onClick={() => setIsEditingGoals(false)}
                className="flex-1 px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveGoals}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl font-semibold transition-all flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save Goals
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
            <Info className="w-5 h-5 text-blue-600" />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-bold text-blue-900 mb-2">About Goals & Forecasting</h4>
            <div className="space-y-2 text-sm text-blue-800">
              <p>• Goals are tracked in real-time based on completed bookings and payments</p>
              <p>• Forecasts use historical data and growth trends with confidence intervals</p>
              <p>• Status indicators: Achieved (100%+), On Track (95%+), At Risk (75-95%), Behind (&lt;75%)</p>
              <p>• Projections are calculated based on current run-rate and remaining days in period</p>
              <p>• AI recommendations prioritize high-impact, actionable strategies for goal achievement</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}