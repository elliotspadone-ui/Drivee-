import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { CheckCircle, XCircle, Loader2, Activity } from "lucide-react";
import { APP_CONFIG } from "@/components/utils/config";

export default function Health() {
  const [status, setStatus] = useState("checking");
  const [checks, setChecks] = useState({
    auth: { status: "pending", message: "" },
    database: { status: "pending", message: "" },
    timestamp: null,
  });

  useEffect(() => {
    const runHealthChecks = async () => {
      const results = {
        auth: { status: "pending", message: "" },
        database: { status: "pending", message: "" },
        timestamp: new Date().toISOString(),
      };

      // Check auth service
      try {
        const isAuth = await base44.auth.isAuthenticated();
        results.auth = {
          status: "healthy",
          message: isAuth ? "Authenticated" : "Not authenticated (expected for health check)",
        };
      } catch (err) {
        results.auth = {
          status: "error",
          message: err.message || "Auth service unreachable",
        };
      }

      // Check database connectivity
      try {
        await base44.entities.School.list();
        results.database = {
          status: "healthy",
          message: "Database connected",
        };
      } catch (err) {
        results.database = {
          status: "error",
          message: err.message || "Database unreachable",
        };
      }

      const allHealthy = results.auth.status === "healthy" && results.database.status === "healthy";
      setStatus(allHealthy ? "healthy" : "degraded");
      setChecks(results);
    };

    runHealthChecks();
  }, []);

  const getStatusColor = (checkStatus) => {
    switch (checkStatus) {
      case "healthy":
        return "text-green-600 bg-green-100";
      case "error":
        return "text-red-600 bg-red-100";
      default:
        return "text-yellow-600 bg-yellow-100";
    }
  };

  const getStatusIcon = (checkStatus) => {
    switch (checkStatus) {
      case "healthy":
        return <CheckCircle className="w-5 h-5" />;
      case "error":
        return <XCircle className="w-5 h-5" />;
      default:
        return <Loader2 className="w-5 h-5 animate-spin" />;
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 p-8">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-zinc-200 bg-gradient-to-r from-zinc-50 to-white">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                status === "healthy" ? "bg-green-100" : status === "degraded" ? "bg-yellow-100" : "bg-zinc-100"
              }`}>
                <Activity className={`w-6 h-6 ${
                  status === "healthy" ? "text-green-600" : status === "degraded" ? "text-yellow-600" : "text-zinc-400"
                }`} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-zinc-900">System Health</h1>
                <p className="text-sm text-zinc-600">
                  Status: <span className="font-semibold capitalize">{status}</span>
                </p>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-4">
            {/* App Info */}
            <div className="p-4 bg-zinc-50 rounded-xl">
              <h3 className="text-sm font-bold text-zinc-700 mb-3">Application Info</h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-zinc-500">Version</p>
                  <p className="font-semibold text-zinc-900">{APP_CONFIG.APP_VERSION}</p>
                </div>
                <div>
                  <p className="text-zinc-500">Environment</p>
                  <p className="font-semibold text-zinc-900 capitalize">{APP_CONFIG.APP_ENV}</p>
                </div>
                <div>
                  <p className="text-zinc-500">Timestamp</p>
                  <p className="font-semibold text-zinc-900 text-xs">
                    {checks.timestamp ? new Date(checks.timestamp).toLocaleString() : "-"}
                  </p>
                </div>
              </div>
            </div>

            {/* Service Checks */}
            <div>
              <h3 className="text-sm font-bold text-zinc-700 mb-3">Service Status</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-4 bg-zinc-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getStatusColor(checks.auth.status)}`}>
                      {getStatusIcon(checks.auth.status)}
                    </div>
                    <div>
                      <p className="font-semibold text-zinc-900">Authentication</p>
                      <p className="text-xs text-zinc-500">{checks.auth.message}</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-zinc-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getStatusColor(checks.database.status)}`}>
                      {getStatusIcon(checks.database.status)}
                    </div>
                    <div>
                      <p className="font-semibold text-zinc-900">Database</p>
                      <p className="text-xs text-zinc-500">{checks.database.message}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}