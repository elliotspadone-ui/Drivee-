import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  BookOpen,
  Video,
  FileText,
  Download,
  ArrowLeft,
  Plus,
  Trash2,
  Edit,
  Users,
  CheckCircle,
  AlertCircle,
  Loader2,
  X,
  Search,
  Filter,
  Eye,
  Share2,
  Lock,
  Unlock,
  UserPlus,
  UserMinus,
  Star,
  Clock,
  Target,
  Award,
  PlayCircle,
  FileCheck,
  Upload,
  FolderOpen,
  Grid,
  List,
  MoreVertical,
  Copy,
  ExternalLink,
  Heart,
  Bookmark,
  BookmarkCheck,
  TrendingUp,
  BarChart3,
  PieChart,
  Calendar,
  MessageSquare,
  Send,
  GraduationCap,
  Zap,
  RefreshCw,
  ChevronRight,
  ChevronDown,
  Settings,
  Tag,
  Link as LinkIcon,
  Image as ImageIcon,
  File,
  Headphones,
  HelpCircle,
  Info,
  CheckCircle2,
  XCircle,
  AlertTriangle
} from "lucide-react";
import { format, differenceInDays, subDays } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const RESOURCE_TYPES = {
  video: { icon: Video, label: "Video", color: "red" },
  quiz: { icon: Target, label: "Quiz", color: "purple" },
  document: { icon: FileText, label: "Document", color: "blue" },
  audio: { icon: Headphones, label: "Audio", color: "green" },
  link: { icon: LinkIcon, label: "External Link", color: "amber" },
  image: { icon: ImageIcon, label: "Image/Diagram", color: "pink" }
};

const CATEGORIES = {
  theory: { label: "Theory", color: "indigo", description: "Road rules and regulations" },
  practical: { label: "Practical", color: "purple", description: "Driving techniques and maneuvers" },
  safety: { label: "Safety", color: "green", description: "Defensive and safe driving" },
  test_prep: { label: "Test Prep", color: "amber", description: "Exam preparation materials" },
  special: { label: "Special Conditions", color: "blue", description: "Night, weather, highway driving" }
};

const DIFFICULTY_LEVELS = {
  beginner: { label: "Beginner", color: "green" },
  intermediate: { label: "Intermediate", color: "amber" },
  advanced: { label: "Advanced", color: "red" }
};

export default function InstructorResources() {
  const queryClient = useQueryClient();
  
  const [user, setUser] = useState(null);
  const [instructor, setInstructor] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("all");
  const [activeCategory, setActiveCategory] = useState("all");
  const [viewMode, setViewMode] = useState("grid");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [selectedResource, setSelectedResource] = useState(null);
  const [selectedStudents, setSelectedStudents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [bulkSelectMode, setBulkSelectMode] = useState(false);
  const [selectedResourceIds, setSelectedResourceIds] = useState(new Set());
  const [expandedFolders, setExpandedFolders] = useState(new Set(["all"]));

  const [newResource, setNewResource] = useState({
    title: "",
    description: "",
    url: "",
    type: "video",
    category: "theory",
    difficulty: "beginner",
    duration: "",
    tags: [],
    is_featured: false,
    is_public: true
  });

  const [tagInput, setTagInput] = useState("");

  useEffect(() => {
    const loadUser = async () => {
      try {
        setIsLoading(true);
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        const instructors = await base44.entities.Instructor.filter({ email: currentUser.email });
        if (instructors.length > 0) {
          setInstructor(instructors[0]);
        }
      } catch (error) {
        console.error("Error loading user:", error);
        toast.error("Failed to load user data");
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: students = [] } = useQuery({
    queryKey: ['instructorStudents', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      const bookings = await base44.entities.Booking.filter({ instructor_id: instructor.id });
      const studentIds = [...new Set(bookings.map(b => b.student_id))];
      if (studentIds.length === 0) return [];
      const allStudents = await base44.entities.Student.list();
      return allStudents.filter(s => studentIds.includes(s.id));
    },
    enabled: !!instructor,
  });

  const { data: dbResources = [], isLoading: loadingResources } = useQuery({
    queryKey: ['instructorResources', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      try {
        return await base44.entities.Resource.filter({ instructor_id: instructor.id });
      } catch {
        return [];
      }
    },
    enabled: !!instructor,
  });

  const { data: resourceShares = [] } = useQuery({
    queryKey: ['resourceShares', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      try {
        return await base44.entities.ResourceShare.filter({ instructor_id: instructor.id });
      } catch {
        return [];
      }
    },
    enabled: !!instructor,
  });

  const { data: resourceAnalytics = [] } = useQuery({
    queryKey: ['resourceAnalytics', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      try {
        return await base44.entities.ResourceAnalytics.filter({ instructor_id: instructor.id });
      } catch {
        return [];
      }
    },
    enabled: !!instructor,
  });

  const sampleResources = useMemo(() => [
    {
      id: "sample-1",
      title: "Parallel Parking Masterclass",
      description: "Step-by-step guide to perfect parallel parking every time. Learn the reference points and techniques used by professional instructors.",
      type: "video",
      category: "practical",
      difficulty: "intermediate",
      url: "https://www.youtube.com/watch?v=example1",
      duration: "15:30",
      tags: ["parking", "maneuvers", "practical"],
      views: 145,
      completions: 89,
      rating: 4.8,
      is_featured: true,
      is_public: true,
      shared_with: [],
      created_at: subDays(new Date(), 30).toISOString()
    },
    {
      id: "sample-2",
      title: "Road Signs Quiz - Advanced Level",
      description: "Comprehensive quiz covering all European road signs including warning, regulatory, and informational signs.",
      type: "quiz",
      category: "theory",
      difficulty: "advanced",
      questions: 50,
      pass_score: 43,
      tags: ["signs", "theory", "test-prep"],
      attempts: 234,
      avg_score: 82,
      is_featured: false,
      is_public: true,
      shared_with: [],
      created_at: subDays(new Date(), 25).toISOString()
    },
    {
      id: "sample-3",
      title: "Defensive Driving Techniques",
      description: "Learn how to anticipate and avoid dangerous situations on the road. Essential viewing for all students.",
      type: "video",
      category: "safety",
      difficulty: "beginner",
      url: "https://www.youtube.com/watch?v=example2",
      duration: "22:15",
      tags: ["safety", "defensive", "essential"],
      views: 312,
      completions: 198,
      rating: 4.9,
      is_featured: true,
      is_public: true,
      shared_with: [],
      created_at: subDays(new Date(), 20).toISOString()
    },
    {
      id: "sample-4",
      title: "Highway Driving Complete Guide",
      description: "Everything you need to know about safe highway driving - merging, lane changes, overtaking, and exit strategies.",
      type: "document",
      category: "special",
      difficulty: "intermediate",
      pages: 24,
      file_size: "2.4 MB",
      tags: ["highway", "motorway", "advanced-driving"],
      downloads: 156,
      is_featured: false,
      is_public: true,
      shared_with: [],
      created_at: subDays(new Date(), 15).toISOString()
    },
    {
      id: "sample-5",
      title: "Theory Test Practice - Official Style",
      description: "50 practice questions matching the official theory test format. Includes hazard perception guidance.",
      type: "quiz",
      category: "test_prep",
      difficulty: "intermediate",
      questions: 50,
      pass_score: 43,
      time_limit: 57,
      tags: ["theory-test", "official", "practice"],
      attempts: 567,
      avg_score: 78,
      is_featured: true,
      is_public: true,
      shared_with: [],
      created_at: subDays(new Date(), 10).toISOString()
    },
    {
      id: "sample-6",
      title: "Night Driving Safety Tips",
      description: "Essential techniques and precautions for safe night driving. Covers visibility, fatigue, and special hazards.",
      type: "video",
      category: "special",
      difficulty: "beginner",
      url: "https://www.youtube.com/watch?v=example3",
      duration: "18:45",
      tags: ["night", "visibility", "safety"],
      views: 189,
      completions: 134,
      rating: 4.7,
      is_featured: false,
      is_public: true,
      shared_with: [],
      created_at: subDays(new Date(), 5).toISOString()
    },
    {
      id: "sample-7",
      title: "Roundabout Navigation Guide",
      description: "Master roundabouts of all sizes - mini, standard, and multi-lane. Includes spiral roundabout techniques.",
      type: "video",
      category: "practical",
      difficulty: "intermediate",
      url: "https://www.youtube.com/watch?v=example4",
      duration: "20:00",
      tags: ["roundabouts", "junctions", "navigation"],
      views: 267,
      completions: 201,
      rating: 4.6,
      is_featured: false,
      is_public: true,
      shared_with: [],
      created_at: subDays(new Date(), 3).toISOString()
    },
    {
      id: "sample-8",
      title: "Emergency Stop Procedure",
      description: "Audio guide explaining the correct procedure for emergency stops. Perfect for listening during practice.",
      type: "audio",
      category: "practical",
      difficulty: "beginner",
      duration: "8:30",
      tags: ["emergency", "stopping", "procedure"],
      plays: 423,
      is_featured: false,
      is_public: true,
      shared_with: [],
      created_at: subDays(new Date(), 1).toISOString()
    }
  ], []);

  const allResources = useMemo(() => {
    const combined = [...sampleResources];
    dbResources.forEach(dbRes => {
      if (!combined.find(r => r.id === dbRes.id)) {
        combined.push({
          ...dbRes,
          shared_with: resourceShares
            .filter(s => s.resource_id === dbRes.id)
            .map(s => s.student_id)
        });
      }
    });
    return combined;
  }, [sampleResources, dbResources, resourceShares]);

  const [resources, setResources] = useState([]);

  useEffect(() => {
    setResources(allResources);
  }, [allResources]);

  const createResourceMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.Resource.create({
        ...data,
        instructor_id: instructor?.id,
        created_at: new Date().toISOString()
      });
    },
    onSuccess: (newRes) => {
      queryClient.invalidateQueries({ queryKey: ['instructorResources'] });
      setResources(prev => [...prev, { ...newRes, shared_with: [] }]);
      toast.success("Resource added successfully");
      setShowAddModal(false);
      resetNewResource();
    },
    onError: () => {
      toast.error("Failed to add resource");
    }
  });

  const updateResourceMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Resource.update(id, data);
    },
    onSuccess: (updatedRes) => {
      queryClient.invalidateQueries({ queryKey: ['instructorResources'] });
      setResources(prev => prev.map(r => r.id === updatedRes.id ? { ...r, ...updatedRes } : r));
      toast.success("Resource updated successfully");
      setShowEditModal(false);
      setSelectedResource(null);
    },
    onError: () => {
      toast.error("Failed to update resource");
    }
  });

  const deleteResourceMutation = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.Resource.delete(id);
    },
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: ['instructorResources'] });
      setResources(prev => prev.filter(r => r.id !== id));
      toast.success("Resource deleted successfully");
      setShowDeleteConfirm(false);
      setSelectedResource(null);
    },
    onError: () => {
      toast.error("Failed to delete resource");
    }
  });

  const shareResourceMutation = useMutation({
    mutationFn: async ({ resourceIds, studentIds }) => {
      const shares = [];
      for (const resourceId of resourceIds) {
        for (const studentId of studentIds) {
          shares.push({
            resource_id: resourceId,
            student_id: studentId,
            instructor_id: instructor?.id,
            shared_at: new Date().toISOString()
          });
        }
      }
      return Promise.all(shares.map(s => base44.entities.ResourceShare.create(s)));
    },
    onSuccess: (_, { resourceIds, studentIds }) => {
      queryClient.invalidateQueries({ queryKey: ['resourceShares'] });
      setResources(prev => prev.map(r => 
        resourceIds.includes(r.id)
          ? { ...r, shared_with: [...new Set([...r.shared_with, ...studentIds])] }
          : r
      ));
      toast.success(`Shared ${resourceIds.length} resource${resourceIds.length !== 1 ? 's' : ''} with ${studentIds.length} student${studentIds.length !== 1 ? 's' : ''}`);
      setShowShareModal(false);
      setSelectedStudents([]);
      setSelectedResourceIds(new Set());
      setSelectedResource(null);
    },
    onError: () => {
      toast.error("Failed to share resources");
    }
  });

  const resetNewResource = () => {
    setNewResource({
      title: "",
      description: "",
      url: "",
      type: "video",
      category: "theory",
      difficulty: "beginner",
      duration: "",
      tags: [],
      is_featured: false,
      is_public: true
    });
    setTagInput("");
  };

  const handleAddTag = () => {
    const tag = tagInput.trim().toLowerCase();
    if (tag && !newResource.tags.includes(tag)) {
      setNewResource(prev => ({
        ...prev,
        tags: [...prev.tags, tag]
      }));
      setTagInput("");
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setNewResource(prev => ({
      ...prev,
      tags: prev.tags.filter(t => t !== tagToRemove)
    }));
  };

  const handleShareResource = () => {
    if (selectedStudents.length === 0) {
      toast.error("Please select at least one student");
      return;
    }

    const resourceIds = selectedResourceIds.size > 0 
      ? Array.from(selectedResourceIds)
      : selectedResource ? [selectedResource.id] : [];

    if (resourceIds.length === 0) {
      toast.error("No resources selected");
      return;
    }

    shareResourceMutation.mutate({ resourceIds, studentIds: selectedStudents });
  };

  const handleRevokeAccess = (resourceId, studentId) => {
    setResources(prev => prev.map(r => 
      r.id === resourceId 
        ? { ...r, shared_with: r.shared_with.filter(id => id !== studentId) }
        : r
    ));
    toast.success("Access revoked");
  };

  const handleBulkAction = (action) => {
    if (selectedResourceIds.size === 0) {
      toast.error("Please select at least one resource");
      return;
    }

    if (action === "share") {
      setShowShareModal(true);
    } else if (action === "delete") {
      setShowDeleteConfirm(true);
    } else if (action === "feature") {
      setResources(prev => prev.map(r => 
        selectedResourceIds.has(r.id) ? { ...r, is_featured: true } : r
      ));
      toast.success(`${selectedResourceIds.size} resource${selectedResourceIds.size !== 1 ? 's' : ''} featured`);
      setSelectedResourceIds(new Set());
      setBulkSelectMode(false);
    }
  };

  const toggleResourceSelection = (id) => {
    setSelectedResourceIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const selectAllResources = () => {
    if (selectedResourceIds.size === filteredResources.length) {
      setSelectedResourceIds(new Set());
    } else {
      setSelectedResourceIds(new Set(filteredResources.map(r => r.id)));
    }
  };

  const filteredResources = useMemo(() => {
    let filtered = resources;

    if (activeTab !== "all") {
      filtered = filtered.filter(r => r.type === activeTab);
    }

    if (activeCategory !== "all") {
      filtered = filtered.filter(r => r.category === activeCategory);
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(r => 
        r.title?.toLowerCase().includes(term) ||
        r.description?.toLowerCase().includes(term) ||
        r.tags?.some(t => t.toLowerCase().includes(term))
      );
    }

    filtered.sort((a, b) => {
      if (sortBy === "newest") return new Date(b.created_at) - new Date(a.created_at);
      if (sortBy === "oldest") return new Date(a.created_at) - new Date(b.created_at);
      if (sortBy === "popular") return (b.views || b.attempts || 0) - (a.views || a.attempts || 0);
      if (sortBy === "name") return a.title.localeCompare(b.title);
      if (sortBy === "rating") return (b.rating || 0) - (a.rating || 0);
      return 0;
    });

    return filtered;
  }, [resources, activeTab, activeCategory, searchTerm, sortBy]);

  const stats = useMemo(() => {
    const totalResources = resources.length;
    const totalViews = resources.reduce((sum, r) => sum + (r.views || r.attempts || r.plays || r.downloads || 0), 0);
    const totalShares = resources.reduce((sum, r) => sum + (r.shared_with?.length || 0), 0);
    const featuredCount = resources.filter(r => r.is_featured).length;
    const avgRating = resources.filter(r => r.rating).length > 0
      ? resources.filter(r => r.rating).reduce((sum, r) => sum + r.rating, 0) / resources.filter(r => r.rating).length
      : 0;

    const byType = Object.entries(RESOURCE_TYPES).map(([type, config]) => ({
      type,
      ...config,
      count: resources.filter(r => r.type === type).length
    }));

    const byCategory = Object.entries(CATEGORIES).map(([category, config]) => ({
      category,
      ...config,
      count: resources.filter(r => r.category === category).length
    }));

    return {
      totalResources,
      totalViews,
      totalShares,
      featuredCount,
      avgRating,
      byType,
      byCategory
    };
  }, [resources]);

  const getResourceIcon = (type) => RESOURCE_TYPES[type]?.icon || BookOpen;
  const getResourceColor = (type) => RESOURCE_TYPES[type]?.color || "gray";
  const getCategoryColor = (category) => CATEGORIES[category]?.color || "gray";
  const getDifficultyColor = (difficulty) => DIFFICULTY_LEVELS[difficulty]?.color || "gray";

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading resources...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Link
          to={createPageUrl("InstructorDashboard")}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Teaching Resources</h1>
            <p className="text-gray-600 mt-1">Manage and share learning materials with your students</p>
          </div>

          <div className="flex gap-3">
            {bulkSelectMode ? (
              <>
                <button
                  onClick={() => {
                    setBulkSelectMode(false);
                    setSelectedResourceIds(new Set());
                  }}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold transition"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleBulkAction("share")}
                  disabled={selectedResourceIds.size === 0}
                  className="px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-300 text-white rounded-xl font-semibold transition flex items-center gap-2"
                >
                  <Share2 className="w-4 h-4" />
                  Share ({selectedResourceIds.size})
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setBulkSelectMode(true)}
                  className="px-4 py-2 bg-white border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  Select
                </button>
                <button
                  onClick={() => setShowAddModal(true)}
                  className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl font-semibold shadow-md transition flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add Resource
                </button>
              </>
            )}
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 md:grid-cols-5 gap-4"
      >
        {[
          { label: "Total Resources", value: stats.totalResources, icon: BookOpen, color: "indigo" },
          { label: "Total Views", value: stats.totalViews, icon: Eye, color: "blue" },
          { label: "Shared", value: stats.totalShares, icon: Share2, color: "green" },
          { label: "Featured", value: stats.featuredCount, icon: Star, color: "amber" },
          { label: "Avg Rating", value: stats.avgRating > 0 ? stats.avgRating.toFixed(1) : "N/A", icon: Award, color: "purple" }
        ].map((stat, idx) => (
          <div key={idx} className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
            <div className={`w-10 h-10 bg-${stat.color}-100 rounded-lg flex items-center justify-center mb-2`}>
              <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-xs text-gray-600">{stat.label}</p>
          </div>
        ))}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm space-y-4"
      >
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search resources by title, description, or tags..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          <div className="flex gap-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="popular">Most Popular</option>
              <option value="name">Name (A-Z)</option>
              <option value="rating">Highest Rated</option>
            </select>

            <div className="flex gap-1 p-1 bg-gray-100 rounded-xl">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-lg transition ${viewMode === "grid" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
              >
                <Grid className="w-5 h-5 text-gray-600" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded-lg transition ${viewMode === "list" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
              >
                <List className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveTab("all")}
            className={`px-4 py-2 rounded-xl text-sm font-semibold transition ${
              activeTab === "all"
                ? "bg-indigo-100 text-indigo-700 border-2 border-indigo-200"
                : "bg-gray-100 text-gray-700 border-2 border-transparent hover:bg-gray-200"
            }`}
          >
            All Types
            <span className="ml-2 px-2 py-0.5 bg-white rounded-full text-xs">{resources.length}</span>
          </button>
          {Object.entries(RESOURCE_TYPES).map(([type, config]) => {
            const count = resources.filter(r => r.type === type).length;
            if (count === 0) return null;
            return (
              <button
                key={type}
                onClick={() => setActiveTab(type)}
                className={`px-4 py-2 rounded-xl text-sm font-semibold transition flex items-center gap-2 ${
                  activeTab === type
                    ? `bg-${config.color}-100 text-${config.color}-700 border-2 border-${config.color}-200`
                    : "bg-gray-100 text-gray-700 border-2 border-transparent hover:bg-gray-200"
                }`}
              >
                <config.icon className="w-4 h-4" />
                {config.label}
                <span className="px-2 py-0.5 bg-white rounded-full text-xs">{count}</span>
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeCategory === "all"
                ? "bg-gray-900 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            All Categories
          </button>
          {Object.entries(CATEGORIES).map(([category, config]) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeCategory === category
                  ? `bg-${config.color}-600 text-white`
                  : `bg-${config.color}-50 text-${config.color}-700 hover:bg-${config.color}-100`
              }`}
            >
              {config.label}
            </button>
          ))}
        </div>
      </motion.div>

      {bulkSelectMode && selectedResourceIds.size > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-indigo-50 border border-indigo-200 rounded-xl p-4 flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <button
              onClick={selectAllResources}
              className="px-3 py-1.5 bg-white border border-indigo-300 rounded-lg text-sm font-semibold text-indigo-700 hover:bg-indigo-50 transition"
            >
              {selectedResourceIds.size === filteredResources.length ? "Deselect All" : "Select All"}
            </button>
            <span className="text-sm font-semibold text-indigo-900">
              {selectedResourceIds.size} resource{selectedResourceIds.size !== 1 ? 's' : ''} selected
            </span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => handleBulkAction("share")}
              className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-semibold transition flex items-center gap-2"
            >
              <Share2 className="w-4 h-4" />
              Share Selected
            </button>
            <button
              onClick={() => handleBulkAction("feature")}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-sm font-semibold transition flex items-center gap-2"
            >
              <Star className="w-4 h-4" />
              Feature
            </button>
          </div>
        </motion.div>
      )}

      {viewMode === "grid" ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredResources.map((resource, index) => {
            const Icon = getResourceIcon(resource.type);
            const typeColor = getResourceColor(resource.type);
            const categoryColor = getCategoryColor(resource.category);
            const difficultyColor = getDifficultyColor(resource.difficulty);
            const sharedCount = resource.shared_with?.length || 0;
            const isSelected = selectedResourceIds.has(resource.id);

            return (
              <motion.div
                key={resource.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className={`bg-white rounded-2xl border-2 shadow-sm hover:shadow-md transition overflow-hidden ${
                  isSelected ? "border-indigo-500 ring-2 ring-indigo-100" : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      {bulkSelectMode && (
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleResourceSelection(resource.id)}
                          className="w-5 h-5 text-indigo-600 rounded"
                        />
                      )}
                      <div className={`w-12 h-12 bg-${typeColor}-100 rounded-xl flex items-center justify-center`}>
                        <Icon className={`w-6 h-6 text-${typeColor}-600`} />
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {resource.is_featured && (
                        <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                      )}
                      <button
                        onClick={() => {
                          setSelectedResource(resource);
                          setShowDetailsModal(true);
                        }}
                        className="p-2 hover:bg-gray-100 rounded-lg transition"
                      >
                        <MoreVertical className="w-5 h-5 text-gray-400" />
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-3">
                    <span className={`px-2 py-0.5 bg-${categoryColor}-50 text-${categoryColor}-700 rounded text-xs font-bold`}>
                      {CATEGORIES[resource.category]?.label || resource.category}
                    </span>
                    {resource.difficulty && (
                      <span className={`px-2 py-0.5 bg-${difficultyColor}-50 text-${difficultyColor}-700 rounded text-xs font-bold`}>
                        {DIFFICULTY_LEVELS[resource.difficulty]?.label || resource.difficulty}
                      </span>
                    )}
                  </div>

                  <h3 className="text-lg font-bold text-gray-900 mb-2 line-clamp-2">{resource.title}</h3>
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2">{resource.description}</p>

                  <div className="flex flex-wrap items-center gap-3 text-sm text-gray-600 mb-4">
                    {resource.duration && (
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{resource.duration}</span>
                      </div>
                    )}
                    {resource.questions && (
                      <div className="flex items-center gap-1">
                        <Target className="w-4 h-4" />
                        <span>{resource.questions} Q</span>
                      </div>
                    )}
                    {resource.pages && (
                      <div className="flex items-center gap-1">
                        <FileText className="w-4 h-4" />
                        <span>{resource.pages} pages</span>
                      </div>
                    )}
                    {resource.views !== undefined && (
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        <span>{resource.views}</span>
                      </div>
                    )}
                    {resource.rating && (
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                        <span>{resource.rating}</span>
                      </div>
                    )}
                  </div>

                  {resource.tags && resource.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-4">
                      {resource.tags.slice(0, 3).map((tag) => (
                        <span key={tag} className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs">
                          #{tag}
                        </span>
                      ))}
                      {resource.tags.length > 3 && (
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs">
                          +{resource.tags.length - 3}
                        </span>
                      )}
                    </div>
                  )}

                  {sharedCount > 0 && (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-2 mb-4">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-green-600" />
                        <span className="text-xs font-semibold text-green-900">
                          Shared with {sharedCount} student{sharedCount !== 1 ? 's' : ''}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setSelectedResource(resource);
                        setShowShareModal(true);
                      }}
                      className="flex-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold text-sm transition flex items-center justify-center gap-2"
                    >
                      <Share2 className="w-4 h-4" />
                      Share
                    </button>
                    
                    {resource.url && (
                      <a
                        href={resource.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-lg font-semibold text-sm transition flex items-center justify-center gap-2"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                {bulkSelectMode && (
                  <th className="px-4 py-3 text-left">
                    <input
                      type="checkbox"
                      checked={selectedResourceIds.size === filteredResources.length && filteredResources.length > 0}
                      onChange={selectAllResources}
                      className="w-5 h-5 text-indigo-600 rounded"
                    />
                  </th>
                )}
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Resource</th>
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Type</th>
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Category</th>
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Stats</th>
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Shared</th>
                <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredResources.map((resource) => {
                const Icon = getResourceIcon(resource.type);
                const typeColor = getResourceColor(resource.type);
                const categoryColor = getCategoryColor(resource.category);
                const sharedCount = resource.shared_with?.length || 0;
                const isSelected = selectedResourceIds.has(resource.id);

                return (
                  <tr key={resource.id} className={`hover:bg-gray-50 transition ${isSelected ? "bg-indigo-50" : ""}`}>
                    {bulkSelectMode && (
                      <td className="px-4 py-4">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleResourceSelection(resource.id)}
                          className="w-5 h-5 text-indigo-600 rounded"
                        />
                      </td>
                    )}
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 bg-${typeColor}-100 rounded-lg flex items-center justify-center`}>
                          <Icon className={`w-5 h-5 text-${typeColor}-600`} />
                        </div>
                        <div>
                          <p className="font-bold text-gray-900 flex items-center gap-2">
                            {resource.title}
                            {resource.is_featured && <Star className="w-4 h-4 text-amber-500 fill-amber-500" />}
                          </p>
                          <p className="text-xs text-gray-600 line-clamp-1 max-w-xs">{resource.description}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <span className={`px-2 py-1 bg-${typeColor}-50 text-${typeColor}-700 rounded text-xs font-bold`}>
                        {RESOURCE_TYPES[resource.type]?.label || resource.type}
                      </span>
                    </td>
                    <td className="px-4 py-4">
                      <span className={`px-2 py-1 bg-${categoryColor}-50 text-${categoryColor}-700 rounded text-xs font-bold`}>
                        {CATEGORIES[resource.category]?.label || resource.category}
                      </span>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-3 text-sm text-gray-600">
                        {resource.views !== undefined && (
                          <span className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            {resource.views}
                          </span>
                        )}
                        {resource.rating && (
                          <span className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-amber-500" />
                            {resource.rating}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      {sharedCount > 0 ? (
                        <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">
                          {sharedCount} student{sharedCount !== 1 ? 's' : ''}
                        </span>
                      ) : (
                        <span className="text-gray-400 text-xs">Not shared</span>
                      )}
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => {
                            setSelectedResource(resource);
                            setShowShareModal(true);
                          }}
                          className="p-2 hover:bg-gray-100 rounded-lg transition"
                          title="Share"
                        >
                          <Share2 className="w-4 h-4 text-gray-600" />
                        </button>
                        <button
                          onClick={() => {
                            setSelectedResource(resource);
                            setShowDetailsModal(true);
                          }}
                          className="p-2 hover:bg-gray-100 rounded-lg transition"
                          title="Details"
                        >
                          <Eye className="w-4 h-4 text-gray-600" />
                        </button>
                        {resource.url && (
                          <a
                            href={resource.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 hover:bg-gray-100 rounded-lg transition"
                            title="Open"
                          >
                            <ExternalLink className="w-4 h-4 text-gray-600" />
                          </a>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filteredResources.length === 0 && (
            <div className="text-center py-12">
              <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No resources found</p>
            </div>
          )}
        </div>
      )}

      {filteredResources.length === 0 && !loadingResources && (
        <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
          <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">No resources found</h3>
          <p className="text-gray-600 mb-6">
            {searchTerm ? "Try adjusting your search or filters" : "Start by adding your first teaching resource"}
          </p>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition flex items-center gap-2 mx-auto"
          >
            <Plus className="w-5 h-5" />
            Add Resource
          </button>
        </div>
      )}

      <AnimatePresence>
        {showShareModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowShareModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">
                    {selectedResourceIds.size > 0 
                      ? `Share ${selectedResourceIds.size} Resource${selectedResourceIds.size !== 1 ? 's' : ''}` 
                      : 'Share Resource'}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {selectedResource?.title || `Select students to share with`}
                  </p>
                </div>
                <button
                  onClick={() => setShowShareModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              {students.length > 0 ? (
                <>
                  <div className="mb-4 flex items-center justify-between">
                    <h4 className="text-sm font-bold text-gray-900">Select Students</h4>
                    <button
                      onClick={() => {
                        if (selectedStudents.length === students.length) {
                          setSelectedStudents([]);
                        } else {
                          setSelectedStudents(students.map(s => s.id));
                        }
                      }}
                      className="text-sm text-indigo-600 hover:text-indigo-700 font-semibold"
                    >
                      {selectedStudents.length === students.length ? "Deselect All" : "Select All"}
                    </button>
                  </div>

                  <div className="space-y-2 max-h-80 overflow-y-auto mb-6">
                    {students.map((student) => {
                      const isSelected = selectedStudents.includes(student.id);
                      const isAlreadyShared = selectedResource?.shared_with?.includes(student.id);

                      return (
                        <div
                          key={student.id}
                          className={`p-4 rounded-xl border-2 transition cursor-pointer ${
                            isSelected 
                              ? "border-indigo-500 bg-indigo-50" 
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                          onClick={() => {
                            if (isSelected) {
                              setSelectedStudents(prev => prev.filter(id => id !== student.id));
                            } else {
                              setSelectedStudents(prev => [...prev, student.id]);
                            }
                          }}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => {}}
                                className="w-5 h-5 text-indigo-600 rounded"
                              />
                              <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center">
                                <span className="text-white font-bold text-sm">
                                  {student.full_name?.charAt(0) || "S"}
                                </span>
                              </div>
                              <div>
                                <p className="font-bold text-gray-900">{student.full_name}</p>
                                <p className="text-xs text-gray-600">{student.email}</p>
                              </div>
                            </div>
                            {isAlreadyShared && (
                              <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">
                                Already Shared
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowShareModal(false)}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleShareResource}
                      disabled={selectedStudents.length === 0 || shareResourceMutation.isPending}
                      className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      {shareResourceMutation.isPending ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <>
                          <Share2 className="w-4 h-4" />
                          Share with {selectedStudents.length} Student{selectedStudents.length !== 1 ? 's' : ''}
                        </>
                      )}
                    </button>
                  </div>
                </>
              ) : (
                <div className="text-center py-8">
                  <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-600">No students assigned to you yet</p>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowAddModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Add New Resource</h3>
                <button
                  onClick={() => {
                    setShowAddModal(false);
                    resetNewResource();
                  }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Resource Type</label>
                    <select
                      value={newResource.type}
                      onChange={(e) => setNewResource({ ...newResource, type: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    >
                      {Object.entries(RESOURCE_TYPES).map(([type, config]) => (
                        <option key={type} value={type}>{config.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                    <select
                      value={newResource.category}
                      onChange={(e) => setNewResource({ ...newResource, category: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    >
                      {Object.entries(CATEGORIES).map(([category, config]) => (
                        <option key={category} value={category}>{config.label}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                  <input
                    type="text"
                    value={newResource.title}
                    onChange={(e) => setNewResource({ ...newResource, title: e.target.value })}
                    placeholder="Enter resource title"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                  <textarea
                    value={newResource.description}
                    onChange={(e) => setNewResource({ ...newResource, description: e.target.value })}
                    placeholder="Brief description of the resource"
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Difficulty Level</label>
                    <select
                      value={newResource.difficulty}
                      onChange={(e) => setNewResource({ ...newResource, difficulty: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    >
                      {Object.entries(DIFFICULTY_LEVELS).map(([level, config]) => (
                        <option key={level} value={level}>{config.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Duration (optional)</label>
                    <input
                      type="text"
                      value={newResource.duration}
                      onChange={(e) => setNewResource({ ...newResource, duration: e.target.value })}
                      placeholder="e.g., 15:30"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">URL</label>
                  <input
                    type="url"
                    value={newResource.url}
                    onChange={(e) => setNewResource({ ...newResource, url: e.target.value })}
                    placeholder="https://..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Tags</label>
                  <div className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), handleAddTag())}
                      placeholder="Add tag..."
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                    <button
                      onClick={handleAddTag}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg font-semibold text-gray-700 transition"
                    >
                      Add
                    </button>
                  </div>
                  {newResource.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {newResource.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-3 py-1 bg-gray-100 rounded-full text-sm flex items-center gap-1"
                        >
                          #{tag}
                          <button
                            onClick={() => handleRemoveTag(tag)}
                            className="ml-1 hover:text-red-600"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={newResource.is_featured}
                      onChange={(e) => setNewResource({ ...newResource, is_featured: e.target.checked })}
                      className="w-5 h-5 text-indigo-600 rounded"
                    />
                    <span className="text-sm text-gray-700">Feature this resource</span>
                  </label>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowAddModal(false);
                    resetNewResource();
                  }}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!newResource.title.trim()) {
                      toast.error("Please enter a title");
                      return;
                    }
                    
                    const resourceData = {
                      ...newResource,
                      id: `custom-${Date.now()}`,
                      shared_with: [],
                      views: 0,
                      created_at: new Date().toISOString()
                    };
                    
                    setResources(prev => [resourceData, ...prev]);
                    toast.success("Resource added successfully");
                    setShowAddModal(false);
                    resetNewResource();
                  }}
                  disabled={createResourceMutation.isPending}
                  className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                >
                  {createResourceMutation.isPending ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Plus className="w-4 h-4" />
                      Add Resource
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showDetailsModal && selectedResource && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => {
              setShowDetailsModal(false);
              setSelectedResource(null);
            }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Resource Details</h3>
                <button
                  onClick={() => {
                    setShowDetailsModal(false);
                    setSelectedResource(null);
                  }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className={`w-16 h-16 bg-${getResourceColor(selectedResource.type)}-100 rounded-xl flex items-center justify-center`}>
                    {React.createElement(getResourceIcon(selectedResource.type), {
                      className: `w-8 h-8 text-${getResourceColor(selectedResource.type)}-600`
                    })}
                  </div>
                  <div className="flex-1">
                    <h4 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                      {selectedResource.title}
                      {selectedResource.is_featured && <Star className="w-5 h-5 text-amber-500 fill-amber-500" />}
                    </h4>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <span className={`px-2 py-1 bg-${getResourceColor(selectedResource.type)}-50 text-${getResourceColor(selectedResource.type)}-700 rounded text-xs font-bold`}>
                        {RESOURCE_TYPES[selectedResource.type]?.label}
                      </span>
                      <span className={`px-2 py-1 bg-${getCategoryColor(selectedResource.category)}-50 text-${getCategoryColor(selectedResource.category)}-700 rounded text-xs font-bold`}>
                        {CATEGORIES[selectedResource.category]?.label}
                      </span>
                      {selectedResource.difficulty && (
                        <span className={`px-2 py-1 bg-${getDifficultyColor(selectedResource.difficulty)}-50 text-${getDifficultyColor(selectedResource.difficulty)}-700 rounded text-xs font-bold`}>
                          {DIFFICULTY_LEVELS[selectedResource.difficulty]?.label}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <p className="text-gray-700">{selectedResource.description}</p>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {selectedResource.duration && (
                    <div className="bg-gray-50 rounded-xl p-3 text-center">
                      <Clock className="w-5 h-5 text-gray-400 mx-auto mb-1" />
                      <p className="text-sm font-bold text-gray-900">{selectedResource.duration}</p>
                      <p className="text-xs text-gray-600">Duration</p>
                    </div>
                  )}
                  {selectedResource.views !== undefined && (
                    <div className="bg-gray-50 rounded-xl p-3 text-center">
                      <Eye className="w-5 h-5 text-gray-400 mx-auto mb-1" />
                      <p className="text-sm font-bold text-gray-900">{selectedResource.views}</p>
                      <p className="text-xs text-gray-600">Views</p>
                    </div>
                  )}
                  {selectedResource.rating && (
                    <div className="bg-gray-50 rounded-xl p-3 text-center">
                      <Star className="w-5 h-5 text-amber-500 mx-auto mb-1" />
                      <p className="text-sm font-bold text-gray-900">{selectedResource.rating}</p>
                      <p className="text-xs text-gray-600">Rating</p>
                    </div>
                  )}
                  <div className="bg-gray-50 rounded-xl p-3 text-center">
                    <Users className="w-5 h-5 text-gray-400 mx-auto mb-1" />
                    <p className="text-sm font-bold text-gray-900">{selectedResource.shared_with?.length || 0}</p>
                    <p className="text-xs text-gray-600">Shared</p>
                  </div>
                </div>

                {selectedResource.tags && selectedResource.tags.length > 0 && (
                  <div>
                    <p className="text-sm font-bold text-gray-700 mb-2">Tags</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedResource.tags.map((tag) => (
                        <span key={tag} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {selectedResource.shared_with?.length > 0 && (
                  <div>
                    <p className="text-sm font-bold text-gray-700 mb-2">Shared With</p>
                    <div className="space-y-2">
                      {selectedResource.shared_with.map((studentId) => {
                        const student = students.find(s => s.id === studentId);
                        if (!student) return null;
                        
                        return (
                          <div key={studentId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center">
                                <span className="text-white font-bold text-xs">
                                  {student.full_name?.charAt(0)}
                                </span>
                              </div>
                              <span className="font-medium text-gray-900">{student.full_name}</span>
                            </div>
                            <button
                              onClick={() => handleRevokeAccess(selectedResource.id, studentId)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                            >
                              <UserMinus className="w-4 h-4" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="flex gap-3 pt-4 border-t border-gray-200">
                  <button
                    onClick={() => {
                      setShowDetailsModal(false);
                      setShowShareModal(true);
                    }}
                    className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                  >
                    <Share2 className="w-4 h-4" />
                    Share
                  </button>
                  {selectedResource.url && (
                    <a
                      href={selectedResource.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-xl font-semibold transition flex items-center justify-center gap-2"
                    >
                      <ExternalLink className="w-4 h-4" />
                      Open Resource
                    </a>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}