import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Star, TrendingUp, Award, MessageSquare, Calendar, User } from "lucide-react";
import { format } from "date-fns";

export default function InstructorReviews() {
  const [instructor, setInstructor] = useState(null);

  useEffect(() => {
    const loadInstructor = async () => {
      const devUser = sessionStorage.getItem("dev_auth_user");
      const user = devUser ? JSON.parse(devUser) : await base44.auth.me();
      const instructors = await base44.entities.Instructor.filter({ email: user.email });
      if (instructors.length > 0) setInstructor(instructors[0]);
    };
    loadInstructor();
  }, []);

  const { data: reviews = [], isLoading } = useQuery({
    queryKey: ['instructorReviews', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      return await base44.entities.Review.filter({ instructor_id: instructor.id }, '-created_date');
    },
    enabled: !!instructor
  });

  const { data: students = [] } = useQuery({
    queryKey: ['students'],
    queryFn: () => base44.entities.Student.list()
  });

  const avgRating = reviews.length > 0 
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length 
    : 0;

  const ratingDistribution = [5, 4, 3, 2, 1].map(rating => ({
    rating,
    count: reviews.filter(r => r.rating === rating).length,
    percentage: reviews.length > 0 ? (reviews.filter(r => r.rating === rating).length / reviews.length) * 100 : 0
  }));

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">My Reviews</h1>
          <p className="text-slate-600 mt-1">See what students are saying about you</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-[#fdfbe8] rounded-xl flex items-center justify-center">
              <Star className="w-6 h-6 text-[#e7d356]" />
            </div>
            <div>
              <p className="text-sm text-slate-600">Average Rating</p>
              <p className="text-3xl font-bold text-slate-900">{avgRating.toFixed(1)}</p>
            </div>
          </div>
          <div className="flex gap-0.5">
            {[1,2,3,4,5].map(i => (
              <Star key={i} className={`w-4 h-4 ${i <= Math.round(avgRating) ? 'fill-[#e7d356] text-[#e7d356]' : 'text-slate-300'}`} />
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#e8f4fa] rounded-xl flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-[#3b82c4]" />
            </div>
            <div>
              <p className="text-sm text-slate-600">Total Reviews</p>
              <p className="text-3xl font-bold text-slate-900">{reviews.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#eefbe7] rounded-xl flex items-center justify-center">
              <Award className="w-6 h-6 text-[#5cb83a]" />
            </div>
            <div>
              <p className="text-sm text-slate-600">5-Star Reviews</p>
              <p className="text-3xl font-bold text-slate-900">
                {reviews.filter(r => r.rating === 5).length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#f3e8f4] rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-[#6c376f]" />
            </div>
            <div>
              <p className="text-sm text-slate-600">This Month</p>
              <p className="text-3xl font-bold text-slate-900">
                {reviews.filter(r => new Date(r.created_date) > new Date(Date.now() - 30*24*60*60*1000)).length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Rating Distribution */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <h3 className="font-bold text-slate-900 mb-4">Rating Distribution</h3>
        <div className="space-y-3">
          {ratingDistribution.map(({ rating, count, percentage }) => (
            <div key={rating} className="flex items-center gap-3">
              <div className="flex items-center gap-1 w-16">
                <span className="text-sm font-semibold text-slate-700">{rating}</span>
                <Star className="w-3 h-3 fill-[#e7d356] text-[#e7d356]" />
              </div>
              <div className="flex-1 h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-[#e7d356]" style={{ width: `${percentage}%` }} />
              </div>
              <span className="text-sm text-slate-600 w-12 text-right">{count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Reviews List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-[#3b82c4] mx-auto" />
          </div>
        ) : reviews.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center shadow-sm border border-slate-200">
            <Star className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 font-medium">No reviews yet</p>
            <p className="text-sm text-slate-500 mt-1">Complete lessons to receive student feedback</p>
          </div>
        ) : (
          reviews.map((review, idx) => {
            const student = students.find(s => s.id === review.student_id);
            return (
              <motion.div
                key={review.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-[#3b82c4] to-[#2563a3] rounded-full flex items-center justify-center text-white font-bold">
                      {student?.full_name?.charAt(0) || "S"}
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">{student?.full_name || "Student"}</p>
                      <p className="text-sm text-slate-500">{format(new Date(review.created_date), "MMM d, yyyy")}</p>
                    </div>
                  </div>
                  <div className="flex gap-0.5">
                    {[1,2,3,4,5].map(i => (
                      <Star key={i} className={`w-4 h-4 ${i <= review.rating ? 'fill-[#e7d356] text-[#e7d356]' : 'text-slate-300'}`} />
                    ))}
                  </div>
                </div>
                {review.comment && (
                  <p className="text-slate-700 leading-relaxed">{review.comment}</p>
                )}
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}