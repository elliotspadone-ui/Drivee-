import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Calendar,
  Plus,
  Trash2,
  ArrowLeft,
  CheckCircle,
  Clock,
  XCircle,
  AlertCircle,
  Loader2,
  X,
  FileText,
  Edit,
  Eye,
  Filter,
  Search,
  Download,
  RefreshCw,
  CalendarDays,
  CalendarRange,
  Sun,
  Briefcase,
  Heart,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Bell,
  Send,
  MessageSquare,
  Copy,
  MoreVertical,
  Info,
  TrendingUp,
  Award,
  Plane,
  Stethoscope,
  User,
  Coffee,
  GraduationCap,
  Baby,
  Home,
  Zap
} from "lucide-react";
import { 
  format, 
  differenceInDays, 
  differenceInBusinessDays,
  isAfter, 
  isBefore, 
  parseISO,
  addDays,
  startOfYear,
  endOfYear,
  eachDayOfInterval,
  isWeekend,
  isSameDay
} from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const REQUEST_TYPES = {
  vacation: { 
    label: "Vacation", 
    icon: Plane, 
    color: "blue",
    description: "Annual leave or holiday"
  },
  sick: { 
    label: "Sick Leave", 
    icon: Stethoscope, 
    color: "red",
    description: "Medical or health-related absence"
  },
  personal: { 
    label: "Personal Day", 
    icon: User, 
    color: "purple",
    description: "Personal matters or appointments"
  },
  family: { 
    label: "Family Emergency", 
    icon: Heart, 
    color: "pink",
    description: "Family-related urgent matters"
  },
  training: { 
    label: "Training/Development", 
    icon: GraduationCap, 
    color: "amber",
    description: "Professional development activities"
  },
  parental: { 
    label: "Parental Leave", 
    icon: Baby, 
    color: "green",
    description: "Maternity or paternity leave"
  },
  bereavement: { 
    label: "Bereavement", 
    icon: Home, 
    color: "gray",
    description: "Loss of a family member"
  },
  other: { 
    label: "Other", 
    icon: HelpCircle, 
    color: "slate",
    description: "Other time off reasons"
  }
};

const STATUS_CONFIG = {
  pending: { 
    label: "Pending", 
    color: "yellow", 
    icon: Clock,
    description: "Awaiting approval"
  },
  approved: { 
    label: "Approved", 
    color: "green", 
    icon: CheckCircle,
    description: "Request approved"
  },
  rejected: { 
    label: "Rejected", 
    color: "red", 
    icon: XCircle,
    description: "Request denied"
  },
  cancelled: { 
    label: "Cancelled", 
    color: "gray", 
    icon: X,
    description: "Request cancelled"
  }
};

export default function InstructorTimeOffRequests() {
  const queryClient = useQueryClient();
  
  const [user, setUser] = useState(null);
  const [instructor, setInstructor] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [yearFilter, setYearFilter] = useState(new Date().getFullYear().toString());
  const [sortBy, setSortBy] = useState("newest");
  const [expandedId, setExpandedId] = useState(null);

  const [formData, setFormData] = useState({
    startDate: "",
    endDate: "",
    reason: "",
    requestType: "vacation",
    halfDayStart: false,
    halfDayEnd: false,
    emergencyContact: "",
    coverageArranged: false,
    notes: ""
  });

  useEffect(() => {
    const loadUser = async () => {
      try {
        setIsLoading(true);
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        const instructors = await base44.entities.Instructor.filter({ email: currentUser.email });
        if (instructors.length > 0) {
          setInstructor(instructors[0]);
        }
      } catch (error) {
        console.error("Error loading user:", error);
        toast.error("Failed to load user data");
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: timeOffRequests = [], isLoading: loadingRequests, refetch } = useQuery({
    queryKey: ['instructorTimeOff', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      try {
        return await base44.entities.TimeOffRequest.filter(
          { instructor_id: instructor.id },
          '-created_date'
        );
      } catch {
        return [];
      }
    },
    enabled: !!instructor,
  });

  const { data: leaveBalance = null } = useQuery({
    queryKey: ['leaveBalance', instructor?.id],
    queryFn: async () => {
      if (!instructor) return null;
      try {
        const balances = await base44.entities.LeaveBalance.filter({ instructor_id: instructor.id });
        return balances[0] || {
          annual_leave: 25,
          sick_leave: 10,
          personal_days: 5,
          used_annual: 0,
          used_sick: 0,
          used_personal: 0
        };
      } catch {
        return {
          annual_leave: 25,
          sick_leave: 10,
          personal_days: 5,
          used_annual: 0,
          used_sick: 0,
          used_personal: 0
        };
      }
    },
    enabled: !!instructor,
  });

  const { data: upcomingBookings = [] } = useQuery({
    queryKey: ['affectedBookings', formData.startDate, formData.endDate],
    queryFn: async () => {
      if (!instructor || !formData.startDate || !formData.endDate) return [];
      try {
        const bookings = await base44.entities.Booking.filter({ instructor_id: instructor.id });
        return bookings.filter(b => {
          const bookingDate = new Date(b.start_datetime);
          const start = new Date(formData.startDate);
          const end = new Date(formData.endDate);
          return (b.status === "confirmed" || b.status === "pending") &&
                 isAfter(bookingDate, start) && isBefore(bookingDate, end);
        });
      } catch {
        return [];
      }
    },
    enabled: !!instructor && !!formData.startDate && !!formData.endDate,
  });

  const createRequestMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.TimeOffRequest.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorTimeOff'] });
      toast.success("Time off request submitted successfully");
      resetForm();
      setShowModal(false);
    },
    onError: () => {
      toast.error("Failed to submit request");
    }
  });

  const updateRequestMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.TimeOffRequest.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorTimeOff'] });
      toast.success("Request updated successfully");
      resetForm();
      setShowModal(false);
      setEditMode(false);
    },
    onError: () => {
      toast.error("Failed to update request");
    }
  });

  const deleteRequestMutation = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.TimeOffRequest.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorTimeOff'] });
      toast.success("Request deleted");
    },
    onError: () => {
      toast.error("Failed to delete request");
    }
  });

  const cancelRequestMutation = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.TimeOffRequest.update(id, { status: "cancelled" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorTimeOff'] });
      toast.info("Request cancelled");
    },
    onError: () => {
      toast.error("Failed to cancel request");
    }
  });

  const resetForm = () => {
    setFormData({
      startDate: "",
      endDate: "",
      reason: "",
      requestType: "vacation",
      halfDayStart: false,
      halfDayEnd: false,
      emergencyContact: "",
      coverageArranged: false,
      notes: ""
    });
    setSelectedRequest(null);
    setEditMode(false);
  };

  const handleSubmit = () => {
    if (!formData.startDate || !formData.endDate) {
      toast.error("Please select start and end dates");
      return;
    }

    if (!formData.reason.trim()) {
      toast.error("Please provide a reason for your request");
      return;
    }

    if (new Date(formData.endDate) < new Date(formData.startDate)) {
      toast.error("End date must be after start date");
      return;
    }

    const requestData = {
      instructor_id: instructor.id,
      school_id: instructor.school_id,
      start_date: formData.startDate,
      end_date: formData.endDate,
      reason: formData.reason,
      request_type: formData.requestType,
      half_day_start: formData.halfDayStart,
      half_day_end: formData.halfDayEnd,
      emergency_contact: formData.emergencyContact,
      coverage_arranged: formData.coverageArranged,
      notes: formData.notes,
      status: "pending",
      created_date: new Date().toISOString(),
      affected_bookings_count: upcomingBookings.length
    };

    if (editMode && selectedRequest) {
      updateRequestMutation.mutate({ id: selectedRequest.id, data: requestData });
    } else {
      createRequestMutation.mutate(requestData);
    }
  };

  const handleEdit = (request) => {
    setSelectedRequest(request);
    setFormData({
      startDate: request.start_date,
      endDate: request.end_date,
      reason: request.reason || "",
      requestType: request.request_type || "vacation",
      halfDayStart: request.half_day_start || false,
      halfDayEnd: request.half_day_end || false,
      emergencyContact: request.emergency_contact || "",
      coverageArranged: request.coverage_arranged || false,
      notes: request.notes || ""
    });
    setEditMode(true);
    setShowModal(true);
  };

  const handleViewDetails = (request) => {
    setSelectedRequest(request);
    setShowDetailsModal(true);
  };

  const calculateDays = useCallback((startDate, endDate, halfDayStart, halfDayEnd) => {
    if (!startDate || !endDate) return 0;
    
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    let businessDays = 0;
    const days = eachDayOfInterval({ start, end });
    
    days.forEach(day => {
      if (!isWeekend(day)) {
        businessDays++;
      }
    });

    if (halfDayStart) businessDays -= 0.5;
    if (halfDayEnd) businessDays -= 0.5;

    return Math.max(0, businessDays);
  }, []);

  const filteredRequests = useMemo(() => {
    let filtered = [...timeOffRequests];

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(r =>
        r.reason?.toLowerCase().includes(term) ||
        r.request_type?.toLowerCase().includes(term) ||
        r.admin_notes?.toLowerCase().includes(term)
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(r => r.status === statusFilter);
    }

    if (typeFilter !== "all") {
      filtered = filtered.filter(r => r.request_type === typeFilter);
    }

    if (yearFilter !== "all") {
      const year = parseInt(yearFilter);
      filtered = filtered.filter(r => {
        const startYear = new Date(r.start_date).getFullYear();
        return startYear === year;
      });
    }

    filtered.sort((a, b) => {
      if (sortBy === "newest") {
        return new Date(b.created_date || b.start_date) - new Date(a.created_date || a.start_date);
      }
      if (sortBy === "oldest") {
        return new Date(a.created_date || a.start_date) - new Date(b.created_date || b.start_date);
      }
      if (sortBy === "start_date") {
        return new Date(a.start_date) - new Date(b.start_date);
      }
      return 0;
    });

    return filtered;
  }, [timeOffRequests, searchTerm, statusFilter, typeFilter, yearFilter, sortBy]);

  const stats = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const yearRequests = timeOffRequests.filter(r => 
      new Date(r.start_date).getFullYear() === currentYear
    );

    const approved = yearRequests.filter(r => r.status === "approved");
    const pending = yearRequests.filter(r => r.status === "pending");
    
    const totalApprovedDays = approved.reduce((sum, r) => {
      return sum + calculateDays(r.start_date, r.end_date, r.half_day_start, r.half_day_end);
    }, 0);

    const totalPendingDays = pending.reduce((sum, r) => {
      return sum + calculateDays(r.start_date, r.end_date, r.half_day_start, r.half_day_end);
    }, 0);

    return {
      totalRequests: yearRequests.length,
      approved: approved.length,
      pending: pending.length,
      rejected: yearRequests.filter(r => r.status === "rejected").length,
      totalApprovedDays,
      totalPendingDays,
      remainingAnnual: leaveBalance ? leaveBalance.annual_leave - leaveBalance.used_annual : 0,
      remainingSick: leaveBalance ? leaveBalance.sick_leave - leaveBalance.used_sick : 0,
      remainingPersonal: leaveBalance ? leaveBalance.personal_days - leaveBalance.used_personal : 0
    };
  }, [timeOffRequests, leaveBalance, calculateDays]);

  const requestedDays = useMemo(() => {
    return calculateDays(
      formData.startDate, 
      formData.endDate, 
      formData.halfDayStart, 
      formData.halfDayEnd
    );
  }, [formData.startDate, formData.endDate, formData.halfDayStart, formData.halfDayEnd, calculateDays]);

  const availableYears = useMemo(() => {
    const years = new Set();
    timeOffRequests.forEach(r => {
      years.add(new Date(r.start_date).getFullYear());
    });
    years.add(new Date().getFullYear());
    return Array.from(years).sort((a, b) => b - a);
  }, [timeOffRequests]);

  if (isLoading || loadingRequests) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading time off requests...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Link
          to={createPageUrl("InstructorSchedule")}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Schedule
        </Link>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Time Off Requests</h1>
            <p className="text-gray-600 mt-1">Manage your vacation, sick leave, and time off</p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => refetch()}
              className="p-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              <RefreshCw className="w-5 h-5 text-gray-600" />
            </button>
            <button
              onClick={() => {
                resetForm();
                setShowModal(true);
              }}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl font-semibold hover:shadow-lg transition"
            >
              <Plus className="w-5 h-5" />
              New Request
            </button>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {[
          { label: "Total Requests", value: stats.totalRequests, icon: Calendar, color: "indigo" },
          { label: "Approved", value: stats.approved, icon: CheckCircle, color: "green" },
          { label: "Pending", value: stats.pending, icon: Clock, color: "amber" },
          { label: "Days Used", value: stats.totalApprovedDays, icon: CalendarDays, color: "blue" },
          { label: "Annual Left", value: stats.remainingAnnual, icon: Sun, color: "purple" },
          { label: "Sick Left", value: stats.remainingSick, icon: Stethoscope, color: "red" }
        ].map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm"
          >
            <div className={`w-10 h-10 bg-${stat.color}-100 rounded-lg flex items-center justify-center mb-2`}>
              <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-xs text-gray-600">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {leaveBalance && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-2xl p-6"
        >
          <h3 className="text-lg font-bold text-gray-900 mb-4">Leave Balance</h3>
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { 
                label: "Annual Leave", 
                total: leaveBalance.annual_leave, 
                used: leaveBalance.used_annual,
                color: "blue",
                icon: Plane
              },
              { 
                label: "Sick Leave", 
                total: leaveBalance.sick_leave, 
                used: leaveBalance.used_sick,
                color: "red",
                icon: Stethoscope
              },
              { 
                label: "Personal Days", 
                total: leaveBalance.personal_days, 
                used: leaveBalance.used_personal,
                color: "purple",
                icon: User
              }
            ].map((balance) => {
              const remaining = balance.total - balance.used;
              const percentage = (balance.used / balance.total) * 100;
              
              return (
                <div key={balance.label} className="bg-white rounded-xl p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <balance.icon className={`w-5 h-5 text-${balance.color}-600`} />
                    <span className="font-semibold text-gray-900">{balance.label}</span>
                  </div>
                  <div className="mb-2">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">{balance.used} used</span>
                      <span className="font-semibold">{remaining} remaining</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className={`h-full bg-${balance.color}-500 rounded-full transition-all`}
                        style={{ width: `${Math.min(100, percentage)}%` }}
                      />
                    </div>
                  </div>
                  <p className="text-xs text-gray-500">of {balance.total} days total</p>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm space-y-4"
      >
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search requests..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          <div className="flex gap-2 flex-wrap">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Status</option>
              {Object.entries(STATUS_CONFIG).map(([key, { label }]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>

            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Types</option>
              {Object.entries(REQUEST_TYPES).map(([key, { label }]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>

            <select
              value={yearFilter}
              onChange={(e) => setYearFilter(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="all">All Years</option>
              {availableYears.map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="start_date">By Start Date</option>
            </select>
          </div>
        </div>

        <div className="text-sm text-gray-600">
          Showing {filteredRequests.length} request{filteredRequests.length !== 1 ? 's' : ''}
        </div>
      </motion.div>

      <div className="space-y-4">
        {filteredRequests.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
            <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-900 mb-2">No time off requests</h3>
            <p className="text-gray-600 mb-6">
              {searchTerm || statusFilter !== "all" || typeFilter !== "all"
                ? "Try adjusting your filters"
                : "You haven't submitted any time off requests yet"
              }
            </p>
            <button
              onClick={() => {
                resetForm();
                setShowModal(true);
              }}
              className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition inline-flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Create Your First Request
            </button>
          </div>
        ) : (
          filteredRequests.map((request, index) => {
            const typeConfig = REQUEST_TYPES[request.request_type] || REQUEST_TYPES.other;
            const statusConfig = STATUS_CONFIG[request.status] || STATUS_CONFIG.pending;
            const dayCount = calculateDays(
              request.start_date, 
              request.end_date, 
              request.half_day_start, 
              request.half_day_end
            );
            const isExpanded = expandedId === request.id;
            const isPast = isBefore(new Date(request.end_date), new Date());

            return (
              <motion.div
                key={request.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className={`bg-white rounded-2xl border-2 shadow-sm overflow-hidden ${
                  request.status === "approved" ? "border-green-200" :
                  request.status === "rejected" ? "border-red-200" :
                  request.status === "pending" ? "border-amber-200" :
                  "border-gray-200"
                } ${isPast ? "opacity-75" : ""}`}
              >
                <div 
                  className="p-4 cursor-pointer hover:bg-gray-50 transition"
                  onClick={() => setExpandedId(isExpanded ? null : request.id)}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 bg-${typeConfig.color}-100 rounded-xl flex items-center justify-center flex-shrink-0`}>
                      <typeConfig.icon className={`w-6 h-6 text-${typeConfig.color}-600`} />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <h3 className="text-lg font-bold text-gray-900">
                          {format(new Date(request.start_date), "MMM d")}
                          {request.start_date !== request.end_date && (
                            <> - {format(new Date(request.end_date), "MMM d, yyyy")}</>
                          )}
                          {request.start_date === request.end_date && (
                            <>, {format(new Date(request.start_date), "yyyy")}</>
                          )}
                        </h3>
                        <span className={`px-2 py-0.5 bg-${statusConfig.color}-100 text-${statusConfig.color}-700 rounded-full text-xs font-bold flex items-center gap-1`}>
                          <statusConfig.icon className="w-3 h-3" />
                          {statusConfig.label}
                        </span>
                        {isPast && (
                          <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full text-xs font-bold">
                            Past
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-sm text-gray-600">
                        <span>{typeConfig.label}</span>
                        <span>•</span>
                        <span>{dayCount} day{dayCount !== 1 ? 's' : ''}</span>
                        {(request.half_day_start || request.half_day_end) && (
                          <>
                            <span>•</span>
                            <span className="text-amber-600">Half day{request.half_day_start && request.half_day_end ? 's' : ''}</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {request.status === "pending" && !isPast && (
                        <>
                          <button
                            onClick={(e) => { e.stopPropagation(); handleEdit(request); }}
                            className="p-2 hover:bg-gray-100 rounded-lg transition"
                            title="Edit"
                          >
                            <Edit className="w-4 h-4 text-gray-600" />
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); cancelRequestMutation.mutate(request.id); }}
                            className="p-2 hover:bg-red-50 rounded-lg transition"
                            title="Cancel"
                          >
                            <X className="w-4 h-4 text-red-600" />
                          </button>
                        </>
                      )}
                      <button
                        onClick={(e) => { e.stopPropagation(); handleViewDetails(request); }}
                        className="p-2 hover:bg-gray-100 rounded-lg transition"
                        title="View Details"
                      >
                        <Eye className="w-4 h-4 text-gray-600" />
                      </button>
                      {isExpanded ? (
                        <ChevronUp className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                  </div>
                </div>

                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 pt-0 border-t border-gray-200 space-y-3">
                        {request.reason && (
                          <div className="mt-4 p-3 bg-gray-50 rounded-xl">
                            <p className="text-xs font-bold text-gray-700 mb-1">Reason</p>
                            <p className="text-sm text-gray-600">{request.reason}</p>
                          </div>
                        )}

                        {request.admin_notes && (
                          <div className={`p-3 bg-${statusConfig.color}-50 border border-${statusConfig.color}-200 rounded-xl`}>
                            <p className="text-xs font-bold text-gray-700 mb-1">Admin Response</p>
                            <p className="text-sm text-gray-600">{request.admin_notes}</p>
                          </div>
                        )}

                        {request.affected_bookings_count > 0 && (
                          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl">
                            <div className="flex items-center gap-2">
                              <AlertCircle className="w-4 h-4 text-amber-600" />
                              <p className="text-sm text-amber-800">
                                {request.affected_bookings_count} lesson{request.affected_bookings_count !== 1 ? 's' : ''} affected
                              </p>
                            </div>
                          </div>
                        )}

                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <Clock className="w-3 h-3" />
                          <span>
                            Submitted {request.created_date ? format(new Date(request.created_date), "MMM d, yyyy 'at' h:mm a") : "N/A"}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })
        )}
      </div>

      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => { setShowModal(false); resetForm(); }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">
                  {editMode ? "Edit Time Off Request" : "Request Time Off"}
                </h3>
                <button
                  onClick={() => { setShowModal(false); resetForm(); }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Request Type</label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {Object.entries(REQUEST_TYPES).map(([key, config]) => (
                      <button
                        key={key}
                        onClick={() => setFormData(prev => ({ ...prev, requestType: key }))}
                        className={`p-3 rounded-xl border-2 transition flex flex-col items-center gap-1 ${
                          formData.requestType === key
                            ? `border-${config.color}-500 bg-${config.color}-50`
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <config.icon className={`w-5 h-5 text-${config.color}-600`} />
                        <span className="text-xs font-semibold">{config.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
                    <input
                      type="date"
                      value={formData.startDate}
                      onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                      min={format(new Date(), "yyyy-MM-dd")}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                    <label className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                      <input
                        type="checkbox"
                        checked={formData.halfDayStart}
                        onChange={(e) => setFormData(prev => ({ ...prev, halfDayStart: e.target.checked }))}
                        className="w-4 h-4 rounded border-gray-300 text-indigo-600"
                      />
                      Half day (afternoon only)
                    </label>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
                    <input
                      type="date"
                      value={formData.endDate}
                      onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                      min={formData.startDate || format(new Date(), "yyyy-MM-dd")}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                    <label className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                      <input
                        type="checkbox"
                        checked={formData.halfDayEnd}
                        onChange={(e) => setFormData(prev => ({ ...prev, halfDayEnd: e.target.checked }))}
                        className="w-4 h-4 rounded border-gray-300 text-indigo-600"
                      />
                      Half day (morning only)
                    </label>
                  </div>
                </div>

                {formData.startDate && formData.endDate && (
                  <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-indigo-900">Total Days Requested</span>
                      <span className="text-2xl font-bold text-indigo-600">{requestedDays}</span>
                    </div>
                    <p className="text-xs text-indigo-700 mt-1">
                      Working days only (excludes weekends)
                    </p>
                  </div>
                )}

                {upcomingBookings.length > 0 && (
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-amber-900">
                          {upcomingBookings.length} lesson{upcomingBookings.length !== 1 ? 's' : ''} will be affected
                        </p>
                        <p className="text-sm text-amber-700 mt-1">
                          These lessons will need to be rescheduled or reassigned if your request is approved.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Reason</label>
                  <textarea
                    value={formData.reason}
                    onChange={(e) => setFormData(prev => ({ ...prev, reason: e.target.value }))}
                    placeholder="Please provide a reason for your time off request..."
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Emergency Contact (optional)</label>
                  <input
                    type="text"
                    value={formData.emergencyContact}
                    onChange={(e) => setFormData(prev => ({ ...prev, emergencyContact: e.target.value }))}
                    placeholder="Name and phone number"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Additional Notes (optional)</label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                    placeholder="Any additional information..."
                    rows={2}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                  />
                </div>

                <label className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.coverageArranged}
                    onChange={(e) => setFormData(prev => ({ ...prev, coverageArranged: e.target.checked }))}
                    className="w-5 h-5 rounded border-gray-300 text-indigo-600"
                  />
                  <div>
                    <p className="font-semibold text-gray-900">Coverage Arranged</p>
                    <p className="text-sm text-gray-600">I have arranged for another instructor to cover my lessons</p>
                  </div>
                </label>

                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm text-blue-900 font-semibold">Approval Required</p>
                      <p className="text-xs text-blue-800 mt-1">
                        Time off requests require admin approval. You'll receive a notification once your request has been reviewed.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => { setShowModal(false); resetForm(); }}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={
                    createRequestMutation.isPending || 
                    updateRequestMutation.isPending ||
                    !formData.startDate || 
                    !formData.endDate || 
                    !formData.reason.trim()
                  }
                  className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {(createRequestMutation.isPending || updateRequestMutation.isPending) ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      {editMode ? "Update Request" : "Submit Request"}
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showDetailsModal && selectedRequest && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => { setShowDetailsModal(false); setSelectedRequest(null); }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Request Details</h3>
                <button
                  onClick={() => { setShowDetailsModal(false); setSelectedRequest(null); }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              {(() => {
                const typeConfig = REQUEST_TYPES[selectedRequest.request_type] || REQUEST_TYPES.other;
                const statusConfig = STATUS_CONFIG[selectedRequest.status] || STATUS_CONFIG.pending;
                const dayCount = calculateDays(
                  selectedRequest.start_date,
                  selectedRequest.end_date,
                  selectedRequest.half_day_start,
                  selectedRequest.half_day_end
                );

                return (
                  <div className="space-y-4">
                    <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                      <div className={`w-14 h-14 bg-${typeConfig.color}-100 rounded-xl flex items-center justify-center`}>
                        <typeConfig.icon className={`w-7 h-7 text-${typeConfig.color}-600`} />
                      </div>
                      <div>
                        <p className="text-lg font-bold text-gray-900">{typeConfig.label}</p>
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 bg-${statusConfig.color}-100 text-${statusConfig.color}-700 rounded-full text-xs font-bold`}>
                          <statusConfig.icon className="w-3 h-3" />
                          {statusConfig.label}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-xs text-gray-500 mb-1">Start Date</p>
                        <p className="font-bold text-gray-900">
                          {format(new Date(selectedRequest.start_date), "MMMM d, yyyy")}
                        </p>
                        {selectedRequest.half_day_start && (
                          <p className="text-xs text-amber-600 mt-1">Half day (PM)</p>
                        )}
                      </div>
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-xs text-gray-500 mb-1">End Date</p>
                        <p className="font-bold text-gray-900">
                          {format(new Date(selectedRequest.end_date), "MMMM d, yyyy")}
                        </p>
                        {selectedRequest.half_day_end && (
                          <p className="text-xs text-amber-600 mt-1">Half day (AM)</p>
                        )}
                      </div>
                    </div>

                    <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl text-center">
                      <p className="text-sm text-indigo-900">Total Duration</p>
                      <p className="text-3xl font-bold text-indigo-600">{dayCount} day{dayCount !== 1 ? 's' : ''}</p>
                    </div>

                    {selectedRequest.reason && (
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-xs font-bold text-gray-700 mb-1">Reason</p>
                        <p className="text-sm text-gray-600">{selectedRequest.reason}</p>
                      </div>
                    )}

                    {selectedRequest.emergency_contact && (
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-xs font-bold text-gray-700 mb-1">Emergency Contact</p>
                        <p className="text-sm text-gray-600">{selectedRequest.emergency_contact}</p>
                      </div>
                    )}

                    {selectedRequest.notes && (
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-xs font-bold text-gray-700 mb-1">Additional Notes</p>
                        <p className="text-sm text-gray-600">{selectedRequest.notes}</p>
                      </div>
                    )}

                    {selectedRequest.admin_notes && (
                      <div className={`p-4 bg-${statusConfig.color}-50 border border-${statusConfig.color}-200 rounded-xl`}>
                        <p className="text-xs font-bold text-gray-700 mb-1">Admin Response</p>
                        <p className="text-sm text-gray-600">{selectedRequest.admin_notes}</p>
                      </div>
                    )}

                    {selectedRequest.coverage_arranged && (
                      <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-xl">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <span className="text-sm text-green-800">Coverage has been arranged</span>
                      </div>
                    )}

                    <div className="text-xs text-gray-500">
                      Submitted: {selectedRequest.created_date 
                        ? format(new Date(selectedRequest.created_date), "MMMM d, yyyy 'at' h:mm a")
                        : "N/A"
                      }
                    </div>

                    {selectedRequest.status === "pending" && (
                      <div className="flex gap-3 pt-4 border-t border-gray-200">
                        <button
                          onClick={() => {
                            setShowDetailsModal(false);
                            handleEdit(selectedRequest);
                          }}
                          className="flex-1 px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-xl font-semibold transition flex items-center justify-center gap-2"
                        >
                          <Edit className="w-4 h-4" />
                          Edit
                        </button>
                        <button
                          onClick={() => {
                            cancelRequestMutation.mutate(selectedRequest.id);
                            setShowDetailsModal(false);
                            setSelectedRequest(null);
                          }}
                          className="flex-1 px-4 py-3 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl font-semibold transition flex items-center justify-center gap-2"
                        >
                          <X className="w-4 h-4" />
                          Cancel Request
                        </button>
                      </div>
                    )}
                  </div>
                );
              })()}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}