import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Calendar, 
  Clock, 
  Car, 
  MapPin, 
  User, 
  CheckCircle, 
  XCircle, 
  FileText, 
  Target, 
  AlertCircle,
  Star,
  MessageSquare,
  Download,
  Filter,
  Search,
  ChevronDown,
  ChevronUp,
  MoreVertical,
  Edit,
  Trash2,
  RefreshCw,
  PlayCircle,
  StopCircle,
  Phone,
  Mail,
  Navigation,
  TrendingUp,
  Award,
  BookOpen,
  Video,
  DollarSign,
  CreditCard,
  Package,
  Share2,
  Printer,
  ArrowLeft,
  SlidersHorizontal,
  X,
  Check,
  Loader2,
  MapPinned,
  Timer,
  ThumbsUp,
  ThumbsDown,
  Info
} from "lucide-react";
import { format, formatDistanceToNow, isBefore, isAfter, startOfDay, endOfDay, addDays, parseISO, differenceInMinutes } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";
import LessonDetailsDrawer from "@/components/student/LessonDetailsDrawer";
import VeeMascot from "@/components/common/VeeMascot";
import { useStudentAuth } from "@/components/student/useStudentAuth";
import StudentOnboarding from "@/components/student/StudentOnboarding";
import { logger } from "@/components/utils/config";
import { BOOKING_STATUS } from "@/components/utils/constants";
import QueryErrorBoundary from "@/components/common/QueryErrorBoundary";
import SkeletonLoader from "@/components/common/SkeletonLoader";

export default function MyLessons() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();
  
  const auth = useStudentAuth();
  const effectiveUser = auth.data?.effectiveUser || null;
  const effectiveStudent = auth.data?.effectiveStudent || null;
  const authStatus = auth.data?.status || "loading";
  const [filter, setFilter] = useState(searchParams.get("status") || "all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedLesson, setSelectedLesson] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState("date-desc");
  const [dateRange, setDateRange] = useState("all");
  const [selectedLessonType, setSelectedLessonType] = useState("all");
  const [expandedLesson, setExpandedLesson] = useState(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [lessonToCancel, setLessonToCancel] = useState(null);
  const [cancelReason, setCancelReason] = useState("");
  const [showRescheduleModal, setShowRescheduleModal] = useState(false);
  const [lessonToReschedule, setLessonToReschedule] = useState(null);

  useEffect(() => {
    const params = {};
    if (filter !== "all") params.status = filter;
    if (sortBy !== "date-desc") params.sort = sortBy;
    if (dateRange !== "all") params.range = dateRange;
    setSearchParams(params);
  }, [filter, sortBy, dateRange, setSearchParams]);

  const { data: bookings = [], isLoading: loadingBookings, error: bookingsError, refetch: refetchBookings } = useQuery({
    queryKey: ['myBookings', effectiveStudent?.id, effectiveStudent?.school_id],
    queryFn: async () => {
      if (!effectiveStudent) return [];
      return await base44.entities.Booking.filter({ 
        student_id: effectiveStudent.id,
        school_id: effectiveStudent.school_id 
      }, '-start_datetime', 200);
    },
    enabled: !!effectiveStudent,
    staleTime: 60000,
  });

  const { data: instructors = [] } = useQuery({
    queryKey: ['instructors', effectiveStudent?.school_id],
    queryFn: () => effectiveStudent?.school_id ? base44.entities.Instructor.filter({ school_id: effectiveStudent.school_id, is_active: true }, "-rating", 50) : [],
    enabled: !!effectiveStudent?.school_id,
    staleTime: 300000,
  });

  const { data: vehicles = [] } = useQuery({
    queryKey: ['vehicles', effectiveStudent?.school_id],
    queryFn: () => effectiveStudent?.school_id ? base44.entities.Vehicle.filter({ school_id: effectiveStudent.school_id }, "-created_date", 50) : [],
    enabled: !!effectiveStudent?.school_id,
    staleTime: 300000,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['reviews', effectiveStudent?.id, effectiveStudent?.school_id],
    queryFn: async () => {
      if (!effectiveStudent) return [];
      return await base44.entities.Review.filter({ 
        student_id: effectiveStudent.id,
        school_id: effectiveStudent.school_id 
      }, "-created_date", 50);
    },
    enabled: !!effectiveStudent,
    staleTime: 300000,
  });

  const cancelBookingMutation = useMutation({
    mutationFn: async ({ bookingId, reason }) => {
      return await base44.entities.Booking.update(bookingId, {
        status: "cancelled",
        cancellation_reason: reason,
        cancelled_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myBookings'] });
      queryClient.invalidateQueries({ queryKey: ['upcomingBookings'] });
      toast.success("Lesson cancelled successfully");
      setShowCancelModal(false);
      setLessonToCancel(null);
      setCancelReason("");
    },
    onError: (error) => {
      logger.error("Cancellation error:", error);
      toast.error("Failed to cancel lesson");
    }
  });

  const filteredAndSortedBookings = useMemo(() => {
    let filtered = bookings;

    if (filter !== "all") {
      filtered = filtered.filter(b => b.status === filter);
    }

    if (searchTerm) {
      filtered = filtered.filter(b => {
        const instructor = instructors.find(i => i.id === b.instructor_id);
        const vehicle = vehicles.find(v => v.id === b.vehicle_id);
        const searchLower = searchTerm.toLowerCase();
        
        return (
          instructor?.full_name?.toLowerCase().includes(searchLower) ||
          vehicle?.make?.toLowerCase().includes(searchLower) ||
          vehicle?.model?.toLowerCase().includes(searchLower) ||
          b.pickup_location?.toLowerCase().includes(searchLower) ||
          b.lesson_type?.toLowerCase().includes(searchLower)
        );
      });
    }

    if (dateRange !== "all") {
      const now = new Date();
      filtered = filtered.filter(b => {
        const bookingDate = new Date(b.start_datetime);
        
        if (dateRange === "upcoming") {
          return isAfter(bookingDate, now);
        } else if (dateRange === "past") {
          return isBefore(bookingDate, now);
        } else if (dateRange === "week") {
          return isAfter(bookingDate, now) && isBefore(bookingDate, addDays(now, 7));
        } else if (dateRange === "month") {
          return isAfter(bookingDate, now) && isBefore(bookingDate, addDays(now, 30));
        }
        return true;
      });
    }

    if (selectedLessonType !== "all") {
      filtered = filtered.filter(b => b.lesson_type === selectedLessonType);
    }

    filtered.sort((a, b) => {
      const dateA = new Date(a.start_datetime);
      const dateB = new Date(b.start_datetime);

      if (sortBy === "date-desc") return dateB.getTime() - dateA.getTime();
      if (sortBy === "date-asc") return dateA.getTime() - dateB.getTime();
      if (sortBy === "status") return a.status.localeCompare(b.status);
      if (sortBy === "instructor") {
        const instrA = instructors.find(i => i.id === a.instructor_id)?.full_name || "";
        const instrB = instructors.find(i => i.id === b.instructor_id)?.full_name || "";
        return instrA.localeCompare(instrB);
      }
      return 0;
    });

    return filtered;
  }, [bookings, filter, searchTerm, dateRange, selectedLessonType, sortBy, instructors, vehicles]);

  const stats = useMemo(() => {
    const total = bookings.length;
    const completed = bookings.filter(b => b.status === "completed").length;
    const upcoming = bookings.filter(b => b.status === "confirmed" && isAfter(new Date(b.start_datetime), new Date())).length;
    const cancelled = bookings.filter(b => b.status === "cancelled").length;
    const totalHours = bookings
      .filter(b => b.status === "completed")
      .reduce((sum, b) => {
        const duration = differenceInMinutes(new Date(b.end_datetime), new Date(b.start_datetime));
        return sum + (duration / 60);
      }, 0);

    return { total, completed, upcoming, cancelled, totalHours };
  }, [bookings]);

  const getInstructor = (id) => instructors.find(i => i.id === id);
  const getVehicle = (id) => vehicles.find(v => v.id === id);
  const getReview = (bookingId) => reviews.find(r => r.booking_id === bookingId);

  const statusConfig = {
    confirmed: {
      label: "Confirmed",
      color: "blue",
      bgColor: "from-[#3b82c4] to-[#a9d5ed]",
      lightBg: "bg-[#e8f4fa]",
      textColor: "text-[#2563a3]",
      borderColor: "border-[#d4eaf5]",
      icon: CheckCircle
    },
    completed: {
      label: "Completed",
      color: "green",
      bgColor: "from-[#81da5a] to-[#5cb83a]",
      lightBg: "bg-[#eefbe7]",
      textColor: "text-[#4a9c2e]",
      borderColor: "border-[#d4f4c3]",
      icon: CheckCircle
    },
    cancelled: {
      label: "Cancelled",
      color: "red",
      bgColor: "from-[#e44138] to-[#c9342c]",
      lightBg: "bg-[#fdeeed]",
      textColor: "text-[#c9342c]",
      borderColor: "border-[#f9d4d2]",
      icon: XCircle
    },
    in_progress: {
      label: "In Progress",
      color: "purple",
      bgColor: "from-[#6c376f] to-[#5a2d5d]",
      lightBg: "bg-[#f3e8f4]",
      textColor: "text-[#5a2d5d]",
      borderColor: "border-[#e5d0e6]",
      icon: PlayCircle
    },
    pending: {
      label: "Pending",
      color: "yellow",
      bgColor: "from-[#e7d356] to-[#d4bf2e]",
      lightBg: "bg-[#fdfbe8]",
      textColor: "text-[#9a8520]",
      borderColor: "border-[#f9f3c8]",
      icon: Clock
    }
  };

  const handleCancelLesson = (lesson) => {
    const lessonDate = new Date(lesson.start_datetime);
    const now = new Date();
    const hoursUntilLesson = (lessonDate.getTime() - now.getTime()) / (1000 * 60 * 60);

    if (hoursUntilLesson < 24) {
      toast.error("Cannot cancel lessons with less than 24 hours notice");
      return;
    }

    setLessonToCancel(lesson);
    setShowCancelModal(true);
  };

  const confirmCancel = () => {
    if (!lessonToCancel) return;
    if (!cancelReason.trim()) {
      toast.error("Please provide a cancellation reason");
      return;
    }

    cancelBookingMutation.mutate({
      bookingId: lessonToCancel.id,
      reason: cancelReason
    });
  };

  const handleReschedule = (lesson) => {
    navigate(createPageUrl("BookLesson"), {
      state: { rescheduleBooking: lesson }
    });
  };

  const canCancelLesson = (lesson) => {
    if (lesson.status !== "confirmed") return false;
    const lessonDate = new Date(lesson.start_datetime);
    const now = new Date();
    const hoursUntilLesson = (lessonDate.getTime() - now.getTime()) / (1000 * 60 * 60);
    return hoursUntilLesson >= 24;
  };

  const canRescheduleLesson = (lesson) => {
    if (lesson.status !== "confirmed") return false;
    const lessonDate = new Date(lesson.start_datetime);
    const now = new Date();
    const hoursUntilLesson = (lessonDate.getTime() - now.getTime()) / (1000 * 60 * 60);
    return hoursUntilLesson >= 48;
  };

  if (auth.isLoading || loadingBookings) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-6">
        <SkeletonLoader count={5} type="card" />
      </div>
    );
  }

  if (authStatus === "unauthenticated" || !effectiveUser) {
    window.location.href = createPageUrl("StudentAuth");
    return null;
  }

  if (authStatus === "no_student" || !effectiveStudent) {
    return <StudentOnboarding user={effectiveUser} onComplete={() => window.location.reload()} />;
  }

  if (bookingsError) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <QueryErrorBoundary 
          error={bookingsError} 
          onRetry={refetchBookings}
          title="Failed to load your lessons"
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <button
          onClick={() => navigate(createPageUrl("StudentDashboard"))}
          className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </button>

        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-[#81da5a] to-[#5cb83a] bg-clip-text text-transparent mb-1">My Lessons</h1>
            <p className="text-gray-600">Track and manage all your driving lessons</p>
          </div>

          <Link
            to={createPageUrl("BookLesson")}
            className="hidden md:flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#3b82c4] to-[#2563a3] text-white rounded-xl font-semibold hover:shadow-lg transition"
          >
            <Calendar className="w-5 h-5" />
            Book New Lesson
          </Link>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6"
      >
        {[
          { label: "Total Lessons", value: stats.total, icon: BookOpen, color: "primary" },
          { label: "Completed", value: stats.completed, icon: CheckCircle, color: "green" },
          { label: "Upcoming", value: stats.upcoming, icon: Calendar, color: "blue" },
          { label: "Hours Logged", value: stats.totalHours.toFixed(1), icon: Clock, color: "accent" }
        ].map((stat, idx) => {
          const colorClasses = {
            primary: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
            green: { bg: 'bg-[#eefbe7]', text: 'text-[#5cb83a]' },
            blue: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
            accent: { bg: 'bg-[#f3e8f4]', text: 'text-[#6c376f]' }
          };
          const colors = colorClasses[stat.color] || colorClasses.primary;
          
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 + idx * 0.05 }}
              className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
            >
              <div className={`w-12 h-12 ${colors.bg} rounded-xl flex items-center justify-center mb-4`}>
                <stat.icon className={`w-6 h-6 ${colors.text}`} />
              </div>
              <p className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</p>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </motion.div>
          );
        })}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-2xl border border-gray-200 p-6 mb-6 shadow-sm"
      >
        <div className="flex flex-col md:flex-row md:items-center gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by instructor, vehicle, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed] transition"
            />
          </div>

          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 px-4 py-3 border border-gray-300 rounded-xl hover:bg-gray-50 transition whitespace-nowrap"
          >
            <SlidersHorizontal className="w-5 h-5" />
            <span className="font-medium">Filters</span>
            {showFilters ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

        <div className="flex flex-wrap gap-3 mb-4">
          {["all", "confirmed", "completed", "cancelled", "pending", "in_progress"].map((status) => {
            const config = statusConfig[status] || statusConfig.confirmed;
            const count = status === "all" 
              ? bookings.length 
              : bookings.filter(b => b.status === status).length;

            return (
              <button
                key={status}
                onClick={() => setFilter(status)}
                className={`px-4 py-2 rounded-xl font-semibold text-sm transition ${
                  filter === status
                    ? `${config.lightBg} ${config.textColor} border-2 ${config.borderColor}`
                    : "bg-gray-100 text-gray-700 border-2 border-transparent hover:bg-gray-200"
                }`}
              >
                {status === "all" ? "All Lessons" : config.label}
                <span className="ml-2 px-2 py-0.5 bg-white rounded-full text-xs font-bold">
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="pt-4 border-t border-gray-200">
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
                    <select
                      value={dateRange}
                      onChange={(e) => setDateRange(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                    >
                      <option value="all">All Time</option>
                      <option value="upcoming">Upcoming</option>
                      <option value="past">Past</option>
                      <option value="week">Next 7 Days</option>
                      <option value="month">Next 30 Days</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Sort By</label>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                    >
                      <option value="date-desc">Newest First</option>
                      <option value="date-asc">Oldest First</option>
                      <option value="status">Status</option>
                      <option value="instructor">Instructor</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Lesson Type</label>
                    <select
                      value={selectedLessonType}
                      onChange={(e) => setSelectedLessonType(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                    >
                      <option value="all">All Types</option>
                      <option value="standard">Standard</option>
                      <option value="intensive">Intensive</option>
                      <option value="test_prep">Test Prep</option>
                      <option value="motorway">Motorway</option>
                      <option value="night">Night Driving</option>
                    </select>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      <div className="space-y-4">
        {filteredAndSortedBookings.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white rounded-2xl border border-gray-200 p-12 text-center shadow-sm"
          >
            <div className="flex justify-center mb-4">
              <VeeMascot size="xl" mood="wave" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              {searchTerm || filter !== "all" ? "No lessons match your search" : "Ready to start learning?"}
            </h3>
            <p className="text-gray-600 mb-6">
              {searchTerm || filter !== "all" ? "Try adjusting your filters" : "Book your first driving lesson and let's hit the road!"}
            </p>
            <Link
              to={createPageUrl("BookLesson")}
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#3b82c4] text-white rounded-xl font-semibold hover:bg-[#2563a3] transition"
            >
              <Calendar className="w-5 h-5" />
              Book Your First Lesson
            </Link>
          </motion.div>
        ) : (
          filteredAndSortedBookings.map((booking, index) => {
            const instructor = getInstructor(booking.instructor_id);
            const vehicle = getVehicle(booking.vehicle_id);
            const review = getReview(booking.id);
            const config = statusConfig[booking.status] || statusConfig.confirmed;
            const isExpanded = expandedLesson === booking.id;
            const lessonDuration = differenceInMinutes(new Date(booking.end_datetime), new Date(booking.start_datetime));

            return (
              <motion.div
                key={booking.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className="bg-white rounded-2xl border-2 border-gray-200 hover:border-gray-300 shadow-sm hover:shadow-md transition overflow-hidden"
              >
                <div className="p-6">
                  <div className="flex flex-col lg:flex-row gap-6">
                    <div className="flex items-center gap-4">
                      <div className="w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl flex flex-col items-center justify-center flex-shrink-0">
                        <p className="text-3xl font-bold text-gray-900">
                          {format(new Date(booking.start_datetime), "d")}
                        </p>
                        <p className="text-xs font-medium text-gray-600 uppercase">
                          {format(new Date(booking.start_datetime), "MMM")}
                        </p>
                      </div>

                      <div className="hidden lg:block w-px h-16 bg-gray-200"></div>
                    </div>

                    <div className="flex-1 space-y-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-xl font-bold text-gray-900">
                              {format(new Date(booking.start_datetime), "EEEE, MMMM d, yyyy")}
                            </h3>
                            <span className={`px-3 py-1 rounded-full text-xs font-bold ${config.lightBg} ${config.textColor} flex items-center gap-1`}>
                              <config.icon className="w-3 h-3" />
                              {config.label}
                            </span>
                          </div>
                          <div className="flex items-center gap-4 text-gray-600">
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4" />
                              <span className="font-medium">
                                {format(new Date(booking.start_datetime), "h:mm a")} - {format(new Date(booking.end_datetime), "h:mm a")}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Timer className="w-4 h-4" />
                              <span className="font-medium">{lessonDuration} minutes</span>
                            </div>
                          </div>
                        </div>

                        {booking.lesson_type && (
                        <span className="px-3 py-1 bg-[#e8f4fa] text-[#3b82c4] rounded-full text-xs font-semibold capitalize">
                          {booking.lesson_type.replace('_', ' ')}
                        </span>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                          <div className="w-10 h-10 bg-[#e8f4fa] rounded-lg flex items-center justify-center flex-shrink-0">
                            <User className="w-5 h-5 text-[#3b82c4]" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs text-gray-500 font-medium">Instructor</p>
                            <p className="font-bold text-gray-900 truncate">{instructor?.full_name || "Unknown"}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                          <div className="w-10 h-10 bg-[#f3e8f4] rounded-lg flex items-center justify-center flex-shrink-0">
                            <Car className="w-5 h-5 text-[#6c376f]" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs text-gray-500 font-medium">Vehicle</p>
                            <p className="font-bold text-gray-900 truncate">
                              {vehicle?.make} {vehicle?.model}
                            </p>
                          </div>
                        </div>

                        {booking.pickup_location && (
                          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                            <div className="w-10 h-10 bg-[#e8f4fa] rounded-lg flex items-center justify-center flex-shrink-0">
                              <MapPin className="w-5 h-5 text-[#3b82c4]" />
                            </div>
                            <div className="min-w-0">
                              <p className="text-xs text-gray-500 font-medium">Pickup</p>
                              <p className="font-bold text-gray-900 truncate">{booking.pickup_location}</p>
                            </div>
                          </div>
                        )}
                      </div>

                      {booking.status === "completed" && (
                        <div className="flex items-center gap-4">
                          {review ? (
                            <div className="flex items-center gap-2 px-3 py-2 bg-[#fdfbe8] border border-[#f9f3c8] rounded-lg">
                              <Star className="w-4 h-4 text-[#e7d356] fill-[#e7d356]" />
                              <span className="text-sm font-semibold text-[#9a8520]">
                                {review.rating}/5 - Reviewed
                              </span>
                            </div>
                          ) : (
                            <button className="flex items-center gap-2 px-3 py-2 bg-[#fdfbe8] border border-[#f9f3c8] rounded-lg hover:bg-[#f9f3c8] transition text-sm font-semibold text-[#9a8520]">
                              <Star className="w-4 h-4" />
                              Leave Review
                            </button>
                          )}
                          {booking.hours_credited && (
                            <div className="flex items-center gap-2 px-3 py-2 bg-[#eefbe7] border border-[#d4f4c3] rounded-lg">
                              <Award className="w-4 h-4 text-[#5cb83a]" />
                              <span className="text-sm font-semibold text-[#4a9c2e]">
                                {booking.hours_credited}h Credited
                              </span>
                            </div>
                          )}
                        </div>
                      )}

                      <div className="flex flex-wrap gap-2">
                        <button
                          onClick={() => setSelectedLesson(booking)}
                          className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-lg font-semibold text-sm transition flex items-center gap-2"
                        >
                          <Info className="w-4 h-4" />
                          View Details
                        </button>

                        {canRescheduleLesson(booking) && (
                          <button
                            onClick={() => handleReschedule(booking)}
                            className="px-4 py-2 bg-[#e8f4fa] hover:bg-[#d4eaf5] text-[#3b82c4] rounded-lg font-semibold text-sm transition flex items-center gap-2"
                          >
                            <RefreshCw className="w-4 h-4" />
                            Reschedule
                          </button>
                        )}

                        {canCancelLesson(booking) && (
                          <button
                            onClick={() => handleCancelLesson(booking)}
                            className="px-4 py-2 bg-[#fdeeed] hover:bg-[#f9d4d2] text-[#e44138] rounded-lg font-semibold text-sm transition flex items-center gap-2"
                          >
                            <XCircle className="w-4 h-4" />
                            Cancel
                          </button>
                        )}

                        {instructor && (
                          <button className="px-4 py-2 bg-[#eefbe7] hover:bg-[#d4f4c3] text-[#5cb83a] rounded-lg font-semibold text-sm transition flex items-center gap-2">
                            <MessageSquare className="w-4 h-4" />
                            Message
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {(booking.instructor_notes || booking.notes || booking.cancellation_reason) && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      {booking.instructor_notes && (
                        <div className="bg-[#e8f4fa] border border-[#d4eaf5] rounded-xl p-4 mb-3">
                          <div className="flex items-center gap-2 mb-2">
                            <User className="w-4 h-4 text-[#3b82c4]" />
                            <p className="text-sm font-bold text-[#2563a3]">Instructor Notes</p>
                          </div>
                          <p className="text-sm text-[#3b82c4]">{booking.instructor_notes}</p>
                        </div>
                      )}

                      {booking.notes && (
                        <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 mb-3">
                          <div className="flex items-center gap-2 mb-2">
                            <FileText className="w-4 h-4 text-gray-600" />
                            <p className="text-sm font-bold text-gray-900">Your Notes</p>
                          </div>
                          <p className="text-sm text-gray-700">{booking.notes}</p>
                        </div>
                      )}

                      {booking.cancellation_reason && (
                        <div className="bg-[#fdeeed] border border-[#f9d4d2] rounded-xl p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <AlertCircle className="w-4 h-4 text-[#e44138]" />
                            <p className="text-sm font-bold text-[#c9342c]">Cancellation Reason</p>
                          </div>
                          <p className="text-sm text-[#e44138]">{booking.cancellation_reason}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      <AnimatePresence>
        {selectedLesson && (
          <LessonDetailsDrawer
            booking={selectedLesson}
            instructor={getInstructor(selectedLesson.instructor_id)}
            vehicle={getVehicle(selectedLesson.vehicle_id)}
            onClose={() => setSelectedLesson(null)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCancelModal && lessonToCancel && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowCancelModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-[#fdeeed] rounded-xl flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-[#e44138]" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Cancel Lesson</h3>
                  <p className="text-sm text-gray-600">
                    {format(new Date(lessonToCancel.start_datetime), "MMM d, yyyy 'at' h:mm a")}
                  </p>
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reason for cancellation *
                </label>
                <textarea
                  value={cancelReason}
                  onChange={(e) => setCancelReason(e.target.value)}
                  placeholder="Please provide a reason for cancelling this lesson..."
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#e44138] resize-none"
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowCancelModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Keep Lesson
                </button>
                <button
                  onClick={confirmCancel}
                  disabled={cancelBookingMutation.isPending || !cancelReason.trim()}
                  className="flex-1 px-4 py-3 bg-[#e44138] hover:bg-[#c9342c] text-white rounded-xl font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {cancelBookingMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Cancelling...
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4" />
                      Cancel Lesson
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}