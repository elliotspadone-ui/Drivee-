import React, { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { format, startOfMonth, endOfMonth } from "date-fns";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";

const currencyFormatter = new Intl.NumberFormat("en-GB", {
  style: "currency",
  currency: "EUR",
  maximumFractionDigits: 2,
});

export default function InstructorCommission() {
  const navigate = useNavigate();
  const [dateRange, setDateRange] = useState({
    start: format(startOfMonth(new Date()), "yyyy-MM-dd"),
    end: format(endOfMonth(new Date()), "yyyy-MM-dd"),
  });

  const {
    data: instructors = [],
    isLoading: loadingInstructors,
    isError: instructorsError,
    error: instructorsErrorObj,
  } = useQuery({
    queryKey: ["instructors"],
    queryFn: () => base44.entities.Instructor.list(),
    retry: false,
  });

  const {
    data: bookings = [],
    isLoading: loadingBookings,
    isError: bookingsError,
    error: bookingsErrorObj,
  } = useQuery({
    queryKey: ["bookings"],
    queryFn: () => base44.entities.Booking.list(),
    retry: false,
  });

  const isLoading = loadingInstructors || loadingBookings;
  const isError = instructorsError || bookingsError;
  const activeError = instructorsErrorObj || bookingsErrorObj;

  const report = useMemo(() => {
    if (!instructors.length) {
      return {
        rows: [],
        totalRevenue: 0,
        totalCommission: 0,
        totalLessons: 0,
      };
    }

    const start = new Date(dateRange.start);
    const end = new Date(dateRange.end);

    const rows = instructors.map((instructor) => {
      const instructorBookings = bookings.filter((b) => {
        if (b.instructor_id !== instructor.id || b.status !== "completed") return false;
        const date = new Date(b.start_datetime);
        if (Number.isNaN(date.getTime())) return false;
        return date >= start && date <= end;
      });

      const revenue = instructorBookings.reduce((sum, b) => sum + (b.price || 0), 0);
      const commissionRate =
        typeof instructor.commission_rate === "number" && instructor.commission_rate >= 0
          ? instructor.commission_rate
          : 30;
      const commission = revenue * (commissionRate / 100);

      return {
        id: instructor.id,
        name: instructor.full_name,
        email: instructor.email,
        lessons: instructorBookings.length,
        revenue,
        commissionRate,
        commission,
        rating: instructor.rating || 0,
      };
    });

    const filteredRows = rows.filter((r) => r.lessons > 0).sort((a, b) => b.revenue - a.revenue);
    const totalRevenue = filteredRows.reduce((sum, r) => sum + r.revenue, 0);
    const totalCommission = filteredRows.reduce((sum, r) => sum + r.commission, 0);
    const totalLessons = filteredRows.reduce((sum, r) => sum + r.lessons, 0);

    return {
      rows: filteredRows,
      totalRevenue,
      totalCommission,
      totalLessons,
    };
  }, [instructors, bookings, dateRange]);

  const handleExport = () => {
    if (!report.rows.length) {
      toast.info("There is no instructor activity in this period to export");
      return;
    }

    try {
      const header = [
        "InstructorId",
        "Name",
        "Email",
        "Lessons",
        "Revenue",
        "CommissionRatePercent",
        "Commission",
        "PeriodStart",
        "PeriodEnd",
      ];

      const rows = report.rows.map((row) => [
        row.id || "",
        row.name || "",
        row.email || "",
        row.lessons,
        row.revenue.toFixed(2),
        row.commissionRate,
        row.commission.toFixed(2),
        dateRange.start,
        dateRange.end,
      ]);

      const csv =
        header.join(",") +
        "\n" +
        rows
          .map((row) =>
            row
              .map((field) => {
                const val = String(field ?? "");
                if (val.includes(",") || val.includes('"') || val.includes("\n")) {
                  return `"${val.replace(/"/g, '""')}"`;
                }
                return val;
              })
              .join(",")
          )
          .join("\n");

      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "drivee_instructor_commission.csv");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success("Instructor commission export generated");
    } catch (err) {
      console.error("Export error:", err);
      toast.error("Could not export instructor commission");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-10 h-10 animate-spin text-[#3b82c4]" />
          <p className="text-sm text-slate-600">Loading instructor commission report...</p>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="bg-white border border-red-100 rounded-xl p-6 max-w-md w-full">
          <p className="text-lg font-semibold text-red-700 mb-2">
            Could not load instructor commission data
          </p>
          <p className="text-sm text-slate-700 mb-4">
            {activeError?.message || "An unexpected error occurred while loading data."}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-red-600 text-white text-sm font-semibold hover:bg-red-700"
          >
            Reload page
          </button>
        </div>
      </div>
    );
  }

  const hasRows = report.rows.length > 0;
  const topInstructorId = hasRows ? report.rows[0].id : null;
  const avgCommissionPerLesson =
    report.totalLessons > 0 ? report.totalCommission / report.totalLessons : 0;

  return (
    <div className="space-y-6 pb-20">
      {/* Back button */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-sm font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
      </div>

      {/* Main card */}
      <div className="bg-white rounded-2xl border border-gray-200 p-8 shadow-sm">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed] bg-clip-text text-transparent">Instructor Commission Report</h1>
            <p className="text-gray-600 mt-1 text-sm">
              Earnings and commission for completed lessons in the selected period.
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Use this view to review payouts, compare instructor performance and plan monthly payroll.
            </p>
          </div>
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#3b82c4] text-white rounded-xl font-semibold hover:bg-[#2563a3] text-sm shadow-sm"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>

        {/* Date range selector */}
        <div className="flex flex-wrap gap-3 mb-8">
          <input
            type="date"
            value={dateRange.start}
            onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
            className="px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
          <span className="flex items-center text-gray-500 text-sm">to</span>
          <input
            type="date"
            value={dateRange.end}
            onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
            className="px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-[#e8f4fa] rounded-2xl p-6 border border-[#d4eaf5] shadow-sm">
            <p className="text-sm font-medium text-[#3b82c4] mb-2">Total Revenue</p>
            <p className="text-2xl font-bold text-gray-900">
              {currencyFormatter.format(report.totalRevenue)}
            </p>
            <p className="text-xs text-gray-600 mt-1">
              Revenue from completed lessons in this period
            </p>
          </div>
          <div className="bg-[#f3e8f4] rounded-2xl p-6 border border-[#e5d0e6] shadow-sm">
            <p className="text-sm font-medium text-[#6c376f] mb-2">Total Commission</p>
            <p className="text-2xl font-bold text-gray-900">
              {currencyFormatter.format(report.totalCommission)}
            </p>
            <p className="text-xs text-gray-600 mt-1">
              {report.rows.length} instructor
              {report.rows.length === 1 ? "" : "s"} with activity
            </p>
          </div>
          <div className="bg-[#eefbe7] rounded-2xl p-6 border border-[#d4f4c3] shadow-sm">
            <p className="text-sm font-medium text-[#5cb83a] mb-2">Total Lessons</p>
            <p className="text-2xl font-bold text-gray-900">{report.totalLessons}</p>
            <p className="text-xs text-gray-600 mt-1">Completed lessons in this period</p>
          </div>
          <div className="bg-[#fdfbe8] rounded-2xl p-6 border border-[#f9f3c8] shadow-sm">
            <p className="text-sm font-medium text-[#e7d356] mb-2">
              Avg Commission per Lesson
            </p>
            <p className="text-2xl font-bold text-gray-900">
              {currencyFormatter.format(avgCommissionPerLesson || 0)}
            </p>
            <p className="text-xs text-gray-600 mt-1">Helps benchmark instructor payouts</p>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                  Instructor
                </th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                  Email
                </th>
                <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">
                  Lessons
                </th>
                <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">
                  Revenue
                </th>
                <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">
                  Rate
                </th>
                <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">
                  Commission
                </th>
              </tr>
            </thead>
            <tbody>
              {report.rows.map((row) => {
                const isTop = row.id === topInstructorId;
                return (
                  <tr
                    key={row.id}
                    className={`border-b border-gray-100 hover:bg-gray-50 ${
                      isTop ? "bg-[#e8f4fa]" : ""
                    }`}
                  >
                    <td className="py-3 px-4 text-sm font-medium text-gray-900">
                      {row.name}
                      {isTop && (
                        <span className="ml-2 inline-flex items-center rounded-full bg-[#e8f4fa] px-2 py-0.5 text-[11px] font-semibold text-[#3b82c4]">
                          Top performer
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-600">{row.email}</td>
                    <td className="py-3 px-4 text-sm text-right text-gray-700">
                      {row.lessons}
                    </td>
                    <td className="py-3 px-4 text-sm text-right font-semibold text-gray-900">
                      {currencyFormatter.format(row.revenue)}
                    </td>
                    <td className="py-3 px-4 text-sm text-right text-gray-700">
                      {row.commissionRate}%
                    </td>
                    <td className="py-3 px-4 text-sm text-right font-bold text-[#6c376f]">
                      {currencyFormatter.format(row.commission)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {!hasRows && (
            <div className="text-center py-12">
              <p className="text-sm font-medium text-gray-800 mb-1">
                No instructor activity for this period
              </p>
              <p className="text-sm text-gray-500">
                Try widening the date range or check that completed lessons have a price set.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}