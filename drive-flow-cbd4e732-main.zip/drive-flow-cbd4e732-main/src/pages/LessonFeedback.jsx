import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Star, CheckCircle, Send } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function LessonFeedback() {
  const queryClient = useQueryClient();

  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);

  // Get booking ID from URL (query param "id" or last part of path)
  const bookingId =
    new URLSearchParams(window.location.search).get("id") ||
    window.location.pathname.split("/").filter(Boolean).pop();

  // Booking
  const {
    data: booking,
    isLoading: bookingLoading,
    isError: bookingError,
  } = useQuery({
    queryKey: ["booking", bookingId],
    queryFn: async () => {
      const bookings = await base44.entities.Booking.filter({ id: bookingId });
      return bookings[0] || null;
    },
    enabled: !!bookingId,
  });

  // Instructor
  const {
    data: instructor,
    isLoading: instructorLoading,
    isError: instructorError,
  } = useQuery({
    queryKey: ["instructor", booking?.instructor_id],
    queryFn: async () => {
      const instructors = await base44.entities.Instructor.filter({
        id: booking.instructor_id,
      });
      return instructors[0] || null;
    },
    enabled: !!booking?.instructor_id,
  });

  // Student (not shown today but useful for future personalization)
  const { data: student } = useQuery({
    queryKey: ["student", booking?.student_id],
    queryFn: async () => {
      const students = await base44.entities.Student.filter({
        id: booking.student_id,
      });
      return students[0] || null;
    },
    enabled: !!booking?.student_id,
  });

  // School for branding in thank you screen
  const { data: school } = useQuery({
    queryKey: ["school", booking?.school_id],
    queryFn: async () => {
      const schools = await base44.entities.School.filter({
        id: booking.school_id,
      });
      return schools[0] || null;
    },
    enabled: !!booking?.school_id,
  });

  // Check if there is already a review for this booking
  const {
    data: existingReview,
    isLoading: reviewLoading,
    isError: reviewError,
  } = useQuery({
    queryKey: ["review", bookingId],
    queryFn: async () => {
      const reviews = await base44.entities.Review.filter({
        booking_id: bookingId,
      });
      return reviews[0] || null;
    },
    enabled: !!bookingId,
  });

  const submitFeedbackMutation = useMutation({
    mutationFn: (data) => base44.entities.Review.create(data),
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Thank you for your feedback!");
      // If you have any aggregated rating views, you could invalidate them here
      queryClient.invalidateQueries({ queryKey: ["review", bookingId] });
    },
    onError: () => {
      toast.error("Something went wrong while submitting your feedback. Please try again.");
    },
  });

  const isSubmitting =
    submitFeedbackMutation.isPending || submitFeedbackMutation.isLoading;

  const handleSubmit = () => {
    if (!booking || !instructor) {
      toast.error("We could not load your lesson details. Please try again later.");
      return;
    }

    if (existingReview) {
      toast.info("You have already submitted feedback for this lesson.");
      return;
    }

    if (rating === 0) {
      toast.error("Please select a rating before submitting.");
      return;
    }

    if (isSubmitting) return;

    submitFeedbackMutation.mutate({
      rating,
      comment,
      booking_id: booking.id,
      instructor_id: instructor.id,
      student_id: booking.student_id,
      school_id: booking.school_id,
    });
  };

  const isLoadingAll =
    bookingLoading || instructorLoading || reviewLoading || !bookingId;
  const hasCriticalError =
    bookingError || instructorError || reviewError || !bookingId;

  // Loading or error states before main view
  if (isLoadingAll && !booking && !instructor) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center p-6">
        <div className="neo-surface p-8 rounded-3xl text-center">
          <p className="text-gray-600">Loading your lesson details...</p>
        </div>
      </div>
    );
  }

  if (hasCriticalError || !booking || !instructor) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center p-6">
        <div className="neo-surface p-8 rounded-3xl text-center max-w-md">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            We could not load your lesson
          </h1>
          <p className="text-gray-600 mb-4">
            The feedback link seems invalid or this lesson is no longer available.
          </p>
          <p className="text-sm text-muted">
            Please contact your driving school if you think this is a mistake.
          </p>
        </div>
      </div>
    );
  }

  const finalSchoolName = school?.name || "DriveSchool";
  const hasExistingReview = !!existingReview;

  // If the user already left a review, or just submitted one, show the thank you view
  if (submitted || hasExistingReview) {
    const displayRating = hasExistingReview
      ? existingReview.rating
      : rating || existingReview?.rating;

    const displayComment =
      hasExistingReview && existingReview.comment
        ? existingReview.comment
        : comment;

    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="neo-surface p-12 rounded-3xl text-center max-w-md"
        >
          <div className="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-9 h-9 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Thank you!</h1>
          <p className="text-gray-600 mb-4">
            Your feedback for this lesson has been recorded.
          </p>

          {displayRating ? (
            <div className="flex items-center justify-center gap-1 mb-3">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-5 h-5 ${
                    star <= displayRating
                      ? "text-yellow-500 fill-yellow-500"
                      : "text-gray-300"
                  }`}
                />
              ))}
            </div>
          ) : null}

          {displayComment ? (
            <p className="text-sm text-gray-500 italic mb-4">
              “{displayComment}”
            </p>
          ) : null}

          {hasExistingReview && (
            <p className="text-xs text-gray-400 mb-2">
              You already shared your feedback for this lesson.
            </p>
          )}

          <p className="text-sm text-muted">{finalSchoolName}</p>
        </motion.div>
      </div>
    );
  }

  const lessonDurationMinutes = Math.round(
    (new Date(booking.end_datetime) - new Date(booking.start_datetime)) / 60000
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="neo-surface p-8 md:p-12 rounded-3xl max-w-2xl w-full"
      >
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Rate your lesson
          </h1>
          <p className="text-muted">
            How was your lesson with {instructor.full_name}?
          </p>
        </div>

        <div className="neo-inset p-6 rounded-2xl mb-8">
          <h3 className="font-semibold text-gray-900 mb-3">Lesson details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted">Instructor</span>
              <span className="font-semibold text-gray-900">
                {instructor.full_name}
              </span>
            </div>
            {student && (
              <div className="flex justify-between">
                <span className="text-muted">Student</span>
                <span className="text-gray-900">
                  {student.full_name || student.email || "You"}
                </span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-muted">Date</span>
              <span className="font-semibold text-gray-900">
                {new Date(booking.start_datetime).toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted">Duration</span>
              <span className="font-semibold text-gray-900">
                {lessonDurationMinutes} minutes
              </span>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          {/* Star Rating */}
          <div className="text-center">
            <p className="text-sm font-semibold text-gray-900 mb-6">
              Your rating
            </p>
            <div className="flex items-center justify-center gap-3">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="smooth transform hover:scale-110"
                >
                  <Star
                    className={`w-14 h-14 ${
                      star <= (hoveredRating || rating)
                        ? "text-yellow-500 fill-yellow-500"
                        : "text-gray-300"
                    }`}
                  />
                </button>
              ))}
            </div>
            {rating > 0 && (
              <p className="text-lg font-semibold text-gray-900 mt-4">
                {rating === 5
                  ? "Excellent! ⭐"
                  : rating === 4
                  ? "Great! 👍"
                  : rating === 3
                  ? "Good 😊"
                  : rating === 2
                  ? "Okay 😐"
                  : "Needs improvement 😕"}
              </p>
            )}
          </div>

          {/* Comment */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-3">
              Share your experience (optional)
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full neo-inset px-4 py-4 rounded-xl focus:outline-none h-40 resize-none"
              placeholder="Tell us what went well and what could be improved..."
            />
          </div>

          {/* Submit */}
          <button
            type="button"
            onClick={handleSubmit}
            disabled={isSubmitting || rating === 0 || hasExistingReview}
            className={`w-full neo-button py-5 flex items-center justify-center gap-3 font-semibold text-lg ${
              rating > 0 && !isSubmitting && !hasExistingReview
                ? "gradient-primary text-white shadow-lg"
                : ""
            } ${hasExistingReview ? "opacity-60 cursor-not-allowed" : ""}`}
          >
            {isSubmitting ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Submitting...</span>
              </>
            ) : hasExistingReview ? (
              <span>Feedback already submitted</span>
            ) : (
              <>
                <Send className="w-6 h-6" />
                <span>Submit feedback</span>
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
