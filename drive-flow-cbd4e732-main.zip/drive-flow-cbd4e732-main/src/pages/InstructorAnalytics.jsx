import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  TrendingUp, 
  Users, 
  CheckCircle, 
  Star, 
  Calendar, 
  Award,
  ArrowLeft,
  Download,
  RefreshCw,
  Loader2,
  Target,
  Clock,
  DollarSign,
  BarChart3,
  PieChart as PieChartIcon,
  Activity,
  Zap,
  Trophy,
  Medal,
  Flame,
  ThumbsUp,
  ThumbsDown,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  ChevronRight,
  Eye,
  Share2,
  Printer,
  Filter,
  Info,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Car,
  BookOpen,
  GraduationCap,
  Heart,
  MessageSquare,
  Bell,
  Settings,
  Sun,
  Moon,
  Sunrise,
  MapPin
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  AreaChart,
  Area,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ComposedChart
} from "recharts";
import { format, subDays, startOfMonth, endOfMonth, differenceInDays, startOfWeek, endOfWeek, subWeeks, subMonths, isWithinInterval, parseISO } from "date-fns";
import { toast } from "sonner";

export default function InstructorAnalytics() {
  const navigate = useNavigate();
  
  const [currentUser, setCurrentUser] = useState(null);
  const [instructor, setInstructor] = useState(null);
  const [dateRange, setDateRange] = useState("30days");
  const [activeTab, setActiveTab] = useState("overview");
  const [isLoading, setIsLoading] = useState(true);
  const [comparisonMode, setComparisonMode] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      try {
        setIsLoading(true);
        const user = await base44.auth.me();
        setCurrentUser(user);
        const instructors = await base44.entities.Instructor.filter({ email: user.email });
        if (instructors.length > 0) {
          setInstructor(instructors[0]);
        }
      } catch (error) {
        console.error("Error loading user:", error);
        toast.error("Failed to load user data");
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: bookings = [], isLoading: loadingBookings } = useQuery({
    queryKey: ['instructorAnalyticsBookings', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      return await base44.entities.Booking.filter({ instructor_id: instructor.id });
    },
    enabled: !!instructor,
  });

  const { data: students = [] } = useQuery({
    queryKey: ['students'],
    queryFn: () => base44.entities.Student.list(),
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['instructorReviews', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      try {
        return await base44.entities.Review.filter({ instructor_id: instructor.id });
      } catch {
        return [];
      }
    },
    enabled: !!instructor,
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ['instructorInvoices', instructor?.id],
    queryFn: async () => {
      if (!instructor) return [];
      try {
        return await base44.entities.Invoice.filter({ instructor_id: instructor.id });
      } catch {
        return [];
      }
    },
    enabled: !!instructor,
  });

  const dateRangeConfig = useMemo(() => {
    const now = new Date();
    let startDate, endDate, previousStartDate, previousEndDate;
    
    if (dateRange === "7days") {
      startDate = subDays(now, 7);
      endDate = now;
      previousStartDate = subDays(now, 14);
      previousEndDate = subDays(now, 7);
    } else if (dateRange === "30days") {
      startDate = subDays(now, 30);
      endDate = now;
      previousStartDate = subDays(now, 60);
      previousEndDate = subDays(now, 30);
    } else if (dateRange === "thisMonth") {
      startDate = startOfMonth(now);
      endDate = endOfMonth(now);
      previousStartDate = startOfMonth(subMonths(now, 1));
      previousEndDate = endOfMonth(subMonths(now, 1));
    } else if (dateRange === "90days") {
      startDate = subDays(now, 90);
      endDate = now;
      previousStartDate = subDays(now, 180);
      previousEndDate = subDays(now, 90);
    } else if (dateRange === "year") {
      startDate = subDays(now, 365);
      endDate = now;
      previousStartDate = subDays(now, 730);
      previousEndDate = subDays(now, 365);
    } else {
      startDate = subDays(now, 30);
      endDate = now;
      previousStartDate = subDays(now, 60);
      previousEndDate = subDays(now, 30);
    }
    
    return { startDate, endDate, previousStartDate, previousEndDate };
  }, [dateRange]);

  const filteredBookings = useMemo(() => {
    const { startDate, endDate } = dateRangeConfig;
    return bookings.filter(b => {
      const bookingDate = new Date(b.start_datetime);
      return bookingDate >= startDate && bookingDate <= endDate;
    });
  }, [bookings, dateRangeConfig]);

  const previousPeriodBookings = useMemo(() => {
    const { previousStartDate, previousEndDate } = dateRangeConfig;
    return bookings.filter(b => {
      const bookingDate = new Date(b.start_datetime);
      return bookingDate >= previousStartDate && bookingDate <= previousEndDate;
    });
  }, [bookings, dateRangeConfig]);

  const stats = useMemo(() => {
    const completedLessons = filteredBookings.filter(b => b.status === "completed").length;
    const prevCompletedLessons = previousPeriodBookings.filter(b => b.status === "completed").length;
    const lessonsGrowth = prevCompletedLessons > 0 
      ? ((completedLessons - prevCompletedLessons) / prevCompletedLessons) * 100 
      : 0;

    const totalHours = filteredBookings
      .filter(b => b.status === "completed")
      .reduce((sum, b) => {
        const start = new Date(b.start_datetime);
        const end = new Date(b.end_datetime);
        return sum + (end - start) / (1000 * 60 * 60);
      }, 0);

    const prevTotalHours = previousPeriodBookings
      .filter(b => b.status === "completed")
      .reduce((sum, b) => {
        const start = new Date(b.start_datetime);
        const end = new Date(b.end_datetime);
        return sum + (end - start) / (1000 * 60 * 60);
      }, 0);
    const hoursGrowth = prevTotalHours > 0 
      ? ((totalHours - prevTotalHours) / prevTotalHours) * 100 
      : 0;

    const assignedStudentIds = [...new Set(bookings.map(b => b.student_id))];
    const assignedStudents = students.filter(s => assignedStudentIds.includes(s.id));

    const studentsWithExam = assignedStudents.filter(s => s.practical_exam_date);
    const passedStudents = assignedStudents.filter(s => s.practical_exam_passed);
    const passRate = studentsWithExam.length > 0 
      ? (passedStudents.length / studentsWithExam.length) * 100 
      : 0;

    const avgRating = reviews.length > 0
      ? reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviews.length
      : 0;

    const earnings = filteredBookings
      .filter(b => b.status === "completed")
      .reduce((sum, b) => sum + ((b.instructor_earnings || b.price * 0.3) || 0), 0);

    const prevEarnings = previousPeriodBookings
      .filter(b => b.status === "completed")
      .reduce((sum, b) => sum + ((b.instructor_earnings || b.price * 0.3) || 0), 0);
    const earningsGrowth = prevEarnings > 0 
      ? ((earnings - prevEarnings) / prevEarnings) * 100 
      : 0;

    const cancelledLessons = filteredBookings.filter(b => b.status === "cancelled").length;
    const noShowLessons = filteredBookings.filter(b => b.status === "no_show").length;
    const cancellationRate = filteredBookings.length > 0
      ? ((cancelledLessons + noShowLessons) / filteredBookings.length) * 100
      : 0;

    const completionRate = filteredBookings.length > 0
      ? (completedLessons / filteredBookings.length) * 100
      : 0;

    return {
      completedLessons,
      lessonsGrowth,
      totalHours,
      hoursGrowth,
      assignedStudents,
      studentsWithExam,
      passedStudents,
      passRate,
      avgRating,
      totalReviews: reviews.length,
      earnings,
      earningsGrowth,
      cancelledLessons,
      noShowLessons,
      cancellationRate,
      completionRate,
      totalBookings: filteredBookings.length
    };
  }, [filteredBookings, previousPeriodBookings, bookings, students, reviews]);

  const weeklyTrendData = useMemo(() => {
    const data = [];
    const weeksToShow = dateRange === "7days" ? 2 : dateRange === "year" ? 52 : 12;
    
    for (let i = weeksToShow - 1; i >= 0; i--) {
      const weekEnd = subWeeks(new Date(), i);
      const weekStart = startOfWeek(weekEnd);
      const weekEndDate = endOfWeek(weekEnd);
      
      const weekBookings = bookings.filter(b => {
        const date = new Date(b.start_datetime);
        return date >= weekStart && date <= weekEndDate;
      });
      
      const completedBookings = weekBookings.filter(b => b.status === "completed");
      
      data.push({
        week: format(weekStart, "MMM d"),
        lessons: completedBookings.length,
        hours: completedBookings.reduce((sum, b) => {
          const start = new Date(b.start_datetime);
          const end = new Date(b.end_datetime);
          return sum + (end - start) / (1000 * 60 * 60);
        }, 0),
        earnings: completedBookings.reduce((sum, b) => 
          sum + ((b.instructor_earnings || b.price * 0.3) || 0), 0
        ),
        cancellations: weekBookings.filter(b => b.status === "cancelled").length
      });
    }
    
    return data;
  }, [bookings, dateRange]);

  const statusDistribution = useMemo(() => {
    return [
      { name: "Completed", value: filteredBookings.filter(b => b.status === "completed").length, color: "#81da5a" },
      { name: "Confirmed", value: filteredBookings.filter(b => b.status === "confirmed").length, color: "#3b82c4" },
      { name: "Cancelled", value: filteredBookings.filter(b => b.status === "cancelled").length, color: "#e44138" },
      { name: "No Show", value: filteredBookings.filter(b => b.status === "no_show").length, color: "#e7d356" },
      { name: "In Progress", value: filteredBookings.filter(b => b.status === "in_progress").length, color: "#6c376f" }
    ].filter(d => d.value > 0);
  }, [filteredBookings]);

  const lessonTimeDistribution = useMemo(() => {
    const timeSlots = {
      morning: { label: "Morning (6-12)", count: 0, icon: Sunrise },
      afternoon: { label: "Afternoon (12-18)", count: 0, icon: Sun },
      evening: { label: "Evening (18-22)", count: 0, icon: Moon }
    };

    filteredBookings.filter(b => b.status === "completed").forEach(b => {
      const hour = new Date(b.start_datetime).getHours();
      if (hour >= 6 && hour < 12) timeSlots.morning.count++;
      else if (hour >= 12 && hour < 18) timeSlots.afternoon.count++;
      else timeSlots.evening.count++;
    });

    return Object.entries(timeSlots).map(([key, value]) => ({
      name: value.label,
      value: value.count,
      color: key === "morning" ? "#e7d356" : key === "afternoon" ? "#3b82c4" : "#6c376f"
    }));
  }, [filteredBookings]);

  const studentProgressData = useMemo(() => {
    return stats.assignedStudents
      .map(s => ({
        name: s.full_name?.split(' ')[0] || 'Student',
        fullName: s.full_name,
        progress: s.progress_percentage || 0,
        hours: s.total_hours_completed || 0,
        lessons: bookings.filter(b => b.student_id === s.id && b.status === "completed").length,
        passedExam: s.practical_exam_passed
      }))
      .sort((a, b) => b.progress - a.progress)
      .slice(0, 10);
  }, [stats.assignedStudents, bookings]);

  const performanceRadarData = useMemo(() => {
    const maxLessons = Math.max(...weeklyTrendData.map(w => w.lessons), 1);
    const maxHours = Math.max(...weeklyTrendData.map(w => w.hours), 1);
    
    return [
      { subject: 'Lessons', A: (stats.completedLessons / (maxLessons * weeklyTrendData.length)) * 100, fullMark: 100 },
      { subject: 'Hours', A: (stats.totalHours / (maxHours * weeklyTrendData.length)) * 100, fullMark: 100 },
      { subject: 'Pass Rate', A: stats.passRate, fullMark: 100 },
      { subject: 'Rating', A: (stats.avgRating / 5) * 100, fullMark: 100 },
      { subject: 'Completion', A: stats.completionRate, fullMark: 100 },
      { subject: 'Retention', A: 100 - stats.cancellationRate, fullMark: 100 }
    ];
  }, [stats, weeklyTrendData]);

  const achievements = useMemo(() => {
    const totalLessonsEver = bookings.filter(b => b.status === "completed").length;
    const totalStudentsEver = stats.assignedStudents.length;
    
    return [
      { 
        id: "lessons_100", 
        title: "Century Teacher", 
        desc: "Complete 100 lessons", 
        icon: "📚", 
        unlocked: totalLessonsEver >= 100,
        progress: Math.min((totalLessonsEver / 100) * 100, 100),
        current: totalLessonsEver,
        target: 100
      },
      { 
        id: "lessons_500", 
        title: "Master Instructor", 
        desc: "Complete 500 lessons", 
        icon: "🎓", 
        unlocked: totalLessonsEver >= 500,
        progress: Math.min((totalLessonsEver / 500) * 100, 100),
        current: totalLessonsEver,
        target: 500
      },
      { 
        id: "first_pass", 
        title: "First Success", 
        desc: "First student passed exam", 
        icon: "🏆", 
        unlocked: stats.passedStudents.length >= 1,
        progress: stats.passedStudents.length >= 1 ? 100 : 0,
        current: stats.passedStudents.length,
        target: 1
      },
      { 
        id: "five_star", 
        title: "5-Star Instructor", 
        desc: "Achieve 5-star rating", 
        icon: "⭐", 
        unlocked: stats.avgRating >= 4.9,
        progress: Math.min((stats.avgRating / 5) * 100, 100),
        current: stats.avgRating.toFixed(1),
        target: 5
      },
      { 
        id: "high_pass", 
        title: "Excellence Award", 
        desc: "80%+ pass rate (10+ students)", 
        icon: "🎯", 
        unlocked: stats.passRate >= 80 && stats.studentsWithExam.length >= 10,
        progress: stats.studentsWithExam.length >= 10 ? Math.min(stats.passRate, 100) : (stats.studentsWithExam.length / 10) * 100,
        current: `${stats.passRate.toFixed(0)}%`,
        target: "80%"
      },
      { 
        id: "student_10", 
        title: "Growing Network", 
        desc: "Teach 10 students", 
        icon: "👥", 
        unlocked: totalStudentsEver >= 10,
        progress: Math.min((totalStudentsEver / 10) * 100, 100),
        current: totalStudentsEver,
        target: 10
      },
      { 
        id: "perfect_week", 
        title: "Perfect Week", 
        desc: "Complete all scheduled lessons in a week", 
        icon: "✨", 
        unlocked: stats.completionRate >= 100 && stats.completedLessons >= 5,
        progress: Math.min(stats.completionRate, 100),
        current: `${stats.completionRate.toFixed(0)}%`,
        target: "100%"
      },
      { 
        id: "dedication", 
        title: "Dedicated Teacher", 
        desc: "Teach 1000 hours total", 
        icon: "💪", 
        unlocked: stats.totalHours >= 1000,
        progress: Math.min((stats.totalHours / 1000) * 100, 100),
        current: stats.totalHours.toFixed(0),
        target: 1000
      }
    ];
  }, [bookings, stats]);

  const handleExportAnalytics = () => {
    const data = {
      period: dateRange,
      generatedAt: new Date().toISOString(),
      summary: {
        completedLessons: stats.completedLessons,
        totalHours: stats.totalHours,
        earnings: stats.earnings,
        passRate: stats.passRate,
        avgRating: stats.avgRating
      },
      weeklyTrend: weeklyTrendData
    };

    const csvContent = [
      ["Analytics Report - " + format(new Date(), "MMMM d, yyyy")],
      [""],
      ["Summary"],
      ["Completed Lessons", stats.completedLessons],
      ["Total Hours", stats.totalHours.toFixed(1)],
      ["Earnings", `€${stats.earnings.toFixed(2)}`],
      ["Pass Rate", `${stats.passRate.toFixed(1)}%`],
      ["Average Rating", stats.avgRating.toFixed(1)],
      [""],
      ["Weekly Trend"],
      ["Week", "Lessons", "Hours", "Earnings"],
      ...weeklyTrendData.map(w => [w.week, w.lessons, w.hours.toFixed(1), `€${w.earnings.toFixed(2)}`])
    ].map(row => row.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `instructor_analytics_${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    toast.success("Analytics exported successfully");
  };

  if (isLoading || loadingBookings) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-[#3b82c4] mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 pb-24 md:pb-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col lg:flex-row lg:items-center justify-between gap-4"
      >
        <div>
          <Link
            to={createPageUrl("InstructorDashboard")}
            className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-[#3b82c4] to-[#6c376f] bg-clip-text text-transparent mb-2">
            Performance Analytics
          </h1>
          <p className="text-gray-600 mt-1">Track your teaching performance and growth</p>
        </div>
        
        <div className="flex gap-3 flex-wrap">
          <button
            onClick={handleExportAnalytics}
            className="px-4 py-2 bg-white border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            {["overview", "trends", "students", "reviews", "achievements"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-xl text-sm font-semibold transition ${
                  activeTab === tab
                    ? "bg-[#3b82c4] text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>
          
          <div className="flex flex-wrap gap-2">
            {[
              { key: "7days", label: "7 Days" },
              { key: "30days", label: "30 Days" },
              { key: "thisMonth", label: "This Month" },
              { key: "90days", label: "90 Days" },
              { key: "year", label: "Year" }
            ].map((range) => (
              <button
                key={range.key}
                onClick={() => setDateRange(range.key)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                  dateRange === range.key
                    ? "bg-[#e8f4fa] text-[#3b82c4] border border-[#d4eaf5]"
                    : "bg-gray-100 hover:bg-gray-200 text-gray-700"
                }`}
              >
                {range.label}
              </button>
            ))}
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {[
          { 
            label: "Lessons", 
            value: stats.completedLessons, 
            icon: CheckCircle, 
            color: "green",
            growth: stats.lessonsGrowth,
            subtitle: `${stats.totalHours.toFixed(1)}h taught`
          },
          { 
            label: "Students", 
            value: stats.assignedStudents.length, 
            icon: Users, 
            color: "indigo",
            subtitle: `${stats.passedStudents.length} passed`
          },
          { 
            label: "Pass Rate", 
            value: `${stats.passRate.toFixed(0)}%`, 
            icon: Award, 
            color: "purple",
            subtitle: `${stats.passedStudents.length}/${stats.studentsWithExam.length}`
          },
          { 
            label: "Rating", 
            value: stats.avgRating.toFixed(1), 
            icon: Star, 
            color: "yellow",
            subtitle: `${stats.totalReviews} reviews`
          },
          { 
            label: "Earnings", 
            value: `€${stats.earnings.toFixed(0)}`, 
            icon: DollarSign, 
            color: "emerald",
            growth: stats.earningsGrowth
          },
          { 
            label: "Completion", 
            value: `${stats.completionRate.toFixed(0)}%`, 
            icon: Target, 
            color: "blue",
            subtitle: `${stats.cancelledLessons} cancelled`
          }
        ].map((stat, idx) => {
          const colorClasses = {
            green: { bg: 'bg-[#eefbe7]', text: 'text-[#5cb83a]' },
            indigo: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
            purple: { bg: 'bg-[#f3e8f4]', text: 'text-[#6c376f]' },
            yellow: { bg: 'bg-[#fdfbe8]', text: 'text-[#e7d356]' },
            emerald: { bg: 'bg-[#eefbe7]', text: 'text-[#5cb83a]' },
            blue: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' }
          };
          const colors = colorClasses[stat.color] || colorClasses.indigo;
          
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + idx * 0.05 }}
              className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm hover:shadow-md transition"
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`w-10 h-10 ${colors.bg} rounded-lg flex items-center justify-center`}>
                  <stat.icon className={`w-5 h-5 ${colors.text}`} />
                </div>
                {stat.growth !== undefined && (
                  <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold ${
                    stat.growth >= 0 ? "bg-[#eefbe7] text-[#4a9c2e]" : "bg-[#fdeeed] text-[#c9342c]"
                  }`}>
                    {stat.growth >= 0 ? (
                      <ArrowUpRight className="w-3 h-3" />
                    ) : (
                      <ArrowDownRight className="w-3 h-3" />
                    )}
                    {Math.abs(stat.growth).toFixed(0)}%
                  </div>
                )}
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-xs text-gray-600">{stat.label}</p>
              {stat.subtitle && (
                <p className="text-xs text-gray-500 mt-1">{stat.subtitle}</p>
              )}
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === "overview" && (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Lessons Trend</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <AreaChart data={weeklyTrendData}>
                    <defs>
                      <linearGradient id="colorLessons" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82c4" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#3b82c4" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="week" stroke="#6b7280" style={{ fontSize: '12px' }} />
                    <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="lessons" 
                      stroke="#3b82c4" 
                      strokeWidth={2}
                      fill="url(#colorLessons)" 
                      name="Lessons" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Performance Radar</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <RadarChart data={performanceRadarData}>
                    <PolarGrid stroke="#e5e7eb" />
                    <PolarAngleAxis dataKey="subject" tick={{ fontSize: 12, fill: '#6b7280' }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 10, fill: '#9ca3af' }} />
                    <Radar 
                      name="Performance" 
                      dataKey="A" 
                      stroke="#3b82c4" 
                      fill="#3b82c4" 
                      fillOpacity={0.3}
                      strokeWidth={2}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Lesson Status Distribution</h3>
                {statusDistribution.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={statusDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}`}
                      >
                        {statusDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-64 text-gray-500">
                    No data available
                  </div>
                )}
              </div>

              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Lesson Time Preferences</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={lessonTimeDistribution} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis type="number" stroke="#6b7280" style={{ fontSize: '12px' }} />
                    <YAxis type="category" dataKey="name" stroke="#6b7280" style={{ fontSize: '12px' }} width={100} />
                    <Tooltip />
                    <Bar dataKey="value" name="Lessons" radius={[0, 8, 8, 0]}>
                      {lessonTimeDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "trends" && (
          <motion.div
            key="trends"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Combined Performance Trends</h3>
              <ResponsiveContainer width="100%" height={350}>
                <ComposedChart data={weeklyTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="week" stroke="#6b7280" style={{ fontSize: '12px' }} />
                  <YAxis yAxisId="left" stroke="#6b7280" style={{ fontSize: '12px' }} />
                  <YAxis yAxisId="right" orientation="right" stroke="#10b981" style={{ fontSize: '12px' }} />
                  <Tooltip />
                  <Legend />
                  <Bar yAxisId="left" dataKey="lessons" fill="#3b82c4" name="Lessons" radius={[4, 4, 0, 0]} />
                  <Line yAxisId="left" type="monotone" dataKey="hours" stroke="#6c376f" strokeWidth={2} name="Hours" />
                  <Line yAxisId="right" type="monotone" dataKey="earnings" stroke="#81da5a" strokeWidth={2} name="Earnings (€)" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Hours Trend</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <AreaChart data={weeklyTrendData}>
                    <defs>
                      <linearGradient id="colorHours" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6c376f" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#6c376f" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="week" stroke="#6b7280" style={{ fontSize: '12px' }} />
                    <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="hours" 
                      stroke="#6c376f" 
                      strokeWidth={2}
                      fill="url(#colorHours)" 
                      name="Hours" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Earnings Trend</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <AreaChart data={weeklyTrendData}>
                    <defs>
                      <linearGradient id="colorEarnings" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#81da5a" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#81da5a" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="week" stroke="#6b7280" style={{ fontSize: '12px' }} />
                    <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} tickFormatter={(v) => `€${v}`} />
                    <Tooltip formatter={(value) => [`€${value.toFixed(2)}`, 'Earnings']} />
                    <Area 
                      type="monotone" 
                      dataKey="earnings" 
                      stroke="#81da5a" 
                      strokeWidth={2}
                      fill="url(#colorEarnings)" 
                      name="Earnings" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "students" && (
          <motion.div
            key="students"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-gradient-to-br from-[#eefbe7] to-[#d4f4c3] border border-[#d4f4c3] rounded-2xl p-6 text-center">
                <Trophy className="w-10 h-10 text-[#5cb83a] mx-auto mb-3" />
                <p className="text-4xl font-bold text-[#5cb83a]">{stats.passedStudents.length}</p>
                <p className="text-sm text-gray-600 mt-1">Students Passed</p>
              </div>
              <div className="bg-gradient-to-br from-[#fdeeed] to-[#f9d4d2] border border-[#f9d4d2] rounded-2xl p-6 text-center">
                <XCircle className="w-10 h-10 text-[#e44138] mx-auto mb-3" />
                <p className="text-4xl font-bold text-[#e44138]">
                  {stats.studentsWithExam.length - stats.passedStudents.length}
                </p>
                <p className="text-sm text-gray-600 mt-1">Students Failed</p>
              </div>
              <div className="bg-gradient-to-br from-[#e8f4fa] to-[#d4eaf5] border border-[#d4eaf5] rounded-2xl p-6 text-center">
                <Target className="w-10 h-10 text-[#3b82c4] mx-auto mb-3" />
                <p className="text-4xl font-bold text-[#3b82c4]">{stats.passRate.toFixed(0)}%</p>
                <p className="text-sm text-gray-600 mt-1">Overall Pass Rate</p>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Student Progress Overview</h3>
              {studentProgressData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={studentProgressData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis type="number" domain={[0, 100]} stroke="#6b7280" style={{ fontSize: '12px' }} />
                    <YAxis type="category" dataKey="name" stroke="#6b7280" style={{ fontSize: '12px' }} width={80} />
                    <Tooltip 
                      formatter={(value, name) => [
                        name === 'progress' ? `${value}%` : value,
                        name === 'progress' ? 'Progress' : name
                      ]}
                    />
                    <Bar dataKey="progress" fill="#3b82c4" name="Progress" radius={[0, 8, 8, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No student progress data available</p>
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Student Details</h3>
              <div className="space-y-3">
                {studentProgressData.map((student, idx) => (
                  <div key={idx} className="p-4 bg-gray-50 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-[#3b82c4] to-[#6c376f] rounded-xl flex items-center justify-center">
                        <span className="text-white font-bold">{student.name.charAt(0)}</span>
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">{student.fullName}</p>
                        <p className="text-sm text-gray-600">{student.lessons} lessons • {student.hours.toFixed(1)}h</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="font-bold text-gray-900">{student.progress}%</p>
                        <p className="text-xs text-gray-500">Progress</p>
                      </div>
                      {student.passedExam && (
                        <span className="px-3 py-1 bg-[#eefbe7] text-[#4a9c2e] rounded-full text-xs font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Passed
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "reviews" && (
          <motion.div
            key="reviews"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-gradient-to-br from-amber-50 to-yellow-50 border border-amber-200 rounded-2xl p-8 text-center">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Star className="w-10 h-10 text-amber-500 fill-amber-500" />
                <span className="text-5xl font-bold text-gray-900">{stats.avgRating.toFixed(1)}</span>
              </div>
              <div className="flex justify-center gap-1 mb-3">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-6 h-6 ${star <= Math.round(stats.avgRating) ? "text-amber-500 fill-amber-500" : "text-gray-300"}`}
                  />
                ))}
              </div>
              <p className="text-gray-600">Based on {stats.totalReviews} reviews</p>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Rating Distribution</h3>
              <div className="space-y-3">
                {[5, 4, 3, 2, 1].map((rating) => {
                  const count = reviews.filter(r => Math.round(r.rating || 0) === rating).length;
                  const percentage = stats.totalReviews > 0 ? (count / stats.totalReviews) * 100 : 0;
                  
                  return (
                    <div key={rating} className="flex items-center gap-3">
                      <div className="flex items-center gap-1 w-20">
                        <span className="font-bold text-gray-900">{rating}</span>
                        <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                      </div>
                      <div className="flex-1 h-3 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 transition-all"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                      <span className="w-12 text-sm text-gray-600 text-right">{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Reviews</h3>
              <div className="space-y-4">
                {reviews.length > 0 ? (
                  reviews.slice(0, 10).map((review, idx) => {
                    const student = students.find(s => s.id === review.student_id);
                    return (
                      <div key={idx} className="p-4 bg-gray-50 rounded-xl">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-[#3b82c4] to-[#6c376f] rounded-xl flex items-center justify-center">
                              <span className="text-white font-bold">
                                {student?.full_name?.charAt(0) || "A"}
                              </span>
                            </div>
                            <div>
                              <p className="font-bold text-gray-900">{student?.full_name || "Anonymous"}</p>
                              {review.created_date && (
                                <p className="text-xs text-gray-500">
                                  {format(new Date(review.created_date), "MMM d, yyyy")}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="flex gap-0.5">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-4 h-4 ${star <= (review.rating || 0) ? "text-amber-500 fill-amber-500" : "text-gray-300"}`}
                              />
                            ))}
                          </div>
                        </div>
                        {review.comment && (
                          <p className="text-sm text-gray-700 leading-relaxed">{review.comment}</p>
                        )}
                      </div>
                    );
                  })
                ) : (
                  <div className="text-center py-12">
                    <Star className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">No reviews yet</p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === "achievements" && (
          <motion.div
            key="achievements"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-6">
                <Trophy className="w-8 h-8 text-amber-500" />
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Achievements & Milestones</h3>
                  <p className="text-sm text-gray-600">
                    {achievements.filter(a => a.unlocked).length}/{achievements.length} unlocked
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {achievements.map((achievement) => (
                  <div
                    key={achievement.id}
                    className={`p-6 rounded-xl border-2 transition ${
                      achievement.unlocked 
                        ? "bg-gradient-to-br from-[#e8f4fa] to-[#f3e8f4] border-[#d4eaf5]" 
                        : "bg-gray-50 border-gray-200"
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <span className={`text-4xl ${achievement.unlocked ? "" : "grayscale opacity-50"}`}>
                        {achievement.icon}
                      </span>
                      <div className="flex-1">
                        <h4 className="font-bold text-gray-900 mb-1">{achievement.title}</h4>
                        <p className="text-sm text-gray-600 mb-3">{achievement.desc}</p>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs">
                            <span className="text-gray-500">Progress</span>
                            <span className="font-bold text-gray-900">
                              {achievement.current} / {achievement.target}
                            </span>
                          </div>
                          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${achievement.progress}%` }}
                              className={`h-full ${achievement.unlocked ? "bg-[#81da5a]" : "bg-[#3b82c4]"}`}
                            />
                          </div>
                        </div>

                        {achievement.unlocked && (
                          <span className="inline-flex items-center gap-1 mt-3 px-3 py-1 bg-[#eefbe7] text-[#4a9c2e] rounded-full text-xs font-bold">
                            <CheckCircle2 className="w-3 h-3" />
                            Unlocked
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}