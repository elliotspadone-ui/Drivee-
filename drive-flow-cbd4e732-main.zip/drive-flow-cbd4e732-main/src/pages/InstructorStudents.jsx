import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Users, 
  Search, 
  Phone, 
  Mail, 
  Calendar, 
  MessageSquare, 
  DollarSign, 
  FileText, 
  TrendingUp, 
  Award, 
  Plus, 
  Eye, 
  Send,
  ArrowLeft,
  Loader2,
  Filter,
  Download,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Star,
  Clock,
  Target,
  AlertCircle,
  CheckCircle,
  XCircle,
  User,
  MapPin,
  Car,
  GraduationCap,
  BookOpen,
  BarChart3,
  PieChart,
  Activity,
  Zap,
  Heart,
  Flag,
  MoreVertical,
  X,
  Edit,
  Trash2,
  Copy,
  ExternalLink,
  Navigation,
  CalendarDays,
  CalendarRange,
  Timer,
  Gauge,
  Shield,
  AlertTriangle,
  Info,
  Bell,
  Settings,
  SortAsc,
  SortDesc,
  Grid,
  List,
  UserPlus,
  UserMinus,
  MessageCircle,
  ThumbsUp,
  ThumbsDown
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  format, 
  differenceInDays, 
  differenceInWeeks,
  isAfter, 
  isBefore, 
  parseISO,
  addDays,
  subDays,
  startOfMonth,
  endOfMonth
} from "date-fns";
import { toast } from "sonner";
import { ScrollFadeIn, StaggerFadeIn, ScrollProgress } from "@/components/animations/FadeSections";
import { KPIComparisonCard, AnimatedCounter } from "@/components/charts/KPIComparison";
import LeafletWorldMap, { MarkerList } from "@/components/maps/LeafletWorldMap";
import { BottomDrawer, ActionSheet } from "@/components/common/Drawer";

const SKILL_CATEGORIES = {
  vehicle_control: {
    label: "Vehicle Control",
    skills: ["Steering", "Gear Changes", "Clutch Control", "Braking", "Acceleration"],
    color: "blue"
  },
  observations: {
    label: "Observations",
    skills: ["Mirror Usage", "Blind Spot Checks", "Road Scanning", "Hazard Perception"],
    color: "purple"
  },
  maneuvers: {
    label: "Maneuvers",
    skills: ["Parallel Parking", "Bay Parking", "Reverse Parking", "Turn in Road", "Emergency Stop"],
    color: "amber"
  },
  road_procedure: {
    label: "Road Procedure",
    skills: ["Roundabouts", "Junctions", "Lane Discipline", "Speed Control", "Following Distance"],
    color: "green"
  }
};

const STUDENT_STATUS = {
  active: { label: "Active", color: "green", icon: CheckCircle },
  inactive: { label: "Inactive", color: "gray", icon: XCircle },
  on_hold: { label: "On Hold", color: "amber", icon: AlertCircle },
  test_ready: { label: "Test Ready", color: "purple", icon: Award },
  graduated: { label: "Graduated", color: "blue", icon: GraduationCap }
};

export default function InstructorStudents() {
  const queryClient = useQueryClient();
  
  const [user, setUser] = useState(null);
  const [instructor, setInstructor] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("active");
  const [viewMode, setViewMode] = useState("table");
  const [sortBy, setSortBy] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showFilters, setShowFilters] = useState(false);
  
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [showStudentModal, setShowStudentModal] = useState(false);
  const [showProgressModal, setShowProgressModal] = useState(false);
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [showBroadcastModal, setShowBroadcastModal] = useState(false);
  const [showNotesModal, setShowNotesModal] = useState(false);
  
  const [messageText, setMessageText] = useState("");
  const [broadcastMessage, setBroadcastMessage] = useState("");
  const [selectedStudentsForBroadcast, setSelectedStudentsForBroadcast] = useState(new Set());
  const [studentNote, setStudentNote] = useState("");
  const [expandedStudentId, setExpandedStudentId] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        setIsLoading(true);
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        const instructors = await base44.entities.Instructor.filter({ email: currentUser.email });
        if (instructors.length > 0) {
          setInstructor(instructors[0]);
        }
      } catch (error) {
        console.error("Error loading user:", error);
        toast.error("Failed to load user data");
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: allStudents = [], isLoading: loadingStudents, refetch: refetchStudents } = useQuery({
    queryKey: ['students'],
    queryFn: () => base44.entities.Student.list(),
    enabled: !!instructor,
  });

  const { data: bookings = [], isLoading: loadingBookings } = useQuery({
    queryKey: ['instructor-bookings', instructor?.id],
    queryFn: () => base44.entities.Booking.filter({ instructor_id: instructor?.id }),
    enabled: !!instructor,
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ['invoices'],
    queryFn: () => base44.entities.Invoice.list(),
    enabled: !!instructor,
  });

  const { data: lessonRecords = [] } = useQuery({
    queryKey: ['lessonRecords', instructor?.id],
    queryFn: async () => {
      try {
        return await base44.entities.LessonRecord.filter({ instructor_id: instructor?.id });
      } catch {
        return [];
      }
    },
    enabled: !!instructor,
  });

  const { data: studentNotes = [] } = useQuery({
    queryKey: ['studentNotes', instructor?.id],
    queryFn: async () => {
      try {
        return await base44.entities.StudentNote.filter({ instructor_id: instructor?.id });
      } catch {
        return [];
      }
    },
    enabled: !!instructor,
  });

  const updateStudentMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Student.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      toast.success("Student updated successfully");
    },
    onError: () => {
      toast.error("Failed to update student");
    }
  });

  const createNoteMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.StudentNote.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['studentNotes'] });
      toast.success("Note added successfully");
      setShowNotesModal(false);
      setStudentNote("");
    },
    onError: () => {
      toast.error("Failed to add note");
    }
  });

  const assignedStudentIds = useMemo(() => {
    return [...new Set(bookings.map(b => b.student_id))];
  }, [bookings]);

  const myStudents = useMemo(() => {
    return allStudents.filter(s => assignedStudentIds.includes(s.id));
  }, [allStudents, assignedStudentIds]);

  const getStudentStats = useCallback((studentId) => {
    const studentBookings = bookings.filter(b => b.student_id === studentId);
    const completedLessons = studentBookings.filter(b => b.status === "completed");
    const upcomingLessons = studentBookings.filter(b => 
      (b.status === "confirmed" || b.status === "pending") && 
      isAfter(new Date(b.start_datetime), new Date())
    ).sort((a, b) => new Date(a.start_datetime) - new Date(b.start_datetime));
    
    const totalHours = completedLessons.reduce((sum, b) => {
      const duration = (new Date(b.end_datetime) - new Date(b.start_datetime)) / (1000 * 60 * 60);
      return sum + duration;
    }, 0);

    const studentInvoices = invoices.filter(i => i.student_id === studentId);
    const balance = studentInvoices.reduce((sum, inv) => 
      sum + (inv.status !== "paid" ? (inv.total_amount || 0) - (inv.amount_paid || 0) : 0), 0
    );

    const studentRecords = lessonRecords.filter(r => r.student_id === studentId);
    const lastLesson = completedLessons[completedLessons.length - 1];
    const nextLesson = upcomingLessons[0];

    const cancelledLessons = studentBookings.filter(b => b.status === "cancelled" || b.status === "no_show").length;
    const attendanceRate = studentBookings.length > 0 
      ? ((studentBookings.length - cancelledLessons) / studentBookings.length) * 100 
      : 100;

    return {
      completedLessons: completedLessons.length,
      upcomingLessons: upcomingLessons.length,
      totalHours,
      balance,
      nextLesson,
      lastLesson,
      lessonRecords: studentRecords,
      attendanceRate,
      cancelledLessons
    };
  }, [bookings, invoices, lessonRecords]);

  const enrichedStudents = useMemo(() => {
    return myStudents.map(student => ({
      ...student,
      stats: getStudentStats(student.id)
    }));
  }, [myStudents, getStudentStats]);

  const filteredStudents = useMemo(() => {
    let filtered = [...enrichedStudents];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(s =>
        s.full_name?.toLowerCase().includes(query) ||
        s.email?.toLowerCase().includes(query) ||
        s.phone?.includes(searchQuery)
      );
    }

    if (statusFilter !== "all") {
      if (statusFilter === "active") {
        filtered = filtered.filter(s => s.is_active !== false);
      } else if (statusFilter === "inactive") {
        filtered = filtered.filter(s => s.is_active === false);
      } else if (statusFilter === "test_ready") {
        filtered = filtered.filter(s => s.exam_eligible);
      } else if (statusFilter === "has_balance") {
        filtered = filtered.filter(s => s.stats.balance > 0);
      }
    }

    if (activeTab === "active") {
      filtered = filtered.filter(s => s.is_active !== false && !s.graduated);
    } else if (activeTab === "test_ready") {
      filtered = filtered.filter(s => s.exam_eligible);
    } else if (activeTab === "graduated") {
      filtered = filtered.filter(s => s.graduated);
    }

    filtered.sort((a, b) => {
      let comparison = 0;
      
      if (sortBy === "name") {
        comparison = (a.full_name || "").localeCompare(b.full_name || "");
      } else if (sortBy === "hours") {
        comparison = (a.stats.totalHours || 0) - (b.stats.totalHours || 0);
      } else if (sortBy === "lessons") {
        comparison = (a.stats.completedLessons || 0) - (b.stats.completedLessons || 0);
      } else if (sortBy === "balance") {
        comparison = (a.stats.balance || 0) - (b.stats.balance || 0);
      } else if (sortBy === "next_lesson") {
        const dateA = a.stats.nextLesson ? new Date(a.stats.nextLesson.start_datetime) : new Date(9999, 0);
        const dateB = b.stats.nextLesson ? new Date(b.stats.nextLesson.start_datetime) : new Date(9999, 0);
        comparison = dateA - dateB;
      }

      return sortOrder === "asc" ? comparison : -comparison;
    });

    return filtered;
  }, [enrichedStudents, searchQuery, statusFilter, activeTab, sortBy, sortOrder]);

  const stats = useMemo(() => {
    const active = enrichedStudents.filter(s => s.is_active !== false && !s.graduated);
    const testReady = enrichedStudents.filter(s => s.exam_eligible);
    const graduated = enrichedStudents.filter(s => s.graduated);
    const completedLessons = bookings.filter(b => b.status === "completed").length;
    const totalHours = enrichedStudents.reduce((sum, s) => sum + (s.stats.totalHours || 0), 0);
    const totalBalance = enrichedStudents.reduce((sum, s) => sum + (s.stats.balance || 0), 0);
    const avgProgress = enrichedStudents.length > 0
      ? enrichedStudents.reduce((sum, s) => {
          const progress = ((s.total_hours_completed || 0) / (s.total_hours_required || 40)) * 100;
          return sum + Math.min(100, progress);
        }, 0) / enrichedStudents.length
      : 0;

    return {
      total: enrichedStudents.length,
      active: active.length,
      testReady: testReady.length,
      graduated: graduated.length,
      completedLessons,
      totalHours,
      totalBalance,
      avgProgress
    };
  }, [enrichedStudents, bookings]);

  const handleSendMessage = (student) => {
    setSelectedStudent(student);
    setMessageText("");
    setShowMessageModal(true);
  };

  const handleViewStudent = (student) => {
    setSelectedStudent(student);
    setShowStudentModal(true);
  };

  const handleViewProgress = (student) => {
    setSelectedStudent(student);
    setShowProgressModal(true);
  };

  const handleAddNote = (student) => {
    setSelectedStudent(student);
    setStudentNote("");
    setShowNotesModal(true);
  };

  const submitNote = () => {
    if (!studentNote.trim() || !selectedStudent) {
      toast.error("Please enter a note");
      return;
    }

    createNoteMutation.mutate({
      student_id: selectedStudent.id,
      instructor_id: instructor.id,
      note: studentNote,
      created_at: new Date().toISOString()
    });
  };

  const sendMessage = () => {
    if (!messageText.trim()) {
      toast.error("Please enter a message");
      return;
    }
    
    toast.success(`Message sent to ${selectedStudent?.full_name}`);
    setShowMessageModal(false);
    setMessageText("");
    setSelectedStudent(null);
  };

  const sendBroadcast = () => {
    if (!broadcastMessage.trim()) {
      toast.error("Please enter a message");
      return;
    }
    
    const count = selectedStudentsForBroadcast.size || filteredStudents.length;
    toast.success(`Broadcast sent to ${count} student${count !== 1 ? 's' : ''}`);
    setShowBroadcastModal(false);
    setBroadcastMessage("");
    setSelectedStudentsForBroadcast(new Set());
  };

  const toggleStudentForBroadcast = (studentId) => {
    setSelectedStudentsForBroadcast(prev => {
      const next = new Set(prev);
      if (next.has(studentId)) {
        next.delete(studentId);
      } else {
        next.add(studentId);
      }
      return next;
    });
  };

  const selectAllForBroadcast = () => {
    if (selectedStudentsForBroadcast.size === filteredStudents.length) {
      setSelectedStudentsForBroadcast(new Set());
    } else {
      setSelectedStudentsForBroadcast(new Set(filteredStudents.map(s => s.id)));
    }
  };

  const toggleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(prev => prev === "asc" ? "desc" : "asc");
    } else {
      setSortBy(field);
      setSortOrder("asc");
    }
  };

  const getStudentStatus = (student) => {
    if (student.graduated) return STUDENT_STATUS.graduated;
    if (student.exam_eligible) return STUDENT_STATUS.test_ready;
    if (student.is_active === false) return STUDENT_STATUS.inactive;
    if (student.on_hold) return STUDENT_STATUS.on_hold;
    return STUDENT_STATUS.active;
  };

  const exportStudentData = () => {
    toast.success("Student data exported");
  };

  if (isLoading || loadingStudents || loadingBookings) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-[#3b82c4] mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading students...</p>
        </div>
      </div>
    );
  }

  return (
    <>
    <ScrollProgress color="#3b82c4" height={3} />
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6 space-y-6">
      <ScrollFadeIn direction="up">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Link
          to={createPageUrl("InstructorDashboard")}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-[#3b82c4] to-[#6c376f] bg-clip-text text-transparent mb-2">
              My Students
            </h1>
            <p className="text-gray-600 mt-1">{stats.total} student{stats.total !== 1 ? 's' : ''} under your instruction</p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => refetchStudents()}
              className="p-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              <RefreshCw className="w-5 h-5 text-gray-600" />
            </button>
            <button
              onClick={exportStudentData}
              className="p-2 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              <Download className="w-5 h-5 text-gray-600" />
            </button>
            <button
              onClick={() => setShowBroadcastModal(true)}
              className="px-4 py-2 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              Broadcast
            </button>
          </div>
        </div>
      </motion.div>
      </ScrollFadeIn>

      <StaggerFadeIn staggerDelay={0.03}>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
        {[
          { label: "Total", value: stats.total, icon: Users, bgColor: "bg-[#e8f4fa]", iconColor: "text-[#3b82c4]" },
          { label: "Active", value: stats.active, icon: CheckCircle, bgColor: "bg-[#eefbe7]", iconColor: "text-[#5cb83a]" },
          { label: "Test Ready", value: stats.testReady, icon: Award, bgColor: "bg-[#f3e8f4]", iconColor: "text-[#6c376f]" },
          { label: "Graduated", value: stats.graduated, icon: GraduationCap, bgColor: "bg-[#e8f4fa]", iconColor: "text-[#3b82c4]" },
          { label: "Lessons", value: stats.completedLessons, icon: Calendar, bgColor: "bg-[#fdfbe8]", iconColor: "text-[#e7d356]" },
          { label: "Hours", value: stats.totalHours.toFixed(1), icon: Clock, bgColor: "bg-[#e8f4fa]", iconColor: "text-[#3b82c4]" },
          { label: "Avg Progress", value: `${stats.avgProgress.toFixed(0)}%`, icon: TrendingUp, bgColor: "bg-[#eefbe7]", iconColor: "text-[#5cb83a]" },
          { label: "Balance", value: `€${stats.totalBalance.toFixed(0)}`, icon: DollarSign, bgColor: "bg-[#fdeeed]", iconColor: "text-[#e44138]" }
        ].map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.03 }}
            className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm hover:shadow-md hover:border-[#d4eaf5] transition-all"
          >
            <div className={`w-10 h-10 ${stat.bgColor} rounded-xl flex items-center justify-center mb-2`}>
              <stat.icon className={`w-5 h-5 ${stat.iconColor}`} />
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-xs text-gray-600 font-medium">{stat.label}</p>
          </motion.div>
        ))}
      </div>
      </StaggerFadeIn>

      <ScrollFadeIn direction="up" delay={0.1}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm space-y-4"
      >
        <div className="flex flex-wrap gap-2">
          {[
            { id: "active", label: "Active", count: stats.active },
            { id: "test_ready", label: "Test Ready", count: stats.testReady },
            { id: "graduated", label: "Graduated", count: stats.graduated },
            { id: "all", label: "All Students", count: stats.total }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition ${
                activeTab === tab.id
                  ? "bg-[#3b82c4] text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {tab.label}
              <span className="ml-2 px-2 py-0.5 bg-white/20 rounded-full text-xs">
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name, email, or phone..."
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
            />
          </div>

          <div className="flex gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
              >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="test_ready">Test Ready</option>
              <option value="has_balance">Has Balance</option>
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
              >
              <option value="name">Sort by Name</option>
              <option value="hours">Sort by Hours</option>
              <option value="lessons">Sort by Lessons</option>
              <option value="balance">Sort by Balance</option>
              <option value="next_lesson">Sort by Next Lesson</option>
            </select>

            <button
              onClick={() => setSortOrder(prev => prev === "asc" ? "desc" : "asc")}
              className="p-3 border border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              {sortOrder === "asc" ? (
                <SortAsc className="w-5 h-5 text-gray-600" />
              ) : (
                <SortDesc className="w-5 h-5 text-gray-600" />
              )}
            </button>

            <div className="flex gap-1 p-1 bg-gray-100 rounded-xl">
              <button
                onClick={() => setViewMode("table")}
                className={`p-2 rounded-lg transition ${viewMode === "table" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
              >
                <List className="w-5 h-5 text-gray-600" />
              </button>
              <button
                onClick={() => setViewMode("cards")}
                className={`p-2 rounded-lg transition ${viewMode === "cards" ? "bg-white shadow-sm" : "hover:bg-gray-200"}`}
              >
                <Grid className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>

        <div className="text-sm text-gray-600">
          Showing {filteredStudents.length} student{filteredStudents.length !== 1 ? 's' : ''}
        </div>
      </motion.div>
      </ScrollFadeIn>

      {filteredStudents.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">No students found</h3>
          <p className="text-gray-600">
            {searchQuery ? "Try adjusting your search or filters" : "No students are currently assigned to you"}
          </p>
        </div>
      ) : viewMode === "table" ? (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Student</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Progress</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Next Lesson</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Test Date</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Balance</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
                  <th className="px-6 py-4 text-right text-xs font-bold text-gray-600 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredStudents.map((student, index) => {
                  const status = getStudentStatus(student);
                  const hoursCompleted = student.total_hours_completed || 0;
                  const hoursRequired = student.total_hours_required || 40;
                  const progress = Math.min(100, (hoursCompleted / hoursRequired) * 100);

                  return (
                    <motion.tr
                      key={student.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: index * 0.02 }}
                      className="hover:bg-gray-50 transition"
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-[#3b82c4] to-[#6c376f] rounded-xl flex items-center justify-center flex-shrink-0">
                            <span className="text-white font-bold">
                              {student.full_name?.charAt(0) || "S"}
                            </span>
                          </div>
                          <div className="min-w-0">
                            <p className="font-bold text-gray-900 truncate">{student.full_name}</p>
                            <p className="text-sm text-gray-600 truncate">{student.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="min-w-[100px]">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-600">{hoursCompleted}h</span>
                            <span className="font-semibold">{hoursRequired}h</span>
                          </div>
                          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed] rounded-full transition-all"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{progress.toFixed(0)}%</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {student.stats.nextLesson ? (
                          <div>
                            <p className="text-sm font-semibold text-gray-900">
                              {format(new Date(student.stats.nextLesson.start_datetime), "MMM d")}
                            </p>
                            <p className="text-xs text-gray-600">
                              {format(new Date(student.stats.nextLesson.start_datetime), "h:mm a")}
                            </p>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-400">Not scheduled</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        {student.practical_exam_date ? (
                          <div>
                            <p className="text-sm font-semibold text-gray-900">
                              {format(new Date(student.practical_exam_date), "MMM d, yyyy")}
                            </p>
                            <p className="text-xs text-gray-600">
                              {differenceInDays(new Date(student.practical_exam_date), new Date())} days away
                            </p>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-400">Not set</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        {student.stats.balance > 0 ? (
                          <span className="text-sm font-bold text-[#e44138]">
                            €{student.stats.balance.toFixed(2)}
                          </span>
                        ) : (
                          <span className="text-sm text-[#5cb83a] font-semibold">Paid</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1 px-2 py-1 bg-${status.color}-100 text-${status.color}-700 rounded-full text-xs font-bold`}>
                          <status.icon className="w-3 h-3" />
                          {status.label}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => handleViewStudent(student)}
                            className="p-2 hover:bg-gray-100 rounded-lg transition"
                            title="View Details"
                          >
                            <Eye className="w-4 h-4 text-gray-600" />
                          </button>
                          <button
                            onClick={() => handleViewProgress(student)}
                            className="p-2 hover:bg-gray-100 rounded-lg transition"
                            title="View Progress"
                          >
                            <BarChart3 className="w-4 h-4 text-gray-600" />
                          </button>
                          {student.phone && (
                            <a
                              href={`tel:${student.phone}`}
                              className="p-2 hover:bg-gray-100 rounded-lg transition"
                              title="Call"
                            >
                              <Phone className="w-4 h-4 text-gray-600" />
                            </a>
                          )}
                          <button
                            onClick={() => handleSendMessage(student)}
                            className="p-2 hover:bg-gray-100 rounded-lg transition"
                            title="Message"
                          >
                            <MessageSquare className="w-4 h-4 text-gray-600" />
                          </button>
                          <button
                            onClick={() => handleAddNote(student)}
                            className="p-2 hover:bg-gray-100 rounded-lg transition"
                            title="Add Note"
                          >
                            <FileText className="w-4 h-4 text-gray-600" />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredStudents.map((student, index) => {
            const status = getStudentStatus(student);
            const hoursCompleted = student.total_hours_completed || 0;
            const hoursRequired = student.total_hours_required || 40;
            const progress = Math.min(100, (hoursCompleted / hoursRequired) * 100);

            return (
              <motion.div
                key={student.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm hover:shadow-md transition"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-[#3b82c4] to-[#6c376f] rounded-xl flex items-center justify-center">
                      <span className="text-white font-bold text-lg">
                        {student.full_name?.charAt(0) || "S"}
                      </span>
                    </div>
                    <div>
                      <p className="font-bold text-gray-900">{student.full_name}</p>
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 bg-${status.color}-100 text-${status.color}-700 rounded-full text-xs font-bold`}>
                        <status.icon className="w-3 h-3" />
                        {status.label}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 mb-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Progress</span>
                      <span className="font-semibold">{hoursCompleted} / {hoursRequired} hours</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed] rounded-full"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 bg-gray-50 rounded-lg">
                      <p className="text-gray-600">Lessons</p>
                      <p className="font-bold text-gray-900">{student.stats.completedLessons}</p>
                    </div>
                    <div className="p-2 bg-gray-50 rounded-lg">
                      <p className="text-gray-600">Attendance</p>
                      <p className="font-bold text-gray-900">{student.stats.attendanceRate.toFixed(0)}%</p>
                    </div>
                  </div>

                  {student.stats.nextLesson && (
                    <div className="p-2 bg-[#e8f4fa] border border-[#d4eaf5] rounded-xl">
                      <p className="text-xs text-[#2563a3] font-semibold">Next Lesson</p>
                      <p className="text-sm text-[#3b82c4]">
                        {format(new Date(student.stats.nextLesson.start_datetime), "MMM d 'at' h:mm a")}
                      </p>
                    </div>
                  )}

                  {student.stats.balance > 0 && (
                    <div className="p-2 bg-[#fdeeed] border border-[#f9d4d2] rounded-xl">
                      <p className="text-xs text-[#c9342c] font-semibold">Outstanding Balance</p>
                      <p className="text-sm font-bold text-[#e44138]">€{student.stats.balance.toFixed(2)}</p>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleViewStudent(student)}
                    className="flex-1 px-3 py-2 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-lg font-semibold text-sm transition flex items-center justify-center gap-1"
                  >
                    <Eye className="w-4 h-4" />
                    View
                  </button>
                  <button
                    onClick={() => handleSendMessage(student)}
                    className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition"
                  >
                    <MessageSquare className="w-4 h-4 text-gray-600" />
                  </button>
                  {student.phone && (
                    <a
                      href={`tel:${student.phone}`}
                      className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition flex items-center justify-center"
                    >
                      <Phone className="w-4 h-4 text-gray-600" />
                    </a>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      <AnimatePresence>
        {showStudentModal && selectedStudent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowStudentModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Student Details</h3>
                <button
                  onClick={() => setShowStudentModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#3b82c4] to-[#6c376f] rounded-2xl flex items-center justify-center">
                    <span className="text-white font-bold text-2xl">
                      {selectedStudent.full_name?.charAt(0) || "S"}
                    </span>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{selectedStudent.full_name}</p>
                    <span className={`inline-flex items-center gap-1 px-2 py-1 bg-${getStudentStatus(selectedStudent).color}-100 text-${getStudentStatus(selectedStudent).color}-700 rounded-full text-xs font-bold`}>
                      {getStudentStatus(selectedStudent).label}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {selectedStudent.email && (
                    <div className="p-3 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-2 mb-1">
                        <Mail className="w-4 h-4 text-gray-400" />
                        <span className="text-xs text-gray-600">Email</span>
                      </div>
                      <p className="text-sm font-semibold text-gray-900">{selectedStudent.email}</p>
                    </div>
                  )}
                  {selectedStudent.phone && (
                    <div className="p-3 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-2 mb-1">
                        <Phone className="w-4 h-4 text-gray-400" />
                        <span className="text-xs text-gray-600">Phone</span>
                      </div>
                      <p className="text-sm font-semibold text-gray-900">{selectedStudent.phone}</p>
                    </div>
                  )}
                  {selectedStudent.address && (
                    <div className="p-3 bg-gray-50 rounded-xl col-span-2">
                      <div className="flex items-center gap-2 mb-1">
                        <MapPin className="w-4 h-4 text-gray-400" />
                        <span className="text-xs text-gray-600">Address</span>
                      </div>
                      <p className="text-sm font-semibold text-gray-900">{selectedStudent.address}</p>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="p-3 bg-[#e8f4fa] rounded-2xl text-center">
                    <p className="text-2xl font-bold text-[#3b82c4]">{selectedStudent.stats.completedLessons}</p>
                    <p className="text-xs text-[#2563a3] font-medium">Lessons</p>
                  </div>
                  <div className="p-3 bg-[#f3e8f4] rounded-2xl text-center">
                    <p className="text-2xl font-bold text-[#6c376f]">{selectedStudent.stats.totalHours.toFixed(1)}</p>
                    <p className="text-xs text-[#5a2d5d] font-medium">Hours</p>
                  </div>
                  <div className="p-3 bg-[#eefbe7] rounded-2xl text-center">
                    <p className="text-2xl font-bold text-[#5cb83a]">{selectedStudent.stats.attendanceRate.toFixed(0)}%</p>
                    <p className="text-xs text-[#4a9c2e] font-medium">Attendance</p>
                  </div>
                  <div className="p-3 bg-[#fdfbe8] rounded-2xl text-center">
                    <p className="text-2xl font-bold text-[#e7d356]">{selectedStudent.stats.upcomingLessons}</p>
                    <p className="text-xs text-[#b8a525] font-medium">Upcoming</p>
                  </div>
                </div>

                {selectedStudent.practical_exam_date && (
                  <div className="p-4 bg-[#f3e8f4] border border-[#e5d0e6] rounded-2xl">
                    <div className="flex items-center gap-2">
                      <Award className="w-5 h-5 text-[#6c376f]" />
                      <p className="font-semibold text-[#5a2d5d]">Practical Test</p>
                    </div>
                    <p className="text-[#6c376f] mt-1">
                      {format(new Date(selectedStudent.practical_exam_date), "EEEE, MMMM d, yyyy")}
                    </p>
                  </div>
                )}

                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowStudentModal(false);
                      handleSendMessage(selectedStudent);
                    }}
                    className="flex-1 px-4 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                  >
                    <MessageSquare className="w-4 h-4" />
                    Send Message
                  </button>
                  {selectedStudent.phone && (
                    <a
                      href={`tel:${selectedStudent.phone}`}
                      className="flex-1 px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-900 rounded-xl font-semibold transition flex items-center justify-center gap-2"
                    >
                      <Phone className="w-4 h-4" />
                      Call
                    </a>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showProgressModal && selectedStudent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowProgressModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Student Progress</h3>
                  <p className="text-sm text-gray-600">{selectedStudent.full_name}</p>
                </div>
                <button
                  onClick={() => setShowProgressModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="p-4 bg-[#e8f4fa] border border-[#d4eaf5] rounded-2xl">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold text-[#2563a3]">Overall Progress</span>
                    <span className="text-lg font-bold text-[#3b82c4]">
                      {((selectedStudent.total_hours_completed || 0) / (selectedStudent.total_hours_required || 40) * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div className="w-full h-3 bg-white rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed] rounded-full"
                      style={{ 
                        width: `${Math.min(100, ((selectedStudent.total_hours_completed || 0) / (selectedStudent.total_hours_required || 40)) * 100)}%` 
                      }}
                    />
                  </div>
                  <p className="text-sm text-[#3b82c4] mt-2">
                    {selectedStudent.total_hours_completed || 0} of {selectedStudent.total_hours_required || 40} hours completed
                  </p>
                </div>

                <div>
                  <h4 className="font-bold text-gray-900 mb-4">Skills Assessment</h4>
                  <div className="space-y-4">
                    {Object.entries(SKILL_CATEGORIES).map(([category, config]) => (
                      <div key={category} className="p-4 bg-gray-50 rounded-xl">
                        <p className="font-semibold text-gray-900 mb-3">{config.label}</p>
                        <div className="space-y-2">
                          {config.skills.map(skill => (
                            <div key={skill} className="flex items-center justify-between">
                              <span className="text-sm text-gray-600">{skill}</span>
                              <div className="flex gap-1">
                                {[1, 2, 3, 4, 5].map(level => (
                                  <div 
                                    key={level}
                                    className={`w-4 h-4 rounded-full ${
                                      level <= 3 ? `bg-${config.color}-500` : "bg-gray-200"
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Message Drawer - Mobile-friendly using vaul */}
      <BottomDrawer
        open={showMessageModal && !!selectedStudent}
        onOpenChange={(open) => !open && setShowMessageModal(false)}
        title="Send Message"
        description={`To: ${selectedStudent?.full_name || ''}`}
      >
        <textarea
          value={messageText}
          onChange={(e) => setMessageText(e.target.value)}
          placeholder="Type your message..."
          rows={5}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed] resize-none mb-4"
        />

        <div className="flex gap-3">
          <button
            onClick={() => setShowMessageModal(false)}
            className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
          >
            Cancel
          </button>
          <button
            onClick={sendMessage}
            disabled={!messageText.trim()}
            className="flex-1 px-4 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            Send
          </button>
        </div>
      </BottomDrawer>

      <AnimatePresence>
        {showBroadcastModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowBroadcastModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Broadcast Message</h3>
                  <p className="text-sm text-gray-600">
                    Send to {selectedStudentsForBroadcast.size || filteredStudents.length} student{(selectedStudentsForBroadcast.size || filteredStudents.length) !== 1 ? 's' : ''}
                  </p>
                </div>
                <button
                  onClick={() => setShowBroadcastModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="mb-4">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-sm font-semibold text-gray-700">Select Recipients</p>
                  <button
                    onClick={selectAllForBroadcast}
                    className="text-sm text-[#3b82c4] hover:text-[#2563a3] font-semibold"
                  >
                    {selectedStudentsForBroadcast.size === filteredStudents.length ? "Deselect All" : "Select All"}
                  </button>
                </div>
                <div className="max-h-48 overflow-y-auto border border-gray-200 rounded-xl p-2 space-y-1">
                  {filteredStudents.map(student => (
                    <label 
                      key={student.id}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedStudentsForBroadcast.has(student.id)}
                        onChange={() => toggleStudentForBroadcast(student.id)}
                        className="w-4 h-4 text-[#3b82c4] rounded"
                      />
                      <span className="text-sm text-gray-900">{student.full_name}</span>
                    </label>
                  ))}
                </div>
              </div>

              <textarea
                value={broadcastMessage}
                onChange={(e) => setBroadcastMessage(e.target.value)}
                placeholder="Type your broadcast message..."
                rows={5}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed] resize-none mb-4"
              />

              <div className="flex gap-3">
                <button
                  onClick={() => setShowBroadcastModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={sendBroadcast}
                  disabled={!broadcastMessage.trim()}
                  className="flex-1 px-4 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  Send Broadcast
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Notes Drawer - Mobile-friendly using vaul */}
      <BottomDrawer
        open={showNotesModal && !!selectedStudent}
        onOpenChange={(open) => !open && setShowNotesModal(false)}
        title="Add Note"
        description={`For: ${selectedStudent?.full_name || ''}`}
      >
        <textarea
          value={studentNote}
          onChange={(e) => setStudentNote(e.target.value)}
          placeholder="Enter your note about this student..."
          rows={5}
          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#a9d5ed] resize-none mb-4"
        />

        <div className="flex gap-3">
          <button
            onClick={() => setShowNotesModal(false)}
            className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
          >
            Cancel
          </button>
          <button
            onClick={submitNote}
            disabled={!studentNote.trim() || createNoteMutation.isPending}
            className="flex-1 px-4 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {createNoteMutation.isPending ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <FileText className="w-4 h-4" />
                Save Note
              </>
            )}
          </button>
        </div>
      </BottomDrawer>
    </div>
    </>
  );
}