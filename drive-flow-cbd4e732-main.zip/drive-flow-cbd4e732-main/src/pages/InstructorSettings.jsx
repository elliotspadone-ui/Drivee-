import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Award, 
  Bell, 
  Clock, 
  Shield, 
  Save, 
  Upload, 
  CheckCircle,
  ArrowLeft,
  Loader2,
  Camera,
  Globe,
  Car,
  FileText,
  AlertCircle,
  Eye,
  EyeOff,
  Lock,
  Key,
  Smartphone,
  Monitor,
  Moon,
  Sun,
  Palette,
  Volume2,
  VolumeX,
  Vibrate,
  MessageSquare,
  DollarSign,
  CreditCard,
  Building,
  Target,
  TrendingUp,
  Settings,
  ChevronRight,
  ChevronDown,
  X,
  Plus,
  Trash2,
  Edit,
  RefreshCw,
  LogOut,
  HelpCircle,
  Info,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Star,
  Briefcase,
  GraduationCap,
  Heart,
  Zap,
  Navigation
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format, differenceInDays } from "date-fns";
import { toast } from "sonner";

const AVAILABLE_LANGUAGES = [
  { code: "en", name: "English" },
  { code: "de", name: "German" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "it", name: "Italian" },
  { code: "pt", name: "Portuguese" },
  { code: "pl", name: "Polish" },
  { code: "tr", name: "Turkish" },
  { code: "ar", name: "Arabic" },
  { code: "ru", name: "Russian" }
];

const SPECIALTIES = [
  "Nervous Students",
  "Highway Driving",
  "Test Preparation",
  "City Driving",
  "Parking Maneuvers",
  "Night Driving",
  "Defensive Driving",
  "Manual Transmission",
  "Automatic Transmission",
  "Refresher Courses",
  "Senior Drivers",
  "Young Drivers",
  "Corporate Training"
];

const TEACHING_STYLES = [
  "Patient & Encouraging",
  "Structured & Methodical",
  "Adaptive & Flexible",
  "Confidence Building",
  "Test-Focused",
  "Safety-First"
];

export default function InstructorSettings() {
  const queryClient = useQueryClient();
  
  const [currentUser, setCurrentUser] = useState(null);
  const [instructor, setInstructor] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("profile");
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showDeleteAccountModal, setShowDeleteAccountModal] = useState(false);
  const [expandedSections, setExpandedSections] = useState(new Set(["personal", "professional"]));

  const [profileData, setProfileData] = useState({
    fullName: "",
    phone: "",
    alternatePhone: "",
    bio: "",
    dateOfBirth: "",
    address: "",
    city: "",
    postalCode: "",
    emergencyContact: "",
    emergencyPhone: "",
    languages: [],
    specialties: [],
    teachingStyles: [],
    yearsExperience: 0,
    hourlyRate: 0,
    serviceRadius: 10
  });

  const [notificationPrefs, setNotificationPrefs] = useState({
    pushEnabled: true,
    emailEnabled: true,
    smsEnabled: false,
    lessonReminders: true,
    reminderTiming: "1hour",
    newBookings: true,
    bookingChanges: true,
    cancellations: true,
    studentMessages: true,
    earnings: true,
    weeklyReport: true,
    monthlyReport: true,
    reviews: true,
    achievements: true,
    systemUpdates: true,
    marketing: false,
    quietHoursEnabled: true,
    quietStart: "22:00",
    quietEnd: "07:00",
    weekendQuiet: false,
    soundEnabled: true,
    vibrationEnabled: true
  });

  const [availabilityPrefs, setAvailabilityPrefs] = useState({
    acceptNewStudents: true,
    allowBackToBack: true,
    minBreakBetweenLessons: 15,
    maxLessonsPerDay: 8,
    bufferBeforeLesson: 10,
    bufferAfterLesson: 5,
    allowSameDayBookings: true,
    sameDayLeadTime: 2,
    maxAdvanceBookingDays: 30,
    autoConfirmRegulars: true,
    requireDeposit: false,
    depositAmount: 0,
    cancellationPolicy: "24hours",
    lateCancellationFee: 50,
    noShowFee: 100,
    availableForTheory: false,
    availableForWeekends: true,
    availableForEvenings: true,
    preferredAreas: [],
    maxTravelDistance: 15
  });

  const [appearancePrefs, setAppearancePrefs] = useState({
    theme: "system",
    compactMode: false,
    showEarnings: true,
    defaultCalendarView: "week",
    startOfWeek: "monday",
    timeFormat: "24h",
    dateFormat: "dd/MM/yyyy",
    currency: "EUR"
  });

  const [securitySettings, setSecuritySettings] = useState({
    twoFactorEnabled: false,
    sessionTimeout: 30,
    loginNotifications: true,
    trustedDevices: []
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });

  const [certifications, setCertifications] = useState([
    { 
      id: "1",
      name: "Driving Instructor License",
      number: "DI-12345-2015",
      issuedDate: "2015-06-15",
      expiryDate: "2025-12-31",
      status: "valid",
      documentUrl: null
    },
    { 
      id: "2",
      name: "Category B (Car) Certification",
      number: "CAT-B-2015",
      issuedDate: "2015-06-15",
      status: "valid",
      documentUrl: null
    },
    { 
      id: "3",
      name: "First Aid Certificate",
      issuedDate: "2023-01-15",
      expiryDate: "2025-01-15",
      status: "valid",
      documentUrl: null
    },
    { 
      id: "4",
      name: "Background Check",
      issuedDate: "2024-01-15",
      expiryDate: "2027-01-15",
      status: "valid",
      documentUrl: null
    }
  ]);

  const [newArea, setNewArea] = useState("");

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        const user = await base44.auth.me();
        setCurrentUser(user);
        
        const instructors = await base44.entities.Instructor.filter({ email: user.email });
        if (instructors.length > 0) {
          const inst = instructors[0];
          setInstructor(inst);
          
          setProfileData({
            fullName: user.full_name || "",
            phone: inst.phone || "",
            alternatePhone: inst.alternate_phone || "",
            bio: inst.bio || "",
            dateOfBirth: inst.date_of_birth || "",
            address: inst.address || "",
            city: inst.city || "",
            postalCode: inst.postal_code || "",
            emergencyContact: inst.emergency_contact || "",
            emergencyPhone: inst.emergency_phone || "",
            languages: inst.languages || [],
            specialties: inst.specialties || [],
            teachingStyles: inst.teaching_styles || [],
            yearsExperience: inst.years_experience || 0,
            hourlyRate: inst.hourly_rate || 0,
            serviceRadius: inst.service_radius || 10
          });

          if (inst.notification_preferences) {
            setNotificationPrefs(prev => ({ ...prev, ...inst.notification_preferences }));
          }
          
          if (inst.availability_preferences) {
            setAvailabilityPrefs(prev => ({ ...prev, ...inst.availability_preferences }));
          }

          if (inst.appearance_preferences) {
            setAppearancePrefs(prev => ({ ...prev, ...inst.appearance_preferences }));
          }

          if (inst.certifications) {
            setCertifications(inst.certifications);
          }
        }
      } catch (error) {
        console.error("Error loading user data:", error);
        toast.error("Failed to load settings");
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, []);

  const updateInstructorMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Instructor.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructor'] });
      toast.success("Settings saved successfully");
    },
    onError: () => {
      toast.error("Failed to save settings");
    }
  });

  const updateUserMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.auth.updateMe(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
    onError: () => {
      toast.error("Failed to update user");
    }
  });

  const handleSaveProfile = () => {
    if (instructor) {
      updateInstructorMutation.mutate({
        id: instructor.id,
        data: {
          phone: profileData.phone,
          alternate_phone: profileData.alternatePhone,
          bio: profileData.bio,
          date_of_birth: profileData.dateOfBirth,
          address: profileData.address,
          city: profileData.city,
          postal_code: profileData.postalCode,
          emergency_contact: profileData.emergencyContact,
          emergency_phone: profileData.emergencyPhone,
          languages: profileData.languages,
          specialties: profileData.specialties,
          teaching_styles: profileData.teachingStyles,
          years_experience: profileData.yearsExperience,
          hourly_rate: profileData.hourlyRate,
          service_radius: profileData.serviceRadius
        }
      });
    }
    
    if (currentUser && profileData.fullName !== currentUser.full_name) {
      updateUserMutation.mutate({ full_name: profileData.fullName });
    }
  };

  const handleSaveNotifications = () => {
    if (instructor) {
      updateInstructorMutation.mutate({
        id: instructor.id,
        data: { notification_preferences: notificationPrefs }
      });
    }
  };

  const handleSaveAvailability = () => {
    if (instructor) {
      updateInstructorMutation.mutate({
        id: instructor.id,
        data: { availability_preferences: availabilityPrefs }
      });
    }
  };

  const handleSaveAppearance = () => {
    if (instructor) {
      updateInstructorMutation.mutate({
        id: instructor.id,
        data: { appearance_preferences: appearancePrefs }
      });
    }
  };

  const handleSaveCertifications = () => {
    if (instructor) {
      updateInstructorMutation.mutate({
        id: instructor.id,
        data: { certifications }
      });
    }
  };

  const handleChangePassword = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    if (passwordData.newPassword.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    toast.success("Password changed successfully");
    setShowPasswordModal(false);
    setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" });
  };

  const toggleLanguage = (lang) => {
    setProfileData(prev => ({
      ...prev,
      languages: prev.languages.includes(lang)
        ? prev.languages.filter(l => l !== lang)
        : [...prev.languages, lang]
    }));
  };

  const toggleSpecialty = (spec) => {
    setProfileData(prev => ({
      ...prev,
      specialties: prev.specialties.includes(spec)
        ? prev.specialties.filter(s => s !== spec)
        : [...prev.specialties, spec]
    }));
  };

  const toggleTeachingStyle = (style) => {
    setProfileData(prev => ({
      ...prev,
      teachingStyles: prev.teachingStyles.includes(style)
        ? prev.teachingStyles.filter(s => s !== style)
        : [...prev.teachingStyles, style]
    }));
  };

  const addPreferredArea = () => {
    if (newArea.trim() && !availabilityPrefs.preferredAreas.includes(newArea.trim())) {
      setAvailabilityPrefs(prev => ({
        ...prev,
        preferredAreas: [...prev.preferredAreas, newArea.trim()]
      }));
      setNewArea("");
    }
  };

  const removePreferredArea = (area) => {
    setAvailabilityPrefs(prev => ({
      ...prev,
      preferredAreas: prev.preferredAreas.filter(a => a !== area)
    }));
  };

  const toggleSection = (section) => {
    setExpandedSections(prev => {
      const next = new Set(prev);
      if (next.has(section)) {
        next.delete(section);
      } else {
        next.add(section);
      }
      return next;
    });
  };

  const getCertificationStatus = (cert) => {
    if (!cert.expiryDate) return { status: "valid", color: "green", label: "Valid" };
    
    const daysUntilExpiry = differenceInDays(new Date(cert.expiryDate), new Date());
    
    if (daysUntilExpiry < 0) return { status: "expired", color: "red", label: "Expired" };
    if (daysUntilExpiry <= 30) return { status: "expiring", color: "amber", label: `Expires in ${daysUntilExpiry} days` };
    if (daysUntilExpiry <= 90) return { status: "warning", color: "yellow", label: `Expires in ${daysUntilExpiry} days` };
    return { status: "valid", color: "green", label: "Valid" };
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Link
          to={createPageUrl("InstructorDashboard")}
          className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>

        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600 mt-1">Manage your profile, preferences, and account settings</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-2xl border border-gray-200 p-2 shadow-sm overflow-x-auto"
      >
        <div className="flex gap-1 min-w-max">
          {[
            { id: "profile", label: "Profile", icon: User },
            { id: "certifications", label: "Certifications", icon: Award },
            { id: "notifications", label: "Notifications", icon: Bell },
            { id: "availability", label: "Availability", icon: Clock },
            { id: "appearance", label: "Appearance", icon: Palette },
            { id: "security", label: "Security", icon: Shield }
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm whitespace-nowrap transition ${
                activeTab === id
                  ? "bg-indigo-600 text-white"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>
      </motion.div>

      <AnimatePresence mode="wait">
        {activeTab === "profile" && (
          <motion.div
            key="profile"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <button
                onClick={() => toggleSection("personal")}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <User className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">Personal Information</h3>
                    <p className="text-sm text-gray-600">Your basic contact details</p>
                  </div>
                </div>
                {expandedSections.has("personal") ? (
                  <ChevronDown className="w-5 h-5 text-gray-400" />
                ) : (
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                )}
              </button>

              <AnimatePresence>
                {expandedSections.has("personal") && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-6 space-y-4 border-t border-gray-200 pt-4">
                      <div className="flex items-center gap-6">
                        <div className="w-24 h-24 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center">
                          <span className="text-white font-bold text-3xl">
                            {profileData.fullName?.charAt(0) || "I"}
                          </span>
                        </div>
                        <div>
                          <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition flex items-center gap-2">
                            <Camera className="w-4 h-4" />
                            Upload Photo
                          </button>
                          <p className="text-xs text-gray-500 mt-2">JPG, PNG or GIF (max 2MB)</p>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                          <input
                            type="text"
                            value={profileData.fullName}
                            onChange={(e) => setProfileData({ ...profileData, fullName: e.target.value })}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                          <input
                            type="email"
                            value={currentUser?.email || ""}
                            disabled
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl bg-gray-50 text-gray-500"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                          <input
                            type="tel"
                            value={profileData.phone}
                            onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Alternate Phone</label>
                          <input
                            type="tel"
                            value={profileData.alternatePhone}
                            onChange={(e) => setProfileData({ ...profileData, alternatePhone: e.target.value })}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Date of Birth</label>
                          <input
                            type="date"
                            value={profileData.dateOfBirth}
                            onChange={(e) => setProfileData({ ...profileData, dateOfBirth: e.target.value })}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">City</label>
                          <input
                            type="text"
                            value={profileData.city}
                            onChange={(e) => setProfileData({ ...profileData, city: e.target.value })}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Address</label>
                        <input
                          type="text"
                          value={profileData.address}
                          onChange={(e) => setProfileData({ ...profileData, address: e.target.value })}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Emergency Contact Name</label>
                          <input
                            type="text"
                            value={profileData.emergencyContact}
                            onChange={(e) => setProfileData({ ...profileData, emergencyContact: e.target.value })}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Emergency Contact Phone</label>
                          <input
                            type="tel"
                            value={profileData.emergencyPhone}
                            onChange={(e) => setProfileData({ ...profileData, emergencyPhone: e.target.value })}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          />
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
              <button
                onClick={() => toggleSection("professional")}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Briefcase className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">Professional Profile</h3>
                    <p className="text-sm text-gray-600">Your teaching experience and expertise</p>
                  </div>
                </div>
                {expandedSections.has("professional") ? (
                  <ChevronDown className="w-5 h-5 text-gray-400" />
                ) : (
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                )}
              </button>

              <AnimatePresence>
                {expandedSections.has("professional") && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-6 space-y-4 border-t border-gray-200 pt-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Bio & Teaching Philosophy</label>
                        <textarea
                          value={profileData.bio}
                          onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                          rows={4}
                          placeholder="Tell students about your experience and teaching style..."
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                        />
                      </div>

                      <div className="grid md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Years of Experience</label>
                          <input
                            type="number"
                            value={profileData.yearsExperience}
                            onChange={(e) => setProfileData({ ...profileData, yearsExperience: parseInt(e.target.value) || 0 })}
                            min="0"
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Hourly Rate (€)</label>
                          <input
                            type="number"
                            value={profileData.hourlyRate}
                            onChange={(e) => setProfileData({ ...profileData, hourlyRate: parseInt(e.target.value) || 0 })}
                            min="0"
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Service Radius (km)</label>
                          <input
                            type="number"
                            value={profileData.serviceRadius}
                            onChange={(e) => setProfileData({ ...profileData, serviceRadius: parseInt(e.target.value) || 0 })}
                            min="0"
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">Languages Spoken</label>
                        <div className="flex flex-wrap gap-2">
                          {AVAILABLE_LANGUAGES.map((lang) => (
                            <button
                              key={lang.code}
                              onClick={() => toggleLanguage(lang.name)}
                              className={`px-4 py-2 rounded-xl text-sm font-semibold transition flex items-center gap-2 ${
                                profileData.languages.includes(lang.name)
                                  ? "bg-indigo-600 text-white"
                                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                              }`}
                            >
                              {profileData.languages.includes(lang.name) && <CheckCircle className="w-4 h-4" />}
                              {lang.name}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">Specialties</label>
                        <div className="flex flex-wrap gap-2">
                          {SPECIALTIES.map((spec) => (
                            <button
                              key={spec}
                              onClick={() => toggleSpecialty(spec)}
                              className={`px-4 py-2 rounded-xl text-sm font-semibold transition flex items-center gap-2 ${
                                profileData.specialties.includes(spec)
                                  ? "bg-purple-600 text-white"
                                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                              }`}
                            >
                              {profileData.specialties.includes(spec) && <CheckCircle className="w-4 h-4" />}
                              {spec}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">Teaching Style</label>
                        <div className="flex flex-wrap gap-2">
                          {TEACHING_STYLES.map((style) => (
                            <button
                              key={style}
                              onClick={() => toggleTeachingStyle(style)}
                              className={`px-4 py-2 rounded-xl text-sm font-semibold transition flex items-center gap-2 ${
                                profileData.teachingStyles.includes(style)
                                  ? "bg-green-600 text-white"
                                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                              }`}
                            >
                              {profileData.teachingStyles.includes(style) && <CheckCircle className="w-4 h-4" />}
                              {style}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleSaveProfile}
                disabled={updateInstructorMutation.isPending || updateUserMutation.isPending}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center gap-2 disabled:opacity-50"
              >
                {(updateInstructorMutation.isPending || updateUserMutation.isPending) ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                Save Profile
              </button>
            </div>
          </motion.div>
        )}

        {activeTab === "certifications" && (
          <motion.div
            key="certifications"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Certifications & Licenses</h3>
                <p className="text-sm text-gray-600">Keep your documents up to date</p>
              </div>
              <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold text-sm transition flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add Certification
              </button>
            </div>

            <div className="space-y-4">
              {certifications.map((cert) => {
                const statusInfo = getCertificationStatus(cert);
                
                return (
                  <div key={cert.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 bg-${statusInfo.color}-100 rounded-xl flex items-center justify-center`}>
                        {statusInfo.status === "valid" ? (
                          <CheckCircle2 className={`w-6 h-6 text-${statusInfo.color}-600`} />
                        ) : statusInfo.status === "expired" ? (
                          <XCircle className={`w-6 h-6 text-${statusInfo.color}-600`} />
                        ) : (
                          <AlertTriangle className={`w-6 h-6 text-${statusInfo.color}-600`} />
                        )}
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">{cert.name}</p>
                        {cert.number && <p className="text-sm text-gray-600">{cert.number}</p>}
                        <div className="flex items-center gap-2 mt-1">
                          {cert.issuedDate && (
                            <span className="text-xs text-gray-500">
                              Issued: {format(new Date(cert.issuedDate), "MMM d, yyyy")}
                            </span>
                          )}
                          {cert.expiryDate && (
                            <span className={`text-xs text-${statusInfo.color}-600 font-semibold`}>
                              • {statusInfo.label}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="px-4 py-2 bg-white hover:bg-gray-100 border border-gray-200 rounded-xl text-sm font-semibold transition flex items-center gap-2">
                        <Upload className="w-4 h-4" />
                        Upload
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition">
                        <Trash2 className="w-4 h-4 text-gray-400" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end mt-6">
              <button
                onClick={handleSaveCertifications}
                disabled={updateInstructorMutation.isPending}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center gap-2 disabled:opacity-50"
              >
                {updateInstructorMutation.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                Save Certifications
              </button>
            </div>
          </motion.div>
        )}

        {activeTab === "notifications" && (
          <motion.div
            key="notifications"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Notification Channels</h3>
              
              <div className="space-y-4">
                {[
                  { key: "pushEnabled", label: "Push Notifications", desc: "Receive notifications on your device", icon: Smartphone },
                  { key: "emailEnabled", label: "Email Notifications", desc: "Receive notifications via email", icon: Mail },
                  { key: "smsEnabled", label: "SMS Notifications", desc: "Receive text message alerts", icon: MessageSquare }
                ].map(({ key, label, desc, icon: Icon }) => (
                  <label key={key} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer">
                    <div className="flex items-center gap-3">
                      <Icon className="w-5 h-5 text-gray-600" />
                      <div>
                        <p className="font-semibold text-gray-900">{label}</p>
                        <p className="text-sm text-gray-600">{desc}</p>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={notificationPrefs[key]}
                      onChange={(e) => setNotificationPrefs({ ...notificationPrefs, [key]: e.target.checked })}
                      className="w-6 h-6 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                  </label>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Lesson Notifications</h3>
              
              <div className="space-y-3">
                {[
                  { key: "lessonReminders", label: "Lesson Reminders" },
                  { key: "newBookings", label: "New Booking Alerts" },
                  { key: "bookingChanges", label: "Booking Changes" },
                  { key: "cancellations", label: "Cancellation Alerts" },
                  { key: "studentMessages", label: "Student Messages" }
                ].map(({ key, label }) => (
                  <label key={key} className="flex items-center justify-between py-2">
                    <span className="text-gray-700">{label}</span>
                    <input
                      type="checkbox"
                      checked={notificationPrefs[key]}
                      onChange={(e) => setNotificationPrefs({ ...notificationPrefs, [key]: e.target.checked })}
                      className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                  </label>
                ))}

                {notificationPrefs.lessonReminders && (
                  <div className="mt-4 p-4 bg-gray-50 rounded-xl">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Reminder Timing</label>
                    <select
                      value={notificationPrefs.reminderTiming}
                      onChange={(e) => setNotificationPrefs({ ...notificationPrefs, reminderTiming: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    >
                      <option value="15min">15 minutes before</option>
                      <option value="30min">30 minutes before</option>
                      <option value="1hour">1 hour before</option>
                      <option value="2hours">2 hours before</option>
                      <option value="1day">1 day before</option>
                    </select>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Performance & Reports</h3>
              
              <div className="space-y-3">
                {[
                  { key: "earnings", label: "Earnings Updates" },
                  { key: "weeklyReport", label: "Weekly Performance Report" },
                  { key: "monthlyReport", label: "Monthly Summary" },
                  { key: "reviews", label: "New Student Reviews" },
                  { key: "achievements", label: "Achievement Unlocked" }
                ].map(({ key, label }) => (
                  <label key={key} className="flex items-center justify-between py-2">
                    <span className="text-gray-700">{label}</span>
                    <input
                      type="checkbox"
                      checked={notificationPrefs[key]}
                      onChange={(e) => setNotificationPrefs({ ...notificationPrefs, [key]: e.target.checked })}
                      className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                  </label>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Quiet Hours</h3>
              
              <label className="flex items-center gap-3 mb-4">
                <input
                  type="checkbox"
                  checked={notificationPrefs.quietHoursEnabled}
                  onChange={(e) => setNotificationPrefs({ ...notificationPrefs, quietHoursEnabled: e.target.checked })}
                  className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-gray-700">Enable quiet hours (no notifications)</span>
              </label>

              {notificationPrefs.quietHoursEnabled && (
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="block text-sm text-gray-600 mb-2">From</label>
                    <input
                      type="time"
                      value={notificationPrefs.quietStart}
                      onChange={(e) => setNotificationPrefs({ ...notificationPrefs, quietStart: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600 mb-2">To</label>
                    <input
                      type="time"
                      value={notificationPrefs.quietEnd}
                      onChange={(e) => setNotificationPrefs({ ...notificationPrefs, quietEnd: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleSaveNotifications}
                disabled={updateInstructorMutation.isPending}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center gap-2 disabled:opacity-50"
              >
                {updateInstructorMutation.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                Save Notifications
              </button>
            </div>
          </motion.div>
        )}

        {activeTab === "availability" && (
          <motion.div
            key="availability"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Booking Rules</h3>
              
              <div className="space-y-4">
                {[
                  { key: "acceptNewStudents", label: "Accept new students", desc: "Allow new students to book with you" },
                  { key: "allowBackToBack", label: "Allow back-to-back lessons", desc: "Book lessons without breaks between them" },
                  { key: "allowSameDayBookings", label: "Allow same-day bookings", desc: "Students can book lessons for today" },
                  { key: "autoConfirmRegulars", label: "Auto-confirm regular students", desc: "Automatically confirm bookings from returning students" }
                ].map(({ key, label, desc }) => (
                  <label key={key} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer">
                    <div>
                      <p className="font-semibold text-gray-900">{label}</p>
                      <p className="text-sm text-gray-600">{desc}</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={availabilityPrefs[key]}
                      onChange={(e) => setAvailabilityPrefs({ ...availabilityPrefs, [key]: e.target.checked })}
                      className="w-6 h-6 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                  </label>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Time Settings</h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Min break between lessons (min)</label>
                  <input
                    type="number"
                    value={availabilityPrefs.minBreakBetweenLessons}
                    onChange={(e) => setAvailabilityPrefs({ ...availabilityPrefs, minBreakBetweenLessons: parseInt(e.target.value) || 0 })}
                    min="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Max lessons per day</label>
                  <input
                    type="number"
                    value={availabilityPrefs.maxLessonsPerDay}
                    onChange={(e) => setAvailabilityPrefs({ ...availabilityPrefs, maxLessonsPerDay: parseInt(e.target.value) || 0 })}
                    min="1"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Same-day lead time (hours)</label>
                  <input
                    type="number"
                    value={availabilityPrefs.sameDayLeadTime}
                    onChange={(e) => setAvailabilityPrefs({ ...availabilityPrefs, sameDayLeadTime: parseInt(e.target.value) || 0 })}
                    min="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Max advance booking (days)</label>
                  <input
                    type="number"
                    value={availabilityPrefs.maxAdvanceBookingDays}
                    onChange={(e) => setAvailabilityPrefs({ ...availabilityPrefs, maxAdvanceBookingDays: parseInt(e.target.value) || 0 })}
                    min="1"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Service Areas</h3>
              
              <div className="flex gap-2 mb-4">
                <input
                  type="text"
                  value={newArea}
                  onChange={(e) => setNewArea(e.target.value)}
                  placeholder="Add a preferred area..."
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  onKeyPress={(e) => e.key === "Enter" && addPreferredArea()}
                />
                <button
                  onClick={addPreferredArea}
                  className="px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition"
                >
                  Add
                </button>
              </div>

              {availabilityPrefs.preferredAreas.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {availabilityPrefs.preferredAreas.map((area) => (
                    <span
                      key={area}
                      className="px-4 py-2 bg-gray-100 rounded-full text-sm font-semibold text-gray-700 flex items-center gap-2"
                    >
                      <MapPin className="w-4 h-4" />
                      {area}
                      <button
                        onClick={() => removePreferredArea(area)}
                        className="ml-1 hover:text-red-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </span>
                  ))}
                </div>
              )}

              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Maximum travel distance (km)</label>
                <input
                  type="number"
                  value={availabilityPrefs.maxTravelDistance}
                  onChange={(e) => setAvailabilityPrefs({ ...availabilityPrefs, maxTravelDistance: parseInt(e.target.value) || 0 })}
                  min="0"
                  className="w-full md:w-48 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                />
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Cancellation Policy</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Cancellation Notice Required</label>
                  <select
                    value={availabilityPrefs.cancellationPolicy}
                    onChange={(e) => setAvailabilityPrefs({ ...availabilityPrefs, cancellationPolicy: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  >
                    <option value="2hours">2 hours</option>
                    <option value="6hours">6 hours</option>
                    <option value="12hours">12 hours</option>
                    <option value="24hours">24 hours</option>
                    <option value="48hours">48 hours</option>
                  </select>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Late cancellation fee (%)</label>
                    <input
                      type="number"
                      value={availabilityPrefs.lateCancellationFee}
                      onChange={(e) => setAvailabilityPrefs({ ...availabilityPrefs, lateCancellationFee: parseInt(e.target.value) || 0 })}
                      min="0"
                      max="100"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">No-show fee (%)</label>
                    <input
                      type="number"
                      value={availabilityPrefs.noShowFee}
                      onChange={(e) => setAvailabilityPrefs({ ...availabilityPrefs, noShowFee: parseInt(e.target.value) || 0 })}
                      min="0"
                      max="100"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleSaveAvailability}
                disabled={updateInstructorMutation.isPending}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center gap-2 disabled:opacity-50"
              >
                {updateInstructorMutation.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                Save Availability
              </button>
            </div>
          </motion.div>
        )}

        {activeTab === "appearance" && (
          <motion.div
            key="appearance"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
          >
            <h3 className="text-lg font-bold text-gray-900 mb-6">Display Preferences</h3>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Theme</label>
                <div className="flex gap-3">
                  {[
                    { value: "light", label: "Light", icon: Sun },
                    { value: "dark", label: "Dark", icon: Moon },
                    { value: "system", label: "System", icon: Monitor }
                  ].map(({ value, label, icon: Icon }) => (
                    <button
                      key={value}
                      onClick={() => setAppearancePrefs({ ...appearancePrefs, theme: value })}
                      className={`flex-1 p-4 rounded-xl border-2 transition flex flex-col items-center gap-2 ${
                        appearancePrefs.theme === value
                          ? "border-indigo-500 bg-indigo-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <Icon className="w-6 h-6 text-gray-600" />
                      <span className="text-sm font-semibold text-gray-900">{label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Default Calendar View</label>
                  <select
                    value={appearancePrefs.defaultCalendarView}
                    onChange={(e) => setAppearancePrefs({ ...appearancePrefs, defaultCalendarView: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  >
                    <option value="day">Day</option>
                    <option value="week">Week</option>
                    <option value="month">Month</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Start of Week</label>
                  <select
                    value={appearancePrefs.startOfWeek}
                    onChange={(e) => setAppearancePrefs({ ...appearancePrefs, startOfWeek: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  >
                    <option value="sunday">Sunday</option>
                    <option value="monday">Monday</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Time Format</label>
                  <select
                    value={appearancePrefs.timeFormat}
                    onChange={(e) => setAppearancePrefs({ ...appearancePrefs, timeFormat: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  >
                    <option value="12h">12 hour (AM/PM)</option>
                    <option value="24h">24 hour</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Currency</label>
                  <select
                    value={appearancePrefs.currency}
                    onChange={(e) => setAppearancePrefs({ ...appearancePrefs, currency: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  >
                    <option value="EUR">Euro (€)</option>
                    <option value="GBP">Pound (£)</option>
                    <option value="USD">Dollar ($)</option>
                    <option value="CHF">Swiss Franc (CHF)</option>
                  </select>
                </div>
              </div>

              <div className="space-y-3">
                <label className="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer">
                  <div>
                    <p className="font-semibold text-gray-900">Compact Mode</p>
                    <p className="text-sm text-gray-600">Show more information in less space</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={appearancePrefs.compactMode}
                    onChange={(e) => setAppearancePrefs({ ...appearancePrefs, compactMode: e.target.checked })}
                    className="w-6 h-6 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                </label>

                <label className="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer">
                  <div>
                    <p className="font-semibold text-gray-900">Show Earnings</p>
                    <p className="text-sm text-gray-600">Display earnings information on dashboard</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={appearancePrefs.showEarnings}
                    onChange={(e) => setAppearancePrefs({ ...appearancePrefs, showEarnings: e.target.checked })}
                    className="w-6 h-6 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                </label>
              </div>
            </div>

            <div className="flex justify-end mt-6">
              <button
                onClick={handleSaveAppearance}
                disabled={updateInstructorMutation.isPending}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center gap-2 disabled:opacity-50"
              >
                {updateInstructorMutation.isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                Save Appearance
              </button>
            </div>
          </motion.div>
        )}

        {activeTab === "security" && (
          <motion.div
            key="security"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Password & Authentication</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Lock className="w-5 h-5 text-gray-600" />
                    <div>
                      <p className="font-semibold text-gray-900">Password</p>
                      <p className="text-sm text-gray-600">Last changed 30 days ago</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowPasswordModal(true)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold text-sm transition"
                  >
                    Change Password
                  </button>
                </div>

                <label className="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Key className="w-5 h-5 text-gray-600" />
                    <div>
                      <p className="font-semibold text-gray-900">Two-Factor Authentication</p>
                      <p className="text-sm text-gray-600">Add an extra layer of security</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={securitySettings.twoFactorEnabled}
                    onChange={(e) => setSecuritySettings({ ...securitySettings, twoFactorEnabled: e.target.checked })}
                    className="w-6 h-6 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                </label>

                <label className="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Bell className="w-5 h-5 text-gray-600" />
                    <div>
                      <p className="font-semibold text-gray-900">Login Notifications</p>
                      <p className="text-sm text-gray-600">Get notified of new login attempts</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={securitySettings.loginNotifications}
                    onChange={(e) => setSecuritySettings({ ...securitySettings, loginNotifications: e.target.checked })}
                    className="w-6 h-6 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                </label>

                <div className="p-4 bg-gray-50 rounded-xl">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Session Timeout (minutes)</label>
                  <select
                    value={securitySettings.sessionTimeout}
                    onChange={(e) => setSecuritySettings({ ...securitySettings, sessionTimeout: parseInt(e.target.value) })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  >
                    <option value={15}>15 minutes</option>
                    <option value={30}>30 minutes</option>
                    <option value={60}>1 hour</option>
                    <option value={120}>2 hours</option>
                    <option value={0}>Never</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Account Actions</h3>
              
              <div className="space-y-4">
                <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition text-left">
                  <div className="flex items-center gap-3">
                    <RefreshCw className="w-5 h-5 text-gray-600" />
                    <div>
                      <p className="font-semibold text-gray-900">Export My Data</p>
                      <p className="text-sm text-gray-600">Download a copy of your data</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>

                <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition text-left">
                  <div className="flex items-center gap-3">
                    <LogOut className="w-5 h-5 text-gray-600" />
                    <div>
                      <p className="font-semibold text-gray-900">Sign Out Everywhere</p>
                      <p className="text-sm text-gray-600">Log out from all devices</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>

                <button
                  onClick={() => setShowDeleteAccountModal(true)}
                  className="w-full flex items-center justify-between p-4 bg-red-50 rounded-xl hover:bg-red-100 transition text-left"
                >
                  <div className="flex items-center gap-3">
                    <Trash2 className="w-5 h-5 text-red-600" />
                    <div>
                      <p className="font-semibold text-red-900">Delete Account</p>
                      <p className="text-sm text-red-700">Permanently delete your account and data</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-red-400" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showPasswordModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowPasswordModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Change Password</h3>
                <button
                  onClick={() => setShowPasswordModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Current Password</label>
                  <input
                    type="password"
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">New Password</label>
                  <input
                    type="password"
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Confirm New Password</label>
                  <input
                    type="password"
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => setShowPasswordModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleChangePassword}
                  className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition"
                >
                  Change Password
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showDeleteAccountModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowDeleteAccountModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertTriangle className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Delete Account?</h3>
                <p className="text-gray-600">
                  This action cannot be undone. All your data, including lessons, students, and earnings history will be permanently deleted.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowDeleteAccountModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    toast.error("Account deletion requires admin approval");
                    setShowDeleteAccountModal(false);
                  }}
                  className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold transition"
                >
                  Delete Account
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}