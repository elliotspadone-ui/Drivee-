import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  MessageCircle,
  Send,
  Search,
  Phone,
  Video,
  MoreVertical,
  Paperclip,
  Image,
  Smile,
  Check,
  CheckCheck,
  Clock,
  Archive,
  Star,
  Trash2,
  Bell,
  BellOff,
  Pin,
  Users,
  Settings,
  Filter,
  ChevronDown,
  X,
  File,
  Download,
  Reply,
  Forward,
  Copy,
  AlertCircle,
  Mic,
  MicOff,
  Camera,
  PhoneOff,
  Maximize2,
  Minimize2,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format, isToday, isYesterday, isThisWeek, formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

const TYPING_TIMEOUT = 3000;
const MESSAGE_BATCH_SIZE = 50;

const getInitials = (name) => {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
};

const formatMessageTime = (date) => {
  if (isToday(date)) {
    return format(date, "HH:mm");
  }
  if (isYesterday(date)) {
    return "Yesterday";
  }
  if (isThisWeek(date)) {
    return format(date, "EEEE");
  }
  return format(date, "dd/MM/yyyy");
};

const formatMessageDate = (date) => {
  if (isToday(date)) {
    return "Today";
  }
  if (isYesterday(date)) {
    return "Yesterday";
  }
  return format(date, "MMMM d, yyyy");
};

const Avatar = React.memo(({ name, url, size = "md", isOnline }) => {
  const sizeClasses = {
    sm: "w-8 h-8 text-xs",
    md: "w-12 h-12 text-sm",
    lg: "w-16 h-16 text-lg",
  };

  return (
    <div className="relative">
      {url ? (
        <img
          src={url}
          alt={name}
          className={`${sizeClasses[size]} rounded-full object-cover`}
        />
      ) : (
        <div
          className={`${sizeClasses[size]} rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-white font-semibold`}
        >
          {getInitials(name)}
        </div>
      )}
      {isOnline !== undefined && (
        <div
          className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
            isOnline ? "bg-emerald-500" : "bg-zinc-400"
          }`}
        />
      )}
    </div>
  );
});

Avatar.displayName = "Avatar";

const MessageStatusIcon = React.memo(({ status }) => {
  switch (status) {
    case "sending":
      return <Clock className="w-4 h-4 text-zinc-400" />;
    case "sent":
      return <Check className="w-4 h-4 text-zinc-400" />;
    case "delivered":
      return <CheckCheck className="w-4 h-4 text-zinc-400" />;
    case "read":
      return <CheckCheck className="w-4 h-4 text-indigo-500" />;
    default:
      return null;
  }
});

MessageStatusIcon.displayName = "MessageStatusIcon";

const TypingIndicatorBubble = React.memo(({ names }) => {
  if (names.length === 0) return null;

  const text =
    names.length === 1
      ? `${names[0]} is typing...`
      : names.length === 2
      ? `${names[0]} and ${names[1]} are typing...`
      : `${names[0]} and ${names.length - 1} others are typing...`;

  return (
    <div className="flex items-center gap-2 text-sm text-zinc-500 px-4 py-2">
      <div className="flex gap-1">
        <span className="w-2 h-2 bg-zinc-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
        <span className="w-2 h-2 bg-zinc-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
        <span className="w-2 h-2 bg-zinc-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
      </div>
      <span>{text}</span>
    </div>
  );
});

TypingIndicatorBubble.displayName = "TypingIndicatorBubble";

const ConversationListItem = React.memo(({ conversation, currentUserId, isSelected, onSelect }) => {
  const otherParticipant = conversation.participants.find((p) => p.id !== currentUserId);
  const displayName = otherParticipant?.name || "Unknown";
  const displayAvatar = otherParticipant?.avatar;

  return (
    <motion.button
      whileHover={{ backgroundColor: "rgba(99, 102, 241, 0.05)" }}
      onClick={onSelect}
      className={`w-full p-4 flex items-start gap-3 border-b border-zinc-100 transition-colors ${
        isSelected ? "bg-indigo-50" : ""
      }`}
    >
      <Avatar name={displayName} url={displayAvatar} isOnline />
      <div className="flex-1 min-w-0 text-left">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            {conversation.is_pinned && <Pin className="w-3 h-3 text-indigo-500" />}
            <h3
              className={`font-semibold truncate ${
                conversation.unread_count > 0 ? "text-zinc-900" : "text-zinc-700"
              }`}
            >
              {displayName}
            </h3>
          </div>
          <span className="text-xs text-zinc-500 flex-shrink-0">
            {conversation.last_message
              ? formatMessageTime(new Date(conversation.last_message.created_at))
              : ""}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <p
            className={`text-sm truncate ${
              conversation.unread_count > 0 ? "text-zinc-800 font-medium" : "text-zinc-500"
            }`}
          >
            {conversation.last_message?.is_deleted
              ? "This message was deleted"
              : conversation.last_message?.content || "No messages yet"}
          </p>
          <div className="flex items-center gap-2 flex-shrink-0">
            {conversation.is_muted && <BellOff className="w-4 h-4 text-zinc-400" />}
            {conversation.unread_count > 0 && (
              <span className="min-w-[20px] h-5 px-1.5 bg-indigo-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                {conversation.unread_count > 99 ? "99+" : conversation.unread_count}
              </span>
            )}
          </div>
        </div>
      </div>
    </motion.button>
  );
});

ConversationListItem.displayName = "ConversationListItem";

const MessageBubble = React.memo(({ message, isOwn, showAvatar, onReply, onDelete, onCopy }) => {
  const [showActions, setShowActions] = useState(false);

  if (message.is_deleted) {
    return (
      <div className={`flex ${isOwn ? "justify-end" : "justify-start"} mb-2`}>
        <div className="px-4 py-2 rounded-2xl bg-zinc-100 text-zinc-500 text-sm italic">
          This message was deleted
        </div>
      </div>
    );
  }

  if (message.message_type === "system") {
    return (
      <div className="flex justify-center mb-4">
        <div className="px-4 py-2 rounded-full bg-zinc-100 text-zinc-600 text-xs">
          {message.content}
        </div>
      </div>
    );
  }

  return (
    <div
      className={`flex ${isOwn ? "justify-end" : "justify-start"} mb-2 group`}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      <div className={`flex items-end gap-2 max-w-[75%] ${isOwn ? "flex-row-reverse" : ""}`}>
        {!isOwn && showAvatar && (
          <Avatar name={message.sender_name} size="sm" />
        )}
        {!isOwn && !showAvatar && <div className="w-8" />}

        <div className="relative">
          {message.reply_to && (
            <div
              className={`mb-1 px-3 py-2 rounded-xl text-xs ${
                isOwn ? "bg-indigo-200/50" : "bg-zinc-200/50"
              }`}
            >
              <p className="font-medium text-zinc-700">{message.reply_to.sender_name}</p>
              <p className="text-zinc-500 truncate">{message.reply_to.content}</p>
            </div>
          )}

          <div
            className={`px-4 py-2.5 rounded-2xl ${
              isOwn
                ? "bg-gradient-to-r from-indigo-500 to-purple-500 text-white"
                : "bg-zinc-100 text-zinc-800"
            }`}
          >
            {message.attachments && message.attachments.length > 0 && (
              <div className="mb-2 space-y-2">
                {message.attachments.map((attachment) => (
                  <div
                    key={attachment.id}
                    className={`flex items-center gap-2 p-2 rounded-lg ${
                      isOwn ? "bg-white/20" : "bg-zinc-200"
                    }`}
                  >
                    {attachment.type.startsWith("image/") ? (
                      <img
                        src={attachment.url}
                        alt={attachment.name}
                        className="max-w-[200px] rounded-lg"
                      />
                    ) : (
                      <>
                        <File className="w-5 h-5" />
                        <span className="text-sm truncate flex-1">{attachment.name}</span>
                        <a
                          href={attachment.url}
                          download
                          className="p-1 rounded hover:bg-white/20"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}

            <p className="whitespace-pre-wrap break-words">{message.content}</p>

            <div
              className={`flex items-center justify-end gap-1 mt-1 text-xs ${
                isOwn ? "text-white/70" : "text-zinc-500"
              }`}
            >
              <span>{format(new Date(message.created_at), "HH:mm")}</span>
              {message.edited_at && <span>(edited)</span>}
              {isOwn && <MessageStatusIcon status={message.status} />}
            </div>
          </div>

          <AnimatePresence>
            {showActions && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className={`absolute top-0 ${
                  isOwn ? "right-full mr-2" : "left-full ml-2"
                } flex items-center gap-1 bg-white rounded-lg shadow-lg border border-zinc-200 p-1`}
              >
                <button
                  onClick={onReply}
                  className="p-1.5 rounded hover:bg-zinc-100 transition"
                  title="Reply"
                >
                  <Reply className="w-4 h-4 text-zinc-600" />
                </button>
                <button
                  onClick={onCopy}
                  className="p-1.5 rounded hover:bg-zinc-100 transition"
                  title="Copy"
                >
                  <Copy className="w-4 h-4 text-zinc-600" />
                </button>
                {isOwn && (
                  <button
                    onClick={onDelete}
                    className="p-1.5 rounded hover:bg-red-50 transition"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </button>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
});

MessageBubble.displayName = "MessageBubble";

const EmptyState = React.memo(({ icon, title, description, action }) => (
  <div className="flex-1 flex items-center justify-center p-8">
    <div className="text-center max-w-sm">
      <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-400">
        {icon}
      </div>
      <h3 className="text-lg font-semibold text-zinc-900 mb-2">{title}</h3>
      <p className="text-zinc-500 mb-4">{description}</p>
      {action && (
        <button
          onClick={action.onClick}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition"
        >
          {action.label}
        </button>
      )}
    </div>
  </div>
));

EmptyState.displayName = "EmptyState";

export default function Messages() {
  const queryClient = useQueryClient();
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  const [currentUser, setCurrentUser] = useState(null);
  const [student, setStudent] = useState(null);
  const [selectedConversationId, setSelectedConversationId] = useState(null);
  const [messageText, setMessageText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [showFilterMenu, setShowFilterMenu] = useState(false);
  const [replyingTo, setReplyingTo] = useState(null);
  const [typingUsers, setTypingUsers] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [showMobileChat, setShowMobileChat] = useState(false);
  const typingTimeoutRef = useRef(null);

  useEffect(() => {
    let isMounted = true;

    const loadUser = async () => {
      try {
        const user = await base44.auth.me();
        if (!isMounted) return;
        setCurrentUser(user);

        const students = await base44.entities.Student.filter({ email: user.email });
        if (isMounted && students.length > 0) {
          setStudent(students[0]);
        }
      } catch (error) {
        if (isMounted) {
          console.error("Failed to load user:", error);
          toast.error("Failed to load user data");
        }
      }
    };

    loadUser();

    return () => {
      isMounted = false;
    };
  }, []);

  const { data: conversations = [], isLoading: conversationsLoading } = useQuery({
    queryKey: ["conversations", student?.id],
    queryFn: async () => {
      if (!student) return [];
      try {
        return await base44.entities.Conversation.filter(
          { participant_ids: student.id },
          "-updated_at"
        );
      } catch {
        return generateMockConversations();
      }
    },
    enabled: !!student,
    staleTime: 30000,
  });

  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ["messages", selectedConversationId],
    queryFn: async () => {
      if (!selectedConversationId) return [];
      try {
        return await base44.entities.Message.filter(
          { conversation_id: selectedConversationId },
          "created_at"
        );
      } catch {
        return generateMockMessages(selectedConversationId);
      }
    },
    enabled: !!selectedConversationId,
    staleTime: 10000,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (data) => {
      return base44.entities.Message.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages", selectedConversationId] });
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
    },
    onError: () => {
      toast.error("Failed to send message");
    },
  });

  const deleteMessageMutation = useMutation({
    mutationFn: async (messageId) => {
      return base44.entities.Message.update(messageId, { is_deleted: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages", selectedConversationId] });
      toast.success("Message deleted");
    },
  });

  const updateConversationMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return base44.entities.Conversation.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
    },
  });

  const generateMockConversations = useCallback(() => {
    return [
      {
        id: "conv-1",
        participants: [
          { id: student?.id || "student-1", type: "student", name: student?.full_name || "You" },
          { id: "instructor-1", type: "instructor", name: "Michael Schmidt" },
        ],
        last_message: {
          id: "msg-3",
          conversation_id: "conv-1",
          sender_id: "instructor-1",
          sender_type: "instructor",
          sender_name: "Michael Schmidt",
          content: "See you tomorrow at 10 AM!",
          message_type: "text",
          status: "read",
          created_at: new Date().toISOString(),
          is_deleted: false,
        },
        unread_count: 2,
        is_pinned: true,
        is_muted: false,
        is_archived: false,
        created_at: new Date(Date.now() - 86400000 * 7).toISOString(),
        updated_at: new Date().toISOString(),
      },
      {
        id: "conv-2",
        participants: [
          { id: student?.id || "student-1", type: "student", name: student?.full_name || "You" },
          { id: "school-1", type: "school", name: "Elite Driving Academy" },
        ],
        last_message: {
          id: "msg-6",
          conversation_id: "conv-2",
          sender_id: "school-1",
          sender_type: "school",
          sender_name: "Elite Driving Academy",
          content: "Your next exam date has been scheduled for December 15th",
          message_type: "text",
          status: "read",
          created_at: new Date(Date.now() - 3600000).toISOString(),
          is_deleted: false,
        },
        unread_count: 0,
        is_pinned: false,
        is_muted: false,
        is_archived: false,
        created_at: new Date(Date.now() - 86400000 * 14).toISOString(),
        updated_at: new Date(Date.now() - 3600000).toISOString(),
      },
      {
        id: "conv-3",
        participants: [
          { id: student?.id || "student-1", type: "student", name: student?.full_name || "You" },
          { id: "instructor-2", type: "instructor", name: "Sarah Weber" },
        ],
        last_message: {
          id: "msg-9",
          conversation_id: "conv-3",
          sender_id: "instructor-2",
          sender_type: "instructor",
          sender_name: "Sarah Weber",
          content: "Great progress today! Keep practicing parallel parking.",
          message_type: "text",
          status: "delivered",
          created_at: new Date(Date.now() - 7200000).toISOString(),
          is_deleted: false,
        },
        unread_count: 1,
        is_pinned: false,
        is_muted: true,
        is_archived: false,
        created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
        updated_at: new Date(Date.now() - 7200000).toISOString(),
      },
    ];
  }, [student]);

  const generateMockMessages = useCallback(
    (conversationId) => {
      const baseMessages = {
        "conv-1": [
          {
            id: "msg-1",
            conversation_id: "conv-1",
            sender_id: "instructor-1",
            sender_type: "instructor",
            sender_name: "Michael Schmidt",
            content: "Hi! Ready for tomorrow's lesson?",
            message_type: "text",
            status: "read",
            created_at: new Date(Date.now() - 7200000).toISOString(),
            is_deleted: false,
          },
          {
            id: "msg-2",
            conversation_id: "conv-1",
            sender_id: student?.id || "student-1",
            sender_type: "student",
            sender_name: student?.full_name || "You",
            content: "Yes! Looking forward to it. What time again?",
            message_type: "text",
            status: "read",
            created_at: new Date(Date.now() - 3600000).toISOString(),
            is_deleted: false,
          },
          {
            id: "msg-3",
            conversation_id: "conv-1",
            sender_id: "instructor-1",
            sender_type: "instructor",
            sender_name: "Michael Schmidt",
            content: "See you tomorrow at 10 AM!",
            message_type: "text",
            status: "read",
            created_at: new Date().toISOString(),
            is_deleted: false,
          },
        ],
        "conv-2": [
          {
            id: "msg-4",
            conversation_id: "conv-2",
            sender_id: "school-1",
            sender_type: "school",
            sender_name: "Elite Driving Academy",
            content: "Welcome to Elite Driving Academy! We're excited to help you on your journey to becoming a licensed driver.",
            message_type: "text",
            status: "read",
            created_at: new Date(Date.now() - 86400000 * 14).toISOString(),
            is_deleted: false,
          },
          {
            id: "msg-5",
            conversation_id: "conv-2",
            sender_id: student?.id || "student-1",
            sender_type: "student",
            sender_name: student?.full_name || "You",
            content: "Thank you! I'm looking forward to starting my lessons.",
            message_type: "text",
            status: "read",
            created_at: new Date(Date.now() - 86400000 * 13).toISOString(),
            is_deleted: false,
          },
          {
            id: "msg-6",
            conversation_id: "conv-2",
            sender_id: "school-1",
            sender_type: "school",
            sender_name: "Elite Driving Academy",
            content: "Your next exam date has been scheduled for December 15th",
            message_type: "text",
            status: "read",
            created_at: new Date(Date.now() - 3600000).toISOString(),
            is_deleted: false,
          },
        ],
        "conv-3": [
          {
            id: "msg-7",
            conversation_id: "conv-3",
            sender_id: "instructor-2",
            sender_type: "instructor",
            sender_name: "Sarah Weber",
            content: "How did you feel about today's lesson?",
            message_type: "text",
            status: "read",
            created_at: new Date(Date.now() - 14400000).toISOString(),
            is_deleted: false,
          },
          {
            id: "msg-8",
            conversation_id: "conv-3",
            sender_id: student?.id || "student-1",
            sender_type: "student",
            sender_name: student?.full_name || "You",
            content: "It was challenging but I learned a lot! The parallel parking was tricky.",
            message_type: "text",
            status: "read",
            created_at: new Date(Date.now() - 10800000).toISOString(),
            is_deleted: false,
          },
          {
            id: "msg-9",
            conversation_id: "conv-3",
            sender_id: "instructor-2",
            sender_type: "instructor",
            sender_name: "Sarah Weber",
            content: "Great progress today! Keep practicing parallel parking.",
            message_type: "text",
            status: "delivered",
            created_at: new Date(Date.now() - 7200000).toISOString(),
            is_deleted: false,
          },
        ],
      };

      return baseMessages[conversationId] || [];
    },
    [student]
  );

  const filteredConversations = useMemo(() => {
    let filtered = [...conversations];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter((conv) =>
        conv.participants.some(
          (p) =>
            p.name.toLowerCase().includes(query) ||
            conv.last_message?.content.toLowerCase().includes(query)
        )
      );
    }

    switch (filterType) {
      case "unread":
        filtered = filtered.filter((c) => c.unread_count > 0);
        break;
      case "pinned":
        filtered = filtered.filter((c) => c.is_pinned);
        break;
      case "archived":
        filtered = filtered.filter((c) => c.is_archived);
        break;
      default:
        filtered = filtered.filter((c) => !c.is_archived);
    }

    return filtered.sort((a, b) => {
      if (a.is_pinned && !b.is_pinned) return -1;
      if (!a.is_pinned && b.is_pinned) return 1;
      return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
    });
  }, [conversations, searchQuery, filterType]);

  const selectedConversation = useMemo(
    () => conversations.find((c) => c.id === selectedConversationId),
    [conversations, selectedConversationId]
  );

  const groupedMessages = useMemo(() => {
    const groups = [];
    let currentDate = "";

    messages.forEach((message) => {
      const messageDate = formatMessageDate(new Date(message.created_at));
      if (messageDate !== currentDate) {
        currentDate = messageDate;
        groups.push({ date: messageDate, messages: [message] });
      } else {
        groups[groups.length - 1].messages.push(message);
      }
    });

    return groups;
  }, [messages]);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  const handleTyping = useCallback(() => {
    if (!isTyping) {
      setIsTyping(true);
    }

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
    }, TYPING_TIMEOUT);
  }, [isTyping]);

  const handleSendMessage = useCallback(() => {
    if (!messageText.trim() || !selectedConversationId || !student) return;

    const newMessage = {
      conversation_id: selectedConversationId,
      sender_id: student.id,
      sender_type: "student",
      sender_name: student.full_name,
      content: messageText.trim(),
      message_type: "text",
      status: "sending",
      created_at: new Date().toISOString(),
      is_deleted: false,
    };

    if (replyingTo) {
      newMessage.reply_to = {
        id: replyingTo.id,
        content: replyingTo.content,
        sender_name: replyingTo.sender_name,
      };
    }

    sendMessageMutation.mutate(newMessage);
    setMessageText("");
    setReplyingTo(null);
    setIsTyping(false);

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
  }, [messageText, selectedConversationId, student, replyingTo, sendMessageMutation]);

  const handleKeyPress = useCallback(
    (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
      }
    },
    [handleSendMessage]
  );

  const handleDeleteMessage = useCallback(
    (messageId) => {
      deleteMessageMutation.mutate(messageId);
    },
    [deleteMessageMutation]
  );

  const handleCopyMessage = useCallback((content) => {
    navigator.clipboard.writeText(content);
    toast.success("Message copied to clipboard");
  }, []);

  const handleTogglePin = useCallback(() => {
    if (!selectedConversation) return;
    updateConversationMutation.mutate({
      id: selectedConversation.id,
      data: { is_pinned: !selectedConversation.is_pinned },
    });
  }, [selectedConversation, updateConversationMutation]);

  const handleToggleMute = useCallback(() => {
    if (!selectedConversation) return;
    updateConversationMutation.mutate({
      id: selectedConversation.id,
      data: { is_muted: !selectedConversation.is_muted },
    });
    toast.success(selectedConversation.is_muted ? "Notifications enabled" : "Notifications muted");
  }, [selectedConversation, updateConversationMutation]);

  const handleArchive = useCallback(() => {
    if (!selectedConversation) return;
    updateConversationMutation.mutate({
      id: selectedConversation.id,
      data: { is_archived: true },
    });
    setSelectedConversationId(null);
    toast.success("Conversation archived");
  }, [selectedConversation, updateConversationMutation]);

  const handleSelectConversation = useCallback((conversationId) => {
    setSelectedConversationId(conversationId);
    setShowMobileChat(true);
  }, []);

  const otherParticipant = selectedConversation?.participants.find(
    (p) => p.id !== student?.id
  );

  const currentTypingUsers = typingUsers
    .filter(
      (t) =>
        t.conversation_id === selectedConversationId &&
        t.user_id !== student?.id &&
        Date.now() - t.timestamp < TYPING_TIMEOUT
    )
    .map((t) => t.user_name);

  if (!student) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-zinc-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-0 pb-24 md:pb-6">
      <div
        className="rounded-2xl border border-zinc-200 bg-white shadow-sm overflow-hidden"
        style={{ height: "calc(100vh - 140px)" }}
      >
        <div className="grid grid-cols-1 md:grid-cols-3 h-full">
          <div
            className={`border-r border-zinc-200 flex flex-col ${
              showMobileChat ? "hidden md:flex" : "flex"
            }`}
          >
            <div className="p-4 border-b border-zinc-200">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-zinc-900">Messages</h2>
                <div className="relative">
                  <button
                    onClick={() => setShowFilterMenu(!showFilterMenu)}
                    className="p-2 rounded-lg hover:bg-zinc-100 transition"
                  >
                    <Filter className="w-5 h-5 text-zinc-600" />
                  </button>
                  <AnimatePresence>
                    {showFilterMenu && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="absolute right-0 top-full mt-1 w-40 bg-white rounded-xl shadow-lg border border-zinc-200 py-1 z-10"
                      >
                        {["all", "unread", "pinned", "archived"].map((filter) => (
                          <button
                            key={filter}
                            onClick={() => {
                              setFilterType(filter);
                              setShowFilterMenu(false);
                            }}
                            className={`w-full px-4 py-2 text-left text-sm capitalize hover:bg-zinc-50 ${
                              filterType === filter ? "text-indigo-600 font-medium" : "text-zinc-700"
                            }`}
                          >
                            {filter}
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search conversations..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-zinc-200 bg-zinc-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {conversationsLoading ? (
                <div className="flex items-center justify-center h-32">
                  <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                </div>
              ) : filteredConversations.length === 0 ? (
                <div className="p-8 text-center">
                  <MessageCircle className="w-12 h-12 text-zinc-300 mx-auto mb-3" />
                  <p className="text-zinc-500">No conversations found</p>
                </div>
              ) : (
                filteredConversations.map((conversation) => (
                  <ConversationListItem
                    key={conversation.id}
                    conversation={conversation}
                    currentUserId={student.id}
                    isSelected={conversation.id === selectedConversationId}
                    onSelect={() => handleSelectConversation(conversation.id)}
                  />
                ))
              )}
            </div>
          </div>

          <div
            className={`md:col-span-2 flex flex-col ${
              showMobileChat ? "flex" : "hidden md:flex"
            }`}
          >
            {selectedConversation && otherParticipant ? (
              <>
                <div className="p-4 border-b border-zinc-200 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setShowMobileChat(false)}
                      className="md:hidden p-2 -ml-2 rounded-lg hover:bg-zinc-100"
                    >
                      <ChevronDown className="w-5 h-5 rotate-90" />
                    </button>
                    <Avatar name={otherParticipant.name} url={otherParticipant.avatar} isOnline />
                    <div>
                      <h3 className="font-semibold text-zinc-900">{otherParticipant.name}</h3>
                      <p className="text-sm text-zinc-500 capitalize">{otherParticipant.type}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button className="p-2 rounded-lg hover:bg-zinc-100 transition">
                      <Phone className="w-5 h-5 text-zinc-600" />
                    </button>
                    <button className="p-2 rounded-lg hover:bg-zinc-100 transition">
                      <Video className="w-5 h-5 text-zinc-600" />
                    </button>
                    <div className="relative">
                      <button className="p-2 rounded-lg hover:bg-zinc-100 transition">
                        <MoreVertical className="w-5 h-5 text-zinc-600" />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4">
                  {messagesLoading ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                    </div>
                  ) : (
                    <>
                      {groupedMessages.map((group) => (
                        <div key={group.date}>
                          <div className="flex items-center justify-center my-4">
                            <span className="px-3 py-1 bg-zinc-100 rounded-full text-xs text-zinc-500">
                              {group.date}
                            </span>
                          </div>
                          {group.messages.map((message, index) => {
                            const isOwn = message.sender_id === student.id;
                            const prevMessage = group.messages[index - 1];
                            const showAvatar =
                              !isOwn &&
                              (!prevMessage || prevMessage.sender_id !== message.sender_id);

                            return (
                              <MessageBubble
                                key={message.id}
                                message={message}
                                isOwn={isOwn}
                                showAvatar={showAvatar}
                                onReply={() => setReplyingTo(message)}
                                onDelete={() => handleDeleteMessage(message.id)}
                                onCopy={() => handleCopyMessage(message.content)}
                              />
                            );
                          })}
                        </div>
                      ))}
                      <TypingIndicatorBubble names={currentTypingUsers} />
                      <div ref={messagesEndRef} />
                    </>
                  )}
                </div>

                <div className="p-4 border-t border-zinc-200">
                  <AnimatePresence>
                    {replyingTo && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mb-3 px-4 py-2 bg-zinc-100 rounded-xl flex items-center justify-between"
                      >
                        <div className="flex items-center gap-2">
                          <Reply className="w-4 h-4 text-zinc-500" />
                          <div>
                            <p className="text-xs font-medium text-zinc-700">
                              Replying to {replyingTo.sender_name}
                            </p>
                            <p className="text-xs text-zinc-500 truncate max-w-[200px]">
                              {replyingTo.content}
                            </p>
                          </div>
                        </div>
                        <button
                          onClick={() => setReplyingTo(null)}
                          className="p-1 rounded hover:bg-zinc-200"
                        >
                          <X className="w-4 h-4 text-zinc-500" />
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div className="flex items-end gap-2">
                    <input
                      type="file"
                      ref={fileInputRef}
                      className="hidden"
                      multiple
                      accept="image/*,.pdf,.doc,.docx"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="p-3 rounded-xl hover:bg-zinc-100 transition"
                    >
                      <Paperclip className="w-5 h-5 text-zinc-500" />
                    </button>

                    <div className="flex-1 relative">
                      <textarea
                        value={messageText}
                        onChange={(e) => {
                          setMessageText(e.target.value);
                          handleTyping();
                        }}
                        onKeyPress={handleKeyPress}
                        placeholder="Type your message..."
                        rows={1}
                        className="w-full px-4 py-3 rounded-xl border border-zinc-200 bg-zinc-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none max-h-32"
                        style={{ minHeight: "48px" }}
                      />
                    </div>

                    <button
                      onClick={handleSendMessage}
                      disabled={!messageText.trim()}
                      className="p-3 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-500 text-white disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg transition"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <EmptyState
                icon={<MessageCircle className="w-8 h-8" />}
                title="Select a conversation"
                description="Choose a conversation from the list to start messaging"
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}