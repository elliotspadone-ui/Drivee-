import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useQueryClient } from "@tanstack/react-query";
import RouteGuard from "@/components/auth/RouteGuard";
import {
  LayoutDashboard,
  Calendar,
  Users,
  Car,
  CreditCard,
  BarChart3,
  Settings,
  GraduationCap,
  FileText,
  UserCheck,
  Menu,
  X,
  Bell,
  Search,
  BookOpen,
  DollarSign,
  Megaphone,
  Globe,
  TrendingUp,
  LogOut,
  ChevronDown,
  ChevronRight,
  Package,
  MessageSquare,
  HelpCircle,
  Star,
  Award,
  Target,
  Command,
  ChevronLeft,
  ArrowUpRight,
  FolderOpen,
  Plus,
  AlertCircle,
  UserCircle,
  Receipt,
} from "lucide-react";

import { base44 } from "@/api/base44Client";
import { motion, AnimatePresence } from "framer-motion";
import { toast, Toaster } from "sonner";

import { getRoleDisplayName } from "@/components/utils/rbac";
import { shouldShowAnts } from "@/components/utils/localisation";
import LanguageSelector from "@/components/common/LanguageSelector";
import { useTranslation, initI18n, changeLanguage } from "@/components/utils/i18n";
import { CelebrationProvider } from "@/components/common/ConfettiCelebration";
import HelpChat from "@/components/student/HelpChat";
import ErrorBoundary from "@/components/errors/ErrorBoundary";
import SkeletonLoader from "@/components/common/SkeletonLoader";
import { logger } from "@/components/utils/config";
import "@/globals.css";

const LOGO_URL =
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691b056345d5788acbd4e732/8bd9d7a47_ChatGPTImageNov29202511_47_17PM.png";

// Init i18n once (safe if already initialized)
try {
  initI18n?.();
} catch {}

/* ---------------------------------------
   Small utilities
---------------------------------------- */
const easing = {
  premium: [0.22, 1, 0.36, 1],
};

function safeGetLS(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v === null ? fallback : v;
  } catch {
    return fallback;
  }
}
function safeSetLS(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch {}
}

function useLocalStorageState(key, initialValue) {
  const [value, setValue] = useState(() => {
    const raw = safeGetLS(key, null);
    if (raw === null) return initialValue;
    try {
      return JSON.parse(raw);
    } catch {
      return raw;
    }
  });

  useEffect(() => {
    try {
      safeSetLS(key, JSON.stringify(value));
    } catch {}
  }, [key, value]);

  return [value, setValue];
}

function useMountedFlag() {
  const mounted = useRef(false);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  return mounted;
}

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

/* ---------------------------------------
   Animation variants
---------------------------------------- */
const slideUp = {
  hidden: { opacity: 0, y: 10, scale: 0.98 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.2, ease: easing.premium },
  },
  exit: { opacity: 0, y: 10, scale: 0.98, transition: { duration: 0.15 } },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.03, delayChildren: 0.03 } },
};

const staggerItem = {
  hidden: { opacity: 0, x: -10 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.18, ease: easing.premium } },
};

/* ---------------------------------------
   Nav builders (kept close to your original)
---------------------------------------- */
function buildAdminNav(t, schoolOperatingCountry) {
  const baseNav = [
    {
      section: t("nav.dashboard"),
      items: [
        { name: t("nav.dashboard"), icon: LayoutDashboard, path: "Dashboard" },
        { name: t("nav.analytics"), icon: BarChart3, path: "Analytics" },
      ],
    },
    {
      section: t("nav.schedule"),
      items: [
        { name: t("nav.schedule"), icon: Calendar, path: "Calendar" },
        { name: t("nav.students"), icon: Users, path: "Students" },
        { name: t("nav.instructors"), icon: UserCheck, path: "Instructors" },
        { name: t("nav.fleet"), icon: Car, path: "Fleet" },
      ],
    },
    {
      section: t("nav.finance"),
      items: [
        { name: t("nav.finance"), icon: DollarSign, path: "Finance" },
        { name: t("nav.packages"), icon: Package, path: "Packages" },
        { name: t("nav.invoices"), icon: Receipt, path: "Invoices" },
        { name: "Auto Payments", icon: CreditCard, path: "AutomatedPayments" },
      ],
    },
    {
      section: t("nav.theory"),
      items: [
        { name: t("nav.theory"), icon: BookOpen, path: "TheoryManagement" },
        { name: t("nav.courses"), icon: GraduationCap, path: "Courses" },
      ],
    },
    {
      section: t("nav.marketing"),
      items: [
        { name: t("nav.marketing"), icon: Megaphone, path: "Marketing" },
        { name: t("nav.website"), icon: Globe, path: "WebsiteBuilder" },
        { name: t("nav.reviews"), icon: Star, path: "Reviews" },
      ],
    },
    {
      section: t("nav.settings"),
      items: [
        { name: t("nav.settings"), icon: Settings, path: "Settings" },
        { name: t("nav.reports"), icon: FileText, path: "Reports" },
      ],
    },
  ];

  if (shouldShowAnts(schoolOperatingCountry)) {
    const settingsIndex = baseNav.findIndex((s) => s.section === t("nav.settings"));
    if (settingsIndex !== -1) {
      baseNav[settingsIndex].items.push({
        name: "ANTS Dossiers",
        icon: FolderOpen,
        path: "AdminAntsDossiers",
      });
    }
  }

  return baseNav;
}

const INSTRUCTOR_NAV = [
  {
    section: "My Work",
    items: [
      { name: "Dashboard", icon: LayoutDashboard, path: "InstructorDashboard" },
      { name: "Schedule", icon: Calendar, path: "InstructorSchedule" },
      { name: "Students", icon: Users, path: "InstructorStudents" },
    ],
  },
  {
    section: "Performance",
    items: [
      { name: "Analytics", icon: TrendingUp, path: "InstructorAnalytics" },
      { name: "Earnings", icon: DollarSign, path: "InstructorEarnings" },
    ],
  },
  {
    section: "Resources",
    items: [
      { name: "My Vehicle", icon: Car, path: "InstructorVehicle" },
      { name: "Materials", icon: BookOpen, path: "InstructorResources" },
    ],
  },
  {
    section: "Account",
    items: [
      { name: "Profile", icon: UserCircle, path: "InstructorProfile" },
      { name: "Settings", icon: Settings, path: "InstructorSettings" },
    ],
  },
];

function buildStudentNav(schoolOperatingCountry) {
  const baseNav = [
    {
      section: "Learning",
      items: [
        { name: "Dashboard", icon: LayoutDashboard, path: "StudentDashboard" },
        { name: "Book Lesson", icon: Calendar, path: "BookLesson" },
        { name: "My Lessons", icon: BookOpen, path: "MyLessons" },
        { name: "Theory", icon: Target, path: "TheoryLearning" },
      ],
    },
    {
      section: "Progress",
      items: [
        { name: "My Progress", icon: TrendingUp, path: "StudentProgress" },
        { name: "Achievements", icon: Award, path: "StudentAchievements" },
      ],
    },
    {
      section: "Billing",
      items: [
        { name: "Invoices", icon: Receipt, path: "StudentInvoices" },
        { name: "Packages", icon: Package, path: "StudentPackages" },
      ],
    },
    {
      section: "Support",
      items: [
        { name: "Messages", icon: MessageSquare, path: "StudentMessages" },
        { name: "Help Center", icon: HelpCircle, path: "StudentHelp" },
      ],
    },
  ];

  if (shouldShowAnts(schoolOperatingCountry)) {
    const learningIndex = baseNav.findIndex((s) => s.section === "Learning");
    if (learningIndex !== -1) {
      baseNav[learningIndex].items.push({
        name: "Mon Dossier ANTS",
        icon: FolderOpen,
        path: "StudentAntsDossier",
      });
    }
  }

  return baseNav;
}

/* ---------------------------------------
   Command Palette (much smoother: keyboard nav, recents, suggestions)
---------------------------------------- */
function CommandPalette({ isOpen, onClose, navigation, t }) {
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef(null);

  const recentKey = "drivee_recent_pages_v1";
  const recentPages = useMemo(() => {
    try {
      const raw = safeGetLS(recentKey, "[]");
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr.slice(0, 6) : [];
    } catch {
      return [];
    }
  }, [isOpen]);

  const allItems = useMemo(() => {
    return navigation.flatMap((section) =>
      section.items.map((item) => ({
        ...item,
        category: section.section,
      }))
    );
  }, [navigation]);

  const filteredItems = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    const ranked = allItems
      .map((item) => {
        const hay = `${item.name} ${item.category} ${item.path}`.toLowerCase();
        const idx = hay.indexOf(q);
        return { item, score: idx === -1 ? 999 : idx };
      })
      .filter((x) => x.score !== 999)
      .sort((a, b) => a.score - b.score)
      .slice(0, 7)
      .map((x) => x.item);
    return ranked;
  }, [query, allItems]);

  const suggestedItems = useMemo(() => {
    if (query.trim()) return [];
    // show a small curated set: first item of each section + recent pages
    const top = navigation
      .flatMap((section) => section.items.slice(0, 1).map((it) => ({ ...it, category: section.section })))
      .slice(0, 6);

    const recent = recentPages
      .map((path) => allItems.find((it) => it.path === path))
      .filter(Boolean)
      .map((it) => ({ ...it, category: it.category || "Recent" }));

    // de-dupe by path
    const seen = new Set();
    const merged = [...recent, ...top].filter((it) => {
      if (seen.has(it.path)) return false;
      seen.add(it.path);
      return true;
    });

    return merged.slice(0, 7);
  }, [query, navigation, recentPages, allItems]);

  const results = query.trim() ? filteredItems : suggestedItems;

  useEffect(() => {
    if (!isOpen) return;
    setQuery("");
    setActiveIndex(0);
    const id = setTimeout(() => inputRef.current?.focus(), 80);
    return () => clearTimeout(id);
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        return;
      }
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveIndex((i) => clamp(i + 1, 0, Math.max(0, results.length - 1)));
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveIndex((i) => clamp(i - 1, 0, Math.max(0, results.length - 1)));
        return;
      }
      if (e.key === "Enter") {
        if (!results.length) return;
        const item = results[activeIndex];
        if (!item) return;
        const url = createPageUrl(item.path);
        // Let the Link click handle navigation via an anchor fallback
        window.location.href = url;
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen, onClose, results, activeIndex]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[14vh] px-4">
      <motion.button
        type="button"
        aria-label="Close command palette"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: -8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: -8 }}
        transition={{ duration: 0.2, ease: easing.premium }}
        className="relative w-full max-w-xl bg-white rounded-2xl shadow-premium-xl border border-slate-200/50 overflow-hidden flex flex-col"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center px-5 py-4 border-b border-slate-100 bg-slate-50/50">
          <Search className="w-5 h-5 text-slate-400 mr-3 flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder={t("layout.searchPlaceholder")}
            className="flex-1 bg-transparent border-none outline-none text-sm text-slate-800 placeholder:text-slate-400 font-medium"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setActiveIndex(0);
            }}
          />
          <button
            onClick={onClose}
            className="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs text-slate-500 font-semibold transition-colors"
          >
            ESC
          </button>
        </div>

        <div className="max-h-[360px] overflow-y-auto">
          {results.length === 0 && (
            <div className="px-5 py-10 text-center">
              <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                <AlertCircle className="w-6 h-6 text-slate-400" />
              </div>
              <p className="text-sm text-slate-600 font-medium">{t("layout.noResults")}</p>
              {query.trim() ? <p className="text-xs text-slate-400 mt-1">"{query}"</p> : null}
            </div>
          )}

          {results.length > 0 && (
            <motion.div variants={staggerContainer} initial="hidden" animate="visible" className="py-2">
              {results.map((item, idx) => {
                const active = idx === activeIndex;
                return (
                  <motion.div key={`${item.path}_${idx}`} variants={staggerItem}>
                    <Link
                      to={createPageUrl(item.path)}
                      onClick={() => {
                        // store recents
                        try {
                          const raw = safeGetLS(recentKey, "[]");
                          const arr = JSON.parse(raw);
                          const next = Array.isArray(arr) ? arr.filter((p) => p !== item.path) : [];
                          next.unshift(item.path);
                          safeSetLS(recentKey, JSON.stringify(next.slice(0, 8)));
                        } catch {}
                        onClose();
                      }}
                      className={[
                        "flex items-center px-5 py-3 cursor-pointer group transition-all",
                        active ? "bg-[#e8f4fa]" : "hover:bg-[#e8f4fa]",
                      ].join(" ")}
                    >
                      <div
                        className={[
                          "w-9 h-9 rounded-xl flex items-center justify-center mr-4 transition-colors",
                          active ? "bg-[#d4eaf5]" : "bg-slate-100 group-hover:bg-[#d4eaf5]",
                        ].join(" ")}
                      >
                        <item.icon
                          className={[
                            "w-4 h-4 transition-colors",
                            active ? "text-[#3b82c4]" : "text-slate-500 group-hover:text-[#3b82c4]",
                          ].join(" ")}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-slate-700 group-hover:text-[#2563a3] transition-colors">
                          {item.name}
                        </p>
                        <p className="text-xs text-slate-400 truncate">{item.category}</p>
                      </div>
                      <ArrowUpRight
                        className={[
                          "w-4 h-4 transition-all",
                          active ? "text-[#3b82c4] opacity-100" : "text-slate-300 opacity-0 group-hover:opacity-100",
                        ].join(" ")}
                      />
                    </Link>
                  </motion.div>
                );
              })}
            </motion.div>
          )}
        </div>

        <div className="px-5 py-3 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <kbd className="px-1.5 py-0.5 bg-white border border-slate-200 rounded text-[10px] font-semibold">
                ↑↓
              </kbd>
              Navigate
            </span>
            <span className="flex items-center gap-1.5">
              <kbd className="px-1.5 py-0.5 bg-white border border-slate-200 rounded text-[10px] font-semibold">
                ↵
              </kbd>
              Open
            </span>
          </div>
          <span className="flex items-center gap-1">
            <Command className="w-3 h-3" />
            <span className="font-semibold">K</span>
          </span>
        </div>
      </motion.div>
    </div>
  );
}

/* ---------------------------------------
   Notifications
---------------------------------------- */
function NotificationItem({ notification, onMarkRead }) {
  const getIcon = (type) => {
    switch (type) {
      case "booking":
        return Calendar;
      case "payment":
        return CreditCard;
      case "message":
        return MessageSquare;
      case "alert":
        return AlertCircle;
      default:
        return Bell;
    }
  };

  const Icon = getIcon(notification?.type);

  return (
    <motion.button
      type="button"
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 10 }}
      className="w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors group"
      onClick={() => onMarkRead(notification.id)}
    >
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 bg-[#e8f4fa] rounded-xl flex items-center justify-center flex-shrink-0">
          <Icon className="w-4 h-4 text-[#3b82c4]" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-slate-800 line-clamp-2">
            {notification.title || notification.message}
          </p>
          <p className="text-xs text-slate-400 mt-1">
            {notification.created_date ? new Date(notification.created_date).toLocaleDateString() : "Just now"}
          </p>
        </div>
        <div className="w-2 h-2 bg-[#3b82c4] rounded-full mt-2 flex-shrink-0" />
      </div>
    </motion.button>
  );
}

/* ---------------------------------------
   Main Layout
---------------------------------------- */
export default function Layout({ children, currentPageName }) {
  const { t } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const mounted = useMountedFlag();

  const STUDENT_PAGES = useMemo(
    () => [
      "StudentDashboard",
      "BookLesson",
      "MyLessons",
      "TheoryLearning",
      "StudentInvoices",
      "StudentProgress",
      "StudentProfile",
      "StudentSettings",
      "StudentAchievements",
      "StudentMessages",
      "StudentHelp",
      "StudentPackages",
      "StudentAntsDossier",
    ],
    []
  );

  const INSTRUCTOR_PAGES = useMemo(
    () => [
      "InstructorDashboard",
      "InstructorSchedule",
      "InstructorStudents",
      "InstructorAnalytics",
      "InstructorEarnings",
      "InstructorVehicle",
      "InstructorResources",
      "InstructorSettings",
      "InstructorProfile",
    ],
    []
  );

  const PUBLIC_PAGES = useMemo(
    () => [
      "Landing",
      "BusinessSolutions",
      "SchoolLogin",
      "SchoolWebsite",
      "Marketplace",
      "SchoolProfile",
      "Register",
      "ForgotPassword",
      "VerifyEmail",
      "ResetPassword",
      "AutoRedirect",
      "StudentAuth",
      "TheoryTestPrep",
      "NotFound",
      "Unauthorized",
      "Health",
      "SeedCatAccount",
    ],
    []
  );

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [sidebarCollapsed, setSidebarCollapsed] = useLocalStorageState("sidebar_collapsed_v2", false);

  const [expandedSections, setExpandedSections] = useLocalStorageState("sidebar_sections_v2", {});
  const [showSearch, setShowSearch] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showQuickActions, setShowQuickActions] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const [user, setUser] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [loadingUser, setLoadingUser] = useState(true);
  const [loadingNotifs, setLoadingNotifs] = useState(false);

  const [schoolOperatingCountry, setSchoolOperatingCountry] = useState("FR");
  const [userLanguage, setUserLanguage] = useLocalStorageState("drivee_language", "en");

  // Early return for public pages - must be after all hooks but before complex logic
  const isPublicPage = PUBLIC_PAGES.includes(currentPageName);

  const closeAllOverlays = useCallback(() => {
    setShowNotifications(false);
    setShowQuickActions(false);
    setShowUserMenu(false);
    setMobileMenuOpen(false);
  }, []);

  const openOverlay = useCallback(
    (name) => {
      // single overlay at a time feels premium and reduces misclicks
      setShowNotifications(false);
      setShowQuickActions(false);
      setShowUserMenu(false);
      if (name === "notifications") setShowNotifications(true);
      if (name === "quickActions") setShowQuickActions(true);
      if (name === "userMenu") setShowUserMenu(true);
    },
    [setShowNotifications, setShowQuickActions, setShowUserMenu]
  );

  const toggleSidebar = useCallback(() => {
    setSidebarCollapsed((v) => !v);
  }, [setSidebarCollapsed]);

  const toggleSection = useCallback(
    (section) => {
      setExpandedSections((prev) => ({ ...(prev || {}), [section]: !(prev?.[section] ?? true) }));
    },
    [setExpandedSections]
  );

  const adminNav = useMemo(() => buildAdminNav(t, schoolOperatingCountry), [t, schoolOperatingCountry]);
  const instructorNav = useMemo(() => INSTRUCTOR_NAV, []);
  const studentNav = useMemo(() => buildStudentNav(schoolOperatingCountry), [schoolOperatingCountry]);

  const portal = useMemo(() => {
    const isInstructor = INSTRUCTOR_PAGES.includes(currentPageName);
    const isStudent = STUDENT_PAGES.includes(currentPageName);

    if (isInstructor) {
      return {
        navigation: instructorNav,
        portalTypeKey: "instructorPortal",
        portalGradient: "from-[#a9d5ed] to-[#3b82c4]",
        portalAccent: "text-[#3b82c4]",
      };
    }
    if (isStudent) {
      return {
        navigation: studentNav,
        portalTypeKey: "studentPortal",
        portalGradient: "from-[#81da5a] to-[#5cb83a]",
        portalAccent: "text-[#5cb83a]",
      };
    }
    return {
      navigation: adminNav,
      portalTypeKey: "adminConsole",
      portalGradient: "from-[#a9d5ed] to-[#3b82c4]",
      portalAccent: "text-[#3b82c4]",
    };
  }, [currentPageName, adminNav, instructorNav, studentNav, INSTRUCTOR_PAGES, STUDENT_PAGES]);

  // Close dropdowns on navigation (prevents stuck menus, feels much smoother)
  useEffect(() => {
    closeAllOverlays();
    setShowSearch(false);
  }, [location.pathname, closeAllOverlays]);

  // Keyboard: Cmd/Ctrl K to open, Escape closes all overlays
  useEffect(() => {
    const onKeyDown = (e) => {
      const isK = e.key?.toLowerCase() === "k";
      if ((e.metaKey || e.ctrlKey) && isK) {
        e.preventDefault();
        closeAllOverlays();
        setShowSearch(true);
        return;
      }
      if (e.key === "Escape") {
        setShowSearch(false);
        closeAllOverlays();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [closeAllOverlays]);

  // Load user, language, notifications, school operating country - only for protected pages
  useEffect(() => {
    let cancelled = false;

    // Skip data loading for public pages
    if (isPublicPage) {
      setLoadingUser(false);
      return;
    }

    const load = async () => {
      setLoadingUser(true);
      try {
        const currentUser = await base44.auth.me();
        if (!currentUser) {
          logger.warn("No user found in Layout");
          throw new Error("No user");
        }

        if (!cancelled && mounted.current) {
          setUser(currentUser);
          const preferredLang = currentUser.preferredLanguage || currentUser.preferred_language;
          if (preferredLang) {
            setUserLanguage(preferredLang);
            try {
              changeLanguage(preferredLang);
            } catch {}
          }
        }

        // Load school country
        try {
          const schools = await base44.entities.School.list();
          if (!cancelled && mounted.current && schools && schools.length > 0) {
            setSchoolOperatingCountry(schools[0].operating_country || "FR");
          }
        } catch {}

        // Load notifications (scoped to user and school)
        setLoadingNotifs(true);
        try {
          let notifFilter = { user_id: currentUser.id, is_read: false };

          // Add school scoping if user has school association
          if (currentUser.school_id) {
            notifFilter.school_id = currentUser.school_id;
          }

          const notifs = await base44.entities.Notification.filter(
            notifFilter,
            "-created_date",
            10
          );
          if (!cancelled && mounted.current) setNotifications(Array.isArray(notifs) ? notifs : []);
        } catch (err) {
          logger.warn("Failed to load notifications:", err);
          if (!cancelled && mounted.current) setNotifications([]);
        } finally {
          if (!cancelled && mounted.current) setLoadingNotifs(false);
        }
      } catch (err) {
        logger.error("Failed to load user in Layout:", err);
        if (!cancelled && mounted.current) setUser(null);
      } finally {
        if (!cancelled && mounted.current) setLoadingUser(false);
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [currentPageName, mounted, setUserLanguage]);

  const handleLogout = useCallback(async () => {
    try {
      await base44.auth.logout();
      
      // Clear all storage
      localStorage.clear();
      sessionStorage.clear();
      
      // Clear React Query cache
      queryClient.clear();
      
      // Redirect to landing page
      window.location.href = createPageUrl("Landing");
    } catch (err) {
      logger.error("Logout failed:", err);
      toast.error(t("layout.failedToLogout"));
    }
  }, [t, queryClient]);

  const handleLanguageChange = useCallback(
    async (newLang) => {
      setUserLanguage(newLang);
      try {
        changeLanguage(newLang);
      } catch {}
      try {
        await base44.auth.updateMe({ preferredLanguage: newLang });
        toast.success(t("common.success"));
      } catch {
        toast.error(t("layout.failedToUpdateLang"));
      }
    },
    [setUserLanguage, t]
  );

  const markNotificationAsRead = useCallback(
    async (notificationId) => {
      try {
        await base44.entities.Notification.update(notificationId, { is_read: true });
        setNotifications((prev) => prev.filter((n) => n.id !== notificationId));
        toast.success(t("layout.markedAsRead"));
      } catch {
        toast.error(t("layout.failedToMarkRead"));
      }
    },
    [t]
  );

  const markAllNotificationsAsRead = useCallback(async () => {
    const ids = notifications.map((n) => n.id).filter(Boolean);
    if (!ids.length) return;
    try {
      await Promise.all(ids.map((id) => base44.entities.Notification.update(id, { is_read: true })));
      setNotifications([]);
      toast.success(t("layout.markedAsRead"));
    } catch {
      toast.error(t("layout.failedToMarkRead"));
    }
  }, [notifications, t]);

  const quickActions = useMemo(
    () => [
      {
        name: t("layout.newBooking"),
        icon: Calendar,
        color: "bg-[#e8f4fa] text-[#3b82c4]",
        action: () => toast.info("Booking modal opening..."),
      },
      {
        name: t("layout.addStudent"),
        icon: UserCircle,
        color: "bg-[#eefbe7] text-[#5cb83a]",
        action: () => toast.info("Add Student modal opening..."),
      },
      {
        name: t("layout.createInvoice"),
        icon: Receipt,
        color: "bg-[#fdfbe8] text-[#b8a525]",
        action: () => toast.info("Invoice creator opening..."),
      },
      {
        name: t("layout.sendMessage"),
        icon: MessageSquare,
        color: "bg-[#f3e8f4] text-[#6c376f]",
        action: () => toast.info("Messenger opening..."),
      },
    ],
    [t]
  );

  // Public pages bypass layout - early return after all hooks
  if (isPublicPage) {
    return <>{children}</>;
  }
  
  const { navigation, portalTypeKey, portalGradient } = portal;

  return (
    <RouteGuard currentPageName={currentPageName}>
      <ErrorBoundary>
        <CelebrationProvider>
          <div className="min-h-screen bg-slate-50/50 antialiased">
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
          * { font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, system-ui, sans-serif; }

          .shadow-premium {
            box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.02),
                        0 1px 2px rgba(0, 0, 0, 0.03),
                        0 4px 8px rgba(0, 0, 0, 0.04),
                        0 12px 24px rgba(0, 0, 0, 0.05);
          }
          .shadow-premium-xl {
            box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.02),
                        0 4px 8px rgba(0, 0, 0, 0.03),
                        0 16px 32px rgba(0, 0, 0, 0.05),
                        0 32px 64px rgba(0, 0, 0, 0.07);
          }
          .glass {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
          }
          .custom-scrollbar::-webkit-scrollbar { width: 5px; }
          .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
          .custom-scrollbar::-webkit-scrollbar-thumb { background: #E2E8F0; border-radius: 10px; }
          .custom-scrollbar:hover::-webkit-scrollbar-thumb { background: #CBD5E1; }

          .nav-item-hover { position: relative; overflow: hidden; }
          .nav-item-hover::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(90deg, transparent, rgba(169, 213, 237, 0.15), transparent);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
          }
          .nav-item-hover:hover::before { transform: translateX(100%); }
        `}</style>

        <Toaster
          position="top-right"
          richColors
          toastOptions={{
            className: "font-medium",
            style: { fontFamily: "Plus Jakarta Sans, system-ui, sans-serif" },
          }}
        />

        <AnimatePresence>{showSearch ? <CommandPalette isOpen={showSearch} onClose={() => setShowSearch(false)} navigation={navigation} t={t} /> : null}</AnimatePresence>

        {/* Sidebar */}
        <aside
          className={[
            "hidden lg:flex fixed left-0 top-0 h-screen bg-white border-r border-slate-200/80 flex-col transition-all duration-300 z-30 shadow-premium",
            sidebarCollapsed ? "w-[76px]" : "w-[264px]",
          ].join(" ")}
        >
          {/* Logo */}
          <div className="h-[72px] flex items-center px-3 border-b border-slate-100">
            <Link
              to={createPageUrl("Landing")}
              className={["flex items-center", sidebarCollapsed ? "justify-center w-full" : "justify-start"].join(" ")}
            >
              <motion.img
                whileHover={{ scale: 1.03 }}
                transition={{ duration: 0.2 }}
                src={LOGO_URL}
                alt="DRIVEE"
                className={["object-contain transition-all", sidebarCollapsed ? "h-10 w-10" : "h-14 w-auto"].join(" ")}
              />
            </Link>
          </div>

          {/* Portal badge */}
          {!sidebarCollapsed && (
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="px-4 py-4">
              <div className="px-4 py-3 bg-gradient-to-r from-slate-50 to-slate-100/50 rounded-xl border border-slate-200/50">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      {t("layout.currentView")}
                    </p>
                    <p className="text-sm font-semibold text-slate-700">{t(`layout.${portalTypeKey}`)}</p>
                  </div>
                  <div className={["w-3 h-3 rounded-full bg-gradient-to-br shadow-sm", portalGradient].join(" ")} />
                </div>
              </div>
            </motion.div>
          )}

          {/* Nav */}
          <div className="flex-1 overflow-y-auto py-4 px-3 custom-scrollbar">
            {navigation.map((navSection, idx) => {
              const sectionKey = `${portalTypeKey}:${navSection.section}`;
              const expanded = (expandedSections?.[sectionKey] ?? true) || sidebarCollapsed;

              return (
                <div key={`${navSection.section}_${idx}`} className="mb-6">
                  {!sidebarCollapsed ? (
                    <button
                      type="button"
                      className="w-full px-3 mb-2 flex items-center justify-between group cursor-pointer"
                      onClick={() => toggleSection(sectionKey)}
                    >
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider group-hover:text-slate-600 transition-colors">
                        {navSection.section}
                      </span>
                      <motion.div animate={{ rotate: expanded ? 90 : 0 }} transition={{ duration: 0.18 }}>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                      </motion.div>
                    </button>
                  ) : (
                    <div className="h-3" />
                  )}

                  <AnimatePresence initial={false}>
                    {expanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.2, ease: easing.premium }}
                        className="space-y-1 overflow-hidden"
                      >
                        {navSection.items.map((item) => {
                          const isActive = location.pathname === createPageUrl(item.path);

                          return (
                            <Link
                              key={item.path}
                              to={createPageUrl(item.path)}
                              className={[
                                "nav-item-hover relative flex items-center h-11 px-3 rounded-xl transition-all duration-200 group",
                                isActive
                                  ? "bg-[#e8f4fa] text-[#3b82c4]"
                                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900",
                                sidebarCollapsed ? "justify-center" : "",
                              ].join(" ")}
                              title={sidebarCollapsed ? item.name : ""}
                            >
                              <div
                                className={[
                                  "flex items-center justify-center w-8 h-8 rounded-lg transition-all",
                                  isActive ? "bg-[#d4eaf5]" : "bg-transparent group-hover:bg-slate-100",
                                ].join(" ")}
                              >
                                <item.icon
                                  className={[
                                    "w-[18px] h-[18px] flex-shrink-0 transition-colors",
                                    isActive ? "text-[#3b82c4]" : "text-slate-400 group-hover:text-slate-600",
                                  ].join(" ")}
                                />
                              </div>

                              {!sidebarCollapsed && (
                                <span className={["ml-3 text-[13px] font-medium", isActive ? "font-semibold" : ""].join(" ")}>
                                  {item.name}
                                </span>
                              )}

                              {isActive && !sidebarCollapsed && (
                                <motion.div
                                  layoutId="sidebar-active-indicator"
                                  className="absolute right-3 w-1.5 h-1.5 rounded-full bg-[#3b82c4]"
                                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                                />
                              )}
                            </Link>
                          );
                        })}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>

          {/* Collapse */}
          <div className="p-4 border-t border-slate-100">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={toggleSidebar}
              className={[
                "flex items-center w-full p-3 rounded-xl hover:bg-slate-50 text-slate-500 transition-all",
                sidebarCollapsed ? "justify-center" : "justify-between",
              ].join(" ")}
            >
              {!sidebarCollapsed && <span className="text-xs font-semibold">{t("layout.collapseSidebar")}</span>}
              <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center">
                {sidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
              </div>
            </motion.button>
          </div>
        </aside>

        {/* Main */}
        <div
          className={[
            "transition-all duration-300 flex flex-col min-h-screen",
            sidebarCollapsed ? "lg:ml-[76px]" : "lg:ml-[264px]",
          ].join(" ")}
        >
          {/* Desktop header */}
          <header className="hidden lg:flex h-[72px] glass border-b border-slate-200/50 sticky top-0 z-20 px-6 items-center justify-between shadow-sm">
            <div className="flex items-center gap-4 flex-1">
              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                onClick={() => {
                  closeAllOverlays();
                  setShowSearch(true);
                }}
                className="flex items-center gap-3 px-4 py-2.5 bg-slate-100/80 hover:bg-slate-200/60 text-slate-500 rounded-xl text-sm transition-all border border-slate-200/50 outline-none w-72"
              >
                <Search className="w-4 h-4" />
                <span className="font-medium">{t("layout.search")}</span>
                <span className="ml-auto flex items-center gap-1 text-[11px] font-bold bg-white px-2 py-1 rounded-lg border border-slate-200 text-slate-400">
                  <Command className="w-3 h-3" />K
                </span>
              </motion.button>
            </div>

            <div className="flex items-center gap-2">
              {/* Quick actions */}
              <div className="relative">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => openOverlay(showQuickActions ? "" : "quickActions")}
                  className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#3b82c4] to-[#2563a3] hover:from-[#2563a3] hover:to-[#1e4f8a] text-white rounded-xl text-sm font-semibold transition-all shadow-md shadow-[#a9d5ed]/50"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t("layout.create")}</span>
                </motion.button>

                <AnimatePresence>
                  {showQuickActions && (
                    <>
                      <motion.button
                        type="button"
                        aria-label="Close"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-10"
                        onClick={closeAllOverlays}
                      />
                      <motion.div
                        variants={slideUp}
                        initial="hidden"
                        animate="visible"
                        exit="exit"
                        className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-premium-xl border border-slate-100 overflow-hidden z-20 py-2"
                      >
                        {quickActions.map((action, i) => (
                          <motion.button
                            key={action.name}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.04 }}
                            onClick={() => {
                              action.action();
                              closeAllOverlays();
                            }}
                            className="flex items-center gap-3 w-full px-4 py-3 text-sm text-slate-700 hover:bg-slate-50 transition-colors text-left group"
                          >
                            <div className={["w-8 h-8 rounded-lg flex items-center justify-center", action.color].join(" ")}>
                              <action.icon className="w-4 h-4" />
                            </div>
                            <span className="font-medium group-hover:text-slate-900">{action.name}</span>
                          </motion.button>
                        ))}
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>

              <div className="h-8 w-px bg-slate-200 mx-2" />

              {/* Language */}
              <LanguageSelector currentLanguage={userLanguage} onLanguageChange={handleLanguageChange} />

              {/* Notifications */}
              <div className="relative">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => openOverlay(showNotifications ? "" : "notifications")}
                  className="p-2.5 text-slate-500 hover:bg-slate-100 rounded-xl transition-colors relative"
                  aria-label="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {notifications.length > 0 && <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 border-2 border-white rounded-full" />}
                </motion.button>

                <AnimatePresence>
                  {showNotifications && (
                    <>
                      <motion.button
                        type="button"
                        aria-label="Close"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-10"
                        onClick={closeAllOverlays}
                      />
                      <motion.div
                        variants={slideUp}
                        initial="hidden"
                        animate="visible"
                        exit="exit"
                        className="absolute right-0 top-full mt-2 w-80 bg-white rounded-2xl shadow-premium-xl border border-slate-100 overflow-hidden z-20"
                      >
                        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                          <h3 className="font-semibold text-slate-900">Notifications</h3>
                          <div className="flex items-center gap-2">
                            {notifications.length > 0 && (
                              <>
                                <span className="px-2 py-0.5 bg-[#e8f4fa] text-[#3b82c4] text-xs font-bold rounded-full">
                                  {notifications.length}
                                </span>
                                <button
                                  type="button"
                                  onClick={markAllNotificationsAsRead}
                                  className="text-xs font-semibold text-slate-500 hover:text-slate-700"
                                >
                                  Mark all
                                </button>
                              </>
                            )}
                          </div>
                        </div>

                        <div className="max-h-80 overflow-y-auto">
                          {loadingNotifs ? (
                            <div className="px-4 py-8 text-center">
                              <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                                <Bell className="w-6 h-6 text-slate-400" />
                              </div>
                              <p className="text-sm text-slate-500">Loading...</p>
                            </div>
                          ) : notifications.length === 0 ? (
                            <div className="px-4 py-8 text-center">
                              <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                                <Bell className="w-6 h-6 text-slate-400" />
                              </div>
                              <p className="text-sm text-slate-500">No new notifications</p>
                            </div>
                          ) : (
                            <AnimatePresence>
                              {notifications.map((notif) => (
                                <NotificationItem key={notif.id} notification={notif} onMarkRead={markNotificationAsRead} />
                              ))}
                            </AnimatePresence>
                          )}
                        </div>

                        {notifications.length > 0 && (
                          <div className="px-4 py-3 border-t border-slate-100">
                            <Link
                              to={createPageUrl("Notifications")}
                              className="block w-full text-center text-sm text-[#3b82c4] font-semibold hover:text-[#2563a3] transition-colors"
                              onClick={closeAllOverlays}
                            >
                              View all notifications
                            </Link>
                          </div>
                        )}
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>

              {/* User menu */}
              <div className="relative ml-1">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => openOverlay(showUserMenu ? "" : "userMenu")}
                  className="flex items-center gap-3 pl-1 pr-3 py-1.5 rounded-xl hover:bg-slate-50 transition-all border border-transparent hover:border-slate-200"
                >
                  <div className={["w-9 h-9 bg-gradient-to-br rounded-xl flex items-center justify-center text-white text-sm font-bold shadow-md", portalGradient].join(" ")}>
                    {user?.full_name?.charAt(0) || "U"}
                  </div>
                  <div className="text-left hidden xl:block">
                    <p className="text-sm font-semibold text-slate-700 leading-none">{user?.full_name || t("layout.loadingUser")}</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">{getRoleDisplayName(user?.role)}</p>
                  </div>
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                </motion.button>

                <AnimatePresence>
                  {showUserMenu && (
                    <>
                      <motion.button
                        type="button"
                        aria-label="Close"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-10"
                        onClick={closeAllOverlays}
                      />
                      <motion.div
                        variants={slideUp}
                        initial="hidden"
                        animate="visible"
                        exit="exit"
                        className="absolute right-0 top-full mt-2 w-64 bg-white rounded-2xl shadow-premium-xl border border-slate-100 overflow-hidden z-20"
                      >
                        <div className="p-4 border-b border-slate-100 bg-slate-50/50">
                          <div className="flex items-center gap-3">
                            <div className={["w-11 h-11 bg-gradient-to-br rounded-xl flex items-center justify-center text-white font-bold shadow-md", portalGradient].join(" ")}>
                              {user?.full_name?.charAt(0) || "U"}
                            </div>
                            <div>
                              <p className="text-sm font-semibold text-slate-900">{user?.full_name || "User"}</p>
                              <p className="text-xs text-slate-500 truncate max-w-[160px]">{user?.email || ""}</p>
                            </div>
                          </div>
                        </div>

                        <div className="p-2">
                          <Link
                            to={createPageUrl("Settings")}
                            onClick={closeAllOverlays}
                            className="flex items-center gap-3 px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-xl transition-colors"
                          >
                            <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center">
                              <Settings className="w-4 h-4 text-slate-500" />
                            </div>
                            <span className="font-medium">{t("nav.settings")}</span>
                          </Link>

                          <Link
                            to={createPageUrl("Support")}
                            onClick={closeAllOverlays}
                            className="flex items-center gap-3 px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-xl transition-colors"
                          >
                            <div className="w-8 h-8 rounded-lg flex items-center justify-center overflow-hidden bg-slate-100">
                              <HelpCircle className="w-4 h-4 text-slate-500" />
                            </div>
                            <span className="font-medium">{t("nav.support")}</span>
                          </Link>

                          <div className="h-px bg-slate-100 my-2" />

                          <button
                            type="button"
                            onClick={handleLogout}
                            className="flex items-center gap-3 px-3 py-2.5 text-sm text-red-600 hover:bg-red-50 rounded-xl w-full text-left transition-colors"
                          >
                            <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                              <LogOut className="w-4 h-4 text-red-600" />
                            </div>
                            <span className="font-medium">{t("nav.logout")}</span>
                          </button>
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </header>

          {/* Mobile header */}
          <header className="lg:hidden h-16 glass border-b border-slate-200/50 flex items-center justify-between px-4 sticky top-0 z-30 shadow-sm">
            <Link to={createPageUrl("Landing")} className="flex items-center">
              <motion.img whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }} src={LOGO_URL} alt="DRIVEE" className="h-10 object-contain" />
            </Link>

            <div className="flex items-center gap-2">
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  closeAllOverlays();
                  setShowSearch(true);
                }}
                className="p-2.5 text-slate-500 hover:bg-slate-100 rounded-xl transition-colors"
              >
                <Search className="w-5 h-5" />
              </motion.button>

              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => setMobileMenuOpen((v) => !v)}
                className="p-2.5 text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
              >
                <AnimatePresence mode="wait">
                  {mobileMenuOpen ? (
                    <motion.div
                      key="close"
                      initial={{ rotate: -90, opacity: 0 }}
                      animate={{ rotate: 0, opacity: 1 }}
                      exit={{ rotate: 90, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <X className="w-6 h-6" />
                    </motion.div>
                  ) : (
                    <motion.div
                      key="menu"
                      initial={{ rotate: 90, opacity: 0 }}
                      animate={{ rotate: 0, opacity: 1 }}
                      exit={{ rotate: -90, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Menu className="w-6 h-6" />
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.button>
            </div>
          </header>

          {/* Mobile menu */}
          <AnimatePresence>
            {mobileMenuOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "calc(100vh - 64px)" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.28, ease: easing.premium }}
                className="lg:hidden fixed top-16 left-0 right-0 bg-white z-20 overflow-y-auto border-b border-slate-200 shadow-premium-xl"
              >
                <div className="p-4 space-y-6">
                  <div className="px-4 py-3 bg-gradient-to-r from-slate-50 to-slate-100/50 rounded-xl border border-slate-200/50">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                          {t("layout.currentView")}
                        </p>
                        <p className="text-sm font-semibold text-slate-700">{t(`layout.${portalTypeKey}`)}</p>
                      </div>
                      <div className={["w-3 h-3 rounded-full bg-gradient-to-br", portalGradient].join(" ")} />
                    </div>
                  </div>

                  {navigation.map((navSection, idx) => (
                    <motion.div
                      key={`${navSection.section}_${idx}`}
                      initial={{ opacity: 0, y: 16 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                    >
                      <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-3 px-1">
                        {navSection.section}
                      </p>
                      <div className="grid grid-cols-2 gap-3">
                        {navSection.items.map((item) => {
                          const isActive = location.pathname === createPageUrl(item.path);
                          return (
                            <Link
                              key={item.path}
                              to={createPageUrl(item.path)}
                              onClick={() => setMobileMenuOpen(false)}
                              className={[
                                "flex flex-col items-center justify-center p-4 rounded-2xl border-2 transition-all",
                                isActive
                                  ? "bg-[#e8f4fa] border-[#a9d5ed] text-[#3b82c4]"
                                  : "bg-slate-50/50 border-slate-100 text-slate-600 hover:border-slate-200",
                              ].join(" ")}
                            >
                              <div
                                className={[
                                  "w-10 h-10 rounded-xl flex items-center justify-center mb-2",
                                  isActive ? "bg-[#d4eaf5]" : "bg-white",
                                ].join(" ")}
                              >
                                <item.icon className={["w-5 h-5", isActive ? "text-[#3b82c4]" : "text-slate-500"].join(" ")} />
                              </div>
                              <span className="text-xs font-semibold text-center">{item.name}</span>
                            </Link>
                          );
                        })}
                      </div>
                    </motion.div>
                  ))}

                  <div className="pt-4 border-t border-slate-100">
                    <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl mb-4">
                      <div className={["w-12 h-12 bg-gradient-to-br rounded-xl flex items-center justify-center text-white font-bold shadow-md", portalGradient].join(" ")}>
                        {user?.full_name?.charAt(0) || "U"}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900">{user?.full_name || "User"}</p>
                        <p className="text-xs text-slate-500">{getRoleDisplayName(user?.role)}</p>
                      </div>
                    </div>

                    <motion.button
                      whileTap={{ scale: 0.98 }}
                      onClick={handleLogout}
                      className="w-full py-3.5 text-sm font-semibold text-red-600 bg-red-50 hover:bg-red-100 rounded-xl flex items-center justify-center gap-2 transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      {t("nav.logout")}
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Content */}
          <main className="flex-1 p-4 lg:p-8 max-w-[1600px] mx-auto w-full">
            {loadingUser ? (
              <SkeletonLoader count={1} type="card" />
            ) : (
              children
            )}
          </main>

          {/* Help chat only for student pages */}
          {STUDENT_PAGES.includes(currentPageName) && user ? <HelpChat user={user} /> : null}
          </div>
          </div>
          </CelebrationProvider>
          </ErrorBoundary>
          </RouteGuard>
          );
          }