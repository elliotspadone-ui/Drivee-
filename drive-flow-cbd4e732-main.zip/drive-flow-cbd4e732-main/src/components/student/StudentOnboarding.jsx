import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { User, Mail, Phone, MapPin, GraduationCap, Loader2, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import VeeMascot from "@/components/common/VeeMascot";
import { logger } from "@/components/utils/config";

function normalizeEmail(email) {
  return email?.trim().toLowerCase() || "";
}

export default function StudentOnboarding({ user, onComplete }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    full_name: user?.full_name || "",
    email: normalizeEmail(user?.email) || "",
    phone: user?.phone || "",
    operating_country: "FR",
    required_hours: 40,
  });

  const createStudentMutation = useMutation({
    mutationFn: async (data) => {
      const normalizedEmail = normalizeEmail(data.email);
      
      // Check for existing student to prevent duplicates
      try {
        const existing = await base44.entities.Student.filter({ email: normalizedEmail }, "-created_date", 1);
        if (existing && existing.length > 0) {
          logger.warn("Student already exists for email:", normalizedEmail);
          const student = existing[0];
          
          // Link to user if not already linked
          if (user?.email) {
            try {
              await base44.auth.updateMe({ student_id: student.id });
            } catch (err) {
              logger.warn("Could not link existing student to user:", err);
            }
          }
          
          return student;
        }
      } catch (err) {
        logger.warn("Could not check for existing student:", err);
      }

      // Get first available school
      const schools = await base44.entities.School.filter({ is_active: true }, "-created_date", 1);
      const schoolId = schools && schools.length > 0 ? schools[0].id : null;

      if (!schoolId) {
        throw new Error("No school available. Please contact support.");
      }

      // Create new student
      const student = await base44.entities.Student.create({
        full_name: data.full_name.trim(),
        email: normalizedEmail,
        phone: data.phone?.trim() || "",
        school_id: schoolId,
        license_category: "B",
        required_hours: Number(data.required_hours) || 40,
        is_active: true,
      });

      // Link student to user
      if (student?.id && user?.email) {
        try {
          await base44.auth.updateMe({ student_id: student.id });
        } catch (err) {
          logger.warn("Could not link student_id to user:", err);
        }
      }

      return student;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["studentAuth"] });
      queryClient.invalidateQueries();
      toast.success("Profile created successfully!");
      setTimeout(() => onComplete?.(), 500);
    },
    onError: (error) => {
      logger.error("Failed to create student profile:", error);
      toast.error(error?.message || "Failed to create profile. Please try again.");
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.full_name || !formData.email) {
      toast.error("Please fill in all required fields");
      return;
    }
    createStudentMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-50 to-white flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-2xl"
      >
        <div className="bg-white rounded-3xl border border-zinc-200 shadow-xl p-8 md:p-12">
          <div className="flex flex-col items-center mb-8">
            <VeeMascot size="lg" mood="wave" animate={true} />
            <h1 className="text-3xl font-bold text-zinc-900 mt-6 mb-2">Welcome to DRIVEE!</h1>
            <p className="text-zinc-600 text-center max-w-md">
              Let's set up your learner profile so you can start booking lessons and tracking your progress.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-zinc-700 mb-2">
                Full Name <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                <input
                  type="text"
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                  placeholder="Enter your full name"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-zinc-700 mb-2">
                Email <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                  placeholder="your@email.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-zinc-700 mb-2">Phone (optional)</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                  placeholder="+33 6 12 34 56 78"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-2">Country</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  <select
                    value={formData.operating_country}
                    onChange={(e) => setFormData({ ...formData, operating_country: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4] appearance-none bg-white"
                  >
                    <option value="FR">France</option>
                    <option value="BE">Belgium</option>
                    <option value="DE">Germany</option>
                    <option value="ES">Spain</option>
                    <option value="IT">Italy</option>
                    <option value="NL">Netherlands</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-2">Required Hours</label>
                <div className="relative">
                  <GraduationCap className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  <input
                    type="number"
                    value={formData.required_hours}
                    onChange={(e) => setFormData({ ...formData, required_hours: parseInt(e.target.value) || 40 })}
                    className="w-full pl-10 pr-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                    min="20"
                    max="100"
                  />
                </div>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={createStudentMutation.isPending}
              className="w-full py-4 bg-gradient-to-r from-[#3b82c4] to-[#2563a3] hover:from-[#2563a3] hover:to-[#1e4f8a] text-white rounded-xl font-bold shadow-lg transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {createStudentMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Creating Profile...
                </>
              ) : (
                <>
                  Complete Setup
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </motion.button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}