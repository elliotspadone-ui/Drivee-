import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { logger, ENABLE_DEV_AUTH } from "@/components/utils/config";

/**
 * Production-ready authentication hook for student portal.
 * No demo fallbacks - requires real authentication.
 * 
 * Returns:
 * - effectiveUser: authenticated user from base44.auth.me()
 * - effectiveStudent: student record linked to user
 * - status: 'loading' | 'authenticated' | 'no_student' | 'unauthenticated'
 */

function normalizeEmail(email) {
  return email?.trim().toLowerCase() || "";
}

async function resolveStudentForUser(user) {
  if (!user) return null;

  // Priority 1: Use student_id from user metadata if available
  if (user.student_id) {
    try {
      const students = await base44.entities.Student.filter({ id: user.student_id }, "-created_date", 1);
      if (students && students.length > 0) {
        return students[0];
      }
    } catch (err) {
      logger.warn("Failed to fetch student by student_id:", err);
    }
  }

  // Priority 2: Lookup by email (normalized)
  const normalizedEmail = normalizeEmail(user.email);
  if (!normalizedEmail) return null;

  try {
    const students = await base44.entities.Student.filter({ email: normalizedEmail }, "-created_date", 5);
    if (!students || students.length === 0) return null;

    // If multiple matches, pick most recent
    if (students.length > 1) {
      logger.warn(`Multiple students found for email ${normalizedEmail}, using most recent`);
      students.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    }

    const student = students[0];
    
    // Update user metadata with student_id for future lookups
    if (student?.id && user?.email) {
      try {
        await base44.auth.updateMe({ student_id: student.id });
      } catch (err) {
        logger.warn("Could not update user student_id:", err);
      }
    }

    return student;
  } catch (err) {
    logger.error("Failed to fetch student by email:", err);
    return null;
  }
}

export function useStudentAuth() {
  return useQuery({
    queryKey: ["studentAuth"],
    queryFn: async () => {
      try {
        // DEV-only: Check for dev auth bypass
        if (ENABLE_DEV_AUTH) {
          const devUser = sessionStorage.getItem("dev_auth_user");
          if (devUser) {
            try {
              const parsedUser = JSON.parse(devUser);
              logger.auth("Using dev auth user:", parsedUser.email);
              const student = await resolveStudentForUser(parsedUser);
              return {
                effectiveUser: parsedUser,
                effectiveStudent: student,
                status: student ? "authenticated" : "no_student",
              };
            } catch (err) {
              logger.warn("Dev auth failed:", err);
            }
          }
        }

        // Production authentication
        const user = await base44.auth.me();
        if (!user) {
          return {
            effectiveUser: null,
            effectiveStudent: null,
            status: "unauthenticated",
          };
        }

        // Resolve student record
        const student = await resolveStudentForUser(user);

        if (!student) {
          return {
            effectiveUser: user,
            effectiveStudent: null,
            status: "no_student",
          };
        }

        return {
          effectiveUser: user,
          effectiveStudent: student,
          status: "authenticated",
        };
      } catch (err) {
        logger.error("Authentication failed:", err);
        return {
          effectiveUser: null,
          effectiveStudent: null,
          status: "unauthenticated",
        };
      }
    },
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });
}