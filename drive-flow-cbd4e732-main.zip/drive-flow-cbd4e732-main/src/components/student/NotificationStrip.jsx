import React, { useMemo } from "react";
import { AlertCircle, DollarSign, Calendar, FileText } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";

const COLOR_VARIANTS = {
  danger: {
    container: "bg-red-50 border-red-200",
    icon: "text-red-600",
    button: "bg-red-600 hover:bg-red-700",
  },
  warning: {
    container: "bg-amber-50 border-amber-200",
    icon: "text-amber-600",
    button: "bg-amber-600 hover:bg-amber-700",
  },
  info: {
    container: "bg-blue-50 border-blue-200",
    icon: "text-blue-600",
    button: "bg-blue-600 hover:bg-blue-700",
  },
};

function formatCurrency(amount, currency) {
  if (typeof amount !== "number") return null;

  const fallbackSymbol =
    currency === "GBP" ? "£" : currency === "USD" ? "$" : "€";

  try {
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency: currency || "EUR",
      maximumFractionDigits: 2,
      minimumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `${fallbackSymbol}${amount.toFixed(2)}`;
  }
}

function formatExam(upcomingExam) {
  if (!upcomingExam) return null;

  // String date or plain text
  if (typeof upcomingExam === "string") {
    const date = new Date(upcomingExam);

    if (!Number.isNaN(date.getTime())) {
      const dateLabel = date.toLocaleDateString(undefined, {
        weekday: "short",
        day: "numeric",
        month: "short",
      });
      const timeLabel = date.toLocaleTimeString(undefined, {
        hour: "2-digit",
        minute: "2-digit",
      });

      return {
        label: `Practical exam on ${dateLabel} at ${timeLabel}`,
      };
    }

    return {
      label: `Practical exam scheduled for ${upcomingExam}`,
    };
  }

  // Object form { date, center, location, time }
  if (typeof upcomingExam === "object" && upcomingExam.date) {
    const date = new Date(upcomingExam.date);
    const dateLabel = Number.isNaN(date.getTime())
      ? upcomingExam.date
      : date.toLocaleDateString(undefined, {
          weekday: "short",
          day: "numeric",
          month: "short",
        });

    const timeLabel =
      upcomingExam.time ||
      (!Number.isNaN(date.getTime())
        ? date.toLocaleTimeString(undefined, {
            hour: "2-digit",
            minute: "2-digit",
          })
        : null);

    const center = upcomingExam.center || upcomingExam.location;
    const parts = [];
    if (dateLabel) parts.push(dateLabel);
    if (timeLabel) parts.push(timeLabel);
    const when = parts.join(" at ");

    return {
      label: `Practical exam${center ? ` at ${center}` : ""} on ${when}`,
    };
  }

  return { label: "Practical exam scheduled" };
}

function formatMissingDocs(missingDocs) {
  if (!missingDocs) {
    return "Please upload your learner permit";
  }

  if (Array.isArray(missingDocs) && missingDocs.length > 0) {
    const labels = missingDocs.map((doc) => {
      if (typeof doc === "string") {
        return doc
          .replace(/_/g, " ")
          .replace(/\b\w/g, (l) => l.toUpperCase());
      }
      if (doc && doc.label) return doc.label;
      return "Document";
    });

    return `Missing documents: ${labels.join(", ")}`;
  }

  if (typeof missingDocs === "object" && missingDocs.label) {
    return missingDocs.label;
  }

  return "Please upload your learner permit";
}

export default function NotificationStrip({
  student,
  unpaidTotal,
  upcomingExam,
  missingDocs,
}) {
  const notifications = useMemo(() => {
    const items = [];

    const currency =
      student?.preferred_currency || student?.currency || "EUR";
    const hasUnpaid =
      typeof unpaidTotal === "number" && Number.isFinite(unpaidTotal) && unpaidTotal > 0;
    const amountLabel = hasUnpaid
      ? formatCurrency(unpaidTotal, currency)
      : null;

    if (hasUnpaid) {
      items.push({
        type: "payment",
        icon: DollarSign,
        variant: "danger",
        message:
          amountLabel != null
            ? `You have ${amountLabel} outstanding`
            : "You have an outstanding balance",
        actionLabel: "Pay Now",
        link: "StudentInvoices",
      });
    }

    const examInfo = formatExam(upcomingExam);
    if (examInfo) {
      items.push({
        type: "exam",
        icon: Calendar,
        variant: "warning",
        message: examInfo.label,
        actionLabel: "View Details",
        link: "StudentDashboard",
      });
    }

    if (missingDocs) {
      items.push({
        type: "docs",
        icon: FileText,
        variant: "info",
        message: formatMissingDocs(missingDocs),
        actionLabel: "Upload",
        link: "StudentDashboard",
      });
    }

    return items;
  }, [student, unpaidTotal, upcomingExam, missingDocs]);

  if (!notifications.length) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        className="space-y-2 mb-6"
        aria-live="polite"
      >
        {notifications.map((notif) => {
          const variant = COLOR_VARIANTS[notif.variant] || COLOR_VARIANTS.info;
          const Icon = notif.icon;

          return (
            <div
              key={notif.type}
              className={`flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 rounded-2xl border-2 px-4 py-3 sm:px-5 sm:py-4 ${variant.container}`}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  <Icon className={`w-5 h-5 ${variant.icon}`} />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="inline-flex items-center gap-1 rounded-full bg-white/70 px-2.5 py-0.5 text-xs font-semibold text-gray-700">
                      <AlertCircle className="w-3 h-3" />
                      Important
                    </span>
                    {student?.first_name && (
                      <span className="text-xs text-gray-500">
                        For {student.first_name}
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-medium text-gray-900">
                    {notif.message}
                  </p>
                </div>
              </div>

              {notif.link && notif.actionLabel && (
                <Link
                  to={createPageUrl(notif.link)}
                  className="inline-flex self-stretch sm:self-auto"
                >
                  <button
                    type="button"
                    className={`ml-auto inline-flex w-full items-center justify-center rounded-xl px-4 py-2 text-sm font-semibold text-white shadow-sm sm:w-auto ${variant.button}`}
                  >
                    {notif.actionLabel}
                  </button>
                </Link>
              )}
            </div>
          );
        })}
      </motion.div>
    </AnimatePresence>
  );
}
