import React, { useEffect } from "react";
import { X, MapPin, Clock, Car, FileText, CheckCircle, AlertCircle } from "lucide-react";
import { format, differenceInMinutes, differenceInCalendarDays, isToday, isTomorrow } from "date-fns";
import { motion } from "framer-motion";

export default function LessonDetailsDrawer({ booking, instructor, vehicle, onClose }) {
  if (!booking) return null;

  const start = new Date(booking.start_datetime);
  const end = new Date(booking.end_datetime);
  const durationMinutes = differenceInMinutes(end, start);
  const dayDiff = differenceInCalendarDays(start, new Date());

  let relativeLabel = "";
  if (isToday(start)) {
    relativeLabel = "Today";
  } else if (isTomorrow(start)) {
    relativeLabel = "Tomorrow";
  } else if (dayDiff > 0) {
    relativeLabel = `In ${dayDiff} day${dayDiff > 1 ? "s" : ""}`;
  } else if (dayDiff < 0) {
    const abs = Math.abs(dayDiff);
    relativeLabel = `${abs} day${abs > 1 ? "s" : ""} ago`;
  }

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        onClose?.();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  const handleOverlayClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose?.();
    }
  };

  const vehicleLabel = vehicle
    ? `${vehicle.make || ""} ${vehicle.model || ""} ${vehicle.year ? `(${vehicle.year})` : ""}`.trim()
    : "Not assigned";

  return (
    <div
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end md:items-center justify-center p-4"
      onClick={handleOverlayClick}
    >
      <motion.div
        role="dialog"
        aria-modal="true"
        aria-label="Lesson details"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b p-6 flex items-center justify-between rounded-t-3xl">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Lesson Details</h2>
            {relativeLabel && (
              <p className="text-sm text-gray-500 mt-1">{relativeLabel}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-xl"
            aria-label="Close lesson details"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Date & Time */}
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <Clock className="w-5 h-5 text-indigo-600" />
              <h3 className="font-semibold text-gray-900">Date & Time</h3>
            </div>
            <p className="text-lg font-bold text-gray-900">
              {format(start, "EEEE, MMMM d, yyyy")}
            </p>
            <p className="text-gray-700">
              {format(start, "h:mm a")} - {format(end, "h:mm a")}
              {Number.isFinite(durationMinutes) && (
                <span className="ml-2 text-sm text-gray-500">
                  ({durationMinutes} min)
                </span>
              )}
            </p>
            {booking.lesson_type && (
              <p className="mt-2 inline-flex items-center rounded-full bg-white/70 px-3 py-1 text-xs font-medium text-gray-700 capitalize">
                {booking.lesson_type.replace("_", " ")}
              </p>
            )}
          </div>

          {/* Instructor */}
          <div className="border-2 border-gray-200 rounded-2xl p-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">
                  {instructor?.full_name?.charAt(0) || "I"}
                </span>
              </div>
              <div>
                <p className="text-xs uppercase tracking-wide text-gray-500">Instructor</p>
                <p className="font-bold text-gray-900">
                  {instructor?.full_name || "Not assigned"}
                </p>
                {instructor?.phone && (
                  <a
                    href={`tel:${instructor.phone}`}
                    className="text-sm text-indigo-600 hover:underline"
                  >
                    {instructor.phone}
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Vehicle */}
          <div className="border-2 border-gray-200 rounded-2xl p-4 flex items-center gap-4">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <Car className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-xs uppercase tracking-wide text-gray-500">Vehicle</p>
              <p className="font-bold text-gray-900">
                {vehicleLabel || "Not assigned"}
              </p>
              {vehicle?.transmission && (
                <p className="text-xs text-gray-600">{vehicle.transmission}</p>
              )}
            </div>
          </div>

          {/* Pickup Location */}
          {booking.pickup_location && (
            <div className="border-2 border-gray-200 rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-pink-600 mt-1" />
                <div className="flex-1">
                  <p className="text-xs uppercase tracking-wide text-gray-500 mb-1">
                    Pickup Location
                  </p>
                  <p className="font-semibold text-gray-900">
                    {booking.pickup_location}
                  </p>
                  <a
                    href={`https://maps.google.com/?q=${encodeURIComponent(
                      booking.pickup_location
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-indigo-600 hover:underline mt-2 inline-block"
                  >
                    Open in Maps →
                  </a>
                </div>
              </div>
            </div>
          )}

          {/* Pre-Lesson Notes */}
          {booking.pre_lesson_notes && (
            <div className="bg-blue-50 rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <FileText className="w-5 h-5 text-blue-600 mt-1" />
                <div>
                  <p className="font-semibold text-gray-900 mb-1">
                    Pre-lesson notes
                  </p>
                  <p className="text-sm text-gray-700">
                    {booking.pre_lesson_notes}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Last Lesson Summary */}
          {booking.last_lesson_summary && (
            <div className="bg-green-50 rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-600 mt-1" />
                <div>
                  <p className="font-semibold text-gray-900 mb-1">
                    Last lesson summary
                  </p>
                  <p className="text-sm text-gray-700">
                    {booking.last_lesson_summary}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* What to bring */}
          {(booking.lesson_type === "practical_driving" || !booking.lesson_type) && (
            <div className="bg-yellow-50 rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-600 mt-1" />
                <div>
                  <p className="font-semibold text-gray-900 mb-2">
                    What to bring
                  </p>
                  <ul className="text-sm text-gray-700 space-y-1">
                    <li>• Valid learner permit</li>
                    <li>• Comfortable shoes</li>
                    <li>• Glasses or contacts if needed</li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
