import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import {
  Target,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  CheckCircle,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Calendar,
  Clock,
  DollarSign,
  Users,
  Car,
  Award,
  Zap,
  Activity,
  BarChart3,
  PieChart,
  LineChart,
  ArrowUpRight,
  ArrowDownRight,
  Info,
  HelpCircle,
  Settings,
  Edit,
  Save,
  X,
  RefreshCw,
  Download,
  Share2,
  Copy,
  Bell,
  BellOff,
  Flag,
  Star,
  Sparkles,
  Rocket,
  Trophy,
  Medal,
  Crown,
  Flame,
  Timer,
  CalendarDays,
  MoreVertical,
  ExternalLink,
  Loader2,
  Play,
  Pause,
  SkipForward,
  History,
  Eye,
  EyeOff
} from "lucide-react";
import {
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Area,
  ComposedChart
} from "recharts";
import { format, differenceInDays, addDays, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isAfter, isBefore, parseISO } from "date-fns";

const GOAL_STATUS = {
  exceeded: {
    id: "exceeded",
    label: "Exceeded",
    emoji: "🎉",
    icon: Trophy,
    color: "green",
    bgColor: "bg-green-50",
    textColor: "text-green-600",
    borderColor: "border-green-200",
    gradient: "from-green-500 to-emerald-500",
    barGradient: "from-green-600 to-emerald-600",
    description: "Goal exceeded! Fantastic achievement!"
  },
  achieved: {
    id: "achieved",
    label: "Achieved",
    emoji: "✅",
    icon: CheckCircle,
    color: "emerald",
    bgColor: "bg-emerald-50",
    textColor: "text-emerald-600",
    borderColor: "border-emerald-200",
    gradient: "from-emerald-500 to-teal-500",
    barGradient: "from-emerald-600 to-teal-600",
    description: "Goal achieved! Great work!"
  },
  onTrack: {
    id: "onTrack",
    label: "On Track",
    emoji: "🟢",
    icon: TrendingUp,
    color: "blue",
    bgColor: "bg-blue-50",
    textColor: "text-blue-600",
    borderColor: "border-blue-200",
    gradient: "from-blue-500 to-indigo-500",
    barGradient: "from-indigo-600 to-purple-600",
    description: "Great progress! Keep it up!"
  },
  slightlyBehind: {
    id: "slightlyBehind",
    label: "Slightly Behind",
    emoji: "🟡",
    icon: AlertCircle,
    color: "amber",
    bgColor: "bg-amber-50",
    textColor: "text-amber-600",
    borderColor: "border-amber-200",
    gradient: "from-amber-500 to-orange-500",
    barGradient: "from-amber-500 to-orange-500",
    description: "A little behind schedule, but recoverable"
  },
  atRisk: {
    id: "atRisk",
    label: "At Risk",
    emoji: "🟠",
    icon: AlertTriangle,
    color: "orange",
    bgColor: "bg-orange-50",
    textColor: "text-orange-600",
    borderColor: "border-orange-200",
    gradient: "from-orange-500 to-red-500",
    barGradient: "from-orange-500 to-red-500",
    description: "Needs attention to get back on track"
  },
  critical: {
    id: "critical",
    label: "Critical",
    emoji: "🔴",
    icon: AlertCircle,
    color: "red",
    bgColor: "bg-red-50",
    textColor: "text-red-600",
    borderColor: "border-red-200",
    gradient: "from-red-500 to-rose-500",
    barGradient: "from-red-500 to-pink-500",
    description: "Significantly behind, urgent action needed"
  }
};

const GOAL_TYPES = {
  revenue: { id: "revenue", label: "Revenue", icon: DollarSign, unit: "€", color: "green" },
  bookings: { id: "bookings", label: "Bookings", icon: Calendar, unit: "", color: "blue" },
  students: { id: "students", label: "New Students", icon: Users, unit: "", color: "purple" },
  lessons: { id: "lessons", label: "Lessons", icon: Car, unit: "", color: "indigo" },
  passRate: { id: "passRate", label: "Pass Rate", icon: Award, unit: "%", color: "amber" },
  retention: { id: "retention", label: "Retention", icon: Users, unit: "%", color: "teal" },
  custom: { id: "custom", label: "Custom", icon: Target, unit: "", color: "gray" }
};

const TIMEFRAMES = [
  { id: "daily", label: "Daily", days: 1 },
  { id: "weekly", label: "Weekly", days: 7 },
  { id: "monthly", label: "Monthly", days: 30 },
  { id: "quarterly", label: "Quarterly", days: 90 },
  { id: "yearly", label: "Yearly", days: 365 }
];

export default function GoalProgress({
  title,
  current,
  target,
  unit = "€",
  type = "revenue",
  daysLeft,
  startDate,
  endDate,
  previousPeriodValue,
  historicalData = [],
  milestones = [],
  notes,
  onEdit,
  onDelete,
  onNotificationToggle,
  onShare,
  isEditable = false,
  showChart = true,
  showMilestones = true,
  showProjection = true,
  showComparison = true,
  showActions = true,
  compact = false,
  animated = true,
  highlighted = false,
  notificationsEnabled = true,
  className = ""
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedTarget, setEditedTarget] = useState(target);
  const [showDetails, setShowDetails] = useState(false);
  const [animatedCurrent, setAnimatedCurrent] = useState(0);
  const [animatedProgress, setAnimatedProgress] = useState(0);
  const progressRef = useRef(null);

  const progress = useMemo(() => {
    return target > 0 ? (current / target) * 100 : 0;
  }, [current, target]);

  const remaining = useMemo(() => target - current, [current, target]);

  const dailyNeeded = useMemo(() => {
    if (daysLeft <= 0 || remaining <= 0) return 0;
    return remaining / daysLeft;
  }, [remaining, daysLeft]);

  const status = useMemo(() => {
    if (progress >= 100) return GOAL_STATUS.exceeded;
    if (progress >= 95) return GOAL_STATUS.achieved;
    
    const expectedProgress = daysLeft !== undefined && startDate && endDate
      ? ((differenceInDays(new Date(), new Date(startDate)) / differenceInDays(new Date(endDate), new Date(startDate))) * 100)
      : null;

    if (expectedProgress !== null) {
      const progressDiff = progress - expectedProgress;
      if (progressDiff >= 5) return GOAL_STATUS.onTrack;
      if (progressDiff >= -5) return GOAL_STATUS.slightlyBehind;
      if (progressDiff >= -15) return GOAL_STATUS.atRisk;
      return GOAL_STATUS.critical;
    }

    if (progress >= 90) return GOAL_STATUS.onTrack;
    if (progress >= 75) return GOAL_STATUS.slightlyBehind;
    if (progress >= 50) return GOAL_STATUS.atRisk;
    return GOAL_STATUS.critical;
  }, [progress, daysLeft, startDate, endDate]);

  const projectedValue = useMemo(() => {
    if (!startDate || !endDate || !daysLeft) return null;
    
    const totalDays = differenceInDays(new Date(endDate), new Date(startDate));
    const elapsedDays = totalDays - daysLeft;
    
    if (elapsedDays <= 0) return current;
    
    const dailyRate = current / elapsedDays;
    return dailyRate * totalDays;
  }, [current, startDate, endDate, daysLeft]);

  const projectedStatus = useMemo(() => {
    if (!projectedValue || !target) return null;
    const projectedProgress = (projectedValue / target) * 100;
    
    if (projectedProgress >= 100) return "on-track";
    if (projectedProgress >= 90) return "close";
    if (projectedProgress >= 75) return "at-risk";
    return "unlikely";
  }, [projectedValue, target]);

  const comparisonChange = useMemo(() => {
    if (!previousPeriodValue || previousPeriodValue === 0) return null;
    return ((current - previousPeriodValue) / previousPeriodValue) * 100;
  }, [current, previousPeriodValue]);

  const chartData = useMemo(() => {
    if (!historicalData || historicalData.length === 0) {
      if (!startDate || !endDate) return [];
      
      const days = eachDayOfInterval({
        start: new Date(startDate),
        end: new Date()
      });

      const totalDays = differenceInDays(new Date(endDate), new Date(startDate));
      
      return days.map((day, index) => {
        const dayProgress = (index / totalDays) * target;
        const actualProgress = Math.min(current, dayProgress * (1 + (Math.random() - 0.5) * 0.3));
        
        return {
          date: format(day, "MMM d"),
          actual: Math.round(actualProgress),
          expected: Math.round(dayProgress),
          target: target
        };
      });
    }
    
    return historicalData;
  }, [historicalData, startDate, endDate, current, target]);

  const activeMilestones = useMemo(() => {
    return milestones.map(milestone => ({
      ...milestone,
      achieved: current >= milestone.value,
      progress: target > 0 ? (milestone.value / target) * 100 : 0
    }));
  }, [milestones, current, target]);

  useEffect(() => {
    if (!animated) {
      setAnimatedCurrent(current);
      setAnimatedProgress(progress);
      return;
    }

    const duration = 1000;
    const startTime = Date.now();
    const startValue = 0;

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progressRatio = Math.min(elapsed / duration, 1);
      const easeProgress = 1 - Math.pow(1 - progressRatio, 3);

      setAnimatedCurrent(startValue + (current - startValue) * easeProgress);
      setAnimatedProgress(easeProgress * progress);

      if (progressRatio < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [current, progress, animated]);

  const handleSaveEdit = useCallback(() => {
    if (onEdit && editedTarget !== target) {
      onEdit({ target: editedTarget });
    }
    setIsEditing(false);
  }, [editedTarget, target, onEdit]);

  const handleCancelEdit = useCallback(() => {
    setEditedTarget(target);
    setIsEditing(false);
  }, [target]);

  const formatValue = useCallback((value, includeUnit = true) => {
    if (value === null || value === undefined) return "—";
    
    const formattedNumber = new Intl.NumberFormat("en-IE", {
      minimumFractionDigits: 0,
      maximumFractionDigits: type === "passRate" || type === "retention" ? 1 : 0
    }).format(value);

    if (!includeUnit) return formattedNumber;
    
    if (unit === "€") return `€${formattedNumber}`;
    if (unit === "%") return `${formattedNumber}%`;
    return formattedNumber;
  }, [unit, type]);

  const formatCompact = useCallback((value) => {
    if (value >= 1000000) return `${unit}${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${unit}${(value / 1000).toFixed(1)}K`;
    return formatValue(value);
  }, [unit, formatValue]);

  const typeConfig = GOAL_TYPES[type] || GOAL_TYPES.custom;
  const StatusIcon = status.icon;
  const TypeIcon = typeConfig.icon;

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;

    return (
      <div className="bg-white p-3 rounded-xl shadow-lg border border-gray-200 text-sm">
        <p className="font-semibold text-gray-900 mb-2">{label}</p>
        {payload.map((entry, index) => (
          <div key={index} className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div
                className="w-2 h-2 rounded-full"
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-gray-600">{entry.name}:</span>
            </div>
            <span className="font-semibold">{formatValue(entry.value)}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div
      className={`
        bg-white rounded-2xl border transition-all duration-300
        ${highlighted ? "border-indigo-300 ring-2 ring-indigo-100" : "border-gray-200"}
        ${isExpanded ? "shadow-lg" : "hover:shadow-lg"}
        ${className}
      `}
    >
      <div className={`${compact ? "p-4" : "p-6"}`}>
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start gap-3">
            <div className={`
              ${compact ? "w-10 h-10" : "w-12 h-12"} 
              ${status.id === 'exceeded' ? 'bg-gradient-to-br from-green-500 to-emerald-500' :
                status.id === 'achieved' ? 'bg-gradient-to-br from-emerald-500 to-teal-500' :
                status.id === 'onTrack' ? 'bg-gradient-to-br from-blue-500 to-indigo-500' :
                status.id === 'slightlyBehind' ? 'bg-gradient-to-br from-amber-500 to-orange-500' :
                status.id === 'atRisk' ? 'bg-gradient-to-br from-orange-500 to-red-500' :
                'bg-gradient-to-br from-red-500 to-rose-500'}
              rounded-xl flex items-center justify-center flex-shrink-0
            `}>
              <TypeIcon className={`${compact ? "w-5 h-5" : "w-6 h-6"} text-white`} />
            </div>
            <div>
              <p className={`font-medium text-gray-600 ${compact ? "text-xs" : "text-sm"} mb-1`}>
                {title}
              </p>
              <div className="flex items-baseline gap-2">
                <p className={`font-bold text-gray-900 tabular-nums ${compact ? "text-2xl" : "text-3xl"}`}>
                  {formatValue(animatedCurrent)}
                </p>
                <span className="text-gray-400">/</span>
                {isEditing ? (
                  <input
                    type="number"
                    value={editedTarget}
                    onChange={(e) => setEditedTarget(parseFloat(e.target.value) || 0)}
                    className="w-24 px-2 py-1 border border-gray-300 rounded-lg text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    autoFocus
                  />
                ) : (
                  <p className={`text-gray-500 tabular-nums ${compact ? "text-lg" : "text-xl"}`}>
                    {formatValue(target)}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className={`${
              status.id === 'exceeded' ? 'bg-green-50' :
              status.id === 'achieved' ? 'bg-emerald-50' :
              status.id === 'onTrack' ? 'bg-blue-50' :
              status.id === 'slightlyBehind' ? 'bg-amber-50' :
              status.id === 'atRisk' ? 'bg-orange-50' :
              'bg-red-50'
            } px-3 py-1.5 rounded-lg flex items-center gap-2`}>
              <StatusIcon className={`w-4 h-4 ${
                status.id === 'exceeded' ? 'text-green-600' :
                status.id === 'achieved' ? 'text-emerald-600' :
                status.id === 'onTrack' ? 'text-blue-600' :
                status.id === 'slightlyBehind' ? 'text-amber-600' :
                status.id === 'atRisk' ? 'text-orange-600' :
                'text-red-600'
              }`} />
              <span className={`text-sm font-semibold ${
                status.id === 'exceeded' ? 'text-green-600' :
                status.id === 'achieved' ? 'text-emerald-600' :
                status.id === 'onTrack' ? 'text-blue-600' :
                status.id === 'slightlyBehind' ? 'text-amber-600' :
                status.id === 'atRisk' ? 'text-orange-600' :
                'text-red-600'
              }`}>
                {status.label} {status.emoji}
              </span>
            </div>

            {showActions && (
              <div className="flex items-center gap-1">
                {isEditing ? (
                  <>
                    <button
                      onClick={handleSaveEdit}
                      className="p-1.5 bg-green-100 text-green-600 rounded-lg hover:bg-green-200 transition"
                    >
                      <Save className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleCancelEdit}
                      className="p-1.5 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <>
                    {isEditable && (
                      <button
                        onClick={() => setIsEditing(true)}
                        className="p-1.5 hover:bg-gray-100 rounded-lg transition"
                      >
                        <Edit className="w-4 h-4 text-gray-400" />
                      </button>
                    )}
                    <button
                      onClick={() => setIsExpanded(!isExpanded)}
                      className="p-1.5 hover:bg-gray-100 rounded-lg transition"
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-gray-400" />
                      )}
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">Progress</span>
              <span className="text-sm font-bold text-gray-900 tabular-nums">
                {animatedProgress.toFixed(1)}%
              </span>
            </div>
            <div className="relative">
              <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                <div
                  ref={progressRef}
                  className={`h-full bg-gradient-to-r ${status.barGradient} transition-all duration-500 rounded-full`}
                  style={{ width: `${Math.min(animatedProgress, 100)}%` }}
                />
              </div>

              {showMilestones && activeMilestones.length > 0 && (
                <div className="absolute inset-0 pointer-events-none">
                  {activeMilestones.map((milestone, index) => (
                    <div
                      key={index}
                      className="absolute top-0 h-full flex items-center"
                      style={{ left: `${milestone.progress}%` }}
                    >
                      <div
                        className={`w-1 h-5 -mt-1 rounded-full transition-colors ${
                          milestone.achieved ? "bg-green-500" : "bg-gray-300"
                        }`}
                        title={`${milestone.label}: ${formatValue(milestone.value)}`}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 bg-gray-50 rounded-xl">
              <p className="text-xs text-gray-500 mb-1">Remaining</p>
              <p className={`font-bold ${remaining > 0 ? "text-gray-900" : "text-green-600"}`}>
                {remaining > 0 ? formatValue(remaining) : "Goal Met!"}
              </p>
            </div>

            {daysLeft !== undefined && daysLeft > 0 && (
              <div className="p-3 bg-gray-50 rounded-xl">
                <p className="text-xs text-gray-500 mb-1">Days Left</p>
                <p className="font-bold text-gray-900">{daysLeft}</p>
              </div>
            )}

            {dailyNeeded > 0 && status.id !== "exceeded" && status.id !== "achieved" && (
              <div className="p-3 bg-gray-50 rounded-xl">
                <p className="text-xs text-gray-500 mb-1">Daily Needed</p>
                <p className="font-bold text-gray-900">{formatValue(dailyNeeded)}/day</p>
              </div>
            )}

            {showComparison && comparisonChange !== null && (
              <div className="p-3 bg-gray-50 rounded-xl">
                <p className="text-xs text-gray-500 mb-1">vs Last Period</p>
                <div className={`flex items-center gap-1 font-bold ${
                  comparisonChange >= 0 ? "text-green-600" : "text-red-600"
                }`}>
                  {comparisonChange >= 0 ? (
                    <ArrowUpRight className="w-4 h-4" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4" />
                  )}
                  {Math.abs(comparisonChange).toFixed(1)}%
                </div>
              </div>
            )}
          </div>

          {showProjection && projectedValue && status.id !== "exceeded" && status.id !== "achieved" && (
            <div className={`p-3 rounded-xl ${
              projectedStatus === "on-track" ? "bg-green-50 border border-green-200" :
              projectedStatus === "close" ? "bg-blue-50 border border-blue-200" :
              projectedStatus === "at-risk" ? "bg-amber-50 border border-amber-200" :
              "bg-red-50 border border-red-200"
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Rocket className={`w-4 h-4 ${
                    projectedStatus === "on-track" ? "text-green-600" :
                    projectedStatus === "close" ? "text-blue-600" :
                    projectedStatus === "at-risk" ? "text-amber-600" :
                    "text-red-600"
                  }`} />
                  <span className="text-sm font-medium text-gray-700">Projected at end of period:</span>
                </div>
                <span className={`font-bold ${
                  projectedStatus === "on-track" ? "text-green-600" :
                  projectedStatus === "close" ? "text-blue-600" :
                  projectedStatus === "at-risk" ? "text-amber-600" :
                  "text-red-600"
                }`}>
                  {formatValue(projectedValue)} ({((projectedValue / target) * 100).toFixed(0)}%)
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {isExpanded && (
        <div className="border-t border-gray-200">
          {showChart && chartData.length > 0 && (
            <div className={`${compact ? "p-4" : "p-6"} border-b border-gray-200`}>
              <h4 className="font-semibold text-gray-900 mb-4">Progress Over Time</h4>
              <ResponsiveContainer width="100%" height={200}>
                <ComposedChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="#9ca3af" />
                  <YAxis tickFormatter={(v) => formatCompact(v)} tick={{ fontSize: 11 }} stroke="#9ca3af" />
                  <Tooltip content={<CustomTooltip />} />
                  <ReferenceLine y={target} stroke="#6366f1" strokeDasharray="5 5" label={{ value: "Target", fill: "#6366f1", fontSize: 11 }} />
                  <Area type="monotone" dataKey="expected" fill="#e0e7ff" stroke="#a5b4fc" strokeWidth={1} fillOpacity={0.5} name="Expected" />
                  <Line type="monotone" dataKey="actual" stroke="#6366f1" strokeWidth={2} dot={false} name="Actual" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          )}

          {showMilestones && activeMilestones.length > 0 && (
            <div className={`${compact ? "p-4" : "p-6"} border-b border-gray-200`}>
              <h4 className="font-semibold text-gray-900 mb-4">Milestones</h4>
              <div className="space-y-3">
                {activeMilestones.map((milestone, index) => (
                  <div
                    key={index}
                    className={`flex items-center justify-between p-3 rounded-xl ${
                      milestone.achieved ? "bg-green-50" : "bg-gray-50"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        milestone.achieved ? "bg-green-100" : "bg-gray-200"
                      }`}>
                        {milestone.achieved ? (
                          <CheckCircle className="w-5 h-5 text-green-600" />
                        ) : (
                          <Target className="w-5 h-5 text-gray-400" />
                        )}
                      </div>
                      <div>
                        <p className={`font-medium ${milestone.achieved ? "text-green-700" : "text-gray-700"}`}>
                          {milestone.label}
                        </p>
                        <p className="text-sm text-gray-500">{formatValue(milestone.value)}</p>
                      </div>
                    </div>
                    {milestone.achieved && milestone.achievedDate && (
                      <span className="text-xs text-green-600">
                        Achieved {format(new Date(milestone.achievedDate), "MMM d")}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {notes && (
            <div className={`${compact ? "p-4" : "p-6"}`}>
              <h4 className="font-semibold text-gray-900 mb-2">Notes</h4>
              <p className="text-sm text-gray-600">{notes}</p>
            </div>
          )}

          <div className={`${compact ? "p-4" : "p-6"} bg-gray-50 flex items-center justify-between`}>
            <div className="flex items-center gap-2">
              {onNotificationToggle && (
                <button
                  onClick={() => onNotificationToggle(!notificationsEnabled)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                    notificationsEnabled
                      ? "bg-indigo-100 text-indigo-700"
                      : "bg-gray-200 text-gray-600"
                  }`}
                >
                  {notificationsEnabled ? (
                    <Bell className="w-4 h-4" />
                  ) : (
                    <BellOff className="w-4 h-4" />
                  )}
                  {notificationsEnabled ? "Notifications On" : "Notifications Off"}
                </button>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              {onShare && (
                <button
                  onClick={onShare}
                  className="p-2 hover:bg-gray-200 rounded-lg transition"
                  title="Share"
                >
                  <Share2 className="w-4 h-4 text-gray-600" />
                </button>
              )}
              {onDelete && (
                <button
                  onClick={onDelete}
                  className="p-2 hover:bg-red-100 rounded-lg transition"
                  title="Delete Goal"
                >
                  <X className="w-4 h-4 text-red-600" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function GoalProgressCompact({ title, current, target, unit = "€", status: statusOverride }) {
  const progress = target > 0 ? (current / target) * 100 : 0;
  
  const status = statusOverride || (
    progress >= 100 ? GOAL_STATUS.exceeded :
    progress >= 90 ? GOAL_STATUS.onTrack :
    progress >= 75 ? GOAL_STATUS.slightlyBehind :
    progress >= 50 ? GOAL_STATUS.atRisk :
    GOAL_STATUS.critical
  );

  const formatValue = (value) => {
    if (unit === "€") return `€${value.toLocaleString()}`;
    if (unit === "%") return `${value}%`;
    return value.toLocaleString();
  };

  return (
    <div className="flex items-center gap-3">
      <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${status.gradient}`} />
      <div className="flex-1 min-w-0">
        <p className="text-sm text-gray-600 truncate">{title}</p>
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-gray-900">{formatValue(current)}</span>
          <span className="text-xs text-gray-400">/ {formatValue(target)}</span>
        </div>
      </div>
      <div className="text-right">
        <span className={`text-sm font-bold ${status.textColor}`}>
          {progress.toFixed(0)}%
        </span>
      </div>
    </div>
  );
}

export function GoalProgressRing({ current, target, size = 80, strokeWidth = 8, color = "indigo" }) {
  const progress = target > 0 ? Math.min((current / target) * 100, 100) : 0;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="w-full h-full transform -rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#e5e7eb"
          strokeWidth={strokeWidth}
          fill="none"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={`url(#gradient-${color})`}
          strokeWidth={strokeWidth}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
        />
        <defs>
          <linearGradient id={`gradient-${color}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={color === "green" ? "#10b981" : color === "red" ? "#ef4444" : "#6366f1"} />
            <stop offset="100%" stopColor={color === "green" ? "#34d399" : color === "red" ? "#f87171" : "#a855f7"} />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-lg font-bold text-gray-900">{progress.toFixed(0)}%</span>
      </div>
    </div>
  );
}

export function GoalProgressGrid({ goals = [], columns = 2, className = "" }) {
  return (
    <div className={`grid grid-cols-1 md:grid-cols-${columns} gap-4 ${className}`}>
      {goals.map((goal, index) => (
        <GoalProgress key={goal.id || index} {...goal} />
      ))}
    </div>
  );
}