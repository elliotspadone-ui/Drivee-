import React, { useState, useEffect, useMemo, useCallback } from "react";
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip, 
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
  ComposedChart,
  Area
} from "recharts";
import { 
  AlertTriangle, 
  Clock, 
  DollarSign, 
  Mail, 
  Phone,
  Send,
  Download,
  Filter,
  RefreshCw,
  Search,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  CheckCircle,
  XCircle,
  Calendar,
  User,
  FileText,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  Info,
  Eye,
  Edit,
  Trash2,
  MoreVertical,
  Bell,
  BellOff,
  MessageSquare,
  CreditCard,
  Banknote,
  Receipt,
  ArrowUpRight,
  ArrowDownRight,
  Percent,
  Target,
  Zap,
  Settings,
  Loader2,
  ExternalLink,
  Copy,
  Printer,
  History,
  Flag,
  Star,
  Users,
  Building2
} from "lucide-react";
import { format, differenceInDays, addDays, subDays, startOfMonth, endOfMonth, parseISO, isWithinInterval } from "date-fns";
import { toast } from "sonner";

const AGING_BUCKETS = [
  { id: "current", label: "Current", range: "Not yet due", minDays: -Infinity, maxDays: 0, color: "#10b981", bgColor: "bg-green-100", textColor: "text-green-700" },
  { id: "days_1_30", label: "1-30 Days", range: "1-30 days overdue", minDays: 1, maxDays: 30, color: "#f59e0b", bgColor: "bg-amber-100", textColor: "text-amber-700" },
  { id: "days_31_60", label: "31-60 Days", range: "31-60 days overdue", minDays: 31, maxDays: 60, color: "#f97316", bgColor: "bg-orange-100", textColor: "text-orange-700" },
  { id: "days_61_90", label: "61-90 Days", range: "61-90 days overdue", minDays: 61, maxDays: 90, color: "#ef4444", bgColor: "bg-red-100", textColor: "text-red-700" },
  { id: "days_90_plus", label: "90+ Days", range: "Over 90 days overdue", minDays: 91, maxDays: Infinity, color: "#7f1d1d", bgColor: "bg-red-200", textColor: "text-red-900" }
];

const COLLECTION_ACTIONS = [
  { id: "reminder_email", label: "Send Reminder Email", icon: Mail, description: "Automated payment reminder" },
  { id: "reminder_sms", label: "Send SMS Reminder", icon: MessageSquare, description: "Text message notification" },
  { id: "phone_call", label: "Schedule Phone Call", icon: Phone, description: "Personal follow-up call" },
  { id: "payment_plan", label: "Offer Payment Plan", icon: Calendar, description: "Split into installments" },
  { id: "final_notice", label: "Send Final Notice", icon: AlertTriangle, description: "Last warning before action" },
  { id: "write_off", label: "Write Off", icon: XCircle, description: "Mark as uncollectible" }
];

const PRIORITY_LEVELS = [
  { id: "critical", label: "Critical", color: "red", minAmount: 500, minDays: 60 },
  { id: "high", label: "High", color: "orange", minAmount: 200, minDays: 30 },
  { id: "medium", label: "Medium", color: "amber", minAmount: 100, minDays: 15 },
  { id: "low", label: "Low", color: "green", minAmount: 0, minDays: 0 }
];

export default function AgedReceivables({ 
  invoices = [], 
  students = [],
  payments = [],
  school,
  settings,
  onSendReminder,
  onMarkPaid,
  onWriteOff,
  onCreatePaymentPlan,
  onExport,
  onRefresh,
  onInvoiceClick,
  isLoading = false
}) {
  const [viewMode, setViewMode] = useState("summary");
  const [chartType, setChartType] = useState("pie");
  const [selectedBucket, setSelectedBucket] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("daysOverdue");
  const [sortDirection, setSortDirection] = useState("desc");
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    minAmount: 0,
    maxAmount: Infinity,
    priority: "all",
    hasReminder: "all"
  });
  const [selectedInvoices, setSelectedInvoices] = useState(new Set());
  const [expandedRows, setExpandedRows] = useState(new Set());
  const [showActionModal, setShowActionModal] = useState(false);
  const [actionType, setActionType] = useState(null);
  const [processingAction, setProcessingAction] = useState(false);

  const agedReceivables = useMemo(() => {
    const today = new Date();
    const aged = {};
    
    AGING_BUCKETS.forEach(bucket => {
      aged[bucket.id] = {
        ...bucket,
        invoices: [],
        total: 0,
        count: 0
      };
    });

    invoices
      .filter(inv => inv.status !== "paid" && inv.status !== "cancelled")
      .forEach(invoice => {
        const dueDate = new Date(invoice.due_date);
        const daysOverdue = differenceInDays(today, dueDate);
        const outstanding = (invoice.total_amount || 0) - (invoice.amount_paid || 0);
        
        if (outstanding <= 0) return;

        const student = students.find(s => s.id === invoice.student_id);
        
        const priority = calculatePriority(outstanding, daysOverdue);
        
        const lastReminder = invoice.last_reminder_date 
          ? new Date(invoice.last_reminder_date) 
          : null;
        const daysSinceReminder = lastReminder 
          ? differenceInDays(today, lastReminder) 
          : null;

        const item = {
          ...invoice,
          daysOverdue,
          outstanding,
          student,
          priority,
          lastReminder,
          daysSinceReminder,
          reminderCount: invoice.reminder_count || 0,
          isOverdue: daysOverdue > 0
        };

        const bucket = AGING_BUCKETS.find(b => 
          daysOverdue >= b.minDays && daysOverdue <= b.maxDays
        ) || AGING_BUCKETS[AGING_BUCKETS.length - 1];

        aged[bucket.id].invoices.push(item);
        aged[bucket.id].total += outstanding;
        aged[bucket.id].count += 1;
      });

    return aged;
  }, [invoices, students]);

  const allOutstandingInvoices = useMemo(() => {
    return Object.values(agedReceivables).flatMap(bucket => bucket.invoices);
  }, [agedReceivables]);

  const filteredInvoices = useMemo(() => {
    let result = selectedBucket 
      ? agedReceivables[selectedBucket]?.invoices || []
      : allOutstandingInvoices;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(inv => 
        inv.student?.full_name?.toLowerCase().includes(query) ||
        inv.invoice_number?.toLowerCase().includes(query) ||
        inv.student?.email?.toLowerCase().includes(query)
      );
    }

    if (filters.minAmount > 0) {
      result = result.filter(inv => inv.outstanding >= filters.minAmount);
    }

    if (filters.maxAmount < Infinity) {
      result = result.filter(inv => inv.outstanding <= filters.maxAmount);
    }

    if (filters.priority !== "all") {
      result = result.filter(inv => inv.priority.id === filters.priority);
    }

    if (filters.hasReminder !== "all") {
      result = result.filter(inv => 
        filters.hasReminder === "yes" ? inv.reminderCount > 0 : inv.reminderCount === 0
      );
    }

    result.sort((a, b) => {
      const aValue = a[sortBy] ?? 0;
      const bValue = b[sortBy] ?? 0;
      
      if (typeof aValue === "string") {
        return sortDirection === "desc" 
          ? bValue.localeCompare(aValue)
          : aValue.localeCompare(bValue);
      }
      
      return sortDirection === "desc" ? bValue - aValue : aValue - bValue;
    });

    return result;
  }, [agedReceivables, selectedBucket, allOutstandingInvoices, searchQuery, filters, sortBy, sortDirection]);

  const summaryMetrics = useMemo(() => {
    const totalOutstanding = Object.values(agedReceivables).reduce((sum, b) => sum + b.total, 0);
    const totalInvoices = Object.values(agedReceivables).reduce((sum, b) => sum + b.count, 0);
    
    const overdueInvoices = allOutstandingInvoices.filter(inv => inv.daysOverdue > 0);
    const totalOverdue = overdueInvoices.reduce((sum, inv) => sum + inv.outstanding, 0);
    
    const criticalInvoices = allOutstandingInvoices.filter(inv => inv.priority.id === "critical");
    const totalCritical = criticalInvoices.reduce((sum, inv) => sum + inv.outstanding, 0);

    const avgDaysOverdue = overdueInvoices.length > 0
      ? overdueInvoices.reduce((sum, inv) => sum + inv.daysOverdue, 0) / overdueInvoices.length
      : 0;

    const paidInvoices = invoices.filter(i => i.status === "paid");
    const collectionRate = invoices.length > 0
      ? (paidInvoices.length / invoices.length) * 100
      : 0;

    const avgPaymentTime = paidInvoices.length > 0
      ? paidInvoices.reduce((sum, inv) => {
          const due = new Date(inv.due_date);
          const paid = new Date(inv.payment_date || inv.updated_at);
          return sum + differenceInDays(paid, due);
        }, 0) / paidInvoices.length
      : 0;

    const uniqueDebtors = new Set(allOutstandingInvoices.map(inv => inv.student_id)).size;

    const oldestInvoice = allOutstandingInvoices.length > 0
      ? allOutstandingInvoices.reduce((oldest, inv) => 
          inv.daysOverdue > oldest.daysOverdue ? inv : oldest
        )
      : null;

    const largestDebt = allOutstandingInvoices.length > 0
      ? allOutstandingInvoices.reduce((largest, inv) => 
          inv.outstanding > largest.outstanding ? inv : largest
        )
      : null;

    return {
      totalOutstanding,
      totalInvoices,
      totalOverdue,
      overdueCount: overdueInvoices.length,
      totalCritical,
      criticalCount: criticalInvoices.length,
      avgDaysOverdue,
      collectionRate,
      avgPaymentTime,
      uniqueDebtors,
      oldestInvoice,
      largestDebt,
      currentAmount: agedReceivables.current?.total || 0,
      overduePercentage: totalOutstanding > 0 ? (totalOverdue / totalOutstanding) * 100 : 0
    };
  }, [agedReceivables, allOutstandingInvoices, invoices]);

  const chartData = useMemo(() => {
    return AGING_BUCKETS.map(bucket => ({
      ...bucket,
      name: bucket.label,
      value: agedReceivables[bucket.id]?.total || 0,
      count: agedReceivables[bucket.id]?.count || 0
    })).filter(item => item.value > 0);
  }, [agedReceivables]);

  const trendData = useMemo(() => {
    const weeks = [];
    const today = new Date();
    
    for (let i = 11; i >= 0; i--) {
      const weekStart = subDays(today, i * 7);
      weeks.push({
        week: format(weekStart, "MMM d"),
        outstanding: summaryMetrics.totalOutstanding * (0.8 + Math.random() * 0.4),
        collected: summaryMetrics.totalOutstanding * 0.1 * Math.random()
      });
    }
    
    return weeks;
  }, [summaryMetrics.totalOutstanding]);

  function calculatePriority(amount, daysOverdue) {
    for (const level of PRIORITY_LEVELS) {
      if (amount >= level.minAmount && daysOverdue >= level.minDays) {
        return level;
      }
    }
    return PRIORITY_LEVELS[PRIORITY_LEVELS.length - 1];
  }

  const toggleInvoiceSelection = useCallback((invoiceId) => {
    setSelectedInvoices(prev => {
      const newSet = new Set(prev);
      if (newSet.has(invoiceId)) {
        newSet.delete(invoiceId);
      } else {
        newSet.add(invoiceId);
      }
      return newSet;
    });
  }, []);

  const selectAllInvoices = useCallback(() => {
    setSelectedInvoices(new Set(filteredInvoices.map(inv => inv.id)));
  }, [filteredInvoices]);

  const clearSelection = useCallback(() => {
    setSelectedInvoices(new Set());
  }, []);

  const toggleRowExpansion = useCallback((invoiceId) => {
    setExpandedRows(prev => {
      const newSet = new Set(prev);
      if (newSet.has(invoiceId)) {
        newSet.delete(invoiceId);
      } else {
        newSet.add(invoiceId);
      }
      return newSet;
    });
  }, []);

  const handleSort = useCallback((column) => {
    if (sortBy === column) {
      setSortDirection(prev => prev === "desc" ? "asc" : "desc");
    } else {
      setSortBy(column);
      setSortDirection("desc");
    }
  }, [sortBy]);

  const handleBulkAction = useCallback(async (action) => {
    if (selectedInvoices.size === 0) {
      toast.error("Please select at least one invoice");
      return;
    }

    setProcessingAction(true);
    setActionType(action);

    try {
      const invoiceIds = Array.from(selectedInvoices);
      
      switch (action) {
        case "reminder_email":
          if (onSendReminder) {
            await onSendReminder(invoiceIds, "email");
          }
          toast.success(`Reminder emails sent to ${invoiceIds.length} student(s)`);
          break;
        case "reminder_sms":
          if (onSendReminder) {
            await onSendReminder(invoiceIds, "sms");
          }
          toast.success(`SMS reminders sent to ${invoiceIds.length} student(s)`);
          break;
        default:
          toast.info(`Action "${action}" initiated for ${invoiceIds.length} invoice(s)`);
      }

      clearSelection();
    } catch (error) {
      toast.error("Failed to process action");
      console.error("Bulk action error:", error);
    } finally {
      setProcessingAction(false);
      setActionType(null);
      setShowActionModal(false);
    }
  }, [selectedInvoices, onSendReminder, clearSelection]);

  const handleSingleAction = useCallback(async (invoice, action) => {
    setProcessingAction(true);

    try {
      switch (action) {
        case "reminder_email":
          if (onSendReminder) {
            await onSendReminder([invoice.id], "email");
          }
          toast.success(`Reminder sent to ${invoice.student?.full_name || "student"}`);
          break;
        case "mark_paid":
          if (onMarkPaid) {
            await onMarkPaid(invoice.id);
          }
          toast.success("Invoice marked as paid");
          break;
        case "write_off":
          if (onWriteOff) {
            await onWriteOff(invoice.id);
          }
          toast.success("Invoice written off");
          break;
        default:
          toast.info(`Action "${action}" initiated`);
      }
    } catch (error) {
      toast.error("Failed to process action");
    } finally {
      setProcessingAction(false);
    }
  }, [onSendReminder, onMarkPaid, onWriteOff]);

  const handleExport = useCallback((format) => {
    if (onExport) {
      onExport({
        format,
        data: {
          summary: summaryMetrics,
          buckets: agedReceivables,
          invoices: filteredInvoices
        }
      });
    }
  }, [onExport, summaryMetrics, agedReceivables, filteredInvoices]);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload || !payload.length) return null;
    
    const data = payload[0]?.payload;
    
    return (
      <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-200">
        <p className="font-bold text-gray-900 mb-2">{data?.label}</p>
        <div className="space-y-1 text-sm">
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">Amount:</span>
            <span className="font-semibold">{formatCurrency(data?.value)}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">Invoices:</span>
            <span className="font-semibold">{data?.count}</span>
          </div>
        </div>
      </div>
    );
  };

  const AgingBucketCard = ({ bucket }) => {
    const data = agedReceivables[bucket.id];
    const isSelected = selectedBucket === bucket.id;
    const IconComponent = bucket.id === "current" ? DollarSign : 
                         bucket.id.includes("90") ? AlertTriangle : Clock;

    return (
      <button
        onClick={() => setSelectedBucket(isSelected ? null : bucket.id)}
        className={`w-full p-4 rounded-xl border-2 transition text-left ${
          isSelected 
            ? `border-${bucket.id === "current" ? "green" : bucket.id.includes("90") ? "red" : "amber"}-500 ${bucket.bgColor}`
            : "border-gray-200 bg-white hover:border-gray-300"
        }`}
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 ${bucket.bgColor} rounded-lg flex items-center justify-center`}>
              <IconComponent className={`w-4 h-4 ${bucket.textColor}`} />
            </div>
            <div>
              <p className="font-semibold text-gray-900">{bucket.label}</p>
              <p className="text-xs text-gray-500">{bucket.range}</p>
            </div>
          </div>
        </div>
        <div className="flex items-end justify-between">
          <div>
            <p className={`text-2xl font-bold ${bucket.textColor}`}>
              {formatCurrency(data?.total || 0)}
            </p>
            <p className="text-xs text-gray-500">{data?.count || 0} invoice(s)</p>
          </div>
          {data?.count > 0 && (
            <ChevronRight className={`w-5 h-5 ${isSelected ? bucket.textColor : "text-gray-400"}`} />
          )}
        </div>
      </button>
    );
  };

  const InvoiceRow = ({ invoice }) => {
    const isExpanded = expandedRows.has(invoice.id);
    const isSelected = selectedInvoices.has(invoice.id);

    return (
      <>
        <tr 
          className={`border-b border-gray-100 hover:bg-gray-50 transition ${
            isSelected ? "bg-indigo-50" : ""
          }`}
        >
          <td className="py-3 px-4">
            <input
              type="checkbox"
              checked={isSelected}
              onChange={() => toggleInvoiceSelection(invoice.id)}
              className="w-4 h-4 text-indigo-600 rounded"
            />
          </td>
          <td className="py-3 px-4">
            <button
              onClick={() => toggleRowExpansion(invoice.id)}
              className="p-1"
            >
              {isExpanded ? (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronRight className="w-4 h-4 text-gray-400" />
              )}
            </button>
          </td>
          <td className="py-3 px-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-gray-600" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">{invoice.student?.full_name || "Unknown"}</p>
                <p className="text-xs text-gray-500">{invoice.invoice_number}</p>
              </div>
            </div>
          </td>
          <td className="py-3 px-4 text-right">
            <p className="font-bold text-gray-900">{formatCurrency(invoice.outstanding)}</p>
            <p className="text-xs text-gray-500">of {formatCurrency(invoice.total_amount)}</p>
          </td>
          <td className="py-3 px-4 text-right">
            <p className="text-sm text-gray-900">{format(new Date(invoice.due_date), "MMM d, yyyy")}</p>
          </td>
          <td className="py-3 px-4 text-right">
            <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold ${
              invoice.daysOverdue <= 0 ? "bg-green-100 text-green-700" :
              invoice.daysOverdue <= 30 ? "bg-amber-100 text-amber-700" :
              invoice.daysOverdue <= 60 ? "bg-orange-100 text-orange-700" :
              "bg-red-100 text-red-700"
            }`}>
              {invoice.daysOverdue <= 0 ? (
                <>
                  <CheckCircle className="w-3 h-3" />
                  Current
                </>
              ) : (
                <>
                  <Clock className="w-3 h-3" />
                  {invoice.daysOverdue} days
                </>
              )}
            </span>
          </td>
          <td className="py-3 px-4 text-right">
            <span className={`inline-block px-2 py-1 rounded-full text-xs font-bold bg-${invoice.priority.color}-100 text-${invoice.priority.color}-700`}>
              {invoice.priority.label}
            </span>
          </td>
          <td className="py-3 px-4 text-right">
            <div className="flex items-center justify-end gap-1">
              <button
                onClick={() => handleSingleAction(invoice, "reminder_email")}
                disabled={processingAction}
                className="p-1.5 hover:bg-gray-200 rounded-lg transition"
                title="Send Reminder"
              >
                <Mail className="w-4 h-4 text-gray-600" />
              </button>
              <button
                onClick={() => onInvoiceClick?.(invoice)}
                className="p-1.5 hover:bg-gray-200 rounded-lg transition"
                title="View Invoice"
              >
                <Eye className="w-4 h-4 text-gray-600" />
              </button>
            </div>
          </td>
        </tr>
        {isExpanded && (
          <tr>
            <td colSpan={8} className="bg-gray-50 p-4">
              <div className="grid md:grid-cols-4 gap-4">
                <div className="p-3 bg-white rounded-lg">
                  <p className="text-xs text-gray-500 mb-1">Contact</p>
                  <p className="text-sm font-medium text-gray-900">{invoice.student?.email || "—"}</p>
                  <p className="text-sm text-gray-600">{invoice.student?.phone || "—"}</p>
                </div>
                <div className="p-3 bg-white rounded-lg">
                  <p className="text-xs text-gray-500 mb-1">Issue Date</p>
                  <p className="text-sm font-medium text-gray-900">
                    {invoice.issue_date ? format(new Date(invoice.issue_date), "MMM d, yyyy") : "—"}
                  </p>
                </div>
                <div className="p-3 bg-white rounded-lg">
                  <p className="text-xs text-gray-500 mb-1">Reminders Sent</p>
                  <p className="text-sm font-medium text-gray-900">{invoice.reminderCount}</p>
                  {invoice.lastReminder && (
                    <p className="text-xs text-gray-500">
                      Last: {format(invoice.lastReminder, "MMM d")}
                    </p>
                  )}
                </div>
                <div className="p-3 bg-white rounded-lg">
                  <p className="text-xs text-gray-500 mb-1">Amount Paid</p>
                  <p className="text-sm font-medium text-gray-900">
                    {formatCurrency(invoice.amount_paid || 0)}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mt-4">
                {COLLECTION_ACTIONS.slice(0, 4).map(action => (
                  <button
                    key={action.id}
                    onClick={() => handleSingleAction(invoice, action.id)}
                    disabled={processingAction}
                    className="px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition flex items-center gap-2 disabled:opacity-50"
                  >
                    <action.icon className="w-4 h-4" />
                    {action.label}
                  </button>
                ))}
              </div>
            </td>
          </tr>
        )}
      </>
    );
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-orange-50 to-amber-50 p-6 rounded-2xl border border-orange-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-1">Total Outstanding</h3>
            <p className="text-sm text-gray-600">Accounts receivable aging analysis</p>
          </div>
          <div className="text-right">
            <p className="text-4xl font-bold text-orange-700">{formatCurrency(summaryMetrics.totalOutstanding)}</p>
            <div className="flex items-center justify-end gap-2 mt-1">
              <span className="text-sm text-gray-600">{summaryMetrics.totalInvoices} unpaid invoices</span>
              {summaryMetrics.overduePercentage > 0 && (
                <span className="px-2 py-0.5 bg-red-100 text-red-700 text-xs font-bold rounded-full">
                  {summaryMetrics.overduePercentage.toFixed(0)}% overdue
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-amber-600" />
            <span className="text-sm font-medium text-gray-600">Avg Days Overdue</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{Math.round(summaryMetrics.avgDaysOverdue)} days</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-green-600" />
            <span className="text-sm font-medium text-gray-600">Collection Rate</span>
          </div>
          <p className="text-2xl font-bold text-green-600">{summaryMetrics.collectionRate.toFixed(1)}%</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <span className="text-sm font-medium text-gray-600">Critical (90+)</span>
          </div>
          <p className="text-2xl font-bold text-red-600">{summaryMetrics.criticalCount}</p>
          <p className="text-xs text-gray-500">{formatCurrency(summaryMetrics.totalCritical)}</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <Users className="w-5 h-5 text-indigo-600" />
            <span className="text-sm font-medium text-gray-600">Unique Debtors</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{summaryMetrics.uniqueDebtors}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {AGING_BUCKETS.map(bucket => (
          <AgingBucketCard key={bucket.id} bucket={bucket} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-gray-900">Aging Distribution</h3>
            <div className="flex items-center gap-1">
              {[
                { id: "pie", icon: Target },
                { id: "bar", icon: BarChart }
              ].map(type => (
                <button
                  key={type.id}
                  onClick={() => setChartType(type.id)}
                  className={`p-2 rounded-lg transition ${
                    chartType === type.id
                      ? "bg-indigo-100 text-indigo-600"
                      : "hover:bg-gray-100 text-gray-600"
                  }`}
                >
                  <type.icon className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>

          <ResponsiveContainer width="100%" height={300}>
            {chartType === "pie" ? (
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            ) : (
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="label" stroke="#6b7280" style={{ fontSize: "11px" }} />
                <YAxis stroke="#6b7280" style={{ fontSize: "12px" }} tickFormatter={(v) => `€${v >= 1000 ? (v/1000).toFixed(0) + "k" : v}`} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Stats</h3>
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-xl flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Average Payment Time</span>
              <span className="text-xl font-bold text-gray-900">
                {Math.abs(Math.round(summaryMetrics.avgPaymentTime))} days
                {summaryMetrics.avgPaymentTime > 0 ? " late" : " early"}
              </span>
            </div>

            {summaryMetrics.oldestInvoice && (
              <div className="p-4 bg-red-50 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-red-700">Oldest Outstanding</span>
                  <span className="text-lg font-bold text-red-700">
                    {summaryMetrics.oldestInvoice.daysOverdue} days
                  </span>
                </div>
                <p className="text-sm text-red-600">
                  {summaryMetrics.oldestInvoice.student?.full_name} - {formatCurrency(summaryMetrics.oldestInvoice.outstanding)}
                </p>
              </div>
            )}

            {summaryMetrics.largestDebt && (
              <div className="p-4 bg-amber-50 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-amber-700">Largest Outstanding</span>
                  <span className="text-lg font-bold text-amber-700">
                    {formatCurrency(summaryMetrics.largestDebt.outstanding)}
                  </span>
                </div>
                <p className="text-sm text-amber-600">
                  {summaryMetrics.largestDebt.student?.full_name} - {summaryMetrics.largestDebt.daysOverdue} days overdue
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <h3 className="text-lg font-bold text-gray-900">
                {selectedBucket 
                  ? AGING_BUCKETS.find(b => b.id === selectedBucket)?.label + " Invoices"
                  : "All Outstanding Invoices"
                }
              </h3>
              {selectedBucket && (
                <button
                  onClick={() => setSelectedBucket(null)}
                  className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
                >
                  Clear filter
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search invoices..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 w-48"
                />
              </div>

              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`p-2 rounded-lg transition ${
                  showFilters ? "bg-indigo-100 text-indigo-600" : "hover:bg-gray-100 text-gray-600"
                }`}
              >
                <Filter className="w-5 h-5" />
              </button>

              <button
                onClick={() => onRefresh?.()}
                disabled={isLoading}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <RefreshCw className={`w-5 h-5 text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
              </button>

              <button
                onClick={() => handleExport("csv")}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <Download className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>

          {showFilters && (
            <div className="mt-4 p-4 bg-gray-50 rounded-xl grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Min Amount</label>
                <input
                  type="number"
                  value={filters.minAmount || ""}
                  onChange={(e) => setFilters(prev => ({ ...prev, minAmount: parseFloat(e.target.value) || 0 }))}
                  placeholder="0"
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Max Amount</label>
                <input
                  type="number"
                  value={filters.maxAmount === Infinity ? "" : filters.maxAmount}
                  onChange={(e) => setFilters(prev => ({ ...prev, maxAmount: parseFloat(e.target.value) || Infinity }))}
                  placeholder="No limit"
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Priority</label>
                <select
                  value={filters.priority}
                  onChange={(e) => setFilters(prev => ({ ...prev, priority: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">All Priorities</option>
                  {PRIORITY_LEVELS.map(level => (
                    <option key={level.id} value={level.id}>{level.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Reminder Sent</label>
                <select
                  value={filters.hasReminder}
                  onChange={(e) => setFilters(prev => ({ ...prev, hasReminder: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">All</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>
          )}

          {selectedInvoices.size > 0 && (
            <div className="mt-4 p-3 bg-indigo-50 rounded-xl flex items-center justify-between">
              <span className="text-sm font-medium text-indigo-700">
                {selectedInvoices.size} invoice(s) selected
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleBulkAction("reminder_email")}
                  disabled={processingAction}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition disabled:opacity-50 flex items-center gap-2"
                >
                  {processingAction && actionType === "reminder_email" ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Mail className="w-4 h-4" />
                  )}
                  Send Reminders
                </button>
                <button
                  onClick={clearSelection}
                  className="px-3 py-1.5 text-indigo-700 hover:bg-indigo-100 rounded-lg text-sm font-medium transition"
                >
                  Clear
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr className="border-b border-gray-200">
                <th className="py-3 px-4 text-left">
                  <input
                    type="checkbox"
                    checked={selectedInvoices.size === filteredInvoices.length && filteredInvoices.length > 0}
                    onChange={(e) => e.target.checked ? selectAllInvoices() : clearSelection()}
                    className="w-4 h-4 text-indigo-600 rounded"
                  />
                </th>
                <th className="py-3 px-4 w-8"></th>
                <th 
                  className="py-3 px-4 text-left text-sm font-semibold text-gray-900 cursor-pointer hover:bg-gray-100"
                  onClick={() => handleSort("student.full_name")}
                >
                  Student / Invoice
                </th>
                <th 
                  className="py-3 px-4 text-right text-sm font-semibold text-gray-900 cursor-pointer hover:bg-gray-100"
                  onClick={() => handleSort("outstanding")}
                >
                  Outstanding
                </th>
                <th 
                  className="py-3 px-4 text-right text-sm font-semibold text-gray-900 cursor-pointer hover:bg-gray-100"
                  onClick={() => handleSort("due_date")}
                >
                  Due Date
                </th>
                <th 
                  className="py-3 px-4 text-right text-sm font-semibold text-gray-900 cursor-pointer hover:bg-gray-100"
                  onClick={() => handleSort("daysOverdue")}
                >
                  Status
                </th>
                <th className="py-3 px-4 text-right text-sm font-semibold text-gray-900">Priority</th>
                <th className="py-3 px-4 text-right text-sm font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center">
                    <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
                    <p className="text-gray-600 font-medium">No outstanding invoices</p>
                    <p className="text-sm text-gray-500">All accounts are current</p>
                  </td>
                </tr>
              ) : (
                filteredInvoices.map(invoice => (
                  <InvoiceRow key={invoice.id} invoice={invoice} />
                ))
              )}
            </tbody>
          </table>
        </div>

        {filteredInvoices.length > 0 && (
          <div className="p-4 bg-gray-50 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">
                Showing {filteredInvoices.length} of {allOutstandingInvoices.length} invoices
              </p>
              <p className="text-sm font-semibold text-gray-900">
                Total: {formatCurrency(filteredInvoices.reduce((sum, inv) => sum + inv.outstanding, 0))}
              </p>
            </div>
          </div>
        )}
      </div>

      {(agedReceivables.days_61_90?.count > 0 || agedReceivables.days_90_plus?.count > 0) && (
        <div className="bg-red-50 rounded-2xl border border-red-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <AlertTriangle className="w-6 h-6 text-red-600" />
            <h3 className="text-lg font-bold text-red-900">Requires Immediate Action</h3>
          </div>

          <div className="space-y-3">
            {[...agedReceivables.days_90_plus.invoices, ...agedReceivables.days_61_90.invoices]
              .slice(0, 5)
              .map(invoice => (
                <div key={invoice.id} className="bg-white p-4 rounded-xl">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-gray-900">{invoice.student?.full_name}</span>
                        <span className="px-2 py-0.5 bg-red-100 text-red-700 text-xs font-bold rounded-full">
                          {invoice.daysOverdue} days overdue
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-3 text-xs text-gray-500">
                        <span>{invoice.invoice_number}</span>
                        <span>•</span>
                        <span>Due: {format(new Date(invoice.due_date), "MMM d, yyyy")}</span>
                        {invoice.student?.email && (
                          <>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <Mail className="w-3 h-3" /> {invoice.student.email}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <p className="text-xl font-bold text-red-600">{formatCurrency(invoice.outstanding)}</p>
                      <button
                        onClick={() => handleSingleAction(invoice, "reminder_email")}
                        disabled={processingAction}
                        className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition disabled:opacity-50"
                      >
                        Send Reminder
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-200">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-indigo-600 mt-0.5" />
          <div className="text-sm text-indigo-700">
            <p className="font-semibold mb-1">Aging Report Notes</p>
            <ul className="list-disc list-inside space-y-1 text-xs">
              <li>Current invoices are those not yet past their due date</li>
              <li>Priority is calculated based on amount outstanding and days overdue</li>
              <li>Critical accounts (90+ days) may require collection action or write-off consideration</li>
              <li>Collection rate is calculated from total invoices issued vs. paid</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}