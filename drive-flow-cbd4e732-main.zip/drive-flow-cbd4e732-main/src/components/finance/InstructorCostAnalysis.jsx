import React, { useState, useEffect, useMemo, useCallback } from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend, 
  Cell,
  PieChart,
  Pie,
  LineChart,
  Line,
  ComposedChart,
  Area,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis
} from "recharts";
import { 
  Users, 
  DollarSign, 
  TrendingUp, 
  TrendingDown,
  Award,
  Clock,
  Calendar,
  Star,
  Target,
  Zap,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Download,
  Filter,
  RefreshCw,
  Search,
  Settings,
  Eye,
  EyeOff,
  Info,
  AlertCircle,
  CheckCircle,
  XCircle,
  BarChart3,
  PieChart as PieChartIcon,
  Activity,
  Percent,
  ArrowUpRight,
  ArrowDownRight,
  Car,
  MapPin,
  Phone,
  Mail,
  Edit,
  MoreVertical,
  Loader2,
  GraduationCap,
  ThumbsUp,
  UserCheck,
  Briefcase
} from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, differenceInDays, parseISO, isWithinInterval, startOfWeek, endOfWeek, addDays } from "date-fns";

const CHART_COLORS = [
  "#6366f1", "#8b5cf6", "#a855f7", "#d946ef", 
  "#ec4899", "#f43f5e", "#f97316", "#eab308",
  "#22c55e", "#14b8a6", "#06b6d4", "#3b82f6"
];

const PERFORMANCE_TIERS = [
  { id: "platinum", label: "Platinum", minScore: 90, color: "#818cf8", icon: Award },
  { id: "gold", label: "Gold", minScore: 75, color: "#fbbf24", icon: Star },
  { id: "silver", label: "Silver", minScore: 60, color: "#9ca3af", icon: Target },
  { id: "bronze", label: "Bronze", minScore: 0, color: "#cd7f32", icon: Zap }
];

const COMMISSION_STRUCTURES = [
  { id: "fixed", label: "Fixed Rate", description: "Same rate for all lessons" },
  { id: "tiered", label: "Tiered", description: "Rate increases with volume" },
  { id: "performance", label: "Performance-Based", description: "Rate based on metrics" },
  { id: "hybrid", label: "Hybrid", description: "Base rate plus bonuses" }
];

export default function InstructorCostAnalysis({ 
  instructors = [], 
  bookings = [], 
  payments = [],
  students = [],
  vehicles = [],
  reviews = [],
  dateRange,
  previousPeriodData,
  commissionSettings,
  school,
  onExport,
  onRefresh,
  onInstructorClick,
  isLoading = false
}) {
  const [selectedInstructor, setSelectedInstructor] = useState(null);
  const [viewMode, setViewMode] = useState("overview");
  const [chartType, setChartType] = useState("bar");
  const [sortBy, setSortBy] = useState("revenue");
  const [sortDirection, setSortDirection] = useState("desc");
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    minLessons: 0,
    minRevenue: 0,
    performanceTier: "all",
    status: "all"
  });
  const [expandedRows, setExpandedRows] = useState(new Set());
  const [showComparison, setShowComparison] = useState(true);

  const filterByDateRange = useCallback((items, dateField) => {
    if (!dateRange?.start || !dateRange?.end) return items;
    
    return items.filter(item => {
      const itemDate = new Date(item[dateField]);
      return isWithinInterval(itemDate, {
        start: new Date(dateRange.start),
        end: new Date(dateRange.end)
      });
    });
  }, [dateRange]);

  const filteredBookings = useMemo(() => {
    return filterByDateRange(bookings, "start_datetime");
  }, [bookings, filterByDateRange]);

  const filteredPayments = useMemo(() => {
    return filterByDateRange(payments, "payment_date");
  }, [payments, filterByDateRange]);

  const instructorMetrics = useMemo(() => {
    return instructors.map(instructor => {
      const instructorBookings = filteredBookings.filter(b => 
        b.instructor_id === instructor.id
      );
      
      const completedBookings = instructorBookings.filter(b => b.status === "completed");
      const cancelledBookings = instructorBookings.filter(b => b.status === "cancelled");
      const noShowBookings = instructorBookings.filter(b => b.status === "no_show");
      
      const totalRevenue = completedBookings.reduce((sum, b) => sum + (b.price || 0), 0);
      
      const commissionRate = instructor.commission_rate || commissionSettings?.defaultRate || 0.70;
      let instructorEarnings = totalRevenue * commissionRate;
      
      if (commissionSettings?.structure === "tiered") {
        const tiers = commissionSettings.tiers || [];
        for (const tier of tiers.sort((a, b) => b.minLessons - a.minLessons)) {
          if (completedBookings.length >= tier.minLessons) {
            instructorEarnings = totalRevenue * tier.rate;
            break;
          }
        }
      }
      
      const bonuses = calculateBonuses(instructor, completedBookings, reviews);
      instructorEarnings += bonuses.total;
      
      const schoolShare = totalRevenue - instructorEarnings;
      
      const lessonsCount = completedBookings.length;
      const avgRevenuePerLesson = lessonsCount > 0 ? totalRevenue / lessonsCount : 0;
      const avgCommissionPerLesson = lessonsCount > 0 ? instructorEarnings / lessonsCount : 0;
      
      const totalHours = completedBookings.reduce((sum, b) => {
        const duration = b.duration_minutes || 60;
        return sum + (duration / 60);
      }, 0);
      const revenuePerHour = totalHours > 0 ? totalRevenue / totalHours : 0;
      const earningsPerHour = totalHours > 0 ? instructorEarnings / totalHours : 0;
      
      const uniqueStudents = new Set(completedBookings.map(b => b.student_id)).size;
      
      const instructorReviews = reviews.filter(r => r.instructor_id === instructor.id);
      const avgRating = instructorReviews.length > 0
        ? instructorReviews.reduce((sum, r) => sum + (r.rating || 0), 0) / instructorReviews.length
        : 0;
      
      const completionRate = instructorBookings.length > 0
        ? (completedBookings.length / instructorBookings.length) * 100
        : 0;
      
      const cancellationRate = instructorBookings.length > 0
        ? (cancelledBookings.length / instructorBookings.length) * 100
        : 0;
      
      const noShowRate = instructorBookings.length > 0
        ? (noShowBookings.length / instructorBookings.length) * 100
        : 0;
      
      const passedTests = students.filter(s => 
        s.instructor_id === instructor.id && s.test_passed === true
      ).length;
      const totalTests = students.filter(s => 
        s.instructor_id === instructor.id && s.test_date != null
      ).length;
      const passRate = totalTests > 0 ? (passedTests / totalTests) * 100 : 0;
      
      const utilizationRate = calculateUtilizationRate(instructor, completedBookings, dateRange);
      
      const performanceScore = calculatePerformanceScore({
        revenue: totalRevenue,
        lessons: lessonsCount,
        rating: avgRating,
        completionRate,
        passRate,
        utilizationRate
      });
      
      const performanceTier = PERFORMANCE_TIERS.find(t => performanceScore >= t.minScore) || PERFORMANCE_TIERS[PERFORMANCE_TIERS.length - 1];

      const weeklyData = calculateWeeklyBreakdown(completedBookings, dateRange);

      return {
        id: instructor.id,
        name: instructor.full_name || `${instructor.first_name} ${instructor.last_name}`,
        email: instructor.email,
        phone: instructor.phone,
        avatar: instructor.avatar_url,
        status: instructor.status || "active",
        totalRevenue,
        instructorEarnings,
        schoolShare,
        bonuses,
        lessonsCount,
        totalHours,
        avgRevenuePerLesson,
        avgCommissionPerLesson,
        revenuePerHour,
        earningsPerHour,
        commissionRate: commissionRate * 100,
        uniqueStudents,
        avgRating,
        reviewCount: instructorReviews.length,
        completionRate,
        cancellationRate,
        noShowRate,
        passRate,
        passedTests,
        totalTests,
        utilizationRate,
        performanceScore,
        performanceTier,
        weeklyData,
        scheduledBookings: instructorBookings.filter(b => b.status === "confirmed").length,
        cancelledBookings: cancelledBookings.length
      };
    });
  }, [instructors, filteredBookings, reviews, students, commissionSettings, dateRange]);

  function calculateBonuses(instructor, completedBookings, reviews) {
    const bonuses = {
      performance: 0,
      reviews: 0,
      retention: 0,
      volume: 0,
      total: 0
    };

    if (!commissionSettings?.bonuses) return bonuses;

    if (commissionSettings.bonuses.performance) {
      const instructorReviews = reviews.filter(r => r.instructor_id === instructor.id);
      const avgRating = instructorReviews.length > 0
        ? instructorReviews.reduce((sum, r) => sum + r.rating, 0) / instructorReviews.length
        : 0;
      
      if (avgRating >= 4.5) {
        bonuses.performance = commissionSettings.bonuses.performance.amount || 50;
      }
    }

    if (commissionSettings.bonuses.volume && completedBookings.length >= 50) {
      bonuses.volume = commissionSettings.bonuses.volume.amount || 100;
    }

    bonuses.total = bonuses.performance + bonuses.reviews + bonuses.retention + bonuses.volume;
    return bonuses;
  }

  function calculateUtilizationRate(instructor, completedBookings, dateRange) {
    if (!dateRange?.start || !dateRange?.end) return 0;
    
    const workingDays = differenceInDays(new Date(dateRange.end), new Date(dateRange.start));
    const workingHoursPerDay = instructor.working_hours_per_day || 8;
    const totalAvailableHours = workingDays * workingHoursPerDay * 0.7;
    
    const totalWorkedHours = completedBookings.reduce((sum, b) => {
      return sum + ((b.duration_minutes || 60) / 60);
    }, 0);
    
    return totalAvailableHours > 0 ? (totalWorkedHours / totalAvailableHours) * 100 : 0;
  }

  function calculatePerformanceScore(metrics) {
    const weights = {
      revenue: 0.25,
      lessons: 0.15,
      rating: 0.25,
      completionRate: 0.15,
      passRate: 0.10,
      utilizationRate: 0.10
    };

    let score = 0;
    
    score += Math.min(metrics.revenue / 5000, 1) * 100 * weights.revenue;
    score += Math.min(metrics.lessons / 50, 1) * 100 * weights.lessons;
    score += (metrics.rating / 5) * 100 * weights.rating;
    score += metrics.completionRate * weights.completionRate;
    score += metrics.passRate * weights.passRate;
    score += Math.min(metrics.utilizationRate, 100) * weights.utilizationRate;
    
    return Math.round(score);
  }

  function calculateWeeklyBreakdown(bookings, dateRange) {
    if (!dateRange?.start || !dateRange?.end) return [];
    
    const weeks = [];
    let currentStart = startOfWeek(new Date(dateRange.start));
    const endDate = new Date(dateRange.end);
    
    while (currentStart <= endDate) {
      const weekEnd = endOfWeek(currentStart);
      const weekBookings = bookings.filter(b => {
        const bookingDate = new Date(b.start_datetime);
        return isWithinInterval(bookingDate, { start: currentStart, end: weekEnd });
      });
      
      weeks.push({
        week: format(currentStart, "MMM d"),
        lessons: weekBookings.length,
        revenue: weekBookings.reduce((sum, b) => sum + (b.price || 0), 0),
        hours: weekBookings.reduce((sum, b) => sum + ((b.duration_minutes || 60) / 60), 0)
      });
      
      currentStart = addDays(weekEnd, 1);
    }
    
    return weeks;
  }

  const filteredMetrics = useMemo(() => {
    let result = instructorMetrics;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(m => 
        m.name.toLowerCase().includes(query) ||
        m.email?.toLowerCase().includes(query)
      );
    }

    if (filters.minLessons > 0) {
      result = result.filter(m => m.lessonsCount >= filters.minLessons);
    }

    if (filters.minRevenue > 0) {
      result = result.filter(m => m.totalRevenue >= filters.minRevenue);
    }

    if (filters.performanceTier !== "all") {
      result = result.filter(m => m.performanceTier.id === filters.performanceTier);
    }

    if (filters.status !== "all") {
      result = result.filter(m => m.status === filters.status);
    }

    result.sort((a, b) => {
      const aValue = a[sortBy] ?? 0;
      const bValue = b[sortBy] ?? 0;
      return sortDirection === "desc" ? bValue - aValue : aValue - bValue;
    });

    return result;
  }, [instructorMetrics, searchQuery, filters, sortBy, sortDirection]);

  const summaryMetrics = useMemo(() => {
    const activeMetrics = filteredMetrics.filter(m => m.totalRevenue > 0);
    
    const totalRevenue = activeMetrics.reduce((sum, m) => sum + m.totalRevenue, 0);
    const totalInstructorCosts = activeMetrics.reduce((sum, m) => sum + m.instructorEarnings, 0);
    const totalSchoolShare = activeMetrics.reduce((sum, m) => sum + m.schoolShare, 0);
    const totalLessons = activeMetrics.reduce((sum, m) => sum + m.lessonsCount, 0);
    const totalHours = activeMetrics.reduce((sum, m) => sum + m.totalHours, 0);
    const totalBonuses = activeMetrics.reduce((sum, m) => sum + m.bonuses.total, 0);
    
    const avgCommissionRate = activeMetrics.length > 0
      ? activeMetrics.reduce((sum, m) => sum + m.commissionRate, 0) / activeMetrics.length
      : 0;
    
    const avgRating = activeMetrics.length > 0
      ? activeMetrics.reduce((sum, m) => sum + m.avgRating, 0) / activeMetrics.length
      : 0;
    
    const avgPerformanceScore = activeMetrics.length > 0
      ? activeMetrics.reduce((sum, m) => sum + m.performanceScore, 0) / activeMetrics.length
      : 0;
    
    const avgUtilization = activeMetrics.length > 0
      ? activeMetrics.reduce((sum, m) => sum + m.utilizationRate, 0) / activeMetrics.length
      : 0;

    const topPerformer = activeMetrics.length > 0
      ? activeMetrics.reduce((best, m) => m.performanceScore > best.performanceScore ? m : best)
      : null;

    const highestEarner = activeMetrics.length > 0
      ? activeMetrics.reduce((best, m) => m.instructorEarnings > best.instructorEarnings ? m : best)
      : null;

    return {
      totalRevenue,
      totalInstructorCosts,
      totalSchoolShare,
      totalLessons,
      totalHours,
      totalBonuses,
      avgCommissionRate,
      avgRating,
      avgPerformanceScore,
      avgUtilization,
      activeInstructors: activeMetrics.length,
      topPerformer,
      highestEarner,
      costPercentage: totalRevenue > 0 ? (totalInstructorCosts / totalRevenue) * 100 : 0,
      avgRevenuePerInstructor: activeMetrics.length > 0 ? totalRevenue / activeMetrics.length : 0,
      avgLessonsPerInstructor: activeMetrics.length > 0 ? totalLessons / activeMetrics.length : 0
    };
  }, [filteredMetrics]);

  const chartData = useMemo(() => {
    return filteredMetrics.slice(0, 12).map((m, index) => ({
      ...m,
      fill: CHART_COLORS[index % CHART_COLORS.length],
      shortName: m.name.split(" ")[0]
    }));
  }, [filteredMetrics]);

  const toggleRow = useCallback((instructorId) => {
    setExpandedRows(prev => {
      const newSet = new Set(prev);
      if (newSet.has(instructorId)) {
        newSet.delete(instructorId);
      } else {
        newSet.add(instructorId);
      }
      return newSet;
    });
  }, []);

  const handleSort = useCallback((column) => {
    if (sortBy === column) {
      setSortDirection(prev => prev === "desc" ? "asc" : "desc");
    } else {
      setSortBy(column);
      setSortDirection("desc");
    }
  }, [sortBy]);

  const handleExport = useCallback((format) => {
    if (onExport) {
      onExport({
        format,
        data: {
          instructors: filteredMetrics,
          summary: summaryMetrics,
          dateRange
        }
      });
    }
  }, [onExport, filteredMetrics, summaryMetrics, dateRange]);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;
    
    const data = payload[0]?.payload;
    
    return (
      <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-200 max-w-xs">
        <p className="font-bold text-gray-900 mb-2">{data?.name}</p>
        <div className="space-y-1 text-sm">
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">Total Revenue:</span>
            <span className="font-semibold text-gray-900">{formatCurrency(data?.totalRevenue)}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">Earnings:</span>
            <span className="font-semibold text-red-600">{formatCurrency(data?.instructorEarnings)}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">School Share:</span>
            <span className="font-semibold text-green-600">{formatCurrency(data?.schoolShare)}</span>
          </div>
          <div className="flex items-center justify-between gap-4 pt-2 border-t border-gray-200">
            <span className="text-gray-600">Lessons:</span>
            <span className="font-medium">{data?.lessonsCount}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-gray-600">Performance:</span>
            <span className="font-medium">{data?.performanceScore}/100</span>
          </div>
        </div>
      </div>
    );
  };

  const renderChart = () => {
    switch (chartType) {
      case "pie":
        return (
          <PieChart>
            <Pie
              data={chartData}
              dataKey="instructorEarnings"
              nameKey="shortName"
              cx="50%"
              cy="50%"
              outerRadius={120}
              label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend />
          </PieChart>
        );

      case "composed":
        return (
          <ComposedChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              dataKey="shortName" 
              stroke="#6b7280" 
              style={{ fontSize: "11px" }}
            />
            <YAxis 
              yAxisId="left"
              stroke="#6b7280" 
              style={{ fontSize: "12px" }}
              tickFormatter={(v) => `€${v >= 1000 ? (v/1000).toFixed(0) + "k" : v}`}
            />
            <YAxis 
              yAxisId="right"
              orientation="right"
              stroke="#8b5cf6" 
              style={{ fontSize: "12px" }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar 
              yAxisId="left"
              dataKey="instructorEarnings" 
              name="Instructor Earnings" 
              radius={[4, 4, 0, 0]}
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
            </Bar>
            <Bar 
              yAxisId="left"
              dataKey="schoolShare" 
              name="School Share" 
              fill="#10b981" 
              radius={[4, 4, 0, 0]}
            />
            <Line 
              yAxisId="right"
              type="monotone" 
              dataKey="lessonsCount" 
              name="Lessons" 
              stroke="#8b5cf6" 
              strokeWidth={2}
              dot={{ fill: "#8b5cf6" }}
            />
          </ComposedChart>
        );

      default:
        return (
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              dataKey="shortName" 
              stroke="#6b7280" 
              style={{ fontSize: "11px" }}
            />
            <YAxis 
              stroke="#6b7280" 
              style={{ fontSize: "12px" }}
              tickFormatter={(v) => `€${v >= 1000 ? (v/1000).toFixed(0) + "k" : v}`}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar 
              dataKey="instructorEarnings" 
              name="Instructor Earnings" 
              radius={[4, 4, 0, 0]}
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
            </Bar>
            <Bar 
              dataKey="schoolShare" 
              name="School Share" 
              fill="#10b981" 
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        );
    }
  };

  const SortableHeader = ({ column, label, className = "" }) => (
    <th 
      className={`py-3 px-4 text-sm font-semibold text-gray-900 cursor-pointer hover:bg-gray-50 transition ${className}`}
      onClick={() => handleSort(column)}
    >
      <div className="flex items-center gap-1">
        {label}
        {sortBy === column && (
          sortDirection === "desc" ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />
        )}
      </div>
    </th>
  );

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-3">
            <DollarSign className="w-6 h-6 text-red-600" />
          </div>
          <p className="text-sm text-gray-500 mb-1">Total Instructor Costs</p>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(summaryMetrics.totalInstructorCosts)}</p>
          <p className="text-xs text-gray-500 mt-1">
            {summaryMetrics.costPercentage.toFixed(1)}% of revenue
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-3">
            <TrendingUp className="w-6 h-6 text-green-600" />
          </div>
          <p className="text-sm text-gray-500 mb-1">School Share</p>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(summaryMetrics.totalSchoolShare)}</p>
          <p className="text-xs text-gray-500 mt-1">
            {summaryMetrics.totalRevenue > 0 ? ((summaryMetrics.totalSchoolShare / summaryMetrics.totalRevenue) * 100).toFixed(1) : 0}% margin
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-3">
            <Users className="w-6 h-6 text-indigo-600" />
          </div>
          <p className="text-sm text-gray-500 mb-1">Active Instructors</p>
          <p className="text-2xl font-bold text-gray-900">{summaryMetrics.activeInstructors}</p>
          <p className="text-xs text-gray-500 mt-1">
            Avg {summaryMetrics.avgCommissionRate.toFixed(1)}% commission
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-3">
            <Award className="w-6 h-6 text-purple-600" />
          </div>
          <p className="text-sm text-gray-500 mb-1">Total Lessons</p>
          <p className="text-2xl font-bold text-gray-900">{summaryMetrics.totalLessons}</p>
          <p className="text-xs text-gray-500 mt-1">
            {summaryMetrics.totalHours.toFixed(1)} hours delivered
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-amber-50 to-yellow-50 p-4 rounded-xl border border-amber-200">
          <div className="flex items-center gap-3">
            <Star className="w-6 h-6 text-amber-600" />
            <div>
              <p className="text-sm text-amber-700">Avg Performance Score</p>
              <p className="text-xl font-bold text-amber-900">{summaryMetrics.avgPerformanceScore.toFixed(0)}/100</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-4 rounded-xl border border-blue-200">
          <div className="flex items-center gap-3">
            <Activity className="w-6 h-6 text-blue-600" />
            <div>
              <p className="text-sm text-blue-700">Avg Utilization</p>
              <p className="text-xl font-bold text-blue-900">{summaryMetrics.avgUtilization.toFixed(1)}%</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 rounded-xl border border-green-200">
          <div className="flex items-center gap-3">
            <ThumbsUp className="w-6 h-6 text-green-600" />
            <div>
              <p className="text-sm text-green-700">Avg Rating</p>
              <p className="text-xl font-bold text-green-900">{summaryMetrics.avgRating.toFixed(1)}/5.0</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-start justify-between mb-4">
            <h3 className="text-lg font-bold text-gray-900">Revenue Distribution by Instructor</h3>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onRefresh?.()}
                disabled={isLoading}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <RefreshCw className={`w-5 h-5 text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
              </button>
              <button
                onClick={() => handleExport("csv")}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <Download className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {[
              { id: "bar", icon: BarChart3 },
              { id: "composed", icon: Activity },
              { id: "pie", icon: PieChartIcon }
            ].map(type => (
              <button
                key={type.id}
                onClick={() => setChartType(type.id)}
                className={`p-2 rounded-lg transition ${
                  chartType === type.id
                    ? "bg-indigo-100 text-indigo-600"
                    : "hover:bg-gray-100 text-gray-600"
                }`}
              >
                <type.icon className="w-5 h-5" />
              </button>
            ))}
          </div>
        </div>

        <div className="p-6">
          <ResponsiveContainer width="100%" height={350}>
            {renderChart()}
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <h3 className="text-lg font-bold text-gray-900">Detailed Instructor Analysis</h3>
            
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search instructors..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 w-48"
                />
              </div>

              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`p-2 rounded-lg transition ${
                  showFilters ? "bg-indigo-100 text-indigo-600" : "hover:bg-gray-100 text-gray-600"
                }`}
              >
                <Filter className="w-5 h-5" />
              </button>
            </div>
          </div>

          {showFilters && (
            <div className="mt-4 p-4 bg-gray-50 rounded-xl grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Min Lessons</label>
                <input
                  type="number"
                  value={filters.minLessons}
                  onChange={(e) => setFilters(prev => ({ ...prev, minLessons: parseInt(e.target.value) || 0 }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Min Revenue</label>
                <input
                  type="number"
                  value={filters.minRevenue}
                  onChange={(e) => setFilters(prev => ({ ...prev, minRevenue: parseInt(e.target.value) || 0 }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Performance Tier</label>
                <select
                  value={filters.performanceTier}
                  onChange={(e) => setFilters(prev => ({ ...prev, performanceTier: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">All Tiers</option>
                  {PERFORMANCE_TIERS.map(tier => (
                    <option key={tier.id} value={tier.id}>{tier.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Status</label>
                <select
                  value={filters.status}
                  onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">All Status</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr className="border-b border-gray-200">
                <th className="w-8 py-3 px-4"></th>
                <SortableHeader column="name" label="Instructor" className="text-left" />
                <SortableHeader column="lessonsCount" label="Lessons" className="text-right" />
                <SortableHeader column="totalRevenue" label="Revenue" className="text-right" />
                <SortableHeader column="instructorEarnings" label="Earnings" className="text-right" />
                <SortableHeader column="schoolShare" label="School Share" className="text-right" />
                <SortableHeader column="avgRating" label="Rating" className="text-right" />
                <SortableHeader column="performanceScore" label="Performance" className="text-right" />
                <th className="py-3 px-4 text-right text-sm font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredMetrics.map((metric) => (
                <React.Fragment key={metric.id}>
                  <tr 
                    className={`border-b border-gray-100 hover:bg-gray-50 transition cursor-pointer ${
                      expandedRows.has(metric.id) ? "bg-indigo-50" : ""
                    }`}
                    onClick={() => toggleRow(metric.id)}
                  >
                    <td className="py-3 px-4">
                      <button className="p-1">
                        {expandedRows.has(metric.id) ? (
                          <ChevronDown className="w-4 h-4 text-gray-400" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-gray-400" />
                        )}
                      </button>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                          {metric.avatar ? (
                            <img src={metric.avatar} alt="" className="w-10 h-10 rounded-full object-cover" />
                          ) : (
                            <span className="text-sm font-bold text-indigo-600">
                              {metric.name.split(" ").map(n => n[0]).join("")}
                            </span>
                          )}
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900">{metric.name}</p>
                          <div className="flex items-center gap-2">
                            <span 
                              className="text-xs font-medium px-2 py-0.5 rounded-full"
                              style={{ 
                                backgroundColor: `${metric.performanceTier.color}20`,
                                color: metric.performanceTier.color
                              }}
                            >
                              {metric.performanceTier.label}
                            </span>
                            <span className="text-xs text-gray-500">{metric.commissionRate.toFixed(0)}%</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="text-right py-3 px-4">
                      <span className="font-semibold text-gray-900">{metric.lessonsCount}</span>
                      <p className="text-xs text-gray-500">{metric.totalHours.toFixed(1)}h</p>
                    </td>
                    <td className="text-right py-3 px-4 font-semibold text-gray-900">
                      {formatCurrency(metric.totalRevenue)}
                    </td>
                    <td className="text-right py-3 px-4 font-semibold text-red-600">
                      {formatCurrency(metric.instructorEarnings)}
                    </td>
                    <td className="text-right py-3 px-4 font-semibold text-green-600">
                      {formatCurrency(metric.schoolShare)}
                    </td>
                    <td className="text-right py-3 px-4">
                      <div className="flex items-center justify-end gap-1">
                        <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                        <span className="font-semibold">{metric.avgRating.toFixed(1)}</span>
                        <span className="text-xs text-gray-500">({metric.reviewCount})</span>
                      </div>
                    </td>
                    <td className="text-right py-3 px-4">
                      <div className="flex items-center justify-end gap-2">
                        <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full rounded-full"
                            style={{ 
                              width: `${metric.performanceScore}%`,
                              backgroundColor: metric.performanceTier.color
                            }}
                          />
                        </div>
                        <span className="font-semibold text-gray-900 w-8">{metric.performanceScore}</span>
                      </div>
                    </td>
                    <td className="text-right py-3 px-4">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          onInstructorClick?.(metric);
                        }}
                        className="p-2 hover:bg-gray-200 rounded-lg transition"
                      >
                        <Eye className="w-4 h-4 text-gray-600" />
                      </button>
                    </td>
                  </tr>

                  {expandedRows.has(metric.id) && (
                    <tr>
                      <td colSpan={9} className="bg-gray-50 p-4">
                        <div className="grid md:grid-cols-4 gap-4">
                          <div className="p-3 bg-white rounded-lg">
                            <p className="text-xs text-gray-500 mb-1">Completion Rate</p>
                            <p className="text-lg font-bold text-gray-900">{metric.completionRate.toFixed(1)}%</p>
                          </div>
                          <div className="p-3 bg-white rounded-lg">
                            <p className="text-xs text-gray-500 mb-1">Pass Rate</p>
                            <p className="text-lg font-bold text-gray-900">{metric.passRate.toFixed(1)}%</p>
                            <p className="text-xs text-gray-500">{metric.passedTests}/{metric.totalTests} tests</p>
                          </div>
                          <div className="p-3 bg-white rounded-lg">
                            <p className="text-xs text-gray-500 mb-1">Utilization</p>
                            <p className="text-lg font-bold text-gray-900">{metric.utilizationRate.toFixed(1)}%</p>
                          </div>
                          <div className="p-3 bg-white rounded-lg">
                            <p className="text-xs text-gray-500 mb-1">Unique Students</p>
                            <p className="text-lg font-bold text-gray-900">{metric.uniqueStudents}</p>
                          </div>
                        </div>

                        <div className="grid md:grid-cols-3 gap-4 mt-4">
                          <div className="p-3 bg-white rounded-lg">
                            <p className="text-xs text-gray-500 mb-1">Revenue/Lesson</p>
                            <p className="text-lg font-bold text-gray-900">{formatCurrency(metric.avgRevenuePerLesson)}</p>
                          </div>
                          <div className="p-3 bg-white rounded-lg">
                            <p className="text-xs text-gray-500 mb-1">Earnings/Hour</p>
                            <p className="text-lg font-bold text-gray-900">{formatCurrency(metric.earningsPerHour)}</p>
                          </div>
                          <div className="p-3 bg-white rounded-lg">
                            <p className="text-xs text-gray-500 mb-1">Bonuses</p>
                            <p className="text-lg font-bold text-green-600">{formatCurrency(metric.bonuses.total)}</p>
                          </div>
                        </div>

                        {metric.weeklyData.length > 0 && (
                          <div className="mt-4">
                            <p className="text-sm font-semibold text-gray-700 mb-2">Weekly Trend</p>
                            <ResponsiveContainer width="100%" height={100}>
                              <LineChart data={metric.weeklyData}>
                                <XAxis dataKey="week" hide />
                                <YAxis hide />
                                <Tooltip />
                                <Line 
                                  type="monotone" 
                                  dataKey="revenue" 
                                  stroke="#6366f1" 
                                  strokeWidth={2}
                                  dot={false}
                                />
                              </LineChart>
                            </ResponsiveContainer>
                          </div>
                        )}
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
            <tfoot className="bg-gray-100 border-t-2 border-gray-200">
              <tr className="font-bold">
                <td className="py-4 px-4"></td>
                <td className="py-4 px-4 text-gray-900">TOTAL ({summaryMetrics.activeInstructors} instructors)</td>
                <td className="text-right py-4 px-4 text-gray-900">{summaryMetrics.totalLessons}</td>
                <td className="text-right py-4 px-4 text-gray-900">{formatCurrency(summaryMetrics.totalRevenue)}</td>
                <td className="text-right py-4 px-4 text-red-600">{formatCurrency(summaryMetrics.totalInstructorCosts)}</td>
                <td className="text-right py-4 px-4 text-green-600">{formatCurrency(summaryMetrics.totalSchoolShare)}</td>
                <td className="text-right py-4 px-4 text-gray-900">{summaryMetrics.avgRating.toFixed(1)}</td>
                <td className="text-right py-4 px-4 text-gray-900">{summaryMetrics.avgPerformanceScore.toFixed(0)}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-200">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-indigo-600 mt-0.5" />
          <div className="text-sm text-indigo-700">
            <p className="font-semibold mb-1">Cost Analysis Notes</p>
            <ul className="list-disc list-inside space-y-1 text-xs">
              <li>Instructor costs include base commissions and any performance bonuses</li>
              <li>Performance scores are calculated based on revenue, lessons, ratings, completion rate, pass rate, and utilization</li>
              <li>School share represents net margin after instructor payments</li>
              <li>Utilization rate is calculated based on expected working hours in the period</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}