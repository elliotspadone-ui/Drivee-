import React, { useState, useEffect, useMemo, useCallback } from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle, 
  DollarSign, 
  Users, 
  Calendar,
  Target,
  Zap,
  Shield,
  Activity,
  Award,
  Star,
  Clock,
  CreditCard,
  Percent,
  BarChart3,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  Info,
  HelpCircle,
  RefreshCw,
  Download,
  Settings,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Eye,
  EyeOff,
  Loader2,
  Lightbulb,
  TrendingUp as Growth,
  Wallet,
  Receipt,
  Building2,
  Car,
  GraduationCap,
  UserCheck,
  AlertCircle,
  ThumbsUp,
  ThumbsDown,
  Sparkles,
  Flag
} from "lucide-react";
import { format, subMonths, differenceInDays, startOfMonth, endOfMonth, parseISO, isWithinInterval } from "date-fns";

const HEALTH_CATEGORIES = {
  excellent: { min: 85, label: "Excellent", grade: "A+", color: "emerald", description: "Outstanding financial performance" },
  veryGood: { min: 75, label: "Very Good", grade: "A", color: "green", description: "Strong financial health" },
  good: { min: 65, label: "Good", grade: "B+", color: "teal", description: "Solid financial foundation" },
  satisfactory: { min: 55, label: "Satisfactory", grade: "B", color: "blue", description: "Adequate performance with room for improvement" },
  fair: { min: 45, label: "Fair", grade: "C", color: "amber", description: "Some areas need attention" },
  needsWork: { min: 35, label: "Needs Work", grade: "D", color: "orange", description: "Significant improvements needed" },
  critical: { min: 0, label: "Critical", grade: "F", color: "red", description: "Urgent action required" }
};

const METRIC_WEIGHTS = {
  profitability: { weight: 25, maxScore: 25, label: "Profitability", icon: DollarSign },
  cashFlow: { weight: 20, maxScore: 20, label: "Cash Flow", icon: Wallet },
  revenueGrowth: { weight: 15, maxScore: 15, label: "Revenue Growth", icon: TrendingUp },
  utilization: { weight: 12, maxScore: 12, label: "Utilization", icon: Calendar },
  paymentSuccess: { weight: 10, maxScore: 10, label: "Payment Success", icon: CreditCard },
  customerRetention: { weight: 8, maxScore: 8, label: "Customer Retention", icon: Users },
  operationalEfficiency: { weight: 5, maxScore: 5, label: "Operational Efficiency", icon: Zap },
  riskManagement: { weight: 5, maxScore: 5, label: "Risk Management", icon: Shield }
};

const BENCHMARK_DATA = {
  profitMargin: { excellent: 30, good: 20, average: 15, poor: 10 },
  cashFlowRatio: { excellent: 0.05, good: 0.15, average: 0.25, poor: 0.40 },
  growthRate: { excellent: 20, good: 10, average: 5, poor: 0 },
  utilization: { excellent: 90, good: 75, average: 60, poor: 45 },
  paymentSuccess: { excellent: 98, good: 95, average: 90, poor: 80 },
  retention: { excellent: 80, good: 65, average: 50, poor: 35 }
};

export default function FinancialHealthScore({ 
  totalRevenue = 0, 
  totalExpenses = 0, 
  unpaidBalance = 0, 
  avgTransactionValue = 0,
  revenueChange = 0,
  bookings = [],
  payments = [],
  invoices = [],
  students = [],
  instructors = [],
  previousPeriodData,
  industryBenchmarks,
  school,
  settings,
  onExport,
  onRefresh,
  isLoading = false
}) {
  const [selectedMetric, setSelectedMetric] = useState(null);
  const [showDetails, setShowDetails] = useState(true);
  const [showBenchmarks, setShowBenchmarks] = useState(false);
  const [showTrends, setShowTrends] = useState(false);
  const [showRecommendations, setShowRecommendations] = useState(true);
  const [expandedRecommendations, setExpandedRecommendations] = useState(new Set());

  const healthMetrics = useMemo(() => {
    const metrics = [];

    const profitMargin = totalRevenue > 0 ? ((totalRevenue - totalExpenses) / totalRevenue) * 100 : 0;
    const profitabilityScore = Math.min(METRIC_WEIGHTS.profitability.maxScore, Math.max(0, 
      profitMargin >= BENCHMARK_DATA.profitMargin.excellent ? METRIC_WEIGHTS.profitability.maxScore :
      profitMargin >= BENCHMARK_DATA.profitMargin.good ? METRIC_WEIGHTS.profitability.maxScore * 0.8 :
      profitMargin >= BENCHMARK_DATA.profitMargin.average ? METRIC_WEIGHTS.profitability.maxScore * 0.6 :
      profitMargin >= BENCHMARK_DATA.profitMargin.poor ? METRIC_WEIGHTS.profitability.maxScore * 0.4 :
      (profitMargin / BENCHMARK_DATA.profitMargin.poor) * METRIC_WEIGHTS.profitability.maxScore * 0.4
    ));
    
    metrics.push({
      id: "profitability",
      name: "Profitability",
      score: profitabilityScore,
      maxScore: METRIC_WEIGHTS.profitability.maxScore,
      value: profitMargin,
      displayValue: `${profitMargin.toFixed(1)}% margin`,
      status: profitabilityScore >= METRIC_WEIGHTS.profitability.maxScore * 0.8 ? "good" : 
              profitabilityScore >= METRIC_WEIGHTS.profitability.maxScore * 0.5 ? "warning" : "critical",
      icon: DollarSign,
      benchmark: BENCHMARK_DATA.profitMargin,
      trend: previousPeriodData?.profitMargin ? profitMargin - previousPeriodData.profitMargin : null,
      description: "Net profit as a percentage of total revenue",
      recommendations: generateProfitabilityRecommendations(profitMargin, totalRevenue, totalExpenses)
    });

    const cashFlowRatio = totalRevenue > 0 ? (unpaidBalance / totalRevenue) : 0;
    const cashFlowScore = Math.max(0, METRIC_WEIGHTS.cashFlow.maxScore * (1 - (cashFlowRatio / BENCHMARK_DATA.cashFlowRatio.poor)));
    
    metrics.push({
      id: "cashFlow",
      name: "Cash Flow",
      score: Math.min(METRIC_WEIGHTS.cashFlow.maxScore, cashFlowScore),
      maxScore: METRIC_WEIGHTS.cashFlow.maxScore,
      value: cashFlowRatio * 100,
      displayValue: `${(cashFlowRatio * 100).toFixed(1)}% receivables`,
      status: cashFlowRatio <= BENCHMARK_DATA.cashFlowRatio.good ? "good" :
              cashFlowRatio <= BENCHMARK_DATA.cashFlowRatio.average ? "warning" : "critical",
      icon: Wallet,
      benchmark: BENCHMARK_DATA.cashFlowRatio,
      trend: previousPeriodData?.cashFlowRatio ? (previousPeriodData.cashFlowRatio - cashFlowRatio) * 100 : null,
      description: "Outstanding receivables as a percentage of revenue",
      recommendations: generateCashFlowRecommendations(cashFlowRatio, unpaidBalance, invoices)
    });

    const growthScore = Math.min(METRIC_WEIGHTS.revenueGrowth.maxScore, Math.max(0,
      revenueChange >= BENCHMARK_DATA.growthRate.excellent ? METRIC_WEIGHTS.revenueGrowth.maxScore :
      revenueChange >= BENCHMARK_DATA.growthRate.good ? METRIC_WEIGHTS.revenueGrowth.maxScore * 0.8 :
      revenueChange >= BENCHMARK_DATA.growthRate.average ? METRIC_WEIGHTS.revenueGrowth.maxScore * 0.6 :
      revenueChange >= BENCHMARK_DATA.growthRate.poor ? METRIC_WEIGHTS.revenueGrowth.maxScore * 0.4 :
      Math.max(0, (revenueChange + 10) / 10) * METRIC_WEIGHTS.revenueGrowth.maxScore * 0.4
    ));

    metrics.push({
      id: "revenueGrowth",
      name: "Revenue Growth",
      score: growthScore,
      maxScore: METRIC_WEIGHTS.revenueGrowth.maxScore,
      value: revenueChange,
      displayValue: `${revenueChange >= 0 ? "+" : ""}${revenueChange.toFixed(1)}%`,
      status: revenueChange >= BENCHMARK_DATA.growthRate.good ? "good" :
              revenueChange >= BENCHMARK_DATA.growthRate.poor ? "warning" : "critical",
      icon: TrendingUp,
      benchmark: BENCHMARK_DATA.growthRate,
      trend: null,
      description: "Revenue change compared to previous period",
      recommendations: generateGrowthRecommendations(revenueChange, bookings)
    });

    const completedBookings = bookings.filter(b => b.status === "completed").length;
    const totalBookings = bookings.length;
    const utilizationRate = totalBookings > 0 ? (completedBookings / totalBookings) * 100 : 0;
    const utilizationScore = Math.min(METRIC_WEIGHTS.utilization.maxScore, (utilizationRate / 100) * METRIC_WEIGHTS.utilization.maxScore);

    metrics.push({
      id: "utilization",
      name: "Booking Utilization",
      score: utilizationScore,
      maxScore: METRIC_WEIGHTS.utilization.maxScore,
      value: utilizationRate,
      displayValue: `${utilizationRate.toFixed(0)}% completion`,
      status: utilizationRate >= BENCHMARK_DATA.utilization.good ? "good" :
              utilizationRate >= BENCHMARK_DATA.utilization.average ? "warning" : "critical",
      icon: Calendar,
      benchmark: BENCHMARK_DATA.utilization,
      trend: previousPeriodData?.utilizationRate ? utilizationRate - previousPeriodData.utilizationRate : null,
      description: "Percentage of bookings completed successfully",
      recommendations: generateUtilizationRecommendations(utilizationRate, bookings)
    });

    const successfulPayments = payments.filter(p => p.status === "completed").length;
    const totalPayments = payments.length;
    const paymentSuccessRate = totalPayments > 0 ? (successfulPayments / totalPayments) * 100 : 100;
    const paymentScore = Math.min(METRIC_WEIGHTS.paymentSuccess.maxScore, (paymentSuccessRate / 100) * METRIC_WEIGHTS.paymentSuccess.maxScore);

    metrics.push({
      id: "paymentSuccess",
      name: "Payment Success",
      score: paymentScore,
      maxScore: METRIC_WEIGHTS.paymentSuccess.maxScore,
      value: paymentSuccessRate,
      displayValue: `${paymentSuccessRate.toFixed(0)}% success`,
      status: paymentSuccessRate >= BENCHMARK_DATA.paymentSuccess.good ? "good" :
              paymentSuccessRate >= BENCHMARK_DATA.paymentSuccess.average ? "warning" : "critical",
      icon: CreditCard,
      benchmark: BENCHMARK_DATA.paymentSuccess,
      trend: previousPeriodData?.paymentSuccessRate ? paymentSuccessRate - previousPeriodData.paymentSuccessRate : null,
      description: "Percentage of payments processed successfully",
      recommendations: generatePaymentRecommendations(paymentSuccessRate, payments)
    });

    const activeStudents = students.filter(s => s.status === "active").length;
    const returningStudents = students.filter(s => s.bookings_count > 1).length;
    const retentionRate = activeStudents > 0 ? (returningStudents / activeStudents) * 100 : 0;
    const retentionScore = Math.min(METRIC_WEIGHTS.customerRetention.maxScore, (retentionRate / 100) * METRIC_WEIGHTS.customerRetention.maxScore);

    metrics.push({
      id: "customerRetention",
      name: "Customer Retention",
      score: retentionScore,
      maxScore: METRIC_WEIGHTS.customerRetention.maxScore,
      value: retentionRate,
      displayValue: `${retentionRate.toFixed(0)}% retention`,
      status: retentionRate >= BENCHMARK_DATA.retention.good ? "good" :
              retentionRate >= BENCHMARK_DATA.retention.average ? "warning" : "critical",
      icon: Users,
      benchmark: BENCHMARK_DATA.retention,
      trend: previousPeriodData?.retentionRate ? retentionRate - previousPeriodData.retentionRate : null,
      description: "Percentage of students who book multiple lessons",
      recommendations: generateRetentionRecommendations(retentionRate, students)
    });

    const cancelledBookings = bookings.filter(b => b.status === "cancelled").length;
    const noShowBookings = bookings.filter(b => b.status === "no_show").length;
    const inefficiencyRate = totalBookings > 0 ? ((cancelledBookings + noShowBookings) / totalBookings) * 100 : 0;
    const efficiencyRate = 100 - inefficiencyRate;
    const efficiencyScore = Math.min(METRIC_WEIGHTS.operationalEfficiency.maxScore, (efficiencyRate / 100) * METRIC_WEIGHTS.operationalEfficiency.maxScore);

    metrics.push({
      id: "operationalEfficiency",
      name: "Operational Efficiency",
      score: efficiencyScore,
      maxScore: METRIC_WEIGHTS.operationalEfficiency.maxScore,
      value: efficiencyRate,
      displayValue: `${efficiencyRate.toFixed(0)}% efficiency`,
      status: efficiencyRate >= 90 ? "good" : efficiencyRate >= 75 ? "warning" : "critical",
      icon: Zap,
      trend: previousPeriodData?.efficiencyRate ? efficiencyRate - previousPeriodData.efficiencyRate : null,
      description: "Percentage of bookings without cancellations or no-shows",
      recommendations: generateEfficiencyRecommendations(efficiencyRate, bookings)
    });

    const overdueInvoices = invoices.filter(inv => {
      if (inv.status === "paid") return false;
      const dueDate = new Date(inv.due_date);
      return differenceInDays(new Date(), dueDate) > 30;
    }).length;
    const overdueRatio = invoices.length > 0 ? (overdueInvoices / invoices.length) * 100 : 0;
    const riskScore = Math.max(0, METRIC_WEIGHTS.riskManagement.maxScore * (1 - (overdueRatio / 50)));

    metrics.push({
      id: "riskManagement",
      name: "Risk Management",
      score: Math.min(METRIC_WEIGHTS.riskManagement.maxScore, riskScore),
      maxScore: METRIC_WEIGHTS.riskManagement.maxScore,
      value: 100 - overdueRatio,
      displayValue: `${(100 - overdueRatio).toFixed(0)}% healthy`,
      status: overdueRatio <= 5 ? "good" : overdueRatio <= 15 ? "warning" : "critical",
      icon: Shield,
      trend: previousPeriodData?.overdueRatio ? (previousPeriodData.overdueRatio - overdueRatio) : null,
      description: "Percentage of accounts in good standing",
      recommendations: generateRiskRecommendations(overdueRatio, invoices)
    });

    return metrics;
  }, [totalRevenue, totalExpenses, unpaidBalance, revenueChange, bookings, payments, invoices, students, previousPeriodData]);

  const healthScore = useMemo(() => {
    const totalScore = healthMetrics.reduce((sum, m) => sum + m.score, 0);
    const maxPossible = healthMetrics.reduce((sum, m) => sum + m.maxScore, 0);
    const percentage = maxPossible > 0 ? (totalScore / maxPossible) * 100 : 0;

    let category = HEALTH_CATEGORIES.critical;
    for (const [key, cat] of Object.entries(HEALTH_CATEGORIES)) {
      if (percentage >= cat.min) {
        category = cat;
        break;
      }
    }

    const goodMetrics = healthMetrics.filter(m => m.status === "good").length;
    const warningMetrics = healthMetrics.filter(m => m.status === "warning").length;
    const criticalMetrics = healthMetrics.filter(m => m.status === "critical").length;

    return {
      totalScore: Math.round(totalScore),
      maxScore: maxPossible,
      percentage: Math.round(percentage),
      category,
      goodMetrics,
      warningMetrics,
      criticalMetrics,
      trend: previousPeriodData?.healthScore ? percentage - previousPeriodData.healthScore : null
    };
  }, [healthMetrics, previousPeriodData]);

  function generateProfitabilityRecommendations(margin, revenue, expenses) {
    const recommendations = [];
    if (margin < 20) {
      recommendations.push({
        priority: "high",
        title: "Review pricing strategy",
        description: "Consider adjusting lesson prices to improve margins while staying competitive."
      });
    }
    if (margin < 15) {
      recommendations.push({
        priority: "high",
        title: "Analyze expense categories",
        description: "Review operational costs for potential savings opportunities."
      });
    }
    if (margin >= 20 && margin < 30) {
      recommendations.push({
        priority: "medium",
        title: "Optimize revenue streams",
        description: "Consider package deals or premium services to increase average transaction value."
      });
    }
    return recommendations;
  }

  function generateCashFlowRecommendations(ratio, unpaid, invoicesList) {
    const recommendations = [];
    if (ratio > 0.15) {
      recommendations.push({
        priority: "high",
        title: "Improve collection process",
        description: "Implement automated payment reminders and follow-up procedures."
      });
    }
    if (ratio > 0.25) {
      recommendations.push({
        priority: "high",
        title: "Review payment terms",
        description: "Consider requiring deposits or shorter payment terms for new bookings."
      });
    }
    if (ratio > 0.10) {
      recommendations.push({
        priority: "medium",
        title: "Offer payment incentives",
        description: "Consider early payment discounts to encourage faster collections."
      });
    }
    return recommendations;
  }

  function generateGrowthRecommendations(growth, bookingsList) {
    const recommendations = [];
    if (growth < 5) {
      recommendations.push({
        priority: "high",
        title: "Increase marketing efforts",
        description: "Invest in targeted marketing to attract new students."
      });
    }
    if (growth < 10) {
      recommendations.push({
        priority: "medium",
        title: "Launch referral program",
        description: "Encourage existing students to refer friends and family."
      });
    }
    if (growth >= 10) {
      recommendations.push({
        priority: "low",
        title: "Scale operations",
        description: "Consider expanding capacity to sustain growth momentum."
      });
    }
    return recommendations;
  }

  function generateUtilizationRecommendations(rate, bookingsList) {
    const recommendations = [];
    if (rate < 75) {
      recommendations.push({
        priority: "high",
        title: "Reduce cancellations",
        description: "Implement cancellation policies and reminder systems."
      });
    }
    if (rate < 85) {
      recommendations.push({
        priority: "medium",
        title: "Optimize scheduling",
        description: "Use scheduling software to minimize gaps and conflicts."
      });
    }
    return recommendations;
  }

  function generatePaymentRecommendations(rate, paymentsList) {
    const recommendations = [];
    if (rate < 95) {
      recommendations.push({
        priority: "high",
        title: "Diversify payment options",
        description: "Offer multiple payment methods to reduce failed transactions."
      });
    }
    if (rate < 90) {
      recommendations.push({
        priority: "high",
        title: "Implement card-on-file",
        description: "Allow students to save payment methods for easier transactions."
      });
    }
    return recommendations;
  }

  function generateRetentionRecommendations(rate, studentsList) {
    const recommendations = [];
    if (rate < 50) {
      recommendations.push({
        priority: "high",
        title: "Improve student experience",
        description: "Focus on quality instruction and customer service to boost retention."
      });
    }
    if (rate < 65) {
      recommendations.push({
        priority: "medium",
        title: "Create loyalty program",
        description: "Reward returning students with discounts or perks."
      });
    }
    return recommendations;
  }

  function generateEfficiencyRecommendations(rate, bookingsList) {
    const recommendations = [];
    if (rate < 85) {
      recommendations.push({
        priority: "medium",
        title: "Implement confirmation system",
        description: "Send booking confirmations and reminders to reduce no-shows."
      });
    }
    if (rate < 75) {
      recommendations.push({
        priority: "high",
        title: "Review cancellation policy",
        description: "Consider implementing penalties for late cancellations."
      });
    }
    return recommendations;
  }

  function generateRiskRecommendations(overdueRate, invoicesList) {
    const recommendations = [];
    if (overdueRate > 10) {
      recommendations.push({
        priority: "high",
        title: "Address overdue accounts",
        description: "Create a collection strategy for accounts over 30 days past due."
      });
    }
    if (overdueRate > 20) {
      recommendations.push({
        priority: "high",
        title: "Review credit policies",
        description: "Consider requiring upfront payment for high-risk accounts."
      });
    }
    return recommendations;
  }

  const allRecommendations = useMemo(() => {
    return healthMetrics
      .flatMap(m => m.recommendations.map(r => ({ ...r, metric: m.name, metricId: m.id })))
      .sort((a, b) => {
        const priorityOrder = { high: 0, medium: 1, low: 2 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      });
  }, [healthMetrics]);

  const toggleRecommendation = useCallback((index) => {
    setExpandedRecommendations(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  }, []);

  const handleExport = useCallback((format) => {
    if (onExport) {
      onExport({
        format,
        data: {
          score: healthScore,
          metrics: healthMetrics,
          recommendations: allRecommendations
        }
      });
    }
  }, [onExport, healthScore, healthMetrics, allRecommendations]);

  const getStatusColor = (status) => {
    if (status === "good") return "green";
    if (status === "warning") return "amber";
    return "red";
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const ScoreCircle = ({ score, maxScore, size = "large" }) => {
    const percentage = maxScore > 0 ? (score / maxScore) * 100 : 0;
    const radius = size === "large" ? 88 : size === "medium" ? 44 : 28;
    const strokeWidth = size === "large" ? 12 : size === "medium" ? 8 : 4;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (percentage / 100) * circumference;

    return (
      <div className="relative" style={{ width: radius * 2 + strokeWidth * 2, height: radius * 2 + strokeWidth * 2 }}>
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx={radius + strokeWidth}
            cy={radius + strokeWidth}
            r={radius}
            stroke="#e5e7eb"
            strokeWidth={strokeWidth}
            fill="none"
          />
          <circle
            cx={radius + strokeWidth}
            cy={radius + strokeWidth}
            r={radius}
            stroke={healthScore.category.color === "emerald" ? "#10b981" :
                   healthScore.category.color === "green" ? "#22c55e" :
                   healthScore.category.color === "teal" ? "#14b8a6" :
                   healthScore.category.color === "blue" ? "#3b82f6" :
                   healthScore.category.color === "amber" ? "#f59e0b" :
                   healthScore.category.color === "orange" ? "#f97316" : "#ef4444"}
            strokeWidth={strokeWidth}
            fill="none"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {size === "large" && (
            <>
              <div className="text-4xl font-bold text-gray-900">{healthScore.percentage}</div>
              <div className="text-sm text-gray-500">of 100</div>
            </>
          )}
        </div>
      </div>
    );
  };

  const MetricCard = ({ metric }) => {
    const statusColor = getStatusColor(metric.status);
    const IconComponent = metric.icon;
    const isSelected = selectedMetric === metric.id;

    return (
      <button
        onClick={() => setSelectedMetric(isSelected ? null : metric.id)}
        className={`w-full p-4 rounded-xl border-2 transition text-left ${
          isSelected 
            ? `${statusColor === 'green' ? 'border-green-500 bg-green-50' :
                statusColor === 'amber' ? 'border-amber-500 bg-amber-50' :
                'border-red-500 bg-red-50'}`
            : "border-gray-200 bg-white hover:border-gray-300"
        }`}
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 ${
              statusColor === 'green' ? 'bg-green-100' :
              statusColor === 'amber' ? 'bg-amber-100' :
              'bg-red-100'
            } rounded-lg flex items-center justify-center`}>
              <IconComponent className={`w-4 h-4 ${
                statusColor === 'green' ? 'text-green-600' :
                statusColor === 'amber' ? 'text-amber-600' :
                'text-red-600'
              }`} />
            </div>
            <div>
              <p className="font-semibold text-gray-900 text-sm">{metric.name}</p>
              <p className="text-xs text-gray-500">{metric.displayValue}</p>
            </div>
          </div>
          <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
            statusColor === 'green' ? 'bg-green-100 text-green-700' :
            statusColor === 'amber' ? 'bg-amber-100 text-amber-700' :
            'bg-red-100 text-red-700'
          }`}>
            {metric.status}
          </span>
        </div>

        <div className="relative h-2 bg-gray-200 rounded-full overflow-hidden">
          <div 
            className={`absolute h-full transition-all duration-500 rounded-full ${
              statusColor === 'green' ? 'bg-green-500' :
              statusColor === 'amber' ? 'bg-amber-500' :
              'bg-red-500'
            }`}
            style={{ width: `${(metric.score / metric.maxScore) * 100}%` }}
          />
        </div>
        <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
          <span>{metric.score.toFixed(1)} / {metric.maxScore}</span>
          {metric.trend !== null && (
            <span className={`flex items-center gap-0.5 ${metric.trend >= 0 ? "text-green-600" : "text-red-600"}`}>
              {metric.trend >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
              {Math.abs(metric.trend).toFixed(1)}%
            </span>
          )}
        </div>
      </button>
    );
  };

  const selectedMetricData = selectedMetric ? healthMetrics.find(m => m.id === selectedMetric) : null;

  return (
    <div className="space-y-6">
      <div 
        className="p-8 rounded-2xl"
        style={{ 
          background: healthScore.category.color === "emerald" ? "linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%)" :
                     healthScore.category.color === "green" ? "linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%)" :
                     healthScore.category.color === "teal" ? "linear-gradient(135deg, #ccfbf1 0%, #99f6e4 100%)" :
                     healthScore.category.color === "blue" ? "linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)" :
                     healthScore.category.color === "amber" ? "linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)" :
                     healthScore.category.color === "orange" ? "linear-gradient(135deg, #fed7aa 0%, #fdba74 100%)" :
                     "linear-gradient(135deg, #fecaca 0%, #fca5a5 100%)"
        }}
      >
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="flex-1 text-center lg:text-left">
            <div className="flex items-center justify-center lg:justify-start gap-2 mb-2">
              <h3 className="text-2xl font-bold text-gray-900">Financial Health Score</h3>
              {healthScore.trend !== null && (
                <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold ${
                  healthScore.trend >= 0 ? "bg-green-200 text-green-800" : "bg-red-200 text-red-800"
                }`}>
                  {healthScore.trend >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {Math.abs(healthScore.trend).toFixed(1)}%
                </span>
              )}
            </div>
            <p className="text-gray-700 mb-6">{healthScore.category.description}</p>
            
            <div className="flex items-center justify-center lg:justify-start gap-6">
              <div>
                <div className={`text-6xl font-bold ${
                  healthScore.category.color === 'emerald' ? 'text-emerald-700' :
                  healthScore.category.color === 'green' ? 'text-green-700' :
                  healthScore.category.color === 'teal' ? 'text-teal-700' :
                  healthScore.category.color === 'blue' ? 'text-blue-700' :
                  healthScore.category.color === 'amber' ? 'text-amber-700' :
                  healthScore.category.color === 'orange' ? 'text-orange-700' :
                  'text-red-700'
                }`}>
                  {healthScore.percentage}
                </div>
                <div className="text-sm text-gray-600">out of 100</div>
              </div>
              <div className="h-16 w-px bg-gray-300" />
              <div>
                <div className={`text-5xl font-bold ${
                  healthScore.category.color === 'emerald' ? 'text-emerald-700' :
                  healthScore.category.color === 'green' ? 'text-green-700' :
                  healthScore.category.color === 'teal' ? 'text-teal-700' :
                  healthScore.category.color === 'blue' ? 'text-blue-700' :
                  healthScore.category.color === 'amber' ? 'text-amber-700' :
                  healthScore.category.color === 'orange' ? 'text-orange-700' :
                  'text-red-700'
                }`}>
                  {healthScore.category.grade}
                </div>
                <div className="text-sm text-gray-600">Grade</div>
              </div>
            </div>

            <div className="flex items-center justify-center lg:justify-start gap-4 mt-6">
              <div className="flex items-center gap-1">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm text-gray-700">{healthScore.goodMetrics} Good</span>
              </div>
              <div className="flex items-center gap-1">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span className="text-sm text-gray-700">{healthScore.warningMetrics} Warning</span>
              </div>
              <div className="flex items-center gap-1">
                <AlertTriangle className="w-4 h-4 text-red-600" />
                <span className="text-sm text-gray-700">{healthScore.criticalMetrics} Critical</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-center">
            <ScoreCircle score={healthScore.totalScore} maxScore={healthScore.maxScore} size="large" />
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <h4 className="text-lg font-bold text-gray-900">Performance Metrics</h4>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onRefresh?.()}
            disabled={isLoading}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <RefreshCw className={`w-5 h-5 text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
          </button>
          <button
            onClick={() => handleExport("pdf")}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <Download className="w-5 h-5 text-gray-600" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {healthMetrics.map((metric) => (
          <MetricCard key={metric.id} metric={metric} />
        ))}
      </div>

      {selectedMetricData && (
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 bg-${getStatusColor(selectedMetricData.status)}-100 rounded-xl flex items-center justify-center`}>
                <selectedMetricData.icon className={`w-5 h-5 text-${getStatusColor(selectedMetricData.status)}-600`} />
              </div>
              <div>
                <h4 className="font-bold text-gray-900">{selectedMetricData.name} Details</h4>
                <p className="text-sm text-gray-500">{selectedMetricData.description}</p>
              </div>
            </div>
            <button
              onClick={() => setSelectedMetric(null)}
              className="p-1 hover:bg-gray-100 rounded-lg transition"
            >
              <ChevronUp className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mb-4">
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-xs text-gray-500 mb-1">Current Score</p>
              <p className="text-2xl font-bold text-gray-900">{selectedMetricData.score.toFixed(1)} / {selectedMetricData.maxScore}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-xs text-gray-500 mb-1">Current Value</p>
              <p className="text-2xl font-bold text-gray-900">{selectedMetricData.displayValue}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-xs text-gray-500 mb-1">Trend</p>
              {selectedMetricData.trend !== null ? (
                <p className={`text-2xl font-bold ${selectedMetricData.trend >= 0 ? "text-green-600" : "text-red-600"}`}>
                  {selectedMetricData.trend >= 0 ? "+" : ""}{selectedMetricData.trend.toFixed(1)}%
                </p>
              ) : (
                <p className="text-2xl font-bold text-gray-400">—</p>
              )}
            </div>
          </div>

          {selectedMetricData.recommendations.length > 0 && (
            <div>
              <h5 className="font-semibold text-gray-900 mb-3">Recommendations</h5>
              <div className="space-y-2">
                {selectedMetricData.recommendations.map((rec, idx) => (
                  <div key={idx} className={`p-3 rounded-lg ${
                    rec.priority === "high" ? "bg-red-50 border border-red-200" :
                    rec.priority === "medium" ? "bg-amber-50 border border-amber-200" :
                    "bg-green-50 border border-green-200"
                  }`}>
                    <div className="flex items-start gap-2">
                      <Lightbulb className={`w-4 h-4 mt-0.5 ${
                        rec.priority === "high" ? "text-red-600" :
                        rec.priority === "medium" ? "text-amber-600" :
                        "text-green-600"
                      }`} />
                      <div>
                        <p className="font-medium text-gray-900 text-sm">{rec.title}</p>
                        <p className="text-xs text-gray-600">{rec.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {showRecommendations && allRecommendations.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Lightbulb className="w-6 h-6 text-amber-500" />
                <div>
                  <h4 className="font-bold text-gray-900">Action Recommendations</h4>
                  <p className="text-sm text-gray-500">{allRecommendations.length} suggestions to improve your score</p>
                </div>
              </div>
              <button
                onClick={() => setShowRecommendations(false)}
                className="text-sm text-gray-500 hover:text-gray-700"
              >
                Hide
              </button>
            </div>
          </div>

          <div className="divide-y divide-gray-100">
            {allRecommendations.slice(0, 6).map((rec, index) => (
              <div key={index} className="p-4 hover:bg-gray-50 transition">
                <div 
                  className="flex items-start gap-3 cursor-pointer"
                  onClick={() => toggleRecommendation(index)}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    rec.priority === "high" ? "bg-red-100" :
                    rec.priority === "medium" ? "bg-amber-100" :
                    "bg-green-100"
                  }`}>
                    {rec.priority === "high" ? <AlertTriangle className="w-4 h-4 text-red-600" /> :
                     rec.priority === "medium" ? <AlertCircle className="w-4 h-4 text-amber-600" /> :
                     <CheckCircle className="w-4 h-4 text-green-600" />}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold text-gray-900">{rec.title}</p>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                        rec.priority === "high" ? "bg-red-100 text-red-700" :
                        rec.priority === "medium" ? "bg-amber-100 text-amber-700" :
                        "bg-green-100 text-green-700"
                      }`}>
                        {rec.priority}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">{rec.description}</p>
                    <p className="text-xs text-gray-400 mt-1">Related to: {rec.metric}</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition ${
                    expandedRecommendations.has(index) ? "rotate-90" : ""
                  }`} />
                </div>
              </div>
            ))}
          </div>

          {allRecommendations.length > 6 && (
            <div className="p-4 bg-gray-50 text-center">
              <button className="text-sm text-indigo-600 font-medium hover:text-indigo-700">
                View all {allRecommendations.length} recommendations
              </button>
            </div>
          )}
        </div>
      )}

      {healthMetrics.every(m => m.status === "good") && (
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl border border-green-200">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h4 className="font-bold text-green-900 mb-1">Excellent Financial Health!</h4>
              <p className="text-green-700">
                Your driving school is performing exceptionally well across all financial metrics. 
                Keep up the great work and continue monitoring these indicators to maintain your success.
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-200">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-indigo-600 mt-0.5" />
          <div className="text-sm text-indigo-700">
            <p className="font-semibold mb-1">How the Score is Calculated</p>
            <p className="text-xs">
              The Financial Health Score combines {healthMetrics.length} key performance indicators, 
              weighted by importance: Profitability (25%), Cash Flow (20%), Revenue Growth (15%), 
              Utilization (12%), Payment Success (10%), Customer Retention (8%), 
              Operational Efficiency (5%), and Risk Management (5%).
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}