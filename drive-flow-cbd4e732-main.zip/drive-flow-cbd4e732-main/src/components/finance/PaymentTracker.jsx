import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  DollarSign,
  Clock,
  AlertTriangle,
  CheckCircle,
  Send,
  Mail,
  CreditCard,
  ExternalLink,
  MoreVertical,
  Eye,
  Download,
  Bell,
  Filter,
  Search,
  ChevronDown,
  XCircle,
  RefreshCw,
} from "lucide-react";
import { format, parseISO, differenceInDays, isAfter } from "date-fns";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";

const STATUS_CONFIG = {
  draft: { label: "Draft", color: "bg-zinc-100 text-zinc-700 border-zinc-200", icon: Clock },
  sent: { label: "Sent", color: "bg-blue-100 text-blue-700 border-blue-200", icon: Send },
  paid: { label: "Paid", color: "bg-emerald-100 text-emerald-700 border-emerald-200", icon: CheckCircle },
  overdue: { label: "Overdue", color: "bg-red-100 text-red-700 border-red-200", icon: AlertTriangle },
  cancelled: { label: "Cancelled", color: "bg-zinc-100 text-zinc-500 border-zinc-200", icon: XCircle },
};

export default function PaymentTracker({
  invoices,
  students,
  onSendReminder,
  onMarkPaid,
  onViewInvoice,
}) {
  const queryClient = useQueryClient();
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedInvoice, setExpandedInvoice] = useState(null);
  const [sendingReminder, setSendingReminder] = useState(null);

  const studentMap = useMemo(() => new Map(students.map((s) => [s.id, s])), [students]);

  // Process invoices to determine actual status
  const processedInvoices = useMemo(() => {
    const today = new Date();
    return invoices.map((invoice) => {
      let status = invoice.status;
      if (status !== "paid" && status !== "cancelled" && invoice.due_date) {
        const dueDate = parseISO(invoice.due_date);
        if (isAfter(today, dueDate)) {
          status = "overdue";
        }
      }
      const daysOverdue = invoice.due_date
        ? differenceInDays(today, parseISO(invoice.due_date))
        : 0;
      return { ...invoice, displayStatus: status, daysOverdue: Math.max(0, daysOverdue) };
    });
  }, [invoices]);

  // Filter invoices
  const filteredInvoices = useMemo(() => {
    return processedInvoices.filter((invoice) => {
      const matchesStatus = filterStatus === "all" || invoice.displayStatus === filterStatus;
      const student = studentMap.get(invoice.student_id);
      const matchesSearch =
        !searchQuery ||
        invoice.invoice_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student?.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student?.email?.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }, [processedInvoices, filterStatus, searchQuery, studentMap]);

  // Summary stats
  const stats = useMemo(() => {
    const pending = processedInvoices.filter((i) => i.displayStatus === "sent");
    const overdue = processedInvoices.filter((i) => i.displayStatus === "overdue");
    const paid = processedInvoices.filter((i) => i.displayStatus === "paid");
    
    return {
      totalPending: pending.reduce((sum, i) => sum + (i.total_amount - (i.amount_paid || 0)), 0),
      pendingCount: pending.length,
      totalOverdue: overdue.reduce((sum, i) => sum + (i.total_amount - (i.amount_paid || 0)), 0),
      overdueCount: overdue.length,
      totalCollected: paid.reduce((sum, i) => sum + i.total_amount, 0),
      paidCount: paid.length,
    };
  }, [processedInvoices]);

  const updateInvoiceMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Invoice.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invoices"] });
    },
  });

  const handleMarkPaid = async (invoice) => {
    try {
      await updateInvoiceMutation.mutateAsync({
        id: invoice.id,
        data: {
          status: "paid",
          amount_paid: invoice.total_amount,
          payment_method: "manual",
        },
      });
      toast.success("Invoice marked as paid");
      onMarkPaid?.(invoice);
    } catch (error) {
      toast.error("Failed to update invoice");
    }
  };

  const handleSendReminder = async (invoice) => {
    const student = studentMap.get(invoice.student_id);
    if (!student?.email) {
      toast.error("Student email not found");
      return;
    }

    setSendingReminder(invoice.id);

    try {
      await base44.integrations.Core.SendEmail({
        to: student.email,
        subject: `Payment Reminder - Invoice ${invoice.invoice_number}`,
        body: `
Dear ${student.full_name},

This is a friendly reminder that invoice ${invoice.invoice_number} for €${invoice.total_amount.toFixed(2)} is ${invoice.displayStatus === "overdue" ? "overdue" : "due soon"}.

Due Date: ${format(parseISO(invoice.due_date), "MMMM d, yyyy")}
Amount Due: €${(invoice.total_amount - (invoice.amount_paid || 0)).toFixed(2)}

Please make your payment at your earliest convenience.

Thank you,
${invoice.school_name || "Your Driving School"}
        `.trim(),
      });

      toast.success(`Reminder sent to ${student.full_name}`);
      onSendReminder?.(invoice, student);
    } catch (error) {
      toast.error("Failed to send reminder");
    } finally {
      setSendingReminder(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-zinc-200 p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-zinc-600">Pending</p>
              <p className="text-2xl font-bold text-zinc-900">€{stats.totalPending.toFixed(2)}</p>
              <p className="text-xs text-zinc-500">{stats.pendingCount} invoice{stats.pendingCount !== 1 ? "s" : ""}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-zinc-200 p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-red-100 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-zinc-600">Overdue</p>
              <p className="text-2xl font-bold text-red-600">€{stats.totalOverdue.toFixed(2)}</p>
              <p className="text-xs text-zinc-500">{stats.overdueCount} invoice{stats.overdueCount !== 1 ? "s" : ""}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-zinc-200 p-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-zinc-600">Collected</p>
              <p className="text-2xl font-bold text-emerald-600">€{stats.totalCollected.toFixed(2)}</p>
              <p className="text-xs text-zinc-500">{stats.paidCount} invoice{stats.paidCount !== 1 ? "s" : ""}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-zinc-200 p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search invoices..."
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-zinc-200 bg-zinc-50 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2">
            {["all", "sent", "overdue", "paid"].map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition ${
                  filterStatus === status
                    ? "bg-indigo-600 text-white"
                    : "bg-zinc-100 text-zinc-700 hover:bg-zinc-200"
                }`}
              >
                {status === "all" ? "All" : STATUS_CONFIG[status]?.label || status}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Invoice List */}
      <div className="bg-white rounded-2xl border border-zinc-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-zinc-50 border-b border-zinc-200">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-zinc-600 uppercase">Invoice</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-zinc-600 uppercase">Student</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-zinc-600 uppercase">Due Date</th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-zinc-600 uppercase">Amount</th>
                <th className="px-6 py-4 text-center text-xs font-semibold text-zinc-600 uppercase">Status</th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-zinc-600 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-zinc-500">
                    No invoices found
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((invoice) => {
                  const student = studentMap.get(invoice.student_id);
                  const statusConfig = STATUS_CONFIG[invoice.displayStatus] || STATUS_CONFIG.sent;
                  const StatusIcon = statusConfig.icon;
                  const amountDue = invoice.total_amount - (invoice.amount_paid || 0);

                  return (
                    <tr key={invoice.id} className="hover:bg-zinc-50 transition">
                      <td className="px-6 py-4">
                        <p className="text-sm font-semibold text-zinc-900">{invoice.invoice_number}</p>
                        <p className="text-xs text-zinc-500">
                          {invoice.issue_date && format(parseISO(invoice.issue_date), "MMM d, yyyy")}
                        </p>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm font-medium text-zinc-900">{student?.full_name || "—"}</p>
                        <p className="text-xs text-zinc-500">{student?.email || "—"}</p>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm text-zinc-900">
                          {invoice.due_date && format(parseISO(invoice.due_date), "MMM d, yyyy")}
                        </p>
                        {invoice.daysOverdue > 0 && (
                          <p className="text-xs text-red-600 font-medium">
                            {invoice.daysOverdue} day{invoice.daysOverdue !== 1 ? "s" : ""} overdue
                          </p>
                        )}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <p className="text-sm font-bold text-zinc-900">€{invoice.total_amount.toFixed(2)}</p>
                        {amountDue > 0 && amountDue < invoice.total_amount && (
                          <p className="text-xs text-zinc-500">€{amountDue.toFixed(2)} due</p>
                        )}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${statusConfig.color}`}>
                          <StatusIcon className="w-3 h-3" />
                          {statusConfig.label}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-end gap-2">
                          {invoice.displayStatus !== "paid" && invoice.displayStatus !== "cancelled" && (
                            <>
                              <button
                                onClick={() => handleSendReminder(invoice)}
                                disabled={sendingReminder === invoice.id}
                                className="p-2 rounded-lg hover:bg-blue-50 text-blue-600 transition"
                                title="Send Reminder"
                              >
                                {sendingReminder === invoice.id ? (
                                  <RefreshCw className="w-4 h-4 animate-spin" />
                                ) : (
                                  <Mail className="w-4 h-4" />
                                )}
                              </button>
                              <button
                                onClick={() => handleMarkPaid(invoice)}
                                className="p-2 rounded-lg hover:bg-emerald-50 text-emerald-600 transition"
                                title="Mark as Paid"
                              >
                                <CheckCircle className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => onViewInvoice?.(invoice)}
                            className="p-2 rounded-lg hover:bg-zinc-100 text-zinc-600 transition"
                            title="View Invoice"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}