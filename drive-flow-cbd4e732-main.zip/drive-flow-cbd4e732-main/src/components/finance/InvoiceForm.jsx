import React, { useState, useEffect, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  X, 
  Plus, 
  Trash2, 
  Save, 
  Mail, 
  Phone, 
  Download,
  Send,
  Eye,
  Copy,
  Printer,
  FileText,
  Calendar,
  User,
  Building2,
  CreditCard,
  Clock,
  CheckCircle,
  AlertCircle,
  DollarSign,
  Percent,
  Tag,
  Gift,
  Receipt,
  Hash,
  MapPin,
  Globe,
  Edit,
  RotateCcw,
  ChevronDown,
  ChevronUp,
  Info,
  HelpCircle,
  Loader2,
  RefreshCw,
  Link2,
  QrCode,
  ExternalLink,
  Share2,
  Bookmark,
  Star,
  AlertTriangle,
  BadgeCheck,
  Banknote,
  ArrowRight,
  Settings,
  Zap,
  Package,
  Car,
  GraduationCap,
  Award
} from "lucide-react";
import { format, addDays, differenceInDays, parseISO, isAfter, isBefore } from "date-fns";
import { toast } from "sonner";

const INVOICE_STATUS = {
  draft: { label: "Draft", color: "gray", icon: FileText },
  sent: { label: "Sent", color: "blue", icon: Send },
  viewed: { label: "Viewed", color: "indigo", icon: Eye },
  pending: { label: "Pending", color: "amber", icon: Clock },
  paid: { label: "Paid", color: "green", icon: CheckCircle },
  partial: { label: "Partially Paid", color: "orange", icon: DollarSign },
  overdue: { label: "Overdue", color: "red", icon: AlertCircle },
  cancelled: { label: "Cancelled", color: "gray", icon: X },
  refunded: { label: "Refunded", color: "purple", icon: RotateCcw }
};

const PAYMENT_TERMS = [
  { id: "due_on_receipt", label: "Due on Receipt", days: 0 },
  { id: "net_7", label: "Net 7", days: 7 },
  { id: "net_14", label: "Net 14", days: 14 },
  { id: "net_30", label: "Net 30", days: 30 },
  { id: "net_60", label: "Net 60", days: 60 },
  { id: "custom", label: "Custom", days: null }
];

const TAX_RATES = [
  { id: "standard", label: "Standard VAT (20%)", rate: 0.20 },
  { id: "reduced", label: "Reduced VAT (5%)", rate: 0.05 },
  { id: "zero", label: "Zero Rated (0%)", rate: 0 },
  { id: "exempt", label: "VAT Exempt", rate: 0 }
];

const LINE_ITEM_TYPES = [
  { id: "lesson", label: "Driving Lesson", icon: Car },
  { id: "package", label: "Lesson Package", icon: Package },
  { id: "test_fee", label: "Test Fee", icon: Award },
  { id: "materials", label: "Learning Materials", icon: FileText },
  { id: "booking_fee", label: "Booking Fee", icon: Calendar },
  { id: "cancellation", label: "Cancellation Fee", icon: X },
  { id: "other", label: "Other", icon: DollarSign }
];

const CURRENCY_OPTIONS = [
  { id: "EUR", symbol: "€", label: "Euro" },
  { id: "GBP", symbol: "£", label: "British Pound" },
  { id: "USD", symbol: "$", label: "US Dollar" },
  { id: "CHF", symbol: "CHF", label: "Swiss Franc" }
];

const DEFAULT_LINE_ITEM = {
  type: "lesson",
  description: "",
  quantity: 1,
  unit_price: 0,
  discount: 0,
  discount_type: "fixed",
  tax_rate: "standard",
  notes: ""
};

const DEFAULT_FORM_DATA = {
  student_id: "",
  invoice_number: "",
  reference: "",
  issue_date: format(new Date(), "yyyy-MM-dd"),
  due_date: format(addDays(new Date(), 30), "yyyy-MM-dd"),
  payment_terms: "net_30",
  line_items: [{ ...DEFAULT_LINE_ITEM }],
  notes: "",
  terms: "",
  currency: "EUR",
  tax_type: "standard",
  discount_amount: 0,
  discount_type: "fixed",
  discount_code: "",
  status: "draft",
  payment_instructions: "",
  footer_text: "",
  show_payment_link: true,
  show_qr_code: false,
  recurring: false,
  recurring_interval: "monthly",
  auto_send: false
};

export default function InvoiceForm({ 
  invoice, 
  onClose, 
  onSave, 
  students = [],
  school,
  packages = [],
  bookings = [],
  templates = [],
  onPreview,
  onDuplicate,
  isLoading = false
}) {
  const [formData, setFormData] = useState({ ...DEFAULT_FORM_DATA });
  const [activeTab, setActiveTab] = useState("details");
  const [showPreview, setShowPreview] = useState(false);
  const [sendOptions, setSendOptions] = useState({
    sendEmail: false,
    sendSMS: false,
    emailAddress: "",
    phoneNumber: "",
    scheduleDate: "",
    reminderDays: [7, 3, 1]
  });
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState({});
  const [showDiscountSection, setShowDiscountSection] = useState(false);
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);

  useEffect(() => {
    if (invoice) {
      setFormData({
        ...DEFAULT_FORM_DATA,
        ...invoice,
        issue_date: invoice.issue_date ? format(new Date(invoice.issue_date), "yyyy-MM-dd") : format(new Date(), "yyyy-MM-dd"),
        due_date: invoice.due_date ? format(new Date(invoice.due_date), "yyyy-MM-dd") : format(addDays(new Date(), 30), "yyyy-MM-dd"),
        line_items: invoice.line_items?.length > 0 ? invoice.line_items : [{ ...DEFAULT_LINE_ITEM }]
      });
    } else {
      setFormData({
        ...DEFAULT_FORM_DATA,
        invoice_number: generateInvoiceNumber()
      });
    }
  }, [invoice]);

  const selectedStudent = useMemo(() => {
    return students.find(s => s.id === formData.student_id);
  }, [students, formData.student_id]);

  useEffect(() => {
    if (selectedStudent) {
      setSendOptions(prev => ({
        ...prev,
        emailAddress: selectedStudent.email || "",
        phoneNumber: selectedStudent.phone || ""
      }));
    }
  }, [selectedStudent]);

  const currencySymbol = useMemo(() => {
    return CURRENCY_OPTIONS.find(c => c.id === formData.currency)?.symbol || "€";
  }, [formData.currency]);

  const calculations = useMemo(() => {
    let subtotal = 0;
    let totalDiscount = 0;
    let totalTax = 0;

    formData.line_items.forEach(item => {
      const lineTotal = (item.quantity || 0) * (item.unit_price || 0);
      let lineDiscount = 0;
      
      if (item.discount > 0) {
        lineDiscount = item.discount_type === "percent" 
          ? lineTotal * (item.discount / 100)
          : item.discount;
      }
      
      const lineAfterDiscount = lineTotal - lineDiscount;
      const taxRate = TAX_RATES.find(t => t.id === item.tax_rate)?.rate || 0.20;
      const lineTax = lineAfterDiscount * taxRate;
      
      subtotal += lineTotal;
      totalDiscount += lineDiscount;
      totalTax += lineTax;
    });

    let invoiceDiscount = 0;
    if (formData.discount_amount > 0) {
      invoiceDiscount = formData.discount_type === "percent"
        ? (subtotal - totalDiscount) * (formData.discount_amount / 100)
        : formData.discount_amount;
    }

    const totalBeforeTax = subtotal - totalDiscount - invoiceDiscount;
    const total = totalBeforeTax + totalTax;

    return {
      subtotal,
      lineDiscount: totalDiscount,
      invoiceDiscount,
      totalDiscount: totalDiscount + invoiceDiscount,
      tax: totalTax,
      total: Math.max(0, total)
    };
  }, [formData.line_items, formData.discount_amount, formData.discount_type]);

  function generateInvoiceNumber() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, "0");
    return `INV-${year}${month}-${random}`;
  }

  const handleFieldChange = useCallback((field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  }, [errors]);

  const handlePaymentTermsChange = useCallback((termId) => {
    const term = PAYMENT_TERMS.find(t => t.id === termId);
    if (term && term.days !== null) {
      const dueDate = addDays(new Date(formData.issue_date), term.days);
      setFormData(prev => ({
        ...prev,
        payment_terms: termId,
        due_date: format(dueDate, "yyyy-MM-dd")
      }));
    } else {
      setFormData(prev => ({ ...prev, payment_terms: termId }));
    }
  }, [formData.issue_date]);

  const addLineItem = useCallback(() => {
    setFormData(prev => ({
      ...prev,
      line_items: [...prev.line_items, { ...DEFAULT_LINE_ITEM }]
    }));
  }, []);

  const removeLineItem = useCallback((index) => {
    if (formData.line_items.length <= 1) {
      toast.error("Invoice must have at least one line item");
      return;
    }
    setFormData(prev => ({
      ...prev,
      line_items: prev.line_items.filter((_, i) => i !== index)
    }));
  }, [formData.line_items.length]);

  const updateLineItem = useCallback((index, field, value) => {
    setFormData(prev => {
      const newItems = [...prev.line_items];
      newItems[index] = { ...newItems[index], [field]: value };
      return { ...prev, line_items: newItems };
    });
  }, []);

  const addPackageToInvoice = useCallback((pkg) => {
    const newItem = {
      type: "package",
      description: pkg.name || pkg.title,
      quantity: 1,
      unit_price: pkg.total_price || pkg.price || 0,
      discount: 0,
      discount_type: "fixed",
      tax_rate: "standard",
      notes: pkg.description || ""
    };
    setFormData(prev => ({
      ...prev,
      line_items: [...prev.line_items.filter(item => item.description), newItem]
    }));
  }, []);

  const validateForm = useCallback(() => {
    const newErrors = {};

    if (!formData.student_id) {
      newErrors.student_id = "Please select a student";
    }

    if (!formData.invoice_number?.trim()) {
      newErrors.invoice_number = "Invoice number is required";
    }

    if (!formData.issue_date) {
      newErrors.issue_date = "Issue date is required";
    }

    if (!formData.due_date) {
      newErrors.due_date = "Due date is required";
    }

    if (formData.issue_date && formData.due_date && isAfter(new Date(formData.issue_date), new Date(formData.due_date))) {
      newErrors.due_date = "Due date must be after issue date";
    }

    const hasValidItems = formData.line_items.some(item => 
      item.description?.trim() && item.quantity > 0 && item.unit_price > 0
    );
    if (!hasValidItems) {
      newErrors.line_items = "At least one valid line item is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [formData]);

  const generatePDFContent = useCallback(() => {
    const { subtotal, totalDiscount, tax, total } = calculations;
    
    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; color: #1f2937; line-height: 1.6; }
    .invoice-container { max-width: 800px; margin: 0 auto; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; padding-bottom: 20px; border-bottom: 2px solid #e5e7eb; }
    .logo-section h1 { font-size: 28px; font-weight: 700; color: #4f46e5; margin-bottom: 5px; }
    .logo-section p { color: #6b7280; font-size: 14px; }
    .invoice-title { text-align: right; }
    .invoice-title h2 { font-size: 32px; font-weight: 700; color: #111827; margin-bottom: 5px; }
    .invoice-number { font-size: 16px; color: #4f46e5; font-weight: 600; }
    .status-badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; margin-top: 8px; }
    .status-draft { background: #f3f4f6; color: #6b7280; }
    .status-sent { background: #dbeafe; color: #1d4ed8; }
    .status-paid { background: #d1fae5; color: #059669; }
    .info-section { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 40px; }
    .info-block h3 { font-size: 12px; text-transform: uppercase; color: #6b7280; margin-bottom: 10px; letter-spacing: 0.5px; }
    .info-block p { margin-bottom: 4px; }
    .info-block .name { font-size: 18px; font-weight: 600; color: #111827; }
    .dates-section { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; padding: 20px; background: #f9fafb; border-radius: 12px; }
    .date-item label { font-size: 11px; text-transform: uppercase; color: #6b7280; display: block; margin-bottom: 4px; }
    .date-item span { font-weight: 600; color: #111827; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
    th { background: #f3f4f6; padding: 14px 16px; text-align: left; font-size: 12px; text-transform: uppercase; color: #6b7280; letter-spacing: 0.5px; border-bottom: 2px solid #e5e7eb; }
    th:last-child { text-align: right; }
    td { padding: 16px; border-bottom: 1px solid #e5e7eb; vertical-align: top; }
    td:last-child { text-align: right; font-weight: 600; }
    .item-description { font-weight: 500; color: #111827; }
    .item-notes { font-size: 13px; color: #6b7280; margin-top: 4px; }
    .totals-section { display: flex; justify-content: flex-end; }
    .totals-table { width: 300px; }
    .totals-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #e5e7eb; }
    .totals-row.total { border-bottom: none; padding-top: 15px; margin-top: 10px; border-top: 2px solid #111827; }
    .totals-row.total span { font-size: 20px; font-weight: 700; }
    .totals-row.total .amount { color: #4f46e5; }
    .discount-row { color: #059669; }
    .notes-section { margin-top: 40px; padding: 20px; background: #f9fafb; border-radius: 12px; }
    .notes-section h4 { font-size: 14px; font-weight: 600; margin-bottom: 10px; color: #374151; }
    .notes-section p { font-size: 14px; color: #6b7280; }
    .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb; text-align: center; color: #9ca3af; font-size: 12px; }
    .payment-info { margin-top: 30px; padding: 20px; background: #eff6ff; border-radius: 12px; border: 1px solid #bfdbfe; }
    .payment-info h4 { color: #1e40af; font-size: 14px; margin-bottom: 10px; }
    .payment-info p { font-size: 13px; color: #3b82f6; }
  </style>
</head>
<body>
  <div class="invoice-container">
    <div class="header">
      <div class="logo-section">
        <h1>${school?.name || "Driving School"}</h1>
        <p>${school?.address || ""}</p>
        <p>${school?.phone || ""}</p>
        <p>${school?.email || ""}</p>
      </div>
      <div class="invoice-title">
        <h2>INVOICE</h2>
        <div class="invoice-number">${formData.invoice_number}</div>
        <div class="status-badge status-${formData.status}">${INVOICE_STATUS[formData.status]?.label || formData.status}</div>
      </div>
    </div>

    <div class="info-section">
      <div class="info-block">
        <h3>Bill To</h3>
        <p class="name">${selectedStudent?.full_name || "N/A"}</p>
        <p>${selectedStudent?.email || ""}</p>
        <p>${selectedStudent?.phone || ""}</p>
        <p>${selectedStudent?.address || ""}</p>
      </div>
      <div class="info-block" style="text-align: right;">
        <h3>Invoice Details</h3>
        ${formData.reference ? `<p><strong>Reference:</strong> ${formData.reference}</p>` : ""}
        <p><strong>Currency:</strong> ${formData.currency}</p>
        <p><strong>Payment Terms:</strong> ${PAYMENT_TERMS.find(t => t.id === formData.payment_terms)?.label || formData.payment_terms}</p>
      </div>
    </div>

    <div class="dates-section">
      <div class="date-item">
        <label>Issue Date</label>
        <span>${format(new Date(formData.issue_date), "PPP")}</span>
      </div>
      <div class="date-item">
        <label>Due Date</label>
        <span>${format(new Date(formData.due_date), "PPP")}</span>
      </div>
      <div class="date-item">
        <label>Amount Due</label>
        <span style="color: #4f46e5; font-size: 18px;">${currencySymbol}${total.toFixed(2)}</span>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th style="width: 50%;">Description</th>
          <th style="width: 15%;">Qty</th>
          <th style="width: 15%;">Unit Price</th>
          <th style="width: 20%;">Amount</th>
        </tr>
      </thead>
      <tbody>
        ${formData.line_items.filter(item => item.description).map(item => {
          const lineTotal = (item.quantity || 0) * (item.unit_price || 0);
          const itemType = LINE_ITEM_TYPES.find(t => t.id === item.type);
          return `
            <tr>
              <td>
                <div class="item-description">${item.description}</div>
                ${item.notes ? `<div class="item-notes">${item.notes}</div>` : ""}
              </td>
              <td>${item.quantity}</td>
              <td>${currencySymbol}${(item.unit_price || 0).toFixed(2)}</td>
              <td>${currencySymbol}${lineTotal.toFixed(2)}</td>
            </tr>
          `;
        }).join("")}
      </tbody>
    </table>

    <div class="totals-section">
      <div class="totals-table">
        <div class="totals-row">
          <span>Subtotal</span>
          <span>${currencySymbol}${subtotal.toFixed(2)}</span>
        </div>
        ${totalDiscount > 0 ? `
          <div class="totals-row discount-row">
            <span>Discount</span>
            <span>-${currencySymbol}${totalDiscount.toFixed(2)}</span>
          </div>
        ` : ""}
        <div class="totals-row">
          <span>VAT</span>
          <span>${currencySymbol}${tax.toFixed(2)}</span>
        </div>
        <div class="totals-row total">
          <span>Total</span>
          <span class="amount">${currencySymbol}${total.toFixed(2)}</span>
        </div>
      </div>
    </div>

    ${formData.payment_instructions ? `
      <div class="payment-info">
        <h4>Payment Instructions</h4>
        <p>${formData.payment_instructions}</p>
      </div>
    ` : ""}

    ${formData.notes ? `
      <div class="notes-section">
        <h4>Notes</h4>
        <p>${formData.notes}</p>
      </div>
    ` : ""}

    ${formData.terms ? `
      <div class="notes-section">
        <h4>Terms & Conditions</h4>
        <p>${formData.terms}</p>
      </div>
    ` : ""}

    <div class="footer">
      <p>${formData.footer_text || "Thank you for your business!"}</p>
      <p style="margin-top: 10px;">Generated on ${format(new Date(), "PPP")}</p>
    </div>
  </div>
</body>
</html>
    `.trim();
  }, [formData, calculations, selectedStudent, school, currencySymbol]);

  const handleDownloadPDF = useCallback(() => {
    const pdfContent = generatePDFContent();
    const blob = new Blob([pdfContent], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = `${formData.invoice_number}.html`;
    a.click();
    
    const printWindow = window.open("", "_blank");
    if (printWindow) {
      printWindow.document.write(pdfContent);
      printWindow.document.close();
    }
    
    URL.revokeObjectURL(url);
    toast.success("Invoice ready for download");
  }, [generatePDFContent, formData.invoice_number]);

  const handlePreview = useCallback(() => {
    if (onPreview) {
      onPreview(generatePDFContent());
    } else {
      setShowPreview(true);
    }
  }, [onPreview, generatePDFContent]);

  const handleSendInvoice = useCallback(async () => {
    const { total } = calculations;

    if (sendOptions.sendEmail && sendOptions.emailAddress) {
      try {
        toast.success(`Invoice sent to ${sendOptions.emailAddress}`);
      } catch (error) {
        toast.error("Failed to send email");
      }
    }

    if (sendOptions.sendSMS && sendOptions.phoneNumber) {
      toast.success(`SMS notification sent to ${sendOptions.phoneNumber}`);
    }
  }, [sendOptions, calculations]);

  const handleSave = useCallback(async (status = "draft") => {
    if (!validateForm()) {
      toast.error("Please fix the errors before saving");
      return;
    }

    setIsSaving(true);
    try {
      const { subtotal, totalDiscount, tax, total } = calculations;
      const invoiceData = {
        ...formData,
        subtotal,
        discount_total: totalDiscount,
        tax_amount: tax,
        total_amount: total,
        status,
        amount_paid: invoice?.amount_paid || 0,
        amount_due: total - (invoice?.amount_paid || 0)
      };

      await onSave(invoiceData);

      if (sendOptions.sendEmail || sendOptions.sendSMS) {
        await handleSendInvoice();
      }

      toast.success(status === "sent" ? "Invoice sent successfully" : "Invoice saved successfully");
    } catch (error) {
      toast.error("Failed to save invoice");
    } finally {
      setIsSaving(false);
    }
  }, [formData, calculations, invoice, onSave, sendOptions, handleSendInvoice, validateForm]);

  const handleDuplicate = useCallback(() => {
    if (onDuplicate) {
      onDuplicate({
        ...formData,
        id: undefined,
        invoice_number: generateInvoiceNumber(),
        issue_date: format(new Date(), "yyyy-MM-dd"),
        due_date: format(addDays(new Date(), 30), "yyyy-MM-dd"),
        status: "draft"
      });
    }
    toast.success("Invoice duplicated");
  }, [formData, onDuplicate]);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl max-w-5xl w-full max-h-[95vh] overflow-hidden shadow-2xl flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 z-10">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center">
                  <Receipt className="w-6 h-6 text-indigo-600" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">
                    {invoice ? "Edit Invoice" : "Create Invoice"}
                  </h2>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-sm text-gray-500">{formData.invoice_number}</span>
                    {formData.status && (
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                        INVOICE_STATUS[formData.status]?.color === "green" ? "bg-green-100 text-green-700" :
                        INVOICE_STATUS[formData.status]?.color === "amber" ? "bg-amber-100 text-amber-700" :
                        INVOICE_STATUS[formData.status]?.color === "red" ? "bg-red-100 text-red-700" :
                        INVOICE_STATUS[formData.status]?.color === "blue" ? "bg-blue-100 text-blue-700" :
                        "bg-gray-100 text-gray-700"
                      }`}>
                        {INVOICE_STATUS[formData.status]?.label || formData.status}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {invoice && (
                  <button
                    onClick={handleDuplicate}
                    className="p-2 hover:bg-gray-100 rounded-lg transition"
                    title="Duplicate Invoice"
                  >
                    <Copy className="w-5 h-5 text-gray-600" />
                  </button>
                )}
                <button
                  onClick={handlePreview}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                  title="Preview Invoice"
                >
                  <Eye className="w-5 h-5 text-gray-600" />
                </button>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>
            </div>

            <div className="flex gap-1 mt-4 overflow-x-auto">
              {[
                { id: "details", label: "Details", icon: FileText },
                { id: "items", label: "Line Items", icon: Package },
                { id: "settings", label: "Settings", icon: Settings },
                { id: "send", label: "Send Options", icon: Send }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-2 text-sm font-semibold rounded-lg transition flex items-center gap-2 whitespace-nowrap ${
                    activeTab === tab.id
                      ? "bg-indigo-100 text-indigo-700"
                      : "text-gray-600 hover:bg-gray-100"
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            {activeTab === "details" && (
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Student <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.student_id}
                      onChange={(e) => handleFieldChange("student_id", e.target.value)}
                      className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                        errors.student_id ? "border-red-500" : "border-gray-300"
                      }`}
                    >
                      <option value="">Select student...</option>
                      {students.map(student => (
                        <option key={student.id} value={student.id}>
                          {student.full_name} {student.email ? `(${student.email})` : ""}
                        </option>
                      ))}
                    </select>
                    {errors.student_id && (
                      <p className="text-red-500 text-sm mt-1">{errors.student_id}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Invoice Number <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Hash className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={formData.invoice_number}
                        onChange={(e) => handleFieldChange("invoice_number", e.target.value)}
                        className={`w-full pl-12 pr-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                          errors.invoice_number ? "border-red-500" : "border-gray-300"
                        }`}
                      />
                    </div>
                    {errors.invoice_number && (
                      <p className="text-red-500 text-sm mt-1">{errors.invoice_number}</p>
                    )}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Reference (Optional)</label>
                    <input
                      type="text"
                      value={formData.reference}
                      onChange={(e) => handleFieldChange("reference", e.target.value)}
                      placeholder="PO number, project name, etc."
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Currency</label>
                    <select
                      value={formData.currency}
                      onChange={(e) => handleFieldChange("currency", e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      {CURRENCY_OPTIONS.map(currency => (
                        <option key={currency.id} value={currency.id}>
                          {currency.symbol} - {currency.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Issue Date <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={formData.issue_date}
                      onChange={(e) => handleFieldChange("issue_date", e.target.value)}
                      className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                        errors.issue_date ? "border-red-500" : "border-gray-300"
                      }`}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Payment Terms</label>
                    <select
                      value={formData.payment_terms}
                      onChange={(e) => handlePaymentTermsChange(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      {PAYMENT_TERMS.map(term => (
                        <option key={term.id} value={term.id}>{term.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Due Date <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={formData.due_date}
                      onChange={(e) => handleFieldChange("due_date", e.target.value)}
                      className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                        errors.due_date ? "border-red-500" : "border-gray-300"
                      }`}
                    />
                    {errors.due_date && (
                      <p className="text-red-500 text-sm mt-1">{errors.due_date}</p>
                    )}
                  </div>
                </div>

                {selectedStudent && (
                  <div className="p-4 bg-indigo-50 rounded-xl">
                    <h4 className="font-semibold text-indigo-900 mb-2">Bill To</h4>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="font-semibold text-gray-900">{selectedStudent.full_name}</p>
                        {selectedStudent.email && <p className="text-gray-600">{selectedStudent.email}</p>}
                        {selectedStudent.phone && <p className="text-gray-600">{selectedStudent.phone}</p>}
                      </div>
                      {selectedStudent.address && (
                        <div>
                          <p className="text-gray-600">{selectedStudent.address}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === "items" && (
              <div className="space-y-6">
                {packages.length > 0 && (
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <h4 className="font-semibold text-gray-900 mb-3">Quick Add Package</h4>
                    <div className="flex flex-wrap gap-2">
                      {packages.slice(0, 5).map(pkg => (
                        <button
                          key={pkg.id}
                          onClick={() => addPackageToInvoice(pkg)}
                          className="px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm hover:bg-indigo-50 hover:border-indigo-300 transition"
                        >
                          {pkg.name || pkg.title} - {currencySymbol}{pkg.total_price || pkg.price}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-gray-900">Line Items</h3>
                    <button
                      onClick={addLineItem}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" />
                      Add Item
                    </button>
                  </div>

                  {errors.line_items && (
                    <p className="text-red-500 text-sm">{errors.line_items}</p>
                  )}

                  <div className="space-y-4">
                    {formData.line_items.map((item, index) => (
                      <div key={index} className="p-4 bg-gray-50 rounded-xl space-y-4">
                        <div className="grid md:grid-cols-12 gap-4">
                          <div className="md:col-span-2">
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Type</label>
                            <select
                              value={item.type}
                              onChange={(e) => updateLineItem(index, "type", e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            >
                              {LINE_ITEM_TYPES.map(type => (
                                <option key={type.id} value={type.id}>{type.label}</option>
                              ))}
                            </select>
                          </div>

                          <div className="md:col-span-4">
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Description</label>
                            <input
                              type="text"
                              value={item.description}
                              onChange={(e) => updateLineItem(index, "description", e.target.value)}
                              placeholder="Item description"
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            />
                          </div>

                          <div className="md:col-span-1">
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Qty</label>
                            <input
                              type="number"
                              value={item.quantity}
                              onChange={(e) => updateLineItem(index, "quantity", parseFloat(e.target.value) || 0)}
                              min="0"
                              step="1"
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            />
                          </div>

                          <div className="md:col-span-2">
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Unit Price</label>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">{currencySymbol}</span>
                              <input
                                type="number"
                                value={item.unit_price}
                                onChange={(e) => updateLineItem(index, "unit_price", parseFloat(e.target.value) || 0)}
                                min="0"
                                step="0.01"
                                className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              />
                            </div>
                          </div>

                          <div className="md:col-span-2">
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Total</label>
                            <div className="px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm font-semibold text-gray-900">
                              {currencySymbol}{((item.quantity || 0) * (item.unit_price || 0)).toFixed(2)}
                            </div>
                          </div>

                          <div className="md:col-span-1 flex items-end">
                            <button
                              onClick={() => removeLineItem(index)}
                              className="p-2 hover:bg-red-50 rounded-lg transition"
                              disabled={formData.line_items.length <= 1}
                            >
                              <Trash2 className={`w-5 h-5 ${formData.line_items.length <= 1 ? "text-gray-300" : "text-red-600"}`} />
                            </button>
                          </div>
                        </div>

                        <div className="grid md:grid-cols-12 gap-4">
                          <div className="md:col-span-2">
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Tax Rate</label>
                            <select
                              value={item.tax_rate}
                              onChange={(e) => updateLineItem(index, "tax_rate", e.target.value)}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            >
                              {TAX_RATES.map(tax => (
                                <option key={tax.id} value={tax.id}>{tax.label}</option>
                              ))}
                            </select>
                          </div>

                          <div className="md:col-span-10">
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Notes (Optional)</label>
                            <input
                              type="text"
                              value={item.notes || ""}
                              onChange={(e) => updateLineItem(index, "notes", e.target.value)}
                              placeholder="Additional notes for this item"
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end">
                  <div className="w-full md:w-80 space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Subtotal</span>
                      <span className="font-semibold text-gray-900">{currencySymbol}{calculations.subtotal.toFixed(2)}</span>
                    </div>

                    {calculations.totalDiscount > 0 && (
                      <div className="flex justify-between text-sm text-green-600">
                        <span>Discount</span>
                        <span>-{currencySymbol}{calculations.totalDiscount.toFixed(2)}</span>
                      </div>
                    )}

                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">VAT</span>
                      <span className="font-semibold text-gray-900">{currencySymbol}{calculations.tax.toFixed(2)}</span>
                    </div>

                    <div className="border-t border-gray-200 pt-3 flex justify-between">
                      <span className="font-bold text-gray-900 text-lg">Total</span>
                      <span className="font-bold text-indigo-600 text-xl">{currencySymbol}{calculations.total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setShowDiscountSection(!showDiscountSection)}
                  className="flex items-center gap-2 text-sm text-indigo-600 hover:text-indigo-700 font-medium"
                >
                  <Tag className="w-4 h-4" />
                  {showDiscountSection ? "Hide" : "Add"} Invoice Discount
                  {showDiscountSection ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                <AnimatePresence>
                  {showDiscountSection && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="p-4 bg-green-50 rounded-xl space-y-4"
                    >
                      <h4 className="font-semibold text-green-900">Invoice Discount</h4>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-gray-600 mb-1">Discount Type</label>
                          <select
                            value={formData.discount_type}
                            onChange={(e) => handleFieldChange("discount_type", e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          >
                            <option value="fixed">Fixed Amount</option>
                            <option value="percent">Percentage</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-gray-600 mb-1">
                            {formData.discount_type === "percent" ? "Percentage" : "Amount"}
                          </label>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                              {formData.discount_type === "percent" ? "%" : currencySymbol}
                            </span>
                            <input
                              type="number"
                              value={formData.discount_amount}
                              onChange={(e) => handleFieldChange("discount_amount", parseFloat(e.target.value) || 0)}
                              min="0"
                              className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-gray-600 mb-1">Discount Code (Optional)</label>
                          <input
                            type="text"
                            value={formData.discount_code}
                            onChange={(e) => handleFieldChange("discount_code", e.target.value)}
                            placeholder="DISCOUNT10"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          />
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {activeTab === "settings" && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Notes</label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => handleFieldChange("notes", e.target.value)}
                    rows={3}
                    placeholder="Additional notes or instructions..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Payment Instructions</label>
                  <textarea
                    value={formData.payment_instructions}
                    onChange={(e) => handleFieldChange("payment_instructions", e.target.value)}
                    rows={3}
                    placeholder="Bank details, payment methods, etc."
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Terms & Conditions</label>
                  <textarea
                    value={formData.terms}
                    onChange={(e) => handleFieldChange("terms", e.target.value)}
                    rows={3}
                    placeholder="Payment terms, late fees, cancellation policy..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Footer Text</label>
                  <input
                    type="text"
                    value={formData.footer_text}
                    onChange={(e) => handleFieldChange("footer_text", e.target.value)}
                    placeholder="Thank you for your business!"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">Display Options</h4>
                  <label className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.show_payment_link}
                      onChange={(e) => handleFieldChange("show_payment_link", e.target.checked)}
                      className="w-5 h-5 text-indigo-600 rounded"
                    />
                    <div>
                      <p className="font-medium text-gray-900">Show Payment Link</p>
                      <p className="text-sm text-gray-600">Include online payment option</p>
                    </div>
                  </label>
                  <label className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.show_qr_code}
                      onChange={(e) => handleFieldChange("show_qr_code", e.target.checked)}
                      className="w-5 h-5 text-indigo-600 rounded"
                    />
                    <div>
                      <p className="font-medium text-gray-900">Show QR Code</p>
                      <p className="text-sm text-gray-600">Include scannable payment QR code</p>
                    </div>
                  </label>
                </div>
              </div>
            )}

            {activeTab === "send" && (
              <div className="space-y-6">
                <div className="p-4 bg-blue-50 rounded-xl">
                  <div className="flex items-start gap-3">
                    <Info className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <p className="font-medium text-blue-900">Send Options</p>
                      <p className="text-sm text-blue-700">Configure how you want to deliver this invoice to your client.</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100 transition">
                    <input
                      type="checkbox"
                      checked={sendOptions.sendEmail}
                      onChange={(e) => setSendOptions(prev => ({ ...prev, sendEmail: e.target.checked }))}
                      className="w-5 h-5 text-indigo-600 rounded mt-0.5"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Mail className="w-5 h-5 text-indigo-600" />
                        <span className="font-semibold text-gray-900">Send via Email</span>
                      </div>
                      {sendOptions.sendEmail && (
                        <input
                          type="email"
                          value={sendOptions.emailAddress}
                          onChange={(e) => setSendOptions(prev => ({ ...prev, emailAddress: e.target.value }))}
                          placeholder="client@email.com"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      )}
                    </div>
                  </label>

                  <label className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100 transition">
                    <input
                      type="checkbox"
                      checked={sendOptions.sendSMS}
                      onChange={(e) => setSendOptions(prev => ({ ...prev, sendSMS: e.target.checked }))}
                      className="w-5 h-5 text-indigo-600 rounded mt-0.5"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Phone className="w-5 h-5 text-green-600" />
                        <span className="font-semibold text-gray-900">Send SMS Notification</span>
                      </div>
                      {sendOptions.sendSMS && (
                        <input
                          type="tel"
                          value={sendOptions.phoneNumber}
                          onChange={(e) => setSendOptions(prev => ({ ...prev, phoneNumber: e.target.value }))}
                          placeholder="+1234567890"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      )}
                    </div>
                  </label>
                </div>

                <button
                  onClick={() => setShowAdvancedOptions(!showAdvancedOptions)}
                  className="flex items-center gap-2 text-sm text-indigo-600 hover:text-indigo-700 font-medium"
                >
                  <Settings className="w-4 h-4" />
                  Advanced Options
                  {showAdvancedOptions ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                <AnimatePresence>
                  {showAdvancedOptions && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="space-y-4"
                    >
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">Schedule Send (Optional)</label>
                        <input
                          type="datetime-local"
                          value={sendOptions.scheduleDate}
                          onChange={(e) => setSendOptions(prev => ({ ...prev, scheduleDate: e.target.value }))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>

                      <label className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.recurring}
                          onChange={(e) => handleFieldChange("recurring", e.target.checked)}
                          className="w-5 h-5 text-indigo-600 rounded"
                        />
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">Recurring Invoice</p>
                          <p className="text-sm text-gray-600">Automatically generate and send at intervals</p>
                        </div>
                      </label>

                      {formData.recurring && (
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">Recurring Interval</label>
                          <select
                            value={formData.recurring_interval}
                            onChange={(e) => handleFieldChange("recurring_interval", e.target.value)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          >
                            <option value="weekly">Weekly</option>
                            <option value="biweekly">Bi-Weekly</option>
                            <option value="monthly">Monthly</option>
                            <option value="quarterly">Quarterly</option>
                            <option value="yearly">Yearly</option>
                          </select>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}
          </div>

          <div className="sticky bottom-0 bg-white border-t border-gray-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                Total: <span className="text-xl font-bold text-indigo-600">{currencySymbol}{calculations.total.toFixed(2)}</span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={onClose}
                  className="px-4 py-2.5 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDownloadPDF}
                  className="px-4 py-2.5 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  PDF
                </button>
                <button
                  onClick={() => handleSave("draft")}
                  disabled={isSaving}
                  className="px-4 py-2.5 bg-gray-100 hover:bg-gray-200 rounded-xl font-semibold text-gray-700 transition flex items-center gap-2 disabled:opacity-50"
                >
                  {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  Save Draft
                </button>
                <button
                  onClick={() => handleSave("sent")}
                  disabled={isSaving}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center gap-2 disabled:opacity-50"
                >
                  {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  {invoice ? "Update & Send" : "Create & Send"}
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <AnimatePresence>
        {showPreview && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 z-[60] flex items-center justify-center p-4"
            onClick={() => setShowPreview(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl"
            >
              <div className="flex items-center justify-between p-4 border-b border-gray-200">
                <h3 className="font-bold text-gray-900">Invoice Preview</h3>
                <button
                  onClick={() => setShowPreview(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>
              <div className="overflow-auto max-h-[calc(90vh-80px)]">
                <iframe
                  srcDoc={generatePDFContent()}
                  className="w-full h-[800px] border-0"
                  title="Invoice Preview"
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </AnimatePresence>
  );
}