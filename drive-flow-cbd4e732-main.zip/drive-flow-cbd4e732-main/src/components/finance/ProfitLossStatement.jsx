import React, { useState, useEffect, useMemo, useCallback } from "react";
import { 
  ChevronDown, 
  ChevronRight, 
  ChevronUp,
  TrendingUp, 
  TrendingDown,
  DollarSign,
  Users,
  Car,
  Fuel,
  Wrench,
  Shield,
  Building2,
  Megaphone,
  Settings,
  Calendar,
  Download,
  Filter,
  RefreshCw,
  Info,
  AlertCircle,
  CheckCircle,
  Clock,
  Eye,
  EyeOff,
  BarChart3,
  PieChart,
  FileText,
  Printer,
  Mail,
  ArrowUpRight,
  ArrowDownRight,
  Percent,
  Target,
  Zap,
  CreditCard,
  Banknote,
  Receipt,
  Wallet,
  Calculator,
  BookOpen,
  GraduationCap,
  Award,
  Package,
  Loader2,
  HelpCircle
} from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, differenceInDays, parseISO, isWithinInterval } from "date-fns";

const REVENUE_CATEGORIES = [
  { id: "lesson", label: "Individual Lessons", icon: Car, color: "emerald" },
  { id: "package", label: "Package Sales", icon: Package, color: "blue" },
  { id: "test_fee", label: "Test Fees", icon: Award, color: "purple" },
  { id: "materials", label: "Learning Materials", icon: BookOpen, color: "amber" },
  { id: "cancellation_fee", label: "Cancellation Fees", icon: Clock, color: "orange" },
  { id: "booking_deposit", label: "Booking Deposits", icon: Wallet, color: "cyan" },
  { id: "other", label: "Other Revenue", icon: DollarSign, color: "gray" }
];

const EXPENSE_CATEGORIES = {
  direct: {
    label: "Direct Costs",
    description: "Costs directly tied to delivering lessons",
    items: [
      { id: "instructor_commission", label: "Instructor Commissions", icon: Users, defaultPercentage: 70 },
      { id: "fuel", label: "Fuel Costs", icon: Fuel, defaultPerVehicle: 200 },
      { id: "vehicle_maintenance", label: "Vehicle Maintenance", icon: Wrench, defaultPerVehicle: 150 },
      { id: "vehicle_insurance", label: "Vehicle Insurance", icon: Shield, defaultPerVehicle: 100 }
    ]
  },
  operating: {
    label: "Operating Expenses",
    description: "Regular business operating costs",
    items: [
      { id: "facility", label: "Facility Costs", icon: Building2, defaultAmount: 1500 },
      { id: "business_insurance", label: "Business Insurance", icon: Shield, defaultAmount: 500 },
      { id: "marketing", label: "Marketing & Advertising", icon: Megaphone, defaultAmount: 400 },
      { id: "software", label: "Software & Tools", icon: Settings, defaultAmount: 200 },
      { id: "admin", label: "Administrative", icon: FileText, defaultAmount: 300 },
      { id: "training", label: "Staff Training", icon: GraduationCap, defaultAmount: 150 }
    ]
  },
  taxes: {
    label: "Taxes & Compliance",
    description: "Tax obligations and compliance costs",
    items: [
      { id: "vat", label: "VAT Payable", icon: Receipt, calculateFromRevenue: true, rate: 0.20 },
      { id: "corporate_tax", label: "Corporate Tax", icon: Calculator, calculateFromProfit: true, rate: 0.25 },
      { id: "payroll_tax", label: "Payroll Tax", icon: Users, calculateFromPayroll: true, rate: 0.15 }
    ]
  }
};

const COMPARISON_PERIODS = [
  { id: "previous_month", label: "vs Previous Month" },
  { id: "previous_quarter", label: "vs Previous Quarter" },
  { id: "previous_year", label: "vs Previous Year" },
  { id: "budget", label: "vs Budget" }
];

export default function ProfitLossStatement({ 
  payments = [], 
  bookings = [], 
  instructors = [], 
  vehicles = [],
  expenses = [],
  dateRange,
  budget,
  previousPeriodData,
  school,
  settings,
  onExport,
  onRefresh,
  isLoading = false
}) {
  const [expandedSections, setExpandedSections] = useState({ 
    revenue: true, 
    directCosts: true,
    operatingExpenses: true,
    taxes: false
  });
  const [showPercentages, setShowPercentages] = useState(true);
  const [showComparison, setShowComparison] = useState(true);
  const [comparisonPeriod, setComparisonPeriod] = useState("previous_month");
  const [showDetailedView, setShowDetailedView] = useState(false);
  const [selectedView, setSelectedView] = useState("standard");
  const [showBudgetVariance, setShowBudgetVariance] = useState(false);
  const [customExpenseOverrides, setCustomExpenseOverrides] = useState({});

  const filterPaymentsByDateRange = useCallback((paymentsList) => {
    if (!dateRange?.start || !dateRange?.end) return paymentsList;
    
    return paymentsList.filter(p => {
      const paymentDate = new Date(p.payment_date || p.created_date);
      return isWithinInterval(paymentDate, { 
        start: new Date(dateRange.start), 
        end: new Date(dateRange.end) 
      });
    });
  }, [dateRange]);

  const filterBookingsByDateRange = useCallback((bookingsList) => {
    if (!dateRange?.start || !dateRange?.end) return bookingsList;
    
    return bookingsList.filter(b => {
      const bookingDate = new Date(b.start_datetime || b.date);
      return isWithinInterval(bookingDate, { 
        start: new Date(dateRange.start), 
        end: new Date(dateRange.end) 
      });
    });
  }, [dateRange]);

  const filteredPayments = useMemo(() => filterPaymentsByDateRange(payments), [payments, filterPaymentsByDateRange]);
  const filteredBookings = useMemo(() => filterBookingsByDateRange(bookings), [bookings, filterBookingsByDateRange]);
  const completedBookings = useMemo(() => filteredBookings.filter(b => b.status === "completed"), [filteredBookings]);

  const revenueBreakdown = useMemo(() => {
    const breakdown = {};
    
    REVENUE_CATEGORIES.forEach(cat => {
      breakdown[cat.id] = {
        ...cat,
        amount: 0,
        count: 0,
        items: []
      };
    });

    filteredPayments.forEach(payment => {
      const type = payment.payment_type || "other";
      const category = breakdown[type] || breakdown.other;
      
      category.amount += payment.amount || 0;
      category.count += 1;
      category.items.push(payment);
    });

    return breakdown;
  }, [filteredPayments]);

  const totalRevenue = useMemo(() => {
    return Object.values(revenueBreakdown).reduce((sum, cat) => sum + cat.amount, 0);
  }, [revenueBreakdown]);

  const grossRevenue = useMemo(() => {
    const vatRate = settings?.vatRate || 0.20;
    return totalRevenue / (1 + vatRate);
  }, [totalRevenue, settings]);

  const expenseCalculations = useMemo(() => {
    const calculations = {
      direct: { items: [], total: 0 },
      operating: { items: [], total: 0 },
      taxes: { items: [], total: 0 }
    };

    const instructorCommission = customExpenseOverrides.instructor_commission ?? 
      completedBookings.reduce((sum, b) => {
        const commissionRate = b.instructor_commission_rate || 0.70;
        return sum + ((b.price || 0) * commissionRate);
      }, 0);
    
    calculations.direct.items.push({
      id: "instructor_commission",
      label: "Instructor Commissions",
      icon: Users,
      amount: instructorCommission,
      percentage: totalRevenue > 0 ? (instructorCommission / totalRevenue) * 100 : 0,
      details: `Based on ${completedBookings.length} completed lessons`
    });

    const vehicleCount = vehicles.length || 1;
    
    const fuelCost = customExpenseOverrides.fuel ?? 
      (vehicleCount * (settings?.fuelCostPerVehicle || 200));
    calculations.direct.items.push({
      id: "fuel",
      label: "Fuel Costs",
      icon: Fuel,
      amount: fuelCost,
      percentage: totalRevenue > 0 ? (fuelCost / totalRevenue) * 100 : 0,
      details: `${vehicleCount} vehicle(s) @ €${settings?.fuelCostPerVehicle || 200}/vehicle`
    });

    const maintenanceCost = customExpenseOverrides.vehicle_maintenance ?? 
      (vehicleCount * (settings?.maintenanceCostPerVehicle || 150));
    calculations.direct.items.push({
      id: "vehicle_maintenance",
      label: "Vehicle Maintenance",
      icon: Wrench,
      amount: maintenanceCost,
      percentage: totalRevenue > 0 ? (maintenanceCost / totalRevenue) * 100 : 0,
      details: `${vehicleCount} vehicle(s) @ €${settings?.maintenanceCostPerVehicle || 150}/vehicle`
    });

    const vehicleInsurance = customExpenseOverrides.vehicle_insurance ?? 
      (vehicleCount * (settings?.insuranceCostPerVehicle || 100));
    calculations.direct.items.push({
      id: "vehicle_insurance",
      label: "Vehicle Insurance",
      icon: Shield,
      amount: vehicleInsurance,
      percentage: totalRevenue > 0 ? (vehicleInsurance / totalRevenue) * 100 : 0,
      details: `${vehicleCount} vehicle(s)`
    });

    calculations.direct.total = calculations.direct.items.reduce((sum, item) => sum + item.amount, 0);

    EXPENSE_CATEGORIES.operating.items.forEach(expenseType => {
      const expenseAmount = customExpenseOverrides[expenseType.id] ?? 
        expenses.filter(e => e.category === expenseType.id).reduce((sum, e) => sum + (e.amount || 0), 0) ||
        expenseType.defaultAmount;
      
      calculations.operating.items.push({
        id: expenseType.id,
        label: expenseType.label,
        icon: expenseType.icon,
        amount: expenseAmount,
        percentage: totalRevenue > 0 ? (expenseAmount / totalRevenue) * 100 : 0
      });
    });

    calculations.operating.total = calculations.operating.items.reduce((sum, item) => sum + item.amount, 0);

    const vatRate = settings?.vatRate || 0.20;
    const vatAmount = totalRevenue * (vatRate / (1 + vatRate));
    calculations.taxes.items.push({
      id: "vat",
      label: "VAT Payable",
      icon: Receipt,
      amount: vatAmount,
      percentage: totalRevenue > 0 ? (vatAmount / totalRevenue) * 100 : 0,
      details: `${(vatRate * 100).toFixed(0)}% of gross revenue`
    });

    calculations.taxes.total = calculations.taxes.items.reduce((sum, item) => sum + item.amount, 0);

    return calculations;
  }, [completedBookings, vehicles, expenses, totalRevenue, settings, customExpenseOverrides]);

  const totalDirectCosts = expenseCalculations.direct.total;
  const totalOperatingExpenses = expenseCalculations.operating.total;
  const totalTaxes = expenseCalculations.taxes.total;
  const totalExpenses = totalDirectCosts + totalOperatingExpenses;

  const grossProfit = totalRevenue - totalDirectCosts;
  const operatingProfit = grossProfit - totalOperatingExpenses;
  const netProfitBeforeTax = operatingProfit;
  const netProfit = operatingProfit - totalTaxes;

  const grossMargin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;
  const operatingMargin = totalRevenue > 0 ? (operatingProfit / totalRevenue) * 100 : 0;
  const netMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  const previousPeriodMetrics = useMemo(() => {
    if (!previousPeriodData) return null;

    const prevRevenue = previousPeriodData.totalRevenue || 0;
    const prevExpenses = previousPeriodData.totalExpenses || 0;
    const prevProfit = previousPeriodData.netProfit || 0;

    return {
      revenue: prevRevenue,
      expenses: prevExpenses,
      profit: prevProfit,
      revenueChange: prevRevenue > 0 ? ((totalRevenue - prevRevenue) / prevRevenue) * 100 : 0,
      expensesChange: prevExpenses > 0 ? ((totalExpenses - prevExpenses) / prevExpenses) * 100 : 0,
      profitChange: prevProfit !== 0 ? ((netProfit - prevProfit) / Math.abs(prevProfit)) * 100 : 0
    };
  }, [previousPeriodData, totalRevenue, totalExpenses, netProfit]);

  const perLessonMetrics = useMemo(() => {
    const lessonCount = completedBookings.length || 1;
    
    return {
      revenuePerLesson: totalRevenue / lessonCount,
      costPerLesson: totalExpenses / lessonCount,
      profitPerLesson: netProfit / lessonCount,
      directCostPerLesson: totalDirectCosts / lessonCount,
      operatingCostPerLesson: totalOperatingExpenses / lessonCount
    };
  }, [completedBookings.length, totalRevenue, totalExpenses, netProfit, totalDirectCosts, totalOperatingExpenses]);

  const toggleSection = useCallback((section) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  }, []);

  const handleExport = useCallback((format) => {
    if (onExport) {
      onExport({
        format,
        data: {
          revenue: revenueBreakdown,
          expenses: expenseCalculations,
          totals: {
            totalRevenue,
            grossProfit,
            operatingProfit,
            netProfit
          },
          margins: {
            grossMargin,
            operatingMargin,
            netMargin
          },
          perLesson: perLessonMetrics,
          dateRange
        }
      });
    }
  }, [onExport, revenueBreakdown, expenseCalculations, totalRevenue, grossProfit, operatingProfit, netProfit, grossMargin, operatingMargin, netMargin, perLessonMetrics, dateRange]);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const formatPercentage = (value) => {
    return `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`;
  };

  const RevenueItem = ({ item, totalRevenue }) => {
    const percentage = totalRevenue > 0 ? (item.amount / totalRevenue) * 100 : 0;
    const IconComponent = item.icon || DollarSign;
    
    return (
      <div className="flex items-center justify-between py-3 px-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition">
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 bg-${item.color}-100 rounded-lg flex items-center justify-center`}>
            <IconComponent className={`w-4 h-4 text-${item.color}-600`} />
          </div>
          <div>
            <span className="text-sm font-medium text-gray-900">{item.label}</span>
            {item.count > 0 && (
              <p className="text-xs text-gray-500">{item.count} transaction(s)</p>
            )}
          </div>
        </div>
        <div className="text-right">
          <span className="text-base font-bold text-gray-900">{formatCurrency(item.amount)}</span>
          {showPercentages && (
            <span className="text-xs text-gray-500 ml-2">({percentage.toFixed(1)}%)</span>
          )}
        </div>
      </div>
    );
  };

  const ExpenseItem = ({ item, totalRevenue }) => {
    const IconComponent = item.icon || DollarSign;
    
    return (
      <div className="flex items-center justify-between py-3 px-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
            <IconComponent className="w-4 h-4 text-red-600" />
          </div>
          <div>
            <span className="text-sm font-medium text-gray-900">{item.label}</span>
            {item.details && (
              <p className="text-xs text-gray-500">{item.details}</p>
            )}
          </div>
        </div>
        <div className="text-right">
          <span className="text-base font-bold text-red-600">{formatCurrency(item.amount)}</span>
          {showPercentages && (
            <span className="text-xs text-gray-500 ml-2">({item.percentage.toFixed(1)}%)</span>
          )}
        </div>
      </div>
    );
  };

  const SectionHeader = ({ title, subtitle, total, isExpanded, onToggle, variant = "default" }) => {
    const bgColor = variant === "revenue" ? "bg-green-50 hover:bg-green-100" :
                   variant === "expense" ? "bg-red-50 hover:bg-red-100" :
                   "bg-gray-50 hover:bg-gray-100";
    const textColor = variant === "revenue" ? "text-green-700" :
                     variant === "expense" ? "text-red-700" :
                     "text-gray-900";

    return (
      <button
        onClick={onToggle}
        className={`w-full p-4 ${bgColor} rounded-xl flex items-center justify-between transition`}
      >
        <div className="flex items-center gap-3">
          {isExpanded ? (
            <ChevronDown className="w-5 h-5 text-gray-600" />
          ) : (
            <ChevronRight className="w-5 h-5 text-gray-600" />
          )}
          <div className="text-left">
            <span className="text-lg font-bold text-gray-900">{title}</span>
            {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
          </div>
        </div>
        <span className={`text-2xl font-bold ${textColor}`}>{formatCurrency(total)}</span>
      </button>
    );
  };

  const ComparisonBadge = ({ current, previous, label }) => {
    if (!previous) return null;
    
    const change = previous !== 0 ? ((current - previous) / Math.abs(previous)) * 100 : 0;
    const isPositive = change >= 0;
    
    return (
      <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
        isPositive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
      }`}>
        {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
        {formatPercentage(change)}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-1">Profit & Loss Statement</h3>
            <p className="text-sm text-gray-500">
              {dateRange?.start && dateRange?.end ? (
                `${format(new Date(dateRange.start), "MMM d, yyyy")} - ${format(new Date(dateRange.end), "MMM d, yyyy")}`
              ) : (
                "Comprehensive income and expense breakdown"
              )}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onRefresh?.()}
              disabled={isLoading}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
              title="Refresh data"
            >
              <RefreshCw className={`w-5 h-5 text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
            </button>
            <button
              onClick={() => setShowPercentages(!showPercentages)}
              className={`p-2 rounded-lg transition ${showPercentages ? "bg-indigo-100 text-indigo-600" : "hover:bg-gray-100 text-gray-600"}`}
              title="Toggle percentages"
            >
              <Percent className="w-5 h-5" />
            </button>
            <button
              onClick={() => handleExport("pdf")}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
              title="Export PDF"
            >
              <Download className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-gray-100 rounded-lg">
            {[
              { id: "standard", label: "Standard" },
              { id: "detailed", label: "Detailed" },
              { id: "summary", label: "Summary" }
            ].map(view => (
              <button
                key={view.id}
                onClick={() => setSelectedView(view.id)}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition ${
                  selectedView === view.id
                    ? "bg-white text-gray-900 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                {view.label}
              </button>
            ))}
          </div>

          {showComparison && (
            <select
              value={comparisonPeriod}
              onChange={(e) => setComparisonPeriod(e.target.value)}
              className="px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {COMPARISON_PERIODS.map(period => (
                <option key={period.id} value={period.id}>{period.label}</option>
              ))}
            </select>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="space-y-3">
          <SectionHeader
            title="Revenue"
            subtitle={`${Object.values(revenueBreakdown).reduce((sum, cat) => sum + cat.count, 0)} transactions`}
            total={totalRevenue}
            isExpanded={expandedSections.revenue}
            onToggle={() => toggleSection("revenue")}
            variant="revenue"
          />

          {expandedSections.revenue && (
            <div className="space-y-2 pl-4">
              {Object.values(revenueBreakdown)
                .filter(item => item.amount > 0 || selectedView === "detailed")
                .sort((a, b) => b.amount - a.amount)
                .map(item => (
                  <RevenueItem key={item.id} item={item} totalRevenue={totalRevenue} />
                ))}
            </div>
          )}
        </div>

        <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-gray-900">Gross Profit</span>
              {previousPeriodMetrics && (
                <ComparisonBadge current={grossProfit} previous={previousPeriodMetrics.profit * 0.8} />
              )}
            </div>
            <div className="text-right">
              <span className="text-2xl font-bold text-indigo-700">{formatCurrency(grossProfit)}</span>
              <p className="text-sm text-gray-600">{grossMargin.toFixed(1)}% margin</p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <SectionHeader
            title="Direct Costs"
            subtitle="Costs directly tied to delivering services"
            total={totalDirectCosts}
            isExpanded={expandedSections.directCosts}
            onToggle={() => toggleSection("directCosts")}
            variant="expense"
          />

          {expandedSections.directCosts && (
            <div className="space-y-2 pl-4">
              {expenseCalculations.direct.items.map(item => (
                <ExpenseItem key={item.id} item={item} totalRevenue={totalRevenue} />
              ))}
            </div>
          )}
        </div>

        <div className="space-y-3">
          <SectionHeader
            title="Operating Expenses"
            subtitle="Regular business operating costs"
            total={totalOperatingExpenses}
            isExpanded={expandedSections.operatingExpenses}
            onToggle={() => toggleSection("operatingExpenses")}
            variant="expense"
          />

          {expandedSections.operatingExpenses && (
            <div className="space-y-2 pl-4">
              {expenseCalculations.operating.items.map(item => (
                <ExpenseItem key={item.id} item={item} totalRevenue={totalRevenue} />
              ))}
            </div>
          )}
        </div>

        <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-gray-900">Operating Profit</span>
            </div>
            <div className="text-right">
              <span className={`text-2xl font-bold ${operatingProfit >= 0 ? "text-purple-700" : "text-red-700"}`}>
                {formatCurrency(operatingProfit)}
              </span>
              <p className="text-sm text-gray-600">{operatingMargin.toFixed(1)}% margin</p>
            </div>
          </div>
        </div>

        {selectedView === "detailed" && (
          <div className="space-y-3">
            <SectionHeader
              title="Taxes & Compliance"
              subtitle="Tax obligations"
              total={totalTaxes}
              isExpanded={expandedSections.taxes}
              onToggle={() => toggleSection("taxes")}
              variant="expense"
            />

            {expandedSections.taxes && (
              <div className="space-y-2 pl-4">
                {expenseCalculations.taxes.items.map(item => (
                  <ExpenseItem key={item.id} item={item} totalRevenue={totalRevenue} />
                ))}
              </div>
            )}
          </div>
        )}

        <div className={`p-6 rounded-2xl ${
          netProfit >= 0 
            ? "bg-gradient-to-br from-green-100 to-emerald-100" 
            : "bg-gradient-to-br from-red-100 to-orange-100"
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <span className="text-xl font-bold text-gray-900">Net Profit</span>
              {netProfit >= 0 ? (
                <TrendingUp className="w-6 h-6 text-green-700" />
              ) : (
                <TrendingDown className="w-6 h-6 text-red-700" />
              )}
              {previousPeriodMetrics && (
                <ComparisonBadge current={netProfit} previous={previousPeriodMetrics.profit} />
              )}
            </div>
            <div className="text-right">
              <span className={`text-3xl font-bold ${netProfit >= 0 ? "text-green-700" : "text-red-700"}`}>
                {formatCurrency(netProfit)}
              </span>
              <p className={`text-sm font-medium ${netProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
                {netMargin.toFixed(1)}% profit margin
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-gray-200/50">
            <div className="text-center">
              <p className="text-xs text-gray-600 mb-1">Gross Margin</p>
              <p className="text-lg font-bold text-gray-900">{grossMargin.toFixed(1)}%</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-600 mb-1">Operating Margin</p>
              <p className="text-lg font-bold text-gray-900">{operatingMargin.toFixed(1)}%</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-600 mb-1">Net Margin</p>
              <p className={`text-lg font-bold ${netProfit >= 0 ? "text-green-700" : "text-red-700"}`}>
                {netMargin.toFixed(1)}%
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="text-center p-4 bg-gray-50 rounded-xl">
            <p className="text-xs text-gray-500 mb-1">Revenue/Lesson</p>
            <p className="text-lg font-bold text-gray-900">{formatCurrency(perLessonMetrics.revenuePerLesson)}</p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-xl">
            <p className="text-xs text-gray-500 mb-1">Direct Cost/Lesson</p>
            <p className="text-lg font-bold text-gray-900">{formatCurrency(perLessonMetrics.directCostPerLesson)}</p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-xl">
            <p className="text-xs text-gray-500 mb-1">Operating Cost/Lesson</p>
            <p className="text-lg font-bold text-gray-900">{formatCurrency(perLessonMetrics.operatingCostPerLesson)}</p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-xl">
            <p className="text-xs text-gray-500 mb-1">Total Cost/Lesson</p>
            <p className="text-lg font-bold text-gray-900">{formatCurrency(perLessonMetrics.costPerLesson)}</p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-xl">
            <p className="text-xs text-gray-500 mb-1">Profit/Lesson</p>
            <p className={`text-lg font-bold ${perLessonMetrics.profitPerLesson >= 0 ? "text-green-700" : "text-red-700"}`}>
              {formatCurrency(perLessonMetrics.profitPerLesson)}
            </p>
          </div>
        </div>

        <div className="p-4 bg-indigo-50 rounded-xl">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-indigo-600 mt-0.5" />
            <div className="text-sm text-indigo-700">
              <p className="font-semibold mb-1">Statement Notes</p>
              <ul className="list-disc list-inside space-y-1 text-xs">
                <li>Based on {completedBookings.length} completed lessons in the period</li>
                <li>Direct costs include instructor commissions, fuel, maintenance, and vehicle insurance</li>
                <li>Operating expenses are estimated based on typical driving school operations</li>
                <li>VAT is calculated at {((settings?.vatRate || 0.20) * 100).toFixed(0)}% of gross revenue</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}