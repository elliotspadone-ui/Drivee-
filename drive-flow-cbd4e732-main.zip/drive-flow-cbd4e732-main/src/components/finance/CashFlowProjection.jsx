import React, { useState, useEffect, useMemo, useCallback } from "react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend,
  AreaChart,
  Area,
  BarChart,
  Bar,
  ComposedChart,
  ReferenceLine
} from "recharts";
import { 
  TrendingUp, 
  TrendingDown,
  Calendar, 
  DollarSign,
  AlertCircle,
  CheckCircle,
  Clock,
  ChevronDown,
  ChevronUp,
  Info,
  RefreshCw,
  Download,
  Settings,
  Eye,
  EyeOff,
  Target,
  Zap,
  BarChart3,
  PieChart,
  Activity,
  Wallet,
  CreditCard,
  Banknote,
  ArrowUpRight,
  ArrowDownRight,
  Percent,
  Users,
  Car,
  GraduationCap,
  Filter,
  Loader2
} from "lucide-react";
import { 
  format, 
  addDays, 
  addWeeks, 
  addMonths, 
  startOfWeek, 
  endOfWeek,
  startOfMonth,
  endOfMonth,
  differenceInDays,
  isSameWeek,
  isSameMonth,
  subWeeks,
  subMonths,
  parseISO,
  isAfter,
  isBefore,
  isWithinInterval
} from "date-fns";

const PROJECTION_PERIODS = [
  { id: "4_weeks", label: "4 Weeks", weeks: 4 },
  { id: "8_weeks", label: "8 Weeks", weeks: 8 },
  { id: "12_weeks", label: "12 Weeks", weeks: 12 },
  { id: "6_months", label: "6 Months", weeks: 26 },
  { id: "12_months", label: "12 Months", weeks: 52 }
];

const CHART_TYPES = [
  { id: "line", label: "Line Chart", icon: Activity },
  { id: "area", label: "Area Chart", icon: BarChart3 },
  { id: "bar", label: "Bar Chart", icon: BarChart3 },
  { id: "composed", label: "Combined", icon: PieChart }
];

const EXPENSE_CATEGORIES = [
  { id: "fuel", label: "Fuel", percentage: 15 },
  { id: "vehicle_maintenance", label: "Vehicle Maintenance", percentage: 10 },
  { id: "insurance", label: "Insurance", percentage: 8 },
  { id: "marketing", label: "Marketing", percentage: 5 },
  { id: "software", label: "Software & Tools", percentage: 3 },
  { id: "rent", label: "Office Rent", percentage: 12 },
  { id: "salaries", label: "Staff Salaries", percentage: 35 },
  { id: "taxes", label: "Taxes", percentage: 10 },
  { id: "other", label: "Other", percentage: 2 }
];

const CONFIDENCE_LEVELS = {
  high: { label: "High", color: "green", multiplier: 0.95 },
  medium: { label: "Medium", color: "amber", multiplier: 0.85 },
  low: { label: "Low", color: "red", multiplier: 0.70 }
};

const SCENARIO_TYPES = [
  { id: "optimistic", label: "Optimistic", multiplier: 1.20, color: "#10b981" },
  { id: "realistic", label: "Realistic", multiplier: 1.0, color: "#6366f1" },
  { id: "conservative", label: "Conservative", multiplier: 0.80, color: "#f59e0b" }
];

export default function CashFlowProjection({ 
  bookings = [], 
  payments = [], 
  expenses = [],
  packages = [],
  instructors = [],
  students = [],
  school,
  settings,
  onExport,
  onRefresh,
  isLoading = false
}) {
  const [projectionPeriod, setProjectionPeriod] = useState("12_weeks");
  const [chartType, setChartType] = useState("composed");
  const [showExpenseBreakdown, setShowExpenseBreakdown] = useState(false);
  const [showScenarios, setShowScenarios] = useState(true);
  const [selectedScenario, setSelectedScenario] = useState("realistic");
  const [showAdvancedMetrics, setShowAdvancedMetrics] = useState(false);
  const [walkInBuffer, setWalkInBuffer] = useState(15);
  const [expenseRatio, setExpenseRatio] = useState(30);
  const [showSettings, setShowSettings] = useState(false);
  const [visibleLines, setVisibleLines] = useState({
    scheduledRevenue: true,
    projectedRevenue: true,
    expenses: true,
    netCashFlow: true,
    optimistic: false,
    conservative: false
  });

  const selectedPeriod = useMemo(() => {
    return PROJECTION_PERIODS.find(p => p.id === projectionPeriod);
  }, [projectionPeriod]);

  const historicalMetrics = useMemo(() => {
    const today = new Date();
    const thirtyDaysAgo = subMonths(today, 1);
    const sixtyDaysAgo = subMonths(today, 2);
    const ninetyDaysAgo = subMonths(today, 3);

    const recentPayments = payments.filter(p => {
      const date = new Date(p.payment_date || p.created_date);
      return isAfter(date, thirtyDaysAgo);
    });

    const previousPayments = payments.filter(p => {
      const date = new Date(p.payment_date || p.created_date);
      return isAfter(date, sixtyDaysAgo) && isBefore(date, thirtyDaysAgo);
    });

    const recentRevenue = recentPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
    const previousRevenue = previousPayments.reduce((sum, p) => sum + (p.amount || 0), 0);

    const recentBookingsCount = bookings.filter(b => {
      const date = new Date(b.start_datetime);
      return isAfter(date, thirtyDaysAgo) && b.status === "completed";
    }).length;

    const avgRevenuePerBooking = recentBookingsCount > 0 
      ? recentRevenue / recentBookingsCount 
      : 45;

    const weeklyPayments = {};
    payments.forEach(p => {
      const date = new Date(p.payment_date || p.created_date);
      if (isAfter(date, ninetyDaysAgo)) {
        const weekKey = format(startOfWeek(date), "yyyy-MM-dd");
        weeklyPayments[weekKey] = (weeklyPayments[weekKey] || 0) + (p.amount || 0);
      }
    });

    const weeklyValues = Object.values(weeklyPayments);
    const avgWeeklyRevenue = weeklyValues.length > 0
      ? weeklyValues.reduce((a, b) => a + b, 0) / weeklyValues.length
      : 0;

    const growthRate = previousRevenue > 0 
      ? ((recentRevenue - previousRevenue) / previousRevenue) * 100 
      : 0;

    const completionRate = bookings.length > 0
      ? (bookings.filter(b => b.status === "completed").length / bookings.length) * 100
      : 85;

    const cancellationRate = bookings.length > 0
      ? (bookings.filter(b => b.status === "cancelled").length / bookings.length) * 100
      : 5;

    return {
      recentRevenue,
      previousRevenue,
      avgRevenuePerBooking,
      avgWeeklyRevenue,
      growthRate,
      completionRate,
      cancellationRate,
      totalBookings: bookings.length,
      completedBookings: bookings.filter(b => b.status === "completed").length
    };
  }, [bookings, payments]);

  const projections = useMemo(() => {
    const today = new Date();
    const weeksToProject = selectedPeriod?.weeks || 12;
    const projectionData = [];
    
    let cumulativeRevenue = 0;
    let cumulativeExpenses = 0;
    let cumulativeNet = 0;

    for (let i = 0; i < weeksToProject; i++) {
      const weekStart = addWeeks(today, i);
      const weekEnd = addWeeks(today, i + 1);
      
      const scheduledBookings = bookings.filter(b => {
        const bookingDate = new Date(b.start_datetime);
        return b.status === "confirmed" && 
               isWithinInterval(bookingDate, { start: weekStart, end: weekEnd });
      });

      const scheduledRevenue = scheduledBookings.reduce((sum, b) => {
        return sum + (b.price || b.lesson_price || historicalMetrics.avgRevenuePerBooking);
      }, 0);
      
      const walkInRevenue = scheduledRevenue * (walkInBuffer / 100);
      const baseProjectedRevenue = scheduledRevenue + walkInRevenue;
      
      const growthFactor = 1 + (historicalMetrics.growthRate / 100 / 52) * i;
      const seasonalFactor = getSeasonalFactor(weekStart);
      const completionFactor = historicalMetrics.completionRate / 100;
      
      const projectedRevenue = baseProjectedRevenue * growthFactor * seasonalFactor * completionFactor;

      const scheduledExpenses = expenses.filter(e => {
        const expenseDate = new Date(e.date || e.due_date);
        return isWithinInterval(expenseDate, { start: weekStart, end: weekEnd });
      }).reduce((sum, e) => sum + (e.amount || 0), 0);

      const estimatedExpenses = scheduledExpenses > 0 
        ? scheduledExpenses 
        : projectedRevenue * (expenseRatio / 100);

      const netCashFlow = projectedRevenue - estimatedExpenses;

      cumulativeRevenue += projectedRevenue;
      cumulativeExpenses += estimatedExpenses;
      cumulativeNet += netCashFlow;

      const scenarioMultiplier = SCENARIO_TYPES.find(s => s.id === selectedScenario)?.multiplier || 1;
      const optimisticRevenue = projectedRevenue * SCENARIO_TYPES.find(s => s.id === "optimistic").multiplier;
      const conservativeRevenue = projectedRevenue * SCENARIO_TYPES.find(s => s.id === "conservative").multiplier;

      const confidence = getConfidenceLevel(i, scheduledBookings.length);

      projectionData.push({
        week: format(weekStart, "MMM d"),
        weekNumber: i + 1,
        startDate: weekStart.toISOString(),
        endDate: weekEnd.toISOString(),
        scheduledRevenue: Math.round(scheduledRevenue * 100) / 100,
        projectedRevenue: Math.round(projectedRevenue * scenarioMultiplier * 100) / 100,
        optimisticRevenue: Math.round(optimisticRevenue * 100) / 100,
        conservativeRevenue: Math.round(conservativeRevenue * 100) / 100,
        expenses: Math.round(estimatedExpenses * 100) / 100,
        netCashFlow: Math.round(netCashFlow * scenarioMultiplier * 100) / 100,
        cumulativeRevenue: Math.round(cumulativeRevenue * 100) / 100,
        cumulativeExpenses: Math.round(cumulativeExpenses * 100) / 100,
        cumulativeNet: Math.round(cumulativeNet * 100) / 100,
        bookingsCount: scheduledBookings.length,
        confidence,
        growthFactor,
        seasonalFactor
      });
    }
    
    return projectionData;
  }, [bookings, expenses, selectedPeriod, walkInBuffer, expenseRatio, selectedScenario, historicalMetrics]);

  const summaryMetrics = useMemo(() => {
    const totalProjectedRevenue = projections.reduce((sum, p) => sum + p.projectedRevenue, 0);
    const totalScheduledRevenue = projections.reduce((sum, p) => sum + p.scheduledRevenue, 0);
    const totalProjectedExpenses = projections.reduce((sum, p) => sum + p.expenses, 0);
    const netProjection = totalProjectedRevenue - totalProjectedExpenses;
    const totalBookings = projections.reduce((sum, p) => sum + p.bookingsCount, 0);

    const avgWeeklyRevenue = totalProjectedRevenue / projections.length;
    const avgWeeklyExpenses = totalProjectedExpenses / projections.length;
    const avgWeeklyNet = netProjection / projections.length;

    const profitMargin = totalProjectedRevenue > 0 
      ? (netProjection / totalProjectedRevenue) * 100 
      : 0;

    const breakEvenWeek = projections.findIndex(p => p.cumulativeNet > 0);

    const optimisticTotal = projections.reduce((sum, p) => sum + p.optimisticRevenue, 0);
    const conservativeTotal = projections.reduce((sum, p) => sum + p.conservativeRevenue, 0);

    const highConfidenceWeeks = projections.filter(p => p.confidence === "high").length;
    const overallConfidence = highConfidenceWeeks / projections.length > 0.6 ? "high" :
                             highConfidenceWeeks / projections.length > 0.3 ? "medium" : "low";

    return {
      totalProjectedRevenue,
      totalScheduledRevenue,
      totalProjectedExpenses,
      netProjection,
      totalBookings,
      avgWeeklyRevenue,
      avgWeeklyExpenses,
      avgWeeklyNet,
      profitMargin,
      breakEvenWeek: breakEvenWeek >= 0 ? breakEvenWeek + 1 : null,
      optimisticTotal,
      conservativeTotal,
      overallConfidence,
      projectionRange: {
        min: conservativeTotal - totalProjectedExpenses,
        max: optimisticTotal - totalProjectedExpenses
      }
    };
  }, [projections]);

  const expenseBreakdown = useMemo(() => {
    const totalExpenses = summaryMetrics.totalProjectedExpenses;
    return EXPENSE_CATEGORIES.map(cat => ({
      ...cat,
      amount: (totalExpenses * cat.percentage) / 100
    }));
  }, [summaryMetrics.totalProjectedExpenses]);

  function getSeasonalFactor(date) {
    const month = date.getMonth();
    const seasonalFactors = {
      0: 0.85,
      1: 0.90,
      2: 1.0,
      3: 1.10,
      4: 1.15,
      5: 1.20,
      6: 0.95,
      7: 0.90,
      8: 1.15,
      9: 1.10,
      10: 1.0,
      11: 0.80
    };
    return seasonalFactors[month] || 1.0;
  }

  function getConfidenceLevel(weekIndex, bookingsCount) {
    if (weekIndex <= 2 && bookingsCount > 5) return "high";
    if (weekIndex <= 4 && bookingsCount > 3) return "high";
    if (weekIndex <= 6 && bookingsCount > 0) return "medium";
    if (weekIndex <= 8) return "medium";
    return "low";
  }

  const toggleLine = useCallback((lineKey) => {
    setVisibleLines(prev => ({
      ...prev,
      [lineKey]: !prev[lineKey]
    }));
  }, []);

  const handleExport = useCallback(() => {
    if (onExport) {
      onExport({
        projections,
        summary: summaryMetrics,
        settings: {
          period: projectionPeriod,
          scenario: selectedScenario,
          walkInBuffer,
          expenseRatio
        }
      });
    }
  }, [onExport, projections, summaryMetrics, projectionPeriod, selectedScenario, walkInBuffer, expenseRatio]);

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;

    const data = payload[0]?.payload;
    
    return (
      <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-200 max-w-xs">
        <p className="font-bold text-gray-900 mb-2">{label}</p>
        <div className="space-y-1 text-sm">
          {visibleLines.scheduledRevenue && (
            <div className="flex items-center justify-between gap-4">
              <span className="text-gray-600">Scheduled:</span>
              <span className="font-semibold text-emerald-600">€{data?.scheduledRevenue?.toFixed(2)}</span>
            </div>
          )}
          {visibleLines.projectedRevenue && (
            <div className="flex items-center justify-between gap-4">
              <span className="text-gray-600">Projected:</span>
              <span className="font-semibold text-indigo-600">€{data?.projectedRevenue?.toFixed(2)}</span>
            </div>
          )}
          {visibleLines.expenses && (
            <div className="flex items-center justify-between gap-4">
              <span className="text-gray-600">Expenses:</span>
              <span className="font-semibold text-red-600">€{data?.expenses?.toFixed(2)}</span>
            </div>
          )}
          {visibleLines.netCashFlow && (
            <div className="flex items-center justify-between gap-4 pt-1 border-t border-gray-200">
              <span className="text-gray-600">Net:</span>
              <span className={`font-bold ${data?.netCashFlow >= 0 ? "text-green-600" : "text-red-600"}`}>
                €{data?.netCashFlow?.toFixed(2)}
              </span>
            </div>
          )}
          <div className="pt-2 mt-2 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <span className="text-gray-500">Bookings:</span>
              <span className="font-medium">{data?.bookingsCount}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-500">Confidence:</span>
              <span className={`font-medium capitalize ${
                data?.confidence === "high" ? "text-green-600" :
                data?.confidence === "medium" ? "text-amber-600" : "text-red-600"
              }`}>
                {data?.confidence}
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderChart = () => {
    const commonProps = {
      data: projections,
      margin: { top: 20, right: 30, left: 20, bottom: 5 }
    };

    const commonElements = (
      <>
        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
        <XAxis 
          dataKey="week" 
          stroke="#6b7280" 
          style={{ fontSize: "12px" }}
          tick={{ fill: "#6b7280" }}
        />
        <YAxis 
          stroke="#6b7280" 
          style={{ fontSize: "12px" }}
          tick={{ fill: "#6b7280" }}
          tickFormatter={(value) => `€${value >= 1000 ? (value/1000).toFixed(1) + "k" : value}`}
        />
        <Tooltip content={<CustomTooltip />} />
        <Legend 
          onClick={(e) => toggleLine(e.dataKey)}
          wrapperStyle={{ cursor: "pointer" }}
        />
        <ReferenceLine y={0} stroke="#9ca3af" strokeDasharray="3 3" />
      </>
    );

    switch (chartType) {
      case "area":
        return (
          <AreaChart {...commonProps}>
            {commonElements}
            {visibleLines.projectedRevenue && (
              <Area 
                type="monotone" 
                dataKey="projectedRevenue" 
                stroke="#6366f1" 
                fill="#6366f1"
                fillOpacity={0.3}
                strokeWidth={2}
                name="Projected Revenue"
              />
            )}
            {visibleLines.expenses && (
              <Area 
                type="monotone" 
                dataKey="expenses" 
                stroke="#ef4444" 
                fill="#ef4444"
                fillOpacity={0.3}
                strokeWidth={2}
                name="Expenses"
              />
            )}
            {visibleLines.netCashFlow && (
              <Area 
                type="monotone" 
                dataKey="netCashFlow" 
                stroke="#8b5cf6" 
                fill="#8b5cf6"
                fillOpacity={0.3}
                strokeWidth={2}
                name="Net Cash Flow"
              />
            )}
          </AreaChart>
        );

      case "bar":
        return (
          <BarChart {...commonProps}>
            {commonElements}
            {visibleLines.projectedRevenue && (
              <Bar 
                dataKey="projectedRevenue" 
                fill="#6366f1" 
                name="Projected Revenue"
                radius={[4, 4, 0, 0]}
              />
            )}
            {visibleLines.expenses && (
              <Bar 
                dataKey="expenses" 
                fill="#ef4444" 
                name="Expenses"
                radius={[4, 4, 0, 0]}
              />
            )}
            {visibleLines.netCashFlow && (
              <Bar 
                dataKey="netCashFlow" 
                fill="#8b5cf6" 
                name="Net Cash Flow"
                radius={[4, 4, 0, 0]}
              />
            )}
          </BarChart>
        );

      case "composed":
        return (
          <ComposedChart {...commonProps}>
            {commonElements}
            {showScenarios && visibleLines.optimistic && (
              <Area
                type="monotone"
                dataKey="optimisticRevenue"
                stroke="#10b981"
                fill="#10b981"
                fillOpacity={0.1}
                strokeWidth={1}
                strokeDasharray="5 5"
                name="Optimistic"
              />
            )}
            {showScenarios && visibleLines.conservative && (
              <Area
                type="monotone"
                dataKey="conservativeRevenue"
                stroke="#f59e0b"
                fill="#f59e0b"
                fillOpacity={0.1}
                strokeWidth={1}
                strokeDasharray="5 5"
                name="Conservative"
              />
            )}
            {visibleLines.scheduledRevenue && (
              <Line 
                type="monotone" 
                dataKey="scheduledRevenue" 
                stroke="#10b981" 
                strokeWidth={2}
                name="Scheduled Revenue"
                strokeDasharray="5 5"
                dot={false}
              />
            )}
            {visibleLines.projectedRevenue && (
              <Line 
                type="monotone" 
                dataKey="projectedRevenue" 
                stroke="#6366f1" 
                strokeWidth={3}
                name="Projected Revenue"
                dot={{ fill: "#6366f1", strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            )}
            {visibleLines.expenses && (
              <Bar 
                dataKey="expenses" 
                fill="#fee2e2" 
                stroke="#ef4444"
                name="Expenses"
                radius={[4, 4, 0, 0]}
              />
            )}
            {visibleLines.netCashFlow && (
              <Line 
                type="monotone" 
                dataKey="netCashFlow" 
                stroke="#8b5cf6" 
                strokeWidth={3}
                name="Net Cash Flow"
                dot={{ fill: "#8b5cf6", strokeWidth: 2, r: 4 }}
              />
            )}
          </ComposedChart>
        );

      default:
        return (
          <LineChart {...commonProps}>
            {commonElements}
            {visibleLines.scheduledRevenue && (
              <Line 
                type="monotone" 
                dataKey="scheduledRevenue" 
                stroke="#10b981" 
                strokeWidth={2}
                name="Scheduled Revenue"
                strokeDasharray="5 5"
                dot={false}
              />
            )}
            {visibleLines.projectedRevenue && (
              <Line 
                type="monotone" 
                dataKey="projectedRevenue" 
                stroke="#6366f1" 
                strokeWidth={3}
                name="Projected Revenue"
              />
            )}
            {visibleLines.expenses && (
              <Line 
                type="monotone" 
                dataKey="expenses" 
                stroke="#ef4444" 
                strokeWidth={2}
                name="Expenses"
              />
            )}
            {visibleLines.netCashFlow && (
              <Line 
                type="monotone" 
                dataKey="netCashFlow" 
                stroke="#8b5cf6" 
                strokeWidth={3}
                name="Net Cash Flow"
              />
            )}
          </LineChart>
        );
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-1">Cash Flow Projection</h3>
            <p className="text-sm text-gray-500">
              {selectedPeriod?.label} forecast based on scheduled lessons and historical data
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onRefresh?.()}
              disabled={isLoading}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
              title="Refresh data"
            >
              <RefreshCw className={`w-5 h-5 text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
            </button>
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-lg transition ${showSettings ? "bg-indigo-100 text-indigo-600" : "hover:bg-gray-100 text-gray-600"}`}
              title="Settings"
            >
              <Settings className="w-5 h-5" />
            </button>
            <button
              onClick={handleExport}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
              title="Export projection"
            >
              <Download className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-gray-100 rounded-lg">
            {PROJECTION_PERIODS.slice(0, 4).map(period => (
              <button
                key={period.id}
                onClick={() => setProjectionPeriod(period.id)}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition ${
                  projectionPeriod === period.id
                    ? "bg-white text-gray-900 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                {period.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 p-1 bg-gray-100 rounded-lg">
            {CHART_TYPES.map(type => (
              <button
                key={type.id}
                onClick={() => setChartType(type.id)}
                className={`p-1.5 rounded-md transition ${
                  chartType === type.id
                    ? "bg-white text-indigo-600 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
                title={type.label}
              >
                <type.icon className="w-4 h-4" />
              </button>
            ))}
          </div>

          <select
            value={selectedScenario}
            onChange={(e) => setSelectedScenario(e.target.value)}
            className="px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            {SCENARIO_TYPES.map(scenario => (
              <option key={scenario.id} value={scenario.id}>{scenario.label} Scenario</option>
            ))}
          </select>

          <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${
            summaryMetrics.overallConfidence === "high" ? "bg-green-100 text-green-700" :
            summaryMetrics.overallConfidence === "medium" ? "bg-amber-100 text-amber-700" :
            "bg-red-100 text-red-700"
          }`}>
            {summaryMetrics.overallConfidence === "high" ? <CheckCircle className="w-4 h-4" /> :
             summaryMetrics.overallConfidence === "medium" ? <AlertCircle className="w-4 h-4" /> :
             <AlertCircle className="w-4 h-4" />}
            {CONFIDENCE_LEVELS[summaryMetrics.overallConfidence]?.label} Confidence
          </div>
        </div>
      </div>

      {showSettings && (
        <div className="p-4 bg-gray-50 border-b border-gray-200">
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Walk-in Buffer: {walkInBuffer}%
              </label>
              <input
                type="range"
                min="0"
                max="50"
                value={walkInBuffer}
                onChange={(e) => setWalkInBuffer(parseInt(e.target.value))}
                className="w-full"
              />
              <p className="text-xs text-gray-500 mt-1">Additional revenue from walk-in bookings</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Expense Ratio: {expenseRatio}%
              </label>
              <input
                type="range"
                min="10"
                max="60"
                value={expenseRatio}
                onChange={(e) => setExpenseRatio(parseInt(e.target.value))}
                className="w-full"
              />
              <p className="text-xs text-gray-500 mt-1">Estimated expenses as % of revenue</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Visible Lines</label>
              <div className="flex flex-wrap gap-2">
                {Object.entries(visibleLines).map(([key, value]) => (
                  <button
                    key={key}
                    onClick={() => toggleLine(key)}
                    className={`px-2 py-1 text-xs font-medium rounded transition ${
                      value ? "bg-indigo-100 text-indigo-700" : "bg-gray-200 text-gray-600"
                    }`}
                  >
                    {key.replace(/([A-Z])/g, " $1").trim()}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 border-b border-gray-200">
        <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-green-600" />
            <p className="text-sm font-medium text-gray-600">Projected Revenue</p>
          </div>
          <p className="text-2xl font-bold text-green-700">
            €{summaryMetrics.totalProjectedRevenue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </p>
          <p className="text-xs text-gray-500 mt-1">
            {selectedPeriod?.label} total
          </p>
        </div>

        <div className="p-4 bg-gradient-to-br from-red-50 to-orange-50 rounded-xl">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="w-5 h-5 text-red-600" />
            <p className="text-sm font-medium text-gray-600">Projected Expenses</p>
          </div>
          <p className="text-2xl font-bold text-red-700">
            €{summaryMetrics.totalProjectedExpenses.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </p>
          <p className="text-xs text-gray-500 mt-1">
            {expenseRatio}% of revenue
          </p>
        </div>

        <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
          <div className="flex items-center gap-2 mb-2">
            <Wallet className="w-5 h-5 text-indigo-600" />
            <p className="text-sm font-medium text-gray-600">Net Projection</p>
          </div>
          <p className={`text-2xl font-bold ${summaryMetrics.netProjection >= 0 ? "text-indigo-700" : "text-red-700"}`}>
            €{summaryMetrics.netProjection.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </p>
          <p className="text-xs text-gray-500 mt-1">
            {summaryMetrics.profitMargin.toFixed(1)}% margin
          </p>
        </div>

        <div className="p-4 bg-gradient-to-br from-amber-50 to-yellow-50 rounded-xl">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-5 h-5 text-amber-600" />
            <p className="text-sm font-medium text-gray-600">Scheduled Bookings</p>
          </div>
          <p className="text-2xl font-bold text-amber-700">
            {summaryMetrics.totalBookings}
          </p>
          <p className="text-xs text-gray-500 mt-1">
            €{summaryMetrics.totalScheduledRevenue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })} confirmed
          </p>
        </div>
      </div>

      <div className="p-6">
        <ResponsiveContainer width="100%" height={400}>
          {renderChart()}
        </ResponsiveContainer>
      </div>

      <button
        onClick={() => setShowAdvancedMetrics(!showAdvancedMetrics)}
        className="w-full px-6 py-3 bg-gray-50 border-t border-gray-200 flex items-center justify-center gap-2 text-sm font-medium text-gray-600 hover:bg-gray-100 transition"
      >
        {showAdvancedMetrics ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        {showAdvancedMetrics ? "Hide" : "Show"} Advanced Analytics
      </button>

      {showAdvancedMetrics && (
        <div className="p-6 border-t border-gray-200 space-y-6">
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-sm font-medium text-gray-600 mb-1">Avg Weekly Revenue</p>
              <p className="text-xl font-bold text-gray-900">€{summaryMetrics.avgWeeklyRevenue.toFixed(2)}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-sm font-medium text-gray-600 mb-1">Avg Weekly Expenses</p>
              <p className="text-xl font-bold text-gray-900">€{summaryMetrics.avgWeeklyExpenses.toFixed(2)}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-xl">
              <p className="text-sm font-medium text-gray-600 mb-1">Avg Weekly Net</p>
              <p className={`text-xl font-bold ${summaryMetrics.avgWeeklyNet >= 0 ? "text-green-600" : "text-red-600"}`}>
                €{summaryMetrics.avgWeeklyNet.toFixed(2)}
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Scenario Comparison</h4>
              <div className="space-y-3">
                {SCENARIO_TYPES.map(scenario => {
                  const total = scenario.id === "optimistic" ? summaryMetrics.optimisticTotal :
                               scenario.id === "conservative" ? summaryMetrics.conservativeTotal :
                               summaryMetrics.totalProjectedRevenue;
                  const net = total - summaryMetrics.totalProjectedExpenses;
                  
                  return (
                    <div key={scenario.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: scenario.color }} />
                        <span className="font-medium text-gray-900">{scenario.label}</span>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold" style={{ color: scenario.color }}>
                          €{total.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </p>
                        <p className={`text-xs ${net >= 0 ? "text-green-600" : "text-red-600"}`}>
                          Net: €{net.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-gray-900">Expense Breakdown</h4>
                <button
                  onClick={() => setShowExpenseBreakdown(!showExpenseBreakdown)}
                  className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
                >
                  {showExpenseBreakdown ? "Hide" : "Show"} Details
                </button>
              </div>
              
              {showExpenseBreakdown && (
                <div className="space-y-2">
                  {expenseBreakdown.map(cat => (
                    <div key={cat.id} className="flex items-center gap-3">
                      <div className="flex-1">
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-gray-600">{cat.label}</span>
                          <span className="font-medium text-gray-900">€{cat.amount.toFixed(0)}</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-indigo-500 rounded-full"
                            style={{ width: `${cat.percentage}%` }}
                          />
                        </div>
                      </div>
                      <span className="text-xs text-gray-500 w-10 text-right">{cat.percentage}%</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-indigo-600 mt-0.5" />
              <div>
                <p className="font-semibold text-indigo-900 mb-1">Projection Methodology</p>
                <p className="text-sm text-indigo-700">
                  Projections are calculated using confirmed bookings, a {walkInBuffer}% walk-in buffer, 
                  historical growth rate of {historicalMetrics.growthRate.toFixed(1)}%, 
                  seasonal adjustment factors, and a {historicalMetrics.completionRate.toFixed(0)}% lesson completion rate. 
                  Expenses are estimated at {expenseRatio}% of projected revenue based on typical driving school operating costs.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}