import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Zap,
  RefreshCw,
  ChevronRight,
  User,
  CheckCircle,
} from "lucide-react";
import { format, parseISO, differenceInDays } from "date-fns";
import { toast } from "sonner";
import { motion } from "framer-motion";

export default function AutomatedInvoicing({
  bookings,
  invoices,
  students,
  instructors,
  school,
  onInvoiceCreated,
}) {
  const queryClient = useQueryClient();
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedBookings, setSelectedBookings] = useState([]);

  const studentMap = useMemo(
    () => new Map(students.map((s) => [s.id, s])),
    [students]
  );

  const instructorMap = useMemo(
    () => new Map(instructors.map((i) => [i.id, i])),
    [instructors]
  );

  const invoicedBookingIds = useMemo(
    () => new Set(invoices.map((inv) => inv.booking_id).filter(Boolean)),
    [invoices]
  );

  // Completed bookings without invoices, sorted by date (oldest first)
  const uninvoicedBookings = useMemo(() => {
    return bookings
      .filter(
        (b) =>
          b.status === "completed" &&
          !invoicedBookingIds.has(b.id) &&
          b.price > 0
      )
      .sort(
        (a, b) =>
          new Date(a.start_datetime) - new Date(b.start_datetime)
      );
  }, [bookings, invoicedBookingIds]);

  const stats = useMemo(() => {
    const count = uninvoicedBookings.length;
    const totalAmount = uninvoicedBookings.reduce(
      (sum, b) => sum + (b.price || 0),
      0
    );
    return { count, totalAmount };
  }, [uninvoicedBookings]);

  const createInvoiceMutation = useMutation({
    mutationFn: async (invoiceData) => {
      return base44.entities.Invoice.create(invoiceData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invoices"] });
    },
  });

  const generateInvoiceNumber = () => {
    const date = new Date();
    const prefix = "INV";
    const year = date.getFullYear().toString().slice(-2);
    const month = (date.getMonth() + 1).toString().padStart(2, "0");
    const random = Math.floor(Math.random() * 10000)
      .toString()
      .padStart(4, "0");
    return `${prefix}-${year}${month}-${random}`;
  };

  const handleGenerateInvoices = async () => {
    const bookingsToInvoice =
      selectedBookings.length > 0
        ? uninvoicedBookings.filter((b) =>
            selectedBookings.includes(b.id)
          )
        : uninvoicedBookings;

    if (bookingsToInvoice.length === 0) {
      toast.info("No bookings to invoice");
      return;
    }

    setIsGenerating(true);
    let successCount = 0;
    let errorCount = 0;

    for (const booking of bookingsToInvoice) {
      const student = studentMap.get(booking.student_id);
      const instructor = instructorMap.get(booking.instructor_id);

      const taxRate = school?.tax_rate ?? 0.2; // respect 0 if configured
      const subtotal = booking.price;
      const taxAmount = subtotal * taxRate;
      const total = subtotal + taxAmount;

      const issueDate = new Date();
      const dueDate = new Date(
        issueDate.getTime() + 14 * 24 * 60 * 60 * 1000
      );

      const invoiceData = {
        school_id: booking.school_id || school?.id,
        student_id: booking.student_id,
        instructor_id: booking.instructor_id,
        booking_id: booking.id,
        invoice_number: generateInvoiceNumber(),
        issue_date: issueDate.toISOString().split("T")[0],
        due_date: dueDate.toISOString().split("T")[0],
        subtotal,
        tax_amount: taxAmount,
        total_amount: total,
        amount_paid: 0,
        status: "sent",
        lesson_type: booking.lesson_type || "practical_driving",
        line_items: [
          {
            description: `Driving lesson - ${format(
              parseISO(booking.start_datetime),
              "MMM d, yyyy HH:mm"
            )}`,
            quantity: 1,
            unit_price: subtotal,
            total: subtotal,
          },
        ],
        notes: `Lesson with ${
          instructor?.full_name || "Instructor"
        } on ${format(
          parseISO(booking.start_datetime),
          "MMMM d, yyyy"
        )}`,
        student_name: student?.full_name,
        student_email: student?.email,
      };

      try {
        await createInvoiceMutation.mutateAsync(invoiceData);
        successCount++;
      } catch (error) {
        console.error("Failed to create invoice:", error);
        errorCount++;
      }
    }

    setIsGenerating(false);
    setSelectedBookings([]);

    if (successCount > 0) {
      toast.success(
        `Generated ${successCount} invoice${
          successCount > 1 ? "s" : ""
        }`
      );
      onInvoiceCreated?.();
    }
    if (errorCount > 0) {
      toast.error(
        `Failed to generate ${errorCount} invoice${
          errorCount > 1 ? "s" : ""
        }`
      );
    }
  };

  const toggleBookingSelection = (bookingId) => {
    setSelectedBookings((prev) =>
      prev.includes(bookingId)
        ? prev.filter((id) => id !== bookingId)
        : [...prev, bookingId]
    );
  };

  const selectAllBookings = () => {
    if (selectedBookings.length === uninvoicedBookings.length) {
      setSelectedBookings([]);
    } else {
      setSelectedBookings(uninvoicedBookings.map((b) => b.id));
    }
  };

  const selectedCount =
    selectedBookings.length > 0
      ? selectedBookings.length
      : stats.count;

  const pluralSuffix = selectedCount !== 1 ? "s" : "";

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl border border-zinc-200 overflow-hidden"
    >
      <div className="p-6 border-b border-zinc-100 bg-gradient-to-r from-indigo-50 to-purple-50">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-zinc-900">
                Auto-generate invoices
              </h3>
              <p className="text-sm text-zinc-600">
                {stats.count} completed lesson
                {stats.count !== 1 ? "s" : ""} pending invoicing - total
                approx €{stats.totalAmount.toFixed(2)}
              </p>
            </div>
          </div>

          <button
            onClick={handleGenerateInvoices}
            disabled={isGenerating || stats.count === 0}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition shadow-sm"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                Generate {selectedCount} invoice{pluralSuffix}
              </>
            )}
          </button>
        </div>
      </div>

      {stats.count > 0 ? (
        <div className="divide-y divide-zinc-100">
          <div className="px-6 py-3 bg-zinc-50 flex items-center gap-4">
            <input
              type="checkbox"
              checked={
                selectedBookings.length > 0 &&
                selectedBookings.length === uninvoicedBookings.length
              }
              onChange={selectAllBookings}
              className="w-4 h-4 rounded border-zinc-300 text-indigo-600 focus:ring-indigo-500"
            />
            <span className="text-sm font-medium text-zinc-600">
              Select all ({uninvoicedBookings.length})
            </span>
          </div>

          {uninvoicedBookings.slice(0, 10).map((booking) => {
            const student = studentMap.get(booking.student_id);
            const instructor = instructorMap.get(booking.instructor_id);
            const isSelected = selectedBookings.includes(booking.id);

            const daysAgo = differenceInDays(
              new Date(),
              parseISO(booking.start_datetime)
            );

            return (
              <div
                key={booking.id}
                className={`px-6 py-4 flex items-center gap-4 hover:bg-zinc-50 transition cursor-pointer ${
                  isSelected ? "bg-indigo-50" : ""
                }`}
                onClick={() => toggleBookingSelection(booking.id)}
              >
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => {}}
                  className="w-4 h-4 rounded border-zinc-300 text-indigo-600 focus:ring-indigo-500 pointer-events-none"
                />

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-zinc-100 flex items-center justify-center">
                      <User className="w-5 h-5 text-zinc-500" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-zinc-900">
                        {student?.full_name || "Unknown student"}
                      </p>
                      <p className="text-xs text-zinc-500">
                        with {instructor?.full_name || "Instructor"} •{" "}
                        {format(
                          parseISO(booking.start_datetime),
                          "MMM d, yyyy HH:mm"
                        )}{" "}
                        {Number.isFinite(daysAgo) && (
                          <>• {daysAgo} day{daysAgo !== 1 ? "s" : ""} ago</>
                        )}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-lg font-bold text-zinc-900">
                    €{booking.price.toFixed(2)}
                  </p>
                  <p className="text-xs text-zinc-500 capitalize">
                    {booking.lesson_type?.replace("_", " ") || "Standard"}
                  </p>
                </div>

                <ChevronRight className="w-5 h-5 text-zinc-400" />
              </div>
            );
          })}

          {uninvoicedBookings.length > 10 && (
            <div className="px-6 py-3 text-center text-sm text-zinc-500">
              And {uninvoicedBookings.length - 10} more...
            </div>
          )}
        </div>
      ) : (
        <div className="p-12 text-center">
          <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-4" />
          <p className="text-zinc-600 font-medium">
            All completed lessons have been invoiced
          </p>
        </div>
      )}
    </motion.div>
  );
}
