import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { 
  AlertTriangle, 
  TrendingDown, 
  AlertCircle, 
  Info, 
  ChevronRight,
  ChevronDown,
  ChevronUp,
  X,
  Check,
  Clock,
  Bell,
  BellOff,
  Filter,
  RefreshCw,
  Download,
  Settings,
  Eye,
  EyeOff,
  MoreVertical,
  ExternalLink,
  Copy,
  Trash2,
  Archive,
  Flag,
  Star,
  Zap,
  Shield,
  DollarSign,
  Users,
  Calendar,
  Car,
  CreditCard,
  FileText,
  TrendingUp,
  Target,
  Activity,
  Loader2,
  CheckCircle,
  XCircle,
  HelpCircle,
  Megaphone,
  MessageSquare,
  Mail,
  Phone,
  MapPin,
  Bookmark,
  Share2,
  Printer,
  Search,
  SortAsc,
  SortDesc
} from "lucide-react";
import { format, formatDistanceToNow, differenceInHours, differenceInDays, parseISO, isToday, isYesterday } from "date-fns";

const SEVERITY_CONFIG = {
  critical: {
    icon: AlertTriangle,
    bgClass: "bg-red-50",
    borderClass: "border-red-200",
    textClass: "text-red-900",
    iconClass: "text-red-600",
    badgeBgClass: "bg-red-100",
    badgeTextClass: "text-red-700",
    priority: 1,
    label: "Critical",
    description: "Requires immediate attention"
  },
  warning: {
    icon: AlertCircle,
    bgClass: "bg-amber-50",
    borderClass: "border-amber-200",
    textClass: "text-amber-900",
    iconClass: "text-amber-600",
    badgeBgClass: "bg-amber-100",
    badgeTextClass: "text-amber-700",
    priority: 2,
    label: "Warning",
    description: "Should be addressed soon"
  },
  info: {
    icon: Info,
    bgClass: "bg-blue-50",
    borderClass: "border-blue-200",
    textClass: "text-blue-900",
    iconClass: "text-blue-600",
    badgeBgClass: "bg-blue-100",
    badgeTextClass: "text-blue-700",
    priority: 3,
    label: "Info",
    description: "For your information"
  },
  success: {
    icon: CheckCircle,
    bgClass: "bg-green-50",
    borderClass: "border-green-200",
    textClass: "text-green-900",
    iconClass: "text-green-600",
    badgeBgClass: "bg-green-100",
    badgeTextClass: "text-green-700",
    priority: 4,
    label: "Success",
    description: "Positive updates"
  }
};

const ALERT_CATEGORIES = {
  financial: { label: "Financial", icon: DollarSign, color: "emerald" },
  scheduling: { label: "Scheduling", icon: Calendar, color: "blue" },
  students: { label: "Students", icon: Users, color: "purple" },
  instructors: { label: "Instructors", icon: Car, color: "indigo" },
  payments: { label: "Payments", icon: CreditCard, color: "amber" },
  compliance: { label: "Compliance", icon: Shield, color: "red" },
  system: { label: "System", icon: Settings, color: "gray" },
  marketing: { label: "Marketing", icon: Megaphone, color: "pink" }
};

const SORT_OPTIONS = [
  { id: "priority", label: "Priority" },
  { id: "date", label: "Date" },
  { id: "category", label: "Category" },
  { id: "status", label: "Status" }
];

const FILTER_OPTIONS = [
  { id: "all", label: "All Alerts" },
  { id: "unread", label: "Unread" },
  { id: "critical", label: "Critical Only" },
  { id: "actionable", label: "Action Required" },
  { id: "starred", label: "Starred" }
];

export default function AlertPanel({ 
  alerts = [],
  onDismiss,
  onMarkRead,
  onMarkAllRead,
  onAction,
  onStarToggle,
  onArchive,
  onRefresh,
  onExport,
  onSettingsClick,
  maxVisible = 5,
  showFilters = true,
  showActions = true,
  compact = false,
  autoRefresh = false,
  refreshInterval = 60000,
  isLoading = false,
  title = "Attention Needed",
  emptyMessage = "All systems running smoothly",
  className = ""
}) {
  const [expandedAlerts, setExpandedAlerts] = useState(new Set());
  const [filter, setFilter] = useState("all");
  const [sortBy, setSortBy] = useState("priority");
  const [sortDirection, setSortDirection] = useState("asc");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAllAlerts, setShowAllAlerts] = useState(false);
  const [selectedAlerts, setSelectedAlerts] = useState(new Set());
  const [showMenu, setShowMenu] = useState(null);
  const [dismissingIds, setDismissingIds] = useState(new Set());
  const [animatingIds, setAnimatingIds] = useState(new Set());
  const menuRef = useRef(null);
  const panelRef = useRef(null);

  useEffect(() => {
    if (!autoRefresh || !onRefresh) return;

    const interval = setInterval(() => {
      onRefresh();
    }, refreshInterval);

    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval, onRefresh]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowMenu(null);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const processedAlerts = useMemo(() => {
    return alerts.map(alert => ({
      ...alert,
      id: alert.id || `alert-${Math.random().toString(36).substr(2, 9)}`,
      severity: alert.severity || "info",
      category: alert.category || "system",
      timestamp: alert.timestamp || alert.created_at || new Date().toISOString(),
      read: alert.read || false,
      starred: alert.starred || false,
      dismissed: alert.dismissed || false,
      actionable: !!alert.action || !!alert.link
    }));
  }, [alerts]);

  const filteredAlerts = useMemo(() => {
    let result = processedAlerts.filter(alert => !alert.dismissed);

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(alert => 
        alert.message?.toLowerCase().includes(query) ||
        alert.title?.toLowerCase().includes(query) ||
        alert.category?.toLowerCase().includes(query)
      );
    }

    switch (filter) {
      case "unread":
        result = result.filter(alert => !alert.read);
        break;
      case "critical":
        result = result.filter(alert => alert.severity === "critical");
        break;
      case "actionable":
        result = result.filter(alert => alert.actionable);
        break;
      case "starred":
        result = result.filter(alert => alert.starred);
        break;
    }

    result.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case "priority":
          comparison = (SEVERITY_CONFIG[a.severity]?.priority || 99) - (SEVERITY_CONFIG[b.severity]?.priority || 99);
          break;
        case "date":
          comparison = new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
          break;
        case "category":
          comparison = (a.category || "").localeCompare(b.category || "");
          break;
        case "status":
          comparison = (a.read ? 1 : 0) - (b.read ? 1 : 0);
          break;
      }

      return sortDirection === "asc" ? comparison : -comparison;
    });

    return result;
  }, [processedAlerts, filter, sortBy, sortDirection, searchQuery]);

  const displayedAlerts = useMemo(() => {
    return showAllAlerts ? filteredAlerts : filteredAlerts.slice(0, maxVisible);
  }, [filteredAlerts, showAllAlerts, maxVisible]);

  const alertStats = useMemo(() => {
    const stats = {
      total: filteredAlerts.length,
      critical: 0,
      warning: 0,
      info: 0,
      success: 0,
      unread: 0,
      starred: 0
    };

    filteredAlerts.forEach(alert => {
      if (alert.severity) stats[alert.severity]++;
      if (!alert.read) stats.unread++;
      if (alert.starred) stats.starred++;
    });

    return stats;
  }, [filteredAlerts]);

  const toggleExpand = useCallback((alertId) => {
    setExpandedAlerts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(alertId)) {
        newSet.delete(alertId);
      } else {
        newSet.add(alertId);
      }
      return newSet;
    });
  }, []);

  const handleDismiss = useCallback(async (alertId) => {
    setDismissingIds(prev => new Set(prev).add(alertId));
    setAnimatingIds(prev => new Set(prev).add(alertId));

    await new Promise(resolve => setTimeout(resolve, 300));

    if (onDismiss) {
      await onDismiss(alertId);
    }

    setDismissingIds(prev => {
      const newSet = new Set(prev);
      newSet.delete(alertId);
      return newSet;
    });
    setAnimatingIds(prev => {
      const newSet = new Set(prev);
      newSet.delete(alertId);
      return newSet;
    });
  }, [onDismiss]);

  const handleBulkDismiss = useCallback(async () => {
    for (const alertId of selectedAlerts) {
      await handleDismiss(alertId);
    }
    setSelectedAlerts(new Set());
  }, [selectedAlerts, handleDismiss]);

  const handleMarkRead = useCallback(async (alertId) => {
    if (onMarkRead) {
      await onMarkRead(alertId);
    }
  }, [onMarkRead]);

  const handleMarkAllRead = useCallback(async () => {
    if (onMarkAllRead) {
      await onMarkAllRead();
    }
  }, [onMarkAllRead]);

  const handleStarToggle = useCallback(async (alertId) => {
    if (onStarToggle) {
      await onStarToggle(alertId);
    }
  }, [onStarToggle]);

  const handleAction = useCallback(async (alert) => {
    if (onAction) {
      await onAction(alert);
    }
    if (!alert.read) {
      handleMarkRead(alert.id);
    }
  }, [onAction, handleMarkRead]);

  const toggleAlertSelection = useCallback((alertId) => {
    setSelectedAlerts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(alertId)) {
        newSet.delete(alertId);
      } else {
        newSet.add(alertId);
      }
      return newSet;
    });
  }, []);

  const selectAllAlerts = useCallback(() => {
    setSelectedAlerts(new Set(displayedAlerts.map(a => a.id)));
  }, [displayedAlerts]);

  const clearSelection = useCallback(() => {
    setSelectedAlerts(new Set());
  }, []);

  const formatTimestamp = useCallback((timestamp) => {
    const date = new Date(timestamp);
    
    if (isToday(date)) {
      return `Today at ${format(date, "h:mm a")}`;
    }
    if (isYesterday(date)) {
      return `Yesterday at ${format(date, "h:mm a")}`;
    }
    
    const hoursAgo = differenceInHours(new Date(), date);
    if (hoursAgo < 24) {
      return formatDistanceToNow(date, { addSuffix: true });
    }
    
    const daysAgo = differenceInDays(new Date(), date);
    if (daysAgo < 7) {
      return format(date, "EEEE 'at' h:mm a");
    }
    
    return format(date, "MMM d 'at' h:mm a");
  }, []);

  const getCategoryConfig = useCallback((category) => {
    return ALERT_CATEGORIES[category] || ALERT_CATEGORIES.system;
  }, []);

  const AlertItem = ({ alert, isExpanded, onToggle }) => {
    const config = SEVERITY_CONFIG[alert.severity] || SEVERITY_CONFIG.info;
    const categoryConfig = getCategoryConfig(alert.category);
    const Icon = config.icon;
    const CategoryIcon = categoryConfig.icon;
    const isDismissing = dismissingIds.has(alert.id);
    const isAnimating = animatingIds.has(alert.id);
    const isSelected = selectedAlerts.has(alert.id);

    return (
      <div
        className={`
          ${config.bgClass} ${config.borderClass} border rounded-xl overflow-hidden
          transition-all duration-300
          ${isAnimating ? "opacity-0 scale-95 -translate-x-full" : "opacity-100 scale-100 translate-x-0"}
          ${isSelected ? "ring-2 ring-indigo-500" : ""}
          ${!alert.read ? "shadow-sm" : ""}
        `}
      >
        <div className="p-4">
          <div className="flex items-start gap-3">
            {showActions && (
              <input
                type="checkbox"
                checked={isSelected}
                onChange={() => toggleAlertSelection(alert.id)}
                className="mt-1 w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
              />
            )}

            <div className={`flex-shrink-0 w-10 h-10 ${config.badgeBgClass} rounded-xl flex items-center justify-center`}>
              <Icon className={`w-5 h-5 ${config.iconClass}`} />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2 mb-1">
                <div className="flex items-center gap-2 flex-wrap">
                  {alert.title && (
                    <p className={`font-semibold ${config.textClass}`}>{alert.title}</p>
                  )}
                  <span className={`px-2 py-0.5 ${config.badgeBgClass} ${config.badgeTextClass} rounded-full text-xs font-medium`}>
                    {config.label}
                  </span>
                  <span className={`px-2 py-0.5 bg-${categoryConfig.color}-100 text-${categoryConfig.color}-700 rounded-full text-xs font-medium flex items-center gap-1`}>
                    <CategoryIcon className="w-3 h-3" />
                    {categoryConfig.label}
                  </span>
                  {!alert.read && (
                    <span className="w-2 h-2 bg-blue-500 rounded-full" title="Unread" />
                  )}
                </div>
                
                <div className="flex items-center gap-1 flex-shrink-0">
                  {alert.starred && (
                    <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                  )}
                  <button
                    onClick={() => handleStarToggle(alert.id)}
                    className="p-1 hover:bg-white/50 rounded-lg transition"
                    title={alert.starred ? "Unstar" : "Star"}
                  >
                    <Star className={`w-4 h-4 ${alert.starred ? "text-amber-500 fill-amber-500" : "text-gray-400"}`} />
                  </button>
                  <button
                    onClick={() => handleDismiss(alert.id)}
                    disabled={isDismissing}
                    className="p-1 hover:bg-white/50 rounded-lg transition"
                    title="Dismiss"
                  >
                    {isDismissing ? (
                      <Loader2 className="w-4 h-4 text-gray-400 animate-spin" />
                    ) : (
                      <X className="w-4 h-4 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>

              <p className={`text-sm ${alert.read ? "text-gray-600" : config.textClass} mb-2`}>
                {alert.message}
              </p>

              {alert.impact && (
                <p className="text-sm text-gray-600 mb-2">
                  <span className="font-medium">Impact:</span> {alert.impact}
                </p>
              )}

              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-3 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatTimestamp(alert.timestamp)}
                  </span>
                  {alert.source && (
                    <span className="flex items-center gap-1">
                      <Activity className="w-3 h-3" />
                      {alert.source}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {alert.action && (
                    <button
                      onClick={() => handleAction(alert)}
                      className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
                    >
                      {alert.action}
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  )}
                  {alert.link && (
                    
                      href={alert.link}
                      onClick={() => !alert.read && handleMarkRead(alert.id)}
                      className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
                    >
                      View details
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                  {(alert.details || alert.recommendations) && (
                    <button
                      onClick={() => onToggle(alert.id)}
                      className="text-xs font-medium text-gray-600 hover:text-gray-700 flex items-center gap-1"
                    >
                      {isExpanded ? "Less" : "More"}
                      {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {isExpanded && (alert.details || alert.recommendations) && (
          <div className="px-4 pb-4 pt-2 border-t border-gray-200/50 bg-white/50">
            {alert.details && (
              <div className="mb-3">
                <p className="text-xs font-semibold text-gray-500 uppercase mb-1">Details</p>
                <p className="text-sm text-gray-700">{alert.details}</p>
              </div>
            )}
            {alert.recommendations && (
              <div>
                <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Recommendations</p>
                <ul className="space-y-1">
                  {alert.recommendations.map((rec, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                      <Zap className="w-3 h-3 text-amber-500 flex-shrink-0 mt-1" />
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {alert.relatedAlerts && alert.relatedAlerts.length > 0 && (
              <div className="mt-3 pt-3 border-t border-gray-200">
                <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Related Alerts</p>
                <div className="flex flex-wrap gap-2">
                  {alert.relatedAlerts.map((related, idx) => (
                    <span key={idx} className="px-2 py-1 bg-gray-100 text-gray-600 rounded-lg text-xs">
                      {related}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  if (!alerts || alerts.length === 0) {
    return (
      <div className={`bg-white rounded-2xl p-6 border border-gray-200 ${className}`}>
        <h3 className="text-lg font-bold text-gray-900 mb-4">{title}</h3>
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <p className="text-gray-900 font-medium mb-1">No Alerts</p>
          <p className="text-sm text-gray-500">{emptyMessage}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white rounded-2xl border border-gray-200 overflow-hidden ${className}`} ref={panelRef}>
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <h3 className="text-lg font-bold text-gray-900">{title}</h3>
            <div className="flex items-center gap-1">
              {alertStats.critical > 0 && (
                <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs font-bold">
                  {alertStats.critical} critical
                </span>
              )}
              {alertStats.warning > 0 && (
                <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-xs font-bold">
                  {alertStats.warning} warning
                </span>
              )}
              {alertStats.unread > 0 && (
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs font-bold">
                  {alertStats.unread} unread
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onRefresh && (
              <button
                onClick={onRefresh}
                disabled={isLoading}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
                title="Refresh"
              >
                <RefreshCw className={`w-4 h-4 text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
              </button>
            )}
            {alertStats.unread > 0 && (
              <button
                onClick={handleMarkAllRead}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
                title="Mark all as read"
              >
                <Check className="w-4 h-4 text-gray-600" />
              </button>
            )}
            {onSettingsClick && (
              <button
                onClick={onSettingsClick}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
                title="Alert settings"
              >
                <Settings className="w-4 h-4 text-gray-600" />
              </button>
            )}
          </div>
        </div>

        {showFilters && (
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center bg-gray-100 rounded-lg p-1">
              {FILTER_OPTIONS.map(option => (
                <button
                  key={option.id}
                  onClick={() => setFilter(option.id)}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition ${
                    filter === option.id
                      ? "bg-white text-gray-900 shadow-sm"
                      : "text-gray-600 hover:text-gray-900"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-2 py-1 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {SORT_OPTIONS.map(option => (
                <option key={option.id} value={option.id}>Sort by {option.label}</option>
              ))}
            </select>

            <button
              onClick={() => setSortDirection(prev => prev === "asc" ? "desc" : "asc")}
              className="p-1 hover:bg-gray-100 rounded-lg transition"
            >
              {sortDirection === "asc" ? (
                <SortAsc className="w-4 h-4 text-gray-600" />
              ) : (
                <SortDesc className="w-4 h-4 text-gray-600" />
              )}
            </button>
          </div>
        )}

        {selectedAlerts.size > 0 && (
          <div className="mt-3 flex items-center justify-between p-2 bg-indigo-50 rounded-lg">
            <span className="text-sm text-indigo-700">
              {selectedAlerts.size} alert(s) selected
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={handleBulkDismiss}
                className="px-3 py-1 bg-indigo-600 text-white rounded-lg text-xs font-medium hover:bg-indigo-700 transition"
              >
                Dismiss Selected
              </button>
              <button
                onClick={clearSelection}
                className="px-3 py-1 text-indigo-700 hover:bg-indigo-100 rounded-lg text-xs font-medium transition"
              >
                Clear
              </button>
            </div>
          </div>
        )}
      </div>

      <div className={`p-4 space-y-3 ${compact ? "max-h-96 overflow-y-auto" : ""}`}>
        {displayedAlerts.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No alerts match your filters</p>
          </div>
        ) : (
          displayedAlerts.map((alert, index) => (
            <AlertItem
              key={alert.id}
              alert={alert}
              isExpanded={expandedAlerts.has(alert.id)}
              onToggle={toggleExpand}
            />
          ))
        )}
      </div>

      {filteredAlerts.length > maxVisible && (
        <div className="p-4 border-t border-gray-200">
          <button
            onClick={() => setShowAllAlerts(!showAllAlerts)}
            className="w-full py-2 text-sm font-semibold text-indigo-600 hover:text-indigo-700 transition flex items-center justify-center gap-1"
          >
            {showAllAlerts ? (
              <>
                <ChevronUp className="w-4 h-4" />
                Show less
              </>
            ) : (
              <>
                View all {filteredAlerts.length} alerts
                <ChevronDown className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      )}

      {isLoading && (
        <div className="absolute inset-0 bg-white/80 flex items-center justify-center">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        </div>
      )}
    </div>
  );
}

export function AlertBadge({ count, severity = "warning", pulse = false }) {
  if (!count || count === 0) return null;

  const config = SEVERITY_CONFIG[severity] || SEVERITY_CONFIG.warning;

  return (
    <span className={`
      relative inline-flex items-center justify-center px-2 py-0.5 
      ${config.badgeBg} ${config.badgeText} rounded-full text-xs font-bold
    `}>
      {count}
      {pulse && (
        <span className={`absolute -top-0.5 -right-0.5 w-2 h-2 ${config.badgeBg} rounded-full animate-ping`} />
      )}
    </span>
  );
}

export function AlertToast({ alert, onDismiss, onAction, duration = 5000 }) {
  const [isVisible, setIsVisible] = useState(true);
  const config = SEVERITY_CONFIG[alert.severity] || SEVERITY_CONFIG.info;
  const Icon = config.icon;

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(() => onDismiss?.(alert.id), 300);
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, alert.id, onDismiss]);

  return (
    <div className={`
      fixed bottom-4 right-4 max-w-sm w-full
      ${config.bg} ${config.border} border rounded-xl shadow-lg p-4
      transition-all duration-300
      ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}
    `}>
      <div className="flex items-start gap-3">
        <Icon className={`w-5 h-5 ${config.iconColor} flex-shrink-0`} />
        <div className="flex-1 min-w-0">
          <p className={`font-semibold ${config.text} text-sm`}>{alert.title || config.label}</p>
          <p className="text-sm text-gray-600 mt-1">{alert.message}</p>
          {alert.action && (
            <button
              onClick={() => onAction?.(alert)}
              className="mt-2 text-sm font-semibold text-indigo-600 hover:text-indigo-700"
            >
              {alert.action}
            </button>
          )}
        </div>
        <button
          onClick={() => {
            setIsVisible(false);
            setTimeout(() => onDismiss?.(alert.id), 300);
          }}
          className="p-1 hover:bg-white/50 rounded-lg transition"
        >
          <X className="w-4 h-4 text-gray-400" />
        </button>
      </div>
    </div>
  );
}

export function useAlerts(initialAlerts = []) {
  const [alerts, setAlerts] = useState(initialAlerts);

  const addAlert = useCallback((alert) => {
    const newAlert = {
      id: `alert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      read: false,
      starred: false,
      dismissed: false,
      ...alert
    };
    setAlerts(prev => [newAlert, ...prev]);
    return newAlert.id;
  }, []);

  const dismissAlert = useCallback((alertId) => {
    setAlerts(prev => prev.map(a => 
      a.id === alertId ? { ...a, dismissed: true } : a
    ));
  }, []);

  const markRead = useCallback((alertId) => {
    setAlerts(prev => prev.map(a => 
      a.id === alertId ? { ...a, read: true } : a
    ));
  }, []);

  const markAllRead = useCallback(() => {
    setAlerts(prev => prev.map(a => ({ ...a, read: true })));
  }, []);

  const toggleStar = useCallback((alertId) => {
    setAlerts(prev => prev.map(a => 
      a.id === alertId ? { ...a, starred: !a.starred } : a
    ));
  }, []);

  const clearAll = useCallback(() => {
    setAlerts([]);
  }, []);

  return {
    alerts,
    addAlert,
    dismissAlert,
    markRead,
    markAllRead,
    toggleStar,
    clearAll,
    setAlerts
  };
}