import React, { useState, useEffect, useMemo, useCallback } from "react";
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip, 
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
  ComposedChart,
  Area
} from "recharts";
import { 
  CreditCard, 
  Banknote, 
  Building2, 
  Smartphone,
  Wallet,
  QrCode,
  Globe,
  Receipt,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Download,
  RefreshCw,
  Filter,
  Calendar,
  Info,
  AlertCircle,
  CheckCircle,
  Clock,
  Settings,
  Eye,
  EyeOff,
  MoreVertical,
  Percent,
  DollarSign,
  Target,
  Zap,
  Shield,
  Lock,
  AlertTriangle,
  XCircle,
  Users,
  FileText,
  BarChart3,
  PieChart as PieChartIcon,
  Activity,
  Loader2
} from "lucide-react";
import { format, subDays, subMonths, startOfMonth, endOfMonth, differenceInDays, parseISO, isWithinInterval } from "date-fns";

const PAYMENT_METHOD_CONFIG = {
  card: {
    label: "Card Payments",
    icon: CreditCard,
    color: "#6366f1",
    description: "Credit and debit card transactions",
    processingFee: 2.9,
    fixedFee: 0.30
  },
  cash: {
    label: "Cash",
    icon: Banknote,
    color: "#10b981",
    description: "Cash payments collected",
    processingFee: 0,
    fixedFee: 0
  },
  bank_transfer: {
    label: "Bank Transfer",
    icon: Building2,
    color: "#f59e0b",
    description: "Direct bank transfers",
    processingFee: 0.5,
    fixedFee: 0
  },
  online: {
    label: "Online Payment",
    icon: Globe,
    color: "#a855f7",
    description: "Online payment gateway",
    processingFee: 2.5,
    fixedFee: 0.25
  },
  wallet: {
    label: "Digital Wallet",
    icon: Wallet,
    color: "#ec4899",
    description: "Apple Pay, Google Pay, etc.",
    processingFee: 2.9,
    fixedFee: 0.30
  },
  qr_code: {
    label: "QR Code",
    icon: QrCode,
    color: "#14b8a6",
    description: "QR code payments",
    processingFee: 1.5,
    fixedFee: 0.15
  },
  direct_debit: {
    label: "Direct Debit",
    icon: Receipt,
    color: "#f97316",
    description: "Recurring direct debit",
    processingFee: 1.0,
    fixedFee: 0.20
  },
  other: {
    label: "Other",
    icon: DollarSign,
    color: "#94a3b8",
    description: "Other payment methods",
    processingFee: 0,
    fixedFee: 0
  }
};

const CHART_VIEWS = [
  { id: "pie", label: "Distribution", icon: PieChartIcon },
  { id: "bar", label: "Comparison", icon: BarChart3 },
  { id: "trend", label: "Trend", icon: Activity }
];

const TIME_PERIODS = [
  { id: "7d", label: "Last 7 Days" },
  { id: "30d", label: "Last 30 Days" },
  { id: "90d", label: "Last 90 Days" },
  { id: "ytd", label: "Year to Date" },
  { id: "all", label: "All Time" }
];

export default function PaymentBreakdown({ 
  data = [],
  processingFees,
  transactions = [],
  historicalData = [],
  dateRange,
  previousPeriodData,
  settings,
  onExport,
  onRefresh,
  onMethodClick,
  onSettingsClick,
  isLoading = false,
  showTrends = true,
  showFees = true,
  showInsights = true,
  compact = false
}) {
  const [chartView, setChartView] = useState("pie");
  const [selectedPeriod, setSelectedPeriod] = useState("30d");
  const [expandedMethod, setExpandedMethod] = useState(null);
  const [showAllMethods, setShowAllMethods] = useState(false);
  const [showFeeDetails, setShowFeeDetails] = useState(false);
  const [sortBy, setSortBy] = useState("value");
  const [sortDirection, setSortDirection] = useState("desc");

  const processedData = useMemo(() => {
    return data.map(item => {
      const config = PAYMENT_METHOD_CONFIG[item.name] || PAYMENT_METHOD_CONFIG.other;
      const transactionCount = item.transactions || item.count || 0;
      
      const percentageFee = (item.value * config.processingFee) / 100;
      const fixedFees = transactionCount * config.fixedFee;
      const totalFees = percentageFee + fixedFees;
      const netAmount = item.value - totalFees;

      return {
        ...item,
        ...config,
        transactionCount,
        totalFees,
        netAmount,
        avgTransaction: transactionCount > 0 ? item.value / transactionCount : 0,
        effectiveRate: item.value > 0 ? (totalFees / item.value) * 100 : 0
      };
    });
  }, [data]);

  const sortedData = useMemo(() => {
    return [...processedData].sort((a, b) => {
      const aValue = a[sortBy] || 0;
      const bValue = b[sortBy] || 0;
      return sortDirection === "desc" ? bValue - aValue : aValue - bValue;
    });
  }, [processedData, sortBy, sortDirection]);

  const displayData = useMemo(() => {
    return showAllMethods ? sortedData : sortedData.slice(0, 5);
  }, [sortedData, showAllMethods]);

  const totalMetrics = useMemo(() => {
    const total = processedData.reduce((sum, item) => sum + item.value, 0);
    const totalFees = processedData.reduce((sum, item) => sum + item.totalFees, 0);
    const totalTransactions = processedData.reduce((sum, item) => sum + item.transactionCount, 0);
    const netTotal = total - totalFees;

    const previousTotal = previousPeriodData?.reduce((sum, item) => sum + item.value, 0) || 0;
    const growthRate = previousTotal > 0 ? ((total - previousTotal) / previousTotal) * 100 : 0;

    const dominantMethod = processedData.reduce((max, item) => 
      item.value > (max?.value || 0) ? item : max
    , null);

    const avgTransactionValue = totalTransactions > 0 ? total / totalTransactions : 0;
    const blendedRate = total > 0 ? (totalFees / total) * 100 : 0;

    return {
      total,
      totalFees,
      totalTransactions,
      netTotal,
      growthRate,
      dominantMethod,
      avgTransactionValue,
      blendedRate
    };
  }, [processedData, previousPeriodData]);

  const chartDataWithPercentage = useMemo(() => {
    return processedData.map(item => ({
      ...item,
      percentage: totalMetrics.total > 0 ? (item.value / totalMetrics.total) * 100 : 0
    }));
  }, [processedData, totalMetrics.total]);

  const trendData = useMemo(() => {
    if (historicalData.length > 0) return historicalData;

    return Array.from({ length: 12 }, (_, i) => {
      const date = subMonths(new Date(), 11 - i);
      const baseMultiplier = 0.8 + Math.random() * 0.4;
      
      return {
        month: format(date, "MMM"),
        card: Math.round(totalMetrics.total * 0.4 * baseMultiplier / 12),
        cash: Math.round(totalMetrics.total * 0.25 * baseMultiplier / 12),
        bank_transfer: Math.round(totalMetrics.total * 0.15 * baseMultiplier / 12),
        online: Math.round(totalMetrics.total * 0.12 * baseMultiplier / 12),
        other: Math.round(totalMetrics.total * 0.08 * baseMultiplier / 12)
      };
    });
  }, [historicalData, totalMetrics.total]);

  const insights = useMemo(() => {
    const results = [];

    if (totalMetrics.dominantMethod) {
      const dominantPercentage = (totalMetrics.dominantMethod.value / totalMetrics.total) * 100;
      if (dominantPercentage > 60) {
        results.push({
          type: "info",
          title: "Payment Concentration",
          message: `${totalMetrics.dominantMethod.label} accounts for ${dominantPercentage.toFixed(0)}% of payments. Consider diversifying payment options.`
        });
      }
    }

    if (totalMetrics.blendedRate > 2.5) {
      results.push({
        type: "warning",
        title: "High Processing Costs",
        message: `Your blended rate of ${totalMetrics.blendedRate.toFixed(2)}% is above average. Consider negotiating lower rates or promoting lower-cost payment methods.`
      });
    }

    const cashPercentage = processedData.find(p => p.name === "cash")?.percentage || 0;
    if (cashPercentage > 30) {
      results.push({
        type: "info",
        title: "High Cash Usage",
        message: "Cash payments are high. Consider encouraging digital payments for better tracking and reduced handling costs."
      });
    }

    if (totalMetrics.growthRate > 10) {
      results.push({
        type: "success",
        title: "Strong Growth",
        message: `Payment volume increased ${totalMetrics.growthRate.toFixed(1)}% compared to the previous period.`
      });
    } else if (totalMetrics.growthRate < -10) {
      results.push({
        type: "warning",
        title: "Volume Decline",
        message: `Payment volume decreased ${Math.abs(totalMetrics.growthRate).toFixed(1)}% compared to the previous period.`
      });
    }

    return results;
  }, [totalMetrics, processedData]);

  const handleSort = useCallback((column) => {
    if (sortBy === column) {
      setSortDirection(prev => prev === "desc" ? "asc" : "desc");
    } else {
      setSortBy(column);
      setSortDirection("desc");
    }
  }, [sortBy]);

  const handleExport = useCallback((format) => {
    if (onExport) {
      onExport({
        format,
        data: {
          breakdown: processedData,
          totals: totalMetrics,
          trends: trendData
        }
      });
    }
  }, [onExport, processedData, totalMetrics, trendData]);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const formatCompact = (amount) => {
    if (amount >= 1000000) return `€${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `€${(amount / 1000).toFixed(1)}K`;
    return formatCurrency(amount);
  };

  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload || !payload.length) return null;
    
    const data = payload[0]?.payload;
    
    return (
      <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-200 max-w-xs">
        <div className="flex items-center gap-2 mb-2">
          <div 
            className="w-3 h-3 rounded-full"
            style={{ backgroundColor: data?.color }}
          />
          <span className="font-semibold text-gray-900">{data?.label}</span>
        </div>
        <div className="space-y-1 text-sm">
          <div className="flex justify-between gap-4">
            <span className="text-gray-600">Amount:</span>
            <span className="font-semibold">{formatCurrency(data?.value)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-gray-600">Percentage:</span>
            <span className="font-semibold">{data?.percentage?.toFixed(1)}%</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-gray-600">Transactions:</span>
            <span className="font-semibold">{data?.transactionCount}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-gray-600">Fees:</span>
            <span className="font-semibold text-red-600">-{formatCurrency(data?.totalFees)}</span>
          </div>
        </div>
      </div>
    );
  };

  const renderPieChart = () => (
    <ResponsiveContainer width="100%" height={compact ? 180 : 220}>
      <PieChart>
        <Pie
          data={chartDataWithPercentage}
          cx="50%"
          cy="50%"
          innerRadius={compact ? 50 : 65}
          outerRadius={compact ? 75 : 90}
          paddingAngle={2}
          dataKey="value"
          strokeWidth={0}
        >
          {chartDataWithPercentage.map((entry, index) => (
            <Cell 
              key={`cell-${index}`} 
              fill={entry.color}
              className="cursor-pointer hover:opacity-80 transition-opacity"
              onClick={() => onMethodClick?.(entry)}
            />
          ))}
        </Pie>
        <Tooltip content={<CustomTooltip />} />
      </PieChart>
    </ResponsiveContainer>
  );

  const renderBarChart = () => (
    <ResponsiveContainer width="100%" height={compact ? 180 : 220}>
      <BarChart data={chartDataWithPercentage} layout="vertical">
        <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
        <XAxis type="number" tickFormatter={(v) => formatCompact(v)} />
        <YAxis type="category" dataKey="label" width={100} tick={{ fontSize: 12 }} />
        <Tooltip content={<CustomTooltip />} />
        <Bar dataKey="value" radius={[0, 4, 4, 0]}>
          {chartDataWithPercentage.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );

  const renderTrendChart = () => (
    <ResponsiveContainer width="100%" height={compact ? 180 : 220}>
      <ComposedChart data={trendData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" tick={{ fontSize: 11 }} />
        <YAxis tickFormatter={(v) => formatCompact(v)} tick={{ fontSize: 11 }} />
        <Tooltip formatter={(value) => formatCurrency(value)} />
        <Legend />
        <Area type="monotone" dataKey="card" stackId="1" fill="#6366f1" stroke="#6366f1" fillOpacity={0.6} name="Card" />
        <Area type="monotone" dataKey="cash" stackId="1" fill="#10b981" stroke="#10b981" fillOpacity={0.6} name="Cash" />
        <Area type="monotone" dataKey="bank_transfer" stackId="1" fill="#f59e0b" stroke="#f59e0b" fillOpacity={0.6} name="Bank Transfer" />
        <Area type="monotone" dataKey="online" stackId="1" fill="#a855f7" stroke="#a855f7" fillOpacity={0.6} name="Online" />
      </ComposedChart>
    </ResponsiveContainer>
  );

  const PaymentMethodRow = ({ method, isExpanded, onToggle }) => {
    const IconComponent = method.icon;
    const percentage = totalMetrics.total > 0 ? (method.value / totalMetrics.total) * 100 : 0;

    return (
      <div className="border-b border-gray-100 last:border-0">
        <button
          onClick={() => onToggle(method.name)}
          className="w-full p-3 flex items-center justify-between hover:bg-gray-50 transition"
        >
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ backgroundColor: `${method.color}15` }}
            >
              <IconComponent className="w-5 h-5" style={{ color: method.color }} />
            </div>
            <div className="text-left">
              <p className="font-medium text-gray-900">{method.label}</p>
              <p className="text-xs text-gray-500">{method.transactionCount} transactions</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-bold text-gray-900 tabular-nums">{formatCurrency(method.value)}</p>
              <p className="text-xs text-gray-500">{percentage.toFixed(1)}%</p>
            </div>
            {isExpanded ? (
              <ChevronUp className="w-4 h-4 text-gray-400" />
            ) : (
              <ChevronDown className="w-4 h-4 text-gray-400" />
            )}
          </div>
        </button>

        {isExpanded && (
          <div className="px-4 pb-4 bg-gray-50">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2">
              <div className="p-3 bg-white rounded-lg">
                <p className="text-xs text-gray-500">Avg Transaction</p>
                <p className="font-semibold text-gray-900">{formatCurrency(method.avgTransaction)}</p>
              </div>
              <div className="p-3 bg-white rounded-lg">
                <p className="text-xs text-gray-500">Processing Fee</p>
                <p className="font-semibold text-gray-900">{method.processingFee}%</p>
              </div>
              <div className="p-3 bg-white rounded-lg">
                <p className="text-xs text-gray-500">Total Fees</p>
                <p className="font-semibold text-red-600">-{formatCurrency(method.totalFees)}</p>
              </div>
              <div className="p-3 bg-white rounded-lg">
                <p className="text-xs text-gray-500">Net Amount</p>
                <p className="font-semibold text-green-600">{formatCurrency(method.netAmount)}</p>
              </div>
            </div>

            <div className="mt-3">
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all duration-500"
                  style={{ 
                    width: `${percentage}%`,
                    backgroundColor: method.color
                  }}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`bg-white rounded-2xl border border-gray-200 overflow-hidden ${compact ? "" : ""}`}>
      <div className={`${compact ? "p-4" : "p-6"} border-b border-gray-200`}>
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className={`font-bold text-gray-900 ${compact ? "text-base" : "text-lg"}`}>Payment Methods</h3>
            <p className="text-sm text-gray-500">Breakdown by payment type</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-gray-100 rounded-lg p-1">
              {CHART_VIEWS.map(view => (
                <button
                  key={view.id}
                  onClick={() => setChartView(view.id)}
                  className={`p-1.5 rounded-md transition ${
                    chartView === view.id
                      ? "bg-white text-gray-900 shadow-sm"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                  title={view.label}
                >
                  <view.icon className="w-4 h-4" />
                </button>
              ))}
            </div>
            <button
              onClick={() => onRefresh?.()}
              disabled={isLoading}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <RefreshCw className={`w-4 h-4 text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
            </button>
            <button
              onClick={() => handleExport("csv")}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <Download className="w-4 h-4 text-gray-600" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="p-3 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
            <p className="text-xs text-indigo-600 font-medium">Total Volume</p>
            <p className="text-xl font-bold text-gray-900">{formatCompact(totalMetrics.total)}</p>
            {totalMetrics.growthRate !== 0 && (
              <div className={`flex items-center gap-1 text-xs ${
                totalMetrics.growthRate >= 0 ? "text-green-600" : "text-red-600"
              }`}>
                {totalMetrics.growthRate >= 0 ? (
                  <ArrowUpRight className="w-3 h-3" />
                ) : (
                  <ArrowDownRight className="w-3 h-3" />
                )}
                {Math.abs(totalMetrics.growthRate).toFixed(1)}%
              </div>
            )}
          </div>
          
          <div className="p-3 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl">
            <p className="text-xs text-green-600 font-medium">Transactions</p>
            <p className="text-xl font-bold text-gray-900">{totalMetrics.totalTransactions.toLocaleString()}</p>
            <p className="text-xs text-gray-500">Avg: {formatCurrency(totalMetrics.avgTransactionValue)}</p>
          </div>
          
          <div className="p-3 bg-gradient-to-br from-red-50 to-orange-50 rounded-xl">
            <p className="text-xs text-red-600 font-medium">Processing Fees</p>
            <p className="text-xl font-bold text-gray-900">-{formatCompact(totalMetrics.totalFees)}</p>
            <p className="text-xs text-gray-500">Rate: {totalMetrics.blendedRate.toFixed(2)}%</p>
          </div>
          
          <div className="p-3 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
            <p className="text-xs text-blue-600 font-medium">Net Revenue</p>
            <p className="text-xl font-bold text-gray-900">{formatCompact(totalMetrics.netTotal)}</p>
            <p className="text-xs text-gray-500">{((totalMetrics.netTotal / totalMetrics.total) * 100).toFixed(1)}% retained</p>
          </div>
        </div>
      </div>

      <div className={`${compact ? "p-4" : "p-6"}`}>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            {chartView === "pie" && renderPieChart()}
            {chartView === "bar" && renderBarChart()}
            {chartView === "trend" && renderTrendChart()}

            {totalMetrics.dominantMethod && (
              <div className="text-center mt-2">
                <p className="text-sm text-gray-500">
                  <span className="font-medium" style={{ color: totalMetrics.dominantMethod.color }}>
                    {totalMetrics.dominantMethod.label}
                  </span>
                  {" "}is your most used method
                </p>
              </div>
            )}
          </div>

          <div className="bg-gray-50 rounded-xl overflow-hidden">
            {displayData.map((method) => (
              <PaymentMethodRow
                key={method.name}
                method={method}
                isExpanded={expandedMethod === method.name}
                onToggle={(name) => setExpandedMethod(expandedMethod === name ? null : name)}
              />
            ))}

            {sortedData.length > 5 && (
              <button
                onClick={() => setShowAllMethods(!showAllMethods)}
                className="w-full p-3 text-sm text-indigo-600 hover:bg-gray-100 transition flex items-center justify-center gap-1"
              >
                {showAllMethods ? (
                  <>
                    <ChevronUp className="w-4 h-4" />
                    Show less
                  </>
                ) : (
                  <>
                    <ChevronDown className="w-4 h-4" />
                    Show {sortedData.length - 5} more
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>

      {showFees && (processingFees || totalMetrics.totalFees > 0) && (
        <div className={`${compact ? "px-4 pb-4" : "px-6 pb-6"}`}>
          <button
            onClick={() => setShowFeeDetails(!showFeeDetails)}
            className="w-full flex items-center justify-between p-4 bg-red-50 rounded-xl hover:bg-red-100 transition"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
                <Receipt className="w-5 h-5 text-red-600" />
              </div>
              <div className="text-left">
                <p className="font-semibold text-gray-900">Processing Fees</p>
                <p className="text-sm text-gray-600">View fee breakdown by method</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="font-bold text-red-600">-{formatCurrency(processingFees?.total || totalMetrics.totalFees)}</p>
                <p className="text-xs text-gray-500">
                  {(processingFees?.rate || totalMetrics.blendedRate).toFixed(2)}% blended rate
                </p>
              </div>
              {showFeeDetails ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </div>
          </button>

          {showFeeDetails && (
            <div className="mt-4 space-y-2">
              {processedData.filter(m => m.totalFees > 0).map(method => (
                <div key={method.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <method.icon className="w-4 h-4" style={{ color: method.color }} />
                    <span className="text-sm text-gray-700">{method.label}</span>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-gray-500">{method.processingFee}% + €{method.fixedFee}</span>
                    <span className="font-semibold text-red-600">-{formatCurrency(method.totalFees)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {showInsights && insights.length > 0 && (
        <div className={`${compact ? "px-4 pb-4" : "px-6 pb-6"} border-t border-gray-200 pt-4`}>
          <div className="flex items-center gap-2 mb-3">
            <Zap className="w-4 h-4 text-amber-500" />
            <h4 className="font-semibold text-gray-900">Insights</h4>
          </div>
          <div className="space-y-2">
            {insights.map((insight, index) => (
              <div 
                key={index}
                className={`flex items-start gap-3 p-3 rounded-lg ${
                  insight.type === "warning" ? "bg-amber-50" :
                  insight.type === "success" ? "bg-green-50" :
                  insight.type === "error" ? "bg-red-50" :
                  "bg-blue-50"
                }`}
              >
                {insight.type === "warning" ? <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" /> :
                 insight.type === "success" ? <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" /> :
                 insight.type === "error" ? <XCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" /> :
                 <Info className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />}
                <div>
                  <p className="font-medium text-gray-900 text-sm">{insight.title}</p>
                  <p className="text-xs text-gray-600">{insight.message}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {isLoading && (
        <div className="absolute inset-0 bg-white/80 flex items-center justify-center">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        </div>
      )}
    </div>
  );
}

export function PaymentMethodSummary({ methods = [], compact = false }) {
  const total = methods.reduce((sum, m) => sum + m.value, 0);

  return (
    <div className={`flex flex-wrap gap-2 ${compact ? "" : "gap-3"}`}>
      {methods.slice(0, 4).map(method => {
        const config = PAYMENT_METHOD_CONFIG[method.name] || PAYMENT_METHOD_CONFIG.other;
        const percentage = total > 0 ? (method.value / total) * 100 : 0;
        const IconComponent = config.icon;

        return (
          <div 
            key={method.name}
            className={`flex items-center gap-2 ${compact ? "px-2 py-1" : "px-3 py-2"} bg-gray-50 rounded-lg`}
          >
            <IconComponent className="w-4 h-4" style={{ color: config.color }} />
            <span className="text-sm font-medium text-gray-900">{percentage.toFixed(0)}%</span>
          </div>
        );
      })}
    </div>
  );
}

export function PaymentMethodIcon({ method, size = "md" }) {
  const config = PAYMENT_METHOD_CONFIG[method] || PAYMENT_METHOD_CONFIG.other;
  const IconComponent = config.icon;

  const sizeClasses = {
    sm: "w-6 h-6",
    md: "w-8 h-8",
    lg: "w-10 h-10"
  };

  const iconSizes = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-5 h-5"
  };

  return (
    <div 
      className={`${sizeClasses[size]} rounded-lg flex items-center justify-center`}
      style={{ backgroundColor: `${config.color}15` }}
    >
      <IconComponent className={iconSizes[size]} style={{ color: config.color }} />
    </div>
  );
}