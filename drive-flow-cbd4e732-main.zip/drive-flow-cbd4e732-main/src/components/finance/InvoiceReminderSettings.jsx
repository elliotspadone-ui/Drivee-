import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Bell, Save } from "lucide-react";
import { toast } from "sonner";

const DEFAULT_SETTINGS = {
  enabled: true,
  firstReminderDays: 3,
  secondReminderDays: 7,
  finalReminderDays: 14,
  reminderEmailSubject: "Payment Reminder - Invoice {{invoice_number}}",
  reminderEmailBody: `Dear {{student_name}},

This is a friendly reminder that your invoice {{invoice_number}} for €{{total_amount}} is now overdue.

Invoice Date: {{invoice_date}}
Due Date: {{due_date}}
Amount Due: €{{amount_due}}

Please make payment at your earliest convenience.

Thank you,
{{school_name}}`,
};

export default function InvoiceReminderSettings() {
  const queryClient = useQueryClient();
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [hydratedFromRules, setHydratedFromRules] = useState(false);

  const { data: schools = [] } = useQuery({
    queryKey: ["schools"],
    queryFn: () => base44.entities.School.list(),
    staleTime: 300000,
  });

  const { data: automationRules = [] } = useQuery({
    queryKey: ["automationRules"],
    queryFn: () => base44.entities.AutomationRule.list(),
  });

  const schoolId = schools[0]?.id || "default";

  // Hydrate settings from existing automation rules once
  useEffect(() => {
    if (hydratedFromRules || automationRules.length === 0) return;

    const invoiceRules = automationRules.filter(
      (r) =>
        r.school_id === schoolId &&
        r.trigger_type === "invoice_overdue" &&
        r.action_type === "send_email"
    );

    if (invoiceRules.length === 0) return;

    const getStageRule = (stage) =>
      invoiceRules.find((r) =>
        r.rule_name?.toLowerCase().includes(`invoice overdue reminder - ${stage}`)
      );

    const firstRule = getStageRule("first");
    const secondRule = getStageRule("second");
    const finalRule = getStageRule("final");

    // Use any existing rule as source for subject/body
    const baseRule = firstRule || secondRule || finalRule;

    setSettings((prev) => ({
      ...prev,
      enabled: invoiceRules.some((r) => r.is_active),
      firstReminderDays:
        firstRule?.trigger_conditions?.days_overdue ??
        prev.firstReminderDays,
      secondReminderDays:
        secondRule?.trigger_conditions?.days_overdue ??
        prev.secondReminderDays,
      finalReminderDays:
        finalRule?.trigger_conditions?.days_overdue ??
        prev.finalReminderDays,
      reminderEmailSubject:
        baseRule?.action_config?.subject ?? prev.reminderEmailSubject,
      reminderEmailBody:
        baseRule?.action_config?.body ?? prev.reminderEmailBody,
    }));

    setHydratedFromRules(true);
  }, [automationRules, hydratedFromRules, schoolId]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      const stages = [
        { days: data.firstReminderDays, stage: "first" },
        { days: data.secondReminderDays, stage: "second" },
        { days: data.finalReminderDays, stage: "final" },
      ];

      const existingRules = automationRules.filter(
        (r) =>
          r.school_id === schoolId &&
          r.trigger_type === "invoice_overdue" &&
          r.action_type === "send_email"
      );

      for (const { days, stage } of stages) {
        const ruleName = `Invoice Overdue Reminder - ${stage}`;
        const existing = existingRules.find((r) => r.rule_name === ruleName);

        const payload = {
          school_id: schoolId,
          rule_name: ruleName,
          trigger_type: "invoice_overdue",
          trigger_conditions: {
            days_overdue: Number.isFinite(days) ? days : 0,
          },
          action_type: "send_email",
          action_config: {
            subject: data.reminderEmailSubject,
            body: data.reminderEmailBody,
            recipient: "{{invoice.student_email}}",
          },
          is_active: data.enabled,
        };

        if (existing) {
          await base44.entities.AutomationRule.update(existing.id, payload);
        } else if (data.enabled) {
          // Only create new rules when feature is enabled
          await base44.entities.AutomationRule.create(payload);
        }
      }

      // If user disabled reminders, make sure we deactivate any extra stray rules
      if (!data.enabled && existingRules.length > 0) {
        const extraRules = existingRules.filter(
          (r) =>
            !stages.some(
              ({ stage }) => r.rule_name === `Invoice Overdue Reminder - ${stage}`
            )
        );
        for (const r of extraRules) {
          if (r.is_active) {
            await base44.entities.AutomationRule.update(r.id, {
              is_active: false,
            });
          }
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["automationRules"] });
      toast.success("Reminder settings saved");
    },
    onError: () => {
      toast.error("Failed to save reminder settings");
    },
  });

  const handleNumberChange = (key) => (e) => {
    const value = parseInt(e.target.value, 10);
    setSettings((prev) => ({
      ...prev,
      [key]: Number.isFinite(value) ? value : 0,
    }));
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6">
      <div className="flex items-center gap-3 mb-6">
        <Bell className="w-6 h-6 text-indigo-600" />
        <div>
          <h3 className="text-lg font-semibold text-gray-900">
            Payment Reminder Settings
          </h3>
          <p className="text-sm text-gray-500">
            Automatically send email reminders for overdue invoices
          </p>
        </div>
      </div>

      <div className="space-y-6">
        <label className="flex items-center gap-3">
          <input
            type="checkbox"
            checked={settings.enabled}
            onChange={(e) =>
              setSettings((prev) => ({
                ...prev,
                enabled: e.target.checked,
              }))
            }
            className="w-5 h-5 rounded border-gray-300"
          />
          <span className="font-medium text-gray-900">
            Enable automatic payment reminders
          </span>
        </label>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              First Reminder (days overdue)
            </label>
            <input
              type="number"
              min={1}
              value={settings.firstReminderDays}
              onChange={handleNumberChange("firstReminderDays")}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Second Reminder (days overdue)
            </label>
            <input
              type="number"
              min={1}
              value={settings.secondReminderDays}
              onChange={handleNumberChange("secondReminderDays")}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Final Reminder (days overdue)
            </label>
            <input
              type="number"
              min={1}
              value={settings.finalReminderDays}
              onChange={handleNumberChange("finalReminderDays")}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Email Subject
          </label>
          <input
            type="text"
            value={settings.reminderEmailSubject}
            onChange={(e) =>
              setSettings((prev) => ({
                ...prev,
                reminderEmailSubject: e.target.value,
              }))
            }
            className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Email Body
          </label>
          <textarea
            value={settings.reminderEmailBody}
            onChange={(e) =>
              setSettings((prev) => ({
                ...prev,
                reminderEmailBody: e.target.value,
              }))
            }
            className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-600 h-64 font-mono text-sm"
          />
          <p className="text-xs text-gray-500 mt-2">
            Available variables:{" "}
            {`{{student_name}}, {{invoice_number}}, {{total_amount}}, {{invoice_date}}, {{due_date}}, {{amount_due}}, {{school_name}}`}
          </p>
        </div>

        <button
          onClick={() => saveMutation.mutate(settings)}
          disabled={saveMutation.isPending}
          className="w-full px-6 py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
        >
          <Save className="w-5 h-5" />
          {saveMutation.isPending ? "Saving..." : "Save Reminder Settings"}
        </button>
      </div>
    </div>
  );
}
