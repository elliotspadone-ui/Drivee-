import React, { useState, useEffect, useMemo, useCallback } from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend, 
  Cell,
  LineChart,
  Line,
  ComposedChart,
  Area,
  PieChart,
  Pie,
  RadialBarChart,
  RadialBar
} from "recharts";
import { 
  Target, 
  TrendingUp, 
  TrendingDown, 
  AlertCircle,
  DollarSign,
  Percent,
  Calendar,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Download,
  RefreshCw,
  Settings,
  Filter,
  Eye,
  EyeOff,
  Info,
  AlertTriangle,
  CheckCircle,
  XCircle,
  ArrowUpRight,
  ArrowDownRight,
  Edit,
  Save,
  X,
  Plus,
  Trash2,
  Copy,
  BarChart3,
  PieChart as PieChartIcon,
  Activity,
  Lightbulb,
  Flag,
  Zap,
  Clock,
  Users,
  Car,
  Fuel,
  Wrench,
  Building2,
  Megaphone,
  Shield,
  Receipt,
  Wallet,
  Calculator,
  FileText,
  Loader2
} from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, addMonths, differenceInDays, parseISO, isWithinInterval } from "date-fns";

const BUDGET_CATEGORIES = {
  revenue: {
    id: "revenue",
    label: "Revenue",
    type: "income",
    icon: DollarSign,
    color: "green",
    subcategories: [
      { id: "lesson_revenue", label: "Lesson Revenue", defaultBudget: 35000 },
      { id: "package_revenue", label: "Package Sales", defaultBudget: 10000 },
      { id: "test_fees", label: "Test Fees", defaultBudget: 3000 },
      { id: "other_revenue", label: "Other Revenue", defaultBudget: 2000 }
    ]
  },
  directCosts: {
    id: "directCosts",
    label: "Direct Costs",
    type: "expense",
    icon: Users,
    color: "red",
    subcategories: [
      { id: "instructor_commission", label: "Instructor Commissions", defaultBudget: 22000 },
      { id: "fuel", label: "Fuel Costs", defaultBudget: 2500 },
      { id: "vehicle_maintenance", label: "Vehicle Maintenance", defaultBudget: 1500 },
      { id: "vehicle_insurance", label: "Vehicle Insurance", defaultBudget: 1000 }
    ]
  },
  operatingExpenses: {
    id: "operatingExpenses",
    label: "Operating Expenses",
    type: "expense",
    icon: Building2,
    color: "orange",
    subcategories: [
      { id: "facility", label: "Facility Costs", defaultBudget: 1500 },
      { id: "marketing", label: "Marketing", defaultBudget: 500 },
      { id: "software", label: "Software & Tools", defaultBudget: 300 },
      { id: "admin", label: "Administrative", defaultBudget: 400 },
      { id: "insurance", label: "Business Insurance", defaultBudget: 500 }
    ]
  }
};

const VARIANCE_THRESHOLDS = {
  excellent: { min: -5, max: 5 },
  good: { min: -10, max: 10 },
  warning: { min: -20, max: 20 },
  critical: { min: -Infinity, max: Infinity }
};

const PERIOD_OPTIONS = [
  { id: "month", label: "This Month" },
  { id: "quarter", label: "This Quarter" },
  { id: "ytd", label: "Year to Date" },
  { id: "year", label: "Full Year" },
  { id: "custom", label: "Custom Range" }
];

export default function BudgetComparison({ 
  totalRevenue = 0, 
  totalExpenses = 0,
  budgetRevenue = 50000,
  budgetExpenses = 30000,
  revenueBreakdown = {},
  expenseBreakdown = {},
  budgetData = {},
  previousPeriodData,
  historicalData = [],
  dateRange,
  school,
  settings,
  onBudgetUpdate,
  onExport,
  onRefresh,
  isLoading = false
}) {
  const [selectedPeriod, setSelectedPeriod] = useState("month");
  const [viewMode, setViewMode] = useState("summary");
  const [chartType, setChartType] = useState("bar");
  const [showSubcategories, setShowSubcategories] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState(new Set(["revenue"]));
  const [isEditing, setIsEditing] = useState(false);
  const [editedBudgets, setEditedBudgets] = useState({});
  const [showForecasting, setShowForecasting] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(null);

  useEffect(() => {
    const defaultBudgets = {};
    Object.values(BUDGET_CATEGORIES).forEach(category => {
      category.subcategories.forEach(sub => {
        defaultBudgets[sub.id] = budgetData[sub.id] || sub.defaultBudget;
      });
    });
    setEditedBudgets(defaultBudgets);
  }, [budgetData]);

  const calculateVariance = useCallback((actual, budget) => {
    if (budget === 0) return { amount: actual, percentage: actual > 0 ? 100 : 0 };
    return {
      amount: actual - budget,
      percentage: ((actual - budget) / budget) * 100
    };
  }, []);

  const getVarianceStatus = useCallback((variance, type = "revenue") => {
    const adjustedVariance = type === "expense" ? -variance : variance;
    
    if (Math.abs(adjustedVariance) <= VARIANCE_THRESHOLDS.excellent.max) return "excellent";
    if (Math.abs(adjustedVariance) <= VARIANCE_THRESHOLDS.good.max) return "good";
    if (Math.abs(adjustedVariance) <= VARIANCE_THRESHOLDS.warning.max) return "warning";
    return "critical";
  }, []);

  const budgetAnalysis = useMemo(() => {
    const actualRevenue = totalRevenue || 0;
    const actualExpenses = totalExpenses || 0;
    const actualProfit = actualRevenue - actualExpenses;
    const budgetProfit = budgetRevenue - budgetExpenses;

    const revenueVariance = calculateVariance(actualRevenue, budgetRevenue);
    const expenseVariance = calculateVariance(actualExpenses, budgetExpenses);
    const profitVariance = calculateVariance(actualProfit, budgetProfit);

    const revenueAchievement = budgetRevenue > 0 ? (actualRevenue / budgetRevenue) * 100 : 0;
    const expenseControl = budgetExpenses > 0 ? (actualExpenses / budgetExpenses) * 100 : 0;
    const profitAchievement = budgetProfit > 0 ? (actualProfit / budgetProfit) * 100 : 0;

    const categoryAnalysis = {};
    
    Object.entries(BUDGET_CATEGORIES).forEach(([key, category]) => {
      const subcategoryAnalysis = category.subcategories.map(sub => {
        const actualAmount = category.type === "income" 
          ? (revenueBreakdown[sub.id] || 0)
          : (expenseBreakdown[sub.id] || 0);
        const budgetAmount = editedBudgets[sub.id] || sub.defaultBudget;
        const variance = calculateVariance(actualAmount, budgetAmount);
        
        return {
          ...sub,
          actual: actualAmount,
          budget: budgetAmount,
          variance,
          achievement: budgetAmount > 0 ? (actualAmount / budgetAmount) * 100 : 0,
          status: getVarianceStatus(variance.percentage, category.type === "income" ? "revenue" : "expense")
        };
      });

      const totalActual = subcategoryAnalysis.reduce((sum, s) => sum + s.actual, 0);
      const totalBudget = subcategoryAnalysis.reduce((sum, s) => sum + s.budget, 0);
      const totalVariance = calculateVariance(totalActual, totalBudget);

      categoryAnalysis[key] = {
        ...category,
        subcategories: subcategoryAnalysis,
        totalActual,
        totalBudget,
        variance: totalVariance,
        achievement: totalBudget > 0 ? (totalActual / totalBudget) * 100 : 0,
        status: getVarianceStatus(totalVariance.percentage, category.type === "income" ? "revenue" : "expense")
      };
    });

    const overallScore = calculateOverallScore({
      revenueAchievement,
      expenseControl,
      profitAchievement
    });

    return {
      revenue: {
        actual: actualRevenue,
        budget: budgetRevenue,
        variance: revenueVariance,
        achievement: revenueAchievement,
        status: getVarianceStatus(revenueVariance.percentage, "revenue")
      },
      expenses: {
        actual: actualExpenses,
        budget: budgetExpenses,
        variance: expenseVariance,
        achievement: expenseControl,
        status: getVarianceStatus(expenseVariance.percentage, "expense")
      },
      profit: {
        actual: actualProfit,
        budget: budgetProfit,
        variance: profitVariance,
        achievement: profitAchievement,
        status: getVarianceStatus(profitVariance.percentage, "revenue")
      },
      categories: categoryAnalysis,
      overallScore
    };
  }, [totalRevenue, totalExpenses, budgetRevenue, budgetExpenses, revenueBreakdown, expenseBreakdown, editedBudgets, calculateVariance, getVarianceStatus]);

  function calculateOverallScore(metrics) {
    const weights = {
      revenueAchievement: 0.4,
      expenseControl: 0.3,
      profitAchievement: 0.3
    };

    let score = 0;
    
    const revenueScore = Math.min(100, Math.max(0, metrics.revenueAchievement));
    score += revenueScore * weights.revenueAchievement;

    const expenseScore = metrics.expenseControl <= 100 
      ? 100 - Math.abs(100 - metrics.expenseControl) * 0.5
      : Math.max(0, 100 - (metrics.expenseControl - 100) * 2);
    score += expenseScore * weights.expenseControl;

    const profitScore = Math.min(100, Math.max(0, metrics.profitAchievement));
    score += profitScore * weights.profitAchievement;

    return Math.round(score);
  }

  const chartData = useMemo(() => {
    return [
      {
        category: "Revenue",
        budget: budgetRevenue,
        actual: budgetAnalysis.revenue.actual,
        variance: budgetAnalysis.revenue.variance.percentage,
        type: "revenue"
      },
      {
        category: "Expenses",
        budget: budgetExpenses,
        actual: budgetAnalysis.expenses.actual,
        variance: budgetAnalysis.expenses.variance.percentage,
        type: "expense"
      },
      {
        category: "Profit",
        budget: budgetAnalysis.profit.budget,
        actual: budgetAnalysis.profit.actual,
        variance: budgetAnalysis.profit.variance.percentage,
        type: "profit"
      }
    ];
  }, [budgetRevenue, budgetExpenses, budgetAnalysis]);

  const trendData = useMemo(() => {
    if (historicalData.length === 0) {
      return Array.from({ length: 6 }, (_, i) => {
        const month = subMonths(new Date(), 5 - i);
        return {
          month: format(month, "MMM"),
          budgetRevenue: budgetRevenue * (0.9 + Math.random() * 0.2),
          actualRevenue: totalRevenue * (0.8 + Math.random() * 0.4),
          budgetExpenses: budgetExpenses * (0.95 + Math.random() * 0.1),
          actualExpenses: totalExpenses * (0.85 + Math.random() * 0.3)
        };
      });
    }
    return historicalData;
  }, [historicalData, budgetRevenue, budgetExpenses, totalRevenue, totalExpenses]);

  const insights = useMemo(() => {
    const results = [];

    if (budgetAnalysis.revenue.variance.percentage < -10) {
      results.push({
        type: "critical",
        category: "Revenue",
        title: "Revenue Below Target",
        description: `Revenue is ${Math.abs(budgetAnalysis.revenue.variance.percentage).toFixed(1)}% below budget. Consider increasing marketing efforts or adjusting pricing strategy.`,
        impact: budgetAnalysis.revenue.variance.amount,
        actions: ["Review pricing strategy", "Increase marketing spend", "Launch promotional campaigns"]
      });
    } else if (budgetAnalysis.revenue.variance.percentage > 10) {
      results.push({
        type: "success",
        category: "Revenue",
        title: "Revenue Exceeds Target",
        description: `Revenue is ${budgetAnalysis.revenue.variance.percentage.toFixed(1)}% above budget. Consider updating forecasts and scaling operations.`,
        impact: budgetAnalysis.revenue.variance.amount,
        actions: ["Update annual forecast", "Consider expansion", "Reward top performers"]
      });
    }

    if (budgetAnalysis.expenses.variance.percentage > 10) {
      results.push({
        type: "warning",
        category: "Expenses",
        title: "Expenses Over Budget",
        description: `Expenses are ${budgetAnalysis.expenses.variance.percentage.toFixed(1)}% above budget. Review operational costs and identify areas for optimization.`,
        impact: budgetAnalysis.expenses.variance.amount,
        actions: ["Review vendor contracts", "Optimize fuel usage", "Reduce administrative overhead"]
      });
    } else if (budgetAnalysis.expenses.variance.percentage < -10) {
      results.push({
        type: "success",
        category: "Expenses",
        title: "Expenses Under Budget",
        description: `Expenses are ${Math.abs(budgetAnalysis.expenses.variance.percentage).toFixed(1)}% under budget. Great cost control!`,
        impact: Math.abs(budgetAnalysis.expenses.variance.amount),
        actions: ["Document best practices", "Consider strategic investments", "Build reserves"]
      });
    }

    if (budgetAnalysis.profit.actual < 0) {
      results.push({
        type: "critical",
        category: "Profit",
        title: "Operating at a Loss",
        description: `Current operations are unprofitable. Immediate action required to improve margins.`,
        impact: budgetAnalysis.profit.actual,
        actions: ["Emergency cost review", "Revenue enhancement initiatives", "Cash flow management"]
      });
    }

    Object.values(budgetAnalysis.categories).forEach(category => {
      category.subcategories.forEach(sub => {
        if (sub.status === "critical" && Math.abs(sub.variance.percentage) > 25) {
          results.push({
            type: "warning",
            category: sub.label,
            title: `${sub.label} Variance Alert`,
            description: `${sub.label} is ${sub.variance.percentage > 0 ? "over" : "under"} budget by ${Math.abs(sub.variance.percentage).toFixed(1)}%`,
            impact: sub.variance.amount,
            actions: [`Review ${sub.label.toLowerCase()} spending`, "Adjust budget allocation"]
          });
        }
      });
    });

    return results;
  }, [budgetAnalysis]);

  const toggleCategory = useCallback((categoryId) => {
    setExpandedCategories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(categoryId)) {
        newSet.delete(categoryId);
      } else {
        newSet.add(categoryId);
      }
      return newSet;
    });
  }, []);

  const handleBudgetChange = useCallback((subcategoryId, value) => {
    setEditedBudgets(prev => ({
      ...prev,
      [subcategoryId]: parseFloat(value) || 0
    }));
  }, []);

  const handleSaveBudgets = useCallback(async () => {
    if (onBudgetUpdate) {
      await onBudgetUpdate(editedBudgets);
    }
    setIsEditing(false);
  }, [editedBudgets, onBudgetUpdate]);

  const handleExport = useCallback((format) => {
    if (onExport) {
      onExport({
        format,
        data: {
          summary: budgetAnalysis,
          trends: trendData,
          insights
        }
      });
    }
  }, [onExport, budgetAnalysis, trendData, insights]);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatPercentage = (value) => {
    return `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "excellent": return "green";
      case "good": return "blue";
      case "warning": return "amber";
      case "critical": return "red";
      default: return "gray";
    }
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;
    
    return (
      <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-200">
        <p className="font-bold text-gray-900 mb-2">{label}</p>
        <div className="space-y-1 text-sm">
          {payload.map((entry, index) => (
            <div key={index} className="flex items-center justify-between gap-4">
              <span className="text-gray-600">{entry.name}:</span>
              <span className="font-semibold" style={{ color: entry.color }}>
                {formatCurrency(entry.value)}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const VarianceCard = ({ title, data, type = "revenue" }) => {
    const isPositive = type === "revenue" 
      ? data.variance.percentage >= 0 
      : data.variance.percentage <= 0;
    const IconComponent = isPositive ? TrendingUp : TrendingDown;
    const statusColor = getStatusColor(data.status);

    return (
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h4 className="font-semibold text-gray-900 mb-1">{title}</h4>
            <p className="text-xs text-gray-500">Budget vs Actual</p>
          </div>
          <div className={`w-10 h-10 ${
            statusColor === 'green' ? 'bg-green-100' :
            statusColor === 'blue' ? 'bg-blue-100' :
            statusColor === 'amber' ? 'bg-amber-100' :
            'bg-red-100'
          } rounded-xl flex items-center justify-center`}>
            <IconComponent className={`w-5 h-5 ${
              statusColor === 'green' ? 'text-green-600' :
              statusColor === 'blue' ? 'text-blue-600' :
              statusColor === 'amber' ? 'text-amber-600' :
              'text-red-600'
            }`} />
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">Budget</span>
            <span className="text-lg font-bold text-gray-900">{formatCurrency(data.budget)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-500">Actual</span>
            <span className={`text-lg font-bold text-${statusColor}-600`}>
              {formatCurrency(data.actual)}
            </span>
          </div>
          <div className="border-t border-gray-200 pt-3 flex items-center justify-between">
            <span className="text-sm font-semibold text-gray-900">Variance</span>
            <div className="text-right">
              <div className={`text-lg font-bold text-${statusColor}-600`}>
                {formatPercentage(data.variance.percentage)}
              </div>
              <div className="text-xs text-gray-500">
                {formatCurrency(Math.abs(data.variance.amount))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4">
          <div className="relative h-3 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className={`absolute h-full transition-all duration-500 rounded-full ${
                statusColor === 'green' ? 'bg-green-500' :
                statusColor === 'blue' ? 'bg-blue-500' :
                statusColor === 'amber' ? 'bg-amber-500' :
                'bg-red-500'
              }`}
              style={{ width: `${Math.min(100, data.achievement)}%` }}
            />
            {data.achievement > 100 && (
              <div 
                className="absolute h-full bg-red-300 transition-all duration-500"
                style={{ left: "100%", width: `${Math.min(50, data.achievement - 100)}%` }}
              />
            )}
          </div>
          <div className="flex items-center justify-between mt-1 text-xs text-gray-500">
            <span>0%</span>
            <span>Target: 100%</span>
            <span className={`font-medium ${
              statusColor === 'green' ? 'text-green-600' :
              statusColor === 'blue' ? 'text-blue-600' :
              statusColor === 'amber' ? 'text-amber-600' :
              'text-red-600'
            }`}>{data.achievement.toFixed(0)}%</span>
          </div>
        </div>
      </div>
    );
  };

  const CategoryBreakdown = ({ category }) => {
    const isExpanded = expandedCategories.has(category.id);
    const IconComponent = category.icon;
    const statusColor = getStatusColor(category.status);

    return (
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <button
          onClick={() => toggleCategory(category.id)}
          className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition"
        >
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 ${
              category.color === 'green' ? 'bg-green-100' :
              category.color === 'red' ? 'bg-red-100' :
              category.color === 'orange' ? 'bg-orange-100' :
              'bg-gray-100'
            } rounded-xl flex items-center justify-center`}>
              <IconComponent className={`w-5 h-5 ${
                category.color === 'green' ? 'text-green-600' :
                category.color === 'red' ? 'text-red-600' :
                category.color === 'orange' ? 'text-orange-600' :
                'text-gray-600'
              }`} />
            </div>
            <div className="text-left">
              <p className="font-semibold text-gray-900">{category.label}</p>
              <p className="text-xs text-gray-500">{category.subcategories.length} line items</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-bold text-gray-900">{formatCurrency(category.totalActual)}</p>
              <p className={`text-sm ${
                statusColor === 'green' ? 'text-green-600' :
                statusColor === 'blue' ? 'text-blue-600' :
                statusColor === 'amber' ? 'text-amber-600' :
                'text-red-600'
              }`}>
                {formatPercentage(category.variance.percentage)}
              </p>
            </div>
            {isExpanded ? (
              <ChevronUp className="w-5 h-5 text-gray-400" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-400" />
            )}
          </div>
        </button>

        {isExpanded && (
          <div className="border-t border-gray-200 divide-y divide-gray-100">
            {category.subcategories.map(sub => {
              const subStatusColor = getStatusColor(sub.status);
              
              return (
                <div key={sub.id} className="p-4 flex items-center justify-between hover:bg-gray-50">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{sub.label}</p>
                  </div>
                  <div className="flex items-center gap-6">
                    {isEditing ? (
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-500">Budget:</span>
                        <input
                          type="number"
                          value={editedBudgets[sub.id] || sub.budget}
                          onChange={(e) => handleBudgetChange(sub.id, e.target.value)}
                          className="w-24 px-2 py-1 border border-gray-200 rounded-lg text-sm text-right focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                    ) : (
                      <div className="text-right">
                        <p className="text-sm text-gray-500">{formatCurrency(sub.budget)}</p>
                        <p className="text-xs text-gray-400">budget</p>
                      </div>
                    )}
                    <div className="text-right w-24">
                      <p className="font-semibold text-gray-900">{formatCurrency(sub.actual)}</p>
                      <p className="text-xs text-gray-500">actual</p>
                    </div>
                    <div className="text-right w-20">
                      <p className={`font-semibold ${
                        subStatusColor === 'green' ? 'text-green-600' :
                        subStatusColor === 'blue' ? 'text-blue-600' :
                        subStatusColor === 'amber' ? 'text-amber-600' :
                        'text-red-600'
                      }`}>
                        {formatPercentage(sub.variance.percentage)}
                      </p>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                        subStatusColor === 'green' ? 'bg-green-100 text-green-700' :
                        subStatusColor === 'blue' ? 'bg-blue-100 text-blue-700' :
                        subStatusColor === 'amber' ? 'bg-amber-100 text-amber-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {sub.status}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}

            <div className="p-4 bg-gray-50 flex items-center justify-between font-semibold">
              <span className="text-gray-900">Category Total</span>
              <div className="flex items-center gap-6">
                <div className="text-right w-24">
                  <p className="text-gray-700">{formatCurrency(category.totalBudget)}</p>
                </div>
                <div className="text-right w-24">
                  <p className="text-gray-900">{formatCurrency(category.totalActual)}</p>
                </div>
                <div className="text-right w-20">
                  <p className={`${
                    statusColor === 'green' ? 'text-green-600' :
                    statusColor === 'blue' ? 'text-blue-600' :
                    statusColor === 'amber' ? 'text-amber-600' :
                    'text-red-600'
                  }`}>
                    {formatPercentage(category.variance.percentage)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-2xl border border-indigo-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-indigo-100 rounded-2xl flex items-center justify-center">
              <Target className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">Budget vs Actual Analysis</h3>
              <p className="text-sm text-gray-600">Performance against financial targets</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {PERIOD_OPTIONS.map(option => (
                <option key={option.id} value={option.id}>{option.label}</option>
              ))}
            </select>

            {isEditing ? (
              <>
                <button
                  onClick={handleSaveBudgets}
                  className="p-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
                >
                  <Save className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setIsEditing(false)}
                  className="p-2 bg-gray-200 text-gray-600 rounded-lg hover:bg-gray-300 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="p-2 hover:bg-white/50 rounded-lg transition"
                title="Edit Budgets"
              >
                <Edit className="w-5 h-5 text-gray-600" />
              </button>
            )}

            <button
              onClick={() => onRefresh?.()}
              disabled={isLoading}
              className="p-2 hover:bg-white/50 rounded-lg transition"
            >
              <RefreshCw className={`w-5 h-5 text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
            </button>

            <button
              onClick={() => handleExport("pdf")}
              className="p-2 hover:bg-white/50 rounded-lg transition"
            >
              <Download className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white/80 p-4 rounded-xl">
            <p className="text-xs text-gray-500 mb-1">Overall Score</p>
            <p className={`text-3xl font-bold ${
              budgetAnalysis.overallScore >= 80 ? "text-green-600" :
              budgetAnalysis.overallScore >= 60 ? "text-blue-600" :
              budgetAnalysis.overallScore >= 40 ? "text-amber-600" :
              "text-red-600"
            }`}>
              {budgetAnalysis.overallScore}/100
            </p>
          </div>
          <div className="bg-white/80 p-4 rounded-xl">
            <p className="text-xs text-gray-500 mb-1">Revenue Achievement</p>
            <p className={`text-3xl font-bold ${
              budgetAnalysis.revenue.achievement >= 100 ? "text-green-600" :
              budgetAnalysis.revenue.achievement >= 90 ? "text-blue-600" :
              "text-amber-600"
            }`}>
              {budgetAnalysis.revenue.achievement.toFixed(0)}%
            </p>
          </div>
          <div className="bg-white/80 p-4 rounded-xl">
            <p className="text-xs text-gray-500 mb-1">Expense Control</p>
            <p className={`text-3xl font-bold ${
              budgetAnalysis.expenses.achievement <= 100 ? "text-green-600" :
              budgetAnalysis.expenses.achievement <= 110 ? "text-amber-600" :
              "text-red-600"
            }`}>
              {budgetAnalysis.expenses.achievement.toFixed(0)}%
            </p>
          </div>
          <div className="bg-white/80 p-4 rounded-xl">
            <p className="text-xs text-gray-500 mb-1">Profit Variance</p>
            <p className={`text-3xl font-bold ${
              budgetAnalysis.profit.variance.percentage >= 0 ? "text-green-600" : "text-red-600"
            }`}>
              {formatPercentage(budgetAnalysis.profit.variance.percentage)}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <VarianceCard 
          title="Revenue" 
          data={budgetAnalysis.revenue}
          type="revenue"
        />
        <VarianceCard 
          title="Expenses" 
          data={budgetAnalysis.expenses}
          type="expense"
        />
        <VarianceCard 
          title="Net Profit" 
          data={budgetAnalysis.profit}
          type="profit"
        />
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-gray-900">Budget vs Actual Comparison</h4>
            <div className="flex items-center gap-2">
              {[
                { id: "bar", icon: BarChart3 },
                { id: "composed", icon: Activity }
              ].map(type => (
                <button
                  key={type.id}
                  onClick={() => setChartType(type.id)}
                  className={`p-2 rounded-lg transition ${
                    chartType === type.id
                      ? "bg-indigo-100 text-indigo-600"
                      : "hover:bg-gray-100 text-gray-600"
                  }`}
                >
                  <type.icon className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="p-6">
          <ResponsiveContainer width="100%" height={350}>
            {chartType === "bar" ? (
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="category" stroke="#6b7280" style={{ fontSize: "12px" }} />
                <YAxis stroke="#6b7280" style={{ fontSize: "12px" }} tickFormatter={(v) => `€${v >= 1000 ? (v/1000).toFixed(0) + "k" : v}`} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar dataKey="budget" name="Budget" fill="#9ca3af" radius={[4, 4, 0, 0]} />
                <Bar dataKey="actual" name="Actual" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.type === "expense" 
                        ? (entry.variance <= 0 ? "#10b981" : "#ef4444")
                        : (entry.variance >= 0 ? "#10b981" : "#ef4444")
                      } 
                    />
                  ))}
                </Bar>
              </BarChart>
            ) : (
              <ComposedChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="month" stroke="#6b7280" style={{ fontSize: "12px" }} />
                <YAxis stroke="#6b7280" style={{ fontSize: "12px" }} tickFormatter={(v) => `€${v >= 1000 ? (v/1000).toFixed(0) + "k" : v}`} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Area type="monotone" dataKey="budgetRevenue" name="Budget Revenue" fill="#e0e7ff" stroke="#6366f1" strokeWidth={2} />
                <Line type="monotone" dataKey="actualRevenue" name="Actual Revenue" stroke="#10b981" strokeWidth={2} dot={{ fill: "#10b981" }} />
                <Line type="monotone" dataKey="actualExpenses" name="Actual Expenses" stroke="#ef4444" strokeWidth={2} dot={{ fill: "#ef4444" }} />
              </ComposedChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-bold text-gray-900">Category Breakdown</h4>
          <button
            onClick={() => setShowSubcategories(!showSubcategories)}
            className="flex items-center gap-2 text-sm text-indigo-600 hover:text-indigo-700"
          >
            {showSubcategories ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {showSubcategories ? "Hide Details" : "Show Details"}
          </button>
        </div>

        {Object.values(budgetAnalysis.categories).map(category => (
          <CategoryBreakdown key={category.id} category={category} />
        ))}
      </div>

      {insights.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-3">
              <Lightbulb className="w-6 h-6 text-amber-500" />
              <div>
                <h4 className="font-bold text-gray-900">Key Insights & Recommendations</h4>
                <p className="text-sm text-gray-500">{insights.length} items requiring attention</p>
              </div>
            </div>
          </div>

          <div className="divide-y divide-gray-100">
            {insights.map((insight, index) => (
              <div key={index} className="p-4">
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    insight.type === "critical" ? "bg-red-100" :
                    insight.type === "warning" ? "bg-amber-100" :
                    "bg-green-100"
                  }`}>
                    {insight.type === "critical" ? <AlertTriangle className="w-4 h-4 text-red-600" /> :
                     insight.type === "warning" ? <AlertCircle className="w-4 h-4 text-amber-600" /> :
                     <CheckCircle className="w-4 h-4 text-green-600" />}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold text-gray-900">{insight.title}</p>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                        insight.type === "critical" ? "bg-red-100 text-red-700" :
                        insight.type === "warning" ? "bg-amber-100 text-amber-700" :
                        "bg-green-100 text-green-700"
                      }`}>
                        {insight.category}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{insight.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {insight.actions.map((action, actionIndex) => (
                        <span key={actionIndex} className="px-2 py-1 bg-gray-100 text-gray-700 rounded-lg text-xs">
                          {action}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${insight.type === "success" ? "text-green-600" : "text-red-600"}`}>
                      {formatCurrency(Math.abs(insight.impact))}
                    </p>
                    <p className="text-xs text-gray-500">impact</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {budgetAnalysis.revenue.variance.percentage >= 0 && budgetAnalysis.expenses.variance.percentage <= 0 && (
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl border border-green-200">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h4 className="font-bold text-green-900 mb-1">On Track!</h4>
              <p className="text-green-700">
                Revenue exceeds target by {budgetAnalysis.revenue.variance.percentage.toFixed(1)}% while keeping expenses {Math.abs(budgetAnalysis.expenses.variance.percentage).toFixed(1)}% under budget. Excellent performance!
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-200">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-indigo-600 mt-0.5" />
          <div className="text-sm text-indigo-700">
            <p className="font-semibold mb-1">Budget Analysis Notes</p>
            <ul className="list-disc list-inside space-y-1 text-xs">
              <li>Variances are calculated as (Actual - Budget) / Budget × 100</li>
              <li>For expenses, negative variance (under budget) is considered favorable</li>
              <li>For revenue, positive variance (over budget) is considered favorable</li>
              <li>Click "Edit Budgets" to adjust budget allocations for each category</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}