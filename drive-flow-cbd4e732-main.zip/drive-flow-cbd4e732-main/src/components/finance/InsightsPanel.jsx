import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { 
  Lightbulb, 
  TrendingUp, 
  TrendingDown,
  Users, 
  Target, 
  Sparkles, 
  CheckCircle, 
  AlertCircle,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  X,
  RefreshCw,
  Download,
  Share2,
  Copy,
  Settings,
  Filter,
  Clock,
  Calendar,
  DollarSign,
  Car,
  CreditCard,
  Award,
  Zap,
  Activity,
  BarChart3,
  PieChart,
  LineChart,
  Star,
  Flag,
  Bell,
  BellOff,
  Eye,
  EyeOff,
  ThumbsUp,
  ThumbsDown,
  MessageSquare,
  Send,
  Bookmark,
  BookmarkCheck,
  ExternalLink,
  Info,
  HelpCircle,
  Loader2,
  Brain,
  Cpu,
  Wand2,
  Rocket,
  Shield,
  Lock,
  Unlock,
  Play,
  Pause,
  SkipForward,
  History,
  Layers,
  Grid,
  List,
  MoreVertical,
  Search,
  SlidersHorizontal
} from "lucide-react";
import { format, formatDistanceToNow, differenceInDays, subDays, parseISO, isToday, isYesterday, isThisWeek } from "date-fns";

const INSIGHT_TYPES = {
  growth: {
    icon: TrendingUp,
    label: "Growth",
    description: "Revenue and business growth opportunities",
    gradient: "from-green-500 to-emerald-500",
    bgColor: "bg-green-500/10",
    borderColor: "border-green-500/30",
    textColor: "text-green-300",
    iconBg: "bg-green-500/20"
  },
  decline: {
    icon: TrendingDown,
    label: "Decline",
    description: "Areas showing decline that need attention",
    gradient: "from-red-500 to-rose-500",
    bgColor: "bg-red-500/10",
    borderColor: "border-red-500/30",
    textColor: "text-red-300",
    iconBg: "bg-red-500/20"
  },
  opportunity: {
    icon: Target,
    label: "Opportunity",
    description: "Potential improvements and optimizations",
    gradient: "from-amber-500 to-orange-500",
    bgColor: "bg-amber-500/10",
    borderColor: "border-amber-500/30",
    textColor: "text-amber-300",
    iconBg: "bg-amber-500/20"
  },
  efficiency: {
    icon: Zap,
    label: "Efficiency",
    description: "Operational efficiency insights",
    gradient: "from-blue-500 to-cyan-500",
    bgColor: "bg-blue-500/10",
    borderColor: "border-blue-500/30",
    textColor: "text-blue-300",
    iconBg: "bg-blue-500/20"
  },
  engagement: {
    icon: Users,
    label: "Engagement",
    description: "Student and instructor engagement",
    gradient: "from-purple-500 to-violet-500",
    bgColor: "bg-purple-500/10",
    borderColor: "border-purple-500/30",
    textColor: "text-purple-300",
    iconBg: "bg-purple-500/20"
  },
  warning: {
    icon: AlertTriangle,
    label: "Warning",
    description: "Issues requiring immediate attention",
    gradient: "from-red-600 to-rose-600",
    bgColor: "bg-red-600/10",
    borderColor: "border-red-600/30",
    textColor: "text-red-300",
    iconBg: "bg-red-600/20"
  },
  success: {
    icon: CheckCircle,
    label: "Success",
    description: "Positive achievements and milestones",
    gradient: "from-emerald-500 to-teal-500",
    bgColor: "bg-emerald-500/10",
    borderColor: "border-emerald-500/30",
    textColor: "text-emerald-300",
    iconBg: "bg-emerald-500/20"
  },
  financial: {
    icon: DollarSign,
    label: "Financial",
    description: "Revenue, costs, and profitability insights",
    gradient: "from-emerald-500 to-green-500",
    bgColor: "bg-emerald-500/10",
    borderColor: "border-emerald-500/30",
    textColor: "text-emerald-300",
    iconBg: "bg-emerald-500/20"
  },
  scheduling: {
    icon: Calendar,
    label: "Scheduling",
    description: "Booking and availability insights",
    gradient: "from-indigo-500 to-blue-500",
    bgColor: "bg-indigo-500/10",
    borderColor: "border-indigo-500/30",
    textColor: "text-indigo-300",
    iconBg: "bg-indigo-500/20"
  },
  prediction: {
    icon: Brain,
    label: "Prediction",
    description: "AI-powered forecasts and predictions",
    gradient: "from-pink-500 to-rose-500",
    bgColor: "bg-pink-500/10",
    borderColor: "border-pink-500/30",
    textColor: "text-pink-300",
    iconBg: "bg-pink-500/20"
  }
};

const INSIGHT_CATEGORIES = [
  { id: "all", label: "All Insights" },
  { id: "actionable", label: "Action Required" },
  { id: "positive", label: "Positive" },
  { id: "warnings", label: "Warnings" },
  { id: "predictions", label: "Predictions" }
];

const PRIORITY_LEVELS = {
  critical: { label: "Critical", color: "red", order: 1 },
  high: { label: "High", color: "orange", order: 2 },
  medium: { label: "Medium", color: "amber", order: 3 },
  low: { label: "Low", color: "green", order: 4 }
};

export default function InsightsPanel({ 
  insights = [],
  onInsightAction,
  onInsightDismiss,
  onInsightFeedback,
  onInsightSave,
  onRefresh,
  onExport,
  onSettingsClick,
  isLoading = false,
  autoRefresh = false,
  refreshInterval = 300000,
  showFilters = true,
  showActions = true,
  maxVisible = 5,
  compact = false,
  animated = true,
  title = "AI Insights",
  emptyTitle = "Everything looks great!",
  emptyMessage = "No critical insights at this time",
  className = ""
}) {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [expandedInsights, setExpandedInsights] = useState(new Set());
  const [savedInsights, setSavedInsights] = useState(new Set());
  const [dismissedInsights, setDismissedInsights] = useState(new Set());
  const [feedbackGiven, setFeedbackGiven] = useState({});
  const [showAllInsights, setShowAllInsights] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("priority");
  const [viewMode, setViewMode] = useState("list");
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [animatingIds, setAnimatingIds] = useState(new Set());
  const panelRef = useRef(null);

  useEffect(() => {
    if (!autoRefresh || !onRefresh) return;

    const interval = setInterval(() => {
      handleRefresh();
    }, refreshInterval);

    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval, onRefresh]);

  const processedInsights = useMemo(() => {
    return insights.map((insight, index) => ({
      ...insight,
      id: insight.id || `insight-${index}-${Date.now()}`,
      type: insight.type || "efficiency",
      priority: insight.priority || "medium",
      timestamp: insight.timestamp || new Date().toISOString(),
      actionable: !!insight.action || !!insight.link,
      saved: savedInsights.has(insight.id),
      dismissed: dismissedInsights.has(insight.id),
      feedback: feedbackGiven[insight.id]
    }));
  }, [insights, savedInsights, dismissedInsights, feedbackGiven]);

  const filteredInsights = useMemo(() => {
    let result = processedInsights.filter(insight => !insight.dismissed);

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(insight =>
        insight.message?.toLowerCase().includes(query) ||
        insight.title?.toLowerCase().includes(query) ||
        insight.recommendation?.toLowerCase().includes(query)
      );
    }

    switch (selectedCategory) {
      case "actionable":
        result = result.filter(insight => insight.actionable);
        break;
      case "positive":
        result = result.filter(insight => ["growth", "success", "opportunity"].includes(insight.type));
        break;
      case "warnings":
        result = result.filter(insight => ["warning", "decline"].includes(insight.type));
        break;
      case "predictions":
        result = result.filter(insight => insight.type === "prediction" || insight.isPrediction);
        break;
    }

    result.sort((a, b) => {
      if (sortBy === "priority") {
        return (PRIORITY_LEVELS[a.priority]?.order || 99) - (PRIORITY_LEVELS[b.priority]?.order || 99);
      }
      if (sortBy === "date") {
        return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
      }
      if (sortBy === "type") {
        return (a.type || "").localeCompare(b.type || "");
      }
      return 0;
    });

    return result;
  }, [processedInsights, selectedCategory, searchQuery, sortBy]);

  const displayedInsights = useMemo(() => {
    return showAllInsights ? filteredInsights : filteredInsights.slice(0, maxVisible);
  }, [filteredInsights, showAllInsights, maxVisible]);

  const insightStats = useMemo(() => {
    const stats = {
      total: filteredInsights.length,
      actionable: 0,
      positive: 0,
      warnings: 0,
      byType: {},
      byPriority: {}
    };

    filteredInsights.forEach(insight => {
      if (insight.actionable) stats.actionable++;
      if (["growth", "success", "opportunity"].includes(insight.type)) stats.positive++;
      if (["warning", "decline"].includes(insight.type)) stats.warnings++;
      
      stats.byType[insight.type] = (stats.byType[insight.type] || 0) + 1;
      stats.byPriority[insight.priority] = (stats.byPriority[insight.priority] || 0) + 1;
    });

    return stats;
  }, [filteredInsights]);

  const toggleExpand = useCallback((insightId) => {
    setExpandedInsights(prev => {
      const newSet = new Set(prev);
      if (newSet.has(insightId)) {
        newSet.delete(insightId);
      } else {
        newSet.add(insightId);
      }
      return newSet;
    });
  }, []);

  const handleSaveInsight = useCallback((insightId) => {
    setSavedInsights(prev => {
      const newSet = new Set(prev);
      if (newSet.has(insightId)) {
        newSet.delete(insightId);
      } else {
        newSet.add(insightId);
      }
      return newSet;
    });
    onInsightSave?.(insightId, !savedInsights.has(insightId));
  }, [savedInsights, onInsightSave]);

  const handleDismissInsight = useCallback((insightId) => {
    setAnimatingIds(prev => new Set(prev).add(insightId));
    
    setTimeout(() => {
      setDismissedInsights(prev => new Set(prev).add(insightId));
      setAnimatingIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(insightId);
        return newSet;
      });
      onInsightDismiss?.(insightId);
    }, 300);
  }, [onInsightDismiss]);

  const handleFeedback = useCallback((insightId, isHelpful) => {
    setFeedbackGiven(prev => ({
      ...prev,
      [insightId]: isHelpful
    }));
    onInsightFeedback?.(insightId, isHelpful);
  }, [onInsightFeedback]);

  const handleRefresh = useCallback(async () => {
    if (!onRefresh || isRefreshing) return;
    
    setIsRefreshing(true);
    try {
      await onRefresh();
    } finally {
      setIsRefreshing(false);
    }
  }, [onRefresh, isRefreshing]);

  const handleAction = useCallback((insight) => {
    onInsightAction?.(insight);
  }, [onInsightAction]);

  const getTypeConfig = useCallback((type) => {
    return INSIGHT_TYPES[type] || INSIGHT_TYPES.efficiency;
  }, []);

  const formatTimestamp = useCallback((timestamp) => {
    const date = new Date(timestamp);
    
    if (isToday(date)) {
      return `Today at ${format(date, "h:mm a")}`;
    }
    if (isYesterday(date)) {
      return `Yesterday`;
    }
    if (isThisWeek(date)) {
      return format(date, "EEEE");
    }
    
    return format(date, "MMM d");
  }, []);

  const InsightCard = ({ insight, isExpanded, onToggle }) => {
    const typeConfig = getTypeConfig(insight.type);
    const Icon = typeConfig.icon;
    const priorityConfig = PRIORITY_LEVELS[insight.priority] || PRIORITY_LEVELS.medium;
    const isAnimating = animatingIds.has(insight.id);

    return (
      <div 
        className={`
          ${typeConfig.bgColor} ${typeConfig.borderColor} border backdrop-blur-sm rounded-xl 
          transition-all duration-300 overflow-hidden
          ${isAnimating ? "opacity-0 scale-95 -translate-x-full" : "opacity-100 scale-100 translate-x-0"}
          ${animated ? "hover:bg-white/20 hover:scale-[1.01]" : ""}
        `}
      >
        <div className="p-4">
          <div className="flex items-start gap-3">
            <div className={`w-10 h-10 ${typeConfig.iconBg} rounded-xl flex items-center justify-center flex-shrink-0`}>
              <Icon className="w-5 h-5 text-white" />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2 mb-1">
                <div className="flex items-center gap-2 flex-wrap">
                  {insight.title && (
                    <span className="font-semibold text-white text-sm">{insight.title}</span>
                  )}
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${typeConfig.bgColor} ${typeConfig.textColor} border ${typeConfig.borderColor}`}>
                    {typeConfig.label}
                  </span>
                  {insight.priority === "critical" && (
                    <span className="px-2 py-0.5 bg-red-500/30 text-red-300 rounded-full text-xs font-bold animate-pulse">
                      Critical
                    </span>
                  )}
                  {insight.isNew && (
                    <span className="px-2 py-0.5 bg-blue-500/30 text-blue-300 rounded-full text-xs font-medium">
                      New
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleSaveInsight(insight.id)}
                    className="p-1 hover:bg-white/10 rounded-lg transition"
                    title={insight.saved ? "Unsave" : "Save"}
                  >
                    {insight.saved ? (
                      <BookmarkCheck className="w-4 h-4 text-amber-400" />
                    ) : (
                      <Bookmark className="w-4 h-4 text-white/60 hover:text-white" />
                    )}
                  </button>
                  {showActions && (
                    <button
                      onClick={() => handleDismissInsight(insight.id)}
                      className="p-1 hover:bg-white/10 rounded-lg transition"
                      title="Dismiss"
                    >
                      <X className="w-4 h-4 text-white/60 hover:text-white" />
                    </button>
                  )}
                </div>
              </div>

              <p className="text-sm text-white/90 leading-snug mb-2">
                {insight.message}
              </p>

              {insight.metrics && (
                <div className="flex items-center gap-3 mb-2">
                  {insight.metrics.map((metric, idx) => (
                    <div key={idx} className="flex items-center gap-1">
                      {metric.trend === "up" && <ArrowUpRight className="w-3 h-3 text-green-400" />}
                      {metric.trend === "down" && <ArrowDownRight className="w-3 h-3 text-red-400" />}
                      <span className="text-xs font-semibold text-white">{metric.value}</span>
                      <span className="text-xs text-white/60">{metric.label}</span>
                    </div>
                  ))}
                </div>
              )}

              {insight.recommendation && !isExpanded && (
                <p className="text-xs text-white/70 leading-relaxed line-clamp-2">
                  💡 {insight.recommendation}
                </p>
              )}

              <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/10">
                <div className="flex items-center gap-3 text-xs text-white/50">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatTimestamp(insight.timestamp)}
                  </span>
                  {insight.source && (
                    <span className="flex items-center gap-1">
                      <Activity className="w-3 h-3" />
                      {insight.source}
                    </span>
                  )}
                  {insight.confidence && (
                    <span className="flex items-center gap-1">
                      <Brain className="w-3 h-3" />
                      {insight.confidence}% confident
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {insight.action && (
                    <button
                      onClick={() => handleAction(insight)}
                      className="px-3 py-1 bg-white/20 hover:bg-white/30 text-white text-xs font-semibold rounded-lg transition flex items-center gap-1"
                    >
                      {insight.action}
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  )}
                  {insight.link && (
                    
                      href={insight.link}
                      className="px-3 py-1 bg-white/20 hover:bg-white/30 text-white text-xs font-semibold rounded-lg transition flex items-center gap-1"
                    >
                      Details
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                  {(insight.recommendation || insight.details || insight.steps) && (
                    <button
                      onClick={() => onToggle(insight.id)}
                      className="p-1 hover:bg-white/10 rounded-lg transition"
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-white/60" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-white/60" />
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {isExpanded && (
          <div className="px-4 pb-4 pt-2 border-t border-white/10 bg-black/10">
            {insight.recommendation && (
              <div className="mb-3">
                <p className="text-xs font-semibold text-white/70 uppercase mb-1">Recommendation</p>
                <p className="text-sm text-white/90">{insight.recommendation}</p>
              </div>
            )}

            {insight.details && (
              <div className="mb-3">
                <p className="text-xs font-semibold text-white/70 uppercase mb-1">Details</p>
                <p className="text-sm text-white/80">{insight.details}</p>
              </div>
            )}

            {insight.steps && insight.steps.length > 0 && (
              <div className="mb-3">
                <p className="text-xs font-semibold text-white/70 uppercase mb-2">Suggested Steps</p>
                <ol className="space-y-1">
                  {insight.steps.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-white/80">
                      <span className="w-5 h-5 bg-white/20 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">
                        {idx + 1}
                      </span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>
            )}

            {insight.impact && (
              <div className="mb-3 p-3 bg-white/10 rounded-lg">
                <p className="text-xs font-semibold text-white/70 uppercase mb-1">Potential Impact</p>
                <p className="text-sm text-white font-semibold">{insight.impact}</p>
              </div>
            )}

            <div className="flex items-center justify-between pt-2 border-t border-white/10">
              <span className="text-xs text-white/50">Was this insight helpful?</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleFeedback(insight.id, true)}
                  className={`p-1.5 rounded-lg transition ${
                    insight.feedback === true
                      ? "bg-green-500/30 text-green-300"
                      : "hover:bg-white/10 text-white/60"
                  }`}
                >
                  <ThumbsUp className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleFeedback(insight.id, false)}
                  className={`p-1.5 rounded-lg transition ${
                    insight.feedback === false
                      ? "bg-red-500/30 text-red-300"
                      : "hover:bg-white/10 text-white/60"
                  }`}
                >
                  <ThumbsDown className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div 
      ref={panelRef}
      className={`
        bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 
        rounded-2xl shadow-lg overflow-hidden ${className}
      `}
    >
      <div className={`${compact ? "p-4" : "p-6"}`}>
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-white" />
            <h3 className="text-lg font-bold text-white">💡 {title}</h3>
            {insightStats.total > 0 && (
              <span className="px-2 py-0.5 bg-white/20 text-white rounded-full text-xs font-bold">
                {insightStats.total}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            {onRefresh && (
              <button
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="p-1.5 hover:bg-white/10 rounded-lg transition"
                title="Refresh insights"
              >
                <RefreshCw className={`w-4 h-4 text-white/80 ${isRefreshing ? "animate-spin" : ""}`} />
              </button>
            )}
            {onSettingsClick && (
              <button
                onClick={onSettingsClick}
                className="p-1.5 hover:bg-white/10 rounded-lg transition"
                title="Settings"
              >
                <Settings className="w-4 h-4 text-white/80" />
              </button>
            )}
          </div>
        </div>

        {showFilters && insightStats.total > 0 && (
          <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1">
            {INSIGHT_CATEGORIES.map(category => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition ${
                  selectedCategory === category.id
                    ? "bg-white/30 text-white"
                    : "bg-white/10 text-white/70 hover:bg-white/20 hover:text-white"
                }`}
              >
                {category.label}
                {category.id === "warnings" && insightStats.warnings > 0 && (
                  <span className="ml-1 px-1.5 py-0.5 bg-red-500/50 rounded-full text-xs">
                    {insightStats.warnings}
                  </span>
                )}
              </button>
            ))}
          </div>
        )}

        {insightStats.total > 0 && !compact && (
          <div className="grid grid-cols-3 gap-2 mb-4">
            <div className="bg-white/10 rounded-lg p-2 text-center">
              <p className="text-lg font-bold text-white">{insightStats.actionable}</p>
              <p className="text-xs text-white/60">Action Required</p>
            </div>
            <div className="bg-white/10 rounded-lg p-2 text-center">
              <p className="text-lg font-bold text-green-300">{insightStats.positive}</p>
              <p className="text-xs text-white/60">Positive</p>
            </div>
            <div className="bg-white/10 rounded-lg p-2 text-center">
              <p className="text-lg font-bold text-red-300">{insightStats.warnings}</p>
              <p className="text-xs text-white/60">Warnings</p>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {displayedInsights.length === 0 ? (
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20 text-center">
              <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <CheckCircle className="w-6 h-6 text-green-400" />
              </div>
              <p className="font-medium text-white mb-1">{emptyTitle}</p>
              <p className="text-sm text-white/70">{emptyMessage}</p>
            </div>
          ) : (
            displayedInsights.map((insight) => (
              <InsightCard
                key={insight.id}
                insight={insight}
                isExpanded={expandedInsights.has(insight.id)}
                onToggle={toggleExpand}
              />
            ))
          )}
        </div>

        {filteredInsights.length > maxVisible && (
          <button
            onClick={() => setShowAllInsights(!showAllInsights)}
            className="w-full mt-4 py-2 text-sm font-semibold text-white/80 hover:text-white transition flex items-center justify-center gap-1"
          >
            {showAllInsights ? (
              <>
                <ChevronUp className="w-4 h-4" />
                Show less
              </>
            ) : (
              <>
                View all {filteredInsights.length} insights
                <ChevronDown className="w-4 h-4" />
              </>
            )}
          </button>
        )}
      </div>

      {isLoading && (
        <div className="absolute inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center">
          <div className="flex items-center gap-2 text-white">
            <Loader2 className="w-6 h-6 animate-spin" />
            <span className="text-sm font-medium">Analyzing data...</span>
          </div>
        </div>
      )}
    </div>
  );
}

export function InsightBadge({ count, type = "info", pulse = false }) {
  if (!count || count === 0) return null;

  const typeConfig = INSIGHT_TYPES[type] || INSIGHT_TYPES.efficiency;

  return (
    <span className={`
      relative inline-flex items-center justify-center px-2 py-0.5 
      bg-gradient-to-r ${typeConfig.gradient} text-white rounded-full text-xs font-bold
    `}>
      {count}
      {pulse && (
        <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-white rounded-full animate-ping" />
      )}
    </span>
  );
}

export function InsightSummaryCard({ insights = [], compact = false }) {
  const stats = useMemo(() => {
    return {
      total: insights.length,
      critical: insights.filter(i => i.priority === "critical").length,
      actionable: insights.filter(i => i.actionable).length,
      types: insights.reduce((acc, i) => {
        acc[i.type] = (acc[i.type] || 0) + 1;
        return acc;
      }, {})
    };
  }, [insights]);

  if (stats.total === 0) return null;

  const topType = Object.entries(stats.types).sort((a, b) => b[1] - a[1])[0];
  const topTypeConfig = topType ? INSIGHT_TYPES[topType[0]] : null;

  return (
    <div className={`
      bg-gradient-to-r from-indigo-500/10 to-purple-500/10 
      border border-indigo-500/20 rounded-xl ${compact ? "p-3" : "p-4"}
    `}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-500" />
          <span className="font-semibold text-gray-900">{stats.total} Insights</span>
        </div>
        <div className="flex items-center gap-2">
          {stats.critical > 0 && (
            <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs font-bold">
              {stats.critical} critical
            </span>
          )}
          {stats.actionable > 0 && (
            <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-xs font-bold">
              {stats.actionable} action needed
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

export function useInsights(initialInsights = []) {
  const [insights, setInsights] = useState(initialInsights);
  const [isGenerating, setIsGenerating] = useState(false);

  const addInsight = useCallback((insight) => {
    const newInsight = {
      id: `insight-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      isNew: true,
      ...insight
    };
    setInsights(prev => [newInsight, ...prev]);
    return newInsight.id;
  }, []);

  const removeInsight = useCallback((insightId) => {
    setInsights(prev => prev.filter(i => i.id !== insightId));
  }, []);

  const updateInsight = useCallback((insightId, updates) => {
    setInsights(prev => prev.map(i => 
      i.id === insightId ? { ...i, ...updates } : i
    ));
  }, []);

  const clearInsights = useCallback(() => {
    setInsights([]);
  }, []);

  const generateInsights = useCallback(async (data) => {
    setIsGenerating(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      return [];
    } finally {
      setIsGenerating(false);
    }
  }, []);

  return {
    insights,
    isGenerating,
    addInsight,
    removeInsight,
    updateInsight,
    clearInsights,
    generateInsights,
    setInsights
  };
}