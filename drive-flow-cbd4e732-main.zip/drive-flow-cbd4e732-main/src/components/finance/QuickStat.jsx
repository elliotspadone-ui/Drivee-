import React, { useState, useEffect, useMemo, useCallback } from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  Minus,
  ArrowUpRight,
  ArrowDownRight,
  Info,
  HelpCircle,
  ChevronRight,
  ExternalLink,
  Sparkles,
  Target,
  Activity,
  Zap,
  Clock,
  Calendar,
  DollarSign,
  Users,
  Car,
  CreditCard,
  Award,
  Star,
  CheckCircle,
  AlertCircle,
  AlertTriangle,
  BarChart3,
  PieChart,
  LineChart,
  Eye,
  EyeOff,
  RefreshCw,
  MoreVertical,
  Copy,
  Share2,
  Loader2
} from "lucide-react";
import { format, formatDistanceToNow, differenceInDays } from "date-fns";

const COLOR_SCHEMES = {
  indigo: {
    bg: "bg-indigo-50",
    text: "text-indigo-600",
    border: "border-indigo-200",
    gradient: "from-indigo-500 to-indigo-600",
    ring: "ring-indigo-500",
    light: "bg-indigo-100",
    dark: "bg-indigo-600"
  },
  green: {
    bg: "bg-green-50",
    text: "text-green-600",
    border: "border-green-200",
    gradient: "from-green-500 to-emerald-600",
    ring: "ring-green-500",
    light: "bg-green-100",
    dark: "bg-green-600"
  },
  purple: {
    bg: "bg-purple-50",
    text: "text-purple-600",
    border: "border-purple-200",
    gradient: "from-purple-500 to-violet-600",
    ring: "ring-purple-500",
    light: "bg-purple-100",
    dark: "bg-purple-600"
  },
  amber: {
    bg: "bg-amber-50",
    text: "text-amber-600",
    border: "border-amber-200",
    gradient: "from-amber-500 to-orange-600",
    ring: "ring-amber-500",
    light: "bg-amber-100",
    dark: "bg-amber-600"
  },
  red: {
    bg: "bg-red-50",
    text: "text-red-600",
    border: "border-red-200",
    gradient: "from-red-500 to-rose-600",
    ring: "ring-red-500",
    light: "bg-red-100",
    dark: "bg-red-600"
  },
  blue: {
    bg: "bg-blue-50",
    text: "text-blue-600",
    border: "border-blue-200",
    gradient: "from-blue-500 to-cyan-600",
    ring: "ring-blue-500",
    light: "bg-blue-100",
    dark: "bg-blue-600"
  },
  emerald: {
    bg: "bg-emerald-50",
    text: "text-emerald-600",
    border: "border-emerald-200",
    gradient: "from-emerald-500 to-teal-600",
    ring: "ring-emerald-500",
    light: "bg-emerald-100",
    dark: "bg-emerald-600"
  },
  cyan: {
    bg: "bg-cyan-50",
    text: "text-cyan-600",
    border: "border-cyan-200",
    gradient: "from-cyan-500 to-blue-600",
    ring: "ring-cyan-500",
    light: "bg-cyan-100",
    dark: "bg-cyan-600"
  },
  pink: {
    bg: "bg-pink-50",
    text: "text-pink-600",
    border: "border-pink-200",
    gradient: "from-pink-500 to-rose-600",
    ring: "ring-pink-500",
    light: "bg-pink-100",
    dark: "bg-pink-600"
  },
  gray: {
    bg: "bg-gray-50",
    text: "text-gray-600",
    border: "border-gray-200",
    gradient: "from-gray-500 to-slate-600",
    ring: "ring-gray-500",
    light: "bg-gray-100",
    dark: "bg-gray-600"
  }
};

const VALUE_TYPES = {
  number: { prefix: "", suffix: "", decimals: 0 },
  currency: { prefix: "€", suffix: "", decimals: 2 },
  percentage: { prefix: "", suffix: "%", decimals: 1 },
  count: { prefix: "", suffix: "", decimals: 0 },
  duration: { prefix: "", suffix: "h", decimals: 1 },
  rating: { prefix: "", suffix: "/5", decimals: 1 }
};

const SIZES = {
  xs: {
    container: "gap-2",
    iconContainer: "w-8 h-8",
    icon: "w-4 h-4",
    label: "text-xs",
    value: "text-sm font-semibold",
    change: "text-xs"
  },
  sm: {
    container: "gap-2",
    iconContainer: "w-9 h-9",
    icon: "w-4 h-4",
    label: "text-xs",
    value: "text-base font-bold",
    change: "text-xs"
  },
  md: {
    container: "gap-3",
    iconContainer: "w-10 h-10",
    icon: "w-5 h-5",
    label: "text-sm",
    value: "text-lg font-bold",
    change: "text-xs"
  },
  lg: {
    container: "gap-4",
    iconContainer: "w-12 h-12",
    icon: "w-6 h-6",
    label: "text-sm",
    value: "text-2xl font-bold",
    change: "text-sm"
  },
  xl: {
    container: "gap-4",
    iconContainer: "w-14 h-14",
    icon: "w-7 h-7",
    label: "text-base",
    value: "text-3xl font-bold",
    change: "text-sm"
  }
};

export default function QuickStat({ 
  label,
  value,
  previousValue,
  change,
  changeLabel = "vs last period",
  icon: Icon,
  color = "indigo",
  size = "md",
  valueType = "number",
  format: customFormat,
  target,
  targetLabel = "Target",
  status,
  statusMessage,
  trend,
  trendData = [],
  subtitle,
  description,
  tooltip,
  link,
  linkLabel = "View details",
  onClick,
  onRefresh,
  loading = false,
  error = null,
  animated = true,
  showTrend = true,
  showTarget = false,
  showSparkline = false,
  invertTrend = false,
  compact = false,
  highlighted = false,
  badge,
  badgeColor,
  interactive = true,
  className = ""
}) {
  const [isHovered, setIsHovered] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);
  const [animatedValue, setAnimatedValue] = useState(0);
  const [copied, setCopied] = useState(false);

  const colorScheme = COLOR_SCHEMES[color] || COLOR_SCHEMES.indigo;
  const sizeConfig = SIZES[size] || SIZES.md;
  const valueConfig = VALUE_TYPES[valueType] || VALUE_TYPES.number;

  const calculatedChange = useMemo(() => {
    if (change !== undefined) return change;
    if (previousValue !== undefined && previousValue !== 0) {
      return ((value - previousValue) / Math.abs(previousValue)) * 100;
    }
    return null;
  }, [change, value, previousValue]);

  const trendDirection = useMemo(() => {
    if (calculatedChange === null) return "neutral";
    const isPositive = invertTrend ? calculatedChange < 0 : calculatedChange > 0;
    const isNegative = invertTrend ? calculatedChange > 0 : calculatedChange < 0;
    if (isPositive) return "positive";
    if (isNegative) return "negative";
    return "neutral";
  }, [calculatedChange, invertTrend]);

  const targetProgress = useMemo(() => {
    if (!target || !value) return null;
    return Math.min(100, (value / target) * 100);
  }, [value, target]);

  const formatValue = useCallback((val) => {
    if (val === null || val === undefined) return "—";
    if (customFormat) return customFormat(val);

    const numVal = typeof val === "number" ? val : parseFloat(val) || 0;
    
    if (valueType === "currency") {
      return new Intl.NumberFormat("en-IE", {
        style: "currency",
        currency: "EUR",
        minimumFractionDigits: valueConfig.decimals,
        maximumFractionDigits: valueConfig.decimals
      }).format(numVal);
    }

    const formattedNumber = new Intl.NumberFormat("en-IE", {
      minimumFractionDigits: valueConfig.decimals,
      maximumFractionDigits: valueConfig.decimals
    }).format(numVal);

    return `${valueConfig.prefix}${formattedNumber}${valueConfig.suffix}`;
  }, [valueType, valueConfig, customFormat]);

  const formatCompactValue = useCallback((val) => {
    if (val === null || val === undefined) return "—";
    
    const numVal = typeof val === "number" ? val : parseFloat(val) || 0;
    const absVal = Math.abs(numVal);
    
    if (absVal >= 1000000) {
      return `${valueConfig.prefix}${(numVal / 1000000).toFixed(1)}M${valueConfig.suffix}`;
    }
    if (absVal >= 1000) {
      return `${valueConfig.prefix}${(numVal / 1000).toFixed(1)}K${valueConfig.suffix}`;
    }
    
    return formatValue(numVal);
  }, [formatValue, valueConfig]);

  useEffect(() => {
    if (loading || !animated) {
      setAnimatedValue(typeof value === "number" ? value : parseFloat(value) || 0);
      return;
    }
    
    const endValue = typeof value === "number" ? value : parseFloat(value) || 0;
    const duration = 800;
    const startTime = Date.now();
    const startValue = 0;

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      
      setAnimatedValue(startValue + (endValue - startValue) * easeProgress);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [value, loading, animated]);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(formatValue(value));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [value, formatValue]);

  const renderTrendIndicator = () => {
    if (!showTrend || calculatedChange === null) return null;

    const TrendIcon = trendDirection === "positive" ? TrendingUp :
                     trendDirection === "negative" ? TrendingDown : Minus;
    
    const trendColorClass = trendDirection === "positive" ? "text-green-600 bg-green-50" :
                          trendDirection === "negative" ? "text-red-600 bg-red-50" :
                          "text-gray-500 bg-gray-50";

    return (
      <div className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded ${trendColorClass} ${sizeConfig.change}`}>
        <TrendIcon className="w-3 h-3" />
        <span className="font-medium tabular-nums">
          {calculatedChange > 0 ? "+" : ""}{calculatedChange.toFixed(1)}%
        </span>
      </div>
    );
  };

  const renderSparkline = () => {
    if (!showSparkline || !trendData || trendData.length < 2) return null;

    const width = 60;
    const height = 20;
    const maxVal = Math.max(...trendData);
    const minVal = Math.min(...trendData);
    const range = maxVal - minVal || 1;

    const points = trendData.map((val, i) => {
      const x = (i / (trendData.length - 1)) * width;
      const y = height - ((val - minVal) / range) * (height - 4) - 2;
      return `${x},${y}`;
    }).join(" ");

    const strokeColor = trendDirection === "positive" ? "#10b981" :
                       trendDirection === "negative" ? "#ef4444" :
                       "#6b7280";

    return (
      <svg width={width} height={height} className="flex-shrink-0">
        <polyline
          fill="none"
          stroke={strokeColor}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={points}
        />
      </svg>
    );
  };

  const renderTargetProgress = () => {
    if (!showTarget || !target || targetProgress === null) return null;

    const progressColor = targetProgress >= 100 ? "bg-green-500" :
                         targetProgress >= 75 ? "bg-blue-500" :
                         targetProgress >= 50 ? "bg-amber-500" :
                         "bg-red-500";

    return (
      <div className="mt-2">
        <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
          <span>{targetLabel}</span>
          <span>{targetProgress.toFixed(0)}%</span>
        </div>
        <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
          <div 
            className={`h-full ${progressColor} rounded-full transition-all duration-500`}
            style={{ width: `${Math.min(100, targetProgress)}%` }}
          />
        </div>
      </div>
    );
  };

  if (error) {
    return (
      <div className={`flex items-center ${sizeConfig.container} ${className}`}>
        <div className={`${sizeConfig.iconContainer} bg-red-50 rounded-lg flex items-center justify-center`}>
          <AlertCircle className={`${sizeConfig.icon} text-red-500`} />
        </div>
        <div>
          <p className={`${sizeConfig.label} text-gray-600`}>{label}</p>
          <p className="text-sm text-red-600">Error loading data</p>
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`
        relative flex items-center ${sizeConfig.container}
        ${interactive && onClick ? "cursor-pointer" : ""}
        ${highlighted ? `ring-2 ${colorScheme.ring} ring-offset-2 rounded-lg p-2` : ""}
        ${className}
      `}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
    >
      {Icon && (
        <div className={`
          ${sizeConfig.iconContainer} rounded-xl flex items-center justify-center flex-shrink-0
          ${compact ? colorScheme.bg : colorScheme.dark}
          ${compact ? colorScheme.text : "text-white"}
          transition-transform duration-200
          ${isHovered && interactive ? "scale-105" : ""}
        `}>
          {loading ? (
            <Loader2 className={`${sizeConfig.icon} animate-spin`} />
          ) : (
            <Icon className={sizeConfig.icon} />
          )}
        </div>
      )}

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className={`${sizeConfig.label} text-gray-600 truncate`}>{label}</p>
          {badge && (
            <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${colorScheme.light} ${colorScheme.text}`}>
              {badge}
            </span>
          )}
          {tooltip && (
            <button
              onMouseEnter={() => setShowTooltip(true)}
              onMouseLeave={() => setShowTooltip(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          {loading ? (
            <div className={`h-6 w-20 bg-gray-200 animate-pulse rounded`} />
          ) : (
            <p className={`${sizeConfig.value} text-gray-900 tabular-nums truncate`}>
              {compact ? formatCompactValue(animatedValue) : formatValue(animatedValue)}
            </p>
          )}
          
          {renderSparkline()}
        </div>

        {subtitle && (
          <p className="text-xs text-gray-500 mt-0.5">{subtitle}</p>
        )}

        <div className="flex items-center gap-2 mt-1 flex-wrap">
          {renderTrendIndicator()}
          
          {changeLabel && calculatedChange !== null && (
            <span className="text-xs text-gray-500">{changeLabel}</span>
          )}

          {status && (
            <span className={`
              inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-medium
              ${status === "success" ? "bg-green-50 text-green-700" :
                status === "warning" ? "bg-amber-50 text-amber-700" :
                status === "error" ? "bg-red-50 text-red-700" :
                "bg-blue-50 text-blue-700"}
            `}>
              {status === "success" && <CheckCircle className="w-3 h-3" />}
              {status === "warning" && <AlertTriangle className="w-3 h-3" />}
              {status === "error" && <AlertCircle className="w-3 h-3" />}
              {statusMessage || status}
            </span>
          )}
        </div>

        {renderTargetProgress()}

        {link && (
          <a 
            href={link}
            className={`inline-flex items-center gap-1 text-xs ${colorScheme.text} hover:underline mt-1`}
            onClick={(e) => e.stopPropagation()}
          >
            {linkLabel}
            <ChevronRight className="w-3 h-3" />
          </a>
        )}
      </div>

      {interactive && isHovered && !compact && (
        <div className="flex items-center gap-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleCopy();
            }}
            className="p-1 hover:bg-gray-100 rounded transition"
            title={copied ? "Copied!" : "Copy value"}
          >
            <Copy className="w-3.5 h-3.5 text-gray-400" />
          </button>
          {onRefresh && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRefresh();
              }}
              className="p-1 hover:bg-gray-100 rounded transition"
              title="Refresh"
            >
              <RefreshCw className="w-3.5 h-3.5 text-gray-400" />
            </button>
          )}
        </div>
      )}

      {showTooltip && tooltip && (
        <div className="absolute bottom-full left-0 mb-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10 max-w-xs">
          {tooltip}
          <div className="absolute top-full left-4 -mt-1 border-4 border-transparent border-t-gray-900" />
        </div>
      )}
    </div>
  );
}

export function QuickStatCard({
  label,
  value,
  icon: Icon,
  color = "indigo",
  change,
  previousValue,
  target,
  trendData = [],
  description,
  onClick,
  loading = false,
  className = ""
}) {
  const colorScheme = COLOR_SCHEMES[color] || COLOR_SCHEMES.indigo;

  const calculatedChange = useMemo(() => {
    if (change !== undefined) return change;
    if (previousValue !== undefined && previousValue !== 0) {
      return ((value - previousValue) / Math.abs(previousValue)) * 100;
    }
    return null;
  }, [change, value, previousValue]);

  const trendDirection = calculatedChange !== null && calculatedChange !== 0
    ? calculatedChange > 0 ? "positive" : "negative"
    : "neutral";

  return (
    <div 
      className={`
        bg-white rounded-2xl p-5 border border-gray-200 
        hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200
        ${onClick ? "cursor-pointer" : ""}
        ${className}
      `}
      onClick={onClick}
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`w-12 h-12 bg-gradient-to-br ${colorScheme.gradient} rounded-xl flex items-center justify-center`}>
          {loading ? (
            <Loader2 className="w-6 h-6 text-white animate-spin" />
          ) : Icon ? (
            <Icon className="w-6 h-6 text-white" />
          ) : null}
        </div>

        {calculatedChange !== null && (
          <div className={`
            flex items-center gap-1 px-2 py-1 rounded-lg text-sm font-medium
            ${trendDirection === "positive" ? "bg-green-50 text-green-600" :
              trendDirection === "negative" ? "bg-red-50 text-red-600" :
              "bg-gray-50 text-gray-600"}
          `}>
            {trendDirection === "positive" ? <ArrowUpRight className="w-4 h-4" /> :
             trendDirection === "negative" ? <ArrowDownRight className="w-4 h-4" /> :
             <Minus className="w-4 h-4" />}
            {Math.abs(calculatedChange).toFixed(1)}%
          </div>
        )}
      </div>

      <div>
        <p className="text-sm text-gray-600 mb-1">{label}</p>
        {loading ? (
          <div className="h-8 w-24 bg-gray-200 animate-pulse rounded" />
        ) : (
          <p className="text-2xl font-bold text-gray-900 tabular-nums">{value}</p>
        )}
        {description && (
          <p className="text-xs text-gray-500 mt-1">{description}</p>
        )}
      </div>

      {trendData.length > 1 && (
        <div className="mt-4 h-8">
          <MiniSparkline data={trendData} color={color} />
        </div>
      )}

      {target && (
        <div className="mt-3">
          <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
            <span>Target</span>
            <span>{Math.min(100, (value / target) * 100).toFixed(0)}%</span>
          </div>
          <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
            <div 
              className={`h-full bg-gradient-to-r ${colorScheme.gradient} rounded-full`}
              style={{ width: `${Math.min(100, (value / target) * 100)}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
}

export function QuickStatRow({ stats = [], className = "" }) {
  return (
    <div className={`flex items-center divide-x divide-gray-200 ${className}`}>
      {stats.map((stat, index) => (
        <div key={index} className={`flex-1 ${index > 0 ? "pl-4" : ""} ${index < stats.length - 1 ? "pr-4" : ""}`}>
          <QuickStat
            {...stat}
            size="sm"
            compact
          />
        </div>
      ))}
    </div>
  );
}

export function QuickStatGrid({ stats = [], columns = 4, className = "" }) {
  return (
    <div className={`grid grid-cols-2 md:grid-cols-${columns} gap-4 ${className}`}>
      {stats.map((stat, index) => (
        <QuickStatCard key={index} {...stat} />
      ))}
    </div>
  );
}

function MiniSparkline({ data, color = "indigo", height = 32 }) {
  const colorScheme = COLOR_SCHEMES[color] || COLOR_SCHEMES.indigo;
  
  if (!data || data.length < 2) return null;

  const width = 100;
  const maxVal = Math.max(...data);
  const minVal = Math.min(...data);
  const range = maxVal - minVal || 1;
  const padding = 2;

  const points = data.map((val, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - padding - ((val - minVal) / range) * (height - padding * 2);
    return `${x},${y}`;
  }).join(" ");

  const areaPath = `M0,${height} L${points} L${width},${height} Z`;

  const gradientId = `sparkline-gradient-${Math.random().toString(36).substr(2, 9)}`;

  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id={gradientId} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor={color === "green" ? "#10b981" : color === "red" ? "#ef4444" : "#6366f1"} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color === "green" ? "#10b981" : color === "red" ? "#ef4444" : "#6366f1"} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path
        d={areaPath}
        fill={`url(#${gradientId})`}
      />
      <polyline
        fill="none"
        stroke={color === "green" ? "#10b981" : color === "red" ? "#ef4444" : "#6366f1"}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={points}
      />
    </svg>
  );
}

export function QuickStatSkeleton({ size = "md", showIcon = true }) {
  const sizeConfig = SIZES[size] || SIZES.md;

  return (
    <div className={`flex items-center ${sizeConfig.container} animate-pulse`}>
      {showIcon && (
        <div className={`${sizeConfig.iconContainer} bg-gray-200 rounded-xl`} />
      )}
      <div className="flex-1">
        <div className="h-4 w-20 bg-gray-200 rounded mb-2" />
        <div className="h-6 w-28 bg-gray-200 rounded" />
      </div>
    </div>
  );
}