import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Info,
  MoreVertical,
  Maximize2,
  Download,
  RefreshCw,
  Eye,
  EyeOff,
  ChevronUp,
  ChevronDown,
  ArrowUpRight,
  ArrowDownRight,
  Target,
  AlertCircle,
  CheckCircle,
  Clock,
  Calendar,
  DollarSign,
  Users,
  Car,
  Award,
  Zap,
  Activity,
  BarChart3,
  PieChart,
  LineChart as LineChartIcon,
  Loader2,
  Star,
  Flag,
  Bell,
  Settings,
  ExternalLink,
  Copy,
  Share2
} from "lucide-react";
import { format, subDays, differenceInDays, parseISO, isWithinInterval } from "date-fns";

const METRIC_TYPES = {
  currency: { prefix: "€", suffix: "", decimals: 2 },
  percentage: { prefix: "", suffix: "%", decimals: 1 },
  number: { prefix: "", suffix: "", decimals: 0 },
  count: { prefix: "", suffix: "", decimals: 0 },
  duration: { prefix: "", suffix: " hrs", decimals: 1 },
  rating: { prefix: "", suffix: "/5", decimals: 1 }
};

const TREND_COLORS = {
  positive: {
    text: "text-green-600",
    bg: "bg-green-50",
    border: "border-green-200",
    gradient: "from-green-500 to-emerald-500"
  },
  negative: {
    text: "text-red-600",
    bg: "bg-red-50",
    border: "border-red-200",
    gradient: "from-red-500 to-rose-500"
  },
  neutral: {
    text: "text-gray-500",
    bg: "bg-gray-50",
    border: "border-gray-200",
    gradient: "from-gray-400 to-gray-500"
  },
  warning: {
    text: "text-amber-600",
    bg: "bg-amber-50",
    border: "border-amber-200",
    gradient: "from-amber-500 to-orange-500"
  }
};

const ANIMATION_VARIANTS = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { 
    opacity: 1, 
    y: 0, 
    scale: 1,
    transition: { duration: 0.3, ease: "easeOut" }
  },
  hover: { 
    y: -2, 
    boxShadow: "0 10px 40px -10px rgba(0,0,0,0.1)",
    transition: { duration: 0.2 }
  }
};

export default function MetricCard({ 
  title,
  value,
  previousValue,
  change,
  changeType = "percentage",
  metricType = "number",
  sparklineData = [],
  historicalData = [],
  icon: Icon,
  iconColor = "indigo",
  loading = false,
  error = null,
  subtitle,
  description,
  target,
  targetLabel = "Target",
  status,
  statusMessage,
  trend,
  comparisonPeriod = "vs last period",
  format: customFormat,
  onClick,
  onRefresh,
  onExpand,
  onExport,
  showSparkline = true,
  showTrend = true,
  showTarget = true,
  showComparison = true,
  compact = false,
  highlighted = false,
  invertTrend = false,
  animationDelay = 0,
  className = "",
  actions = [],
  badge,
  alerts = [],
  insights = [],
  interactive = true,
  refreshInterval,
  lastUpdated,
  dataSource,
  children
}) {
  const [isHovered, setIsHovered] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [animatedValue, setAnimatedValue] = useState(0);
  const [copied, setCopied] = useState(false);
  const menuRef = useRef(null);
  const cardRef = useRef(null);

  const calculatedChange = useMemo(() => {
    if (change !== undefined) return change;
    if (previousValue !== undefined && previousValue !== 0) {
      return ((value - previousValue) / Math.abs(previousValue)) * 100;
    }
    return null;
  }, [change, value, previousValue]);

  const trendDirection = useMemo(() => {
    if (calculatedChange === null) return "neutral";
    const isPositive = invertTrend ? calculatedChange < 0 : calculatedChange > 0;
    const isNegative = invertTrend ? calculatedChange > 0 : calculatedChange < 0;
    if (isPositive) return "positive";
    if (isNegative) return "negative";
    return "neutral";
  }, [calculatedChange, invertTrend]);

  const trendColors = TREND_COLORS[trendDirection];

  const targetProgress = useMemo(() => {
    if (!target || !value) return null;
    return (value / target) * 100;
  }, [value, target]);

  const targetStatus = useMemo(() => {
    if (!targetProgress) return null;
    if (targetProgress >= 100) return "achieved";
    if (targetProgress >= 90) return "close";
    if (targetProgress >= 70) return "onTrack";
    return "behind";
  }, [targetProgress]);

  const formatValue = useCallback((val, type = metricType) => {
    if (val === null || val === undefined) return "—";
    if (customFormat) return customFormat(val);

    const config = METRIC_TYPES[type] || METRIC_TYPES.number;
    const formattedNumber = new Intl.NumberFormat("en-IE", {
      minimumFractionDigits: config.decimals,
      maximumFractionDigits: config.decimals
    }).format(val);

    return `${config.prefix}${formattedNumber}${config.suffix}`;
  }, [metricType, customFormat]);

  const formatCompactValue = useCallback((val) => {
    if (val === null || val === undefined) return "—";
    
    const absVal = Math.abs(val);
    if (absVal >= 1000000) {
      return `${(val / 1000000).toFixed(1)}M`;
    }
    if (absVal >= 1000) {
      return `${(val / 1000).toFixed(1)}K`;
    }
    return val.toFixed(0);
  }, []);

  useEffect(() => {
    if (loading || !value) return;
    
    const duration = 1000;
    const startTime = Date.now();
    const startValue = 0;
    const endValue = typeof value === "number" ? value : parseFloat(value) || 0;

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      
      setAnimatedValue(startValue + (endValue - startValue) * easeProgress);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [value, loading]);

  useEffect(() => {
    if (!refreshInterval || !onRefresh) return;

    const interval = setInterval(() => {
      handleRefresh();
    }, refreshInterval);

    return () => clearInterval(interval);
  }, [refreshInterval, onRefresh]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowMenu(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleRefresh = useCallback(async () => {
    if (!onRefresh || isRefreshing) return;
    
    setIsRefreshing(true);
    try {
      await onRefresh();
    } finally {
      setIsRefreshing(false);
    }
  }, [onRefresh, isRefreshing]);

  const handleCopyValue = useCallback(() => {
    navigator.clipboard.writeText(formatValue(value));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [value, formatValue]);

  const handleExport = useCallback(() => {
    if (onExport) {
      onExport({
        title,
        value,
        change: calculatedChange,
        sparklineData,
        historicalData
      });
    }
  }, [onExport, title, value, calculatedChange, sparklineData, historicalData]);

  const generateSparklinePath = useCallback((data, width = 100, height = 30) => {
    if (!data || data.length < 2) return "";

    const maxVal = Math.max(...data);
    const minVal = Math.min(...data);
    const range = maxVal - minVal || 1;
    const padding = 2;

    const points = data.map((val, i) => {
      const x = (i / (data.length - 1)) * width;
      const y = height - padding - ((val - minVal) / range) * (height - padding * 2);
      return `${x},${y}`;
    });

    return points.join(" ");
  }, []);

  const generateAreaPath = useCallback((data, width = 100, height = 30) => {
    if (!data || data.length < 2) return "";

    const linePath = generateSparklinePath(data, width, height);
    return `M0,${height} L${linePath} L${width},${height} Z`;
  }, [generateSparklinePath]);

  const TrendIcon = trendDirection === "positive" ? TrendingUp : 
                   trendDirection === "negative" ? TrendingDown : Minus;

  const StatusIcon = status === "success" ? CheckCircle :
                    status === "warning" ? AlertCircle :
                    status === "error" ? AlertCircle :
                    status === "info" ? Info : null;

  const renderSparkline = () => {
    if (!showSparkline || !sparklineData || sparklineData.length < 2) return null;

    const width = 120;
    const height = compact ? 24 : 32;
    const gradientId = `sparkline-gradient-${title?.replace(/\s+/g, "-").toLowerCase()}`;

    return (
      <div className={`${compact ? "mt-2" : "mt-4"}`}>
        <svg 
          viewBox={`0 0 ${width} ${height}`} 
          className="w-full h-8"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={trendDirection === "positive" ? "#10b981" : trendDirection === "negative" ? "#ef4444" : "#6366f1"} />
              <stop offset="100%" stopColor={trendDirection === "positive" ? "#34d399" : trendDirection === "negative" ? "#f87171" : "#a855f7"} />
            </linearGradient>
            <linearGradient id={`${gradientId}-fill`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={trendDirection === "positive" ? "#10b981" : trendDirection === "negative" ? "#ef4444" : "#6366f1"} stopOpacity="0.2" />
              <stop offset="100%" stopColor={trendDirection === "positive" ? "#10b981" : trendDirection === "negative" ? "#ef4444" : "#6366f1"} stopOpacity="0" />
            </linearGradient>
          </defs>
          
          <path
            d={generateAreaPath(sparklineData, width, height)}
            fill={`url(#${gradientId}-fill)`}
          />
          
          <polyline
            fill="none"
            stroke={`url(#${gradientId})`}
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            points={generateSparklinePath(sparklineData, width, height)}
          />
          
          {sparklineData.length > 0 && (
            <circle
              cx={width}
              cy={height - 2 - ((sparklineData[sparklineData.length - 1] - Math.min(...sparklineData)) / (Math.max(...sparklineData) - Math.min(...sparklineData) || 1)) * (height - 4)}
              r="3"
              fill={trendDirection === "positive" ? "#10b981" : trendDirection === "negative" ? "#ef4444" : "#6366f1"}
              className="animate-pulse"
            />
          )}
        </svg>
      </div>
    );
  };

  const renderTargetProgress = () => {
    if (!showTarget || !target || targetProgress === null) return null;

    const statusColors = {
      achieved: { bar: "bg-green-500", text: "text-green-600", bg: "bg-green-50" },
      close: { bar: "bg-blue-500", text: "text-blue-600", bg: "bg-blue-50" },
      onTrack: { bar: "bg-amber-500", text: "text-amber-600", bg: "bg-amber-50" },
      behind: { bar: "bg-red-500", text: "text-red-600", bg: "bg-red-50" }
    };

    const colors = statusColors[targetStatus] || statusColors.onTrack;

    return (
      <div className={`${compact ? "mt-2" : "mt-4"}`}>
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-gray-500">{targetLabel}</span>
          <span className={`text-xs font-medium ${colors.text}`}>
            {targetProgress.toFixed(0)}%
          </span>
        </div>
        <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
          <div 
            className={`h-full ${colors.bar} rounded-full transition-all duration-500`}
            style={{ width: `${Math.min(100, targetProgress)}%` }}
          />
        </div>
        <div className="flex items-center justify-between mt-1">
          <span className="text-xs text-gray-400">0</span>
          <span className="text-xs text-gray-400">{formatCompactValue(target)}</span>
        </div>
      </div>
    );
  };

  const renderAlerts = () => {
    if (!alerts || alerts.length === 0) return null;

    return (
      <div className="mt-3 space-y-1">
        {alerts.slice(0, 2).map((alert, index) => (
          <div 
            key={index}
            className={`flex items-center gap-2 px-2 py-1 rounded-lg text-xs ${
              alert.type === "warning" ? "bg-amber-50 text-amber-700" :
              alert.type === "error" ? "bg-red-50 text-red-700" :
              alert.type === "success" ? "bg-green-50 text-green-700" :
              "bg-blue-50 text-blue-700"
            }`}
          >
            <Bell className="w-3 h-3 flex-shrink-0" />
            <span className="truncate">{alert.message}</span>
          </div>
        ))}
      </div>
    );
  };

  const renderInsights = () => {
    if (!insights || insights.length === 0 || !showDetails) return null;

    return (
      <div className="mt-4 pt-4 border-t border-gray-100">
        <p className="text-xs font-medium text-gray-500 mb-2">Insights</p>
        <div className="space-y-2">
          {insights.map((insight, index) => (
            <div key={index} className="flex items-start gap-2 text-xs text-gray-600">
              <Zap className="w-3 h-3 text-amber-500 flex-shrink-0 mt-0.5" />
              <span>{insight}</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderMenu = () => {
    if (!showMenu) return null;

    const menuItems = [
      { icon: Maximize2, label: "Expand", onClick: onExpand, show: !!onExpand },
      { icon: RefreshCw, label: "Refresh", onClick: handleRefresh, show: !!onRefresh },
      { icon: Download, label: "Export", onClick: handleExport, show: !!onExport },
      { icon: Copy, label: copied ? "Copied!" : "Copy Value", onClick: handleCopyValue, show: true },
      { icon: showDetails ? EyeOff : Eye, label: showDetails ? "Hide Details" : "Show Details", onClick: () => setShowDetails(!showDetails), show: true },
      ...actions
    ].filter(item => item.show);

    return (
      <div 
        ref={menuRef}
        className="absolute right-0 top-8 w-44 bg-white rounded-xl shadow-lg border border-gray-200 py-1 z-50"
      >
        {menuItems.map((item, index) => (
          <button
            key={index}
            onClick={(e) => {
              e.stopPropagation();
              item.onClick?.();
              if (item.label !== "Copy Value" && item.label !== "Copied!") {
                setShowMenu(false);
              }
            }}
            className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 transition"
          >
            <item.icon className="w-4 h-4 text-gray-400" />
            {item.label}
          </button>
        ))}
      </div>
    );
  };

  if (error) {
    return (
      <div 
        className={`bg-white rounded-2xl p-6 border border-red-200 ${className}`}
      >
        <div className="flex items-center gap-3 text-red-600">
          <AlertCircle className="w-5 h-5" />
          <div>
            <p className="font-medium">{title}</p>
            <p className="text-sm text-red-500">{error}</p>
          </div>
        </div>
        {onRefresh && (
          <button
            onClick={handleRefresh}
            className="mt-3 text-sm text-red-600 hover:text-red-700 flex items-center gap-1"
          >
            <RefreshCw className="w-4 h-4" />
            Try again
          </button>
        )}
      </div>
    );
  }

  return (
    <div
      ref={cardRef}
      className={`
        relative bg-white rounded-2xl border transition-all duration-300
        ${compact ? "p-4" : "p-6"}
        ${highlighted ? "border-indigo-300 ring-2 ring-indigo-100" : "border-gray-200"}
        ${interactive && !loading ? "hover:shadow-lg hover:-translate-y-0.5 cursor-pointer" : ""}
        ${className}
      `}
      style={{
        animationDelay: `${animationDelay}ms`
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => interactive && onClick?.()}
    >
      {badge && (
        <div className="absolute -top-2 -right-2">
          <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${badge.color || "bg-indigo-100 text-indigo-700"}`}>
            {badge.label}
          </span>
        </div>
      )}

      <div className="flex items-start justify-between mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className={`font-medium text-gray-600 truncate ${compact ? "text-xs" : "text-sm"}`}>
              {title}
            </p>
            {description && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowDetails(!showDetails);
                }}
                className="text-gray-400 hover:text-gray-600 transition"
              >
                <Info className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          
          {loading ? (
            <div className={`${compact ? "h-6 w-20" : "h-9 w-32"} bg-gray-200 animate-pulse rounded mt-1`} />
          ) : (
            <p className={`font-bold text-gray-900 tabular-nums ${compact ? "text-xl" : "text-3xl"}`}>
              {formatValue(typeof value === "number" ? animatedValue : value)}
            </p>
          )}
          
          {subtitle && !loading && (
            <p className="text-xs text-gray-500 mt-1">{subtitle}</p>
          )}
        </div>

        <div className="flex items-start gap-2">
          {Icon && (
            <div className={`${compact ? "w-10 h-10" : "w-12 h-12"} ${
              iconColor === 'indigo' ? 'bg-gradient-to-br from-indigo-50 to-indigo-100' :
              iconColor === 'green' ? 'bg-gradient-to-br from-green-50 to-green-100' :
              iconColor === 'red' ? 'bg-gradient-to-br from-red-50 to-red-100' :
              iconColor === 'amber' ? 'bg-gradient-to-br from-amber-50 to-amber-100' :
              iconColor === 'purple' ? 'bg-gradient-to-br from-purple-50 to-purple-100' :
              'bg-gradient-to-br from-blue-50 to-blue-100'
            } rounded-xl flex items-center justify-center flex-shrink-0`}>
              <Icon className={`${compact ? "w-5 h-5" : "w-6 h-6"} ${
                iconColor === 'indigo' ? 'text-indigo-600' :
                iconColor === 'green' ? 'text-green-600' :
                iconColor === 'red' ? 'text-red-600' :
                iconColor === 'amber' ? 'text-amber-600' :
                iconColor === 'purple' ? 'text-purple-600' :
                'text-blue-600'
              }`} />
            </div>
          )}
          
          {interactive && (isHovered || showMenu) && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowMenu(!showMenu);
              }}
              className="p-1 hover:bg-gray-100 rounded-lg transition"
            >
              <MoreVertical className="w-4 h-4 text-gray-400" />
            </button>
          )}
        </div>

        {renderMenu()}
      </div>

      {showDetails && description && (
        <p className="text-xs text-gray-500 mb-3 pb-3 border-b border-gray-100">
          {description}
        </p>
      )}

      {showTrend && calculatedChange !== null && !loading && (
        <div className="flex items-center gap-3 flex-wrap">
          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg ${trendColors.bg}`}>
            <TrendIcon className={`w-3.5 h-3.5 ${trendColors.text}`} />
            <span className={`text-sm font-semibold tabular-nums ${trendColors.text}`}>
              {calculatedChange > 0 ? "+" : ""}{calculatedChange.toFixed(1)}%
            </span>
          </div>
          
          {showComparison && (
            <span className="text-xs text-gray-500">{comparisonPeriod}</span>
          )}
          
          {status && StatusIcon && (
            <div className={`flex items-center gap-1 text-xs ${
              status === "success" ? "text-green-600" :
              status === "warning" ? "text-amber-600" :
              status === "error" ? "text-red-600" :
              "text-blue-600"
            }`}>
              <StatusIcon className="w-3.5 h-3.5" />
              {statusMessage}
            </div>
          )}
        </div>
      )}

      {renderSparkline()}
      {renderTargetProgress()}
      {renderAlerts()}
      {renderInsights()}

      {children}

      {lastUpdated && (
        <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-400">
          <span>Updated {format(new Date(lastUpdated), "MMM d, h:mm a")}</span>
          {dataSource && <span>{dataSource}</span>}
        </div>
      )}

      {isRefreshing && (
        <div className="absolute inset-0 bg-white/80 rounded-2xl flex items-center justify-center">
          <Loader2 className="w-6 h-6 text-indigo-600 animate-spin" />
        </div>
      )}
    </div>
  );
}

export function MetricCardGrid({ 
  children, 
  columns = 4,
  gap = 4,
  className = "" 
}) {
  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-${columns} gap-${gap} ${className}`}>
      {children}
    </div>
  );
}

export function MetricCardSkeleton({ compact = false }) {
  return (
    <div className={`bg-white rounded-2xl border border-gray-200 ${compact ? "p-4" : "p-6"}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="h-4 w-24 bg-gray-200 animate-pulse rounded mb-2" />
          <div className={`${compact ? "h-6 w-20" : "h-9 w-32"} bg-gray-200 animate-pulse rounded`} />
        </div>
        <div className={`${compact ? "w-10 h-10" : "w-12 h-12"} bg-gray-200 animate-pulse rounded-xl`} />
      </div>
      <div className="h-6 w-28 bg-gray-200 animate-pulse rounded" />
      <div className="mt-4 h-8 w-full bg-gray-200 animate-pulse rounded" />
    </div>
  );
}

export function MetricComparison({
  metrics = [],
  title = "Comparison",
  className = ""
}) {
  if (metrics.length === 0) return null;

  const maxValue = Math.max(...metrics.map(m => m.value || 0));

  return (
    <div className={`bg-white rounded-2xl border border-gray-200 p-6 ${className}`}>
      <h4 className="font-semibold text-gray-900 mb-4">{title}</h4>
      <div className="space-y-4">
        {metrics.map((metric, index) => (
          <div key={index}>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-gray-600">{metric.label}</span>
              <span className="text-sm font-semibold text-gray-900">{metric.formattedValue || metric.value}</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-500 ${metric.color || "bg-indigo-500"}`}
                style={{ width: `${(metric.value / maxValue) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}