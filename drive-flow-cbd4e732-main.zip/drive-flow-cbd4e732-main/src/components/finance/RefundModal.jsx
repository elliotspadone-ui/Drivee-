import React, { useState, useEffect, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  X, 
  AlertCircle, 
  DollarSign,
  RotateCcw,
  CreditCard,
  Banknote,
  Building2,
  Wallet,
  CheckCircle,
  Clock,
  AlertTriangle,
  Info,
  FileText,
  User,
  Calendar,
  Hash,
  Loader2,
  ChevronDown,
  ChevronUp,
  Shield,
  Lock,
  Eye,
  EyeOff,
  Send,
  Mail,
  Phone,
  MessageSquare,
  Receipt,
  ArrowRight,
  History,
  RefreshCw,
  Percent,
  Tag
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

const REFUND_REASONS = [
  { id: "customer_request", label: "Customer Request", description: "Refund requested by the customer" },
  { id: "service_issue", label: "Service Issue", description: "Problem with the service provided" },
  { id: "double_charge", label: "Double Charge", description: "Customer was charged twice" },
  { id: "cancellation", label: "Lesson Cancellation", description: "Lesson was cancelled" },
  { id: "schedule_conflict", label: "Schedule Conflict", description: "Unable to accommodate schedule" },
  { id: "instructor_unavailable", label: "Instructor Unavailable", description: "Instructor could not fulfill booking" },
  { id: "weather", label: "Weather Conditions", description: "Unsafe weather conditions" },
  { id: "vehicle_issue", label: "Vehicle Issue", description: "Vehicle breakdown or unavailability" },
  { id: "medical", label: "Medical Reasons", description: "Student medical issues" },
  { id: "dissatisfaction", label: "Customer Dissatisfaction", description: "Customer unhappy with service" },
  { id: "error", label: "Billing Error", description: "Incorrect charge amount" },
  { id: "other", label: "Other", description: "Other reason (specify below)" }
];

const REFUND_METHODS = [
  { id: "original", label: "Original Payment Method", icon: RefreshCw, description: "Refund to the same payment method" },
  { id: "card", label: "Credit/Debit Card", icon: CreditCard, description: "Refund to card on file" },
  { id: "bank", label: "Bank Transfer", icon: Building2, description: "Direct bank transfer" },
  { id: "cash", label: "Cash", icon: Banknote, description: "Cash refund in person" },
  { id: "credit", label: "Store Credit", icon: Wallet, description: "Credit for future services" }
];

const NOTIFICATION_OPTIONS = [
  { id: "email", label: "Email", icon: Mail },
  { id: "sms", label: "SMS", icon: Phone },
  { id: "both", label: "Both", icon: MessageSquare },
  { id: "none", label: "No notification", icon: EyeOff }
];

export default function RefundModal({ 
  payment, 
  onClose, 
  onRefund, 
  student,
  instructor,
  booking,
  invoice,
  previousRefunds = [],
  canProcessRefund = true,
  requiresApproval = false,
  maxRefundAmount,
  isProcessing = false
}) {
  const [refundAmount, setRefundAmount] = useState(0);
  const [refundReason, setRefundReason] = useState("");
  const [customReason, setCustomReason] = useState("");
  const [refundType, setRefundType] = useState("full");
  const [refundMethod, setRefundMethod] = useState("original");
  const [notifyCustomer, setNotifyCustomer] = useState("email");
  const [internalNotes, setInternalNotes] = useState("");
  const [confirmRefund, setConfirmRefund] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [errors, setErrors] = useState({});
  const [step, setStep] = useState(1);

  const totalPreviousRefunds = useMemo(() => {
    return previousRefunds.reduce((sum, r) => sum + (r.amount || r.refund_amount || 0), 0);
  }, [previousRefunds]);

  const availableRefundAmount = useMemo(() => {
    const maxAllowed = maxRefundAmount ?? (payment?.amount || 0);
    return Math.max(0, maxAllowed - totalPreviousRefunds);
  }, [payment, maxRefundAmount, totalPreviousRefunds]);

  const isFullyRefunded = useMemo(() => {
    return availableRefundAmount <= 0;
  }, [availableRefundAmount]);

  useEffect(() => {
    if (payment?.amount) {
      setRefundAmount(availableRefundAmount);
    }
  }, [payment, availableRefundAmount]);

  useEffect(() => {
    if (refundType === "full") {
      setRefundAmount(availableRefundAmount);
    }
  }, [refundType, availableRefundAmount]);

  const validateForm = useCallback(() => {
    const newErrors = {};

    if (!refundReason) {
      newErrors.reason = "Please select a refund reason";
    }

    if (refundReason === "other" && !customReason.trim()) {
      newErrors.customReason = "Please provide details for the refund reason";
    }

    if (refundType === "partial") {
      if (!refundAmount || refundAmount <= 0) {
        newErrors.amount = "Please enter a valid refund amount";
      } else if (refundAmount > availableRefundAmount) {
        newErrors.amount = `Maximum refundable amount is €${availableRefundAmount.toFixed(2)}`;
      }
    }

    if (step === 2 && !confirmRefund) {
      newErrors.confirm = "Please confirm the refund details";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [refundReason, customReason, refundType, refundAmount, availableRefundAmount, step, confirmRefund]);

  const handleAmountChange = useCallback((value) => {
    const numValue = parseFloat(value) || 0;
    setRefundAmount(Math.min(Math.max(0, numValue), availableRefundAmount));
    if (errors.amount) {
      setErrors(prev => ({ ...prev, amount: null }));
    }
  }, [availableRefundAmount, errors]);

  const handlePercentageClick = useCallback((percentage) => {
    const amount = (availableRefundAmount * percentage) / 100;
    setRefundAmount(Math.round(amount * 100) / 100);
  }, [availableRefundAmount]);

  const handleNextStep = useCallback(() => {
    if (validateForm()) {
      setStep(2);
    }
  }, [validateForm]);

  const handlePreviousStep = useCallback(() => {
    setStep(1);
    setConfirmRefund(false);
  }, []);

  const handleSubmit = useCallback(async () => {
    if (!validateForm()) {
      return;
    }

    if (!canProcessRefund) {
      toast.error("You don't have permission to process refunds");
      return;
    }

    setProcessing(true);

    try {
      const finalAmount = refundType === "full" ? availableRefundAmount : refundAmount;
      const reasonText = refundReason === "other" ? customReason : REFUND_REASONS.find(r => r.id === refundReason)?.label;

      const refundData = {
        payment_id: payment.id,
        student_id: payment.student_id || student?.id,
        school_id: payment.school_id,
        instructor_id: payment.instructor_id || instructor?.id,
        booking_id: payment.booking_id || booking?.id,
        invoice_id: payment.invoice_id || invoice?.id,
        original_amount: payment.amount,
        refund_amount: finalAmount,
        refund_type: refundType,
        refund_reason: refundReason,
        refund_reason_text: reasonText,
        custom_reason: refundReason === "other" ? customReason : null,
        refund_method: refundMethod,
        refund_date: new Date().toISOString(),
        status: requiresApproval ? "pending_approval" : "pending",
        processed_by: "admin",
        notify_customer: notifyCustomer !== "none",
        notification_method: notifyCustomer,
        internal_notes: internalNotes,
        metadata: {
          original_payment_method: payment.payment_method,
          original_payment_date: payment.payment_date,
          previous_refunds_total: totalPreviousRefunds,
          is_partial: refundType === "partial"
        }
      };

      await onRefund(refundData);
      
      toast.success(
        requiresApproval 
          ? "Refund submitted for approval" 
          : `Refund of €${finalAmount.toFixed(2)} processed successfully`
      );
      
      onClose();
    } catch (error) {
      toast.error("Failed to process refund. Please try again.");
      console.error("Refund error:", error);
    } finally {
      setProcessing(false);
    }
  }, [
    validateForm, canProcessRefund, refundType, availableRefundAmount, refundAmount,
    refundReason, customReason, payment, student, instructor, booking, invoice,
    refundMethod, requiresApproval, notifyCustomer, internalNotes, totalPreviousRefunds,
    onRefund, onClose
  ]);

  const selectedReason = REFUND_REASONS.find(r => r.id === refundReason);
  const selectedMethod = REFUND_METHODS.find(m => m.id === refundMethod);
  const finalRefundAmount = refundType === "full" ? availableRefundAmount : refundAmount;

  if (!payment) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-hidden shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 z-10">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                  <RotateCcw className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Process Refund</h2>
                  <p className="text-sm text-gray-500">
                    {student?.full_name || "Customer"} • {payment.id?.substring(0, 8)}
                  </p>
                </div>
              </div>
              <button 
                onClick={onClose} 
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            <div className="flex items-center gap-2 mt-4">
              <div className={`flex-1 h-1 rounded-full ${step >= 1 ? "bg-indigo-600" : "bg-gray-200"}`} />
              <div className={`flex-1 h-1 rounded-full ${step >= 2 ? "bg-indigo-600" : "bg-gray-200"}`} />
            </div>
            <div className="flex justify-between mt-1">
              <span className={`text-xs font-medium ${step >= 1 ? "text-indigo-600" : "text-gray-400"}`}>
                Refund Details
              </span>
              <span className={`text-xs font-medium ${step >= 2 ? "text-indigo-600" : "text-gray-400"}`}>
                Confirm & Process
              </span>
            </div>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-200px)] p-6">
            {isFullyRefunded ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Fully Refunded</h3>
                <p className="text-gray-600 mb-4">
                  This payment has already been fully refunded.
                </p>
                <p className="text-sm text-gray-500">
                  Original amount: €{payment.amount?.toFixed(2)} • 
                  Total refunded: €{totalPreviousRefunds.toFixed(2)}
                </p>
              </div>
            ) : step === 1 ? (
              <div className="space-y-6">
                <div className="p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-gray-600">Original Payment</span>
                    <span className="text-2xl font-bold text-gray-900">€{payment.amount?.toFixed(2)}</span>
                  </div>
                  
                  {totalPreviousRefunds > 0 && (
                    <div className="flex items-center justify-between text-sm mb-3">
                      <span className="text-gray-600">Previous Refunds</span>
                      <span className="text-red-600 font-semibold">-€{totalPreviousRefunds.toFixed(2)}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between pt-3 border-t border-indigo-200">
                    <span className="font-semibold text-gray-900">Available for Refund</span>
                    <span className="text-xl font-bold text-indigo-600">€{availableRefundAmount.toFixed(2)}</span>
                  </div>
                </div>

                {previousRefunds.length > 0 && (
                  <div>
                    <button
                      onClick={() => setShowHistory(!showHistory)}
                      className="flex items-center gap-2 text-sm font-medium text-indigo-600 hover:text-indigo-700"
                    >
                      <History className="w-4 h-4" />
                      View Refund History ({previousRefunds.length})
                      {showHistory ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>

                    <AnimatePresence>
                      {showHistory && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="mt-3 space-y-2"
                        >
                          {previousRefunds.map((refund, idx) => (
                            <div key={idx} className="p-3 bg-gray-50 rounded-lg flex items-center justify-between">
                              <div>
                                <p className="text-sm font-medium text-gray-900">
                                  €{(refund.amount || refund.refund_amount)?.toFixed(2)}
                                </p>
                                <p className="text-xs text-gray-500">
                                  {refund.refund_date ? format(new Date(refund.refund_date), "MMM d, yyyy") : "—"}
                                </p>
                              </div>
                              <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                                refund.status === "completed" ? "bg-green-100 text-green-700" :
                                refund.status === "pending" ? "bg-amber-100 text-amber-700" :
                                "bg-gray-100 text-gray-700"
                              }`}>
                                {refund.status}
                              </span>
                            </div>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                <div className="space-y-3">
                  <label className="block text-sm font-semibold text-gray-900">Refund Type</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setRefundType("full")}
                      className={`p-4 rounded-xl border-2 transition text-left ${
                        refundType === "full"
                          ? "border-indigo-500 bg-indigo-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                          refundType === "full" ? "border-indigo-500" : "border-gray-300"
                        }`}>
                          {refundType === "full" && <div className="w-2 h-2 bg-indigo-500 rounded-full" />}
                        </div>
                        <span className="font-semibold text-gray-900">Full Refund</span>
                      </div>
                      <p className="text-sm text-gray-600 ml-6">€{availableRefundAmount.toFixed(2)}</p>
                    </button>

                    <button
                      onClick={() => setRefundType("partial")}
                      className={`p-4 rounded-xl border-2 transition text-left ${
                        refundType === "partial"
                          ? "border-indigo-500 bg-indigo-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                          refundType === "partial" ? "border-indigo-500" : "border-gray-300"
                        }`}>
                          {refundType === "partial" && <div className="w-2 h-2 bg-indigo-500 rounded-full" />}
                        </div>
                        <span className="font-semibold text-gray-900">Partial Refund</span>
                      </div>
                      <p className="text-sm text-gray-600 ml-6">Custom amount</p>
                    </button>
                  </div>
                </div>

                {refundType === "partial" && (
                  <div className="space-y-3">
                    <label className="block text-sm font-semibold text-gray-900">Refund Amount</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-semibold">€</span>
                      <input
                        type="number"
                        value={refundAmount}
                        onChange={(e) => handleAmountChange(e.target.value)}
                        max={availableRefundAmount}
                        min={0}
                        step="0.01"
                        className={`w-full pl-10 pr-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-lg font-semibold ${
                          errors.amount ? "border-red-500" : "border-gray-300"
                        }`}
                      />
                    </div>
                    {errors.amount && (
                      <p className="text-red-500 text-sm">{errors.amount}</p>
                    )}
                    
                    <div className="flex gap-2">
                      {[25, 50, 75, 100].map(percent => (
                        <button
                          key={percent}
                          onClick={() => handlePercentageClick(percent)}
                          className="flex-1 px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm font-medium text-gray-700 transition"
                        >
                          {percent}%
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  <label className="block text-sm font-semibold text-gray-900">
                    Refund Reason <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={refundReason}
                    onChange={(e) => {
                      setRefundReason(e.target.value);
                      if (errors.reason) setErrors(prev => ({ ...prev, reason: null }));
                    }}
                    className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                      errors.reason ? "border-red-500" : "border-gray-300"
                    }`}
                  >
                    <option value="">Select a reason...</option>
                    {REFUND_REASONS.map(reason => (
                      <option key={reason.id} value={reason.id}>{reason.label}</option>
                    ))}
                  </select>
                  {errors.reason && (
                    <p className="text-red-500 text-sm">{errors.reason}</p>
                  )}
                  {selectedReason && (
                    <p className="text-sm text-gray-500">{selectedReason.description}</p>
                  )}
                </div>

                {refundReason === "other" && (
                  <div className="space-y-2">
                    <label className="block text-sm font-semibold text-gray-900">
                      Please specify <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      value={customReason}
                      onChange={(e) => {
                        setCustomReason(e.target.value);
                        if (errors.customReason) setErrors(prev => ({ ...prev, customReason: null }));
                      }}
                      rows={3}
                      placeholder="Describe the reason for this refund..."
                      className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none ${
                        errors.customReason ? "border-red-500" : "border-gray-300"
                      }`}
                    />
                    {errors.customReason && (
                      <p className="text-red-500 text-sm">{errors.customReason}</p>
                    )}
                  </div>
                )}

                <div className="space-y-3">
                  <label className="block text-sm font-semibold text-gray-900">Refund Method</label>
                  <div className="grid grid-cols-2 gap-2">
                    {REFUND_METHODS.map(method => (
                      <button
                        key={method.id}
                        onClick={() => setRefundMethod(method.id)}
                        className={`p-3 rounded-xl border-2 transition text-left ${
                          refundMethod === method.id
                            ? "border-indigo-500 bg-indigo-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <method.icon className={`w-4 h-4 ${
                            refundMethod === method.id ? "text-indigo-600" : "text-gray-400"
                          }`} />
                          <span className="text-sm font-medium text-gray-900">{method.label}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="block text-sm font-semibold text-gray-900">Customer Notification</label>
                  <div className="flex gap-2">
                    {NOTIFICATION_OPTIONS.map(option => (
                      <button
                        key={option.id}
                        onClick={() => setNotifyCustomer(option.id)}
                        className={`flex-1 p-3 rounded-xl border-2 transition ${
                          notifyCustomer === option.id
                            ? "border-indigo-500 bg-indigo-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <option.icon className={`w-4 h-4 mx-auto mb-1 ${
                          notifyCustomer === option.id ? "text-indigo-600" : "text-gray-400"
                        }`} />
                        <span className="text-xs font-medium text-gray-700">{option.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-gray-900">Internal Notes (Optional)</label>
                  <textarea
                    value={internalNotes}
                    onChange={(e) => setInternalNotes(e.target.value)}
                    rows={2}
                    placeholder="Add any internal notes about this refund..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
                    <div>
                      <p className="font-semibold text-amber-900">Please Review</p>
                      <p className="text-sm text-amber-700">
                        This refund cannot be undone. Please verify all details before processing.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-6 bg-gradient-to-br from-red-50 to-orange-50 rounded-xl text-center">
                  <p className="text-sm text-gray-600 mb-1">Refund Amount</p>
                  <p className="text-4xl font-bold text-red-600">€{finalRefundAmount.toFixed(2)}</p>
                  <p className="text-sm text-gray-500 mt-2">
                    {refundType === "full" ? "Full Refund" : "Partial Refund"}
                  </p>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">Refund Details</h4>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Customer</span>
                      <span className="font-medium text-gray-900">{student?.full_name || "—"}</span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Original Payment</span>
                      <span className="font-medium text-gray-900">€{payment.amount?.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Refund Amount</span>
                      <span className="font-bold text-red-600">€{finalRefundAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Reason</span>
                      <span className="font-medium text-gray-900">
                        {refundReason === "other" ? customReason.substring(0, 30) + "..." : selectedReason?.label}
                      </span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Method</span>
                      <span className="font-medium text-gray-900">{selectedMethod?.label}</span>
                    </div>
                    <div className="flex items-center justify-between py-2">
                      <span className="text-gray-600">Notification</span>
                      <span className="font-medium text-gray-900">
                        {NOTIFICATION_OPTIONS.find(n => n.id === notifyCustomer)?.label}
                      </span>
                    </div>
                  </div>
                </div>

                {requiresApproval && (
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
                    <div className="flex items-start gap-3">
                      <Info className="w-5 h-5 text-blue-600 mt-0.5" />
                      <div>
                        <p className="font-semibold text-blue-900">Approval Required</p>
                        <p className="text-sm text-blue-700">
                          This refund will be submitted for approval before processing.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                <label className="flex items-start gap-3 p-4 bg-gray-50 rounded-xl cursor-pointer">
                  <input
                    type="checkbox"
                    checked={confirmRefund}
                    onChange={(e) => {
                      setConfirmRefund(e.target.checked);
                      if (errors.confirm) setErrors(prev => ({ ...prev, confirm: null }));
                    }}
                    className="w-5 h-5 text-indigo-600 rounded mt-0.5"
                  />
                  <div>
                    <p className="font-medium text-gray-900">
                      I confirm that I have reviewed all refund details and authorize this refund of €{finalRefundAmount.toFixed(2)}
                    </p>
                    {errors.confirm && (
                      <p className="text-red-500 text-sm mt-1">{errors.confirm}</p>
                    )}
                  </div>
                </label>
              </div>
            )}
          </div>

          {!isFullyRefunded && (
            <div className="sticky bottom-0 bg-white border-t border-gray-200 px-6 py-4">
              <div className="flex gap-3">
                {step === 1 ? (
                  <>
                    <button 
                      onClick={onClose} 
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleNextStep}
                      className="flex-1 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2"
                    >
                      Review Refund
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <>
                    <button 
                      onClick={handlePreviousStep}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                    >
                      Back
                    </button>
                    <button
                      onClick={handleSubmit}
                      disabled={processing || isProcessing || !confirmRefund}
                      className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {processing || isProcessing ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <RotateCcw className="w-5 h-5" />
                          {requiresApproval ? "Submit for Approval" : "Process Refund"}
                        </>
                      )}
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}