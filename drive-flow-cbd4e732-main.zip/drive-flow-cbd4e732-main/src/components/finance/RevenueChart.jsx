import React, { useState, useMemo } from "react";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend,
  ReferenceLine,
  Brush,
  LineChart,
  Line,
  BarChart,
  Bar,
  ComposedChart
} from "recharts";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Calendar,
  Download,
  Maximize2,
  Minimize2,
  RefreshCw,
  Info,
  Eye,
  EyeOff,
  Filter,
  MoreVertical,
  Target as TargetIcon,
  Award,
  AlertCircle,
  CheckCircle,
  ArrowUpRight,
  ArrowDownRight
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format, parseISO, startOfMonth, endOfMonth, differenceInDays } from "date-fns";

export default function RevenueChart({ 
  data = [], 
  showBookings = false, 
  target,
  showComparison = false,
  comparisonData = [],
  period = "daily",
  showAverage = false,
  showForecast = false,
  onExport,
  isLoading = false,
  title = "Revenue Trend",
  subtitle = "Daily revenue and bookings",
  height = 300,
  showLegend = true,
  showGrid = true,
  showBrush = false,
  currency = "€",
  showTargetLine = true,
  showMilestones = false,
  milestones = [],
  onDataPointClick
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [chartType, setChartType] = useState("area");
  const [showOptions, setShowOptions] = useState(false);
  const [hiddenSeries, setHiddenSeries] = useState(new Set());
  const [selectedPeriod, setSelectedPeriod] = useState(period);
  const [showTooltipDetails, setShowTooltipDetails] = useState(true);

  const stats = useMemo(() => {
    if (!data.length) return null;

    const totalRevenue = data.reduce((sum, d) => sum + (d.revenue || 0), 0);
    const totalBookings = data.reduce((sum, d) => sum + (d.bookings || 0), 0);
    const avgRevenue = totalRevenue / data.length;
    const avgBookings = totalBookings / data.length;

    const revenueValues = data.map(d => d.revenue || 0);
    const maxRevenue = Math.max(...revenueValues);
    const minRevenue = Math.min(...revenueValues);

    const recentData = data.slice(-7);
    const olderData = data.slice(-14, -7);
    const recentRevenue = recentData.reduce((sum, d) => sum + (d.revenue || 0), 0);
    const olderRevenue = olderData.length > 0 ? olderData.reduce((sum, d) => sum + (d.revenue || 0), 0) : recentRevenue;
    
    const growthRate = olderRevenue > 0 
      ? ((recentRevenue - olderRevenue) / olderRevenue) * 100 
      : 0;

    const targetProgress = target ? (totalRevenue / target) * 100 : null;
    const targetRemaining = target ? target - totalRevenue : null;
    const daysRemaining = data.length > 0 ? differenceInDays(endOfMonth(new Date()), new Date()) : 0;
    const dailyTargetNeeded = targetRemaining && daysRemaining > 0 ? targetRemaining / daysRemaining : 0;

    return {
      totalRevenue,
      totalBookings,
      avgRevenue,
      avgBookings,
      maxRevenue,
      minRevenue,
      growthRate,
      targetProgress,
      targetRemaining,
      dailyTargetNeeded,
      daysRemaining
    };
  }, [data, target]);

  const enhancedData = useMemo(() => {
    if (!data.length) return [];

    let processed = [...data];

    if (showAverage && stats) {
      processed = processed.map(d => ({
        ...d,
        average: stats.avgRevenue
      }));
    }

    if (showForecast && data.length >= 7) {
      const trend = stats.growthRate / 100;
      const lastValue = data[data.length - 1].revenue;
      const forecastDays = 7;
      
      for (let i = 1; i <= forecastDays; i++) {
        processed.push({
          date: `Forecast +${i}`,
          revenue: lastValue * Math.pow(1 + trend / 30, i),
          forecast: true
        });
      }
    }

    if (showComparison && comparisonData.length > 0) {
      processed = processed.map((d, idx) => ({
        ...d,
        comparisonRevenue: comparisonData[idx]?.revenue || 0
      }));
    }

    return processed;
  }, [data, showAverage, showForecast, showComparison, comparisonData, stats]);

  const toggleSeries = (seriesName) => {
    setHiddenSeries(prev => {
      const next = new Set(prev);
      if (next.has(seriesName)) {
        next.delete(seriesName);
      } else {
        next.add(seriesName);
      }
      return next;
    });
  };

  const handleExport = () => {
    if (onExport) {
      onExport(enhancedData);
    } else {
      const csvContent = [
        ["Date", "Revenue", "Bookings"].join(","),
        ...enhancedData.map(d => [
          d.date,
          d.revenue || 0,
          d.bookings || 0
        ].join(","))
      ].join("\n");

      const blob = new Blob([csvContent], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `revenue_chart_${format(new Date(), "yyyy-MM-dd")}.csv`;
      a.click();
    }
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length || !showTooltipDetails) return null;

    return (
      <div className="bg-white border border-gray-200 rounded-xl shadow-lg p-4 min-w-48">
        <p className="text-sm font-bold text-gray-900 mb-2">{label}</p>
        <div className="space-y-1">
          {payload.map((entry, index) => {
            if (hiddenSeries.has(entry.dataKey)) return null;
            
            return (
              <div key={index} className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: entry.color }}
                  />
                  <span className="text-xs text-gray-600">{entry.name}</span>
                </div>
                <span className="text-xs font-bold text-gray-900">
                  {entry.dataKey === "revenue" || entry.dataKey === "comparisonRevenue" || entry.dataKey === "average"
                    ? `${currency}${entry.value.toLocaleString(undefined, { maximumFractionDigits: 0 })}`
                    : entry.value}
                </span>
              </div>
            );
          })}
        </div>
        {stats && payload[0] && (
          <div className="mt-3 pt-3 border-t border-gray-100">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-600">vs Avg</span>
              <span className={`font-bold ${
                payload[0].value > stats.avgRevenue ? "text-green-600" : "text-red-600"
              }`}>
                {payload[0].value > stats.avgRevenue ? "+" : ""}
                {((payload[0].value - stats.avgRevenue) / stats.avgRevenue * 100).toFixed(1)}%
              </span>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderChart = () => {
    const commonProps = {
      data: enhancedData,
      margin: { top: 10, right: 30, left: 0, bottom: 0 }
    };

    const xAxisProps = {
      dataKey: "date",
      stroke: "#9ca3af",
      style: { fontSize: "12px" },
      tick: { fill: "#6b7280" }
    };

    const yAxisProps = {
      stroke: "#9ca3af",
      style: { fontSize: "12px" },
      tick: { fill: "#6b7280" },
      tickFormatter: (value) => `${currency}${value.toLocaleString(undefined, { maximumFractionDigits: 0 })}`
    };

    const tooltipProps = {
      content: <CustomTooltip />,
      cursor: { stroke: "#e5e7eb", strokeWidth: 1 }
    };

    const legendProps = showLegend ? {
      onClick: (e) => toggleSeries(e.dataKey),
      wrapperStyle: { paddingTop: "20px" },
      formatter: (value, entry) => (
        <span 
          style={{ 
            color: hiddenSeries.has(entry.dataKey) ? "#9ca3af" : "#374151",
            textDecoration: hiddenSeries.has(entry.dataKey) ? "line-through" : "none",
            cursor: "pointer"
          }}
        >
          {value}
        </span>
      )
    } : {};

    if (chartType === "line") {
      return (
        <LineChart {...commonProps}>
          {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />}
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <Tooltip {...tooltipProps} />
          {showLegend && <Legend {...legendProps} />}
          {showTargetLine && target && (
            <ReferenceLine 
              y={target / data.length} 
              stroke="#f59e0b" 
              strokeDasharray="5 5"
              label={{ value: "Target", position: "insideTopRight", fill: "#f59e0b" }}
            />
          )}
          {!hiddenSeries.has("revenue") && (
            <Line 
              type="monotone" 
              dataKey="revenue" 
              stroke="#6366f1" 
              strokeWidth={2}
              dot={{ fill: "#6366f1", r: 3 }}
              activeDot={{ r: 5 }}
              name="Revenue"
              isAnimationActive={!isLoading}
            />
          )}
          {showBookings && !hiddenSeries.has("bookings") && (
            <Line 
              type="monotone" 
              dataKey="bookings" 
              stroke="#a855f7" 
              strokeWidth={2}
              dot={{ fill: "#a855f7", r: 3 }}
              name="Bookings"
              yAxisId="right"
              isAnimationActive={!isLoading}
            />
          )}
          {showAverage && !hiddenSeries.has("average") && (
            <Line 
              type="monotone" 
              dataKey="average" 
              stroke="#10b981" 
              strokeWidth={2}
              strokeDasharray="5 5"
              dot={false}
              name="Average"
              isAnimationActive={false}
            />
          )}
          {showComparison && !hiddenSeries.has("comparisonRevenue") && (
            <Line 
              type="monotone" 
              dataKey="comparisonRevenue" 
              stroke="#ef4444" 
              strokeWidth={2}
              strokeDasharray="3 3"
              dot={false}
              name="Previous Period"
              isAnimationActive={!isLoading}
            />
          )}
          {showBrush && <Brush dataKey="date" height={30} stroke="#6366f1" />}
        </LineChart>
      );
    }

    if (chartType === "bar") {
      return (
        <BarChart {...commonProps}>
          {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />}
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <Tooltip {...tooltipProps} />
          {showLegend && <Legend {...legendProps} />}
          {!hiddenSeries.has("revenue") && (
            <Bar 
              dataKey="revenue" 
              fill="#6366f1" 
              name="Revenue"
              radius={[8, 8, 0, 0]}
              isAnimationActive={!isLoading}
            />
          )}
          {showBookings && !hiddenSeries.has("bookings") && (
            <Bar 
              dataKey="bookings" 
              fill="#a855f7" 
              name="Bookings"
              radius={[8, 8, 0, 0]}
              isAnimationActive={!isLoading}
            />
          )}
          {showBrush && <Brush dataKey="date" height={30} stroke="#6366f1" />}
        </BarChart>
      );
    }

    if (chartType === "composed") {
      return (
        <ComposedChart {...commonProps}>
          <defs>
            <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
            </linearGradient>
          </defs>
          {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />}
          <XAxis {...xAxisProps} />
          <YAxis {...yAxisProps} />
          <YAxis 
            yAxisId="right" 
            orientation="right"
            stroke="#a855f7"
            style={{ fontSize: "12px" }}
          />
          <Tooltip {...tooltipProps} />
          {showLegend && <Legend {...legendProps} />}
          {!hiddenSeries.has("revenue") && (
            <Area 
              type="monotone" 
              dataKey="revenue" 
              stroke="#6366f1" 
              strokeWidth={2}
              fill="url(#revenueGradient)" 
              name="Revenue"
              isAnimationActive={!isLoading}
            />
          )}
          {showBookings && !hiddenSeries.has("bookings") && (
            <Bar 
              dataKey="bookings" 
              fill="#a855f7" 
              name="Bookings"
              yAxisId="right"
              radius={[4, 4, 0, 0]}
              isAnimationActive={!isLoading}
            />
          )}
          {showBrush && <Brush dataKey="date" height={30} stroke="#6366f1" />}
        </ComposedChart>
      );
    }

    return (
      <AreaChart {...commonProps}>
        <defs>
          <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
            <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
          </linearGradient>
          <linearGradient id="bookingsGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3}/>
            <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
          </linearGradient>
          <linearGradient id="comparisonGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
            <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
          </linearGradient>
        </defs>
        {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />}
        <XAxis {...xAxisProps} />
        <YAxis {...yAxisProps} />
        <Tooltip {...tooltipProps} />
        {showLegend && <Legend {...legendProps} />}
        {showTargetLine && target && (
          <ReferenceLine 
            y={target / data.length} 
            stroke="#f59e0b" 
            strokeDasharray="5 5"
            label={{ 
              value: "Daily Target", 
              position: "insideTopRight", 
              fill: "#f59e0b",
              fontSize: 12
            }}
          />
        )}
        {!hiddenSeries.has("revenue") && (
          <Area 
            type="monotone" 
            dataKey="revenue" 
            stroke="#6366f1" 
            strokeWidth={2}
            fill="url(#revenueGradient)" 
            name="Revenue"
            isAnimationActive={!isLoading}
          />
        )}
        {showBookings && !hiddenSeries.has("bookings") && (
          <Area 
            type="monotone" 
            dataKey="bookings" 
            stroke="#a855f7" 
            strokeWidth={2}
            fill="url(#bookingsGradient)" 
            name="Bookings"
            isAnimationActive={!isLoading}
          />
        )}
        {showAverage && !hiddenSeries.has("average") && (
          <Area 
            type="monotone" 
            dataKey="average" 
            stroke="#10b981" 
            strokeWidth={2}
            strokeDasharray="5 5"
            fill="none"
            name="Average"
            isAnimationActive={false}
          />
        )}
        {showComparison && !hiddenSeries.has("comparisonRevenue") && (
          <Area 
            type="monotone" 
            dataKey="comparisonRevenue" 
            stroke="#ef4444" 
            strokeWidth={2}
            fill="url(#comparisonGradient)" 
            name="Previous Period"
            isAnimationActive={!isLoading}
          />
        )}
        {showBrush && <Brush dataKey="date" height={30} stroke="#6366f1" />}
      </AreaChart>
    );
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl p-6 border border-gray-200">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/3 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="h-64 bg-gray-100 rounded"></div>
        </div>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="bg-white rounded-2xl p-6 border border-gray-200">
        <h3 className="text-lg font-bold text-gray-900 mb-2">{title}</h3>
        <p className="text-sm text-gray-600 mb-6">{subtitle}</p>
        <div className="flex flex-col items-center justify-center h-64 text-gray-400">
          <BarChart className="w-16 h-16 mb-4" />
          <p className="text-sm font-medium">No data available</p>
          <p className="text-xs">Data will appear here once available</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded-2xl p-6 border border-gray-200 shadow-sm hover:shadow-md transition-shadow ${
        isExpanded ? "fixed inset-4 z-50 overflow-auto" : ""
      }`}
    >
      <div className="flex items-start justify-between mb-6">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-lg font-bold text-gray-900">{title}</h3>
            {stats && stats.growthRate !== 0 && (
              <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${
                stats.growthRate > 0 ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
              }`}>
                {stats.growthRate > 0 ? (
                  <ArrowUpRight className="w-4 h-4" />
                ) : (
                  <ArrowDownRight className="w-4 h-4" />
                )}
                <span className="text-xs font-bold">
                  {Math.abs(stats.growthRate).toFixed(1)}%
                </span>
              </div>
            )}
          </div>
          <p className="text-sm text-gray-600">{subtitle}</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <button
              onClick={() => setShowOptions(!showOptions)}
              className="p-2 rounded-lg hover:bg-gray-100 transition"
            >
              <MoreVertical className="w-5 h-5 text-gray-600" />
            </button>

            <AnimatePresence>
              {showOptions && (
                <>
                  <div 
                    className="fixed inset-0 z-30" 
                    onClick={() => setShowOptions(false)}
                  />
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-lg border border-gray-200 py-2 z-40"
                  >
                    <button
                      onClick={() => {
                        setChartType(chartType === "area" ? "line" : chartType === "line" ? "bar" : chartType === "bar" ? "composed" : "area");
                        setShowOptions(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 transition flex items-center gap-2"
                    >
                      <RefreshCw className="w-4 h-4" />
                      Change Chart Type
                    </button>
                    <button
                      onClick={() => {
                        setShowTooltipDetails(!showTooltipDetails);
                        setShowOptions(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 transition flex items-center gap-2"
                    >
                      {showTooltipDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      {showTooltipDetails ? "Hide" : "Show"} Details
                    </button>
                    <button
                      onClick={() => {
                        handleExport();
                        setShowOptions(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 transition flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      Export Data
                    </button>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 rounded-lg hover:bg-gray-100 transition"
          >
            {isExpanded ? (
              <Minimize2 className="w-5 h-5 text-gray-600" />
            ) : (
              <Maximize2 className="w-5 h-5 text-gray-600" />
            )}
          </button>
        </div>
      </div>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-gray-50 rounded-xl p-4">
            <p className="text-xs text-gray-600 mb-1">Total Revenue</p>
            <p className="text-xl font-bold text-gray-900">
              {currency}{stats.totalRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </p>
          </div>
          <div className="bg-gray-50 rounded-xl p-4">
            <p className="text-xs text-gray-600 mb-1">Average</p>
            <p className="text-xl font-bold text-gray-900">
              {currency}{stats.avgRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </p>
          </div>
          {showBookings && (
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-xs text-gray-600 mb-1">Total Bookings</p>
              <p className="text-xl font-bold text-gray-900">
                {stats.totalBookings}
              </p>
            </div>
          )}
          {target && (
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-xs text-gray-600 mb-1">Target Progress</p>
              <p className="text-xl font-bold text-gray-900">
                {stats.targetProgress.toFixed(1)}%
              </p>
            </div>
          )}
        </div>
      )}
      
      <ResponsiveContainer width="100%" height={isExpanded ? 500 : height}>
        {renderChart()}
      </ResponsiveContainer>
      
      {target && stats && (
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <TargetIcon className="w-5 h-5 text-indigo-600" />
              <span className="text-sm font-bold text-gray-900">Monthly Target</span>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">
                {currency}{target.toLocaleString()} 
                <span className="text-xs text-gray-500 ml-2">
                  ({stats.targetProgress.toFixed(1)}%)
                </span>
              </p>
            </div>
          </div>

          <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden mb-3">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${Math.min(stats.targetProgress, 100)}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              className={`h-full transition-all ${
                stats.targetProgress >= 100 
                  ? "bg-gradient-to-r from-green-500 to-emerald-500" 
                  : stats.targetProgress >= 75
                  ? "bg-gradient-to-r from-indigo-600 to-purple-600"
                  : stats.targetProgress >= 50
                  ? "bg-gradient-to-r from-yellow-500 to-orange-500"
                  : "bg-gradient-to-r from-red-500 to-pink-500"
              }`}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-start gap-2">
              {stats.targetProgress >= 100 ? (
                <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
              )}
              <div>
                <p className="text-xs text-gray-600">Remaining</p>
                <p className="text-sm font-bold text-gray-900">
                  {currency}{Math.max(0, stats.targetRemaining).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </p>
              </div>
            </div>
            {stats.daysRemaining > 0 && stats.targetRemaining > 0 && (
              <div className="flex items-start gap-2">
                <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs text-gray-600">Daily Need</p>
                  <p className="text-sm font-bold text-gray-900">
                    {currency}{stats.dailyTargetNeeded.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </p>
                </div>
              </div>
            )}
          </div>

          {stats.targetProgress >= 100 && (
            <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-xl flex items-center gap-2">
              <Award className="w-5 h-5 text-green-600" />
              <p className="text-sm font-semibold text-green-900">
                Target achieved! Great work! 🎉
              </p>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}