import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Download,
  RefreshCw,
  Filter,
  Eye,
  EyeOff,
  Info,
  HelpCircle,
  MoreVertical,
  Settings,
  Calendar,
  DollarSign,
  Users,
  Car,
  Package,
  CreditCard,
  Award,
  BookOpen,
  Clock,
  Target,
  Zap,
  Activity,
  BarChart3,
  PieChart as PieChartIcon,
  LineChart,
  Layers,
  Grid,
  List,
  Search,
  SlidersHorizontal,
  ExternalLink,
  Copy,
  Share2,
  Loader2,
  CheckCircle,
  AlertCircle,
  AlertTriangle,
  Sparkles
} from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart as RechartsLineChart,
  Line,
  ComposedChart,
  Area
} from "recharts";
import { format, subMonths, startOfMonth, endOfMonth, differenceInDays, parseISO, isWithinInterval } from "date-fns";

const REVENUE_CATEGORIES = {
  lessons: {
    id: "lessons",
    label: "Individual Lessons",
    icon: Car,
    color: "#6366f1",
    gradient: "from-indigo-500 to-indigo-600",
    description: "Revenue from single lesson bookings"
  },
  packages: {
    id: "packages",
    label: "Package Sales",
    icon: Package,
    color: "#8b5cf6",
    gradient: "from-purple-500 to-purple-600",
    description: "Revenue from lesson packages"
  },
  tests: {
    id: "tests",
    label: "Test Fees",
    icon: Award,
    color: "#ec4899",
    gradient: "from-pink-500 to-pink-600",
    description: "Test booking and administration fees"
  },
  materials: {
    id: "materials",
    label: "Learning Materials",
    icon: BookOpen,
    color: "#f59e0b",
    gradient: "from-amber-500 to-amber-600",
    description: "Books, manuals, and study materials"
  },
  cancellation: {
    id: "cancellation",
    label: "Cancellation Fees",
    icon: Clock,
    color: "#ef4444",
    gradient: "from-red-500 to-red-600",
    description: "Late cancellation and no-show fees"
  },
  deposits: {
    id: "deposits",
    label: "Booking Deposits",
    icon: CreditCard,
    color: "#14b8a6",
    gradient: "from-teal-500 to-teal-600",
    description: "Advance booking deposits"
  },
  other: {
    id: "other",
    label: "Other Revenue",
    icon: DollarSign,
    color: "#6b7280",
    gradient: "from-gray-500 to-gray-600",
    description: "Miscellaneous revenue sources"
  }
};

const CHART_COLORS = [
  "#6366f1", "#8b5cf6", "#ec4899", "#f59e0b", 
  "#ef4444", "#14b8a6", "#6b7280", "#3b82f6",
  "#10b981", "#f97316"
];

const VIEW_MODES = [
  { id: "bars", label: "Bar Chart", icon: BarChart3 },
  { id: "pie", label: "Pie Chart", icon: PieChartIcon },
  { id: "list", label: "List View", icon: List }
];

const SORT_OPTIONS = [
  { id: "value_desc", label: "Highest Value" },
  { id: "value_asc", label: "Lowest Value" },
  { id: "percentage_desc", label: "Highest %" },
  { id: "name_asc", label: "Alphabetical" },
  { id: "growth_desc", label: "Highest Growth" }
];

export default function RevenueBreakdown({
  data = [],
  previousPeriodData = [],
  historicalData = [],
  title = "Revenue by Source",
  subtitle,
  dateRange,
  targets = {},
  onExport,
  onRefresh,
  onCategoryClick,
  onSettingsClick,
  isLoading = false,
  showTrends = true,
  showTargets = false,
  showPercentages = true,
  showComparison = true,
  compact = false,
  animated = true,
  defaultView = "bars",
  className = ""
}) {
  const [viewMode, setViewMode] = useState(defaultView);
  const [sortBy, setSortBy] = useState("value_desc");
  const [expandedCategories, setExpandedCategories] = useState(new Set());
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [hoveredCategory, setHoveredCategory] = useState(null);

  const processedData = useMemo(() => {
    const total = data.reduce((sum, item) => sum + (item.value || 0), 0);

    return data.map((item, index) => {
      const categoryConfig = REVENUE_CATEGORIES[item.id] || REVENUE_CATEGORIES[item.name?.toLowerCase()] || {
        id: item.id || item.name,
        label: item.name,
        icon: DollarSign,
        color: CHART_COLORS[index % CHART_COLORS.length],
        gradient: "from-gray-500 to-gray-600"
      };

      const percentage = total > 0 ? (item.value / total) * 100 : 0;

      const previousItem = previousPeriodData.find(p => 
        p.id === item.id || p.name === item.name
      );
      const previousValue = previousItem?.value || 0;
      const growth = previousValue > 0 
        ? ((item.value - previousValue) / previousValue) * 100 
        : item.value > 0 ? 100 : 0;

      const target = targets[item.id] || targets[item.name];
      const targetProgress = target ? (item.value / target) * 100 : null;

      const transactionCount = item.transactions || item.count || 0;
      const avgTransaction = transactionCount > 0 ? item.value / transactionCount : 0;

      return {
        ...item,
        ...categoryConfig,
        name: item.name || categoryConfig.label,
        percentage,
        previousValue,
        growth,
        target,
        targetProgress,
        transactionCount,
        avgTransaction,
        color: item.color || categoryConfig.color
      };
    });
  }, [data, previousPeriodData, targets]);

  const filteredData = useMemo(() => {
    let result = processedData;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(item =>
        item.name?.toLowerCase().includes(query) ||
        item.label?.toLowerCase().includes(query)
      );
    }

    result.sort((a, b) => {
      switch (sortBy) {
        case "value_asc":
          return a.value - b.value;
        case "value_desc":
          return b.value - a.value;
        case "percentage_desc":
          return b.percentage - a.percentage;
        case "name_asc":
          return (a.name || "").localeCompare(b.name || "");
        case "growth_desc":
          return b.growth - a.growth;
        default:
          return b.value - a.value;
      }
    });

    return result;
  }, [processedData, searchQuery, sortBy]);

  const totalMetrics = useMemo(() => {
    const total = filteredData.reduce((sum, item) => sum + item.value, 0);
    const previousTotal = previousPeriodData.reduce((sum, item) => sum + (item.value || 0), 0);
    const totalGrowth = previousTotal > 0 ? ((total - previousTotal) / previousTotal) * 100 : 0;
    const totalTransactions = filteredData.reduce((sum, item) => sum + (item.transactionCount || 0), 0);
    const avgTransactionValue = totalTransactions > 0 ? total / totalTransactions : 0;

    const topCategory = filteredData.length > 0 
      ? filteredData.reduce((max, item) => item.value > max.value ? item : max)
      : null;

    const fastestGrowing = filteredData.length > 0
      ? filteredData.reduce((max, item) => item.growth > max.growth ? item : max)
      : null;

    return {
      total,
      previousTotal,
      totalGrowth,
      totalTransactions,
      avgTransactionValue,
      topCategory,
      fastestGrowing,
      categoryCount: filteredData.length
    };
  }, [filteredData, previousPeriodData]);

  const chartData = useMemo(() => {
    return filteredData.map(item => ({
      ...item,
      fill: item.color
    }));
  }, [filteredData]);

  const toggleCategory = useCallback((categoryId) => {
    setExpandedCategories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(categoryId)) {
        newSet.delete(categoryId);
      } else {
        newSet.add(categoryId);
      }
      return newSet;
    });
  }, []);

  const handleCategoryClick = useCallback((category) => {
    setSelectedCategory(selectedCategory?.id === category.id ? null : category);
    onCategoryClick?.(category);
  }, [selectedCategory, onCategoryClick]);

  const handleExport = useCallback((format) => {
    if (onExport) {
      onExport({
        format,
        data: {
          categories: filteredData,
          totals: totalMetrics,
          dateRange
        }
      });
    }
  }, [onExport, filteredData, totalMetrics, dateRange]);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatCompact = (amount) => {
    if (amount >= 1000000) return `€${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `€${(amount / 1000).toFixed(1)}K`;
    return formatCurrency(amount);
  };

  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload || !payload.length) return null;

    const data = payload[0]?.payload;

    return (
      <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-200 max-w-xs">
        <div className="flex items-center gap-2 mb-2">
          <div
            className="w-3 h-3 rounded-full"
            style={{ backgroundColor: data?.color }}
          />
          <span className="font-semibold text-gray-900">{data?.name}</span>
        </div>
        <div className="space-y-1 text-sm">
          <div className="flex justify-between gap-4">
            <span className="text-gray-600">Revenue:</span>
            <span className="font-semibold">{formatCurrency(data?.value)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-gray-600">Share:</span>
            <span className="font-semibold">{data?.percentage?.toFixed(1)}%</span>
          </div>
          {showTrends && data?.growth !== undefined && (
            <div className="flex justify-between gap-4">
              <span className="text-gray-600">Growth:</span>
              <span className={`font-semibold ${data.growth >= 0 ? "text-green-600" : "text-red-600"}`}>
                {data.growth >= 0 ? "+" : ""}{data.growth.toFixed(1)}%
              </span>
            </div>
          )}
          {data?.transactionCount > 0 && (
            <div className="flex justify-between gap-4">
              <span className="text-gray-600">Transactions:</span>
              <span className="font-semibold">{data.transactionCount}</span>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderBarChart = () => (
    <ResponsiveContainer width="100%" height={compact ? 200 : 300}>
      <BarChart data={chartData} layout="vertical">
        <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
        <XAxis type="number" tickFormatter={(v) => formatCompact(v)} />
        <YAxis 
          type="category" 
          dataKey="name" 
          width={120} 
          tick={{ fontSize: 12 }}
        />
        <Tooltip content={<CustomTooltip />} />
        <Bar 
          dataKey="value" 
          radius={[0, 4, 4, 0]}
          onMouseEnter={(data) => setHoveredCategory(data.id)}
          onMouseLeave={() => setHoveredCategory(null)}
        >
          {chartData.map((entry, index) => (
            <Cell 
              key={`cell-${index}`} 
              fill={entry.color}
              opacity={hoveredCategory && hoveredCategory !== entry.id ? 0.5 : 1}
              className="cursor-pointer transition-opacity duration-200"
              onClick={() => handleCategoryClick(entry)}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );

  const renderPieChart = () => (
    <ResponsiveContainer width="100%" height={compact ? 200 : 300}>
      <PieChart>
        <Pie
          data={chartData}
          cx="50%"
          cy="50%"
          innerRadius={compact ? 40 : 60}
          outerRadius={compact ? 70 : 100}
          paddingAngle={2}
          dataKey="value"
          onMouseEnter={(data) => setHoveredCategory(data.id)}
          onMouseLeave={() => setHoveredCategory(null)}
        >
          {chartData.map((entry, index) => (
            <Cell
              key={`cell-${index}`}
              fill={entry.color}
              opacity={hoveredCategory && hoveredCategory !== entry.id ? 0.5 : 1}
              className="cursor-pointer transition-opacity duration-200"
              onClick={() => handleCategoryClick(entry)}
            />
          ))}
        </Pie>
        <Tooltip content={<CustomTooltip />} />
        <Legend 
          layout="vertical" 
          align="right" 
          verticalAlign="middle"
          formatter={(value, entry) => (
            <span className="text-sm text-gray-700">{value}</span>
          )}
        />
      </PieChart>
    </ResponsiveContainer>
  );

  const renderListView = () => (
    <div className="space-y-3">
      {filteredData.map((item, index) => {
        const IconComponent = item.icon || DollarSign;
        const isExpanded = expandedCategories.has(item.id);
        const isSelected = selectedCategory?.id === item.id;

        return (
          <div
            key={item.id || index}
            className={`
              rounded-xl border transition-all duration-200
              ${isSelected ? "border-indigo-300 ring-2 ring-indigo-100" : "border-gray-200"}
              ${hoveredCategory === item.id ? "shadow-md" : ""}
            `}
            onMouseEnter={() => setHoveredCategory(item.id)}
            onMouseLeave={() => setHoveredCategory(null)}
          >
            <div
              className="p-4 cursor-pointer"
              onClick={() => handleCategoryClick(item)}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ backgroundColor: `${item.color}15` }}
                  >
                    <IconComponent className="w-5 h-5" style={{ color: item.color }} />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{item.name}</p>
                    {item.description && (
                      <p className="text-xs text-gray-500">{item.description}</p>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-gray-900 tabular-nums">
                    {formatCurrency(item.value)}
                  </p>
                  {showPercentages && (
                    <p className="text-sm text-gray-500">{item.percentage.toFixed(1)}%</p>
                  )}
                </div>
              </div>

              <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className={`absolute h-full rounded-full transition-all duration-500 bg-gradient-to-r ${item.gradient}`}
                  style={{ width: `${item.percentage}%` }}
                />
              </div>

              {showTrends && (
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                  <div className="flex items-center gap-4">
                    <div className={`
                      flex items-center gap-1 px-2 py-1 rounded-lg text-sm font-medium
                      ${item.growth >= 0 ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"}
                    `}>
                      {item.growth >= 0 ? (
                        <ArrowUpRight className="w-4 h-4" />
                      ) : (
                        <ArrowDownRight className="w-4 h-4" />
                      )}
                      {Math.abs(item.growth).toFixed(1)}%
                    </div>
                    {showComparison && item.previousValue > 0 && (
                      <span className="text-xs text-gray-500">
                        vs {formatCurrency(item.previousValue)} last period
                      </span>
                    )}
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleCategory(item.id);
                    }}
                    className="p-1 hover:bg-gray-100 rounded-lg transition"
                  >
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-gray-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-gray-400" />
                    )}
                  </button>
                </div>
              )}
            </div>

            {isExpanded && (
              <div className="px-4 pb-4 pt-2 border-t border-gray-100 bg-gray-50">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="p-3 bg-white rounded-lg">
                    <p className="text-xs text-gray-500">Transactions</p>
                    <p className="text-lg font-semibold text-gray-900">
                      {item.transactionCount || 0}
                    </p>
                  </div>
                  <div className="p-3 bg-white rounded-lg">
                    <p className="text-xs text-gray-500">Avg Value</p>
                    <p className="text-lg font-semibold text-gray-900">
                      {formatCurrency(item.avgTransaction)}
                    </p>
                  </div>
                  {item.target && (
                    <>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-xs text-gray-500">Target</p>
                        <p className="text-lg font-semibold text-gray-900">
                          {formatCurrency(item.target)}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg">
                        <p className="text-xs text-gray-500">Progress</p>
                        <p className={`text-lg font-semibold ${
                          item.targetProgress >= 100 ? "text-green-600" :
                          item.targetProgress >= 75 ? "text-amber-600" :
                          "text-red-600"
                        }`}>
                          {item.targetProgress.toFixed(0)}%
                        </p>
                      </div>
                    </>
                  )}
                </div>

                {item.target && (
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                      <span>Target Progress</span>
                      <span>{item.targetProgress.toFixed(0)}%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          item.targetProgress >= 100 ? "bg-green-500" :
                          item.targetProgress >= 75 ? "bg-amber-500" :
                          "bg-red-500"
                        }`}
                        style={{ width: `${Math.min(100, item.targetProgress)}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );

  return (
    <div className={`bg-white rounded-2xl border border-gray-200 overflow-hidden ${className}`}>
      <div className={`${compact ? "p-4" : "p-6"} border-b border-gray-200`}>
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className={`font-bold text-gray-900 ${compact ? "text-base" : "text-lg"}`}>
              {title}
            </h3>
            {subtitle && (
              <p className="text-sm text-gray-500 mt-0.5">{subtitle}</p>
            )}
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center bg-gray-100 rounded-lg p-1">
              {VIEW_MODES.map(mode => (
                <button
                  key={mode.id}
                  onClick={() => setViewMode(mode.id)}
                  className={`p-1.5 rounded-md transition ${
                    viewMode === mode.id
                      ? "bg-white text-gray-900 shadow-sm"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                  title={mode.label}
                >
                  <mode.icon className="w-4 h-4" />
                </button>
              ))}
            </div>

            {onRefresh && (
              <button
                onClick={onRefresh}
                disabled={isLoading}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <RefreshCw className={`w-4 h-4 text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
              </button>
            )}

            {onExport && (
              <button
                onClick={() => handleExport("csv")}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <Download className="w-4 h-4 text-gray-600" />
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="p-3 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
            <p className="text-xs text-indigo-600 font-medium">Total Revenue</p>
            <p className="text-xl font-bold text-gray-900">{formatCompact(totalMetrics.total)}</p>
            {showTrends && (
              <div className={`flex items-center gap-1 text-xs ${
                totalMetrics.totalGrowth >= 0 ? "text-green-600" : "text-red-600"
              }`}>
                {totalMetrics.totalGrowth >= 0 ? (
                  <ArrowUpRight className="w-3 h-3" />
                ) : (
                  <ArrowDownRight className="w-3 h-3" />
                )}
                {Math.abs(totalMetrics.totalGrowth).toFixed(1)}%
              </div>
            )}
          </div>

          <div className="p-3 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl">
            <p className="text-xs text-green-600 font-medium">Categories</p>
            <p className="text-xl font-bold text-gray-900">{totalMetrics.categoryCount}</p>
            <p className="text-xs text-gray-500">revenue sources</p>
          </div>

          {totalMetrics.topCategory && (
            <div className="p-3 bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl">
              <p className="text-xs text-amber-600 font-medium">Top Category</p>
              <p className="text-sm font-bold text-gray-900 truncate">
                {totalMetrics.topCategory.name}
              </p>
              <p className="text-xs text-gray-500">
                {totalMetrics.topCategory.percentage.toFixed(1)}% of total
              </p>
            </div>
          )}

          {totalMetrics.fastestGrowing && totalMetrics.fastestGrowing.growth > 0 && (
            <div className="p-3 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
              <p className="text-xs text-blue-600 font-medium">Fastest Growing</p>
              <p className="text-sm font-bold text-gray-900 truncate">
                {totalMetrics.fastestGrowing.name}
              </p>
              <p className="text-xs text-green-600">
                +{totalMetrics.fastestGrowing.growth.toFixed(1)}%
              </p>
            </div>
          )}
        </div>
      </div>

      <div className={`${compact ? "p-4" : "p-6"}`}>
        {viewMode !== "list" && (
          <div className="flex items-center justify-between mb-4">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {SORT_OPTIONS.map(option => (
                <option key={option.id} value={option.id}>{option.label}</option>
              ))}
            </select>

            {filteredData.length > 0 && (
              <p className="text-sm text-gray-500">
                {filteredData.length} categor{filteredData.length === 1 ? "y" : "ies"}
              </p>
            )}
          </div>
        )}

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          </div>
        ) : filteredData.length === 0 ? (
          <div className="text-center py-12">
            <DollarSign className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">No revenue data available</p>
            <p className="text-sm text-gray-400 mt-1">Revenue breakdown will appear here</p>
          </div>
        ) : (
          <>
            {viewMode === "bars" && renderBarChart()}
            {viewMode === "pie" && renderPieChart()}
            {viewMode === "list" && renderListView()}
          </>
        )}
      </div>

      {selectedCategory && (
        <div className={`${compact ? "px-4 pb-4" : "px-6 pb-6"} border-t border-gray-200 pt-4`}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: `${selectedCategory.color}15` }}
              >
                {selectedCategory.icon && (
                  <selectedCategory.icon className="w-4 h-4" style={{ color: selectedCategory.color }} />
                )}
              </div>
              <div>
                <p className="font-semibold text-gray-900">{selectedCategory.name} Details</p>
                {selectedCategory.description && (
                  <p className="text-xs text-gray-500">{selectedCategory.description}</p>
                )}
              </div>
            </div>
            <button
              onClick={() => setSelectedCategory(null)}
              className="p-1 hover:bg-gray-100 rounded-lg transition"
            >
              <ChevronUp className="w-4 h-4 text-gray-400" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500">Revenue</p>
              <p className="text-lg font-bold text-gray-900">{formatCurrency(selectedCategory.value)}</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500">Share</p>
              <p className="text-lg font-bold text-gray-900">{selectedCategory.percentage.toFixed(1)}%</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500">Growth</p>
              <p className={`text-lg font-bold ${selectedCategory.growth >= 0 ? "text-green-600" : "text-red-600"}`}>
                {selectedCategory.growth >= 0 ? "+" : ""}{selectedCategory.growth.toFixed(1)}%
              </p>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500">Transactions</p>
              <p className="text-lg font-bold text-gray-900">{selectedCategory.transactionCount || 0}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function RevenueBreakdownCompact({ data = [], className = "" }) {
  const total = data.reduce((sum, item) => sum + (item.value || 0), 0);
  const topCategories = [...data]
    .sort((a, b) => b.value - a.value)
    .slice(0, 3);

  return (
    <div className={`flex items-center gap-4 ${className}`}>
      {topCategories.map((item, index) => {
        const percentage = total > 0 ? (item.value / total) * 100 : 0;
        const color = CHART_COLORS[index % CHART_COLORS.length];

        return (
          <div key={item.id || index} className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: color }}
            />
            <span className="text-sm text-gray-600">{item.name}</span>
            <span className="text-sm font-semibold text-gray-900">{percentage.toFixed(0)}%</span>
          </div>
        );
      })}
    </div>
  );
}

export function RevenueBreakdownMini({ data = [], className = "" }) {
  const total = data.reduce((sum, item) => sum + (item.value || 0), 0);

  return (
    <div className={`h-2 bg-gray-100 rounded-full overflow-hidden flex ${className}`}>
      {data.map((item, index) => {
        const percentage = total > 0 ? (item.value / total) * 100 : 0;
        const color = item.color || CHART_COLORS[index % CHART_COLORS.length];

        return (
          <div
            key={item.id || index}
            className="h-full transition-all duration-500"
            style={{
              width: `${percentage}%`,
              backgroundColor: color
            }}
            title={`${item.name}: ${percentage.toFixed(1)}%`}
          />
        );
      })}
    </div>
  );
}