import React, { useState, useEffect, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  X, 
  User, 
  Calendar, 
  CreditCard, 
  DollarSign, 
  FileText,
  Download,
  Printer,
  Mail,
  Send,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Clock,
  XCircle,
  Copy,
  ExternalLink,
  Receipt,
  Building2,
  Phone,
  MapPin,
  Car,
  GraduationCap,
  Award,
  Banknote,
  Wallet,
  ArrowLeft,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  Edit,
  Trash2,
  MoreVertical,
  Share2,
  Link2,
  QrCode,
  Info,
  HelpCircle,
  MessageSquare,
  History,
  TrendingUp,
  TrendingDown,
  Percent,
  Tag,
  Gift,
  Zap,
  Shield,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Loader2,
  BadgeCheck,
  AlertTriangle,
  RotateCcw,
  Hash,
  Bookmark,
  Star,
  Flag
} from "lucide-react";
import { format, formatDistanceToNow, parseISO, differenceInDays } from "date-fns";
import { toast } from "sonner";

const PAYMENT_METHODS = {
  card: { label: "Credit/Debit Card", icon: CreditCard, color: "blue" },
  bank_transfer: { label: "Bank Transfer", icon: Building2, color: "green" },
  cash: { label: "Cash", icon: Banknote, color: "emerald" },
  paypal: { label: "PayPal", icon: Wallet, color: "indigo" },
  stripe: { label: "Stripe", icon: CreditCard, color: "purple" },
  direct_debit: { label: "Direct Debit", icon: RefreshCw, color: "cyan" },
  cheque: { label: "Cheque", icon: FileText, color: "amber" },
  voucher: { label: "Voucher/Gift Card", icon: Gift, color: "pink" },
  other: { label: "Other", icon: DollarSign, color: "gray" }
};

const PAYMENT_STATUS = {
  completed: { label: "Completed", icon: CheckCircle, color: "green", bgColor: "bg-green-100", textColor: "text-green-700" },
  pending: { label: "Pending", icon: Clock, color: "amber", bgColor: "bg-amber-100", textColor: "text-amber-700" },
  processing: { label: "Processing", icon: Loader2, color: "blue", bgColor: "bg-blue-100", textColor: "text-blue-700" },
  failed: { label: "Failed", icon: XCircle, color: "red", bgColor: "bg-red-100", textColor: "text-red-700" },
  refunded: { label: "Refunded", icon: RotateCcw, color: "purple", bgColor: "bg-purple-100", textColor: "text-purple-700" },
  partial_refund: { label: "Partially Refunded", icon: RotateCcw, color: "orange", bgColor: "bg-orange-100", textColor: "text-orange-700" },
  cancelled: { label: "Cancelled", icon: XCircle, color: "gray", bgColor: "bg-gray-100", textColor: "text-gray-700" },
  disputed: { label: "Disputed", icon: AlertTriangle, color: "red", bgColor: "bg-red-100", textColor: "text-red-700" }
};

const PAYMENT_TYPES = {
  lesson: { label: "Lesson Payment", icon: Car },
  package: { label: "Package Purchase", icon: GraduationCap },
  test_fee: { label: "Test Fee", icon: Award },
  booking_deposit: { label: "Booking Deposit", icon: Bookmark },
  cancellation_fee: { label: "Cancellation Fee", icon: XCircle },
  materials: { label: "Learning Materials", icon: FileText },
  insurance: { label: "Insurance", icon: Shield },
  subscription: { label: "Subscription", icon: RefreshCw },
  refund: { label: "Refund", icon: RotateCcw },
  adjustment: { label: "Adjustment", icon: Edit },
  other: { label: "Other", icon: DollarSign }
};

const TAX_RATES = {
  standard: { rate: 0.20, label: "Standard VAT (20%)" },
  reduced: { rate: 0.05, label: "Reduced VAT (5%)" },
  zero: { rate: 0, label: "Zero Rated" },
  exempt: { rate: 0, label: "VAT Exempt" }
};

export default function TransactionDrawer({ 
  transaction, 
  onClose, 
  student, 
  instructor, 
  vehicle,
  booking,
  invoice,
  school,
  relatedTransactions = [],
  onRefund,
  onResend,
  onEdit,
  onDelete,
  onPrint,
  onDownload,
  onEmail,
  onDispute,
  onMarkAsPaid,
  isLoading = false,
  canRefund = true,
  canEdit = true,
  canDelete = false,
  showRelatedTransactions = true
}) {
  const [activeTab, setActiveTab] = useState("details");
  const [showRefundModal, setShowRefundModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [refundAmount, setRefundAmount] = useState(0);
  const [refundReason, setRefundReason] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showTaxBreakdown, setShowTaxBreakdown] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (transaction) {
      setRefundAmount(transaction.amount || 0);
    }
  }, [transaction]);

  const taxDetails = useMemo(() => {
    if (!transaction?.amount) return null;
    
    const taxType = transaction.tax_type || "standard";
    const taxRate = TAX_RATES[taxType]?.rate || 0.20;
    const grossAmount = transaction.amount;
    const netAmount = grossAmount / (1 + taxRate);
    const taxAmount = grossAmount - netAmount;

    return {
      gross: grossAmount,
      net: netAmount,
      tax: taxAmount,
      rate: taxRate,
      label: TAX_RATES[taxType]?.label || "VAT"
    };
  }, [transaction]);

  const statusInfo = useMemo(() => {
    const status = transaction?.status || "pending";
    return PAYMENT_STATUS[status] || PAYMENT_STATUS.pending;
  }, [transaction]);

  const methodInfo = useMemo(() => {
    const method = transaction?.payment_method || "other";
    return PAYMENT_METHODS[method] || PAYMENT_METHODS.other;
  }, [transaction]);

  const typeInfo = useMemo(() => {
    const type = transaction?.payment_type || "other";
    return PAYMENT_TYPES[type] || PAYMENT_TYPES.other;
  }, [transaction]);

  const canBeRefunded = useMemo(() => {
    if (!canRefund || !transaction) return false;
    return ["completed", "partial_refund"].includes(transaction.status);
  }, [canRefund, transaction]);

  const refundedAmount = useMemo(() => {
    if (!transaction?.refunds) return 0;
    return transaction.refunds.reduce((sum, r) => sum + (r.amount || 0), 0);
  }, [transaction]);

  const remainingRefundable = useMemo(() => {
    return (transaction?.amount || 0) - refundedAmount;
  }, [transaction, refundedAmount]);

  const handleCopyTransactionId = useCallback(() => {
    if (transaction?.id) {
      navigator.clipboard.writeText(transaction.id);
      setCopied(true);
      toast.success("Transaction ID copied");
      setTimeout(() => setCopied(false), 2000);
    }
  }, [transaction]);

  const handleDownloadReceipt = useCallback(async () => {
    setIsProcessing(true);
    try {
      if (onDownload) {
        await onDownload(transaction);
      } else {
        toast.success("Receipt downloaded");
      }
    } catch (error) {
      toast.error("Failed to download receipt");
    } finally {
      setIsProcessing(false);
    }
  }, [transaction, onDownload]);

  const handlePrintReceipt = useCallback(async () => {
    setIsProcessing(true);
    try {
      if (onPrint) {
        await onPrint(transaction);
      } else {
        window.print();
        toast.success("Print dialog opened");
      }
    } catch (error) {
      toast.error("Failed to print receipt");
    } finally {
      setIsProcessing(false);
    }
  }, [transaction, onPrint]);

  const handleEmailReceipt = useCallback(async () => {
    setIsProcessing(true);
    try {
      if (onEmail) {
        await onEmail(transaction, student?.email);
      } else {
        toast.success("Receipt sent to " + (student?.email || "customer"));
      }
    } catch (error) {
      toast.error("Failed to send email");
    } finally {
      setIsProcessing(false);
    }
  }, [transaction, student, onEmail]);

  const handleRefund = useCallback(async () => {
    if (refundAmount <= 0 || refundAmount > remainingRefundable) {
      toast.error("Invalid refund amount");
      return;
    }

    setIsProcessing(true);
    try {
      if (onRefund) {
        await onRefund(transaction.id, {
          amount: refundAmount,
          reason: refundReason,
          partial: refundAmount < remainingRefundable
        });
      }
      toast.success(`Refund of €${refundAmount.toFixed(2)} processed`);
      setShowRefundModal(false);
    } catch (error) {
      toast.error("Failed to process refund");
    } finally {
      setIsProcessing(false);
    }
  }, [transaction, refundAmount, refundReason, remainingRefundable, onRefund]);

  const handleMarkAsPaid = useCallback(async () => {
    setIsProcessing(true);
    try {
      if (onMarkAsPaid) {
        await onMarkAsPaid(transaction.id);
      }
      toast.success("Transaction marked as paid");
    } catch (error) {
      toast.error("Failed to update transaction");
    } finally {
      setIsProcessing(false);
    }
  }, [transaction, onMarkAsPaid]);

  const handleDelete = useCallback(async () => {
    setIsProcessing(true);
    try {
      if (onDelete) {
        await onDelete(transaction.id);
      }
      toast.success("Transaction deleted");
      onClose();
    } catch (error) {
      toast.error("Failed to delete transaction");
    } finally {
      setIsProcessing(false);
      setShowDeleteConfirm(false);
    }
  }, [transaction, onDelete, onClose]);

  const formatDate = useCallback((dateString) => {
    if (!dateString) return "N/A";
    try {
      const date = new Date(dateString);
      return format(date, "PPP 'at' p");
    } catch {
      return "Invalid date";
    }
  }, []);

  const formatShortDate = useCallback((dateString) => {
    if (!dateString) return "N/A";
    try {
      const date = new Date(dateString);
      return format(date, "MMM d, yyyy");
    } catch {
      return "Invalid date";
    }
  }, []);

  if (!transaction) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 z-10">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 ${statusInfo.bgColor} rounded-xl flex items-center justify-center`}>
                  <statusInfo.icon className={`w-6 h-6 ${statusInfo.textColor}`} />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Transaction Details</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <button
                      onClick={handleCopyTransactionId}
                      className="text-sm text-gray-500 hover:text-gray-700 flex items-center gap-1"
                    >
                      <Hash className="w-3.5 h-3.5" />
                      {transaction.id?.substring(0, 12)}...
                      {copied ? (
                        <CheckCircle className="w-3.5 h-3.5 text-green-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition">
                    <MoreVertical className="w-5 h-5 text-gray-600" />
                  </button>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>
            </div>

            <div className="flex gap-1 mt-4">
              {[
                { id: "details", label: "Details" },
                { id: "breakdown", label: "Breakdown" },
                { id: "history", label: "History" }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-2 text-sm font-semibold rounded-lg transition ${
                    activeTab === tab.id
                      ? "bg-indigo-100 text-indigo-700"
                      : "text-gray-600 hover:bg-gray-100"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-200px)]">
            <div className="p-6">
              <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-6 text-white mb-6">
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    statusInfo.color === "green" ? "bg-green-400/30" :
                    statusInfo.color === "amber" ? "bg-amber-400/30" :
                    statusInfo.color === "red" ? "bg-red-400/30" :
                    "bg-white/20"
                  }`}>
                    {statusInfo.label}
                  </span>
                  <span className="text-sm text-white/80">
                    {formatDistanceToNow(new Date(transaction.payment_date || transaction.created_date), { addSuffix: true })}
                  </span>
                </div>
                <p className="text-sm text-white/70 mb-1">Amount</p>
                <p className="text-4xl font-bold mb-2">
                  €{transaction.amount?.toFixed(2)}
                </p>
                {refundedAmount > 0 && (
                  <p className="text-sm text-white/70">
                    €{refundedAmount.toFixed(2)} refunded
                  </p>
                )}
              </div>

              {activeTab === "details" && (
                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-3 mb-3">
                        <div className={`w-10 h-10 bg-${methodInfo.color}-100 rounded-lg flex items-center justify-center`}>
                          <methodInfo.icon className={`w-5 h-5 text-${methodInfo.color}-600`} />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Payment Method</p>
                          <p className="font-semibold text-gray-900">{methodInfo.label}</p>
                        </div>
                      </div>
                      {transaction.card_last_four && (
                        <p className="text-sm text-gray-600">
                          •••• •••• •••• {transaction.card_last_four}
                        </p>
                      )}
                    </div>

                    <div className="p-4 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                          <typeInfo.icon className="w-5 h-5 text-purple-600" />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Payment Type</p>
                          <p className="font-semibold text-gray-900">{typeInfo.label}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Calendar className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Transaction Date</p>
                        <p className="font-semibold text-gray-900">
                          {formatDate(transaction.payment_date || transaction.created_date)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {student && (
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                          {student.avatar_url ? (
                            <img src={student.avatar_url} alt="" className="w-10 h-10 rounded-lg object-cover" />
                          ) : (
                            <User className="w-5 h-5 text-indigo-600" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="text-xs text-gray-500">Student</p>
                          <p className="font-semibold text-gray-900">{student.full_name}</p>
                          {student.email && (
                            <p className="text-sm text-gray-600">{student.email}</p>
                          )}
                        </div>
                        {student.phone && (
                          <a 
                            href={`tel:${student.phone}`}
                            className="p-2 hover:bg-gray-200 rounded-lg transition"
                          >
                            <Phone className="w-5 h-5 text-gray-600" />
                          </a>
                        )}
                      </div>
                    </div>
                  )}

                  {instructor && (
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                          <Award className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Instructor</p>
                          <p className="font-semibold text-gray-900">{instructor.full_name}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {booking && (
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                          <Car className="w-5 h-5 text-amber-600" />
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Related Booking</p>
                          <p className="font-semibold text-gray-900">
                            {formatShortDate(booking.start_datetime)}
                          </p>
                          <p className="text-sm text-gray-600">{booking.lesson_type}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {invoice && (
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-cyan-100 rounded-lg flex items-center justify-center">
                            <Receipt className="w-5 h-5 text-cyan-600" />
                          </div>
                          <div>
                            <p className="text-xs text-gray-500">Invoice</p>
                            <p className="font-semibold text-gray-900">#{invoice.invoice_number}</p>
                          </div>
                        </div>
                        <button className="p-2 hover:bg-gray-200 rounded-lg transition">
                          <ExternalLink className="w-4 h-4 text-gray-600" />
                        </button>
                      </div>
                    </div>
                  )}

                  {transaction.notes && (
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <p className="text-xs text-gray-500 mb-1">Notes</p>
                      <p className="text-sm text-gray-700">{transaction.notes}</p>
                    </div>
                  )}

                  {transaction.reference && (
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <p className="text-xs text-gray-500 mb-1">Reference</p>
                      <p className="text-sm text-gray-700 font-mono">{transaction.reference}</p>
                    </div>
                  )}
                </div>
              )}

              {activeTab === "breakdown" && (
                <div className="space-y-4">
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <button
                      onClick={() => setShowTaxBreakdown(!showTaxBreakdown)}
                      className="w-full flex items-center justify-between"
                    >
                      <h3 className="font-semibold text-gray-900">Tax Breakdown</h3>
                      {showTaxBreakdown ? (
                        <ChevronUp className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      )}
                    </button>

                    <AnimatePresence>
                      {showTaxBreakdown && taxDetails && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="mt-4 space-y-3"
                        >
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Subtotal (Net)</span>
                            <span className="font-semibold text-gray-900">€{taxDetails.net.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">{taxDetails.label} ({(taxDetails.rate * 100).toFixed(0)}%)</span>
                            <span className="font-semibold text-gray-900">€{taxDetails.tax.toFixed(2)}</span>
                          </div>
                          <div className="border-t border-gray-300 pt-3 flex justify-between">
                            <span className="font-semibold text-gray-900">Total (Gross)</span>
                            <span className="font-bold text-gray-900 text-lg">€{taxDetails.gross.toFixed(2)}</span>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {transaction.discount_amount > 0 && (
                    <div className="p-4 bg-green-50 rounded-xl">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Tag className="w-5 h-5 text-green-600" />
                          <span className="text-green-700 font-medium">Discount Applied</span>
                        </div>
                        <span className="font-bold text-green-700">-€{transaction.discount_amount.toFixed(2)}</span>
                      </div>
                      {transaction.discount_code && (
                        <p className="text-sm text-green-600 mt-1">Code: {transaction.discount_code}</p>
                      )}
                    </div>
                  )}

                  {refundedAmount > 0 && (
                    <div className="p-4 bg-purple-50 rounded-xl">
                      <h4 className="font-semibold text-purple-900 mb-3">Refund History</h4>
                      <div className="space-y-2">
                        {(transaction.refunds || [{ amount: refundedAmount, date: transaction.refund_date }]).map((refund, idx) => (
                          <div key={idx} className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-2">
                              <RotateCcw className="w-4 h-4 text-purple-600" />
                              <span className="text-purple-700">
                                {refund.date ? formatShortDate(refund.date) : "Refund"}
                              </span>
                            </div>
                            <span className="font-semibold text-purple-900">-€{refund.amount.toFixed(2)}</span>
                          </div>
                        ))}
                        <div className="border-t border-purple-200 pt-2 mt-2 flex justify-between">
                          <span className="text-purple-700">Total Refunded</span>
                          <span className="font-bold text-purple-900">€{refundedAmount.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-purple-700">Net Amount</span>
                          <span className="font-bold text-purple-900">€{(transaction.amount - refundedAmount).toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {transaction.fees && transaction.fees.length > 0 && (
                    <div className="p-4 bg-gray-50 rounded-xl">
                      <h4 className="font-semibold text-gray-900 mb-3">Processing Fees</h4>
                      <div className="space-y-2">
                        {transaction.fees.map((fee, idx) => (
                          <div key={idx} className="flex justify-between text-sm">
                            <span className="text-gray-600">{fee.name}</span>
                            <span className="font-semibold text-gray-900">€{fee.amount.toFixed(2)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === "history" && (
                <div className="space-y-4">
                  <div className="relative">
                    <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200" />
                    
                    <div className="space-y-4">
                      {[
                        {
                          date: transaction.created_date,
                          title: "Transaction Created",
                          description: "Payment initiated",
                          icon: Clock,
                          color: "blue"
                        },
                        transaction.status === "completed" && {
                          date: transaction.payment_date || transaction.completed_date,
                          title: "Payment Completed",
                          description: `€${transaction.amount?.toFixed(2)} received via ${methodInfo.label}`,
                          icon: CheckCircle,
                          color: "green"
                        },
                        refundedAmount > 0 && {
                          date: transaction.refund_date,
                          title: "Refund Processed",
                          description: `€${refundedAmount.toFixed(2)} refunded`,
                          icon: RotateCcw,
                          color: "purple"
                        },
                        transaction.status === "failed" && {
                          date: transaction.failed_date,
                          title: "Payment Failed",
                          description: transaction.failure_reason || "Payment could not be processed",
                          icon: XCircle,
                          color: "red"
                        }
                      ].filter(Boolean).map((event, idx) => (
                        <div key={idx} className="relative flex gap-4 pl-8">
                          <div className={`absolute left-0 w-8 h-8 bg-${event.color}-100 rounded-full flex items-center justify-center`}>
                            <event.icon className={`w-4 h-4 text-${event.color}-600`} />
                          </div>
                          <div className="flex-1 pb-4">
                            <p className="font-semibold text-gray-900">{event.title}</p>
                            <p className="text-sm text-gray-600">{event.description}</p>
                            <p className="text-xs text-gray-400 mt-1">
                              {formatDate(event.date)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {showRelatedTransactions && relatedTransactions.length > 0 && (
                    <div className="mt-6">
                      <h4 className="font-semibold text-gray-900 mb-3">Related Transactions</h4>
                      <div className="space-y-2">
                        {relatedTransactions.map((related) => (
                          <div key={related.id} className="p-3 bg-gray-50 rounded-xl flex items-center justify-between">
                            <div>
                              <p className="font-semibold text-gray-900">€{related.amount?.toFixed(2)}</p>
                              <p className="text-xs text-gray-500">{formatShortDate(related.payment_date)}</p>
                            </div>
                            <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                              PAYMENT_STATUS[related.status]?.bgColor || "bg-gray-100"
                            } ${PAYMENT_STATUS[related.status]?.textColor || "text-gray-700"}`}>
                              {PAYMENT_STATUS[related.status]?.label || related.status}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4">
            <div className="flex flex-wrap gap-2">
              <button
                onClick={handleDownloadReceipt}
                disabled={isProcessing}
                className="flex-1 min-w-[120px] px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold text-sm transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Download className="w-4 h-4" />
                Download
              </button>
              <button
                onClick={handlePrintReceipt}
                disabled={isProcessing}
                className="flex-1 min-w-[120px] px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold text-sm transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Printer className="w-4 h-4" />
                Print
              </button>
              <button
                onClick={handleEmailReceipt}
                disabled={isProcessing || !student?.email}
                className="flex-1 min-w-[120px] px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-semibold text-sm transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Mail className="w-4 h-4" />
                Email
              </button>

              {transaction.status === "pending" && onMarkAsPaid && (
                <button
                  onClick={handleMarkAsPaid}
                  disabled={isProcessing}
                  className="flex-1 min-w-[120px] px-4 py-2.5 bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold text-sm transition flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <CheckCircle className="w-4 h-4" />
                  Mark Paid
                </button>
              )}

              {canBeRefunded && (
                <button
                  onClick={() => setShowRefundModal(true)}
                  disabled={isProcessing}
                  className="flex-1 min-w-[120px] px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold text-sm transition flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <RotateCcw className="w-4 h-4" />
                  Refund
                </button>
              )}
            </div>
          </div>
        </motion.div>

        <AnimatePresence>
          {showRefundModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4"
              onClick={() => setShowRefundModal(false)}
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                    <RotateCcw className="w-6 h-6 text-red-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">Issue Refund</h3>
                    <p className="text-sm text-gray-600">Maximum: €{remainingRefundable.toFixed(2)}</p>
                  </div>
                </div>

                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Refund Amount</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">€</span>
                      <input
                        type="number"
                        value={refundAmount}
                        onChange={(e) => setRefundAmount(Math.min(parseFloat(e.target.value) || 0, remainingRefundable))}
                        max={remainingRefundable}
                        step="0.01"
                        className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="flex gap-2 mt-2">
                      {[25, 50, 75, 100].map(percent => (
                        <button
                          key={percent}
                          onClick={() => setRefundAmount((remainingRefundable * percent) / 100)}
                          className="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded-lg text-xs font-medium text-gray-700"
                        >
                          {percent}%
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Reason (Optional)</label>
                    <textarea
                      value={refundReason}
                      onChange={(e) => setRefundReason(e.target.value)}
                      placeholder="Enter reason for refund..."
                      rows={3}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowRefundModal(false)}
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleRefund}
                    disabled={isProcessing || refundAmount <= 0}
                    className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isProcessing ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        <RotateCcw className="w-5 h-5" />
                        Refund €{refundAmount.toFixed(2)}
                      </>
                    )}
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showDeleteConfirm && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4"
              onClick={() => setShowDeleteConfirm(false)}
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl"
              >
                <div className="text-center">
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <AlertTriangle className="w-8 h-8 text-red-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Delete Transaction</h3>
                  <p className="text-gray-600 mb-6">
                    Are you sure you want to delete this transaction? This action cannot be undone.
                  </p>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowDeleteConfirm(false)}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleDelete}
                      disabled={isProcessing}
                      className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {isProcessing ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <>
                          <Trash2 className="w-5 h-5" />
                          Delete
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </AnimatePresence>
  );
}