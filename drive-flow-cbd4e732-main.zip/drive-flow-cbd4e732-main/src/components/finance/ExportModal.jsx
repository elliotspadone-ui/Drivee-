import React, { useState, useEffect, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  X, 
  Download, 
  FileText, 
  Table, 
  FileCode,
  Calendar,
  Filter,
  Settings,
  CheckCircle,
  Clock,
  AlertCircle,
  Loader2,
  ChevronDown,
  ChevronUp,
  Info,
  Building2,
  Globe,
  Percent,
  DollarSign,
  Receipt,
  Users,
  Car,
  CreditCard,
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  FileSpreadsheet,
  Mail,
  Send,
  Eye,
  Printer,
  Share2,
  Link2,
  Copy,
  RefreshCw,
  Archive,
  FolderOpen,
  HardDrive,
  Cloud,
  Shield,
  Lock,
  Bookmark,
  Star,
  Tag,
  Hash,
  Zap,
  Package
} from "lucide-react";
import { format, subDays, subMonths, startOfMonth, endOfMonth, startOfQuarter, endOfQuarter, startOfYear, endOfYear, subYears } from "date-fns";
import { toast } from "sonner";

const EXPORT_FORMATS = [
  { 
    id: "csv", 
    name: "CSV", 
    icon: Table, 
    description: "Comma-separated values for Excel/Sheets",
    extension: ".csv",
    mimeType: "text/csv"
  },
  { 
    id: "xlsx", 
    name: "Excel", 
    icon: FileSpreadsheet, 
    description: "Microsoft Excel workbook with multiple sheets",
    extension: ".xlsx",
    mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  },
  { 
    id: "pdf", 
    name: "PDF Report", 
    icon: FileText, 
    description: "Formatted report with charts and summaries",
    extension: ".pdf",
    mimeType: "application/pdf"
  },
  { 
    id: "json", 
    name: "JSON", 
    icon: FileCode, 
    description: "Structured data for accounting software",
    extension: ".json",
    mimeType: "application/json"
  },
  { 
    id: "xml", 
    name: "XML", 
    icon: FileCode, 
    description: "Universal data exchange format",
    extension: ".xml",
    mimeType: "application/xml"
  },
  { 
    id: "qbo", 
    name: "QuickBooks", 
    icon: Building2, 
    description: "QuickBooks Online import format",
    extension: ".qbo",
    mimeType: "application/qbo"
  }
];

const DATE_PRESETS = [
  { id: "today", label: "Today", getRange: () => ({ start: new Date(), end: new Date() }) },
  { id: "yesterday", label: "Yesterday", getRange: () => ({ start: subDays(new Date(), 1), end: subDays(new Date(), 1) }) },
  { id: "last_7_days", label: "Last 7 Days", getRange: () => ({ start: subDays(new Date(), 7), end: new Date() }) },
  { id: "last_30_days", label: "Last 30 Days", getRange: () => ({ start: subDays(new Date(), 30), end: new Date() }) },
  { id: "this_month", label: "This Month", getRange: () => ({ start: startOfMonth(new Date()), end: endOfMonth(new Date()) }) },
  { id: "last_month", label: "Last Month", getRange: () => ({ start: startOfMonth(subMonths(new Date(), 1)), end: endOfMonth(subMonths(new Date(), 1)) }) },
  { id: "this_quarter", label: "This Quarter", getRange: () => ({ start: startOfQuarter(new Date()), end: endOfQuarter(new Date()) }) },
  { id: "last_quarter", label: "Last Quarter", getRange: () => ({ start: startOfQuarter(subMonths(new Date(), 3)), end: endOfQuarter(subMonths(new Date(), 3)) }) },
  { id: "this_year", label: "This Year", getRange: () => ({ start: startOfYear(new Date()), end: endOfYear(new Date()) }) },
  { id: "last_year", label: "Last Year", getRange: () => ({ start: startOfYear(subYears(new Date(), 1)), end: endOfYear(subYears(new Date(), 1)) }) },
  { id: "custom", label: "Custom Range", getRange: () => null }
];

const TAX_REGIONS = [
  { id: "EU", label: "European Union", taxName: "VAT", defaultRate: 20, currency: "EUR" },
  { id: "UK", label: "United Kingdom", taxName: "VAT", defaultRate: 20, currency: "GBP" },
  { id: "US", label: "United States", taxName: "Sales Tax", defaultRate: 0, currency: "USD" },
  { id: "CA", label: "Canada", taxName: "GST/HST", defaultRate: 13, currency: "CAD" },
  { id: "AU", label: "Australia", taxName: "GST", defaultRate: 10, currency: "AUD" },
  { id: "CH", label: "Switzerland", taxName: "VAT", defaultRate: 7.7, currency: "CHF" },
  { id: "DE", label: "Germany", taxName: "VAT", defaultRate: 19, currency: "EUR" },
  { id: "FR", label: "France", taxName: "VAT", defaultRate: 20, currency: "EUR" },
  { id: "IE", label: "Ireland", taxName: "VAT", defaultRate: 23, currency: "EUR" },
  { id: "NL", label: "Netherlands", taxName: "VAT", defaultRate: 21, currency: "EUR" }
];

const DATA_SECTIONS = [
  { id: "transactions", label: "Transactions", icon: CreditCard, description: "All payment transactions" },
  { id: "invoices", label: "Invoices", icon: Receipt, description: "Invoice records and statuses" },
  { id: "refunds", label: "Refunds", icon: RefreshCw, description: "Refund history and details" },
  { id: "revenue", label: "Revenue Summary", icon: TrendingUp, description: "Revenue breakdowns by period" },
  { id: "tax", label: "Tax Report", icon: Percent, description: "Tax calculations and liability" },
  { id: "students", label: "Student Payments", icon: Users, description: "Payments grouped by student" },
  { id: "instructors", label: "Instructor Earnings", icon: Car, description: "Instructor payment summaries" },
  { id: "packages", label: "Package Sales", icon: Package, description: "Package purchase analytics" },
  { id: "reconciliation", label: "Reconciliation", icon: CheckCircle, description: "Payment reconciliation data" }
];

const DELIVERY_OPTIONS = [
  { id: "download", label: "Download Now", icon: Download, description: "Download file directly" },
  { id: "email", label: "Send via Email", icon: Mail, description: "Email the report" },
  { id: "schedule", label: "Schedule Report", icon: Clock, description: "Set up recurring exports" }
];

export default function ExportModal({ 
  onClose, 
  onExport,
  defaultFormat = "xlsx",
  defaultDateRange = "last_30_days",
  defaultSections = ["transactions", "invoices", "revenue"],
  availableData,
  school,
  userEmail,
  isLoading = false
}) {
  const [format, setFormat] = useState(defaultFormat);
  const [datePreset, setDatePreset] = useState(defaultDateRange);
  const [customStartDate, setCustomStartDate] = useState(format(subDays(new Date(), 30), "yyyy-MM-dd"));
  const [customEndDate, setCustomEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [selectedSections, setSelectedSections] = useState(defaultSections);
  const [taxRegion, setTaxRegion] = useState("EU");
  const [includeVAT, setIncludeVAT] = useState(true);
  const [includeSummary, setIncludeSummary] = useState(true);
  const [includeCharts, setIncludeCharts] = useState(true);
  const [groupBy, setGroupBy] = useState("day");
  const [currency, setCurrency] = useState("EUR");
  const [deliveryMethod, setDeliveryMethod] = useState("download");
  const [emailAddress, setEmailAddress] = useState(userEmail || "");
  const [scheduleFrequency, setScheduleFrequency] = useState("weekly");
  const [reportName, setReportName] = useState("");
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState("format");
  const [errors, setErrors] = useState({});

  const selectedRegion = useMemo(() => {
    return TAX_REGIONS.find(r => r.id === taxRegion);
  }, [taxRegion]);

  const dateRange = useMemo(() => {
    if (datePreset === "custom") {
      return {
        start: new Date(customStartDate),
        end: new Date(customEndDate)
      };
    }
    const preset = DATE_PRESETS.find(p => p.id === datePreset);
    return preset?.getRange() || { start: subDays(new Date(), 30), end: new Date() };
  }, [datePreset, customStartDate, customEndDate]);

  const selectedFormat = useMemo(() => {
    return EXPORT_FORMATS.find(f => f.id === format);
  }, [format]);

  useEffect(() => {
    if (taxRegion) {
      const region = TAX_REGIONS.find(r => r.id === taxRegion);
      if (region) {
        setCurrency(region.currency);
      }
    }
  }, [taxRegion]);

  useEffect(() => {
    const preset = DATE_PRESETS.find(p => p.id === datePreset);
    const formatStr = EXPORT_FORMATS.find(f => f.id === format)?.name || format.toUpperCase();
    const dateLabel = preset?.label || "Custom";
    setReportName(`Financial_Report_${dateLabel.replace(/\s+/g, "_")}_${format(new Date(), "yyyyMMdd")}`);
  }, [datePreset, format]);

  const toggleSection = useCallback((sectionId) => {
    setSelectedSections(prev => {
      if (prev.includes(sectionId)) {
        return prev.filter(s => s !== sectionId);
      }
      return [...prev, sectionId];
    });
  }, []);

  const selectAllSections = useCallback(() => {
    setSelectedSections(DATA_SECTIONS.map(s => s.id));
  }, []);

  const clearAllSections = useCallback(() => {
    setSelectedSections([]);
  }, []);

  const validateForm = useCallback(() => {
    const newErrors = {};

    if (selectedSections.length === 0) {
      newErrors.sections = "Please select at least one data section";
    }

    if (datePreset === "custom") {
      if (!customStartDate) {
        newErrors.startDate = "Start date is required";
      }
      if (!customEndDate) {
        newErrors.endDate = "End date is required";
      }
      if (customStartDate && customEndDate && new Date(customStartDate) > new Date(customEndDate)) {
        newErrors.endDate = "End date must be after start date";
      }
    }

    if (deliveryMethod === "email" && !emailAddress) {
      newErrors.email = "Email address is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [selectedSections, datePreset, customStartDate, customEndDate, deliveryMethod, emailAddress]);

  const generateExportConfig = useCallback(() => {
    return {
      format,
      formatDetails: selectedFormat,
      dateRange: {
        preset: datePreset,
        start: dateRange.start.toISOString(),
        end: dateRange.end.toISOString()
      },
      sections: selectedSections,
      taxSettings: {
        region: taxRegion,
        regionDetails: selectedRegion,
        includeVAT,
        taxRate: selectedRegion?.defaultRate || 0
      },
      displayOptions: {
        includeSummary,
        includeCharts: format === "pdf" ? includeCharts : false,
        groupBy,
        currency
      },
      delivery: {
        method: deliveryMethod,
        email: deliveryMethod === "email" ? emailAddress : null,
        schedule: deliveryMethod === "schedule" ? scheduleFrequency : null
      },
      metadata: {
        reportName,
        generatedAt: new Date().toISOString(),
        generatedBy: school?.name || "Driving School",
        version: "1.0"
      }
    };
  }, [
    format, selectedFormat, datePreset, dateRange, selectedSections,
    taxRegion, selectedRegion, includeVAT, includeSummary, includeCharts,
    groupBy, currency, deliveryMethod, emailAddress, scheduleFrequency,
    reportName, school
  ]);

  const handleExport = useCallback(async () => {
    if (!validateForm()) {
      toast.error("Please fix the errors before exporting");
      return;
    }

    setProcessing(true);

    try {
      const config = generateExportConfig();
      
      if (onExport) {
        await onExport(config);
      }

      if (deliveryMethod === "download") {
        toast.success(`${selectedFormat?.name} report generated successfully`);
      } else if (deliveryMethod === "email") {
        toast.success(`Report sent to ${emailAddress}`);
      } else if (deliveryMethod === "schedule") {
        toast.success(`${scheduleFrequency} report scheduled successfully`);
      }

      onClose();
    } catch (error) {
      toast.error("Failed to generate report. Please try again.");
      console.error("Export error:", error);
    } finally {
      setProcessing(false);
    }
  }, [validateForm, generateExportConfig, onExport, deliveryMethod, selectedFormat, emailAddress, scheduleFrequency, onClose]);

  const handlePreview = useCallback(() => {
    toast.info("Generating preview...");
  }, []);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 z-10">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center">
                  <Download className="w-6 h-6 text-indigo-600" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Export Financial Report</h2>
                  <p className="text-sm text-gray-500">
                    Generate comprehensive financial data exports
                  </p>
                </div>
              </div>
              <button 
                onClick={onClose} 
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            <div className="flex gap-1 mt-4 overflow-x-auto">
              {[
                { id: "format", label: "Format", icon: FileText },
                { id: "data", label: "Data", icon: Table },
                { id: "options", label: "Options", icon: Settings },
                { id: "delivery", label: "Delivery", icon: Send }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-2 text-sm font-semibold rounded-lg transition flex items-center gap-2 whitespace-nowrap ${
                    activeTab === tab.id
                      ? "bg-indigo-100 text-indigo-700"
                      : "text-gray-600 hover:bg-gray-100"
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-200px)] p-6">
            {activeTab === "format" && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">Export Format</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {EXPORT_FORMATS.map((fmt) => (
                      <button
                        key={fmt.id}
                        onClick={() => setFormat(fmt.id)}
                        className={`p-4 rounded-xl border-2 transition text-left ${
                          format === fmt.id 
                            ? "border-indigo-500 bg-indigo-50" 
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <fmt.icon className={`w-6 h-6 flex-shrink-0 ${
                            format === fmt.id ? "text-indigo-600" : "text-gray-400"
                          }`} />
                          <div>
                            <p className="font-semibold text-gray-900">{fmt.name}</p>
                            <p className="text-xs text-gray-500 mt-1">{fmt.description}</p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">Date Range</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
                    {DATE_PRESETS.slice(0, 8).map(preset => (
                      <button
                        key={preset.id}
                        onClick={() => setDatePreset(preset.id)}
                        className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
                          datePreset === preset.id
                            ? "bg-indigo-100 text-indigo-700 border-2 border-indigo-300"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200 border-2 border-transparent"
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 mb-4">
                    <button
                      onClick={() => setDatePreset("custom")}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
                        datePreset === "custom"
                          ? "bg-indigo-100 text-indigo-700 border-2 border-indigo-300"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200 border-2 border-transparent"
                      }`}
                    >
                      Custom Range
                    </button>
                  </div>

                  {datePreset === "custom" && (
                    <div className="grid md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-xl">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
                        <input
                          type="date"
                          value={customStartDate}
                          onChange={(e) => setCustomStartDate(e.target.value)}
                          className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                            errors.startDate ? "border-red-500" : "border-gray-300"
                          }`}
                        />
                        {errors.startDate && (
                          <p className="text-red-500 text-sm mt-1">{errors.startDate}</p>
                        )}
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
                        <input
                          type="date"
                          value={customEndDate}
                          onChange={(e) => setCustomEndDate(e.target.value)}
                          className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                            errors.endDate ? "border-red-500" : "border-gray-300"
                          }`}
                        />
                        {errors.endDate && (
                          <p className="text-red-500 text-sm mt-1">{errors.endDate}</p>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="mt-4 p-3 bg-indigo-50 rounded-xl">
                    <div className="flex items-center gap-2 text-sm text-indigo-700">
                      <Calendar className="w-4 h-4" />
                      <span className="font-medium">
                        {format(dateRange.start, "MMM d, yyyy")} — {format(dateRange.end, "MMM d, yyyy")}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "data" && (
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-gray-900">Data Sections</h3>
                    <div className="flex gap-2">
                      <button
                        onClick={selectAllSections}
                        className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
                      >
                        Select All
                      </button>
                      <span className="text-gray-300">|</span>
                      <button
                        onClick={clearAllSections}
                        className="text-sm text-gray-600 hover:text-gray-700 font-medium"
                      >
                        Clear All
                      </button>
                    </div>
                  </div>

                  {errors.sections && (
                    <p className="text-red-500 text-sm mb-3">{errors.sections}</p>
                  )}

                  <div className="grid md:grid-cols-2 gap-3">
                    {DATA_SECTIONS.map(section => (
                      <label
                        key={section.id}
                        className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition ${
                          selectedSections.includes(section.id)
                            ? "border-indigo-500 bg-indigo-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={selectedSections.includes(section.id)}
                          onChange={() => toggleSection(section.id)}
                          className="w-5 h-5 text-indigo-600 rounded mt-0.5"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <section.icon className={`w-4 h-4 ${
                              selectedSections.includes(section.id) ? "text-indigo-600" : "text-gray-400"
                            }`} />
                            <span className="font-medium text-gray-900">{section.label}</span>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{section.description}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-gray-50 rounded-xl">
                  <h4 className="font-semibold text-gray-900 mb-3">Group Data By</h4>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { id: "day", label: "Day" },
                      { id: "week", label: "Week" },
                      { id: "month", label: "Month" },
                      { id: "quarter", label: "Quarter" },
                      { id: "year", label: "Year" }
                    ].map(option => (
                      <button
                        key={option.id}
                        onClick={() => setGroupBy(option.id)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                          groupBy === option.id
                            ? "bg-indigo-600 text-white"
                            : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-100"
                        }`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === "options" && (
              <div className="space-y-6">
                <div className="p-4 bg-gray-50 rounded-xl">
                  <h3 className="font-semibold text-gray-900 mb-4">Tax & Compliance Settings</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Country/Region</label>
                      <select
                        value={taxRegion}
                        onChange={(e) => setTaxRegion(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      >
                        {TAX_REGIONS.map(region => (
                          <option key={region.id} value={region.id}>
                            {region.label} ({region.taxName} {region.defaultRate}%)
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Currency</label>
                        <select
                          value={currency}
                          onChange={(e) => setCurrency(e.target.value)}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                          <option value="EUR">EUR (€)</option>
                          <option value="GBP">GBP (£)</option>
                          <option value="USD">USD ($)</option>
                          <option value="CAD">CAD ($)</option>
                          <option value="AUD">AUD ($)</option>
                          <option value="CHF">CHF</option>
                        </select>
                      </div>
                    </div>

                    <label className="flex items-start gap-3 p-3 bg-white rounded-xl cursor-pointer">
                      <input
                        type="checkbox"
                        checked={includeVAT}
                        onChange={(e) => setIncludeVAT(e.target.checked)}
                        className="w-5 h-5 text-indigo-600 rounded mt-0.5"
                      />
                      <div>
                        <p className="font-medium text-gray-900">Include Tax Breakdown</p>
                        <p className="text-xs text-gray-500">Show detailed tax calculations for each transaction</p>
                      </div>
                    </label>
                  </div>
                </div>

                <div className="p-4 bg-gray-50 rounded-xl">
                  <h3 className="font-semibold text-gray-900 mb-4">Display Options</h3>
                  
                  <div className="space-y-3">
                    <label className="flex items-start gap-3 p-3 bg-white rounded-xl cursor-pointer">
                      <input
                        type="checkbox"
                        checked={includeSummary}
                        onChange={(e) => setIncludeSummary(e.target.checked)}
                        className="w-5 h-5 text-indigo-600 rounded mt-0.5"
                      />
                      <div>
                        <p className="font-medium text-gray-900">Include Executive Summary</p>
                        <p className="text-xs text-gray-500">Add overview with key metrics and insights</p>
                      </div>
                    </label>

                    {format === "pdf" && (
                      <label className="flex items-start gap-3 p-3 bg-white rounded-xl cursor-pointer">
                        <input
                          type="checkbox"
                          checked={includeCharts}
                          onChange={(e) => setIncludeCharts(e.target.checked)}
                          className="w-5 h-5 text-indigo-600 rounded mt-0.5"
                        />
                        <div>
                          <p className="font-medium text-gray-900">Include Visual Charts</p>
                          <p className="text-xs text-gray-500">Add charts and graphs to the PDF report</p>
                        </div>
                      </label>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => setShowAdvancedOptions(!showAdvancedOptions)}
                  className="flex items-center gap-2 text-sm font-medium text-indigo-600 hover:text-indigo-700"
                >
                  <Settings className="w-4 h-4" />
                  Advanced Options
                  {showAdvancedOptions ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                <AnimatePresence>
                  {showAdvancedOptions && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="p-4 bg-gray-50 rounded-xl space-y-4"
                    >
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Report Name</label>
                        <input
                          type="text"
                          value={reportName}
                          onChange={(e) => setReportName(e.target.value)}
                          placeholder="Enter custom report name"
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {activeTab === "delivery" && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">Delivery Method</h3>
                  <div className="space-y-3">
                    {DELIVERY_OPTIONS.map(option => (
                      <label
                        key={option.id}
                        className={`flex items-start gap-4 p-4 rounded-xl border-2 cursor-pointer transition ${
                          deliveryMethod === option.id
                            ? "border-indigo-500 bg-indigo-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <input
                          type="radio"
                          name="delivery"
                          checked={deliveryMethod === option.id}
                          onChange={() => setDeliveryMethod(option.id)}
                          className="w-5 h-5 text-indigo-600 mt-0.5"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <option.icon className={`w-5 h-5 ${
                              deliveryMethod === option.id ? "text-indigo-600" : "text-gray-400"
                            }`} />
                            <span className="font-semibold text-gray-900">{option.label}</span>
                          </div>
                          <p className="text-sm text-gray-500 mt-1">{option.description}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {deliveryMethod === "email" && (
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                    <input
                      type="email"
                      value={emailAddress}
                      onChange={(e) => {
                        setEmailAddress(e.target.value);
                        if (errors.email) setErrors(prev => ({ ...prev, email: null }));
                      }}
                      placeholder="Enter email address"
                      className={`w-full px-4 py-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                        errors.email ? "border-red-500" : "border-gray-300"
                      }`}
                    />
                    {errors.email && (
                      <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                    )}
                  </div>
                )}

                {deliveryMethod === "schedule" && (
                  <div className="p-4 bg-gray-50 rounded-xl space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Frequency</label>
                      <select
                        value={scheduleFrequency}
                        onChange={(e) => setScheduleFrequency(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      >
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly (Monday)</option>
                        <option value="biweekly">Bi-Weekly</option>
                        <option value="monthly">Monthly (1st)</option>
                        <option value="quarterly">Quarterly</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                      <input
                        type="email"
                        value={emailAddress}
                        onChange={(e) => setEmailAddress(e.target.value)}
                        placeholder="Enter email address"
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                )}

                <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl">
                  <h4 className="font-semibold text-indigo-900 mb-3">Export Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-indigo-700">Format</span>
                      <span className="font-medium text-indigo-900">{selectedFormat?.name}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-indigo-700">Date Range</span>
                      <span className="font-medium text-indigo-900">
                        {format(dateRange.start, "MMM d")} - {format(dateRange.end, "MMM d, yyyy")}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-indigo-700">Sections</span>
                      <span className="font-medium text-indigo-900">{selectedSections.length} selected</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-indigo-700">Tax Region</span>
                      <span className="font-medium text-indigo-900">{selectedRegion?.label}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="sticky bottom-0 bg-white border-t border-gray-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <button
                onClick={handlePreview}
                className="px-4 py-2.5 text-indigo-600 hover:bg-indigo-50 rounded-xl font-medium transition flex items-center gap-2"
              >
                <Eye className="w-4 h-4" />
                Preview
              </button>

              <div className="flex items-center gap-3">
                <button 
                  onClick={onClose} 
                  className="px-5 py-2.5 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleExport}
                  disabled={processing || isLoading}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold transition flex items-center gap-2 disabled:opacity-50"
                >
                  {processing || isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5" />
                      {deliveryMethod === "download" ? "Export Report" : 
                       deliveryMethod === "email" ? "Send Report" : "Schedule Report"}
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}