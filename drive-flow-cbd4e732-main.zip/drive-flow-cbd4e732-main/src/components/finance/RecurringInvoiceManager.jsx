import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Calendar,
  Plus,
  Trash2,
  Edit,
  CheckCircle,
  XCircle,
  Clock,
  DollarSign,
  Users,
  RefreshCw,
  Download,
  Filter,
  Search,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  MoreVertical,
  Copy,
  Play,
  Pause,
  Settings,
  Bell,
  BellOff,
  AlertCircle,
  AlertTriangle,
  Info,
  Eye,
  EyeOff,
  Mail,
  Send,
  FileText,
  History,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  CalendarDays,
  CalendarClock,
  Repeat,
  Receipt,
  CreditCard,
  Banknote,
  Building2,
  User,
  Package,
  Tag,
  Percent,
  Calculator,
  Save,
  X,
  Loader2,
  ExternalLink,
  Sparkles,
  Zap,
  Target,
  Award
} from "lucide-react";
import { format, addDays, addWeeks, addMonths, addYears, differenceInDays, parseISO, isAfter, isBefore, startOfMonth, endOfMonth, isWithinInterval } from "date-fns";
import { toast } from "sonner";

const FREQUENCY_OPTIONS = [
  { id: "weekly", label: "Weekly", days: 7, description: "Every week" },
  { id: "biweekly", label: "Bi-weekly", days: 14, description: "Every 2 weeks" },
  { id: "monthly", label: "Monthly", days: 30, description: "Every month" },
  { id: "quarterly", label: "Quarterly", days: 90, description: "Every 3 months" },
  { id: "semi_annually", label: "Semi-annually", days: 180, description: "Every 6 months" },
  { id: "annually", label: "Annually", days: 365, description: "Every year" }
];

const INVOICE_TEMPLATES = [
  { id: "lesson_package", label: "Lesson Package", icon: Package, defaultAmount: 500 },
  { id: "monthly_subscription", label: "Monthly Subscription", icon: Repeat, defaultAmount: 200 },
  { id: "test_preparation", label: "Test Preparation", icon: Award, defaultAmount: 150 },
  { id: "custom", label: "Custom", icon: FileText, defaultAmount: 0 }
];

const STATUS_CONFIG = {
  active: {
    label: "Active",
    icon: CheckCircle,
    bgColor: "bg-green-100",
    textColor: "text-green-700",
    borderColor: "border-green-200"
  },
  paused: {
    label: "Paused",
    icon: Pause,
    bgColor: "bg-amber-100",
    textColor: "text-amber-700",
    borderColor: "border-amber-200"
  },
  inactive: {
    label: "Inactive",
    icon: XCircle,
    bgColor: "bg-gray-100",
    textColor: "text-gray-700",
    borderColor: "border-gray-200"
  },
  expired: {
    label: "Expired",
    icon: Clock,
    bgColor: "bg-red-100",
    textColor: "text-red-700",
    borderColor: "border-red-200"
  }
};

const FILTER_OPTIONS = [
  { id: "all", label: "All Templates" },
  { id: "active", label: "Active" },
  { id: "paused", label: "Paused" },
  { id: "inactive", label: "Inactive" },
  { id: "due_soon", label: "Due Soon" }
];

const SORT_OPTIONS = [
  { id: "next_date", label: "Next Invoice Date" },
  { id: "amount", label: "Amount" },
  { id: "student", label: "Student Name" },
  { id: "created", label: "Created Date" },
  { id: "frequency", label: "Frequency" }
];

const mockApi = {
  list: async () => {
    return [];
  },
  create: async (data) => {
    return { ...data, id: `ri-${Date.now()}` };
  },
  update: async (id, data) => {
    return { ...data, id };
  },
  delete: async (id) => {},
  generateInvoice: async (templateId) => {
    return { id: `inv-${Date.now()}`, template_id: templateId };
  }
};

export default function RecurringInvoiceManager({
  students = [],
  onInvoiceGenerated,
  onTemplateChange
}) {
  const queryClient = useQueryClient();
  
  const [showForm, setShowForm] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [selectedTemplates, setSelectedTemplates] = useState(new Set());
  const [expandedTemplates, setExpandedTemplates] = useState(new Set());
  const [filter, setFilter] = useState("all");
  const [sortBy, setSortBy] = useState("next_date");
  const [sortDirection, setSortDirection] = useState("asc");
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState("list");

  const { data: recurringInvoices = [], isLoading, error, refetch } = useQuery({
    queryKey: ["recurringInvoices"],
    queryFn: () => mockApi.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => mockApi.create(data),
    onSuccess: (newTemplate) => {
      queryClient.invalidateQueries({ queryKey: ["recurringInvoices"] });
      setShowForm(false);
      setEditingTemplate(null);
      toast.success("Recurring invoice template created successfully");
      onTemplateChange?.(newTemplate);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create template");
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => mockApi.update(id, data),
    onSuccess: (updatedTemplate) => {
      queryClient.invalidateQueries({ queryKey: ["recurringInvoices"] });
      setShowForm(false);
      setEditingTemplate(null);
      toast.success("Recurring invoice template updated successfully");
      onTemplateChange?.(updatedTemplate);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update template");
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => mockApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["recurringInvoices"] });
      toast.success("Recurring invoice template deleted");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete template");
    }
  });

  const generateInvoiceMutation = useMutation({
    mutationFn: (templateId) => mockApi.generateInvoice(templateId),
    onSuccess: (invoice) => {
      queryClient.invalidateQueries({ queryKey: ["recurringInvoices"] });
      toast.success("Invoice generated successfully");
      onInvoiceGenerated?.(invoice);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to generate invoice");
    }
  });

  const filteredTemplates = useMemo(() => {
    let result = [...recurringInvoices];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(template => {
        const student = students.find(s => s.id === template.student_id);
        return (
          template.template_name?.toLowerCase().includes(query) ||
          student?.full_name?.toLowerCase().includes(query) ||
          student?.email?.toLowerCase().includes(query)
        );
      });
    }

    switch (filter) {
      case "active":
        result = result.filter(t => t.is_active && !t.is_paused);
        break;
      case "paused":
        result = result.filter(t => t.is_paused);
        break;
      case "inactive":
        result = result.filter(t => !t.is_active);
        break;
      case "due_soon":
        const today = new Date();
        const sevenDaysFromNow = addDays(today, 7);
        result = result.filter(t => {
          const nextDate = new Date(t.next_invoice_date);
          return isWithinInterval(nextDate, { start: today, end: sevenDaysFromNow });
        });
        break;
    }

    result.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case "next_date":
          comparison = new Date(a.next_invoice_date).getTime() - new Date(b.next_invoice_date).getTime();
          break;
        case "amount":
          comparison = a.total_amount - b.total_amount;
          break;
        case "student":
          const studentA = students.find(s => s.id === a.student_id);
          const studentB = students.find(s => s.id === b.student_id);
          comparison = (studentA?.full_name || "").localeCompare(studentB?.full_name || "");
          break;
        case "created":
          comparison = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
          break;
        case "frequency":
          const freqA = FREQUENCY_OPTIONS.find(f => f.id === a.frequency)?.days || 0;
          const freqB = FREQUENCY_OPTIONS.find(f => f.id === b.frequency)?.days || 0;
          comparison = freqA - freqB;
          break;
      }

      return sortDirection === "asc" ? comparison : -comparison;
    });

    return result;
  }, [recurringInvoices, filter, sortBy, sortDirection, searchQuery, students]);

  const summaryMetrics = useMemo(() => {
    const activeTemplates = recurringInvoices.filter(t => t.is_active && !t.is_paused);
    const pausedTemplates = recurringInvoices.filter(t => t.is_paused);
    const totalMonthlyRevenue = activeTemplates.reduce((sum, t) => {
      const frequency = FREQUENCY_OPTIONS.find(f => f.id === t.frequency);
      if (!frequency) return sum;
      const monthlyMultiplier = 30 / frequency.days;
      return sum + (t.total_amount * monthlyMultiplier);
    }, 0);

    const today = new Date();
    const dueSoon = recurringInvoices.filter(t => {
      const nextDate = new Date(t.next_invoice_date);
      return differenceInDays(nextDate, today) <= 7 && differenceInDays(nextDate, today) >= 0;
    });

    const totalGenerated = recurringInvoices.reduce((sum, t) => sum + t.invoices_generated, 0);

    return {
      total: recurringInvoices.length,
      active: activeTemplates.length,
      paused: pausedTemplates.length,
      inactive: recurringInvoices.length - activeTemplates.length - pausedTemplates.length,
      dueSoon: dueSoon.length,
      totalMonthlyRevenue,
      totalGenerated
    };
  }, [recurringInvoices]);

  const getStudent = useCallback((studentId: string) => {
    return students.find(s => s.id === studentId);
  }, [students]);

  const getTemplateStatus = useCallback((template: RecurringInvoice) => {
    if (!template.is_active) return STATUS_CONFIG.inactive;
    if (template.is_paused) return STATUS_CONFIG.paused;
    if (template.end_date && isAfter(new Date(), new Date(template.end_date))) {
      return STATUS_CONFIG.expired;
    }
    return STATUS_CONFIG.active;
  }, []);

  const toggleTemplateSelection = useCallback((templateId: string) => {
    setSelectedTemplates(prev => {
      const newSet = new Set(prev);
      if (newSet.has(templateId)) {
        newSet.delete(templateId);
      } else {
        newSet.add(templateId);
      }
      return newSet;
    });
  }, []);

  const toggleTemplateExpansion = useCallback((templateId: string) => {
    setExpandedTemplates(prev => {
      const newSet = new Set(prev);
      if (newSet.has(templateId)) {
        newSet.delete(templateId);
      } else {
        newSet.add(templateId);
      }
      return newSet;
    });
  }, []);

  const handleTogglePause = useCallback(async (template: RecurringInvoice) => {
    const newPausedState = !template.is_paused;
    await updateMutation.mutateAsync({
      id: template.id,
      data: { is_paused: newPausedState }
    });
    toast.success(newPausedState ? "Template paused" : "Template resumed");
  }, [updateMutation]);

  const handleDuplicate = useCallback((template: RecurringInvoice) => {
    const duplicatedTemplate = {
      ...template,
      template_name: `${template.template_name} (Copy)`,
      id: undefined,
      invoices_generated: 0,
      last_generated_date: undefined,
      created_at: new Date().toISOString()
    };
    delete (duplicatedTemplate as any).id;
    setEditingTemplate(duplicatedTemplate as any);
    setShowForm(true);
  }, []);

  const handleGenerateNow = useCallback(async (templateId: string) => {
    await generateInvoiceMutation.mutateAsync(templateId);
  }, [generateInvoiceMutation]);

  const handleBulkAction = useCallback(async (action: string) => {
    const templateIds = Array.from(selectedTemplates);
    
    switch (action) {
      case "pause":
        for (const id of templateIds) {
          await updateMutation.mutateAsync({ id, data: { is_paused: true } });
        }
        toast.success(`${templateIds.length} template(s) paused`);
        break;
      case "resume":
        for (const id of templateIds) {
          await updateMutation.mutateAsync({ id, data: { is_paused: false } });
        }
        toast.success(`${templateIds.length} template(s) resumed`);
        break;
      case "delete":
        if (confirm(`Delete ${templateIds.length} template(s)?`)) {
          for (const id of templateIds) {
            await deleteMutation.mutateAsync(id);
          }
          toast.success(`${templateIds.length} template(s) deleted`);
        }
        break;
    }
    
    setSelectedTemplates(new Set());
  }, [selectedTemplates, updateMutation, deleteMutation]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR"
    }).format(amount);
  };

  const TemplateCard = ({ template }) => {
    const student = getStudent(template.student_id);
    const status = getTemplateStatus(template);
    const StatusIcon = status.icon;
    const isExpanded = expandedTemplates.has(template.id);
    const isSelected = selectedTemplates.has(template.id);
    const frequency = FREQUENCY_OPTIONS.find(f => f.id === template.frequency);
    
    const daysUntilNext = differenceInDays(new Date(template.next_invoice_date), new Date());
    const isOverdue = daysUntilNext < 0;
    const isDueSoon = daysUntilNext >= 0 && daysUntilNext <= 7;

    return (
      <div
        className={`
          bg-white rounded-xl border transition-all duration-200
          ${isSelected ? "border-indigo-300 ring-2 ring-indigo-100" : "border-gray-200"}
          ${isExpanded ? "shadow-lg" : "hover:shadow-md"}
        `}
      >
        <div className="p-4">
          <div className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={isSelected}
              onChange={() => toggleTemplateSelection(template.id)}
              className="mt-1 w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
            />

            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold text-gray-900">{template.template_name}</h4>
                    <span className={`px-2 py-0.5 ${status.bgColor} ${status.textColor} rounded-full text-xs font-semibold flex items-center gap-1`}>
                      <StatusIcon className="w-3 h-3" />
                      {status.label}
                    </span>
                    {isDueSoon && (
                      <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-xs font-semibold">
                        Due Soon
                      </span>
                    )}
                    {isOverdue && (
                      <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs font-semibold">
                        Overdue
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">
                    {student?.full_name || "Unknown Student"}
                  </p>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleTogglePause(template)}
                    className="p-1.5 hover:bg-gray-100 rounded-lg transition"
                    title={template.is_paused ? "Resume" : "Pause"}
                  >
                    {template.is_paused ? (
                      <Play className="w-4 h-4 text-green-600" />
                    ) : (
                      <Pause className="w-4 h-4 text-amber-600" />
                    )}
                  </button>
                  <button
                    onClick={() => {
                      setEditingTemplate(template);
                      setShowForm(true);
                    }}
                    className="p-1.5 hover:bg-gray-100 rounded-lg transition"
                    title="Edit"
                  >
                    <Edit className="w-4 h-4 text-gray-600" />
                  </button>
                  <button
                    onClick={() => handleDuplicate(template)}
                    className="p-1.5 hover:bg-gray-100 rounded-lg transition"
                    title="Duplicate"
                  >
                    <Copy className="w-4 h-4 text-gray-600" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm("Delete this recurring invoice template?")) {
                        deleteMutation.mutate(template.id);
                      }
                    }}
                    className="p-1.5 hover:bg-red-50 rounded-lg transition"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
                <div className="p-2 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500">Amount</p>
                  <p className="font-semibold text-gray-900">{formatCurrency(template.total_amount)}</p>
                </div>
                <div className="p-2 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500">Frequency</p>
                  <p className="font-semibold text-gray-900">{frequency?.label || template.frequency}</p>
                </div>
                <div className="p-2 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500">Next Invoice</p>
                  <p className={`font-semibold ${isOverdue ? "text-red-600" : isDueSoon ? "text-amber-600" : "text-gray-900"}`}>
                    {format(new Date(template.next_invoice_date), "MMM d, yyyy")}
                  </p>
                </div>
                <div className="p-2 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500">Generated</p>
                  <p className="font-semibold text-gray-900">{template.invoices_generated} invoices</p>
                </div>
              </div>

              <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                <div className="flex items-center gap-3 text-xs text-gray-500">
                  {template.auto_send && (
                    <span className="flex items-center gap-1">
                      <Send className="w-3 h-3" />
                      Auto-send enabled
                    </span>
                  )}
                  {template.notification_days_before && (
                    <span className="flex items-center gap-1">
                      <Bell className="w-3 h-3" />
                      Notify {template.notification_days_before}d before
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleGenerateNow(template.id)}
                    disabled={generateInvoiceMutation.isPending}
                    className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-medium hover:bg-indigo-700 transition flex items-center gap-1 disabled:opacity-50"
                  >
                    {generateInvoiceMutation.isPending ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <Zap className="w-3 h-3" />
                    )}
                    Generate Now
                  </button>
                  <button
                    onClick={() => toggleTemplateExpansion(template.id)}
                    className="p-1.5 hover:bg-gray-100 rounded-lg transition"
                  >
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-gray-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {isExpanded && (
          <div className="px-4 pb-4 pt-2 border-t border-gray-100 bg-gray-50">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h5 className="text-sm font-semibold text-gray-700 mb-2">Invoice Items</h5>
                {template.items && template.items.length > 0 ? (
                  <div className="space-y-2">
                    {template.items.map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-white rounded-lg">
                        <span className="text-sm text-gray-700">{item.description}</span>
                        <span className="text-sm font-semibold text-gray-900">
                          {item.quantity} × {formatCurrency(item.unit_price)}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">No items defined</p>
                )}
              </div>

              <div>
                <h5 className="text-sm font-semibold text-gray-700 mb-2">Details</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Start Date:</span>
                    <span className="text-gray-900">{format(new Date(template.start_date), "MMM d, yyyy")}</span>
                  </div>
                  {template.end_date && (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">End Date:</span>
                      <span className="text-gray-900">{format(new Date(template.end_date), "MMM d, yyyy")}</span>
                    </div>
                  )}
                  {template.payment_terms && (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Payment Terms:</span>
                      <span className="text-gray-900">{template.payment_terms} days</span>
                    </div>
                  )}
                  {template.tax_rate !== undefined && (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Tax Rate:</span>
                      <span className="text-gray-900">{template.tax_rate}%</span>
                    </div>
                  )}
                  {template.discount_percent !== undefined && template.discount_percent > 0 && (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Discount:</span>
                      <span className="text-gray-900">{template.discount_percent}%</span>
                    </div>
                  )}
                </div>

                {template.notes && (
                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <p className="text-xs text-gray-500 mb-1">Notes</p>
                    <p className="text-sm text-gray-700">{template.notes}</p>
                  </div>
                )}
              </div>
            </div>

            {template.last_generated_date && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <History className="w-4 h-4" />
                  Last generated: {format(new Date(template.last_generated_date), "MMM d, yyyy 'at' h:mm a")}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-gray-900">Recurring Invoices</h3>
          <p className="text-sm text-gray-500">Manage automated billing schedules</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => refetch()}
            disabled={isLoading}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
            title="Refresh"
          >
            <RefreshCw className={`w-5 h-5 text-gray-600 ${isLoading ? "animate-spin" : ""}`} />
          </button>
          <button
            onClick={() => {
              setEditingTemplate(null);
              setShowForm(true);
            }}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Template
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Repeat className="w-5 h-5 text-indigo-600" />
            <span className="text-sm font-medium text-indigo-600">Total Templates</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{summaryMetrics.total}</p>
          <p className="text-xs text-gray-500">{summaryMetrics.active} active</p>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-5 h-5 text-green-600" />
            <span className="text-sm font-medium text-green-600">Monthly Revenue</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(summaryMetrics.totalMonthlyRevenue)}</p>
          <p className="text-xs text-gray-500">estimated recurring</p>
        </div>

        <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-amber-600" />
            <span className="text-sm font-medium text-amber-600">Due Soon</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{summaryMetrics.dueSoon}</p>
          <p className="text-xs text-gray-500">within 7 days</p>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-600">Total Generated</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{summaryMetrics.totalGenerated}</p>
          <p className="text-xs text-gray-500">invoices created</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search templates or students..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {FILTER_OPTIONS.map(option => (
                <option key={option.id} value={option.id}>{option.label}</option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {SORT_OPTIONS.map(option => (
                <option key={option.id} value={option.id}>{option.label}</option>
              ))}
            </select>

            <button
              onClick={() => setSortDirection(prev => prev === "asc" ? "desc" : "asc")}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
            >
              {sortDirection === "asc" ? (
                <ChevronUp className="w-5 h-5 text-gray-600" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-600" />
              )}
            </button>
          </div>
        </div>

        {selectedTemplates.size > 0 && (
          <div className="mt-4 p-3 bg-indigo-50 rounded-lg flex items-center justify-between">
            <span className="text-sm text-indigo-700 font-medium">
              {selectedTemplates.size} template(s) selected
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleBulkAction("pause")}
                className="px-3 py-1.5 bg-amber-100 text-amber-700 rounded-lg text-sm font-medium hover:bg-amber-200 transition"
              >
                Pause
              </button>
              <button
                onClick={() => handleBulkAction("resume")}
                className="px-3 py-1.5 bg-green-100 text-green-700 rounded-lg text-sm font-medium hover:bg-green-200 transition"
              >
                Resume
              </button>
              <button
                onClick={() => handleBulkAction("delete")}
                className="px-3 py-1.5 bg-red-100 text-red-700 rounded-lg text-sm font-medium hover:bg-red-200 transition"
              >
                Delete
              </button>
              <button
                onClick={() => setSelectedTemplates(new Set())}
                className="px-3 py-1.5 text-gray-600 hover:bg-gray-100 rounded-lg text-sm font-medium transition"
              >
                Clear
              </button>
            </div>
          </div>
        )}
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        </div>
      ) : filteredTemplates.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-xl border border-gray-200">
          <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-900 font-medium mb-1">No Recurring Invoices</p>
          <p className="text-sm text-gray-500 mb-4">
            {searchQuery || filter !== "all"
              ? "No templates match your filters"
              : "Set up automated billing schedules for your students"
            }
          </p>
          <button
            onClick={() => {
              setEditingTemplate(null);
              setShowForm(true);
            }}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition inline-flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Create First Template
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredTemplates.map(template => (
            <TemplateCard key={template.id} template={template} />
          ))}
        </div>
      )}

      {showForm && (
        <RecurringInvoiceForm
          template={editingTemplate}
          students={students}
          onSubmit={async (data) => {
            if (editingTemplate?.id) {
              await updateMutation.mutateAsync({ id: editingTemplate.id, data });
            } else {
              await createMutation.mutateAsync(data);
            }
          }}
          onClose={() => {
            setShowForm(false);
            setEditingTemplate(null);
          }}
          isSubmitting={createMutation.isPending || updateMutation.isPending}
        />
      )}
    </div>
  );
}

function RecurringInvoiceForm({
  template,
  students,
  onSubmit,
  onClose,
  isSubmitting
}) {
  const [formData, setFormData] = useState({
    template_name: template?.template_name || "",
    student_id: template?.student_id || "",
    frequency: template?.frequency || "monthly",
    total_amount: template?.total_amount || 0,
    start_date: template?.start_date || format(new Date(), "yyyy-MM-dd"),
    end_date: template?.end_date || "",
    is_active: template?.is_active ?? true,
    items: template?.items || [],
    notes: template?.notes || "",
    payment_terms: template?.payment_terms || 14,
    auto_send: template?.auto_send ?? true,
    notification_days_before: template?.notification_days_before || 3,
    tax_rate: template?.tax_rate || 0,
    discount_percent: template?.discount_percent || 0
  });

  const [items, setItems] = useState(template?.items || [
    { id: "1", description: "", quantity: 1, unit_price: 0, total: 0 }
  ]);

  const calculatedTotal = useMemo(() => {
    const subtotal = items.reduce((sum, item) => sum + (item.quantity * item.unit_price), 0);
    const taxAmount = subtotal * ((formData.tax_rate || 0) / 100);
    const discountAmount = subtotal * ((formData.discount_percent || 0) / 100);
    return subtotal + taxAmount - discountAmount;
  }, [items, formData.tax_rate, formData.discount_percent]);

  const handleItemChange = (index, field, value) => {
    setItems(prev => {
      const newItems = [...prev];
      newItems[index] = {
        ...newItems[index],
        [field]: value,
        total: field === "quantity" || field === "unit_price"
          ? (field === "quantity" ? value : newItems[index].quantity) *
            (field === "unit_price" ? value : newItems[index].unit_price)
          : newItems[index].total
      };
      return newItems;
    });
  };

  const addItem = () => {
    setItems(prev => [
      ...prev,
      { id: `${Date.now()}`, description: "", quantity: 1, unit_price: 0, total: 0 }
    ]);
  };

  const removeItem = (index) => {
    setItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const nextInvoiceDate = formData.start_date || format(new Date(), "yyyy-MM-dd");
    
    await onSubmit({
      ...formData,
      items,
      total_amount: calculatedTotal,
      next_invoice_date: nextInvoiceDate,
      invoices_generated: template?.invoices_generated || 0
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold text-gray-900">
              {template ? "Edit Recurring Invoice" : "New Recurring Invoice"}
            </h3>
            <p className="text-sm text-gray-500">Set up automated billing schedule</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Template Name *
              </label>
              <input
                type="text"
                value={formData.template_name}
                onChange={(e) => setFormData(prev => ({ ...prev, template_name: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="e.g., Monthly Lesson Package"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Student *
              </label>
              <select
                value={formData.student_id}
                onChange={(e) => setFormData(prev => ({ ...prev, student_id: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              >
                <option value="">Select a student</option>
                {students.map(student => (
                  <option key={student.id} value={student.id}>
                    {student.full_name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Frequency *
              </label>
              <select
                value={formData.frequency}
                onChange={(e) => setFormData(prev => ({ ...prev, frequency: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              >
                {FREQUENCY_OPTIONS.map(option => (
                  <option key={option.id} value={option.id}>
                    {option.label} - {option.description}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Payment Terms (days)
              </label>
              <input
                type="number"
                value={formData.payment_terms}
                onChange={(e) => setFormData(prev => ({ ...prev, payment_terms: parseInt(e.target.value) || 0 }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min="0"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Start Date *
              </label>
              <input
                type="date"
                value={formData.start_date}
                onChange={(e) => setFormData(prev => ({ ...prev, start_date: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                End Date (optional)
              </label>
              <input
                type="date"
                value={formData.end_date}
                onChange={(e) => setFormData(prev => ({ ...prev, end_date: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-gray-700">Invoice Items</label>
              <button
                type="button"
                onClick={addItem}
                className="text-sm text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                Add Item
              </button>
            </div>
            <div className="space-y-2">
              {items.map((item, index) => (
                <div key={item.id} className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                  <input
                    type="text"
                    value={item.description}
                    onChange={(e) => handleItemChange(index, "description", e.target.value)}
                    placeholder="Description"
                    className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => handleItemChange(index, "quantity", parseInt(e.target.value) || 0)}
                    placeholder="Qty"
                    className="w-20 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    min="1"
                  />
                  <input
                    type="number"
                    value={item.unit_price}
                    onChange={(e) => handleItemChange(index, "unit_price", parseFloat(e.target.value) || 0)}
                    placeholder="Price"
                    className="w-24 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    min="0"
                    step="0.01"
                  />
                  <span className="w-24 text-right font-semibold text-gray-900">
                    €{(item.quantity * item.unit_price).toFixed(2)}
                  </span>
                  {items.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeItem(index)}
                      className="p-1 hover:bg-red-100 rounded-lg transition"
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Tax Rate (%)
              </label>
              <input
                type="number"
                value={formData.tax_rate}
                onChange={(e) => setFormData(prev => ({ ...prev, tax_rate: parseFloat(e.target.value) || 0 }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min="0"
                max="100"
                step="0.1"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Discount (%)
              </label>
              <input
                type="number"
                value={formData.discount_percent}
                onChange={(e) => setFormData(prev => ({ ...prev, discount_percent: parseFloat(e.target.value) || 0 }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min="0"
                max="100"
                step="0.1"
              />
            </div>
            <div className="p-3 bg-indigo-50 rounded-lg">
              <p className="text-xs text-indigo-600 font-medium">Total Amount</p>
              <p className="text-2xl font-bold text-gray-900">€{calculatedTotal.toFixed(2)}</p>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes (optional)
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              rows={3}
              placeholder="Additional notes for this recurring invoice..."
            />
          </div>

          <div className="space-y-3">
            <label className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={formData.is_active}
                onChange={(e) => setFormData(prev => ({ ...prev, is_active: e.target.checked }))}
                className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
              />
              <div>
                <p className="font-medium text-gray-900">Active</p>
                <p className="text-xs text-gray-500">Enable automatic invoice generation</p>
              </div>
            </label>

            <label className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={formData.auto_send}
                onChange={(e) => setFormData(prev => ({ ...prev, auto_send: e.target.checked }))}
                className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
              />
              <div>
                <p className="font-medium text-gray-900">Auto-send Invoice</p>
                <p className="text-xs text-gray-500">Automatically email invoice to student</p>
              </div>
            </label>

            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Bell className="w-5 h-5 text-gray-400" />
              <div className="flex-1">
                <p className="font-medium text-gray-900">Notification</p>
                <p className="text-xs text-gray-500">Days before to send reminder</p>
              </div>
              <input
                type="number"
                value={formData.notification_days_before}
                onChange={(e) => setFormData(prev => ({ ...prev, notification_days_before: parseInt(e.target.value) || 0 }))}
                className="w-20 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min="0"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg font-medium transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition flex items-center gap-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  {template ? "Update Template" : "Create Template"}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}