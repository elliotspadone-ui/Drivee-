import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  CreditCard,
  Lock,
  CheckCircle,
  AlertCircle,
  Loader2,
  ExternalLink,
  Shield,
  Wallet,
  Building2,
  Smartphone,
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import { motion } from "framer-motion";

const PAYMENT_METHODS = [
  { id: "card", name: "Credit/Debit Card", icon: CreditCard, description: "Visa, Mastercard, Amex" },
  { id: "bank_transfer", name: "Bank Transfer", icon: Building2, description: "Direct bank transfer" },
  { id: "digital_wallet", name: "Digital Wallet", icon: Smartphone, description: "Apple Pay, Google Pay" },
];

export default function PaymentGateway({
  invoice,
  student,
  onPaymentSuccess,
  onClose,
}) {
  const queryClient = useQueryClient();
  const [selectedMethod, setSelectedMethod] = useState("card");
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);
  const [cardDetails, setCardDetails] = useState({
    number: "",
    expiry: "",
    cvv: "",
    name: "",
  });

  const amountDue = invoice.total_amount - (invoice.amount_paid || 0);

  const updateInvoiceMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Invoice.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invoices"] });
      queryClient.invalidateQueries({ queryKey: ["payments"] });
    },
  });

  const createPaymentMutation = useMutation({
    mutationFn: (data) => base44.entities.Payment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["payments"] });
    },
  });

  const handlePayment = async () => {
    if (selectedMethod === "card") {
      if (!cardDetails.number || !cardDetails.expiry || !cardDetails.cvv || !cardDetails.name) {
        toast.error("Please fill in all card details");
        return;
      }
    }

    setIsProcessing(true);

    try {
      // Simulate payment gateway processing
      await new Promise((resolve) => setTimeout(resolve, 2000));

      // Create payment record
      await createPaymentMutation.mutateAsync({
        school_id: invoice.school_id,
        student_id: invoice.student_id,
        booking_id: invoice.booking_id,
        amount: amountDue,
        currency: "EUR",
        payment_method: selectedMethod,
        payment_type: "lesson",
        status: "completed",
        transaction_id: `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
        payment_date: new Date().toISOString(),
        notes: `Payment for invoice ${invoice.invoice_number}`,
      });

      // Update invoice status
      await updateInvoiceMutation.mutateAsync({
        id: invoice.id,
        data: {
          status: "paid",
          amount_paid: invoice.total_amount,
          payment_method: selectedMethod,
        },
      });

      setPaymentComplete(true);
      toast.success("Payment successful!");
      onPaymentSuccess?.(invoice);

      // Close after showing success
      setTimeout(() => {
        onClose?.();
      }, 2000);
    } catch (error) {
      console.error("Payment failed:", error);
      toast.error("Payment failed. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || "";
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    return parts.length ? parts.join(" ") : value;
  };

  const formatExpiry = (value) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    if (v.length >= 2) {
      return v.substring(0, 2) + "/" + v.substring(2, 4);
    }
    return v;
  };

  if (paymentComplete) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center py-12"
      >
        <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-10 h-10 text-emerald-600" />
        </div>
        <h3 className="text-2xl font-bold text-zinc-900 mb-2">Payment Successful!</h3>
        <p className="text-zinc-600 mb-4">
          Your payment of €{amountDue.toFixed(2)} has been processed.
        </p>
        <p className="text-sm text-zinc-500">
          A receipt has been sent to {student?.email || "your email"}.
        </p>
      </motion.div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Invoice Summary */}
      <div className="bg-zinc-50 rounded-xl p-4 border border-zinc-200">
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm text-zinc-600">Invoice</p>
          <p className="text-sm font-semibold text-zinc-900">{invoice.invoice_number}</p>
        </div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm text-zinc-600">Student</p>
          <p className="text-sm font-medium text-zinc-900">{student?.full_name}</p>
        </div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm text-zinc-600">Due Date</p>
          <p className="text-sm text-zinc-900">
            {invoice.due_date && format(parseISO(invoice.due_date), "MMM d, yyyy")}
          </p>
        </div>
        <div className="h-px bg-zinc-200 my-3" />
        <div className="flex items-center justify-between">
          <p className="text-base font-semibold text-zinc-900">Amount Due</p>
          <p className="text-2xl font-bold text-indigo-600">€{amountDue.toFixed(2)}</p>
        </div>
      </div>

      {/* Payment Methods */}
      <div>
        <p className="text-sm font-semibold text-zinc-700 mb-3">Payment Method</p>
        <div className="grid grid-cols-1 gap-3">
          {PAYMENT_METHODS.map((method) => {
            const Icon = method.icon;
            return (
              <button
                key={method.id}
                onClick={() => setSelectedMethod(method.id)}
                className={`flex items-center gap-4 p-4 rounded-xl border-2 transition ${
                  selectedMethod === method.id
                    ? "border-indigo-500 bg-indigo-50"
                    : "border-zinc-200 hover:border-zinc-300"
                }`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  selectedMethod === method.id ? "bg-indigo-600 text-white" : "bg-zinc-100 text-zinc-600"
                }`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-zinc-900">{method.name}</p>
                  <p className="text-sm text-zinc-500">{method.description}</p>
                </div>
                {selectedMethod === method.id && (
                  <CheckCircle className="w-5 h-5 text-indigo-600 ml-auto" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Card Details */}
      {selectedMethod === "card" && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="space-y-4"
        >
          <div>
            <label className="block text-sm font-medium text-zinc-700 mb-1.5">
              Cardholder Name
            </label>
            <input
              type="text"
              value={cardDetails.name}
              onChange={(e) => setCardDetails({ ...cardDetails, name: e.target.value })}
              placeholder="John Doe"
              className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-700 mb-1.5">
              Card Number
            </label>
            <div className="relative">
              <input
                type="text"
                value={cardDetails.number}
                onChange={(e) => setCardDetails({ ...cardDetails, number: formatCardNumber(e.target.value) })}
                placeholder="1234 5678 9012 3456"
                maxLength={19}
                className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
              />
              <CreditCard className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-zinc-700 mb-1.5">
                Expiry Date
              </label>
              <input
                type="text"
                value={cardDetails.expiry}
                onChange={(e) => setCardDetails({ ...cardDetails, expiry: formatExpiry(e.target.value) })}
                placeholder="MM/YY"
                maxLength={5}
                className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-700 mb-1.5">
                CVV
              </label>
              <input
                type="text"
                value={cardDetails.cvv}
                onChange={(e) => setCardDetails({ ...cardDetails, cvv: e.target.value.replace(/\D/g, "").slice(0, 4) })}
                placeholder="123"
                maxLength={4}
                className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
              />
            </div>
          </div>
        </motion.div>
      )}

      {selectedMethod === "bank_transfer" && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="bg-blue-50 rounded-xl p-4 border border-blue-200"
        >
          <p className="text-sm font-medium text-blue-900 mb-2">Bank Transfer Details</p>
          <div className="space-y-2 text-sm text-blue-800">
            <p><span className="text-blue-600">IBAN:</span> FR76 1234 5678 9012 3456 7890 123</p>
            <p><span className="text-blue-600">BIC:</span> BNPAFRPP</p>
            <p><span className="text-blue-600">Reference:</span> {invoice.invoice_number}</p>
          </div>
        </motion.div>
      )}

      {/* Security Notice */}
      <div className="flex items-center gap-3 text-sm text-zinc-500">
        <Shield className="w-5 h-5 text-emerald-600" />
        <span>Your payment is secured with 256-bit SSL encryption</span>
      </div>

      {/* Pay Button */}
      <button
        onClick={handlePayment}
        disabled={isProcessing}
        className="w-full py-4 rounded-xl bg-indigo-600 text-white font-bold text-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition flex items-center justify-center gap-3"
      >
        {isProcessing ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            Processing...
          </>
        ) : (
          <>
            <Lock className="w-5 h-5" />
            Pay €{amountDue.toFixed(2)}
          </>
        )}
      </button>
    </div>
  );
}