import React from "react";
import { TrendingUp, Award, Target, Star } from "lucide-react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function LeadScoringDashboard({ leadScores, students }) {
  const gradeDistribution = {
    A: leadScores.filter(l => l.grade === 'A').length,
    B: leadScores.filter(l => l.grade === 'B').length,
    C: leadScores.filter(l => l.grade === 'C').length,
    D: leadScores.filter(l => l.grade === 'D').length,
    F: leadScores.filter(l => l.grade === 'F').length
  };

  const pieData = Object.entries(gradeDistribution).map(([grade, count]) => ({
    name: `Grade ${grade}`,
    value: count
  }));

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#6b7280'];

  const topLeads = leadScores
    .sort((a, b) => b.total_score - a.total_score)
    .slice(0, 10)
    .map(score => {
      const student = students.find(s => s.id === score.student_id);
      return { ...score, student_name: student?.full_name || 'Unknown' };
    });

  const scoringActions = [
    { action: "Booking completed", points: 50 },
    { action: "Email opened", points: 5 },
    { action: "Email clicked", points: 15 },
    { action: "Package purchased", points: 100 },
    { action: "Referral made", points: 75 },
    { action: "Review submitted", points: 30 }
  ];

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <Star className="w-8 h-8 text-yellow-500" />
            <span className="text-sm font-semibold text-gray-700">A-Grade</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">{gradeDistribution.A}</p>
          <p className="text-xs text-muted mt-2">Hot Leads</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <TrendingUp className="w-8 h-8 text-blue-500" />
            <span className="text-sm font-semibold text-gray-700">B-Grade</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">{gradeDistribution.B}</p>
          <p className="text-xs text-muted mt-2">Warm Leads</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <Target className="w-8 h-8 text-orange-500" />
            <span className="text-sm font-semibold text-gray-700">C-Grade</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">{gradeDistribution.C}</p>
          <p className="text-xs text-muted mt-2">Need Nurturing</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <Award className="w-8 h-8 text-gray-400" />
            <span className="text-sm font-semibold text-gray-700">D/F-Grade</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">
            {gradeDistribution.D + gradeDistribution.F}
          </p>
          <p className="text-xs text-muted mt-2">Low Priority</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Grade Distribution */}
        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Lead Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Scoring Actions */}
        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Point System</h3>
          <div className="space-y-3">
            {scoringActions.map((action, index) => (
              <div key={index} className="neo-inset p-4 rounded-xl flex items-center justify-between">
                <span className="text-sm text-gray-700">{action.action}</span>
                <span className="font-bold text-indigo-600">+{action.points}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Leads */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Top Leads</h3>
        <div className="space-y-2">
          {topLeads.map((lead, index) => (
            <div key={lead.id} className="neo-inset p-4 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                  lead.grade === 'A' ? 'bg-green-500' :
                  lead.grade === 'B' ? 'bg-blue-500' :
                  lead.grade === 'C' ? 'bg-orange-500' : 'bg-gray-500'
                }`}>
                  {index + 1}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{lead.student_name}</p>
                  <p className="text-xs text-muted">Grade {lead.grade}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-gray-900">{lead.total_score}</p>
                <p className="text-xs text-muted">points</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}