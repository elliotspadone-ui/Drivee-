import React, { useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, TrendingUp, Clock, Users, Mail, MessageSquare, Gift, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function AICampaignSuggestions({ students, bookings, onCreateCampaign }) {
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);

  const analyzeAndSuggest = async () => {
    setLoading(true);
    try {
      // Analyze abandoned bookings
      const now = new Date();
      const sevenDaysAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
      const abandonedStudents = students.filter(s => {
        const lastBooking = bookings
          .filter(b => b.student_id === s.id)
          .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
        
        return lastBooking && 
               new Date(lastBooking.created_date) < sevenDaysAgo && 
               lastBooking.status === 'cancelled';
      });

      // Analyze inactive students
      const thirtyDaysAgo = new Date(now - 30 * 24 * 60 * 60 * 1000);
      const inactiveStudents = students.filter(s => {
        const recentBookings = bookings.filter(b => 
          b.student_id === s.id && 
          new Date(b.created_date) > thirtyDaysAgo
        );
        return recentBookings.length === 0 && s.is_active;
      });

      // Analyze referral potential
      const topPerformers = students.filter(s => 
        s.total_lessons_completed >= 5 && 
        s.is_active
      ).slice(0, 20);

      // Get booking patterns
      const bookingsByHour = {};
      bookings.forEach(b => {
        const hour = new Date(b.start_datetime).getHours();
        bookingsByHour[hour] = (bookingsByHour[hour] || 0) + 1;
      });

      const peakHours = Object.entries(bookingsByHour)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([hour]) => parseInt(hour));

      const offPeakHours = [9, 10, 11, 13, 14].filter(h => !peakHours.includes(h));

      // Use AI to generate campaign suggestions
      const aiPrompt = `Analyze this driving school data and suggest 3-5 marketing campaigns:
      
- ${abandonedStudents.length} students abandoned bookings in the last 7 days
- ${inactiveStudents.length} students haven't booked in 30+ days
- ${topPerformers.length} high-performing students eligible for referral program
- Off-peak hours available: ${offPeakHours.join(', ')}:00
- Peak booking hours: ${peakHours.join(', ')}:00

For each campaign suggestion, provide:
1. Campaign name
2. Target segment (abandoned/inactive/referral/off-peak)
3. Recommended discount/offer (10-30%)
4. Email subject line
5. Brief email body template
6. Optimal send time (day of week and hour)
7. Expected conversion rate (realistic estimate)
8. SMS message option (160 chars max)

Return as JSON array with these exact fields: name, segment, discount, subject, body, sendTime, expectedConversion, smsMessage`;

      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt: aiPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            campaigns: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  segment: { type: "string" },
                  discount: { type: "number" },
                  subject: { type: "string" },
                  body: { type: "string" },
                  sendTime: { type: "string" },
                  expectedConversion: { type: "number" },
                  smsMessage: { type: "string" }
                }
              }
            }
          }
        }
      });

      const campaignSuggestions = aiResponse.campaigns.map(c => ({
        ...c,
        targetCount: 
          c.segment === 'abandoned' ? abandonedStudents.length :
          c.segment === 'inactive' ? inactiveStudents.length :
          c.segment === 'referral' ? topPerformers.length :
          students.length * 0.3,
        targetAudience: 
          c.segment === 'abandoned' ? 'custom' :
          c.segment === 'inactive' ? 'inactive_students' :
          c.segment === 'referral' ? 'active_students' :
          'all_students'
      }));

      setSuggestions(campaignSuggestions);
      toast.success("AI generated campaign suggestions!");
    } catch (error) {
      toast.error("Failed to generate suggestions");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateFromSuggestion = (suggestion) => {
    const scheduleDate = new Date();
    const [day, time] = suggestion.sendTime.split(' at ');
    
    // Calculate next occurrence of the suggested day
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const targetDay = days.indexOf(day);
    const currentDay = scheduleDate.getDay();
    const daysUntil = (targetDay - currentDay + 7) % 7 || 7;
    scheduleDate.setDate(scheduleDate.getDate() + daysUntil);
    
    // Set time
    const [hours] = time.split(':');
    scheduleDate.setHours(parseInt(hours), 0, 0, 0);

    onCreateCampaign({
      name: suggestion.name,
      campaign_type: suggestion.segment === 'off-peak' ? 'off_peak_slots' : 
                     suggestion.segment === 'referral' ? 'referral' : 
                     suggestion.segment === 'inactive' ? 'reactivation' : 'package_promotion',
      target_audience: suggestion.targetAudience,
      email_subject: suggestion.subject,
      email_body: suggestion.body,
      offer_details: {
        discount_percentage: suggestion.discount,
        promo_code: suggestion.name.toUpperCase().replace(/\s+/g, '').slice(0, 10)
      },
      schedule_date: scheduleDate.toISOString(),
      status: 'scheduled'
    });
  };

  return (
    <div className="neo-surface p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900">AI Campaign Suggestions</h3>
            <p className="text-sm text-muted">Smart recommendations based on your data</p>
          </div>
        </div>
        <Button
          onClick={analyzeAndSuggest}
          disabled={loading}
          className="neo-button px-6 py-3 gradient-primary text-white font-semibold flex items-center gap-2"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
          {loading ? "Analyzing..." : "Generate Suggestions"}
        </Button>
      </div>

      {suggestions.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {suggestions.map((suggestion, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="neo-inset p-6 rounded-2xl hover:shadow-lg transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">{suggestion.name}</h4>
                  <span className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded-full font-semibold">
                    {suggestion.segment}
                  </span>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-purple-600">{suggestion.discount}%</p>
                  <p className="text-xs text-muted">discount</p>
                </div>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center gap-2 text-sm">
                  <Users className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-700">{Math.round(suggestion.targetCount)} students</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-700">{suggestion.sendTime}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-700">{suggestion.expectedConversion}% conversion</span>
                </div>
              </div>

              <div className="neo-inset p-3 rounded-xl mb-3">
                <p className="text-xs font-semibold text-gray-900 mb-1">Email Subject:</p>
                <p className="text-xs text-gray-700">{suggestion.subject}</p>
              </div>

              {suggestion.smsMessage && (
                <div className="neo-inset p-3 rounded-xl mb-4">
                  <div className="flex items-center gap-2 mb-1">
                    <MessageSquare className="w-3 h-3 text-gray-500" />
                    <p className="text-xs font-semibold text-gray-900">SMS Option:</p>
                  </div>
                  <p className="text-xs text-gray-700">{suggestion.smsMessage}</p>
                </div>
              )}

              <Button
                onClick={() => handleCreateFromSuggestion(suggestion)}
                className="neo-button w-full py-2 text-sm font-semibold"
              >
                Create Campaign
              </Button>
            </motion.div>
          ))}
        </div>
      )}

      {!loading && suggestions.length === 0 && (
        <div className="text-center py-12">
          <Sparkles className="w-16 h-16 mx-auto mb-4 text-gray-300" />
          <p className="text-gray-500 mb-4">Click "Generate Suggestions" to get AI-powered campaign ideas</p>
          <p className="text-sm text-muted">Our AI will analyze your student data and booking patterns</p>
        </div>
      )}
    </div>
  );
}