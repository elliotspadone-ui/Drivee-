import React from "react";
import { Mail, Eye, MousePointer, ShoppingCart, TrendingUp } from "lucide-react";

export default function CampaignAnalytics({ campaign }) {
  const openRate = campaign.recipients_count > 0 
    ? ((campaign.opened_count / campaign.recipients_count) * 100).toFixed(1)
    : 0;
  
  const clickRate = campaign.recipients_count > 0
    ? ((campaign.clicked_count / campaign.recipients_count) * 100).toFixed(1)
    : 0;
  
  const conversionRate = campaign.recipients_count > 0
    ? ((campaign.converted_count / campaign.recipients_count) * 100).toFixed(1)
    : 0;

  const metrics = [
    { label: "Sent", value: campaign.recipients_count, icon: Mail, color: "blue" },
    { label: "Opened", value: campaign.opened_count, rate: `${openRate}%`, icon: Eye, color: "green" },
    { label: "Clicked", value: campaign.clicked_count, rate: `${clickRate}%`, icon: MousePointer, color: "purple" },
    { label: "Converted", value: campaign.converted_count, rate: `${conversionRate}%`, icon: ShoppingCart, color: "orange" },
  ];

  return (
    <div className="neo-surface p-6 rounded-2xl">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-semibold text-gray-900">Campaign Performance</h3>
        {campaign.revenue_generated > 0 && (
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-600" />
            <span className="text-xl font-bold text-green-600">
              €{campaign.revenue_generated.toFixed(2)}
            </span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {metrics.map((metric, index) => (
          <div key={index} className="neo-inset p-4 rounded-xl text-center">
            <metric.icon className={`w-6 h-6 text-${metric.color}-600 mx-auto mb-2`} />
            <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
            <p className="text-xs text-muted">{metric.label}</p>
            {metric.rate && (
              <p className="text-xs font-semibold text-green-600 mt-1">{metric.rate}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}