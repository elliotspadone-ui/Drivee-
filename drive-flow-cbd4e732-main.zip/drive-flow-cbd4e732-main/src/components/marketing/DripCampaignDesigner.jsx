import React, { useState } from "react";
import { Plus, Mail, MessageSquare, Clock, Trash2, ArrowDown } from "lucide-react";
import { motion } from "framer-motion";

export default function DripCampaignDesigner({ campaign, onSave }) {
  const [steps, setSteps] = useState(campaign?.steps || []);
  const [name, setName] = useState(campaign?.name || "");
  const [triggerEvent, setTriggerEvent] = useState(campaign?.trigger_event || "student_registered");

  const addStep = () => {
    const newStep = {
      step_number: steps.length + 1,
      delay_days: 1,
      channel: "email",
      subject: "",
      content: ""
    };
    setSteps([...steps, newStep]);
  };

  const updateStep = (index, updates) => {
    const updated = [...steps];
    updated[index] = { ...updated[index], ...updates };
    setSteps(updated);
  };

  const deleteStep = (index) => {
    setSteps(steps.filter((_, i) => i !== index));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Campaign Setup */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Drip Campaign Setup</h3>
        
        <div className="space-y-4">
          <div>
            <label className="text-sm font-semibold text-gray-900 mb-2 block">Campaign Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Welcome Series"
              className="neo-button w-full px-4 py-3 rounded-xl"
            />
          </div>

          <div>
            <label className="text-sm font-semibold text-gray-900 mb-2 block">Trigger Event</label>
            <select
              value={triggerEvent}
              onChange={(e) => setTriggerEvent(e.target.value)}
              className="neo-button w-full px-4 py-3 rounded-xl"
            >
              <option value="student_registered">Student Registered</option>
              <option value="package_purchased">Package Purchased</option>
              <option value="lesson_completed">Lesson Completed</option>
              <option value="manual_enrollment">Manual Enrollment</option>
            </select>
          </div>
        </div>
      </div>

      {/* Drip Steps */}
      <div className="space-y-4">
        {steps.map((step, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="neo-surface p-6 rounded-3xl"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="neo-inset w-10 h-10 rounded-xl flex items-center justify-center font-bold text-indigo-600">
                  {index + 1}
                </div>
                <h3 className="font-bold text-gray-900">Step {index + 1}</h3>
              </div>
              <button
                onClick={() => deleteStep(index)}
                className="neo-button p-2 rounded-xl text-red-600"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-xs font-semibold text-gray-900 mb-2 block">
                  <Clock className="w-4 h-4 inline mr-1" />
                  Delay (days)
                </label>
                <input
                  type="number"
                  min="0"
                  value={step.delay_days}
                  onChange={(e) => updateStep(index, { delay_days: parseInt(e.target.value) })}
                  className="neo-button w-full px-4 py-3 rounded-xl"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-900 mb-2 block">Channel</label>
                <select
                  value={step.channel}
                  onChange={(e) => updateStep(index, { channel: e.target.value })}
                  className="neo-button w-full px-4 py-3 rounded-xl"
                >
                  <option value="email">Email</option>
                  <option value="sms">SMS</option>
                  <option value="push">Push Notification</option>
                </select>
              </div>
            </div>

            {step.channel === 'email' && (
              <>
                <input
                  type="text"
                  value={step.subject}
                  onChange={(e) => updateStep(index, { subject: e.target.value })}
                  placeholder="Email Subject"
                  className="neo-button w-full px-4 py-3 rounded-xl mb-3"
                />
                <textarea
                  value={step.content}
                  onChange={(e) => updateStep(index, { content: e.target.value })}
                  placeholder="Email content..."
                  className="neo-button w-full px-4 py-3 rounded-xl h-32 resize-none"
                />
              </>
            )}

            {step.channel === 'sms' && (
              <textarea
                value={step.content}
                onChange={(e) => updateStep(index, { content: e.target.value })}
                placeholder="SMS message (160 characters max)..."
                maxLength={160}
                className="neo-button w-full px-4 py-3 rounded-xl h-24 resize-none"
              />
            )}

            {index < steps.length - 1 && (
              <div className="flex justify-center mt-4">
                <ArrowDown className="w-6 h-6 text-gray-400" />
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Add Step Button */}
      <button
        onClick={addStep}
        className="neo-button w-full py-4 rounded-2xl flex items-center justify-center gap-2 font-semibold text-indigo-600"
      >
        <Plus className="w-5 h-5" />
        Add Step
      </button>

      {/* Save Button */}
      <button
        onClick={() => onSave({ name, trigger_event: triggerEvent, steps })}
        className="neo-button w-full py-4 gradient-primary text-white font-bold text-lg rounded-2xl"
      >
        Save Drip Campaign
      </button>
    </div>
  );
}