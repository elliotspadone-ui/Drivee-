import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Save, Mail, Users, Tag, Calendar } from "lucide-react";

export default function CampaignForm({ campaign, onClose, onSave, students }) {
  const [formData, setFormData] = useState(campaign || {
    name: "",
    description: "",
    campaign_type: "package_promotion",
    target_audience: "all_students",
    email_subject: "",
    email_body: "",
    offer_details: {
      discount_percentage: 0,
      discount_amount: 0,
      promo_code: ""
    },
    schedule_date: "",
    status: "draft"
  });

  const handleSubmit = () => {
    const targetedStudents = getTargetedStudents();
    onSave({
      ...formData,
      recipients_count: targetedStudents.length
    });
  };

  const getTargetedStudents = () => {
    if (formData.target_audience === "all_students") return students;
    if (formData.target_audience === "active_students") return students.filter(s => s.is_active);
    if (formData.target_audience === "inactive_students") return students.filter(s => !s.is_active);
    if (formData.target_audience === "new_students") {
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      return students.filter(s => new Date(s.created_date) > thirtyDaysAgo);
    }
    return students;
  };

  const targetedCount = getTargetedStudents().length;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="neo-surface p-8 rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-1">
                {campaign ? "Edit Campaign" : "Create Campaign"}
              </h2>
              <p className="text-sm text-muted">Design and schedule your marketing campaign</p>
            </div>
            <button onClick={onClose} className="neo-button p-3 rounded-xl">
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="md:col-span-2">
              <label className="block text-sm font-semibold text-gray-900 mb-2">Campaign Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full neo-inset px-4 py-3 rounded-xl focus:outline-none"
                placeholder="Summer Package Sale"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">Campaign Type</label>
              <select
                value={formData.campaign_type}
                onChange={(e) => setFormData({ ...formData, campaign_type: e.target.value })}
                className="w-full neo-inset px-4 py-3 rounded-xl focus:outline-none"
              >
                <option value="package_promotion">Package Promotion</option>
                <option value="off_peak_slots">Off-Peak Slots</option>
                <option value="referral">Referral Program</option>
                <option value="reactivation">Reactivation</option>
                <option value="seasonal">Seasonal Offer</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">Target Audience</label>
              <select
                value={formData.target_audience}
                onChange={(e) => setFormData({ ...formData, target_audience: e.target.value })}
                className="w-full neo-inset px-4 py-3 rounded-xl focus:outline-none"
              >
                <option value="all_students">All Students</option>
                <option value="active_students">Active Students</option>
                <option value="inactive_students">Inactive Students</option>
                <option value="new_students">New Students (Last 30 Days)</option>
              </select>
              <p className="text-xs text-muted mt-1">{targetedCount} students will receive this</p>
            </div>
          </div>

          <div className="neo-inset p-6 rounded-2xl mb-6">
            <h3 className="font-semibold text-gray-900 mb-4">Offer Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Discount %</label>
                <input
                  type="number"
                  value={formData.offer_details.discount_percentage}
                  onChange={(e) => setFormData({
                    ...formData,
                    offer_details: { ...formData.offer_details, discount_percentage: parseFloat(e.target.value) }
                  })}
                  className="w-full neo-inset px-4 py-3 rounded-xl focus:outline-none"
                  placeholder="20"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Discount Amount (€)</label>
                <input
                  type="number"
                  value={formData.offer_details.discount_amount}
                  onChange={(e) => setFormData({
                    ...formData,
                    offer_details: { ...formData.offer_details, discount_amount: parseFloat(e.target.value) }
                  })}
                  className="w-full neo-inset px-4 py-3 rounded-xl focus:outline-none"
                  placeholder="50"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Promo Code</label>
                <input
                  type="text"
                  value={formData.offer_details.promo_code}
                  onChange={(e) => setFormData({
                    ...formData,
                    offer_details: { ...formData.offer_details, promo_code: e.target.value }
                  })}
                  className="w-full neo-inset px-4 py-3 rounded-xl focus:outline-none"
                  placeholder="SUMMER2025"
                />
              </div>
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-900 mb-2">Email Subject</label>
            <input
              type="text"
              value={formData.email_subject}
              onChange={(e) => setFormData({ ...formData, email_subject: e.target.value })}
              className="w-full neo-inset px-4 py-3 rounded-xl focus:outline-none"
              placeholder="🎉 Special Offer: 20% Off All Packages!"
            />
          </div>

          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-900 mb-2">Email Body</label>
            <textarea
              value={formData.email_body}
              onChange={(e) => setFormData({ ...formData, email_body: e.target.value })}
              className="w-full neo-inset px-4 py-3 rounded-xl focus:outline-none h-48 resize-none"
              placeholder="Hi {student_name},&#10;&#10;We're excited to offer you 20% off all lesson packages! Book now and save on your journey to getting your license.&#10;&#10;Use code SUMMER2025 at checkout.&#10;&#10;Best regards,&#10;Your Driving School"
            />
            <p className="text-xs text-muted mt-2">Use {"{student_name}"} to personalize the message</p>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-900 mb-2">Schedule Date (Optional)</label>
            <input
              type="datetime-local"
              value={formData.schedule_date}
              onChange={(e) => setFormData({ ...formData, schedule_date: e.target.value })}
              className="w-full neo-inset px-4 py-3 rounded-xl focus:outline-none"
            />
            <p className="text-xs text-muted mt-1">Leave empty to send immediately</p>
          </div>

          <div className="flex gap-3">
            <button onClick={onClose} className="neo-button flex-1 py-3 font-semibold">
              Cancel
            </button>
            <button
              onClick={() => {
                setFormData({ ...formData, status: 'draft' });
                handleSubmit();
              }}
              className="neo-button flex-1 py-3 font-semibold"
            >
              Save as Draft
            </button>
            <button
              onClick={() => {
                setFormData({ ...formData, status: formData.schedule_date ? 'scheduled' : 'sent' });
                handleSubmit();
              }}
              className="neo-button flex-1 py-3 gradient-primary text-white font-semibold flex items-center justify-center gap-2"
            >
              <Mail className="w-5 h-5" />
              {formData.schedule_date ? 'Schedule Campaign' : 'Send Now'}
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}