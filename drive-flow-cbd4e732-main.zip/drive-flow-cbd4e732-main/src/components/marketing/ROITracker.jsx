import React from "react";
import { DollarSign, TrendingUp, Users, Target, ArrowUpRight } from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function ROITracker({ campaigns, attributions }) {
  const calculateROI = (campaign) => {
    const revenue = attributions
      .filter(a => a.campaign_id === campaign.id)
      .reduce((sum, a) => sum + (a.conversion_value || 0), 0);
    
    const cost = campaign.budget || 0;
    const roi = cost > 0 ? ((revenue - cost) / cost) * 100 : 0;

    return { revenue, cost, roi };
  };

  const campaignStats = campaigns.map(campaign => ({
    ...campaign,
    ...calculateROI(campaign),
    conversions: attributions.filter(a => a.campaign_id === campaign.id).length
  }));

  const totalRevenue = campaignStats.reduce((sum, c) => sum + c.revenue, 0);
  const totalSpend = campaignStats.reduce((sum, c) => sum + c.cost, 0);
  const totalROI = totalSpend > 0 ? ((totalRevenue - totalSpend) / totalSpend) * 100 : 0;

  const revenueByChannel = {
    email: attributions.filter(a => a.touchpoint_type.includes('email')).reduce((sum, a) => sum + (a.conversion_value || 0), 0),
    sms: attributions.filter(a => a.touchpoint_type.includes('sms')).reduce((sum, a) => sum + (a.conversion_value || 0), 0),
    push: attributions.filter(a => a.touchpoint_type.includes('push')).reduce((sum, a) => sum + (a.conversion_value || 0), 0)
  };

  const channelData = Object.entries(revenueByChannel).map(([channel, revenue]) => ({
    channel: channel.toUpperCase(),
    revenue
  }));

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <DollarSign className="w-8 h-8 text-green-500" />
            <span className="text-sm font-semibold text-green-700">Revenue</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">${totalRevenue.toLocaleString()}</p>
          <p className="text-xs text-muted mt-2">Total attributed revenue</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <Target className="w-8 h-8 text-red-500" />
            <span className="text-sm font-semibold text-red-700">Spend</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">${totalSpend.toLocaleString()}</p>
          <p className="text-xs text-muted mt-2">Marketing investment</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <TrendingUp className="w-8 h-8 text-indigo-500" />
            <span className="text-sm font-semibold text-indigo-700">ROI</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">{totalROI.toFixed(0)}%</p>
          <p className="text-xs text-muted mt-2">Return on investment</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <Users className="w-8 h-8 text-purple-500" />
            <span className="text-sm font-semibold text-purple-700">Conversions</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">{attributions.length}</p>
          <p className="text-xs text-muted mt-2">Total conversions</p>
        </div>
      </div>

      {/* Revenue by Channel */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Revenue by Channel</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={channelData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="channel" stroke="#6b7280" />
            <YAxis stroke="#6b7280" />
            <Tooltip />
            <Bar dataKey="revenue" fill="url(#gradient)" radius={[8, 8, 0, 0]} />
            <defs>
              <linearGradient id="gradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#667eea" />
                <stop offset="100%" stopColor="#764ba2" />
              </linearGradient>
            </defs>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Campaign Performance */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Campaign Performance</h3>
        <div className="space-y-3">
          {campaignStats
            .sort((a, b) => b.roi - a.roi)
            .map((campaign, index) => (
              <div key={campaign.id} className="neo-inset p-4 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                      index === 0 ? 'bg-green-500' : index === 1 ? 'bg-blue-500' : 'bg-purple-500'
                    }`}>
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{campaign.name}</p>
                      <p className="text-xs text-muted">{campaign.conversions} conversions</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-gray-900">{campaign.roi.toFixed(0)}%</p>
                    <p className="text-xs text-muted">${campaign.revenue.toLocaleString()} revenue</p>
                  </div>
                </div>
                <div className="relative h-2 bg-gray-200 rounded-full overflow-hidden mt-2">
                  <div 
                    className="absolute h-full bg-gradient-to-r from-green-500 to-emerald-500"
                    style={{ width: `${Math.min(100, campaign.roi)}%` }}
                  />
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}