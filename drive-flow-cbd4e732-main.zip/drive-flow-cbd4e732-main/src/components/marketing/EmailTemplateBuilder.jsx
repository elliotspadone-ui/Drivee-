import React, { useState } from "react";
import { Type, Image, Square, Layout, Save, Eye, Trash2 } from "lucide-react";
import { motion } from "framer-motion";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

export default function EmailTemplateBuilder({ template, onSave }) {
  const [blocks, setBlocks] = useState(template?.design_json?.blocks || []);
  const [subject, setSubject] = useState(template?.subject || "");
  const [previewText, setPreviewText] = useState(template?.preview_text || "");
  const [selectedBlock, setSelectedBlock] = useState(null);
  const [showPreview, setShowPreview] = useState(false);

  const blockTypes = [
    { type: "heading", icon: Type, label: "Heading", color: "indigo" },
    { type: "text", icon: Type, label: "Text", color: "purple" },
    { type: "image", icon: Image, label: "Image", color: "pink" },
    { type: "button", icon: Square, label: "Button", color: "blue" },
    { type: "divider", icon: Layout, label: "Divider", color: "gray" }
  ];

  const addBlock = (type) => {
    const newBlock = {
      id: `block-${Date.now()}`,
      type,
      content: getDefaultContent(type),
      styles: getDefaultStyles(type)
    };
    setBlocks([...blocks, newBlock]);
  };

  const getDefaultContent = (type) => {
    switch (type) {
      case "heading": return "Add Your Heading";
      case "text": return "Add your text content here...";
      case "image": return { url: "https://via.placeholder.com/600x300", alt: "Image" };
      case "button": return { text: "Click Here", url: "#" };
      case "divider": return null;
      default: return "";
    }
  };

  const getDefaultStyles = (type) => {
    switch (type) {
      case "heading": return { fontSize: "28px", color: "#1f2937", fontWeight: "bold", textAlign: "center" };
      case "text": return { fontSize: "16px", color: "#4b5563", lineHeight: "1.6" };
      case "button": return { 
        backgroundColor: "#667eea", 
        color: "#ffffff", 
        padding: "12px 24px",
        borderRadius: "8px",
        textAlign: "center"
      };
      default: return {};
    }
  };

  const updateBlock = (id, updates) => {
    setBlocks(blocks.map(block => 
      block.id === id ? { ...block, ...updates } : block
    ));
  };

  const deleteBlock = (id) => {
    setBlocks(blocks.filter(block => block.id !== id));
    if (selectedBlock?.id === id) setSelectedBlock(null);
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(blocks);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setBlocks(items);
  };

  const generateHTML = () => {
    let html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${subject}</title>
      </head>
      <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background-color: #f3f4f6;">
        <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 40px 20px;">
    `;

    blocks.forEach(block => {
      switch (block.type) {
        case "heading":
          html += `<h1 style="margin: 0 0 20px; ${styleToCSS(block.styles)}">${block.content}</h1>`;
          break;
        case "text":
          html += `<p style="margin: 0 0 20px; ${styleToCSS(block.styles)}">${block.content}</p>`;
          break;
        case "image":
          html += `<img src="${block.content.url}" alt="${block.content.alt}" style="width: 100%; height: auto; margin-bottom: 20px;">`;
          break;
        case "button":
          html += `
            <div style="text-align: center; margin: 20px 0;">
              <a href="${block.content.url}" style="display: inline-block; text-decoration: none; ${styleToCSS(block.styles)}">
                ${block.content.text}
              </a>
            </div>
          `;
          break;
        case "divider":
          html += `<hr style="border: none; border-top: 1px solid #e5e7eb; margin: 30px 0;">`;
          break;
      }
    });

    html += `
        </div>
      </body>
      </html>
    `;

    return html;
  };

  const styleToCSS = (styles) => {
    return Object.entries(styles)
      .map(([key, value]) => {
        const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
        return `${cssKey}: ${value}`;
      })
      .join('; ');
  };

  const handleSave = () => {
    onSave({
      subject,
      preview_text: previewText,
      design_json: { blocks },
      html_content: generateHTML()
    });
  };

  return (
    <div className="flex h-screen">
      {/* Toolbar */}
      <div className="w-64 neo-surface p-4 overflow-y-auto">
        <h3 className="font-bold text-gray-900 mb-4">Add Blocks</h3>
        <div className="space-y-2">
          {blockTypes.map(block => (
            <button
              key={block.type}
              onClick={() => addBlock(block.type)}
              className="neo-button w-full p-3 rounded-xl flex items-center gap-3 hover:bg-indigo-50"
            >
              <block.icon className={`w-5 h-5 text-${block.color}-600`} />
              <span className="text-sm font-semibold">{block.label}</span>
            </button>
          ))}
        </div>

        <div className="mt-6">
          <h3 className="font-bold text-gray-900 mb-3">Merge Tags</h3>
          <div className="space-y-1">
            {["{{student_name}}", "{{instructor_name}}", "{{booking_date}}", "{{school_name}}"].map(tag => (
              <div key={tag} className="neo-inset p-2 rounded-lg">
                <code className="text-xs text-gray-700">{tag}</code>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 overflow-y-auto p-6 bg-gray-100">
        <div className="max-w-2xl mx-auto">
          {/* Header Controls */}
          <div className="neo-surface p-4 rounded-2xl mb-4">
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Email Subject"
              className="w-full neo-inset px-4 py-3 rounded-xl mb-3 font-semibold"
            />
            <input
              type="text"
              value={previewText}
              onChange={(e) => setPreviewText(e.target.value)}
              placeholder="Preview Text"
              className="w-full neo-inset px-4 py-3 rounded-xl text-sm"
            />
          </div>

          {/* Email Canvas */}
          <div className="neo-surface p-8 rounded-2xl min-h-[600px]">
            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="email-canvas">
                {(provided) => (
                  <div {...provided.droppableProps} ref={provided.innerRef}>
                    {blocks.map((block, index) => (
                      <Draggable key={block.id} draggableId={block.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            onClick={() => setSelectedBlock(block)}
                            className={`neo-inset p-4 rounded-xl mb-3 cursor-move ${
                              selectedBlock?.id === block.id ? 'ring-2 ring-indigo-400' : ''
                            }`}
                          >
                            {block.type === "heading" && (
                              <input
                                type="text"
                                value={block.content}
                                onChange={(e) => updateBlock(block.id, { content: e.target.value })}
                                className="w-full bg-transparent border-none text-2xl font-bold"
                                style={{ color: block.styles.color }}
                              />
                            )}
                            {block.type === "text" && (
                              <textarea
                                value={block.content}
                                onChange={(e) => updateBlock(block.id, { content: e.target.value })}
                                className="w-full bg-transparent border-none resize-none"
                                rows={3}
                              />
                            )}
                            {block.type === "button" && (
                              <div className="flex gap-2">
                                <input
                                  type="text"
                                  value={block.content.text}
                                  onChange={(e) => updateBlock(block.id, { 
                                    content: { ...block.content, text: e.target.value }
                                  })}
                                  className="flex-1 neo-button px-4 py-2 rounded-lg"
                                />
                                <button
                                  onClick={() => deleteBlock(block.id)}
                                  className="neo-button p-2 rounded-lg text-red-600"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            )}
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          </div>
        </div>
      </div>

      {/* Properties Panel */}
      {selectedBlock && (
        <div className="w-80 neo-surface p-4 overflow-y-auto">
          <h3 className="font-bold text-gray-900 mb-4">Block Settings</h3>
          
          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-gray-900 mb-2 block">Font Size</label>
              <input
                type="text"
                value={selectedBlock.styles.fontSize || ""}
                onChange={(e) => updateBlock(selectedBlock.id, {
                  styles: { ...selectedBlock.styles, fontSize: e.target.value }
                })}
                className="neo-button w-full px-3 py-2 rounded-xl"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-900 mb-2 block">Color</label>
              <input
                type="color"
                value={selectedBlock.styles.color || "#000000"}
                onChange={(e) => updateBlock(selectedBlock.id, {
                  styles: { ...selectedBlock.styles, color: e.target.value }
                })}
                className="neo-button w-full h-10 rounded-xl"
              />
            </div>

            <button
              onClick={() => deleteBlock(selectedBlock.id)}
              className="neo-button w-full py-3 rounded-xl text-red-700 font-semibold"
            >
              Delete Block
            </button>
          </div>
        </div>
      )}

      {/* Action Bar */}
      <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50">
        <div className="neo-surface p-4 rounded-2xl flex items-center gap-3">
          <button onClick={() => setShowPreview(true)} className="neo-button p-3 rounded-xl">
            <Eye className="w-5 h-5" />
          </button>
          <button onClick={handleSave} className="neo-button px-6 py-3 gradient-primary text-white font-semibold rounded-xl">
            <Save className="w-5 h-5 mr-2 inline" />
            Save Template
          </button>
        </div>
      </div>
    </div>
  );
}