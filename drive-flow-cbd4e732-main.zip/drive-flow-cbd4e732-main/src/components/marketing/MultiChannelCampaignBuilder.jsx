import React, { useState } from "react";
import { Mail, MessageSquare, Bell, Users, Target, Calendar, Send } from "lucide-react";
import { motion } from "framer-motion";

export default function MultiChannelCampaignBuilder({ onSave }) {
  const [campaign, setCampaign] = useState({
    name: "",
    channels: [],
    audience: "all",
    schedule_type: "immediate",
    schedule_date: null,
    ab_test_enabled: false
  });

  const channels = [
    { id: "email", icon: Mail, label: "Email", color: "indigo" },
    { id: "sms", icon: MessageSquare, label: "SMS", color: "green" },
    { id: "push", icon: Bell, label: "Push", color: "purple" }
  ];

  const audiences = [
    { id: "all", label: "All Students", count: 250 },
    { id: "active", label: "Active Students", count: 180 },
    { id: "inactive", label: "Inactive (30+ days)", count: 45 },
    { id: "new", label: "New Students", count: 25 },
    { id: "custom", label: "Custom Segment", count: 0 }
  ];

  const toggleChannel = (channelId) => {
    setCampaign(prev => ({
      ...prev,
      channels: prev.channels.includes(channelId)
        ? prev.channels.filter(c => c !== channelId)
        : [...prev.channels, channelId]
    }));
  };

  return (
    <div className="space-y-6">
      {/* Campaign Name */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Campaign Details</h3>
        <input
          type="text"
          value={campaign.name}
          onChange={(e) => setCampaign({ ...campaign, name: e.target.value })}
          placeholder="Campaign Name"
          className="neo-button w-full px-4 py-3 rounded-xl font-semibold"
        />
      </div>

      {/* Channel Selection */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Select Channels</h3>
        <div className="grid grid-cols-3 gap-4">
          {channels.map(channel => (
            <button
              key={channel.id}
              onClick={() => toggleChannel(channel.id)}
              className={`neo-button p-6 rounded-2xl ${
                campaign.channels.includes(channel.id) ? 'active bg-indigo-50' : ''
              }`}
            >
              <channel.icon className={`w-8 h-8 text-${channel.color}-600 mx-auto mb-2`} />
              <p className="font-semibold text-gray-900">{channel.label}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Audience Selection */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Target Audience</h3>
        <div className="space-y-2">
          {audiences.map(audience => (
            <button
              key={audience.id}
              onClick={() => setCampaign({ ...campaign, audience: audience.id })}
              className={`neo-button w-full p-4 rounded-xl text-left flex items-center justify-between ${
                campaign.audience === audience.id ? 'active bg-indigo-50' : ''
              }`}
            >
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-gray-600" />
                <span className="font-semibold text-gray-900">{audience.label}</span>
              </div>
              <span className="text-sm text-muted">{audience.count} students</span>
            </button>
          ))}
        </div>
      </div>

      {/* Schedule */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Schedule</h3>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setCampaign({ ...campaign, schedule_type: 'immediate' })}
            className={`neo-button p-4 rounded-xl ${
              campaign.schedule_type === 'immediate' ? 'active bg-indigo-50' : ''
            }`}
          >
            <Send className="w-5 h-5 mx-auto mb-2 text-indigo-600" />
            <p className="text-sm font-semibold">Send Now</p>
          </button>
          <button
            onClick={() => setCampaign({ ...campaign, schedule_type: 'scheduled' })}
            className={`neo-button p-4 rounded-xl ${
              campaign.schedule_type === 'scheduled' ? 'active bg-indigo-50' : ''
            }`}
          >
            <Calendar className="w-5 h-5 mx-auto mb-2 text-purple-600" />
            <p className="text-sm font-semibold">Schedule</p>
          </button>
        </div>
        
        {campaign.schedule_type === 'scheduled' && (
          <input
            type="datetime-local"
            className="neo-button w-full px-4 py-3 rounded-xl mt-3"
            onChange={(e) => setCampaign({ ...campaign, schedule_date: e.target.value })}
          />
        )}
      </div>

      {/* A/B Testing */}
      <div className="neo-surface p-6 rounded-3xl">
        <label className="flex items-center justify-between cursor-pointer">
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-1">A/B Testing</h3>
            <p className="text-sm text-muted">Test different versions to optimize results</p>
          </div>
          <input
            type="checkbox"
            checked={campaign.ab_test_enabled}
            onChange={(e) => setCampaign({ ...campaign, ab_test_enabled: e.target.checked })}
            className="w-12 h-6"
          />
        </label>
      </div>

      {/* Summary */}
      <div className="neo-inset p-6 rounded-2xl">
        <h3 className="font-bold text-gray-900 mb-3">Campaign Summary</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted">Channels:</span>
            <span className="font-semibold">{campaign.channels.length || 0} selected</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted">Recipients:</span>
            <span className="font-semibold">
              {audiences.find(a => a.id === campaign.audience)?.count || 0} students
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted">Schedule:</span>
            <span className="font-semibold capitalize">{campaign.schedule_type}</span>
          </div>
        </div>
      </div>

      <button
        onClick={() => onSave(campaign)}
        className="neo-button w-full py-4 gradient-primary text-white font-bold text-lg rounded-2xl"
      >
        Create Campaign
      </button>
    </div>
  );
}