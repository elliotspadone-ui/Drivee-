import React, { useState } from "react";
import { motion } from "framer-motion";
import { Zap, Plus, Edit2, Trash2, Power, Gift, Tag, UserPlus, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function AutomationRules({ onSave }) {
  const [rules, setRules] = useState([
    {
      id: 1,
      name: "Abandoned Booking Recovery",
      trigger: "booking_cancelled",
      delay: 24,
      action: "send_promo_code",
      discount: 15,
      active: true
    },
    {
      id: 2,
      name: "Welcome Gift Card",
      trigger: "student_registered",
      delay: 0,
      action: "send_gift_card",
      amount: 20,
      active: true
    },
    {
      id: 3,
      name: "Referral Reward",
      trigger: "referral_completed",
      delay: 0,
      action: "send_promo_code",
      discount: 20,
      active: true
    },
    {
      id: 4,
      name: "Inactive Student Reactivation",
      trigger: "no_booking_30_days",
      delay: 0,
      action: "send_campaign",
      discount: 25,
      active: true
    }
  ]);
  
  const [showForm, setShowForm] = useState(false);
  const [editingRule, setEditingRule] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    trigger: "booking_cancelled",
    delay: 24,
    action: "send_promo_code",
    discount: 15,
    amount: 20,
    active: true
  });

  const triggers = [
    { value: "booking_cancelled", label: "Booking Cancelled" },
    { value: "student_registered", label: "Student Registered" },
    { value: "referral_completed", label: "Referral Completed" },
    { value: "no_booking_30_days", label: "No Booking for 30 Days" },
    { value: "package_purchased", label: "Package Purchased" },
    { value: "first_lesson_completed", label: "First Lesson Completed" }
  ];

  const actions = [
    { value: "send_promo_code", label: "Send Promo Code", icon: Tag },
    { value: "send_gift_card", label: "Send Gift Card", icon: Gift },
    { value: "send_campaign", label: "Send Campaign", icon: Calendar },
    { value: "send_sms", label: "Send SMS", icon: Zap }
  ];

  const handleSave = () => {
    if (editingRule) {
      setRules(rules.map(r => r.id === editingRule.id ? { ...formData, id: editingRule.id } : r));
      toast.success("Rule updated!");
    } else {
      setRules([...rules, { ...formData, id: Date.now() }]);
      toast.success("Rule created!");
    }
    setShowForm(false);
    setEditingRule(null);
    setFormData({
      name: "",
      trigger: "booking_cancelled",
      delay: 24,
      action: "send_promo_code",
      discount: 15,
      amount: 20,
      active: true
    });
  };

  const handleToggle = (ruleId) => {
    setRules(rules.map(r => r.id === ruleId ? { ...r, active: !r.active } : r));
    toast.success("Rule status updated!");
  };

  const handleDelete = (ruleId) => {
    setRules(rules.filter(r => r.id !== ruleId));
    toast.success("Rule deleted!");
  };

  const handleEdit = (rule) => {
    setEditingRule(rule);
    setFormData(rule);
    setShowForm(true);
  };

  return (
    <div className="neo-surface p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-600 to-red-600 flex items-center justify-center">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900">Automation Rules</h3>
            <p className="text-sm text-muted">Automated promo codes and gift card distribution</p>
          </div>
        </div>
        <Button
          onClick={() => {
            setEditingRule(null);
            setShowForm(true);
          }}
          className="neo-button px-6 py-3 gradient-primary text-white font-semibold flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Add Rule
        </Button>
      </div>

      <div className="space-y-4">
        {rules.map((rule, index) => {
          const ActionIcon = actions.find(a => a.value === rule.action)?.icon || Zap;
          
          return (
            <motion.div
              key={rule.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className={`neo-inset p-6 rounded-2xl ${!rule.active ? 'opacity-50' : ''}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4 flex-1">
                  <div className={`w-10 h-10 rounded-xl ${rule.active ? 'bg-gradient-to-br from-orange-100 to-red-100' : 'bg-gray-100'} flex items-center justify-center`}>
                    <ActionIcon className={`w-5 h-5 ${rule.active ? 'text-orange-600' : 'text-gray-400'}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-bold text-gray-900">{rule.name}</h4>
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${rule.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                        {rule.active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <div className="space-y-1 text-sm text-gray-700">
                      <p>
                        <span className="font-semibold">Trigger:</span>{' '}
                        {triggers.find(t => t.value === rule.trigger)?.label}
                      </p>
                      {rule.delay > 0 && (
                        <p>
                          <span className="font-semibold">Delay:</span> {rule.delay} hours
                        </p>
                      )}
                      <p>
                        <span className="font-semibold">Action:</span>{' '}
                        {actions.find(a => a.value === rule.action)?.label}
                        {rule.discount && ` - ${rule.discount}% off`}
                        {rule.amount && ` - €${rule.amount}`}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleToggle(rule.id)}
                    className="neo-button p-3 rounded-xl"
                    title={rule.active ? "Deactivate" : "Activate"}
                  >
                    <Power className={`w-5 h-5 ${rule.active ? 'text-green-600' : 'text-gray-400'}`} />
                  </button>
                  <button
                    onClick={() => handleEdit(rule)}
                    className="neo-button p-3 rounded-xl"
                  >
                    <Edit2 className="w-5 h-5 text-gray-600" />
                  </button>
                  <button
                    onClick={() => handleDelete(rule.id)}
                    className="neo-button p-3 rounded-xl"
                  >
                    <Trash2 className="w-5 h-5 text-red-600" />
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="neo-surface p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded-3xl"
          >
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              {editingRule ? "Edit Rule" : "Create Automation Rule"}
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Rule Name</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Abandoned Booking Recovery"
                  className="neo-inset"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">Trigger Event</label>
                  <Select
                    value={formData.trigger}
                    onValueChange={(value) => setFormData({ ...formData, trigger: value })}
                  >
                    <SelectTrigger className="neo-inset">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {triggers.map(t => (
                        <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">Delay (hours)</label>
                  <Input
                    type="number"
                    value={formData.delay}
                    onChange={(e) => setFormData({ ...formData, delay: parseInt(e.target.value) })}
                    className="neo-inset"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">Action</label>
                <Select
                  value={formData.action}
                  onValueChange={(value) => setFormData({ ...formData, action: value })}
                >
                  <SelectTrigger className="neo-inset">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {actions.map(a => (
                      <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {formData.action === 'send_promo_code' && (
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">Discount (%)</label>
                  <Input
                    type="number"
                    value={formData.discount}
                    onChange={(e) => setFormData({ ...formData, discount: parseInt(e.target.value) })}
                    className="neo-inset"
                  />
                </div>
              )}

              {formData.action === 'send_gift_card' && (
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">Amount (€)</label>
                  <Input
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: parseInt(e.target.value) })}
                    className="neo-inset"
                  />
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <Button
                  onClick={() => {
                    setShowForm(false);
                    setEditingRule(null);
                  }}
                  className="neo-button flex-1 py-3 font-semibold"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSave}
                  className="neo-button flex-1 py-3 gradient-primary text-white font-semibold"
                >
                  {editingRule ? "Update Rule" : "Create Rule"}
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}