import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { Clock, ChevronRight, History } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function PreviousInstructors({ studentId, instructors, onSelect }) {
    // Fetch completed bookings
    const { data: history = [], isLoading } = useQuery({
        queryKey: ['studentHistory', studentId],
        queryFn: () => base44.entities.Booking.filter({ 
            student_id: studentId, 
            status: 'completed' 
        }),
        enabled: !!studentId
    });

    const previousInstructors = useMemo(() => {
        if (!history.length || !instructors.length) return [];

        // Group by instructor and find most recent lesson
        const map = new Map();
        history.forEach(booking => {
            const existing = map.get(booking.instructor_id);
            // We want to count all completed lessons
            const currentCount = existing ? existing.count : 0;
            
            // Update if new entry or if this booking is more recent
            if (!existing || new Date(booking.start_datetime) > new Date(existing.lastLessonDate)) {
                map.set(booking.instructor_id, {
                    instructorId: booking.instructor_id,
                    lastLessonDate: booking.start_datetime,
                    count: currentCount + 1
                });
            } else {
                // Just update count on the existing entry
                existing.count++;
            }
        });

        // Map to instructor details
        return Array.from(map.values())
            .map(item => ({
                ...item,
                instructor: instructors.find(i => i.id === item.instructorId)
            }))
            .filter(item => item.instructor) // Ensure instructor still exists
            .sort((a, b) => new Date(b.lastLessonDate) - new Date(a.lastLessonDate));
    }, [history, instructors]);

    if (isLoading || previousInstructors.length === 0) return null;

    return (
        <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
        >
            <div className="flex items-center gap-2 mb-4 px-1">
                <div className="p-1.5 bg-indigo-100 rounded-lg">
                    <History className="w-4 h-4 text-indigo-600" />
                </div>
                <div>
                    <h2 className="text-lg font-bold text-gray-900">Rebook Previous Instructor</h2>
                    <p className="text-xs text-gray-500">Instructors you've learned with before</p>
                </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {previousInstructors.map(({ instructor, lastLessonDate, count }) => (
                    <motion.button
                        key={instructor.id}
                        whileHover={{ scale: 1.02, y: -2 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => onSelect(instructor)}
                        className="flex items-center gap-4 p-4 bg-white border border-indigo-100 rounded-xl shadow-sm hover:shadow-md hover:border-indigo-300 transition-all text-left group relative overflow-hidden"
                    >
                        <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                        
                        <div className="w-12 h-12 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center text-indigo-700 font-bold text-lg flex-shrink-0 border border-indigo-50">
                            {instructor.full_name?.charAt(0)}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                            <p className="font-bold text-gray-900 truncate group-hover:text-indigo-700 transition-colors">
                                {instructor.full_name}
                            </p>
                            <div className="flex items-center gap-2 text-xs text-gray-500">
                                <span className="font-medium text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">
                                    {count} lesson{count !== 1 ? 's' : ''}
                                </span>
                                <span>• {formatDistanceToNow(new Date(lastLessonDate))} ago</span>
                            </div>
                        </div>
                        
                        <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center group-hover:bg-indigo-600 transition-colors">
                            <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-white transition-colors" />
                        </div>
                    </motion.button>
                ))}
            </div>
        </motion.div>
    );
}