import React, { useState } from "react";
import { X, Repeat, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function RecurringBookingModal({ 
  isOpen, 
  onClose, 
  instructor,
  vehicle,
  student,
  onSubmit 
}) {
  const [template, setTemplate] = useState({
    frequency: "weekly",
    days_of_week: [],
    preferred_time: "09:00",
    start_date: new Date(),
    total_lessons: 10,
    pickup_location: student?.pickup_zone || ""
  });

  const daysOfWeek = [
    { value: 1, label: "Mon" },
    { value: 2, label: "Tue" },
    { value: 3, label: "Wed" },
    { value: 4, label: "Thu" },
    { value: 5, label: "Fri" },
    { value: 6, label: "Sat" },
    { value: 0, label: "Sun" }
  ];

  const toggleDay = (day) => {
    setTemplate(prev => ({
      ...prev,
      days_of_week: prev.days_of_week.includes(day)
        ? prev.days_of_week.filter(d => d !== day)
        : [...prev.days_of_week, day]
    }));
  };

  const handleSubmit = () => {
    onSubmit({
      ...template,
      instructor_id: instructor.id,
      vehicle_id: vehicle.id,
      student_id: student.id,
      school_id: instructor.school_id
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="neo-surface p-8 rounded-3xl max-w-2xl w-full"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="neo-inset w-12 h-12 rounded-2xl flex items-center justify-center">
              <Repeat className="w-6 h-6 text-indigo-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Recurring Booking</h2>
          </div>
          <button onClick={onClose} className="neo-button p-3 rounded-xl">
            <X className="w-5 h-5 text-gray-700" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Frequency */}
          <div>
            <label className="text-sm font-semibold text-gray-900 mb-3 block">Frequency</label>
            <div className="grid grid-cols-4 gap-3">
              {["daily", "weekly", "biweekly", "monthly"].map(freq => (
                <button
                  key={freq}
                  onClick={() => setTemplate({ ...template, frequency: freq })}
                  className={`neo-button p-3 rounded-xl capitalize ${
                    template.frequency === freq ? "active bg-indigo-50" : ""
                  }`}
                >
                  {freq}
                </button>
              ))}
            </div>
          </div>

          {/* Days of Week */}
          {(template.frequency === "weekly" || template.frequency === "biweekly") && (
            <div>
              <label className="text-sm font-semibold text-gray-900 mb-3 block">Days of Week</label>
              <div className="grid grid-cols-7 gap-2">
                {daysOfWeek.map(day => (
                  <button
                    key={day.value}
                    onClick={() => toggleDay(day.value)}
                    className={`neo-button p-3 rounded-xl ${
                      template.days_of_week.includes(day.value) ? "active bg-indigo-50" : ""
                    }`}
                  >
                    {day.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Time & Date */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold text-gray-900 mb-2 block">Start Date</label>
              <input
                type="date"
                value={format(template.start_date, 'yyyy-MM-dd')}
                onChange={(e) => setTemplate({ ...template, start_date: new Date(e.target.value) })}
                className="neo-button w-full px-4 py-3 rounded-xl focus:outline-none"
              />
            </div>
            
            <div>
              <label className="text-sm font-semibold text-gray-900 mb-2 block">Preferred Time</label>
              <input
                type="time"
                value={template.preferred_time}
                onChange={(e) => setTemplate({ ...template, preferred_time: e.target.value })}
                className="neo-button w-full px-4 py-3 rounded-xl focus:outline-none"
              />
            </div>
          </div>

          {/* Total Lessons */}
          <div>
            <label className="text-sm font-semibold text-gray-900 mb-2 block">Total Lessons</label>
            <input
              type="number"
              min="1"
              max="52"
              value={template.total_lessons}
              onChange={(e) => setTemplate({ ...template, total_lessons: parseInt(e.target.value) })}
              className="neo-button w-full px-4 py-3 rounded-xl focus:outline-none"
            />
          </div>

          {/* Pickup Location */}
          <div>
            <label className="text-sm font-semibold text-gray-900 mb-2 block">Pickup Location</label>
            <input
              type="text"
              value={template.pickup_location}
              onChange={(e) => setTemplate({ ...template, pickup_location: e.target.value })}
              placeholder="Enter pickup address"
              className="neo-button w-full px-4 py-3 rounded-xl focus:outline-none"
            />
          </div>

          {/* Summary */}
          <div className="neo-inset p-4 rounded-2xl">
            <p className="text-sm text-muted mb-2">Summary</p>
            <p className="text-lg font-bold text-gray-900">
              {template.total_lessons} {template.frequency} lessons
            </p>
            <p className="text-sm text-gray-700 mt-1">
              Starting {format(template.start_date, 'MMM d, yyyy')} at {template.preferred_time}
            </p>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={onClose}
            className="neo-button flex-1 py-3 rounded-2xl font-semibold"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="neo-button flex-1 py-3 rounded-2xl gradient-primary text-white font-semibold"
          >
            Create Template
          </button>
        </div>
      </motion.div>
    </div>
  );
}