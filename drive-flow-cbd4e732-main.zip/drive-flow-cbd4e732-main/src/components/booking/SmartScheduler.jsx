import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Sparkles, Calendar, Clock, MapPin } from "lucide-react";
import { toast } from "sonner";

export default function SmartScheduler({ studentId, instructorId, onSuccess }) {
  const queryClient = useQueryClient();
  const [preferences, setPreferences] = useState({
    preferred_days: [],
    preferred_times: "morning",
    frequency: "weekly",
    duration: 60,
  });

  const autoScheduleMutation = useMutation({
    mutationFn: async () => {
      // Fetch instructor availability and bookings
      const [availability, existingBookings] = await Promise.all([
        base44.entities.InstructorAvailability.filter({ instructor_id: instructorId }),
        base44.entities.Booking.filter({ instructor_id: instructorId }),
      ]);

      const weeklyPattern = availability.find(a => a.weekly_pattern)?.weekly_pattern || {};
      
      // Find best matching slots based on preferences
      const suggestedSlots = [];
      const today = new Date();
      
      for (let i = 0; i < 30; i++) {
        const checkDate = new Date(today);
        checkDate.setDate(today.getDate() + i);
        
        const dayName = checkDate.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
        const daySlots = weeklyPattern[dayName] || [];
        
        // Filter by preferred days if set
        if (preferences.preferred_days.length > 0 && 
            !preferences.preferred_days.includes(dayName)) {
          continue;
        }

        daySlots.forEach(pattern => {
          const [startH] = pattern.start_time.split(':').map(Number);
          
          // Filter by preferred time
          let matchesTime = true;
          if (preferences.preferred_times === "morning" && (startH < 6 || startH >= 12)) {
            matchesTime = false;
          }
          if (preferences.preferred_times === "afternoon" && (startH < 12 || startH >= 17)) {
            matchesTime = false;
          }
          if (preferences.preferred_times === "evening" && (startH < 17 || startH >= 21)) {
            matchesTime = false;
          }

          if (!matchesTime) return;

          // Check if slot is available
          const slotDateTime = new Date(`${checkDate.toISOString().split('T')[0]}T${pattern.start_time}`);
          const endDateTime = new Date(slotDateTime);
          endDateTime.setMinutes(endDateTime.getMinutes() + preferences.duration);

          const isBooked = existingBookings.some(b => {
            const bookingStart = new Date(b.start_datetime);
            const bookingEnd = new Date(b.end_datetime);
            return (slotDateTime >= bookingStart && slotDateTime < bookingEnd) ||
                   (endDateTime > bookingStart && endDateTime <= bookingEnd);
          });

          if (!isBooked && slotDateTime > today) {
            suggestedSlots.push({
              start_datetime: slotDateTime.toISOString(),
              end_datetime: endDateTime.toISOString(),
              day: dayName,
            });
          }
        });

        // Limit suggestions based on frequency
        if (preferences.frequency === "weekly" && suggestedSlots.length >= 4) break;
        if (preferences.frequency === "biweekly" && suggestedSlots.length >= 2) break;
      }

      if (suggestedSlots.length === 0) {
        throw new Error("No available slots match your preferences");
      }

      // Create bookings for suggested slots
      const bookingPromises = suggestedSlots.slice(0, 4).map(slot =>
        base44.entities.Booking.create({
          student_id: studentId,
          instructor_id: instructorId,
          start_datetime: slot.start_datetime,
          end_datetime: slot.end_datetime,
          status: "confirmed",
          lesson_type: "practical_driving",
        })
      );

      await Promise.all(bookingPromises);
      return suggestedSlots.slice(0, 4);
    },
    onSuccess: (slots) => {
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
      toast.success(`${slots.length} lessons scheduled automatically!`);
      onSuccess?.();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to auto-schedule");
    },
  });

  const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

  return (
    <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-6 border-2 border-indigo-200">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
          <Sparkles className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Smart Scheduler</h3>
          <p className="text-sm text-gray-600">Let us find the best times for you</p>
        </div>
      </div>

      <div className="space-y-4 mb-6">
        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Preferred Days</label>
          <div className="flex flex-wrap gap-2">
            {days.map(day => (
              <button
                key={day}
                onClick={() => {
                  const newDays = preferences.preferred_days.includes(day)
                    ? preferences.preferred_days.filter(d => d !== day)
                    : [...preferences.preferred_days, day];
                  setPreferences({ ...preferences, preferred_days: newDays });
                }}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition ${
                  preferences.preferred_days.includes(day)
                    ? 'bg-indigo-600 text-white'
                    : 'bg-white text-gray-700 border border-gray-200'
                }`}
              >
                {day.charAt(0).toUpperCase() + day.slice(1, 3)}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Preferred Time</label>
            <select
              value={preferences.preferred_times}
              onChange={(e) => setPreferences({ ...preferences, preferred_times: e.target.value })}
              className="w-full px-4 py-2 rounded-lg border border-gray-200 bg-white"
            >
              <option value="any">Any time</option>
              <option value="morning">Morning (6am-12pm)</option>
              <option value="afternoon">Afternoon (12pm-5pm)</option>
              <option value="evening">Evening (5pm-9pm)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Frequency</label>
            <select
              value={preferences.frequency}
              onChange={(e) => setPreferences({ ...preferences, frequency: e.target.value })}
              className="w-full px-4 py-2 rounded-lg border border-gray-200 bg-white"
            >
              <option value="weekly">Once per week</option>
              <option value="biweekly">Twice per week</option>
            </select>
          </div>
        </div>
      </div>

      <button
        onClick={() => autoScheduleMutation.mutate()}
        disabled={autoScheduleMutation.isPending}
        className="w-full px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg transition flex items-center justify-center gap-2"
      >
        <Sparkles className="w-5 h-5" />
        {autoScheduleMutation.isPending ? "Finding best times..." : "Auto-Schedule Lessons"}
      </button>
    </div>
  );
}