/**
 * Schedule Optimization Engine
 * Optimizes instructor schedules and routes
 */

export class ScheduleOptimizer {
  constructor(bookings, instructors, bufferMinutes = 15) {
    this.bookings = bookings;
    this.instructors = instructors;
    this.bufferMinutes = bufferMinutes;
  }

  /**
   * Check for scheduling conflicts
   */
  checkConflicts(newBooking) {
    const conflicts = [];
    const newStart = new Date(newBooking.start_datetime);
    const newEnd = new Date(newBooking.end_datetime);
    const bufferMs = this.bufferMinutes * 60 * 1000;

    this.bookings.forEach(booking => {
      if (booking.status === 'cancelled') return;

      const existingStart = new Date(booking.start_datetime);
      const existingEnd = new Date(booking.end_datetime);
      const existingEndWithBuffer = new Date(existingEnd.getTime() + bufferMs);

      // Check instructor conflict
      if (booking.instructor_id === newBooking.instructor_id) {
        if (this.hasTimeOverlap(newStart, newEnd, existingStart, existingEndWithBuffer)) {
          conflicts.push({
            type: 'instructor',
            booking,
            message: `Instructor has another lesson at this time (${this.bufferMinutes}min buffer included)`
          });
        }
      }

      // Check vehicle conflict
      if (booking.vehicle_id === newBooking.vehicle_id) {
        if (this.hasTimeOverlap(newStart, newEnd, existingStart, existingEndWithBuffer)) {
          conflicts.push({
            type: 'vehicle',
            booking,
            message: 'Vehicle is already booked at this time'
          });
        }
      }

      // Check student conflict (for group lessons)
      if (booking.student_id === newBooking.student_id || 
          booking.additional_students?.includes(newBooking.student_id)) {
        if (this.hasTimeOverlap(newStart, newEnd, existingStart, existingEnd)) {
          conflicts.push({
            type: 'student',
            booking,
            message: 'Student already has a lesson at this time'
          });
        }
      }
    });

    return conflicts;
  }

  hasTimeOverlap(start1, end1, start2, end2) {
    return start1 < end2 && end1 > start2;
  }

  /**
   * Find available time slots
   */
  findAvailableSlots(instructorId, date, duration = 60) {
    const dayStart = new Date(date);
    dayStart.setHours(8, 0, 0, 0);
    const dayEnd = new Date(date);
    dayEnd.setHours(20, 0, 0, 0);

    const slots = [];
    const slotDuration = duration * 60 * 1000;
    const bufferMs = this.bufferMinutes * 60 * 1000;

    let currentTime = new Date(dayStart);

    while (currentTime < dayEnd) {
      const slotEnd = new Date(currentTime.getTime() + slotDuration);
      const slotEndWithBuffer = new Date(slotEnd.getTime() + bufferMs);

      // Check if slot is available
      const hasConflict = this.bookings.some(booking => {
        if (booking.instructor_id !== instructorId || booking.status === 'cancelled') {
          return false;
        }

        const bookingStart = new Date(booking.start_datetime);
        const bookingEnd = new Date(booking.end_datetime);
        const bookingEndWithBuffer = new Date(bookingEnd.getTime() + bufferMs);

        return this.hasTimeOverlap(currentTime, slotEndWithBuffer, bookingStart, bookingEndWithBuffer);
      });

      if (!hasConflict) {
        slots.push({
          start: new Date(currentTime),
          end: new Date(slotEnd),
          available: true
        });
      }

      currentTime = new Date(currentTime.getTime() + 30 * 60 * 1000); // 30min increments
    }

    return slots;
  }

  /**
   * Optimize route for sequential lessons
   */
  optimizeRoute(dayBookings) {
    if (dayBookings.length <= 1) return dayBookings;

    // Extract bookings with location data
    const bookingsWithLocations = dayBookings.filter(b => 
      b.pickup_latitude && b.pickup_longitude
    );

    if (bookingsWithLocations.length === 0) return dayBookings;

    // Sort by time first
    const sorted = [...bookingsWithLocations].sort((a, b) => 
      new Date(a.start_datetime) - new Date(b.start_datetime)
    );

    // Calculate total distance for current order
    let optimized = [sorted[0]];
    let remaining = sorted.slice(1);

    while (remaining.length > 0) {
      const current = optimized[optimized.length - 1];
      
      // Find nearest next booking
      let nearestIndex = 0;
      let shortestDistance = this.calculateDistance(
        current.pickup_latitude,
        current.pickup_longitude,
        remaining[0].pickup_latitude,
        remaining[0].pickup_longitude
      );

      for (let i = 1; i < remaining.length; i++) {
        const distance = this.calculateDistance(
          current.pickup_latitude,
          current.pickup_longitude,
          remaining[i].pickup_latitude,
          remaining[i].pickup_longitude
        );

        if (distance < shortestDistance) {
          shortestDistance = distance;
          nearestIndex = i;
        }
      }

      optimized.push(remaining[nearestIndex]);
      remaining.splice(nearestIndex, 1);
    }

    // Add route sequence
    return optimized.map((booking, index) => ({
      ...booking,
      route_sequence: index + 1,
      travel_time_minutes: index > 0 ? this.estimateTravelTime(
        optimized[index - 1],
        booking
      ) : 0
    }));
  }

  /**
   * Calculate distance between two points (Haversine formula)
   */
  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in km
    const dLat = this.toRadians(lat2 - lat1);
    const dLon = this.toRadians(lon2 - lon1);
    
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  toRadians(degrees) {
    return degrees * (Math.PI / 180);
  }

  /**
   * Estimate travel time between bookings
   */
  estimateTravelTime(booking1, booking2) {
    const distance = this.calculateDistance(
      booking1.dropoff_latitude || booking1.pickup_latitude,
      booking1.dropoff_longitude || booking1.pickup_longitude,
      booking2.pickup_latitude,
      booking2.pickup_longitude
    );

    // Assume 30 km/h average speed in city
    return Math.ceil((distance / 30) * 60);
  }

  /**
   * Suggest optimal booking time
   */
  suggestOptimalTime(instructorId, studentLocation, date) {
    const availableSlots = this.findAvailableSlots(instructorId, date);
    const instructorBookings = this.bookings.filter(b => 
      b.instructor_id === instructorId &&
      new Date(b.start_datetime).toDateString() === new Date(date).toDateString()
    );

    if (instructorBookings.length === 0) {
      // No bookings yet, suggest morning slot
      return availableSlots[0];
    }

    // Find slot that minimizes total travel distance
    let bestSlot = availableSlots[0];
    let minDistance = Infinity;

    availableSlots.forEach(slot => {
      const totalDistance = this.calculateTotalDistance(
        [...instructorBookings, { ...studentLocation, start_datetime: slot.start }]
      );

      if (totalDistance < minDistance) {
        minDistance = totalDistance;
        bestSlot = slot;
      }
    });

    return bestSlot;
  }

  calculateTotalDistance(bookings) {
    let total = 0;
    for (let i = 1; i < bookings.length; i++) {
      if (bookings[i].pickup_latitude && bookings[i - 1].pickup_latitude) {
        total += this.calculateDistance(
          bookings[i - 1].pickup_latitude,
          bookings[i - 1].pickup_longitude,
          bookings[i].pickup_latitude,
          bookings[i].pickup_longitude
        );
      }
    }
    return total;
  }
}

export default ScheduleOptimizer;