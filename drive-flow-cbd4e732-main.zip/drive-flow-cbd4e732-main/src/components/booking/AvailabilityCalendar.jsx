import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format, addDays, startOfWeek } from "date-fns";
import { ChevronLeft, ChevronRight, Clock, CheckCircle } from "lucide-react";

export default function AvailabilityCalendar({ instructorId, onSelectSlot, selectedSlot }) {
  const [currentWeek, setCurrentWeek] = useState(new Date());

  const { data: bookings = [] } = useQuery({
    queryKey: ['instructorBookings', instructorId],
    queryFn: () => base44.entities.Booking.filter({ instructor_id: instructorId }),
    enabled: !!instructorId,
  });

  const { data: availability = [] } = useQuery({
    queryKey: ['instructorAvailability', instructorId],
    queryFn: () => base44.entities.InstructorAvailability.filter({ instructor_id: instructorId }),
    enabled: !!instructorId,
  });

  const { data: blockedTimes = [] } = useQuery({
    queryKey: ['calendarBlocks', instructorId],
    queryFn: () => base44.entities.CalendarBlock.filter({ instructor_id: instructorId }),
    enabled: !!instructorId,
  });

  const weeklyPattern = availability.find(a => a.weekly_pattern)?.weekly_pattern || {};
  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  const getAvailableSlots = (date) => {
    const dayName = format(date, 'EEEE').toLowerCase();
    const daySlots = weeklyPattern[dayName] || [];
    const dateStr = format(date, 'yyyy-MM-dd');

    const allSlots = [];
    daySlots.forEach(pattern => {
      const [startH, startM] = pattern.start_time.split(':').map(Number);
      const [endH, endM] = pattern.end_time.split(':').map(Number);
      const duration = pattern.slot_duration || 60;

      let currentTime = startH * 60 + startM;
      const endTime = endH * 60 + endM;

      while (currentTime + duration <= endTime) {
        const hour = Math.floor(currentTime / 60);
        const minute = currentTime % 60;
        const timeStr = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        
        const slotDateTime = new Date(`${dateStr}T${timeStr}`);
        
        // Check if slot is booked
        const isBooked = bookings.some(b => {
          const bookingStart = new Date(b.start_datetime);
          const bookingEnd = new Date(b.end_datetime);
          return slotDateTime >= bookingStart && slotDateTime < bookingEnd;
        });

        // Check if slot is blocked
        const isBlocked = blockedTimes.some(block => {
          const blockStart = new Date(block.start_datetime);
          const blockEnd = new Date(block.end_datetime);
          return slotDateTime >= blockStart && slotDateTime < blockEnd;
        });

        if (!isBooked && !isBlocked && slotDateTime > new Date()) {
          allSlots.push({
            time: timeStr,
            datetime: slotDateTime.toISOString(),
            duration,
          });
        }

        currentTime += duration;
      }
    });

    return allSlots;
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Available Times</h3>
        <div className="flex gap-2">
          <button
            onClick={() => setCurrentWeek(addDays(currentWeek, -7))}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => setCurrentWeek(new Date())}
            className="px-4 py-2 hover:bg-gray-100 rounded-lg text-sm font-medium"
          >
            Today
          </button>
          <button
            onClick={() => setCurrentWeek(addDays(currentWeek, 7))}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {weekDays.map(day => {
          const slots = getAvailableSlots(day);
          const isToday = format(day, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
          
          return (
            <div key={day.toISOString()} className="space-y-2">
              <div className={`text-center p-2 rounded-lg ${isToday ? 'bg-indigo-100' : 'bg-gray-50'}`}>
                <p className="text-xs text-gray-600">{format(day, 'EEE')}</p>
                <p className={`text-lg font-bold ${isToday ? 'text-indigo-600' : 'text-gray-900'}`}>
                  {format(day, 'd')}
                </p>
              </div>

              <div className="space-y-1">
                {slots.length === 0 ? (
                  <p className="text-xs text-center text-gray-400 py-2">No slots</p>
                ) : (
                  slots.map((slot, idx) => {
                    const isSelected = selectedSlot?.datetime === slot.datetime;
                    return (
                      <button
                        key={idx}
                        onClick={() => onSelectSlot(slot)}
                        className={`w-full p-2 rounded-lg text-xs font-medium transition flex items-center justify-center gap-1 ${
                          isSelected
                            ? 'bg-indigo-600 text-white'
                            : 'bg-gray-100 hover:bg-indigo-100 text-gray-700'
                        }`}
                      >
                        {isSelected && <CheckCircle className="w-3 h-3" />}
                        {slot.time}
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}