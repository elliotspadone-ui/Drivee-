import React from "react";
import { AlertTriangle, Clock, Calendar, User, Car } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function ConflictResolver({ conflicts, onResolve, onCancel }) {
  if (!conflicts || conflicts.length === 0) return null;

  const getSuggestions = (conflict) => {
    const suggestions = [];
    const conflictStart = new Date(conflict.booking.start_datetime);
    
    // Suggest time before
    const timeBefore = new Date(conflictStart);
    timeBefore.setHours(conflictStart.getHours() - 2);
    suggestions.push({
      type: "time_before",
      label: `Book at ${format(timeBefore, 'h:mm a')} instead`,
      datetime: timeBefore
    });

    // Suggest time after
    const timeAfter = new Date(conflict.booking.end_datetime);
    timeAfter.setMinutes(timeAfter.getMinutes() + 15);
    suggestions.push({
      type: "time_after",
      label: `Book at ${format(timeAfter, 'h:mm a')} instead`,
      datetime: timeAfter
    });

    // Suggest next day
    const nextDay = new Date(conflictStart);
    nextDay.setDate(nextDay.getDate() + 1);
    suggestions.push({
      type: "next_day",
      label: `Book on ${format(nextDay, 'MMM d')} at same time`,
      datetime: nextDay
    });

    return suggestions;
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="neo-surface p-8 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="neo-inset w-12 h-12 rounded-2xl flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 text-orange-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Scheduling Conflicts</h2>
            <p className="text-sm text-muted">We found {conflicts.length} conflict(s) with your booking</p>
          </div>
        </div>

        <div className="space-y-4 mb-6">
          {conflicts.map((conflict, index) => (
            <div key={index} className="neo-inset p-4 rounded-2xl">
              <div className="flex items-start gap-3 mb-4">
                {conflict.type === 'instructor' && <User className="w-5 h-5 text-orange-600 mt-0.5" />}
                {conflict.type === 'vehicle' && <Car className="w-5 h-5 text-orange-600 mt-0.5" />}
                {conflict.type === 'student' && <Calendar className="w-5 h-5 text-orange-600 mt-0.5" />}
                <div className="flex-1">
                  <p className="font-semibold text-gray-900 mb-1 capitalize">
                    {conflict.type} Conflict
                  </p>
                  <p className="text-sm text-gray-700">{conflict.message}</p>
                  <p className="text-xs text-muted mt-2">
                    Conflicting booking: {format(new Date(conflict.booking.start_datetime), 'MMM d, h:mm a')}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-xs font-semibold text-gray-900 mb-2">Suggestions:</p>
                {getSuggestions(conflict).map((suggestion, idx) => (
                  <button
                    key={idx}
                    onClick={() => onResolve(suggestion.datetime)}
                    className="neo-button w-full p-3 rounded-xl text-left hover:bg-indigo-50 smooth flex items-center justify-between"
                  >
                    <span className="text-sm font-medium text-gray-900">{suggestion.label}</span>
                    <Clock className="w-4 h-4 text-indigo-600" />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="neo-button flex-1 py-3 rounded-2xl font-semibold"
          >
            Cancel Booking
          </button>
          <button
            onClick={() => onResolve(null)}
            className="neo-button flex-1 py-3 rounded-2xl font-semibold text-orange-700"
          >
            Book Anyway
          </button>
        </div>
      </motion.div>
    </div>
  );
}