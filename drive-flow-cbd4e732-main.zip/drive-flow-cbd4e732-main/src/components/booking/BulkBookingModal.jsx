import React, { useState } from "react";
import { X, Plus, Trash2, Calendar, Clock } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format, addDays } from "date-fns";

export default function BulkBookingModal({ 
  isOpen, 
  onClose, 
  instructor,
  vehicle,
  student,
  onSubmit 
}) {
  const [bookings, setBookings] = useState([
    { date: new Date(), time: "09:00" }
  ]);

  const addBooking = () => {
    const lastBooking = bookings[bookings.length - 1];
    const newDate = addDays(new Date(lastBooking.date), 7);
    setBookings([...bookings, { date: newDate, time: lastBooking.time }]);
  };

  const removeBooking = (index) => {
    setBookings(bookings.filter((_, i) => i !== index));
  };

  const updateBooking = (index, field, value) => {
    const updated = [...bookings];
    updated[index][field] = value;
    setBookings(updated);
  };

  const handleSubmit = () => {
    onSubmit(bookings);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="neo-surface p-8 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Book Multiple Lessons</h2>
          <button onClick={onClose} className="neo-button p-3 rounded-xl">
            <X className="w-5 h-5 text-gray-700" />
          </button>
        </div>

        <div className="neo-inset p-4 rounded-2xl mb-6">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted mb-1">Instructor</p>
              <p className="font-semibold text-gray-900">{instructor?.full_name}</p>
            </div>
            <div>
              <p className="text-muted mb-1">Vehicle</p>
              <p className="font-semibold text-gray-900">{vehicle?.make} {vehicle?.model}</p>
            </div>
          </div>
        </div>

        <div className="space-y-4 mb-6">
          {bookings.map((booking, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="neo-inset p-4 rounded-2xl"
            >
              <div className="flex items-center gap-4">
                <span className="neo-button w-8 h-8 rounded-xl flex items-center justify-center font-bold text-indigo-600">
                  {index + 1}
                </span>
                
                <div className="flex-1 grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-muted mb-1 block">Date</label>
                    <input
                      type="date"
                      value={format(booking.date, 'yyyy-MM-dd')}
                      onChange={(e) => updateBooking(index, 'date', new Date(e.target.value))}
                      className="neo-button w-full px-3 py-2 rounded-xl focus:outline-none"
                    />
                  </div>
                  
                  <div>
                    <label className="text-xs text-muted mb-1 block">Time</label>
                    <input
                      type="time"
                      value={booking.time}
                      onChange={(e) => updateBooking(index, 'time', e.target.value)}
                      className="neo-button w-full px-3 py-2 rounded-xl focus:outline-none"
                    />
                  </div>
                </div>

                {bookings.length > 1 && (
                  <button
                    onClick={() => removeBooking(index)}
                    className="neo-button p-2 rounded-xl text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        <button
          onClick={addBooking}
          className="neo-button w-full py-3 rounded-2xl flex items-center justify-center gap-2 font-semibold text-indigo-600 mb-6"
        >
          <Plus className="w-5 h-5" />
          Add Another Lesson
        </button>

        <div className="neo-inset p-4 rounded-2xl mb-6">
          <p className="text-sm text-muted mb-2">Summary</p>
          <p className="text-2xl font-bold text-gray-900">{bookings.length} Lessons</p>
          <p className="text-sm text-gray-700 mt-2">
            First: {format(bookings[0].date, 'MMM d')} at {bookings[0].time}
          </p>
          {bookings.length > 1 && (
            <p className="text-sm text-gray-700">
              Last: {format(bookings[bookings.length - 1].date, 'MMM d')} at {bookings[bookings.length - 1].time}
            </p>
          )}
        </div>

        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="neo-button flex-1 py-3 rounded-2xl font-semibold"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="neo-button flex-1 py-3 rounded-2xl gradient-primary text-white font-semibold"
          >
            Book {bookings.length} Lessons
          </button>
        </div>
      </motion.div>
    </div>
  );
}