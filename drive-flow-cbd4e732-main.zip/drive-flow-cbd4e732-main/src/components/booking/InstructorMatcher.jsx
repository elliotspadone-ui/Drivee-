/**
 * Intelligent Instructor Matching Algorithm
 * Matches students with instructors based on multiple criteria
 */

export class InstructorMatcher {
  constructor(instructors, student, bookings, reviews) {
    this.instructors = instructors;
    this.student = student;
    this.bookings = bookings;
    this.reviews = reviews;
  }

  /**
   * Calculate match score for each instructor
   */
  calculateMatchScores() {
    return this.instructors
      .filter(i => i.is_active)
      .map(instructor => ({
        instructor,
        score: this.calculateScore(instructor),
        breakdown: this.getScoreBreakdown(instructor)
      }))
      .sort((a, b) => b.score - a.score);
  }

  calculateScore(instructor) {
    let score = 0;

    // License category match (30 points)
    if (instructor.certifications?.includes(this.student.license_category)) {
      score += 30;
    }

    // Language match (20 points)
    const studentLanguages = this.student.preferred_languages || ['en'];
    const instructorLanguages = instructor.languages || ['en'];
    const languageMatch = studentLanguages.some(lang => 
      instructorLanguages.includes(lang)
    );
    if (languageMatch) score += 20;

    // Rating (20 points)
    score += (instructor.rating || 0) * 4;

    // Transmission preference (10 points)
    const studentPrefersManual = this.student.preferred_transmission === 'manual';
    const instructorHasManual = this.getInstructorVehicles(instructor)
      .some(v => v.transmission === 'manual');
    if (!studentPrefersManual || instructorHasManual) score += 10;

    // Location proximity (10 points) - simplified
    if (this.student.pickup_zone && instructor.service_areas?.includes(this.student.pickup_zone)) {
      score += 10;
    }

    // Availability (10 points)
    const availabilityScore = this.getAvailabilityScore(instructor);
    score += availabilityScore;

    return Math.min(100, score);
  }

  getScoreBreakdown(instructor) {
    return {
      license: instructor.certifications?.includes(this.student.license_category) ? 30 : 0,
      language: 20, // Simplified
      rating: (instructor.rating || 0) * 4,
      transmission: 10,
      location: 10,
      availability: this.getAvailabilityScore(instructor)
    };
  }

  getAvailabilityScore(instructor) {
    const instructorBookings = this.bookings.filter(b => 
      b.instructor_id === instructor.id &&
      b.status !== 'cancelled' &&
      new Date(b.start_datetime) > new Date()
    );
    
    // More available = higher score
    if (instructorBookings.length < 10) return 10;
    if (instructorBookings.length < 20) return 7;
    if (instructorBookings.length < 30) return 4;
    return 0;
  }

  getInstructorVehicles(instructor) {
    // Would filter vehicles by instructor's school
    return [];
  }

  /**
   * Get best match
   */
  getBestMatch() {
    const matches = this.calculateMatchScores();
    return matches.length > 0 ? matches[0] : null;
  }

  /**
   * Get top N matches
   */
  getTopMatches(n = 5) {
    return this.calculateMatchScores().slice(0, n);
  }
}

export default InstructorMatcher;