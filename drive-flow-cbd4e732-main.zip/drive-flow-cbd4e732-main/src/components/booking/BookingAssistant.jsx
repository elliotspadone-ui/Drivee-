import React, { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  MessageCircle, 
  Send, 
  X, 
  Sparkles, 
  Package, 
  Calendar, 
  User, 
  Clock, 
  Target,
  ChevronRight,
  Loader2,
  Lightbulb,
  CheckCircle,
  Car,
  Zap,
  BookOpen
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { format, addDays } from "date-fns";

// ============================================================================
// AI ASSISTANT FOR BOOKING
// ============================================================================

export default function BookingAssistant({
  packages = [],
  instructors = [],
  lessonTypes = [],
  student = null,
  allBookings = [],
  onSelectPackage,
  onSelectLessonType,
  onSelectInstructor,
  onSelectDateTime,
  onApplySuggestion,
  currentStep = 1,
  selectedInstructor = null,
  selectedDate = null
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [hasGreeted, setHasGreeted] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Initial greeting when opened
  useEffect(() => {
    if (isOpen && !hasGreeted) {
      const greeting = getContextualGreeting();
      addBotMessage(greeting.message, greeting.suggestions);
      setHasGreeted(true);
    }
  }, [isOpen, hasGreeted]);

  const getContextualGreeting = () => {
    const hour = new Date().getHours();
    const timeGreeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
    const name = student?.full_name?.split(" ")[0] || "";
    
    if (currentStep === 1) {
      return {
        message: `${timeGreeting}${name ? `, ${name}` : ""}! 👋 I'm your booking assistant. I can help you:\n\n• Find the perfect lesson package\n• Match you with the right instructor\n• Suggest optimal scheduling times\n\nTell me about your driving experience and goals, or ask me anything!`,
        suggestions: [
          { text: "I'm a complete beginner", action: "beginner" },
          { text: "I need help with theory test", action: "theory" },
          { text: "Preparing for practical exam", action: "exam_prep" },
          { text: "Recommend a package", action: "package_help" }
        ]
      };
    } else if (currentStep === 3) {
      return {
        message: `I can help you find the best time slot! When do you prefer to have lessons?`,
        suggestions: [
          { text: "Morning (8am-12pm)", action: "time_morning" },
          { text: "Afternoon (12pm-5pm)", action: "time_afternoon" },
          { text: "Evening (5pm-8pm)", action: "time_evening" },
          { text: "Weekends only", action: "time_weekend" }
        ]
      };
    }
    
    return {
      message: `${timeGreeting}! How can I help you with your booking today?`,
      suggestions: []
    };
  };

  const addBotMessage = (text, newSuggestions = []) => {
    setMessages(prev => [...prev, { role: "assistant", content: text, timestamp: new Date() }]);
    setSuggestions(newSuggestions);
  };

  const addUserMessage = (text) => {
    setMessages(prev => [...prev, { role: "user", content: text, timestamp: new Date() }]);
    setSuggestions([]);
  };

  const analyzeUserNeedsWithAI = async (userMessage) => {
    setIsTyping(true);
    
    try {
      const context = {
        packages: packages.map(p => ({
          id: p.id,
          name: p.name,
          lessons: p.number_of_lessons,
          price: p.total_price,
          includesTheory: p.includes_theory,
          includesExamCar: p.includes_exam_car,
          description: p.description
        })),
        lessonTypes: lessonTypes.map(lt => ({
          id: lt.id,
          name: lt.name,
          description: lt.description,
          price: lt.price,
          duration: lt.duration
        })),
        instructorCount: instructors.filter(i => i.is_active).length,
        studentProgress: student ? {
          lessonsCompleted: student.total_lessons_completed || 0,
          theoryPassed: student.theory_exam_passed || false,
          practicalPassed: student.practical_exam_passed || false
        } : null,
        currentStep
      };

      const prompt = `You are a helpful driving school booking assistant. Analyze the user's message and provide personalized recommendations.

User's message: "${userMessage}"

Available context:
${JSON.stringify(context, null, 2)}

Based on the user's needs, provide:
1. A helpful, friendly response (2-3 sentences max)
2. Specific recommendations for packages or lesson types if relevant
3. Any proactive suggestions for optimization

Response format (JSON):
{
  "message": "Your friendly response here",
  "recommendedPackageId": "package_id or null",
  "recommendedLessonType": "lesson_type_id or null", 
  "recommendedInstructorPreferences": { "experience": "beginner|experienced|expert", "gender": "any|male|female" } or null,
  "suggestedTimeSlots": ["morning", "afternoon", "evening"] or null,
  "actionSuggestions": [
    { "text": "Button text", "action": "action_id" }
  ]
}`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            message: { type: "string" },
            recommendedPackageId: { type: ["string", "null"] },
            recommendedLessonType: { type: ["string", "null"] },
            recommendedInstructorPreferences: {
              type: ["object", "null"],
              properties: {
                experience: { type: "string" },
                gender: { type: "string" }
              }
            },
            suggestedTimeSlots: {
              type: ["array", "null"],
              items: { type: "string" }
            },
            actionSuggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  text: { type: "string" },
                  action: { type: "string" }
                }
              }
            }
          }
        }
      });

      setIsTyping(false);
      return result;
    } catch (error) {
      console.error("AI analysis error:", error);
      setIsTyping(false);
      return {
        message: "I'd be happy to help! Could you tell me more about your driving experience and what you're looking to achieve?",
        actionSuggestions: [
          { text: "I'm a beginner", action: "beginner" },
          { text: "Show me packages", action: "package_help" }
        ]
      };
    }
  };

  const handleSuggestionClick = async (suggestion) => {
    addUserMessage(suggestion.text);
    
    switch (suggestion.action) {
      case "beginner":
        await handleBeginnerFlow();
        break;
      case "theory":
        await handleTheoryFlow();
        break;
      case "exam_prep":
        await handleExamPrepFlow();
        break;
      case "package_help":
        await handlePackageRecommendation();
        break;
      case "time_morning":
      case "time_afternoon":
      case "time_evening":
      case "time_weekend":
        await handleTimePreference(suggestion.action);
        break;
      case "select_package":
        if (suggestion.packageId && onSelectPackage) {
          onSelectPackage(suggestion.packageId);
          addBotMessage("Great choice! I've selected that package for you. Let's move on to choosing an instructor! 🚗");
        }
        break;
      case "select_lesson_type":
        if (suggestion.lessonTypeId && onSelectLessonType) {
          onSelectLessonType(suggestion.lessonTypeId);
          addBotMessage("Perfect! I've set that lesson type for you. ✓");
        }
        break;
      default:
        const aiResponse = await analyzeUserNeedsWithAI(suggestion.text);
        processAIResponse(aiResponse);
    }
  };

  const handleBeginnerFlow = async () => {
    const beginnerPackages = packages.filter(p => 
      p.includes_theory || 
      p.number_of_lessons >= 15 ||
      p.name?.toLowerCase().includes("beginner") ||
      p.name?.toLowerCase().includes("starter")
    );

    const recommended = beginnerPackages[0] || packages.sort((a, b) => 
      (a.total_price || 0) - (b.total_price || 0)
    )[0];

    let message = "Perfect! As a beginner, I recommend starting with a comprehensive package that includes:\n\n";
    message += "✓ Theory preparation\n";
    message += "✓ Multiple practice lessons\n";
    message += "✓ Patient, experienced instructors\n\n";

    if (recommended) {
      message += `I'd suggest the **${recommended.name}** package (${recommended.number_of_lessons} lessons for €${recommended.total_price}).`;
    }

    const suggestions = [];
    if (recommended) {
      suggestions.push({ 
        text: `Select ${recommended.name}`, 
        action: "select_package",
        packageId: recommended.id
      });
    }
    suggestions.push({ text: "Show more options", action: "package_help" });
    suggestions.push({ text: "I need something different", action: "custom" });

    addBotMessage(message, suggestions);

    if (onApplySuggestion) {
      onApplySuggestion({
        type: "instructor_preference",
        experience: "beginner",
        gender: "any"
      });
    }
  };

  const handleTheoryFlow = async () => {
    const theoryPackages = packages.filter(p => p.includes_theory);
    
    let message = "For theory test preparation, I recommend:\n\n";
    message += "📚 A package that includes theory materials\n";
    message += "📝 Practice tests and mock exams\n";
    message += "⏰ Flexible study schedule\n\n";

    if (theoryPackages.length > 0) {
      const recommended = theoryPackages[0];
      message += `The **${recommended.name}** includes theory preparation!`;
    } else {
      message += "I can also recommend our dedicated theory learning resources.";
    }

    const suggestions = theoryPackages.slice(0, 2).map(p => ({
      text: `${p.name} - €${p.total_price}`,
      action: "select_package",
      packageId: p.id
    }));
    suggestions.push({ text: "Just practical lessons", action: "practical_only" });

    addBotMessage(message, suggestions);
  };

  const handleExamPrepFlow = async () => {
    const examLessonType = lessonTypes.find(lt => 
      lt.id === "test_prep" || lt.name?.toLowerCase().includes("test")
    );

    let message = "Getting ready for your practical exam! 🎯 Here's what I recommend:\n\n";
    message += "✓ **Test Preparation** lessons to simulate exam conditions\n";
    message += "✓ Focus on maneuvers and route practice\n";
    message += "✓ Experienced instructor who knows exam routes\n\n";
    
    if (examLessonType) {
      message += `I'd suggest booking **${examLessonType.name}** sessions (€${examLessonType.price} for ${examLessonType.duration} min).`;
    }

    const suggestions = [];
    if (examLessonType) {
      suggestions.push({
        text: `Book Test Prep lesson`,
        action: "select_lesson_type",
        lessonTypeId: examLessonType.id
      });
    }
    suggestions.push({ text: "Show all lesson types", action: "lesson_types" });
    suggestions.push({ text: "Match me with exam-focused instructor", action: "exam_instructor" });

    addBotMessage(message, suggestions);

    if (onApplySuggestion) {
      onApplySuggestion({
        type: "instructor_preference",
        experience: "expert",
        focusArea: "exam_prep"
      });
    }
  };

  const handlePackageRecommendation = async () => {
    if (packages.length === 0) {
      addBotMessage("I don't see any packages available right now. Let me help you with individual lesson booking instead!", [
        { text: "Book single lesson", action: "single_lesson" }
      ]);
      return;
    }

    const sortedPackages = [...packages].sort((a, b) => 
      (b.number_of_lessons || 0) - (a.number_of_lessons || 0)
    );

    let message = "Here are the available packages:\n\n";
    sortedPackages.slice(0, 3).forEach((pkg, idx) => {
      const pricePerLesson = pkg.total_price && pkg.number_of_lessons 
        ? Math.round(pkg.total_price / pkg.number_of_lessons)
        : null;
      message += `${idx + 1}. **${pkg.name}**\n`;
      message += `   ${pkg.number_of_lessons} lessons • €${pkg.total_price}`;
      if (pricePerLesson) message += ` (€${pricePerLesson}/lesson)`;
      if (pkg.includes_theory) message += ` • Includes theory`;
      message += "\n\n";
    });

    message += "Which one interests you? I can explain more about any package.";

    const suggestions = sortedPackages.slice(0, 3).map(pkg => ({
      text: `Select ${pkg.name}`,
      action: "select_package",
      packageId: pkg.id
    }));

    addBotMessage(message, suggestions);
  };

  const handleTimePreference = async (preference) => {
    const timeRanges = {
      time_morning: { start: 8, end: 12, label: "morning" },
      time_afternoon: { start: 12, end: 17, label: "afternoon" },
      time_evening: { start: 17, end: 20, label: "evening" },
      time_weekend: { start: 8, end: 20, label: "weekend" }
    };

    const range = timeRanges[preference];
    
    // Find available slots matching preference
    const availableSlots = findOptimalSlots(range, selectedInstructor, selectedDate, allBookings);

    let message = `Great! I'll look for ${range.label} slots. `;
    
    if (availableSlots.length > 0) {
      message += `I found ${availableSlots.length} available times:\n\n`;
      availableSlots.slice(0, 3).forEach(slot => {
        message += `📅 ${format(slot.date, "EEEE, MMM d")} at ${slot.time}\n`;
      });
      message += "\nWould you like me to book one of these?";
    } else {
      message += "I couldn't find exact matches, but let me suggest some alternatives.";
    }

    const suggestions = availableSlots.slice(0, 3).map(slot => ({
      text: `${format(slot.date, "EEE d")} at ${slot.time}`,
      action: "select_slot",
      slotData: slot
    }));

    if (suggestions.length === 0) {
      suggestions.push({ text: "Show all available times", action: "all_times" });
    }

    addBotMessage(message, suggestions);

    if (onApplySuggestion) {
      onApplySuggestion({
        type: "time_preference",
        preference: range.label,
        slots: availableSlots
      });
    }
  };

  const findOptimalSlots = (timeRange, instructor, date, bookings) => {
    const slots = [];
    const searchDays = 14;
    
    for (let dayOffset = 0; dayOffset < searchDays; dayOffset++) {
      const checkDate = addDays(date || new Date(), dayOffset);
      const dayOfWeek = checkDate.getDay();
      
      // Skip weekdays for weekend preference
      if (timeRange.label === "weekend" && dayOfWeek !== 0 && dayOfWeek !== 6) {
        continue;
      }
      
      for (let hour = timeRange.start; hour < timeRange.end; hour++) {
        const slotTime = `${hour.toString().padStart(2, "0")}:00`;
        
        // Check if slot is available (simplified check)
        const isBooked = bookings.some(b => {
          if (instructor && b.instructor_id !== instructor.id) return false;
          const bookingDate = new Date(b.start_datetime);
          return format(bookingDate, "yyyy-MM-dd") === format(checkDate, "yyyy-MM-dd") &&
                 format(bookingDate, "HH:mm") === slotTime;
        });

        if (!isBooked) {
          slots.push({
            date: checkDate,
            time: slotTime,
            dayOfWeek: format(checkDate, "EEEE")
          });
        }
      }
      
      if (slots.length >= 10) break;
    }
    
    return slots;
  };

  const processAIResponse = (response) => {
    addBotMessage(response.message, response.actionSuggestions || []);

    // Apply any recommendations
    if (response.recommendedPackageId && onApplySuggestion) {
      onApplySuggestion({
        type: "package_recommendation",
        packageId: response.recommendedPackageId
      });
    }

    if (response.recommendedLessonType && onApplySuggestion) {
      onApplySuggestion({
        type: "lesson_type_recommendation",
        lessonTypeId: response.recommendedLessonType
      });
    }

    if (response.recommendedInstructorPreferences && onApplySuggestion) {
      onApplySuggestion({
        type: "instructor_preference",
        ...response.recommendedInstructorPreferences
      });
    }
  };

  const handleSendMessage = async () => {
    const message = inputValue.trim();
    if (!message) return;

    addUserMessage(message);
    setInputValue("");
    
    const aiResponse = await analyzeUserNeedsWithAI(message);
    processAIResponse(aiResponse);
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Floating Button */}
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.5, type: "spring" }}
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 z-50 w-16 h-16 rounded-full shadow-lg hover:shadow-xl transition-all flex items-center justify-center ${isOpen ? "hidden" : ""}`}
      >
        <img 
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691b056345d5788acbd4e732/0ff5868d6_ChatGPTImageDec5202503_24_09PM.png" 
          alt="AI Assistant"
          className="w-20 h-20 object-contain scale-110"
        />
        <span className="absolute top-0 right-0 w-4 h-4 bg-emerald-500 rounded-full animate-pulse border-2 border-white" />
      </motion.button>

      {/* Chat Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: "spring", damping: 25 }}
            className="fixed bottom-6 right-6 z-50 w-[380px] max-w-[calc(100vw-48px)] h-[560px] max-h-[calc(100vh-100px)] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-[#3b82c4] to-[#6c376f] p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-white">Booking Assistant</h3>
                  <p className="text-xs text-white/70">AI-powered help</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((msg, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                      msg.role === "user"
                        ? "bg-[#3b82c4] text-white"
                        : "bg-slate-100 text-slate-800"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">
                      {msg.content.split("**").map((part, i) => 
                        i % 2 === 1 ? <strong key={i}>{part}</strong> : part
                      )}
                    </p>
                  </div>
                </motion.div>
              ))}

              {isTyping && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-start"
                >
                  <div className="bg-slate-100 rounded-2xl px-4 py-3">
                    <div className="flex items-center gap-1">
                      <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                </motion.div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Suggestions */}
            {suggestions.length > 0 && (
              <div className="px-4 pb-2">
                <div className="flex flex-wrap gap-2">
                  {suggestions.map((suggestion, idx) => (
                    <motion.button
                      key={idx}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: idx * 0.05 }}
                      onClick={() => handleSuggestionClick(suggestion)}
                      className="px-3 py-1.5 bg-[#e8f4fa] hover:bg-[#d4eaf5] text-[#3b82c4] text-sm font-medium rounded-full transition-colors flex items-center gap-1"
                    >
                      <Lightbulb className="w-3 h-3" />
                      {suggestion.text}
                    </motion.button>
                  ))}
                </div>
              </div>
            )}

            {/* Input */}
            <div className="p-4 border-t border-slate-200">
              <div className="flex items-center gap-2">
                <input
                  ref={inputRef}
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me anything about booking..."
                  className="flex-1 px-4 py-2.5 bg-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#a9d5ed]"
                  disabled={isTyping}
                />
                <button
                  onClick={handleSendMessage}
                  disabled={!inputValue.trim() || isTyping}
                  className="p-2.5 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isTyping ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <Send className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}