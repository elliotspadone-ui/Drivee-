/**
 * PAYMENT PROCESSING SYSTEM - COMPLETE DESIGN DOCUMENT
 * 
 * This file contains the comprehensive architecture and design specifications
 * for the driving school platform's payment processing system.
 */

export const PAYMENT_SYSTEM_DESIGN = {
  
  /* ============================================
     1. DATABASE SCHEMA
     ============================================ */
  
  entities: {
    PaymentMethod: {
      description: "Stores student payment methods (cards, ACH, wallets)",
      fields: {
        school_id: "Reference to School",
        student_id: "Reference to Student",
        stripe_payment_method_id: "Stripe payment method ID",
        type: "card | ach | apple_pay | google_pay",
        card_brand: "Visa, Mastercard, etc.",
        last_four: "Last 4 digits",
        expiry_month: "Number",
        expiry_year: "Number",
        is_default: "Boolean",
        billing_address: "Object with address fields",
        is_active: "Boolean"
      }
    },

    Transaction: {
      description: "Records all payment transactions",
      fields: {
        school_id: "Reference to School",
        student_id: "Reference to Student",
        payment_id: "Reference to Payment",
        stripe_payment_intent_id: "Stripe payment intent ID",
        stripe_charge_id: "Stripe charge ID",
        amount: "Number",
        currency: "String (usd)",
        type: "charge | refund | late_fee | installment | deposit",
        status: "pending | processing | succeeded | failed | cancelled | refunded",
        payment_method_id: "Reference to PaymentMethod",
        failure_code: "Error code if failed",
        failure_message: "Error description",
        retry_count: "Number of retry attempts",
        next_retry_date: "DateTime for next retry",
        metadata: "Additional data object",
        receipt_url: "Stripe receipt URL",
        processed_at: "DateTime"
      }
    },

    PaymentPlan: {
      description: "Manages installment and payment plans",
      fields: {
        school_id: "Reference to School",
        student_id: "Reference to Student",
        package_id: "Reference to Package",
        total_amount: "Total plan amount",
        amount_paid: "Amount paid so far",
        remaining_balance: "Remaining to pay",
        installment_amount: "Amount per installment",
        installment_frequency: "weekly | biweekly | monthly",
        total_installments: "Number of installments",
        completed_installments: "Number completed",
        next_payment_date: "Date",
        payment_method_id: "Reference to PaymentMethod",
        status: "active | completed | defaulted | cancelled",
        auto_charge_enabled: "Boolean",
        late_fee_percentage: "Number",
        grace_period_days: "Number",
        failed_payment_count: "Number"
      }
    },

    StripeAccount: {
      description: "Manages Stripe Connect accounts per school",
      fields: {
        school_id: "Reference to School",
        stripe_account_id: "Stripe Connect account ID",
        account_type: "standard | express | custom",
        charges_enabled: "Boolean - can accept payments",
        payouts_enabled: "Boolean - can receive payouts",
        details_submitted: "Boolean - onboarding complete",
        onboarding_completed: "Boolean",
        platform_fee_percentage: "Platform commission (default 5%)",
        instructor_split_percentage: "% to instructor (default 70%)",
        default_currency: "String (usd)",
        business_name: "School business name",
        business_tax_id: "Tax ID",
        bank_account_last_four: "Last 4 of bank account",
        requirements: "Stripe onboarding requirements object",
        is_active: "Boolean"
      }
    },

    PaymentSplit: {
      description: "Records payment distribution",
      fields: {
        payment_id: "Reference to Payment",
        transaction_id: "Reference to Transaction",
        school_id: "Reference to School",
        instructor_id: "Reference to Instructor",
        total_amount: "Original payment amount",
        platform_fee: "Platform commission",
        school_amount: "School's share after platform fee",
        instructor_amount: "Instructor's share",
        stripe_transfer_id: "Stripe transfer ID for instructor payout",
        split_status: "pending | processed | failed",
        processed_at: "DateTime"
      }
    },

    InvoiceTemplate: {
      description: "Customizable invoice designs",
      fields: {
        school_id: "Reference to School",
        template_name: "Template name",
        is_default: "Boolean",
        logo_url: "School logo URL",
        primary_color: "Hex color code",
        header_text: "Invoice header",
        footer_text: "Invoice footer",
        payment_terms: "Payment terms text",
        notes: "Additional notes",
        show_payment_methods: "Boolean",
        show_tax_breakdown: "Boolean",
        include_qr_code: "Boolean"
      }
    },

    // Enhanced existing entities
    Payment_Enhancements: {
      new_fields: {
        stripe_payment_intent_id: "Link to Stripe payment intent",
        payment_plan_id: "Reference to PaymentPlan if installment",
        platform_fee: "Platform commission amount",
        school_net_amount: "Amount after platform fee",
        instructor_amount: "Instructor's share",
        payment_split_status: "pending | processed | failed"
      }
    },

    Invoice_Enhancements: {
      new_fields: {
        invoice_template_id: "Reference to InvoiceTemplate",
        stripe_invoice_id: "Stripe invoice ID",
        payment_link: "Unique payment URL",
        due_date: "Payment due date",
        late_fee_applied: "Late fee amount if any",
        reminder_sent_count: "Number of reminders sent"
      }
    }
  },

  /* ============================================
     2. STRIPE CONNECT ARCHITECTURE
     ============================================ */

  stripeConnect: {
    structure: {
      platform: "Your main Stripe account",
      connectedAccounts: "One per driving school (Express accounts recommended)",
      benefits: [
        "Stripe handles onboarding UI",
        "Quick setup process",
        "Stripe manages compliance",
        "Schools maintain control of their money"
      ]
    },

    onboardingFlow: [
      "1. School registers on platform",
      "2. Create Stripe Express Account via API",
      "3. Generate account link for onboarding",
      "4. School completes Stripe onboarding (handled by Stripe)",
      "5. Verify charges_enabled and payouts_enabled",
      "6. Store account ID in StripeAccount entity"
    ],

    paymentFlow: {
      description: "Student Payment → Platform → School → Instructor",
      splits: {
        platform_fee: "5% of payment goes to platform",
        school_share: "95% goes to school's Stripe account",
        instructor_split: "70% of school's share can go to instructor (configurable)"
      }
    }
  },

  /* ============================================
     3. PAYMENT FLOWS
     ============================================ */

  flows: {
    
    oneTimePayment: [
      "1. Student selects service/package",
      "2. Choose payment method (saved or new via Stripe Elements)",
      "3. Review order and confirm",
      "4. Create Stripe Payment Intent with:",
      "   - amount: total",
      "   - application_fee_amount: platform_fee",
      "   - on_behalf_of: school_stripe_account",
      "   - transfer_data: { destination: school_account }",
      "5. Process payment via Stripe",
      "6. On success:",
      "   - Generate invoice",
      "   - Update booking status to 'paid'",
      "   - Create Transaction record",
      "   - Create PaymentSplit record",
      "   - Send confirmation email",
      "7. On failure: Execute retry logic"
    ],

    paymentPlan: [
      "1. Student selects package and chooses payment plan",
      "2. Configure plan:",
      "   - Down payment amount",
      "   - Number of installments",
      "   - Frequency (weekly/monthly)",
      "   - Select payment method",
      "3. Create PaymentPlan entity",
      "4. Process initial down payment",
      "5. Schedule future payments",
      "6. Automated job runs daily:",
      "   - Check for due payments",
      "   - Charge payment method automatically",
      "   - Update plan progress"
    ],

    retryLogic: [
      "1. Payment fails → Record failure details",
      "2. Check if failure is retryable",
      "3. Schedule retry:",
      "   - Retry 1: +1 day",
      "   - Retry 2: +3 days",
      "   - Retry 3: +7 days",
      "4. Send notification to student",
      "5. Attempt retry on scheduled date",
      "6. After 3 failed attempts:",
      "   - Mark PaymentPlan as 'defaulted'",
      "   - Suspend booking privileges",
      "   - Require manual intervention"
    ],

    lateFees: [
      "1. Daily automated job checks overdue payments",
      "2. Filter by grace_period_days passed",
      "3. Calculate late_fee = amount × late_fee_percentage",
      "4. Add to remaining_balance",
      "5. Create late_fee Transaction",
      "6. Send notification to student"
    ],

    refundProcess: [
      "1. Refund request initiated",
      "2. Validate against refund policy",
      "3. Calculate refund amount (policy % minus non-refundable fees)",
      "4. Create Stripe refund:",
      "   - refund_application_fee: true",
      "   - reverse_transfer: true",
      "5. Update records:",
      "   - Payment status = 'refunded'",
      "   - Create refund Transaction",
      "   - Reverse PaymentSplit amounts",
      "6. Process instructor clawback if already paid",
      "7. Send notifications to all parties"
    ],

    splitPayment: [
      "1. Payment succeeds → Calculate splits:",
      "   Example: $100 payment",
      "   - Platform fee: $100 × 5% = $5",
      "   - School net: $100 - $5 = $95",
      "   - Instructor: $95 × 70% = $66.50",
      "   - School keeps: $28.50",
      "2. Create PaymentSplit record",
      "3. Platform fee automatically deducted by Stripe",
      "4. School receives $95 in their account",
      "5. Transfer $66.50 to instructor's account",
      "6. Update PaymentSplit status to 'processed'"
    ]
  },

  /* ============================================
     4. API ENDPOINTS (Backend Functions)
     ============================================ */

  backendFunctions: {
    
    CreatePaymentIntent: {
      input: {
        student_id: "string",
        amount: "number",
        school_id: "string",
        booking_id: "string",
        payment_method_id: "string"
      },
      process: [
        "1. Fetch school's StripeAccount",
        "2. Calculate platform_fee = amount × platform_fee_percentage",
        "3. Create Stripe PaymentIntent with all parameters",
        "4. Create Transaction record",
        "5. Return client_secret"
      ],
      output: {
        client_secret: "string",
        payment_intent_id: "string",
        transaction_id: "string"
      }
    },

    SetupPaymentMethod: {
      input: {
        student_id: "string",
        payment_method_id: "string (from Stripe Elements)"
      },
      process: [
        "1. Attach payment method to student's Stripe customer",
        "2. Create PaymentMethod entity record",
        "3. Set as default if first method"
      ],
      output: {
        payment_method_id: "string",
        success: "boolean"
      }
    },

    CreatePaymentPlan: {
      input: {
        student_id: "string",
        package_id: "string",
        down_payment: "number",
        total_installments: "number",
        installment_frequency: "string",
        payment_method_id: "string"
      },
      process: [
        "1. Calculate installment_amount",
        "2. Create PaymentPlan entity",
        "3. Process down payment immediately",
        "4. Schedule first installment"
      ],
      output: {
        payment_plan_id: "string",
        next_payment_date: "date",
        installment_amount: "number"
      }
    },

    ProcessRefund: {
      input: {
        payment_id: "string",
        reason: "string",
        amount: "number (optional)"
      },
      process: [
        "1. Fetch original Payment and Transaction",
        "2. Validate refund policy",
        "3. Calculate refund amount",
        "4. Create Stripe Refund",
        "5. Update entities",
        "6. Send notifications"
      ],
      output: {
        refund_id: "string",
        refund_amount: "number",
        success: "boolean"
      }
    },

    ProcessScheduledPayments: {
      trigger: "Daily cron job",
      process: [
        "1. Fetch active PaymentPlans where next_payment_date <= today",
        "2. For each plan: charge, update progress, handle failures",
        "3. Check for overdue payments and apply late fees",
        "4. Retry failed transactions based on schedule"
      ],
      output: {
        processed_count: "number",
        success_count: "number",
        failed_count: "number",
        late_fees_applied: "number"
      }
    }
  },

  /* ============================================
     5. SECURITY & PCI COMPLIANCE
     ============================================ */

  security: {
    
    pciCompliance: {
      principle: "NEVER store sensitive card data on your servers",
      implementation: [
        "Use Stripe Elements/Payment Element for card input",
        "Tokenization happens on Stripe's servers",
        "Store only Stripe payment_method_id tokens",
        "Store last 4 digits and brand for display only",
        "Never store full PAN, CVV, or PIN"
      ]
    },

    dataEncryption: {
      encrypted_fields: [
        "stripe_payment_method_id - Encrypted at rest",
        "billing_address - Encrypted at rest"
      ],
      accessControl: {
        students: "View only their own payment methods",
        instructors: "No access to payment data",
        schoolAdmins: "View payment reports, no raw card data",
        platformAdmins: "Access for support only, audit logged"
      }
    },

    webhookSecurity: [
      "Verify Stripe webhook signatures using stripe.webhooks.constructEvent()",
      "Use HTTPS only",
      "Validate event authenticity",
      "Store webhook secret in environment variables"
    ],

    fraudPrevention: [
      "Use Stripe Radar for fraud detection",
      "Implement velocity checks",
      "Monitor for unusual payment patterns",
      "Require 3D Secure for high-value transactions",
      "Block suspicious IP addresses"
    ]
  },

  /* ============================================
     6. ERROR HANDLING
     ============================================ */

  errorHandling: {
    
    paymentFailures: {
      card_declined: "Retry with exponential backoff",
      insufficient_funds: "Wait 3 days, notify student",
      expired_card: "Request new payment method",
      incorrect_cvc: "Request correction",
      processing_error: "Retry immediately, then backoff",
      card_velocity_exceeded: "Wait 24 hours"
    },

    refundEdgeCases: {
      partial_refunds: "Calculate split proportionally",
      multiple_payments: "Refund most recent first",
      expired_cards: "Refund still processes to card issuer",
      closed_accounts: "Stripe handles return to issuer"
    },

    splitPaymentEdgeCases: {
      instructor_not_onboarded: "Hold funds, transfer when ready",
      instructor_suspended: "Transfer to school holding account",
      multiple_instructors: "Split proportionally by lesson count"
    }
  },

  /* ============================================
     7. TESTING
     ============================================ */

  testing: {
    
    stripeTestCards: {
      success: "4242 4242 4242 4242",
      decline: "4000 0000 0000 0002",
      insufficient_funds: "4000 0000 0000 9995",
      expired: "4000 0000 0000 0069",
      processing_error: "4000 0000 0000 0119"
    },

    testScenarios: [
      "One-time payment success",
      "Payment failure with retry",
      "Create and process payment plan",
      "Missed installment with late fee",
      "Full refund processing",
      "Partial refund with split adjustment",
      "Split payment to instructor",
      "Invoice generation and email"
    ]
  },

  /* ============================================
     8. COMPLIANCE & LEGAL
     ============================================ */

  compliance: {
    
    requiredDisclosures: [
      "Payment terms and conditions",
      "Refund policy clearly stated",
      "Late fee disclosure",
      "Platform fee transparency (for schools)",
      "Data handling and privacy policy"
    ],

    recordRetention: {
      transaction_records: "7 years",
      invoice_copies: "7 years",
      refund_documentation: "7 years",
      payment_method_tokens: "Until deleted by user"
    }
  },

  /* ============================================
     9. IMPLEMENTATION PHASES
     ============================================ */

  implementation: {
    
    phase1_foundation: [
      "Create all entity schemas",
      "Set up Stripe Connect integration",
      "Implement payment intent creation",
      "Add payment method management",
      "Create basic invoice generation"
    ],

    phase2_advanced: [
      "Implement payment plans",
      "Add automated retry logic",
      "Create refund processing",
      "Set up split payments",
      "Build late fee system"
    ],

    phase3_automation: [
      "Schedule payment processor cron job",
      "Implement reminder system",
      "Add webhook handlers",
      "Create financial reports",
      "Build admin dashboards"
    ],

    phase4_optimization: [
      "Add payment analytics",
      "Implement fraud detection",
      "Optimize retry strategies",
      "Add custom invoice templates",
      "Create student payment portal"
    ]
  }
};

// Export for documentation and reference
export default PAYMENT_SYSTEM_DESIGN;