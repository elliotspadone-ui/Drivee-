import React, { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Volume1,
  Maximize,
  Minimize,
  SkipBack,
  SkipForward,
  Settings,
  X,
  Check,
  Gauge,
  Subtitles,
  PictureInPicture2,
  Repeat,
  Download,
  Share2,
  ChevronRight
} from "lucide-react";

/**
 * VideoPlayer - Full-featured video player with animations and controls
 * 
 * @param {string} src - Video source URL
 * @param {string} poster - Poster image URL
 * @param {string} title - Video title
 * @param {Function} onProgress - Callback for progress updates
 * @param {Function} onEnded - Callback when video ends
 * @param {boolean} autoPlay - Auto-play video
 * @param {boolean} loop - Loop video
 */
export default function VideoPlayer({
  src,
  poster,
  title,
  onProgress,
  onEnded,
  autoPlay = false,
  loop = false,
  className = ""
}) {
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const progressRef = useRef(null);
  const hideControlsTimeout = useRef(null);

  // State
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isBuffering, setIsBuffering] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [seekPreview, setSeekPreview] = useState(null);
  const [hasStarted, setHasStarted] = useState(false);

  // Speed options
  const speedOptions = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

  // Format time
  const formatTime = (seconds) => {
    if (isNaN(seconds)) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // Play/Pause toggle
  const togglePlay = useCallback(() => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.play();
      setHasStarted(true);
    }
  }, [isPlaying]);

  // Mute toggle
  const toggleMute = useCallback(() => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  }, [isMuted]);

  // Volume change
  const handleVolumeChange = useCallback((e) => {
    const newVolume = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
      setVolume(newVolume);
      setIsMuted(newVolume === 0);
    }
  }, []);

  // Speed change
  const handleSpeedChange = useCallback((speed) => {
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
      setPlaybackSpeed(speed);
      setShowSpeedMenu(false);
      setShowSettingsMenu(false);
    }
  }, []);

  // Seek
  const handleSeek = useCallback((e) => {
    if (!videoRef.current || !progressRef.current) return;
    
    const rect = progressRef.current.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    const newTime = pos * duration;
    
    videoRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  }, [duration]);

  // Seek preview
  const handleSeekPreview = useCallback((e) => {
    if (!progressRef.current) return;
    
    const rect = progressRef.current.getBoundingClientRect();
    const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const previewTime = pos * duration;
    
    setSeekPreview({
      time: previewTime,
      position: pos * 100
    });
  }, [duration]);

  // Skip forward/backward
  const skip = useCallback((seconds) => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = Math.max(0, Math.min(duration, currentTime + seconds));
  }, [currentTime, duration]);

  // Fullscreen toggle
  const toggleFullscreen = useCallback(async () => {
    if (!containerRef.current) return;

    try {
      if (!document.fullscreenElement) {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch (err) {
      console.error("Fullscreen error:", err);
    }
  }, []);

  // Picture-in-Picture
  const togglePiP = useCallback(async () => {
    if (!videoRef.current) return;

    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else {
        await videoRef.current.requestPictureInPicture();
      }
    } catch (err) {
      console.error("PiP error:", err);
    }
  }, []);

  // Hide controls after inactivity
  const resetHideControlsTimer = useCallback(() => {
    setShowControls(true);
    
    if (hideControlsTimeout.current) {
      clearTimeout(hideControlsTimeout.current);
    }
    
    if (isPlaying && !showSpeedMenu && !showSettingsMenu) {
      hideControlsTimeout.current = setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
  }, [isPlaying, showSpeedMenu, showSettingsMenu]);

  // Video event handlers
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime);
      onProgress?.({ played: video.currentTime / video.duration, playedSeconds: video.currentTime });
    };
    const handleLoadedMetadata = () => setDuration(video.duration);
    const handleWaiting = () => setIsBuffering(true);
    const handlePlaying = () => setIsBuffering(false);
    const handleEnded = () => {
      setIsPlaying(false);
      onEnded?.();
    };

    video.addEventListener("play", handlePlay);
    video.addEventListener("pause", handlePause);
    video.addEventListener("timeupdate", handleTimeUpdate);
    video.addEventListener("loadedmetadata", handleLoadedMetadata);
    video.addEventListener("waiting", handleWaiting);
    video.addEventListener("playing", handlePlaying);
    video.addEventListener("ended", handleEnded);

    return () => {
      video.removeEventListener("play", handlePlay);
      video.removeEventListener("pause", handlePause);
      video.removeEventListener("timeupdate", handleTimeUpdate);
      video.removeEventListener("loadedmetadata", handleLoadedMetadata);
      video.removeEventListener("waiting", handleWaiting);
      video.removeEventListener("playing", handlePlaying);
      video.removeEventListener("ended", handleEnded);
    };
  }, [onProgress, onEnded]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!isHovering) return;

      switch (e.key.toLowerCase()) {
        case " ":
        case "k":
          e.preventDefault();
          togglePlay();
          break;
        case "m":
          toggleMute();
          break;
        case "f":
          toggleFullscreen();
          break;
        case "arrowleft":
          skip(-10);
          break;
        case "arrowright":
          skip(10);
          break;
        case "arrowup":
          e.preventDefault();
          handleVolumeChange({ target: { value: Math.min(1, volume + 0.1) } });
          break;
        case "arrowdown":
          e.preventDefault();
          handleVolumeChange({ target: { value: Math.max(0, volume - 0.1) } });
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isHovering, togglePlay, toggleMute, toggleFullscreen, skip, handleVolumeChange, volume]);

  // Fullscreen change listener
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, []);

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <motion.div
      ref={containerRef}
      className={`relative bg-black rounded-2xl overflow-hidden group ${className}`}
      onMouseEnter={() => { setIsHovering(true); resetHideControlsTimer(); }}
      onMouseLeave={() => { setIsHovering(false); setSeekPreview(null); }}
      onMouseMove={resetHideControlsTimer}
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        src={src}
        poster={poster}
        className="w-full aspect-video object-contain"
        autoPlay={autoPlay}
        loop={loop}
        onClick={togglePlay}
        playsInline
      />

      {/* Buffering Indicator */}
      <AnimatePresence>
        {isBuffering && (
          <motion.div
            className="absolute inset-0 flex items-center justify-center bg-black/30"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="w-16 h-16 border-4 border-white/30 border-t-white rounded-full"
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Big Play Button (Initial) */}
      <AnimatePresence>
        {!hasStarted && !isPlaying && (
          <motion.button
            className="absolute inset-0 flex items-center justify-center bg-black/40"
            onClick={togglePlay}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="w-20 h-20 bg-white/90 rounded-full flex items-center justify-center shadow-2xl"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <Play className="w-8 h-8 text-gray-900 ml-1" fill="currentColor" />
            </motion.div>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Play/Pause Animation Overlay */}
      <AnimatePresence>
        {hasStarted && (
          <motion.div
            key={isPlaying ? "playing" : "paused"}
            className="absolute inset-0 flex items-center justify-center pointer-events-none"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: [0, 1, 0], scale: [0.5, 1, 1.2] }}
            transition={{ duration: 0.4 }}
          >
            <div className="w-16 h-16 bg-black/60 rounded-full flex items-center justify-center">
              {isPlaying ? (
                <Play className="w-7 h-7 text-white ml-1" fill="white" />
              ) : (
                <Pause className="w-7 h-7 text-white" fill="white" />
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Controls Overlay */}
      <AnimatePresence>
        {showControls && (
          <motion.div
            className="absolute inset-0 flex flex-col justify-end"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            {/* Gradient Background */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none" />

            {/* Title */}
            {title && (
              <motion.div
                className="absolute top-4 left-4 right-4"
                initial={{ y: -10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.1 }}
              >
                <h3 className="text-white font-semibold text-lg drop-shadow-lg">{title}</h3>
              </motion.div>
            )}

            {/* Bottom Controls */}
            <div className="relative z-10 p-4 space-y-3">
              {/* Progress Bar */}
              <div
                ref={progressRef}
                className="relative h-1.5 bg-white/30 rounded-full cursor-pointer group/progress"
                onClick={handleSeek}
                onMouseMove={handleSeekPreview}
                onMouseLeave={() => setSeekPreview(null)}
              >
                {/* Buffered */}
                <div className="absolute inset-y-0 left-0 bg-white/40 rounded-full" style={{ width: "60%" }} />
                
                {/* Progress */}
                <motion.div
                  className="absolute inset-y-0 left-0 bg-[#3b82c4] rounded-full"
                  style={{ width: `${progress}%` }}
                  layoutId="progress"
                />
                
                {/* Seek Handle */}
                <motion.div
                  className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg opacity-0 group-hover/progress:opacity-100 transition-opacity"
                  style={{ left: `calc(${progress}% - 8px)` }}
                  whileHover={{ scale: 1.2 }}
                />

                {/* Seek Preview */}
                <AnimatePresence>
                  {seekPreview && (
                    <motion.div
                      className="absolute -top-10 px-2 py-1 bg-black/90 rounded text-white text-xs font-medium"
                      style={{ left: `${seekPreview.position}%`, transform: "translateX(-50%)" }}
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                    >
                      {formatTime(seekPreview.time)}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Control Buttons */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {/* Play/Pause */}
                  <motion.button
                    onClick={togglePlay}
                    className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {isPlaying ? (
                      <Pause className="w-6 h-6" fill="white" />
                    ) : (
                      <Play className="w-6 h-6 ml-0.5" fill="white" />
                    )}
                  </motion.button>

                  {/* Skip Buttons */}
                  <motion.button
                    onClick={() => skip(-10)}
                    className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <SkipBack className="w-5 h-5" />
                  </motion.button>
                  <motion.button
                    onClick={() => skip(10)}
                    className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <SkipForward className="w-5 h-5" />
                  </motion.button>

                  {/* Volume */}
                  <div className="flex items-center gap-1 group/volume">
                    <motion.button
                      onClick={toggleMute}
                      className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      {isMuted || volume === 0 ? (
                        <VolumeX className="w-5 h-5" />
                      ) : volume < 0.5 ? (
                        <Volume1 className="w-5 h-5" />
                      ) : (
                        <Volume2 className="w-5 h-5" />
                      )}
                    </motion.button>
                    <motion.div
                      className="w-0 overflow-hidden group-hover/volume:w-20 transition-all duration-200"
                    >
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={isMuted ? 0 : volume}
                        onChange={handleVolumeChange}
                        className="w-full h-1 bg-white/30 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:rounded-full"
                      />
                    </motion.div>
                  </div>

                  {/* Time Display */}
                  <span className="text-white text-sm font-medium ml-2">
                    {formatTime(currentTime)} / {formatTime(duration)}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  {/* Speed Control */}
                  <div className="relative">
                    <motion.button
                      onClick={() => { setShowSpeedMenu(!showSpeedMenu); setShowSettingsMenu(false); }}
                      className="px-2 py-1 text-white hover:bg-white/20 rounded-lg transition-colors text-sm font-medium flex items-center gap-1"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Gauge className="w-4 h-4" />
                      {playbackSpeed}x
                    </motion.button>

                    <AnimatePresence>
                      {showSpeedMenu && (
                        <motion.div
                          className="absolute bottom-full right-0 mb-2 bg-gray-900/95 backdrop-blur-sm rounded-xl shadow-2xl border border-white/10 overflow-hidden min-w-[140px]"
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          transition={{ duration: 0.15 }}
                        >
                          <div className="p-2">
                            <p className="text-xs text-white/60 font-semibold px-3 py-2">Playback Speed</p>
                            {speedOptions.map((speed) => (
                              <motion.button
                                key={speed}
                                onClick={() => handleSpeedChange(speed)}
                                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors ${
                                  playbackSpeed === speed
                                    ? "bg-[#3b82c4] text-white"
                                    : "text-white hover:bg-white/10"
                                }`}
                                whileHover={{ x: 2 }}
                              >
                                <span>{speed === 1 ? "Normal" : `${speed}x`}</span>
                                {playbackSpeed === speed && <Check className="w-4 h-4" />}
                              </motion.button>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Settings */}
                  <div className="relative">
                    <motion.button
                      onClick={() => { setShowSettingsMenu(!showSettingsMenu); setShowSpeedMenu(false); }}
                      className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Settings className="w-5 h-5" />
                    </motion.button>

                    <AnimatePresence>
                      {showSettingsMenu && (
                        <motion.div
                          className="absolute bottom-full right-0 mb-2 bg-gray-900/95 backdrop-blur-sm rounded-xl shadow-2xl border border-white/10 overflow-hidden min-w-[180px]"
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          transition={{ duration: 0.15 }}
                        >
                          <div className="p-2 space-y-1">
                            <button
                              onClick={() => { setShowSpeedMenu(true); setShowSettingsMenu(false); }}
                              className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-white text-sm hover:bg-white/10 transition-colors"
                            >
                              <span className="flex items-center gap-2">
                                <Gauge className="w-4 h-4" />
                                Speed
                              </span>
                              <span className="text-white/60">{playbackSpeed}x</span>
                            </button>
                            <button
                              onClick={togglePiP}
                              className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-white text-sm hover:bg-white/10 transition-colors"
                            >
                              <PictureInPicture2 className="w-4 h-4" />
                              Picture-in-Picture
                            </button>
                            <button
                              className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-white text-sm hover:bg-white/10 transition-colors"
                            >
                              <Subtitles className="w-4 h-4" />
                              Subtitles
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* PiP */}
                  <motion.button
                    onClick={togglePiP}
                    className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors hidden md:block"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <PictureInPicture2 className="w-5 h-5" />
                  </motion.button>

                  {/* Fullscreen */}
                  <motion.button
                    onClick={toggleFullscreen}
                    className="p-2 text-white hover:bg-white/20 rounded-lg transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {isFullscreen ? (
                      <Minimize className="w-5 h-5" />
                    ) : (
                      <Maximize className="w-5 h-5" />
                    )}
                  </motion.button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}