import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { logger, ENABLE_DEV_AUTH } from "@/components/utils/config";

function normalizeEmail(email) {
  return email?.trim().toLowerCase() || "";
}

async function resolveInstructorForUser(user) {
  if (!user) return null;

  // Priority 1: Use instructor_id from user metadata if available
  if (user.instructor_id) {
    try {
      const instructors = await base44.entities.Instructor.filter({ id: user.instructor_id });
      if (instructors && instructors.length > 0) {
        return instructors[0];
      }
    } catch (err) {
      logger.warn("Failed to fetch instructor by instructor_id:", err);
    }
  }

  // Priority 2: Lookup by email (normalized)
  const normalizedEmail = normalizeEmail(user.email);
  if (!normalizedEmail) return null;

  try {
    const instructors = await base44.entities.Instructor.filter({ email: normalizedEmail });
    if (!instructors || instructors.length === 0) return null;

    if (instructors.length > 1) {
      logger.warn(`Multiple instructors found for email ${normalizedEmail}, using most recent`);
      instructors.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    }

    return instructors[0];
  } catch (err) {
    logger.error("Failed to fetch instructor by email:", err);
    return null;
  }
}

export function useInstructorAuth() {
  return useQuery({
    queryKey: ["instructorAuth"],
    queryFn: async () => {
      try {
        // DEV-only: Check for dev auth bypass
        if (ENABLE_DEV_AUTH) {
          const devUser = sessionStorage.getItem("dev_auth_user");
          if (devUser) {
            try {
              const parsedUser = JSON.parse(devUser);
              logger.auth("Using dev auth user:", parsedUser.email);
              const instructor = await resolveInstructorForUser(parsedUser);
              return {
                effectiveUser: parsedUser,
                effectiveInstructor: instructor,
                status: instructor ? "authenticated" : "no_instructor",
              };
            } catch (err) {
              logger.warn("Dev auth failed:", err);
            }
          }
        }

        // Production authentication
        const user = await base44.auth.me();
        if (!user) {
          return {
            effectiveUser: null,
            effectiveInstructor: null,
            status: "unauthenticated",
          };
        }

        const instructor = await resolveInstructorForUser(user);

        if (!instructor) {
          return {
            effectiveUser: user,
            effectiveInstructor: null,
            status: "no_instructor",
          };
        }

        return {
          effectiveUser: user,
          effectiveInstructor: instructor,
          status: "authenticated",
        };
      } catch (err) {
        logger.error("Instructor authentication failed:", err);
        return {
          effectiveUser: null,
          effectiveInstructor: null,
          status: "unauthenticated",
        };
      }
    },
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });
}