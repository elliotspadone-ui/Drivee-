import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  X, Save, Star, CheckCircle, AlertTriangle, 
  TrendingUp, Target, Award, MessageSquare,
  Loader2, Sparkles, ThumbsUp, ThumbsDown
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { format } from "date-fns";

export default function EnhancedLessonNotes({ 
  booking, 
  student, 
  onClose, 
  onSave 
}) {
  const [notes, setNotes] = useState(booking.instructor_notes || "");
  const [performance, setPerformance] = useState({
    parking: booking.student_performance?.parking || 3,
    highway_driving: booking.student_performance?.highway_driving || 3,
    city_driving: booking.student_performance?.city_driving || 3,
    traffic_rules: booking.student_performance?.traffic_rules || 3,
    overall: booking.student_performance?.overall || 3
  });
  const [skillsPracticed, setSkillsPracticed] = useState([]);
  const [areasToImprove, setAreasToImprove] = useState([]);
  const [testReady, setTestReady] = useState(student?.exam_eligible || false);
  const [saving, setSaving] = useState(false);

  const performanceAreas = [
    { key: "parking", label: "Parking", icon: Target },
    { key: "highway_driving", label: "Highway", icon: TrendingUp },
    { key: "city_driving", label: "City Driving", icon: AlertTriangle },
    { key: "traffic_rules", label: "Traffic Rules", icon: CheckCircle },
    { key: "overall", label: "Overall", icon: Star }
  ];

  const suggestedSkills = [
    "Parallel Parking", "Highway Merging", "Roundabouts", 
    "Lane Changes", "Night Driving", "Reverse Parking",
    "City Navigation", "Emergency Stops", "Hill Starts"
  ];

  const suggestedImprovements = [
    "Wider turns", "Mirror checks", "Speed control", 
    "Shoulder checks", "Smooth braking", "Signal timing",
    "Spatial awareness", "Confidence", "Decision making"
  ];

  const handleSave = async () => {
    setSaving(true);
    try {
      // Update booking
      await base44.entities.Booking.update(booking.id, {
        instructor_notes: notes,
        student_performance: performance,
        attendance_marked: true
      });

      // Update student progress
      const lessonHours = (new Date(booking.end_datetime) - new Date(booking.start_datetime)) / (1000 * 60 * 60);
      await base44.entities.Student.update(student.id, {
        total_hours_completed: (student.total_hours_completed || 0) + lessonHours,
        total_lessons_completed: (student.total_lessons_completed || 0) + 1,
        progress_percentage: Math.min(
          ((student.total_hours_completed || 0) + lessonHours) / (student.required_hours || 20) * 100,
          100
        ),
        exam_eligible: testReady
      });

      toast.success("Lesson notes saved successfully");
      onSave?.();
      onClose();
    } catch (error) {
      toast.error("Failed to save notes");
      console.error(error);
    } finally {
      setSaving(false);
    }
  };

  const averageScore = Object.values(performance).reduce((a, b) => a + b, 0) / Object.values(performance).length;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <motion.div
        initial={{ y: "100%", opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: "100%", opacity: 0 }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        className="bg-white rounded-t-[32px] sm:rounded-[32px] max-w-2xl w-full max-h-[95vh] sm:max-h-[90vh] overflow-hidden flex flex-col shadow-2xl"
      >
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-[#3b82c4] to-[#2563a3] text-white p-6 flex items-center justify-between z-10">
          <div>
            <h2 className="text-xl font-bold">Lesson Completion</h2>
            <p className="text-white/80 text-sm">{student?.full_name} • {format(new Date(booking.start_datetime), "MMM d, h:mm a")}</p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-xl transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Performance Ratings */}
          <div>
            <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Star className="w-5 h-5 text-[#e7d356]" />
              Student Performance
            </h3>
            <div className="space-y-4">
              {performanceAreas.map(area => (
                <div key={area.key}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <area.icon className="w-4 h-4 text-slate-400" />
                      <span className="text-sm font-semibold text-slate-700">{area.label}</span>
                    </div>
                    <span className={`text-sm font-bold ${
                      performance[area.key] >= 4 ? "text-[#5cb83a]" :
                      performance[area.key] >= 3 ? "text-[#3b82c4]" :
                      "text-[#e7d356]"
                    }`}>
                      {performance[area.key]}/5
                    </span>
                  </div>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map(rating => (
                      <button
                        key={rating}
                        onClick={() => setPerformance(prev => ({ ...prev, [area.key]: rating }))}
                        className={`flex-1 h-10 rounded-lg transition-all ${
                          performance[area.key] >= rating
                            ? rating >= 4 ? "bg-[#81da5a] text-white" :
                              rating >= 3 ? "bg-[#3b82c4] text-white" :
                              "bg-[#e7d356] text-white"
                            : "bg-slate-100 hover:bg-slate-200"
                        }`}
                      >
                        <span className="text-xs font-bold">{rating}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Average Score */}
            <div className="mt-4 p-4 bg-gradient-to-r from-[#e8f4fa] to-[#d4eaf5] rounded-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#3b82c4]" />
                  <span className="font-bold text-slate-900">Overall Performance</span>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-[#3b82c4]">{averageScore.toFixed(1)}/5</p>
                  <p className="text-xs text-slate-600">
                    {averageScore >= 4 ? "Excellent! 🎉" : 
                     averageScore >= 3 ? "Good Progress" : 
                     "Needs Practice"}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Skills Practiced */}
          <div>
            <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-[#5cb83a]" />
              Skills Practiced Today
            </h3>
            <div className="flex flex-wrap gap-2">
              {suggestedSkills.map(skill => {
                const selected = skillsPracticed.includes(skill);
                return (
                  <button
                    key={skill}
                    onClick={() => setSkillsPracticed(prev => 
                      selected ? prev.filter(s => s !== skill) : [...prev, skill]
                    )}
                    className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                      selected
                        ? "bg-[#81da5a] text-white shadow-sm"
                        : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    {skill}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Areas to Improve */}
          <div>
            <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
              <Target className="w-5 h-5 text-[#e7d356]" />
              Areas to Improve
            </h3>
            <div className="flex flex-wrap gap-2">
              {suggestedImprovements.map(area => {
                const selected = areasToImprove.includes(area);
                return (
                  <button
                    key={area}
                    onClick={() => setAreasToImprove(prev => 
                      selected ? prev.filter(a => a !== area) : [...prev, area]
                    )}
                    className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                      selected
                        ? "bg-[#e7d356] text-[#5c4d0a] shadow-sm"
                        : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    {area}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Notes */}
          <div>
            <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-[#6c376f]" />
              Additional Notes
            </h3>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Detailed observations, recommendations, student questions, next lesson focus..."
              className="w-full h-32 px-4 py-3 rounded-xl border-2 border-slate-200 focus:outline-none focus:border-[#3b82c4] focus:ring-4 focus:ring-[#e8f4fa] resize-none transition"
            />
            <p className="text-xs text-slate-500 mt-2">
              💡 Tip: These notes will be visible to the student and help track their progress
            </p>
          </div>

          {/* Test Ready */}
          <motion.div
            whileHover={{ scale: 1.01 }}
            className={`p-4 rounded-xl border-2 cursor-pointer transition ${
              testReady 
                ? "bg-gradient-to-r from-[#eefbe7] to-[#d4f4c3] border-[#81da5a]" 
                : "bg-slate-50 border-slate-200 hover:border-slate-300"
            }`}
            onClick={() => setTestReady(!testReady)}
          >
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={testReady}
                onChange={(e) => setTestReady(e.target.checked)}
                className="w-5 h-5 text-[#5cb83a] rounded focus:ring-[#81da5a]"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <Award className={`w-5 h-5 ${testReady ? "text-[#5cb83a]" : "text-slate-400"}`} />
                  <p className="font-bold text-slate-900">Student is Test Ready</p>
                </div>
                <p className="text-sm text-slate-600">Mark if student has mastered all required skills and is ready for the driving test</p>
              </div>
            </label>
          </motion.div>
        </div>

        {/* Footer Actions */}
        <div className="sticky bottom-0 bg-slate-50 border-t-2 border-slate-200 p-6 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-6 py-4 rounded-xl border-2 border-slate-300 font-bold text-slate-700 hover:bg-slate-100 transition"
          >
            Cancel
          </button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleSave}
            disabled={saving}
            className="flex-1 px-6 py-4 rounded-xl bg-gradient-to-r from-[#3b82c4] to-[#2563a3] hover:from-[#2563a3] hover:to-[#1e4f8a] text-white font-bold transition disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg"
          >
            {saving ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-5 h-5" />
                Save & Complete
              </>
            )}
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}