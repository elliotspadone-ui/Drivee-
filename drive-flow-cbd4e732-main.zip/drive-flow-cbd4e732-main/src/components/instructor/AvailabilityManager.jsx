import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Calendar, Clock, Plus, Trash2, Save, X, 
  Loader2, CheckCircle, AlertCircle, Copy,
  CalendarDays, Coffee, Sunrise, Sunset
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { format, addDays, startOfWeek } from "date-fns";

const DAYS_OF_WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

const TIME_SLOTS = [
  { label: "Early Morning", icon: Sunrise, range: "6:00 AM - 9:00 AM", start: "06:00", end: "09:00" },
  { label: "Morning", icon: Clock, range: "9:00 AM - 12:00 PM", start: "09:00", end: "12:00" },
  { label: "Afternoon", icon: Coffee, range: "12:00 PM - 3:00 PM", start: "12:00", end: "15:00" },
  { label: "Late Afternoon", icon: Clock, range: "3:00 PM - 6:00 PM", start: "15:00", end: "18:00" },
  { label: "Evening", icon: Sunset, range: "6:00 PM - 9:00 PM", start: "18:00", end: "21:00" }
];

export default function AvailabilityManager({ instructor, onUpdate }) {
  const [availability, setAvailability] = useState({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (instructor?.availability) {
      setAvailability(instructor.availability);
    } else {
      // Default availability (Monday-Friday, 9 AM - 6 PM)
      const defaultAvailability = {};
      DAYS_OF_WEEK.slice(0, 5).forEach(day => {
        defaultAvailability[day] = [
          { start: "09:00", end: "18:00" }
        ];
      });
      setAvailability(defaultAvailability);
    }
  }, [instructor]);

  const toggleTimeSlot = (day, slot) => {
    setAvailability(prev => {
      const daySlots = prev[day] || [];
      const hasSlot = daySlots.some(s => s.start === slot.start && s.end === slot.end);
      
      if (hasSlot) {
        return {
          ...prev,
          [day]: daySlots.filter(s => !(s.start === slot.start && s.end === slot.end))
        };
      } else {
        return {
          ...prev,
          [day]: [...daySlots, { start: slot.start, end: slot.end }].sort((a, b) => 
            a.start.localeCompare(b.start)
          )
        };
      }
    });
  };

  const isSlotSelected = (day, slot) => {
    const daySlots = availability[day] || [];
    return daySlots.some(s => s.start === slot.start && s.end === slot.end);
  };

  const copyToAllDays = (sourceDay) => {
    const sourceSlots = availability[sourceDay] || [];
    const newAvailability = {};
    DAYS_OF_WEEK.forEach(day => {
      newAvailability[day] = [...sourceSlots];
    });
    setAvailability(newAvailability);
    toast.success(`Copied ${sourceDay} schedule to all days`);
  };

  const clearDay = (day) => {
    setAvailability(prev => ({
      ...prev,
      [day]: []
    }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await base44.entities.Instructor.update(instructor.id, {
        availability
      });
      toast.success("Availability updated successfully");
      if (onUpdate) onUpdate();
    } catch (error) {
      toast.error("Failed to update availability");
    } finally {
      setSaving(false);
    }
  };

  const getTotalHours = () => {
    let total = 0;
    Object.values(availability).forEach(daySlots => {
      daySlots.forEach(slot => {
        const [startHour, startMin] = slot.start.split(":").map(Number);
        const [endHour, endMin] = slot.end.split(":").map(Number);
        const hours = (endHour * 60 + endMin - startHour * 60 - startMin) / 60;
        total += hours;
      });
    });
    return total;
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#e8f4fa] to-[#d4eaf5] p-5 border-b border-slate-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center">
              <CalendarDays className="w-5 h-5 text-[#3b82c4]" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">Manage Availability</h3>
              <p className="text-sm text-slate-600">Set your weekly working hours</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-[#3b82c4]">{getTotalHours().toFixed(1)}</p>
            <p className="text-xs text-slate-600">hrs/week</p>
          </div>
        </div>
      </div>

      {/* Days Grid */}
      <div className="p-5 space-y-6">
        {DAYS_OF_WEEK.map((day, dayIdx) => {
          const hasSlots = (availability[day] || []).length > 0;
          
          return (
            <motion.div
              key={day}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: dayIdx * 0.05 }}
              className="border-2 border-slate-100 rounded-xl p-4 hover:border-slate-200 transition"
            >
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-bold text-slate-900">{day}</h4>
                  <p className="text-xs text-slate-500">
                    {hasSlots ? `${(availability[day] || []).length} time slot${(availability[day] || []).length > 1 ? 's' : ''}` : "Unavailable"}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => copyToAllDays(day)}
                    className="p-2 hover:bg-slate-100 rounded-lg transition"
                    title="Copy to all days"
                  >
                    <Copy className="w-4 h-4 text-slate-500" />
                  </button>
                  {hasSlots && (
                    <button
                      onClick={() => clearDay(day)}
                      className="p-2 hover:bg-red-50 rounded-lg transition"
                      title="Clear day"
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
                {TIME_SLOTS.map((slot, slotIdx) => {
                  const selected = isSlotSelected(day, slot);
                  return (
                    <motion.button
                      key={slotIdx}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => toggleTimeSlot(day, slot)}
                      className={`p-3 rounded-xl border-2 transition-all text-left ${
                        selected
                          ? "bg-[#3b82c4] border-[#3b82c4] text-white shadow-md"
                          : "bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-100"
                      }`}
                    >
                      <slot.icon className={`w-4 h-4 mb-1 ${selected ? "text-white" : "text-slate-400"}`} />
                      <p className="text-xs font-bold">{slot.label}</p>
                      <p className="text-[10px] opacity-80">{slot.range}</p>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="p-5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-sm text-slate-600">
          <AlertCircle className="w-4 h-4" />
          <span>Changes take effect immediately</span>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleSave}
          disabled={saving}
          className="px-6 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-bold transition disabled:opacity-50 flex items-center gap-2 shadow-md"
        >
          {saving ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              Save Availability
            </>
          )}
        </motion.button>
      </div>
    </div>
  );
}