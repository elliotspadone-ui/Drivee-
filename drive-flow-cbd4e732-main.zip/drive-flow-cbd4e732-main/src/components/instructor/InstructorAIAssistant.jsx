import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import {
  Sparkles,
  X,
  Send,
  Loader2,
  Calendar,
  MessageSquare,
  User,
  ChevronDown,
  Copy,
  Check,
  Clock,
  TrendingUp,
  Lightbulb,
  RefreshCw,
  Wand2
} from "lucide-react";
import { toast } from "sonner";
import { format, getDay, getHours } from "date-fns";

const ASSISTANT_MODES = [
  {
    id: "availability",
    label: "Optimize Availability",
    icon: Calendar,
    description: "Get suggestions for ideal time slots",
    color: "indigo"
  },
  {
    id: "response",
    label: "Draft Response",
    icon: MessageSquare,
    description: "Create personalized replies to students",
    color: "purple"
  },
  {
    id: "bio",
    label: "Generate Bio",
    icon: User,
    description: "Create an engaging 'about me' description",
    color: "emerald"
  }
];

export default function InstructorAIAssistant({ 
  instructor, 
  bookings = [], 
  reviews = [],
  onUpdateBio 
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [copied, setCopied] = useState(false);
  const [userInput, setUserInput] = useState("");
  const resultRef = useRef(null);

  useEffect(() => {
    if (result && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }, [result]);

  const analyzeBookingPatterns = () => {
    if (bookings.length === 0) {
      return {
        peakDays: ["Monday", "Wednesday", "Saturday"],
        peakHours: ["10:00", "14:00", "16:00"],
        lowDemandTimes: ["Tuesday afternoon", "Friday evening"],
        avgBookingsPerWeek: 0,
        completionRate: 0
      };
    }

    const dayCount = {};
    const hourCount = {};
    const completedBookings = bookings.filter(b => b.status === "completed");

    bookings.forEach(b => {
      if (b.start_datetime) {
        const date = new Date(b.start_datetime);
        const day = format(date, "EEEE");
        const hour = getHours(date);
        
        dayCount[day] = (dayCount[day] || 0) + 1;
        hourCount[hour] = (hourCount[hour] || 0) + 1;
      }
    });

    const sortedDays = Object.entries(dayCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([day]) => day);

    const sortedHours = Object.entries(hourCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([hour]) => `${hour}:00`);

    return {
      peakDays: sortedDays.length > 0 ? sortedDays : ["Monday", "Wednesday", "Saturday"],
      peakHours: sortedHours.length > 0 ? sortedHours : ["10:00", "14:00", "16:00"],
      lowDemandTimes: ["Tuesday afternoon", "Friday evening"],
      avgBookingsPerWeek: Math.round(bookings.length / 12),
      completionRate: bookings.length > 0 ? Math.round((completedBookings.length / bookings.length) * 100) : 0
    };
  };

  const handleOptimizeAvailability = async () => {
    setIsLoading(true);
    setResult(null);

    try {
      const patterns = analyzeBookingPatterns();
      
      const prompt = `You are an AI assistant for a driving instructor named ${instructor?.full_name || "the instructor"}.

Based on their booking data:
- Peak demand days: ${patterns.peakDays.join(", ")}
- Peak demand hours: ${patterns.peakHours.join(", ")}
- Low demand times: ${patterns.lowDemandTimes.join(", ")}
- Average bookings per week: ${patterns.avgBookingsPerWeek}
- Completion rate: ${patterns.completionRate}%
- Years of experience: ${instructor?.years_experience || 5}

Generate practical availability optimization suggestions. Include:
1. Best time slots to open for maximum bookings
2. Times to consider closing or reducing
3. Tips for balancing workload
4. Seasonal considerations

Keep it concise and actionable. Format with bullet points.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            recommendations: {
              type: "array",
              items: { type: "string" }
            },
            suggestedSlots: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  day: { type: "string" },
                  time: { type: "string" },
                  reason: { type: "string" }
                }
              }
            },
            summary: { type: "string" }
          }
        }
      });

      setResult({
        type: "availability",
        data: response,
        patterns
      });
    } catch (error) {
      toast.error("Failed to generate suggestions. Please try again.");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDraftResponse = async () => {
    if (!userInput.trim()) {
      toast.error("Please enter the student's inquiry");
      return;
    }

    setIsLoading(true);
    setResult(null);

    try {
      const avgRating = reviews.length > 0 
        ? (reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviews.length).toFixed(1)
        : "N/A";

      const prompt = `You are helping driving instructor ${instructor?.full_name || "the instructor"} respond to a student inquiry.

Instructor details:
- Experience: ${instructor?.years_experience || 5} years
- Languages: ${instructor?.languages?.join(", ") || "English"}
- Teaching style: Patient and thorough
- Rating: ${avgRating} stars
- Certifications: ${instructor?.certifications?.join(", ") || "Category B"}

Student inquiry:
"${userInput}"

Draft a warm, professional response that:
1. Addresses their specific question
2. Highlights relevant experience or qualifications
3. Encourages booking a lesson
4. Maintains a friendly, approachable tone

Keep it concise (2-3 paragraphs max).`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            response: { type: "string" },
            tone: { type: "string" },
            suggestions: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setResult({
        type: "response",
        data: response,
        inquiry: userInput
      });
    } catch (error) {
      toast.error("Failed to draft response. Please try again.");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateBio = async () => {
    setIsLoading(true);
    setResult(null);

    try {
      const completedLessons = bookings.filter(b => b.status === "completed").length;
      const avgRating = reviews.length > 0 
        ? (reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviews.length).toFixed(1)
        : null;

      const prompt = `Generate an engaging, professional "About Me" bio for a driving instructor profile.

Instructor details:
- Name: ${instructor?.full_name || "Instructor"}
- Years of experience: ${instructor?.years_experience || 5}
- Certifications: ${instructor?.certifications?.join(", ") || "Category B"}
- Languages spoken: ${instructor?.languages?.join(", ") || "English"}
- Completed lessons: ${completedLessons}
- Average rating: ${avgRating || "New instructor"}
- Specializations: ${instructor?.specializations?.join(", ") || "Beginner friendly, nervous drivers"}
${userInput ? `- Additional info from instructor: ${userInput}` : ""}

Create 3 different bio options:
1. Professional and formal
2. Friendly and approachable  
3. Enthusiastic and motivating

Each bio should:
- Be 2-3 sentences
- Highlight key strengths
- Appeal to potential students
- Be unique and engaging`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            bios: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  style: { type: "string" },
                  text: { type: "string" }
                }
              }
            },
            tips: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setResult({
        type: "bio",
        data: response
      });
    } catch (error) {
      toast.error("Failed to generate bio. Please try again.");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success("Copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleUseBio = (bioText) => {
    if (onUpdateBio) {
      onUpdateBio(bioText);
      toast.success("Bio updated!");
      setIsOpen(false);
    } else {
      handleCopy(bioText);
    }
  };

  const handleSubmit = () => {
    switch (mode) {
      case "availability":
        handleOptimizeAvailability();
        break;
      case "response":
        handleDraftResponse();
        break;
      case "bio":
        handleGenerateBio();
        break;
    }
  };

  const resetState = () => {
    setMode(null);
    setResult(null);
    setUserInput("");
  };

  return (
    <>
      {/* Floating Button */}
      <motion.button
        onClick={() => setIsOpen(true)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transition-shadow"
      >
        <Sparkles className="w-5 h-5" />
        <span className="font-semibold">AI Assistant</span>
      </motion.button>

      {/* Modal */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
            onClick={() => setIsOpen(false)}
          >
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white w-full sm:max-w-xl sm:rounded-2xl rounded-t-2xl max-h-[85vh] overflow-hidden flex flex-col shadow-2xl"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-indigo-50 to-purple-50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">AI Profile Assistant</h3>
                    <p className="text-sm text-gray-600">Optimize your instructor profile</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-xl transition"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-4">
                {!mode ? (
                  /* Mode Selection */
                  <div className="space-y-3">
                    <p className="text-sm text-gray-600 mb-4">
                      Choose how I can help you today:
                    </p>
                    
                    {ASSISTANT_MODES.map((m) => (
                      <button
                        key={m.id}
                        onClick={() => setMode(m.id)}
                        className={`w-full p-4 rounded-xl border-2 text-left transition hover:border-${m.color}-400 hover:bg-${m.color}-50 border-gray-200`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-10 h-10 bg-${m.color}-100 rounded-xl flex items-center justify-center flex-shrink-0`}>
                            <m.icon className={`w-5 h-5 text-${m.color}-600`} />
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">{m.label}</p>
                            <p className="text-sm text-gray-600">{m.description}</p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  /* Active Mode */
                  <div className="space-y-4">
                    <button
                      onClick={resetState}
                      className="text-sm text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
                    >
                      ← Back to options
                    </button>

                    {/* Mode-specific inputs */}
                    {mode === "availability" && (
                      <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-200">
                        <div className="flex items-center gap-2 mb-2">
                          <Calendar className="w-5 h-5 text-indigo-600" />
                          <h4 className="font-semibold text-gray-900">Availability Optimization</h4>
                        </div>
                        <p className="text-sm text-gray-600">
                          I'll analyze your booking patterns and suggest optimal time slots to maximize your bookings.
                        </p>
                      </div>
                    )}

                    {mode === "response" && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Paste the student's inquiry:
                        </label>
                        <textarea
                          value={userInput}
                          onChange={(e) => setUserInput(e.target.value)}
                          placeholder="e.g., Hi, I'm a nervous beginner looking for a patient instructor. Do you have any availability on weekends?"
                          rows={4}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                        />
                      </div>
                    )}

                    {mode === "bio" && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Any specific details to include? (optional)
                        </label>
                        <textarea
                          value={userInput}
                          onChange={(e) => setUserInput(e.target.value)}
                          placeholder="e.g., I specialize in helping nervous drivers, I use a dual-control modern car, I'm known for being very patient..."
                          rows={3}
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
                        />
                      </div>
                    )}

                    {/* Generate Button */}
                    {!result && (
                      <button
                        onClick={handleSubmit}
                        disabled={isLoading || (mode === "response" && !userInput.trim())}
                        className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl font-semibold transition flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        {isLoading ? (
                          <>
                            <Loader2 className="w-5 h-5 animate-spin" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Wand2 className="w-5 h-5" />
                            Generate Suggestions
                          </>
                        )}
                      </button>
                    )}

                    {/* Results */}
                    {result && (
                      <motion.div
                        ref={resultRef}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                      >
                        {result.type === "availability" && (
                          <>
                            <div className="p-4 bg-green-50 border border-green-200 rounded-xl">
                              <h4 className="font-semibold text-green-900 mb-2 flex items-center gap-2">
                                <TrendingUp className="w-5 h-5" />
                                Your Booking Patterns
                              </h4>
                              <div className="grid grid-cols-2 gap-3 text-sm">
                                <div>
                                  <p className="text-green-700">Peak Days</p>
                                  <p className="font-semibold text-green-900">
                                    {result.patterns.peakDays.join(", ")}
                                  </p>
                                </div>
                                <div>
                                  <p className="text-green-700">Peak Hours</p>
                                  <p className="font-semibold text-green-900">
                                    {result.patterns.peakHours.join(", ")}
                                  </p>
                                </div>
                              </div>
                            </div>

                            <div className="p-4 bg-white border border-gray-200 rounded-xl">
                              <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                                <Lightbulb className="w-5 h-5 text-amber-500" />
                                Recommendations
                              </h4>
                              <ul className="space-y-2">
                                {result.data.recommendations?.map((rec, idx) => (
                                  <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                                    <span className="w-5 h-5 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold">
                                      {idx + 1}
                                    </span>
                                    {rec}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {result.data.suggestedSlots?.length > 0 && (
                              <div className="p-4 bg-white border border-gray-200 rounded-xl">
                                <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                                  <Clock className="w-5 h-5 text-indigo-600" />
                                  Suggested Time Slots
                                </h4>
                                <div className="space-y-2">
                                  {result.data.suggestedSlots.map((slot, idx) => (
                                    <div key={idx} className="p-3 bg-indigo-50 rounded-lg">
                                      <p className="font-medium text-indigo-900">
                                        {slot.day} at {slot.time}
                                      </p>
                                      <p className="text-sm text-indigo-700">{slot.reason}</p>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </>
                        )}

                        {result.type === "response" && (
                          <div className="p-4 bg-white border border-gray-200 rounded-xl">
                            <div className="flex items-center justify-between mb-3">
                              <h4 className="font-semibold text-gray-900 flex items-center gap-2">
                                <MessageSquare className="w-5 h-5 text-purple-600" />
                                Draft Response
                              </h4>
                              <button
                                onClick={() => handleCopy(result.data.response)}
                                className="p-2 hover:bg-gray-100 rounded-lg transition flex items-center gap-1 text-sm text-gray-600"
                              >
                                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                Copy
                              </button>
                            </div>
                            <div className="p-4 bg-gray-50 rounded-lg">
                              <p className="text-gray-800 whitespace-pre-wrap">{result.data.response}</p>
                            </div>
                            {result.data.suggestions?.length > 0 && (
                              <div className="mt-3 pt-3 border-t border-gray-200">
                                <p className="text-xs font-medium text-gray-500 mb-2">Tips for improvement:</p>
                                <ul className="space-y-1">
                                  {result.data.suggestions.map((tip, idx) => (
                                    <li key={idx} className="text-xs text-gray-600 flex items-start gap-1">
                                      <span className="text-amber-500">•</span> {tip}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        )}

                        {result.type === "bio" && (
                          <div className="space-y-3">
                            {result.data.bios?.map((bio, idx) => (
                              <div key={idx} className="p-4 bg-white border border-gray-200 rounded-xl">
                                <div className="flex items-center justify-between mb-2">
                                  <span className="px-2 py-1 bg-indigo-100 text-indigo-700 text-xs font-semibold rounded-full">
                                    {bio.style}
                                  </span>
                                  <div className="flex gap-1">
                                    <button
                                      onClick={() => handleCopy(bio.text)}
                                      className="p-1.5 hover:bg-gray-100 rounded-lg transition"
                                      title="Copy"
                                    >
                                      <Copy className="w-4 h-4 text-gray-500" />
                                    </button>
                                    <button
                                      onClick={() => handleUseBio(bio.text)}
                                      className="px-3 py-1 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-700 transition"
                                    >
                                      Use This
                                    </button>
                                  </div>
                                </div>
                                <p className="text-gray-800">{bio.text}</p>
                              </div>
                            ))}

                            {result.data.tips?.length > 0 && (
                              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
                                <h4 className="font-semibold text-amber-900 mb-2 flex items-center gap-2">
                                  <Lightbulb className="w-5 h-5" />
                                  Pro Tips
                                </h4>
                                <ul className="space-y-1">
                                  {result.data.tips.map((tip, idx) => (
                                    <li key={idx} className="text-sm text-amber-800 flex items-start gap-2">
                                      <span>•</span> {tip}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Regenerate Button */}
                        <button
                          onClick={handleSubmit}
                          disabled={isLoading}
                          className="w-full py-2 border-2 border-gray-200 hover:border-gray-300 text-gray-700 rounded-xl font-medium transition flex items-center justify-center gap-2"
                        >
                          <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
                          Regenerate
                        </button>
                      </motion.div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}