import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  CheckCircle, XCircle, Clock, MapPin, Phone, Navigation,
  MessageSquare, FileText, Star, AlertTriangle, PlayCircle,
  PauseCircle, Loader2, ChevronDown, ChevronUp, Users
} from "lucide-react";
import { format, differenceInMinutes } from "date-fns";
import { toast } from "sonner";

export default function QuickLessonActions({ 
  booking, 
  student, 
  onStatusUpdate, 
  onAddNote,
  isExpanded = false 
}) {
  const [expanded, setExpanded] = useState(isExpanded);
  const [updating, setUpdating] = useState(false);

  const getStatusColor = (status) => {
    switch (status) {
      case "completed": return { bg: "bg-[#eefbe7]", border: "border-[#81da5a]", text: "text-[#5cb83a]" };
      case "in_progress": return { bg: "bg-[#e8f4fa]", border: "border-[#3b82c4]", text: "text-[#3b82c4]" };
      case "cancelled": return { bg: "bg-[#fdeeed]", border: "border-[#e44138]", text: "text-[#e44138]" };
      case "no_show": return { bg: "bg-[#fdfbe8]", border: "border-[#e7d356]", text: "text-[#b8a525]" };
      default: return { bg: "bg-slate-50", border: "border-slate-200", text: "text-slate-600" };
    }
  };

  const handleStatusChange = async (newStatus) => {
    setUpdating(true);
    try {
      await onStatusUpdate(booking.id, newStatus);
      toast.success(`Lesson marked as ${newStatus.replace("_", " ")}`);
    } catch (error) {
      toast.error("Failed to update status");
    } finally {
      setUpdating(false);
    }
  };

  const colors = getStatusColor(booking.status);
  const duration = differenceInMinutes(
    new Date(booking.end_datetime), 
    new Date(booking.start_datetime)
  );

  return (
    <motion.div
      layout
      className={`${colors.bg} border-2 ${colors.border} rounded-2xl overflow-hidden transition-all`}
    >
      {/* Collapsed View */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full p-4 flex items-center justify-between hover:opacity-80 transition"
      >
        <div className="flex items-center gap-4 flex-1 min-w-0">
          <div className="text-center flex-shrink-0">
            <p className="text-xl font-bold text-slate-900">
              {format(new Date(booking.start_datetime), "h:mm")}
            </p>
            <p className="text-xs text-slate-600">
              {format(new Date(booking.start_datetime), "a")}
            </p>
          </div>
          
          <div className="flex-1 min-w-0">
            <p className="font-bold text-slate-900 truncate">{student?.full_name || "Unknown Student"}</p>
            <p className="text-sm text-slate-600 truncate">{duration} min • {booking.lesson_type || "Standard"}</p>
          </div>

          <div className={`px-3 py-1 ${colors.bg} ${colors.text} rounded-full text-xs font-bold border ${colors.border} flex-shrink-0`}>
            {booking.status.replace("_", " ")}
          </div>
        </div>

        {expanded ? <ChevronUp className="w-5 h-5 text-slate-400 ml-2 flex-shrink-0" /> : <ChevronDown className="w-5 h-5 text-slate-400 ml-2 flex-shrink-0" />}
      </button>

      {/* Expanded View */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <div className="px-4 pb-4 space-y-4 border-t-2 border-white/50 pt-4">
              {/* Student Info */}
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-start gap-2">
                  <Users className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs text-slate-500">Student</p>
                    <p className="font-semibold text-slate-900 truncate">{student?.full_name}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Clock className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-slate-500">Duration</p>
                    <p className="font-semibold text-slate-900">{duration} minutes</p>
                  </div>
                </div>
              </div>

              {booking.pickup_location && (
                <div className="flex items-start gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-slate-400 mt-1 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-slate-500 mb-1">Pickup Location</p>
                    <p className="text-slate-700">{booking.pickup_location}</p>
                  </div>
                </div>
              )}

              {/* Quick Actions */}
              <div className="grid grid-cols-2 gap-2">
                {booking.pickup_location && (
                  <a
                    href={`https://maps.google.com/?q=${encodeURIComponent(booking.pickup_location)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-2 bg-white hover:bg-slate-50 border-2 border-slate-200 text-slate-700 rounded-xl text-sm font-semibold transition flex items-center justify-center gap-2"
                  >
                    <Navigation className="w-4 h-4" />
                    Navigate
                  </a>
                )}
                {student?.phone && (
                  <a
                    href={`tel:${student.phone}`}
                    className="px-3 py-2 bg-white hover:bg-slate-50 border-2 border-slate-200 text-slate-700 rounded-xl text-sm font-semibold transition flex items-center justify-center gap-2"
                  >
                    <Phone className="w-4 h-4" />
                    Call
                  </a>
                )}
              </div>

              {/* Status Update Actions */}
              <div>
                <p className="text-xs font-bold text-slate-600 uppercase mb-2">Update Status</p>
                <div className="grid grid-cols-2 gap-2">
                  {booking.status !== "completed" && (
                    <button
                      onClick={() => handleStatusChange("completed")}
                      disabled={updating}
                      className="px-4 py-3 bg-[#81da5a] hover:bg-[#5cb83a] text-white rounded-xl text-sm font-bold transition disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {updating ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                      Complete
                    </button>
                  )}
                  {booking.status !== "cancelled" && (
                    <button
                      onClick={() => handleStatusChange("cancelled")}
                      disabled={updating}
                      className="px-4 py-3 bg-[#e44138] hover:bg-[#c9342c] text-white rounded-xl text-sm font-bold transition disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {updating ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                      Cancel
                    </button>
                  )}
                  {booking.status !== "no_show" && (
                    <button
                      onClick={() => handleStatusChange("no_show")}
                      disabled={updating}
                      className="px-4 py-3 bg-[#e7d356] hover:bg-[#d4bf2e] text-[#5c4d0a] rounded-xl text-sm font-bold transition disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {updating ? <Loader2 className="w-4 h-4 animate-spin" /> : <AlertTriangle className="w-4 h-4" />}
                      No Show
                    </button>
                  )}
                  <button
                    onClick={() => onAddNote(booking)}
                    className="px-4 py-3 bg-slate-700 hover:bg-slate-800 text-white rounded-xl text-sm font-bold transition flex items-center justify-center gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    Add Notes
                  </button>
                </div>
              </div>

              {/* Existing Notes Preview */}
              {booking.instructor_notes && (
                <div className="bg-white rounded-xl p-3 border border-slate-200">
                  <p className="text-xs font-bold text-slate-500 uppercase mb-1">Previous Notes</p>
                  <p className="text-sm text-slate-700 line-clamp-2">{booking.instructor_notes}</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}