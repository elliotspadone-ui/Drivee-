import React, { useState } from "react";
import { motion } from "framer-motion";
import { X, Save } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function LessonNotesModal({ booking, student, onClose, onSave }) {
  const [notes, setNotes] = useState(booking.notes || "");
  const [rating, setRating] = useState(3);
  const [skillsPracticed, setSkillsPracticed] = useState([]);
  const [testReady, setTestReady] = useState(false);
  const [saving, setSaving] = useState(false);

  const skills = [
    "Parallel Parking",
    "Highway Driving",
    "Night Driving",
    "City Navigation",
    "Reverse Parking",
    "Lane Changes",
    "Roundabouts",
    "Emergency Stops"
  ];

  const toggleSkill = (skill) => {
    setSkillsPracticed(prev =>
      prev.includes(skill)
        ? prev.filter(s => s !== skill)
        : [...prev, skill]
    );
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Update booking with notes
      await base44.entities.Booking.update(booking.id, {
        ...booking,
        notes,
        lesson_rating: rating,
        skills_practiced: skillsPracticed,
      });

      // Update student progress
      if (student) {
        const duration = (new Date(booking.end_datetime) - new Date(booking.start_datetime)) / (1000 * 60 * 60);
        await base44.entities.Student.update(student.id, {
          total_hours_completed: (student.total_hours_completed || 0) + duration,
          lessons_completed: (student.lessons_completed || 0) + 1,
          exam_eligible: testReady,
        });
      }

      toast.success("Lesson notes saved successfully");
      onSave();
    } catch (error) {
      toast.error("Failed to save notes");
      console.error(error);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="sticky top-0 bg-white border-b p-6 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-gray-900">Add Lesson Notes</h2>
            <p className="text-sm text-gray-600">{student?.full_name}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Lesson Rating */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-3">
              How did the lesson go?
            </label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((value) => (
                <button
                  key={value}
                  onClick={() => setRating(value)}
                  className={`flex-1 py-3 rounded-lg font-medium transition ${
                    rating === value
                      ? "bg-indigo-600 text-white"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  {value === 1 && "Poor"}
                  {value === 2 && "Fair"}
                  {value === 3 && "Good"}
                  {value === 4 && "Great"}
                  {value === 5 && "Excellent"}
                </button>
              ))}
            </div>
          </div>

          {/* Skills Practiced */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-3">
              What did you practice?
            </label>
            <div className="grid grid-cols-2 gap-2">
              {skills.map((skill) => (
                <button
                  key={skill}
                  onClick={() => toggleSkill(skill)}
                  className={`px-4 py-3 rounded-lg text-sm font-medium text-left transition ${
                    skillsPracticed.includes(skill)
                      ? "bg-indigo-100 text-indigo-700 border-2 border-indigo-600"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  {skill}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-3">
              Lesson Notes
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="What went well? What needs improvement? Any observations..."
              className="w-full h-32 px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          {/* Test Ready */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl border-2 border-green-200">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={testReady}
                onChange={(e) => setTestReady(e.target.checked)}
                className="w-5 h-5 text-green-600 rounded"
              />
              <div>
                <p className="font-semibold text-gray-900">Mark student as test ready</p>
                <p className="text-sm text-gray-600">Student has mastered all required skills</p>
              </div>
            </label>
          </div>
        </div>

        <div className="sticky bottom-0 bg-gray-50 border-t p-6 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-6 py-3 rounded-lg border-2 border-gray-200 font-semibold text-gray-700 hover:bg-gray-100"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 px-6 py-3 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {saving ? (
              "Saving..."
            ) : (
              <>
                <Save className="w-5 h-5" />
                Save Notes
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
}