import React, { useState } from "react";
import { motion } from "framer-motion";
import { 
  X, Phone, Mail, MapPin, Calendar, DollarSign, 
  FileText, TrendingUp, Clock, CheckCircle 
} from "lucide-react";
import { format } from "date-fns";

export default function StudentDetailModal({ student, bookings, invoices, onClose }) {
  const [activeTab, setActiveTab] = useState("progress");

  const completedLessons = bookings.filter(b => b.status === "completed");
  const upcomingLessons = bookings.filter(b => 
    b.status === "confirmed" && new Date(b.start_datetime) > new Date()
  );

  const totalInvoiced = invoices.reduce((sum, inv) => sum + inv.total_amount, 0);
  const totalPaid = invoices.reduce((sum, inv) => sum + inv.amount_paid, 0);
  const outstanding = totalInvoiced - totalPaid;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col"
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b p-6">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center">
                <span className="text-white text-2xl font-bold">
                  {student.full_name?.charAt(0) || "S"}
                </span>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{student.full_name}</h2>
                <p className="text-sm text-gray-600">License: {student.license_category || "B"}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
              <X className="w-6 h-6 text-gray-600" />
            </button>
          </div>

          {/* Contact */}
          <div className="flex gap-3 mt-4">
            <a
              href={`tel:${student.phone}`}
              className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4" />
              Call
            </a>
            <a
              href={`mailto:${student.email}`}
              className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium flex items-center justify-center gap-2"
            >
              <Mail className="w-4 h-4" />
              Email
            </a>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b">
          <div className="flex gap-1 px-6">
            <button
              onClick={() => setActiveTab("progress")}
              className={`px-4 py-3 font-medium border-b-2 transition ${
                activeTab === "progress"
                  ? "border-indigo-600 text-indigo-600"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              Progress
            </button>
            <button
              onClick={() => setActiveTab("lessons")}
              className={`px-4 py-3 font-medium border-b-2 transition ${
                activeTab === "lessons"
                  ? "border-indigo-600 text-indigo-600"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              Lessons
            </button>
            <button
              onClick={() => setActiveTab("financial")}
              className={`px-4 py-3 font-medium border-b-2 transition ${
                activeTab === "financial"
                  ? "border-indigo-600 text-indigo-600"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              Financial
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === "progress" && (
            <div className="space-y-6">
              {/* Stats Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-gray-50 rounded-xl p-4">
                  <p className="text-sm text-gray-600 mb-1">Hours Completed</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {student.total_hours_completed || 0}
                  </p>
                  <p className="text-xs text-gray-500">of {student.total_hours_required || 40}</p>
                </div>
                <div className="bg-gray-50 rounded-xl p-4">
                  <p className="text-sm text-gray-600 mb-1">Lessons Done</p>
                  <p className="text-2xl font-bold text-gray-900">{completedLessons.length}</p>
                </div>
                <div className="bg-gray-50 rounded-xl p-4">
                  <p className="text-sm text-gray-600 mb-1">Progress</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {((student.total_hours_completed || 0) / (student.total_hours_required || 40) * 100).toFixed(0)}%
                  </p>
                </div>
                <div className="bg-gray-50 rounded-xl p-4">
                  <p className="text-sm text-gray-600 mb-1">Status</p>
                  <p className={`text-sm font-semibold ${
                    student.exam_eligible ? "text-green-600" : "text-yellow-600"
                  }`}>
                    {student.exam_eligible ? "Test Ready" : "In Training"}
                  </p>
                </div>
              </div>

              {/* Test Date */}
              {student.practical_exam_date && (
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-xl border-2 border-green-200">
                  <div className="flex items-center gap-3">
                    <Calendar className="w-6 h-6 text-green-600" />
                    <div>
                      <p className="font-semibold text-gray-900">Practical Test Scheduled</p>
                      <p className="text-lg font-bold text-green-600">
                        {format(new Date(student.practical_exam_date), "EEEE, MMMM d, yyyy")}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Skills */}
              {completedLessons.some(b => b.skills_practiced) && (
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">Skills Practiced</h3>
                  <div className="flex flex-wrap gap-2">
                    {[...new Set(completedLessons.flatMap(b => b.skills_practiced || []))].map(skill => (
                      <span
                        key={skill}
                        className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === "lessons" && (
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-900">Lesson History</h3>
              {completedLessons.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No lessons completed yet</p>
              ) : (
                completedLessons.map(booking => (
                  <div key={booking.id} className="bg-gray-50 rounded-xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-semibold text-gray-900">
                          {format(new Date(booking.start_datetime), "EEEE, MMM d, yyyy")}
                        </p>
                        <p className="text-sm text-gray-600">
                          {format(new Date(booking.start_datetime), "h:mm a")} - {format(new Date(booking.end_datetime), "h:mm a")}
                        </p>
                      </div>
                      {booking.lesson_rating && (
                        <div className="flex items-center gap-1 px-3 py-1 bg-white rounded-lg">
                          <span className="text-sm font-semibold text-gray-900">{booking.lesson_rating}/5</span>
                        </div>
                      )}
                    </div>
                    {booking.notes && (
                      <p className="text-sm text-gray-700 mt-2 p-3 bg-white rounded-lg">{booking.notes}</p>
                    )}
                    {booking.skills_practiced && booking.skills_practiced.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {booking.skills_practiced.map(skill => (
                          <span
                            key={skill}
                            className="px-2 py-1 bg-indigo-100 text-indigo-700 rounded text-xs font-medium"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === "financial" && (
            <div className="space-y-6">
              {/* Summary */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-gray-50 rounded-xl p-4">
                  <p className="text-sm text-gray-600 mb-1">Total Invoiced</p>
                  <p className="text-2xl font-bold text-gray-900">${totalInvoiced.toFixed(2)}</p>
                </div>
                <div className="bg-green-50 rounded-xl p-4">
                  <p className="text-sm text-green-600 mb-1">Total Paid</p>
                  <p className="text-2xl font-bold text-green-700">${totalPaid.toFixed(2)}</p>
                </div>
                <div className="bg-red-50 rounded-xl p-4">
                  <p className="text-sm text-red-600 mb-1">Outstanding</p>
                  <p className="text-2xl font-bold text-red-700">${outstanding.toFixed(2)}</p>
                </div>
              </div>

              {/* Invoices */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Payment History</h3>
                <div className="space-y-2">
                  {invoices.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">No invoices yet</p>
                  ) : (
                    invoices.map(invoice => (
                      <div key={invoice.id} className="bg-gray-50 rounded-lg p-4 flex items-center justify-between">
                        <div>
                          <p className="font-semibold text-gray-900">#{invoice.invoice_number}</p>
                          <p className="text-sm text-gray-600">
                            {format(new Date(invoice.issue_date), "MMM d, yyyy")}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-gray-900">${invoice.total_amount.toFixed(2)}</p>
                          <span className={`text-xs font-semibold ${
                            invoice.status === "paid" ? "text-green-600" : "text-red-600"
                          }`}>
                            {invoice.status}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}