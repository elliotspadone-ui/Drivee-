import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function ProgressChart({
  data,
  type = "line",
  title,
  xKey = "name",
  yKey = "value",
  height = 300,
  yFormatter,
}) {
  const hasData = Array.isArray(data) && data.length > 0;

  const gradientId = useMemo(
    () => `progress-gradient-${Math.random().toString(36).slice(2, 9)}`,
    []
  );

  if (!hasData) {
    return (
      <div className="neo-inset p-8 rounded-2xl text-center">
        <p className="text-sm text-zinc-500">No data available</p>
      </div>
    );
  }

  const commonTooltip = (
    <Tooltip
      contentStyle={{
        background: "#f5f5f7",
        border: "none",
        borderRadius: "12px",
        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
      }}
      formatter={(value) =>
        typeof yFormatter === "function" ? yFormatter(value) : value
      }
    />
  );

  const commonAxes = (
    <>
      <XAxis dataKey={xKey} stroke="#6b7280" tickMargin={8} />
      <YAxis
        stroke="#6b7280"
        tickMargin={8}
        tickFormatter={(val) =>
          typeof yFormatter === "function" ? yFormatter(val) : val
        }
      />
    </>
  );

  return (
    <div className="neo-surface p-6 rounded-2xl">
      {title && (
        <h3 className="font-semibold text-gray-900 mb-4 text-sm md:text-base">
          {title}
        </h3>
      )}
      <ResponsiveContainer width="100%" height={height}>
        {type === "line" ? (
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            {commonAxes}
            {commonTooltip}
            <defs>
              <linearGradient id={gradientId} x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#667eea" />
                <stop offset="100%" stopColor="#764ba2" />
              </linearGradient>
            </defs>
            <Line
              type="monotone"
              dataKey={yKey}
              stroke={`url(#${gradientId})`}
              strokeWidth={3}
              dot={{ fill: "#667eea", r: 4 }}
              activeDot={{ r: 5 }}
            />
          </LineChart>
        ) : (
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            {commonAxes}
            {commonTooltip}
            <defs>
              <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#667eea" />
                <stop offset="100%" stopColor="#764ba2" />
              </linearGradient>
            </defs>
            <Bar
              dataKey={yKey}
              fill={`url(#${gradientId})`}
              radius={[8, 8, 0, 0]}
            />
          </BarChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}
