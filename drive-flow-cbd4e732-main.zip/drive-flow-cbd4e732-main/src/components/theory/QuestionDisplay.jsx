import React, { useState, useMemo } from "react";
import { CheckCircle, XCircle, Play } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function QuestionDisplay({
  question,
  onAnswer,
  showExplanation = false,
  language = "en",
}) {
  const [selectedAnswers, setSelectedAnswers] = useState([]);
  const [showVideo, setShowVideo] = useState(false);

  const hasQuestion = !!question && Array.isArray(question.options);

  const questionText = useMemo(() => {
    if (!question) return "";
    return (
      question.question_text_translations?.[language] ||
      question.question_text ||
      ""
    );
  }, [question, language]);

  const explanation = useMemo(() => {
    if (!question) return "";
    return (
      question.explanation_translations?.[language] ||
      question.correct_answer_explanation ||
      ""
    );
  }, [question, language]);

  const handleSelectOption = (optionIndex) => {
    if (!hasQuestion || showExplanation) return;

    if (question.question_type === "multiple_select") {
      setSelectedAnswers((prev) =>
        prev.includes(optionIndex)
          ? prev.filter((i) => i !== optionIndex)
          : [...prev, optionIndex]
      );
    } else {
      setSelectedAnswers([optionIndex]);
      // Auto-submit for single choice
      setTimeout(() => {
        onAnswer([optionIndex]);
      }, 300);
    }
  };

  const handleSubmit = () => {
    if (!hasQuestion || selectedAnswers.length === 0) return;
    onAnswer(selectedAnswers);
  };

  const isCorrectOption = (index) =>
    hasQuestion ? !!question.options[index]?.is_correct : false;

  const isSelected = (index) => selectedAnswers.includes(index);

  const allCorrectSelected = useMemo(() => {
    if (!hasQuestion || selectedAnswers.length === 0) return false;
    const correctIndices = question.options
      .map((opt, idx) => (opt.is_correct ? idx : null))
      .filter((idx) => idx !== null);

    const selectedSet = new Set(selectedAnswers);
    const correctSet = new Set(correctIndices);

    if (selectedSet.size !== correctSet.size) return false;
    for (const idx of correctSet) {
      if (!selectedSet.has(idx)) return false;
    }
    return true;
  }, [question, selectedAnswers, hasQuestion]);

  if (!hasQuestion) {
    return (
      <div className="neo-surface p-8 rounded-3xl text-center">
        <p className="text-muted">No question available</p>
      </div>
    );
  }

  const isMultipleSelect = question.question_type === "multiple_select";

  return (
    <div className="space-y-6">
      {/* Question */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="neo-surface p-8 rounded-3xl"
      >
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-4">
            {question.category && (
              <span className="neo-button px-4 py-2 text-sm font-semibold text-indigo-700 capitalize">
                {String(question.category).replace(/_/g, " ")}
              </span>
            )}
            {question.difficulty && (
              <span className="neo-button px-4 py-2 text-sm font-semibold text-gray-700 capitalize">
                {question.difficulty}
              </span>
            )}
          </div>

          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            {questionText}
          </h3>

          {question.question_image_url && (
            <img
              src={question.question_image_url}
              alt="Question visual"
              className="w-full max-w-2xl rounded-2xl shadow-lg mb-4"
            />
          )}

          {isMultipleSelect && (
            <p className="text-sm text-muted italic">Select all that apply</p>
          )}
        </div>

        {/* Options */}
        <div
          className="space-y-3"
          role={isMultipleSelect ? "group" : "radiogroup"}
          aria-label="Answer options"
        >
          {question.options.map((option, index) => {
            const optionText = option.translations?.[language] || option.text;
            const isCorrect = isCorrectOption(index);
            const selected = isSelected(index);

            const showAsCorrect = showExplanation && isCorrect;
            const showAsIncorrect = showExplanation && selected && !isCorrect;

            return (
              <button
                key={index}
                type="button"
                onClick={() => handleSelectOption(index)}
                disabled={showExplanation}
                aria-pressed={selected}
                className={`w-full neo-button p-5 rounded-2xl text-left transition-all ${
                  showAsCorrect
                    ? "bg-green-50 border-2 border-green-500"
                    : showAsIncorrect
                    ? "bg-red-50 border-2 border-red-500"
                    : selected
                    ? "active bg-indigo-50"
                    : ""
                }`}
              >
                <div className="flex items-center gap-4">
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold ${
                      showAsCorrect
                        ? "bg-green-500 text-white"
                        : showAsIncorrect
                        ? "bg-red-500 text-white"
                        : selected
                        ? "bg-indigo-600 text-white"
                        : "neo-inset text-gray-600"
                    }`}
                  >
                    {showAsCorrect ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : showAsIncorrect ? (
                      <XCircle className="w-5 h-5" />
                    ) : (
                      String.fromCharCode(65 + index)
                    )}
                  </div>
                  <span className="flex-1 font-semibold text-gray-900">
                    {optionText}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Submit Button for Multiple Select */}
        {isMultipleSelect && !showExplanation && (
          <button
            type="button"
            onClick={handleSubmit}
            disabled={selectedAnswers.length === 0}
            className="neo-button w-full mt-6 py-4 gradient-primary text-white font-bold text-lg disabled:opacity-50"
          >
            Submit Answer
          </button>
        )}
      </motion.div>

      {/* Explanation */}
      <AnimatePresence>
        {showExplanation && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="neo-surface p-6 rounded-3xl"
          >
            <h4 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
              {allCorrectSelected ? (
                <>
                  <CheckCircle className="w-6 h-6 text-green-600" />
                  Correct
                </>
              ) : (
                <>
                  <XCircle className="w-6 h-6 text-red-600" />
                  Incorrect
                </>
              )}
            </h4>

            {explanation && (
              <p className="text-gray-700 mb-4">{explanation}</p>
            )}

            {question.video_explanation_url && (
              <>
                <button
                  type="button"
                  onClick={() => setShowVideo((prev) => !prev)}
                  className="neo-button px-6 py-3 flex items-center gap-2 font-semibold text-indigo-700"
                >
                  <Play className="w-5 h-5" />
                  {showVideo ? "Hide" : "Watch"} Video Explanation
                </button>

                {showVideo && (
                  <div className="mt-4 rounded-2xl overflow-hidden">
                    <video
                      src={question.video_explanation_url}
                      controls
                      className="w-full"
                      autoPlay
                    />
                  </div>
                )}
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
