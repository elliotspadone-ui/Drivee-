import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  ReferenceLine
} from "recharts";
import {
  TrendingUp,
  Target,
  Award,
  BookOpen,
  CheckCircle
} from "lucide-react";
import { format } from "date-fns";

const COLORS = [
  "#667eea",
  "#764ba2",
  "#10b981",
  "#f59e0b",
  "#ef4444",
  "#8b5cf6",
  "#ec4899",
  "#06b6d4"
];

export default function ProgressDashboard({ attempts = [], questions = [], studyPlan }) {
  const passThreshold = 80;

  // Category performance
  const categoryPerformance = useMemo(() => {
    const stats = {};

    attempts.forEach((attempt) => {
      attempt.questions?.forEach((q) => {
        const question = questions.find((quest) => quest.id === q.question_id);
        if (!question) return;

        if (!stats[question.category]) {
          stats[question.category] = { total: 0, correct: 0 };
        }

        stats[question.category].total += 1;
        if (q.is_correct) stats[question.category].correct += 1;
      });
    });

    return Object.entries(stats)
      .map(([category, data]) => ({
        category: category.split("_").join(" "),
        rawCategory: category,
        accuracy: data.total > 0 ? (data.correct / data.total) * 100 : 0,
        total: data.total
      }))
      .sort((a, b) => a.accuracy - b.accuracy);
  }, [attempts, questions]);

  // Progress over time
  const progressOverTime = useMemo(() => {
    return attempts
      .filter((a) => a.completed_at)
      .sort(
        (a, b) => new Date(a.completed_at).getTime() - new Date(b.completed_at).getTime()
      )
      .map((attempt, index) => ({
        attempt: index + 1,
        score: attempt.score_percentage || 0,
        date: format(new Date(attempt.completed_at), "MMM d")
      }));
  }, [attempts]);

  // Overall stats
  const totalQuestions = attempts.reduce(
    (sum, a) => sum + (a.total_questions || 0),
    0
  );
  const totalCorrect = attempts.reduce(
    (sum, a) => sum + (a.correct_answers || 0),
    0
  );
  const overallAccuracy =
    totalQuestions > 0 ? (totalCorrect / totalQuestions) * 100 : 0;

  const recentAttempts = attempts.slice(-5);
  const averageScore =
    recentAttempts.length > 0
      ? recentAttempts.reduce(
          (sum, a) => sum + (a.score_percentage || 0),
          0
        ) / recentAttempts.length
      : 0;

  // Weak areas
  const weakAreas = categoryPerformance.filter((c) => c.accuracy < 70);

  // Readiness score
  const readinessScore = useMemo(() => {
    const coverageBoost = Math.min(totalQuestions, 500) / 5;
    const penalty = weakAreas.length * 10;
    const raw = averageScore - penalty + coverageBoost;
    return Math.min(100, Math.max(0, raw || 0));
  }, [averageScore, weakAreas.length, totalQuestions]);

  // Study plan goals: accept both array and { daily_goals: [...] }
  const studyGoals = useMemo(() => {
    if (!studyPlan) return [];
    if (Array.isArray(studyPlan)) return studyPlan;
    if (Array.isArray(studyPlan.daily_goals)) return studyPlan.daily_goals;
    return [];
  }, [studyPlan]);

  // Category distribution for pie chart
  const categoryDistribution = useMemo(() => {
    return categoryPerformance
      .filter((c) => c.total > 0)
      .map((c) => ({
        name: c.category,
        value: c.total
      }));
  }, [categoryPerformance]);

  return (
    <div className="space-y-6">
      {/* Overall Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <div className="neo-inset w-12 h-12 rounded-2xl flex items-center justify-center">
              <Target className="w-6 h-6 text-indigo-600" />
            </div>
            <span className="text-sm font-semibold text-gray-700">Readiness</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">
            {readinessScore.toFixed(0)}%
          </p>
          <p className="text-xs text-muted mt-2">
            {readinessScore >= 80
              ? "Ready for exam!"
              : readinessScore >= 60
              ? "Almost ready"
              : "Keep practicing"}
          </p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <div className="neo-inset w-12 h-12 rounded-2xl flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-sm font-semibold text-gray-700">Questions</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">{totalQuestions}</p>
          <p className="text-xs text-muted mt-2">
            {attempts.length} practice sessions
          </p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <div className="neo-inset w-12 h-12 rounded-2xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-sm font-semibold text-gray-700">Accuracy</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">
            {overallAccuracy.toFixed(0)}%
          </p>
          <p className="text-xs text-muted mt-2">
            {totalCorrect} correct answers
          </p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <div className="neo-inset w-12 h-12 rounded-2xl flex items-center justify-center">
              <Award className="w-6 h-6 text-yellow-600" />
            </div>
            <span className="text-sm font-semibold text-gray-700">
              Recent Avg
            </span>
          </div>
          <p className="text-4xl font-bold text-gray-900">
            {averageScore.toFixed(0)}%
          </p>
          <p className="text-xs text-muted mt-2">Last 5 attempts</p>
        </div>
      </div>

      {/* Progress Chart */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">
          Progress Over Time
        </h3>

        {progressOverTime.length === 0 ? (
          <div className="h-40 flex items-center justify-center text-sm text-muted">
            Not enough data yet. Complete at least one attempt to see your
            progress.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={progressOverTime}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis
                dataKey="date"
                stroke="#6b7280"
                style={{ fontSize: "12px" }}
              />
              <YAxis
                stroke="#6b7280"
                style={{ fontSize: "12px" }}
                domain={[0, 100]}
              />
              <Tooltip
                contentStyle={{
                  background: "#f5f5f7",
                  border: "none",
                  borderRadius: "12px",
                  boxShadow: "0 4px 12px rgba(0,0,0,0.1)"
                }}
              />
              <Line
                type="monotone"
                dataKey="score"
                stroke="#667eea"
                strokeWidth={3}
                dot={{ fill: "#667eea", r: 5 }}
              />
              <ReferenceLine
                y={passThreshold}
                stroke="#10b981"
                strokeDasharray="5 5"
              />
            </LineChart>
          </ResponsiveContainer>
        )}

        <p className="text-xs text-muted text-center mt-2">
          Green line indicates {passThreshold}% pass threshold
        </p>
      </div>

      {/* Category Performance + Weak Areas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">
            Category Performance
          </h3>
          {categoryPerformance.length === 0 ? (
            <div className="h-40 flex items-center justify-center text-sm text-muted">
              No category data yet. Practice some questions to see breakdowns.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={categoryPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis
                  dataKey="category"
                  stroke="#6b7280"
                  style={{ fontSize: "11px" }}
                  angle={-45}
                  textAnchor="end"
                  height={100}
                />
                <YAxis
                  stroke="#6b7280"
                  style={{ fontSize: "12px" }}
                  domain={[0, 100]}
                />
                <Tooltip
                  contentStyle={{
                    background: "#f5f5f7",
                    border: "none",
                    borderRadius: "12px",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.1)"
                  }}
                />
                <Bar dataKey="accuracy" radius={[8, 8, 0, 0]}>
                  {categoryPerformance.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={
                        entry.accuracy >= 70
                          ? "#10b981"
                          : entry.accuracy >= 50
                          ? "#f59e0b"
                          : "#ef4444"
                      }
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Weak Areas</h3>
          {weakAreas.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <CheckCircle className="w-16 h-16 text-green-600 mb-4" />
              <p className="text-lg font-semibold text-gray-900">
                No weak areas
              </p>
              <p className="text-sm text-muted">
                You are performing well in all categories
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {weakAreas.map((area, index) => (
                <div key={index} className="neo-inset p-4 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-gray-900 capitalize">
                      {area.category}
                    </span>
                    <span
                      className={`font-bold ${
                        area.accuracy >= 50
                          ? "text-orange-600"
                          : "text-red-600"
                      }`}
                    >
                      {area.accuracy.toFixed(0)}%
                    </span>
                  </div>
                  <div className="relative h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={`absolute h-full ${
                        area.accuracy >= 50
                          ? "bg-orange-600"
                          : "bg-red-600"
                      }`}
                      style={{ width: `${area.accuracy}%` }}
                    />
                  </div>
                  <p className="text-xs text-muted mt-2">
                    {area.total} questions attempted
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Category Distribution Pie */}
      {categoryDistribution.length > 0 && (
        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">
            Question Distribution by Category
          </h3>
          <div className="w-full h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryDistribution}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  labelLine={false}
                  label={(entry) => `${entry.name} (${entry.value})`}
                >
                  {categoryDistribution.map((entry, index) => (
                    <Cell
                      key={`slice-${index}`}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "#f5f5f7",
                    border: "none",
                    borderRadius: "12px",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.1)"
                  }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Study Plan Progress */}
      {studyGoals.length > 0 && (
        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">
            Study Plan Progress
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
            {studyGoals.slice(0, 7).map((goal, index) => (
              <div
                key={index}
                className={`neo-inset p-4 rounded-xl text-center ${
                  goal.completed ? "bg-green-50" : ""
                }`}
              >
                <p className="text-xs text-muted mb-1">
                  {format(new Date(goal.date), "EEE")}
                </p>
                <p className="text-lg font-bold text-gray-900">
                  {goal.questions_completed}/{goal.target_questions}
                </p>
                {goal.completed && (
                  <CheckCircle className="w-4 h-4 text-green-600 mx-auto mt-2" />
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
