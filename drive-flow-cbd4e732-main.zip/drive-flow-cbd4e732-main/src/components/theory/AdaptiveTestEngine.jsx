/**
 * Adaptive Test Engine
 * Intelligently selects questions based on student performance
 */

export class AdaptiveTestEngine {
  constructor(questions = [], studentHistory = []) {
    this.questions = Array.isArray(questions) ? questions : [];
    this.studentHistory = Array.isArray(studentHistory) ? studentHistory : [];

    // Precompute lookup map for questions by id for faster access
    this.questionIndex = new Map(
      this.questions
        .filter(q => q && typeof q.id !== "undefined")
        .map(q => [q.id, q])
    );

    // Precompute category list from question bank
    this.categories = [
      ...new Set(
        this.questions
          .map(q => q.category)
          .filter(Boolean)
      ),
    ];
  }

  /**
   * Replace the full history (for example after refetch)
   */
  setStudentHistory(history = []) {
    this.studentHistory = Array.isArray(history) ? history : [];
  }

  /**
   * Incrementally add a new test attempt to the history
   */
  addAttempt(attempt) {
    if (!attempt || !Array.isArray(attempt.questions)) return;
    this.studentHistory.push(attempt);
  }

  /**
   * Internal helper to get a question by id
   */
  getQuestionById(id) {
    return this.questionIndex.get(id);
  }

  /**
   * Calculate student's weak areas based on past attempts
   */
  analyzeWeakAreas() {
    const categoryStats = {};

    this.studentHistory.forEach(attempt => {
      if (!attempt || !Array.isArray(attempt.questions)) return;

      attempt.questions.forEach(q => {
        if (!q || typeof q.question_id === "undefined") return;

        const question = this.getQuestionById(q.question_id);
        if (!question || !question.category) return;

        if (!categoryStats[question.category]) {
          categoryStats[question.category] = {
            total: 0,
            correct: 0,
            avgTime: 0,
          };
        }

        const stats = categoryStats[question.category];

        stats.total += 1;
        if (q.is_correct) stats.correct += 1;
        stats.avgTime += q.time_spent_seconds || 0;
      });
    });

    const result = Object.entries(categoryStats).map(([category, stats]) => {
      const accuracyRaw = stats.total > 0 ? stats.correct / stats.total : 0;
      return {
        category,
        accuracy: accuracyRaw * 100,
        totalAnswered: stats.total,
        avgTime: stats.total > 0 ? stats.avgTime / stats.total : 0,
        needsWork: stats.total > 0 && accuracyRaw < 0.7, // 70% threshold
      };
    });

    // Sort from weakest to strongest
    return result.sort((a, b) => a.accuracy - b.accuracy);
  }

  /**
   * Get commonly mistaken questions
   */
  getMistakePatterns() {
    const mistakes = {};

    this.studentHistory.forEach(attempt => {
      if (!attempt || !Array.isArray(attempt.questions)) return;

      attempt.questions.forEach(q => {
        if (!q || q.is_correct || typeof q.question_id === "undefined") return;

        if (!mistakes[q.question_id]) {
          mistakes[q.question_id] = {
            count: 0,
            question: this.getQuestionById(q.question_id),
          };
        }
        mistakes[q.question_id].count += 1;
      });
    });

    return Object.values(mistakes)
      .filter(m => m.question)
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }

  /**
   * Select next questions adaptively
   * 60% from weak areas, 20% from commonly mistaken, 20% random
   */
  selectAdaptiveQuestions(count = 40) {
    if (!Array.isArray(this.questions) || this.questions.length === 0) {
      return [];
    }

    const weakAreas = this.analyzeWeakAreas();
    const selected = [];
    const usedQuestions = new Set();

    const safeCount = Math.max(1, Math.floor(count));
    const weakCount = Math.floor(safeCount * 0.6);
    const mistakeCount = Math.floor(safeCount * 0.2);

    // 60% from weak areas
    const weakCategories = weakAreas.filter(w => w.needsWork).map(w => w.category);

    if (weakCategories.length > 0) {
      const weakQuestions = this.questions.filter(
        q => weakCategories.includes(q.category) && !usedQuestions.has(q.id)
      );

      const selectedWeak = this.randomSample(weakQuestions, weakCount);
      selectedWeak.forEach(q => {
        selected.push(q);
        usedQuestions.add(q.id);
      });
    }

    // 20% from mistakes
    const mistakePatterns = this.getMistakePatterns();
    const mistakeQuestions = mistakePatterns
      .map(m => m.question)
      .filter(q => q && !usedQuestions.has(q.id));

    const selectedMistakes = this.randomSample(mistakeQuestions, mistakeCount);
    selectedMistakes.forEach(q => {
      selected.push(q);
      usedQuestions.add(q.id);
    });

    // Fill remaining with random questions
    const remaining = safeCount - selected.length;
    if (remaining > 0) {
      const availableQuestions = this.questions.filter(q => !usedQuestions.has(q.id));
      const randomQuestions = this.randomSample(availableQuestions, remaining);
      selected.push(...randomQuestions);
    }

    return this.shuffleArray(selected);
  }

  /**
   * Generate personalized study plan until test date
   */
  generateStudyPlan(testDate, dailyMinutes = 30) {
    const today = new Date();
    const test = new Date(testDate);
    const msPerDay = 1000 * 60 * 60 * 24;
    const daysUntilTest = Math.ceil((test - today) / msPerDay);

    if (Number.isNaN(daysUntilTest) || daysUntilTest <= 0) {
      return null;
    }

    const weakAreas = this.analyzeWeakAreas();
    const questionsPerDay = Math.max(1, Math.floor(dailyMinutes / 1.5)); // ~1.5 min per question

    // Use computed weak areas if available, otherwise fall back to a default set
    const categories =
      weakAreas.length > 0
        ? weakAreas
        : (this.categories.length > 0
            ? this.categories.map(cat => ({ category: cat, accuracy: 50 }))
            : ["traffic_signs", "road_rules", "safety", "vehicle_handling"].map(cat => ({
                category: cat,
                accuracy: 50,
              })));

    const plan = [];

    for (let i = 0; i < daysUntilTest; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() + i);

      const categoryIndex = i % categories.length;
      const category = categories[categoryIndex].category;

      plan.push({
        date: date.toISOString().split("T")[0],
        category,
        target_questions: questionsPerDay,
        completed: false,
        questions_completed: 0,
      });
    }

    return plan;
  }

  /**
   * Helper: Random sample from array using Fisher Yates shuffle
   */
  randomSample(array, count) {
    if (!Array.isArray(array) || array.length === 0 || count <= 0) {
      return [];
    }

    const maxCount = Math.min(count, array.length);
    const copy = [...array];

    for (let i = copy.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }

    return copy.slice(0, maxCount);
  }

  /**
   * Helper: Shuffle array (non mutating)
   */
  shuffleArray(array) {
    if (!Array.isArray(array) || array.length === 0) {
      return [];
    }

    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }

  /**
   * Calculate readiness score between 0 and 100
   */
  calculateReadinessScore() {
    if (!Array.isArray(this.studentHistory) || this.studentHistory.length === 0) {
      return 0;
    }

    const recentAttempts = this.studentHistory.slice(-5).filter(a => a);
    if (recentAttempts.length === 0) {
      return 0;
    }

    const avgScore =
      recentAttempts.reduce((sum, a) => sum + (a.score_percentage || 0), 0) /
      recentAttempts.length;

    const weakAreas = this.analyzeWeakAreas();
    const weakCount = weakAreas.filter(w => w.needsWork).length;
    const weakPenalty = weakCount * 10;

    const totalQuestions = this.studentHistory.reduce(
      (sum, a) => sum + (a.total_questions || 0),
      0
    );

    const questionPoolSize = Math.max(1, this.questions.length);
    const coverageFactor = Math.min(100, (totalQuestions / questionPoolSize) * 100);

    const rawScore = avgScore - weakPenalty + coverageFactor * 0.2;
    return Math.max(0, Math.min(100, rawScore));
  }
}

export default AdaptiveTestEngine;
