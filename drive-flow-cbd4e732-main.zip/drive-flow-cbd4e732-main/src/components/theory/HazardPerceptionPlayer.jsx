import React, { useState, useRef } from "react";
import { Play, Pause, RotateCcw, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function HazardPerceptionPlayer({ test, onComplete }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [clicks, setClicks] = useState([]);
  const [detectedHazards, setDetectedHazards] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const videoRef = useRef(null);

  const hasTest = !!test && Array.isArray(test.hazards);

  const handleVideoClick = (e) => {
    if (!isPlaying || !videoRef.current) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    setClicks((prev) => [
      ...prev,
      {
        timestamp: videoRef.current.currentTime || 0,
        x,
        y,
      },
    ]);
  };

  const checkHazardDetection = () => {
    if (!hasTest || clicks.length === 0) return;

    test.hazards.forEach((hazard, index) => {
      setDetectedHazards((prev) => {
        // Already detected this hazard
        if (prev.some((d) => d.hazard_index === index)) return prev;

        const relevantClicks = clicks.filter(
          (c) =>
            c.timestamp >= hazard.start_time &&
            c.timestamp <= hazard.end_time
        );

        if (relevantClicks.length === 0) return prev;

        const firstClick = relevantClicks[0];
        const responseTime = firstClick.timestamp - hazard.start_time;
        const windowDuration = hazard.end_time - hazard.start_time;

        const rawScore =
          hazard.max_points *
          (1 - responseTime / Math.max(windowDuration, 0.01));

        const points = Math.max(1, Math.floor(rawScore));

        return [
          ...prev,
          {
            hazard_index: index,
            click_time: firstClick.timestamp,
            points_awarded: points,
          },
        ];
      });
    });
  };

  const calculateScore = () => {
    if (!hasTest) return;

    const totalScore = detectedHazards.reduce(
      (sum, d) => sum + d.points_awarded,
      0
    );
    const maxScore = test.hazards.reduce(
      (sum, h) => sum + h.max_points,
      0
    );

    setShowResults(true);

    if (onComplete) {
      onComplete({
        clicks,
        hazards_detected: detectedHazards,
        total_score: totalScore,
        max_possible_score: maxScore,
      });
    }
  };

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;
    const t = video.currentTime || 0;
    setCurrentTime(t);
    checkHazardDetection();
  };

  const handleEnded = () => {
    setIsPlaying(false);
    calculateScore();
  };

  const handlePlayPause = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
      setIsPlaying(false);
    } else {
      video.play();
      setIsPlaying(true);
    }
  };

  const handleRestart = () => {
    const video = videoRef.current;
    if (!video) return;

    video.pause();
    video.currentTime = 0;

    setIsPlaying(false);
    setClicks([]);
    setDetectedHazards([]);
    setShowResults(false);
    setCurrentTime(0);
  };

  if (!hasTest) {
    return (
      <div className="neo-surface p-8 rounded-3xl text-center">
        <p className="text-muted">No hazard perception test available</p>
      </div>
    );
  }

  const durationSeconds = test.duration_seconds || 0;

  return (
    <div className="space-y-6">
      {/* Instructions */}
      {!isPlaying && currentTime === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="neo-surface p-6 rounded-3xl"
        >
          <h3 className="text-xl font-bold text-gray-900 mb-3">
            Instructions
          </h3>
          <ul className="space-y-2 text-gray-700">
            <li>• Click anywhere on the video when you spot a developing hazard</li>
            <li>• The earlier you identify the hazard, the more points you score</li>
            <li>• You can click multiple times, but only the first click in each hazard window counts</li>
            <li>• The test will end automatically when the video finishes</li>
          </ul>
        </motion.div>
      )}

      {/* Video Player */}
      <div className="neo-surface p-6 rounded-3xl">
        <div className="relative rounded-2xl overflow-hidden bg-black">
          <video
            ref={videoRef}
            src={test.video_url}
            className="w-full cursor-crosshair"
            onClick={handleVideoClick}
            onTimeUpdate={handleTimeUpdate}
            onEnded={handleEnded}
          />

          {/* Click markers */}
          {clicks.map((click, index) => (
            <motion.div
              key={index}
              initial={{ scale: 0 }}
              animate={{ scale: [0, 1.5, 0] }}
              transition={{ duration: 0.5 }}
              className="absolute w-4 h-4 bg-red-500 rounded-full pointer-events-none"
              style={{
                left: `${click.x}%`,
                top: `${click.y}%`,
                transform: "translate(-50%, -50%)",
              }}
            />
          ))}

          {/* Hazard detection indicators */}
          {detectedHazards.map((detection, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute right-4"
              style={{ top: `${20 + index * 40}px` }}
            >
              <div className="neo-button px-4 py-2 bg-green-50 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="text-sm font-bold text-green-700">
                  +{detection.points_awarded} points
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center gap-3">
            <button
              onClick={handlePlayPause}
              className="neo-button p-3 rounded-xl"
              type="button"
            >
              {isPlaying ? (
                <Pause className="w-6 h-6 text-gray-700" />
              ) : (
                <Play className="w-6 h-6 text-gray-700" />
              )}
            </button>
            <button
              onClick={handleRestart}
              className="neo-button p-3 rounded-xl"
              type="button"
            >
              <RotateCcw className="w-6 h-6 text-gray-700" />
            </button>
          </div>

          <div className="neo-inset px-4 py-2 rounded-xl">
            <span className="font-semibold text-gray-900">
              {Math.floor(currentTime)}s / {durationSeconds}s
            </span>
          </div>

          <div className="neo-inset px-4 py-2 rounded-xl">
            <span className="font-semibold text-gray-900">
              {detectedHazards.length} / {test.hazards.length} hazards detected
            </span>
          </div>
        </div>
      </div>

      {/* Results */}
      {showResults && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="neo-surface p-8 rounded-3xl"
        >
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Test Complete!
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="neo-inset p-6 rounded-2xl text-center">
              <p className="text-sm text-muted mb-2">Your Score</p>
              <p className="text-4xl font-bold text-indigo-600">
                {detectedHazards.reduce(
                  (sum, d) => sum + d.points_awarded,
                  0
                )}
              </p>
            </div>
            <div className="neo-inset p-6 rounded-2xl text-center">
              <p className="text-sm text-muted mb-2">Max Possible</p>
              <p className="text-4xl font-bold text-gray-900">
                {test.hazards.reduce((sum, h) => sum + h.max_points, 0)}
              </p>
            </div>
            <div className="neo-inset p-6 rounded-2xl text-center">
              <p className="text-sm text-muted mb-2">Hazards Found</p>
              <p className="text-4xl font-bold text-green-600">
                {detectedHazards.length} / {test.hazards.length}
              </p>
            </div>
          </div>

          {/* Hazard Breakdown */}
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-900">
              Hazard Breakdown
            </h4>
            {test.hazards.map((hazard, index) => {
              const detected = detectedHazards.find(
                (d) => d.hazard_index === index
              );
              return (
                <div
                  key={index}
                  className="neo-inset p-4 rounded-xl flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    {detected ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : (
                      <div className="w-6 h-6 rounded-full border-2 border-gray-300" />
                    )}
                    <span className="text-sm text-gray-700">
                      {hazard.description}
                    </span>
                  </div>
                  <span
                    className={`font-bold ${
                      detected ? "text-green-600" : "text-gray-400"
                    }`}
                  >
                    {detected ? `+${detected.points_awarded}` : "0"} /{" "}
                    {hazard.max_points}
                  </span>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}
    </div>
  );
}
