import React, { useState, useEffect, useRef, useCallback } from "react";
import { Clock, Flag, ChevronLeft, ChevronRight, CheckCircle, XCircle } from "lucide-react";
import { motion } from "framer-motion";
import QuestionDisplay from "./QuestionDisplay";

export default function MockExamInterface({
  questions,
  timeLimit = 2400, // 40 minutes in seconds
  passingScore = 80,
  onComplete,
}) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [flagged, setFlagged] = useState(new Set());
  const [timeRemaining, setTimeRemaining] = useState(timeLimit);
  const [isStarted, setIsStarted] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const [showReview, setShowReview] = useState(false);
  const [examResults, setExamResults] = useState(null);

  // Per question timing
  const questionTimeRef = useRef({});
  const lastChangeRef = useRef(0);

  const currentQuestion = questions[currentQuestionIndex];

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const handleStart = () => {
    setIsStarted(true);
    setIsFinished(false);
    setShowReview(false);
    setTimeRemaining(timeLimit);
    setCurrentQuestionIndex(0);
    setAnswers({});
    setFlagged(new Set());
    setExamResults(null);
    questionTimeRef.current = {};
    lastChangeRef.current = 0;
  };

  const recordCurrentQuestionTime = () => {
    const elapsed = timeLimit - timeRemaining;
    const delta = elapsed - lastChangeRef.current;
    if (delta <= 0) return;

    const times = questionTimeRef.current;
    const prev = times[currentQuestionIndex] || 0;
    times[currentQuestionIndex] = prev + delta;
    questionTimeRef.current = times;
    lastChangeRef.current = elapsed;
  };

  const checkAnswer = (question, selectedAnswers) => {
    const correctIndices = question.options
      .map((opt, idx) => (opt.is_correct ? idx : null))
      .filter((idx) => idx !== null);

    return (
      correctIndices.length === selectedAnswers.length &&
      correctIndices.every((idx) => selectedAnswers.includes(idx))
    );
  };

  const handleAnswer = (selectedAnswers) => {
    const isCorrect = checkAnswer(currentQuestion, selectedAnswers);

    setAnswers((prev) => ({
      ...prev,
      [currentQuestionIndex]: {
        question_id: currentQuestion.id,
        student_answer: selectedAnswers,
        is_correct: isCorrect,
      },
    }));

    // Auto-advance for single choice questions
    if (
      currentQuestion.question_type !== "multiple_select" &&
      currentQuestionIndex < questions.length - 1
    ) {
      // Record time spent on this question up to the answer moment
      recordCurrentQuestionTime();
      setTimeout(() => {
        setCurrentQuestionIndex((prev) => prev + 1);
        // Last change timestamp stays at the elapsed time when we left the question
        // Next time we record, delta will be from this moment
      }, 500);
    }
  };

  const finishExam = useCallback(() => {
    if (isFinished || questions.length === 0) return;

    // Final time record for the current question
    recordCurrentQuestionTime();

    const times = questionTimeRef.current || {};

    const questionResults = questions.map((q, index) => {
      const answer = answers[index];
      const time_spent_seconds = times[index] || 0;

      if (!answer) {
        return {
          question_id: q.id,
          student_answer: [],
          is_correct: false,
          time_spent_seconds,
        };
      }

      return {
        ...answer,
        time_spent_seconds,
      };
    });

    const correctAnswers = questionResults.filter((r) => r.is_correct).length;
    const scorePercentage = (correctAnswers / questions.length) * 100;
    const totalTimeSpent = questionResults.reduce(
      (sum, r) => sum + (r.time_spent_seconds || 0),
      0
    );

    const results = {
      questions: questionResults,
      total_questions: questions.length,
      correct_answers: correctAnswers,
      score_percentage: scorePercentage,
      time_spent_seconds: totalTimeSpent,
      passed: scorePercentage >= passingScore,
    };

    setIsFinished(true);
    setExamResults(results);

    if (onComplete) {
      onComplete(results);
    }
  }, [answers, isFinished, onComplete, passingScore, questions, timeLimit, timeRemaining]);

  // Countdown timer
  useEffect(() => {
    if (!isStarted || isFinished) return;

    if (timeRemaining <= 0) {
      finishExam();
      return;
    }

    const timer = setInterval(() => {
      setTimeRemaining((prev) => Math.max(prev - 1, 0));
    }, 1000);

    return () => clearInterval(timer);
  }, [isStarted, isFinished, timeRemaining, finishExam]);

  const toggleFlag = () => {
    setFlagged((prev) => {
      const next = new Set(prev);
      if (next.has(currentQuestionIndex)) {
        next.delete(currentQuestionIndex);
      } else {
        next.add(currentQuestionIndex);
      }
      return next;
    });
  };

  const goToQuestion = (index) => {
    if (index === currentQuestionIndex) return;
    recordCurrentQuestionTime();
    setCurrentQuestionIndex(index);
  };

  // Start Screen
  if (!isStarted) {
    return (
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="neo-surface p-12 rounded-3xl text-center"
        >
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Mock Theory Test</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="neo-inset p-6 rounded-2xl">
              <p className="text-sm text-muted mb-2">Questions</p>
              <p className="text-3xl font-bold text-gray-900">{questions.length}</p>
            </div>
            <div className="neo-inset p-6 rounded-2xl">
              <p className="text-sm text-muted mb-2">Time Limit</p>
              <p className="text-3xl font-bold text-gray-900">{timeLimit / 60} min</p>
            </div>
            <div className="neo-inset p-6 rounded-2xl">
              <p className="text-sm text-muted mb-2">Pass Mark</p>
              <p className="text-3xl font-bold text-gray-900">{passingScore}%</p>
            </div>
          </div>

          <div className="neo-inset p-6 rounded-2xl mb-8 text-left">
            <h3 className="font-bold text-gray-900 mb-3">Instructions:</h3>
            <ul className="space-y-2 text-gray-700">
              <li>• You have {timeLimit / 60} minutes to complete {questions.length} questions</li>
              <li>• You need {passingScore}% to pass</li>
              <li>• You can flag questions to review later</li>
              <li>• You can navigate between questions using the arrows</li>
              <li>• Click "Finish Exam" when you are done</li>
            </ul>
          </div>

          <button
            onClick={handleStart}
            className="neo-button px-12 py-4 gradient-primary text-white font-bold text-lg"
          >
            Start Mock Exam
          </button>
        </motion.div>
      </div>
    );
  }

  // Results + Review Screens
  if (isFinished && examResults) {
    const score = examResults.score_percentage;
    const passed = examResults.passed;
    const correctCount = examResults.correct_answers;
    const incorrectCount = examResults.total_questions - correctCount;
    const timeUsedMinutes = Math.floor((examResults.time_spent_seconds || 0) / 60);

    if (showReview) {
      // Review Screen
      return (
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="neo-surface p-6 rounded-3xl flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-1">Review Answers</h2>
              <p className="text-sm text-muted">
                Tap any question below to see what you selected compared to the correct answer.
              </p>
            </div>
            <button
              onClick={() => setShowReview(false)}
              className="neo-button px-6 py-3 font-semibold"
            >
              Back to Summary
            </button>
          </div>

          <div className="neo-surface p-6 rounded-3xl">
            <div className="grid grid-cols-1 gap-4">
              {examResults.questions.map((result, index) => {
                const question = questions.find((q) => q.id === result.question_id) || questions[index];
                const studentAnswers = result.student_answer || [];
                const isCorrect = result.is_correct;
                const timeSpent = result.time_spent_seconds || 0;

                const correctIndices = question.options
                  .map((opt, idx) => (opt.is_correct ? idx : null))
                  .filter((idx) => idx !== null);

                return (
                  <div key={index} className="neo-inset p-4 rounded-2xl">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-semibold px-2 py-1 rounded-lg bg-zinc-100 text-zinc-700">
                          Q{index + 1}
                        </span>
                        <p className="font-semibold text-gray-900">
                          {question.question_text}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted">
                          {Math.round(timeSpent)}s
                        </span>
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold ${
                            isCorrect
                              ? "bg-green-50 text-green-700"
                              : "bg-red-50 text-red-700"
                          }`}
                        >
                          {isCorrect ? (
                            <CheckCircle className="w-4 h-4" />
                          ) : (
                            <XCircle className="w-4 h-4" />
                          )}
                          {isCorrect ? "Correct" : "Incorrect"}
                        </span>
                      </div>
                    </div>

                    <ul className="mt-3 space-y-2">
                      {question.options.map((opt, optIndex) => {
                        const isCorrectOpt = correctIndices.includes(optIndex);
                        const isSelected = studentAnswers.includes(optIndex);

                        const base =
                          "flex items-start gap-3 p-3 rounded-xl border text-sm";
                        const stateClass = isCorrectOpt
                          ? "bg-green-50 border-green-200 text-green-800"
                          : isSelected
                          ? "bg-red-50 border-red-200 text-red-800"
                          : "bg-zinc-50 border-zinc-200 text-gray-800";

                        return (
                          <li key={optIndex} className={`${base} ${stateClass}`}>
                            <span className="w-7 h-7 rounded-lg flex items-center justify-center font-bold bg-white/60 text-gray-700">
                              {String.fromCharCode(65 + optIndex)}
                            </span>
                            <span>{opt.text}</span>
                          </li>
                        );
                      })}
                    </ul>

                    {question.correct_answer_explanation && (
                      <p className="mt-3 text-sm text-gray-700">
                        <span className="font-semibold">Explanation: </span>
                        {question.correct_answer_explanation}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      );
    }

    // Summary Screen
    return (
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="neo-surface p-12 rounded-3xl text-center"
        >
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            {passed ? "Congratulations! 🎉" : "Keep Practicing"}
          </h2>
          <p className="text-lg text-muted mb-8">
            {passed ? "You have passed the mock exam." : "You need more practice to reach the pass mark."}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="neo-inset p-6 rounded-2xl">
              <p className="text-sm text-muted mb-2">Score</p>
              <p className={`text-4xl font-bold ${passed ? "text-green-600" : "text-red-600"}`}>
                {score.toFixed(0)}%
              </p>
            </div>
            <div className="neo-inset p-6 rounded-2xl">
              <p className="text-sm text-muted mb-2">Correct</p>
              <p className="text-4xl font-bold text-gray-900">{correctCount}</p>
            </div>
            <div className="neo-inset p-6 rounded-2xl">
              <p className="text-sm text-muted mb-2">Incorrect</p>
              <p className="text-4xl font-bold text-gray-900">{incorrectCount}</p>
            </div>
            <div className="neo-inset p-6 rounded-2xl">
              <p className="text-sm text-muted mb-2">Time Used</p>
              <p className="text-4xl font-bold text-gray-900">{timeUsedMinutes}m</p>
            </div>
          </div>

          <button
            onClick={() => setShowReview(true)}
            className="neo-button px-12 py-4 gradient-primary text-white font-bold text-lg"
          >
            Review Answers
          </button>
        </motion.div>
      </div>
    );
  }

  // Live Exam Interface
  if (!currentQuestion) {
    return (
      <div className="max-w-3xl mx-auto">
        <div className="neo-surface p-8 rounded-3xl text-center">
          <p className="text-muted">No questions available.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="neo-surface p-4 mb-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div
            className={`neo-inset px-4 py-2 rounded-xl flex items-center gap-2 ${
              timeRemaining < 300 ? "bg-red-50" : ""
            }`}
          >
            <Clock
              className={`w-5 h-5 ${
                timeRemaining < 300 ? "text-red-600" : "text-gray-600"
              }`}
            />
            <span
              className={`font-bold ${
                timeRemaining < 300 ? "text-red-600" : "text-gray-900"
              }`}
            >
              {formatTime(timeRemaining)}
            </span>
          </div>

          <div className="neo-inset px-4 py-2 rounded-xl">
            <span className="font-semibold text-gray-900">
              Question {currentQuestionIndex + 1} of {questions.length}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={toggleFlag}
            className={`neo-button p-3 rounded-xl ${
              flagged.has(currentQuestionIndex) ? "bg-yellow-50" : ""
            }`}
          >
            <Flag
              className={`w-5 h-5 ${
                flagged.has(currentQuestionIndex)
                  ? "text-yellow-600 fill-yellow-600"
                  : "text-gray-600"
              }`}
            />
          </button>

          <button
            onClick={finishExam}
            className="neo-button px-6 py-3 gradient-primary text-white font-semibold"
          >
            Finish Exam
          </button>
        </div>
      </div>

      {/* Question */}
      <QuestionDisplay
        question={currentQuestion}
        onAnswer={handleAnswer}
        showExplanation={false}
      />

      {/* Navigation */}
      <div className="neo-surface p-4 mt-6">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() =>
              goToQuestion(Math.max(0, currentQuestionIndex - 1))
            }
            disabled={currentQuestionIndex === 0}
            className="neo-button px-6 py-3 flex items-center gap-2 disabled:opacity-50"
          >
            <ChevronLeft className="w-5 h-5" />
            Previous
          </button>

          <button
            onClick={() =>
              goToQuestion(
                Math.min(questions.length - 1, currentQuestionIndex + 1)
              )
            }
            disabled={currentQuestionIndex === questions.length - 1}
            className="neo-button px-6 py-3 flex items-center gap-2 disabled:opacity-50"
          >
            Next
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Question Grid */}
        <div className="grid grid-cols-10 gap-2">
          {questions.map((_, index) => (
            <button
              key={index}
              onClick={() => goToQuestion(index)}
              className={`neo-button p-3 rounded-xl font-semibold ${
                index === currentQuestionIndex
                  ? "active bg-indigo-50"
                  : answers[index]
                  ? "bg-green-50 text-green-700"
                  : flagged.has(index)
                  ? "bg-yellow-50 text-yellow-700"
                  : ""
              }`}
            >
              {index + 1}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
