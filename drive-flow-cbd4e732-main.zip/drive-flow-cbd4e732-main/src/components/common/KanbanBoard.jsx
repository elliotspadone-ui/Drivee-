import React from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { motion } from "framer-motion";
import { GripVertical } from "lucide-react";

/**
 * Reusable Kanban Board Component
 * 
 * @param {Object} props
 * @param {Array} props.columns - Array of column objects with { id, title, color, items }
 * @param {Function} props.onDragEnd - Callback when drag ends (result)
 * @param {Function} props.renderCard - Function to render each card item
 * @param {String} props.className - Additional classes
 */
export default function KanbanBoard({ 
  columns = [], 
  onDragEnd, 
  renderCard,
  className = "",
  emptyMessage = "No items"
}) {
  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className={`flex gap-4 overflow-x-auto pb-4 ${className}`}>
        {columns.map((column, columnIndex) => (
          <motion.div
            key={column.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: columnIndex * 0.05 }}
            className="flex-1 min-w-[280px] max-w-[320px]"
          >
            {/* Column Header */}
            <div className="flex items-center gap-2 mb-3">
              <div className={`w-3 h-3 rounded-full ${column.color}`} />
              <h3 className="font-semibold text-gray-900">{column.title}</h3>
              <span className="text-sm text-gray-500 tabular-nums ml-auto">
                ({column.items?.length || 0})
              </span>
            </div>

            {/* Droppable Area */}
            <Droppable droppableId={column.id}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className={`
                    space-y-2 min-h-[200px] max-h-[calc(100vh-400px)] overflow-y-auto pr-2 
                    rounded-2xl border-2 border-dashed p-3 transition-all
                    ${snapshot.isDraggingOver 
                      ? "border-[#3b82c4] bg-[#e8f4fa]/30" 
                      : "border-gray-200 bg-gray-50/50"
                    }
                  `}
                >
                  {column.items?.length > 0 ? (
                    column.items.map((item, index) => (
                      <Draggable
                        key={item.id}
                        draggableId={item.id}
                        index={index}
                      >
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            className={`
                              group rounded-xl border bg-white transition-all
                              ${snapshot.isDragging 
                                ? "shadow-lg border-[#3b82c4] scale-105 rotate-2" 
                                : "shadow-sm border-gray-200 hover:shadow-md hover:border-gray-300"
                              }
                            `}
                          >
                            <div className="p-3">
                              {/* Drag Handle */}
                              <div
                                {...provided.dragHandleProps}
                                className="flex items-center justify-center mb-2 opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <div className="h-1 w-8 bg-gray-300 rounded-full flex items-center justify-center">
                                  <GripVertical className="w-4 h-4 text-gray-400" />
                                </div>
                              </div>

                              {/* Card Content */}
                              {renderCard(item, snapshot.isDragging)}
                            </div>
                          </div>
                        )}
                      </Draggable>
                    ))
                  ) : (
                    <div className="rounded-xl border border-dashed border-gray-300 p-6 text-center">
                      <p className="text-sm text-gray-400">{emptyMessage}</p>
                    </div>
                  )}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </motion.div>
        ))}
      </div>
    </DragDropContext>
  );
}

/**
 * Utility function to reorder items within same column
 */
export const reorderWithinColumn = (list, startIndex, endIndex) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);
  return result;
};

/**
 * Utility function to move items between columns
 */
export const moveBetweenColumns = (source, destination, sourceIndex, destIndex) => {
  const sourceClone = Array.from(source);
  const destClone = Array.from(destination);
  const [removed] = sourceClone.splice(sourceIndex, 1);
  destClone.splice(destIndex, 0, removed);

  return {
    source: sourceClone,
    destination: destClone,
  };
};