import React from "react";
import { motion } from "framer-motion";

/**
 * Unified stats grid component matching TheoryLearning design
 * 
 * @param {Object} props
 * @param {Array} props.stats - Array of stat objects with { icon, label, value, color }
 * @param {number} props.columns - Grid columns (2, 3, 4, 8)
 */
export default function StatsGrid({ stats, columns = 4 }) {
  const gridCols = {
    2: "grid-cols-2",
    3: "grid-cols-2 md:grid-cols-3",
    4: "grid-cols-2 md:grid-cols-4",
    8: "grid-cols-2 md:grid-cols-4 lg:grid-cols-8"
  };

  const colorClasses = {
    primary: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
    green: { bg: 'bg-[#eefbe7]', text: 'text-[#5cb83a]' },
    accent: { bg: 'bg-[#f3e8f4]', text: 'text-[#6c376f]' },
    yellow: { bg: 'bg-[#fdfbe8]', text: 'text-[#e7d356]' },
    red: { bg: 'bg-[#fdeeed]', text: 'text-[#e44138]' },
    blue: { bg: 'bg-[#e8f4fa]', text: 'text-[#3b82c4]' },
  };

  return (
    <div className={`grid ${gridCols[columns]} gap-4`}>
      {stats.map((stat, idx) => {
        const colors = colorClasses[stat.color] || colorClasses.primary;
        
        return (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.03 }}
            className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm"
          >
            <div className={`w-12 h-12 ${colors.bg} rounded-xl flex items-center justify-center mb-3`}>
              <stat.icon className={`w-6 h-6 ${colors.text}`} />
            </div>
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500 mb-1">
              {stat.label}
            </p>
            <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
            {stat.trend !== undefined && (
              <span className={`text-xs font-semibold mt-2 inline-block ${
                stat.trend >= 0 ? 'text-[#5cb83a]' : 'text-[#e44138]'
              }`}>
                {stat.trend >= 0 ? '+' : ''}{stat.trend}%
              </span>
            )}
          </motion.div>
        );
      })}
    </div>
  );
}