import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ArrowRight, Sparkles, Zap } from "lucide-react";

/**
 * Floating CTA - Attention-grabbing call-to-action button
 * 
 * @param {string} text - CTA text
 * @param {Function} onClick - Click handler
 * @param {ReactNode} icon - Icon component
 * @param {string} position - 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left' | 'bottom-center'
 * @param {string} variant - 'primary' | 'success' | 'accent' | 'warning'
 * @param {boolean} pulsate - Enable pulsating effect
 * @param {boolean} glow - Enable glow effect
 * @param {boolean} dismissible - Show close button
 * @param {Function} onDismiss - Dismiss handler
 */
export default function FloatingCTA({ 
  text = "Take Action",
  onClick,
  icon: Icon = ArrowRight,
  position = "bottom-right",
  variant = "primary",
  pulsate = true,
  glow = true,
  dismissible = false,
  onDismiss,
  badge,
  subtext
}) {
  const [isDismissed, setIsDismissed] = useState(false);

  const positions = {
    "bottom-right": "bottom-6 right-6",
    "bottom-left": "bottom-6 left-6",
    "top-right": "top-6 right-6",
    "top-left": "top-6 left-6",
    "bottom-center": "bottom-6 left-1/2 -translate-x-1/2"
  };

  const variants = {
    primary: {
      bg: "bg-gradient-to-r from-[#3b82c4] to-[#2563a3]",
      hoverBg: "hover:from-[#2563a3] hover:to-[#1e4f8a]",
      text: "text-white",
      glow: "shadow-[0_0_30px_rgba(59,130,196,0.4)]",
      pulse: "bg-[#a9d5ed]"
    },
    success: {
      bg: "bg-gradient-to-r from-[#81da5a] to-[#5cb83a]",
      hoverBg: "hover:from-[#5cb83a] hover:to-[#4a9c2e]",
      text: "text-white",
      glow: "shadow-[0_0_30px_rgba(129,218,90,0.4)]",
      pulse: "bg-[#d4f4c3]"
    },
    accent: {
      bg: "bg-gradient-to-r from-[#6c376f] to-[#5a2d5d]",
      hoverBg: "hover:from-[#5a2d5d] hover:to-[#4a2449]",
      text: "text-white",
      glow: "shadow-[0_0_30px_rgba(108,55,111,0.4)]",
      pulse: "bg-[#e5d0e6]"
    },
    warning: {
      bg: "bg-gradient-to-r from-[#e7d356] to-[#d4bf2e]",
      hoverBg: "hover:from-[#d4bf2e] hover:to-[#b8a525]",
      text: "text-gray-900",
      glow: "shadow-[0_0_30px_rgba(231,211,86,0.4)]",
      pulse: "bg-[#f9f3c8]"
    }
  };

  const config = variants[variant];

  const handleDismiss = () => {
    setIsDismissed(true);
    onDismiss?.();
  };

  if (isDismissed) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8, y: 20 }}
        className={`fixed ${positions[position]} z-40`}
      >
        {/* Pulsating rings */}
        {pulsate && (
          <>
            <motion.div
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.5, 0, 0.5]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className={`absolute inset-0 rounded-2xl ${config.pulse} blur-xl`}
            />
            <motion.div
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.7, 0, 0.7]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 0.3
              }}
              className={`absolute inset-0 rounded-2xl ${config.pulse} blur-lg`}
            />
          </>
        )}

        {/* Main button */}
        <motion.button
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={onClick}
          className={`
            relative flex items-center gap-3 px-6 py-4 
            ${config.bg} ${config.hoverBg} ${config.text}
            rounded-2xl font-bold shadow-2xl
            ${glow ? config.glow : ""}
            transition-all duration-300
          `}
        >
          {/* Floating icon */}
          <motion.div
            animate={{ 
              rotate: [0, 10, -10, 0],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Icon className="w-6 h-6" />
          </motion.div>

          {/* Text content */}
          <div className="text-left">
            <div className="flex items-center gap-2">
              <span className="text-base">{text}</span>
              {badge && (
                <span className="px-2 py-0.5 bg-white/20 rounded-full text-xs font-bold">
                  {badge}
                </span>
              )}
            </div>
            {subtext && (
              <p className="text-xs opacity-90 mt-0.5">{subtext}</p>
            )}
          </div>

          {/* Arrow indicator */}
          <motion.div
            animate={{ x: [0, 4, 0] }}
            transition={{ 
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <ArrowRight className="w-5 h-5" />
          </motion.div>

          {/* Shimmer effect */}
          <motion.div
            animate={{
              x: ["-100%", "200%"]
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "linear",
              repeatDelay: 1
            }}
            className="absolute inset-0 w-1/3 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12"
          />

          {/* Dismiss button */}
          {dismissible && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleDismiss();
              }}
              className="absolute -top-2 -right-2 w-6 h-6 bg-gray-900 hover:bg-gray-800 rounded-full flex items-center justify-center transition-colors"
            >
              <X className="w-3 h-3 text-white" />
            </button>
          )}
        </motion.button>
      </motion.div>
    </AnimatePresence>
  );
}

/**
 * Compact Floating Action Button (FAB)
 */
export function FloatingActionButton({ 
  onClick,
  icon: Icon = Sparkles,
  variant = "primary",
  position = "bottom-right",
  tooltip
}) {
  const [showTooltip, setShowTooltip] = useState(false);

  const variants = {
    primary: "bg-gradient-to-br from-[#3b82c4] to-[#2563a3] hover:from-[#2563a3] hover:to-[#1e4f8a]",
    success: "bg-gradient-to-br from-[#81da5a] to-[#5cb83a] hover:from-[#5cb83a] hover:to-[#4a9c2e]",
    accent: "bg-gradient-to-br from-[#6c376f] to-[#5a2d5d] hover:from-[#5a2d5d] hover:to-[#4a2449]"
  };

  const positions = {
    "bottom-right": "bottom-6 right-6",
    "bottom-left": "bottom-6 left-6"
  };

  return (
    <div className={`fixed ${positions[position]} z-40`}>
      <AnimatePresence>
        {showTooltip && tooltip && (
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 10 }}
            className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-3 py-2 bg-gray-900 text-white text-sm rounded-lg whitespace-nowrap"
          >
            {tooltip}
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.1, rotate: 5 }}
        whileTap={{ scale: 0.9 }}
        animate={{ 
          y: [0, -8, 0],
        }}
        transition={{ 
          y: { duration: 2, repeat: Infinity, ease: "easeInOut" }
        }}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        onClick={onClick}
        className={`
          w-14 h-14 rounded-full ${variants[variant]}
          flex items-center justify-center text-white
          shadow-2xl shadow-[#3b82c4]/50
          transition-all duration-300
        `}
      >
        <Icon className="w-6 h-6" />
      </motion.button>
    </div>
  );
}

/**
 * Floating Notification Badge
 */
export function FloatingBadge({ 
  count = 0,
  position = "bottom-right",
  onClick,
  variant = "primary"
}) {
  const positions = {
    "bottom-right": "bottom-6 right-6",
    "bottom-left": "bottom-6 left-6"
  };

  const variants = {
    primary: "from-[#3b82c4] to-[#2563a3]",
    danger: "from-[#e44138] to-[#c9342c]"
  };

  if (count === 0) return null;

  return (
    <motion.div
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      className={`fixed ${positions[position]} z-40`}
    >
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        animate={{
          scale: [1, 1.1, 1],
        }}
        transition={{
          scale: { duration: 1, repeat: Infinity, ease: "easeInOut" }
        }}
        onClick={onClick}
        className={`
          min-w-[56px] h-14 px-4 rounded-full
          bg-gradient-to-r ${variants[variant]}
          text-white font-bold shadow-2xl
          flex items-center justify-center
        `}
      >
        {count > 99 ? "99+" : count}
      </motion.button>
    </motion.div>
  );
}