import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Cookie, X } from "lucide-react";
import { APP_CONFIG } from "@/components/utils/config";

/**
 * Cookie Banner - GDPR compliant notification
 * Only shown when analytics are enabled
 */
export default function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Only show if analytics enabled and user hasn't accepted yet
    if (!APP_CONFIG.ENABLE_ANALYTICS) return;
    
    const accepted = localStorage.getItem("cookie_consent");
    if (!accepted) {
      // Show after 2 seconds
      const timer = setTimeout(() => setVisible(true), 2000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("cookie_consent", "true");
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem("cookie_consent", "declined");
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="fixed bottom-6 left-6 right-6 md:left-auto md:right-6 md:max-w-md z-50"
        >
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 p-5">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 bg-[#e8f4fa] rounded-xl flex items-center justify-center">
                <Cookie className="w-5 h-5 text-[#3b82c4]" />
              </div>
              
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-bold text-slate-900 mb-1">
                  We use cookies
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  We use cookies to improve your experience and analyze site usage. 
                  By clicking "Accept", you consent to our use of cookies.
                </p>
                
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleAccept}
                    className="px-4 py-2 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-lg text-xs font-semibold transition-all"
                  >
                    Accept
                  </button>
                  <button
                    onClick={handleDecline}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-all"
                  >
                    Decline
                  </button>
                </div>
              </div>
              
              <button
                onClick={handleDecline}
                className="flex-shrink-0 p-1.5 hover:bg-slate-100 rounded-lg transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}