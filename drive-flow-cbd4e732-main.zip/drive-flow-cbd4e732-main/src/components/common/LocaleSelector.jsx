import React, { useMemo, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Globe, Check } from "lucide-react";
import { getCountryOptions, getLocaleById, saveLocalePreference } from "@/components/utils/localisation";
import { changeLanguage, getCurrentLanguage, onLanguageChange, useTranslation } from "@/components/utils/i18n";

export default function LocaleSelector({ isOpen, onClose, onSelectLocale, currentLocaleId }) {
  const { t } = useTranslation();
  const countryOptions = useMemo(() => getCountryOptions(), []);
  const currentLocale = useMemo(() => getLocaleById(currentLocaleId), [currentLocaleId]);

  const handleSelect = (localeId) => {
    const locale = getLocaleById(localeId);
    
    // Update both the locale preference AND the i18n language
    saveLocalePreference(localeId);
    changeLanguage(locale.languageCode);
    
    // Call parent handler
    if (onSelectLocale) {
      onSelectLocale(localeId);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          onClick={onClose}
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-100 bg-gradient-to-r from-indigo-50 to-purple-50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center">
                <Globe className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-gray-900">
                  {t('localeSelector.title')}
                </h2>
                <p className="text-sm text-gray-500">
                  {t('localeSelector.subtitle')}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-white/80 transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* Country/Language Grid */}
          <div className="max-h-[60vh] overflow-y-auto p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {countryOptions.map((country) => (
                <div key={country.code} className="space-y-2">
                  {/* Country Header */}
                  <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
                    <span className="text-xl">{country.flag}</span>
                    <h3 className="font-semibold text-gray-800">{country.name}</h3>
                  </div>
                  
                  {/* Language Options */}
                  <div className="space-y-1">
                    {country.languages.map((lang) => {
                      const isSelected = lang.id === currentLocale.id;
                      return (
                        <button
                          key={lang.id}
                          onClick={() => handleSelect(lang.id)}
                          className={`w-full text-left px-3 py-2 text-sm rounded-lg transition-all flex items-center justify-between group ${
                            isSelected
                              ? "bg-indigo-100 text-indigo-700 font-medium"
                              : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                          }`}
                        >
                          <span>{lang.name}</span>
                          {isSelected && (
                            <Check className="w-4 h-4 text-indigo-600" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-gray-100 bg-gray-50">
            <p className="text-xs text-gray-500 text-center">
              {t('localeSelector.saved')}
            </p>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}