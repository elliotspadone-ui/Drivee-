import React, { useState, useEffect } from "react";
import Confetti from "react-confetti";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Award, Trophy, Star, Zap, CheckCircle } from "lucide-react";

/**
 * Reusable Confetti Celebration Component
 * 
 * @param {boolean} active - Whether celebration is active
 * @param {string} message - Celebration message to display
 * @param {string} type - 'default' | 'achievement' | 'milestone' | 'success'
 * @param {number} duration - Duration in ms (0 = manual close)
 * @param {Function} onComplete - Callback when celebration ends
 */
export default function ConfettiCelebration({ 
  active = false,
  message = "Congratulations!",
  type = "default",
  duration = 5000,
  onComplete,
  autoClose = true
}) {
  const [show, setShow] = useState(false);
  const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    const updateSize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight
      });
    };

    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  useEffect(() => {
    if (active) {
      setShow(true);
      
      if (autoClose && duration > 0) {
        const timer = setTimeout(() => {
          setShow(false);
          onComplete?.();
        }, duration);
        
        return () => clearTimeout(timer);
      }
    } else {
      setShow(false);
    }
  }, [active, duration, autoClose, onComplete]);

  const configs = {
    default: {
      icon: Sparkles,
      gradient: "from-[#3b82c4] to-[#a9d5ed]",
      colors: ['#3b82c4', '#a9d5ed', '#6c376f', '#81da5a', '#e7d356'],
      numberOfPieces: 200
    },
    achievement: {
      icon: Award,
      gradient: "from-[#e7d356] to-[#b8a525]",
      colors: ['#e7d356', '#b8a525', '#81da5a', '#3b82c4'],
      numberOfPieces: 300
    },
    milestone: {
      icon: Trophy,
      gradient: "from-[#81da5a] to-[#5cb83a]",
      colors: ['#81da5a', '#5cb83a', '#3b82c4', '#e7d356'],
      numberOfPieces: 250
    },
    success: {
      icon: CheckCircle,
      gradient: "from-[#5cb83a] to-[#4a9c2e]",
      colors: ['#81da5a', '#5cb83a', '#3b82c4'],
      numberOfPieces: 150
    },
    exam: {
      icon: Star,
      gradient: "from-[#6c376f] to-[#5a2d5d]",
      colors: ['#6c376f', '#3b82c4', '#81da5a', '#e7d356'],
      numberOfPieces: 400
    }
  };

  const config = configs[type] || configs.default;
  const Icon = config.icon;

  if (!show) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 pointer-events-none">
        <Confetti
          width={windowSize.width}
          height={windowSize.height}
          colors={config.colors}
          numberOfPieces={config.numberOfPieces}
          recycle={false}
          gravity={0.3}
          wind={0.01}
          tweenDuration={5000}
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: -50 }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-auto"
        >
          <div className="relative">
            {/* Glow effect */}
            <div className={`absolute inset-0 bg-gradient-to-r ${config.gradient} opacity-20 blur-3xl rounded-full scale-150`} />
            
            {/* Card */}
            <motion.div
              animate={{ 
                rotate: [0, -2, 2, -2, 0],
                scale: [1, 1.05, 1]
              }}
              transition={{ 
                duration: 0.5,
                repeat: 3,
                ease: "easeInOut"
              }}
              className="relative bg-white rounded-3xl shadow-2xl border-2 border-gray-200 p-8 max-w-md"
            >
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 200, damping: 15 }}
                  className={`w-20 h-20 bg-gradient-to-br ${config.gradient} rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg`}
                >
                  <Icon className="w-10 h-10 text-white" />
                </motion.div>

                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className={`text-3xl font-bold bg-gradient-to-r ${config.gradient} bg-clip-text text-transparent mb-2`}
                >
                  {message}
                </motion.h2>

                {duration > 0 && autoClose && (
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    className="text-sm text-gray-600"
                  >
                    Keep up the great work! 🎉
                  </motion.p>
                )}

                {(!autoClose || duration === 0) && (
                  <motion.button
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    onClick={() => {
                      setShow(false);
                      onComplete?.();
                    }}
                    className={`mt-4 px-6 py-3 bg-gradient-to-r ${config.gradient} text-white rounded-xl font-semibold hover:shadow-lg transition-all`}
                  >
                    Continue
                  </motion.button>
                )}
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

/**
 * Quick trigger function for celebrations
 */
export const celebrate = (message, type = "default") => {
  const event = new CustomEvent("drivee-celebrate", { 
    detail: { message, type } 
  });
  window.dispatchEvent(event);
};

/**
 * Global Celebration Provider Component
 * Place once in Layout or App root
 */
export function CelebrationProvider({ children }) {
  const [celebration, setCelebration] = useState({ active: false, message: "", type: "default" });

  useEffect(() => {
    const handleCelebrate = (e) => {
      setCelebration({
        active: true,
        message: e.detail.message,
        type: e.detail.type || "default"
      });
    };

    window.addEventListener("drivee-celebrate", handleCelebrate);
    return () => window.removeEventListener("drivee-celebrate", handleCelebrate);
  }, []);

  return (
    <>
      {children}
      <ConfettiCelebration
        active={celebration.active}
        message={celebration.message}
        type={celebration.type}
        onComplete={() => setCelebration({ active: false, message: "", type: "default" })}
      />
    </>
  );
}