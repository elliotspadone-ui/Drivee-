import React from 'react';
import { Drawer } from 'vaul';
import { X } from 'lucide-react';

/**
 * Bottom Drawer Component using Vaul
 * Perfect for mobile-friendly modals and action sheets
 */
export function BottomDrawer({
  open,
  onOpenChange,
  children,
  title,
  description,
  showHandle = true,
  snapPoints,
  className = ''
}) {
  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange} snapPoints={snapPoints}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50" />
        <Drawer.Content 
          className={`fixed bottom-0 left-0 right-0 bg-white rounded-t-3xl z-50 flex flex-col max-h-[96vh] ${className}`}
        >
          {showHandle && (
            <div className="mx-auto mt-4 h-1.5 w-12 flex-shrink-0 rounded-full bg-gray-300" />
          )}
          
          <div className="flex-1 overflow-y-auto p-6">
            {(title || description) && (
              <div className="mb-6">
                {title && (
                  <Drawer.Title className="text-xl font-bold text-gray-900">
                    {title}
                  </Drawer.Title>
                )}
                {description && (
                  <Drawer.Description className="text-sm text-gray-600 mt-1">
                    {description}
                  </Drawer.Description>
                )}
              </div>
            )}
            {children}
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

/**
 * Drawer Trigger Button
 */
export function DrawerTrigger({ children, asChild, ...props }) {
  return (
    <Drawer.Trigger asChild={asChild} {...props}>
      {children}
    </Drawer.Trigger>
  );
}

/**
 * Action Sheet - Mobile-friendly action menu
 */
export function ActionSheet({
  open,
  onOpenChange,
  title,
  actions = [],
  cancelLabel = 'Cancel'
}) {
  return (
    <BottomDrawer open={open} onOpenChange={onOpenChange} title={title}>
      <div className="space-y-2">
        {actions.map((action, index) => (
          <button
            key={index}
            onClick={() => {
              action.onClick?.();
              onOpenChange(false);
            }}
            disabled={action.disabled}
            className={`w-full flex items-center gap-3 px-4 py-4 rounded-xl text-left transition ${
              action.destructive
                ? 'text-[#e44138] hover:bg-[#fdeeed]'
                : 'text-gray-900 hover:bg-gray-100'
            } ${action.disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {action.icon && (
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                action.destructive ? 'bg-[#fdeeed]' : 'bg-gray-100'
              }`}>
                <action.icon className={`w-5 h-5 ${
                  action.destructive ? 'text-[#e44138]' : 'text-gray-600'
                }`} />
              </div>
            )}
            <div className="flex-1">
              <p className="font-semibold">{action.label}</p>
              {action.description && (
                <p className="text-sm text-gray-500">{action.description}</p>
              )}
            </div>
          </button>
        ))}
        
        <div className="pt-2 border-t border-gray-100">
          <button
            onClick={() => onOpenChange(false)}
            className="w-full px-4 py-4 text-center font-semibold text-gray-600 hover:bg-gray-100 rounded-xl transition"
          >
            {cancelLabel}
          </button>
        </div>
      </div>
    </BottomDrawer>
  );
}

/**
 * Confirmation Drawer
 */
export function ConfirmationDrawer({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  onConfirm,
  destructive = false,
  loading = false
}) {
  return (
    <BottomDrawer open={open} onOpenChange={onOpenChange}>
      <div className="text-center pb-4">
        <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
        {description && (
          <p className="text-gray-600">{description}</p>
        )}
      </div>
      
      <div className="flex gap-3 mt-6">
        <button
          onClick={() => onOpenChange(false)}
          className="flex-1 px-4 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
        >
          {cancelLabel}
        </button>
        <button
          onClick={() => {
            onConfirm?.();
            onOpenChange(false);
          }}
          disabled={loading}
          className={`flex-1 px-4 py-3 rounded-xl font-semibold transition flex items-center justify-center gap-2 ${
            destructive
              ? 'bg-[#e44138] hover:bg-[#c9342c] text-white'
              : 'bg-[#3b82c4] hover:bg-[#2563a3] text-white'
          } ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            confirmLabel
          )}
        </button>
      </div>
    </BottomDrawer>
  );
}

export default BottomDrawer;