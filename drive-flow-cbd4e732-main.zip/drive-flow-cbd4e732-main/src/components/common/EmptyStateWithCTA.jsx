import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import VeeMascot from "./VeeMascot";

/**
 * Reusable Empty State Component
 * Shows when no data is available with a clear CTA
 */
export default function EmptyStateWithCTA({ 
  icon: Icon,
  title, 
  description, 
  actionLabel, 
  actionLink,
  onAction,
  showVee = true,
  veeMood = "thinking"
}) {
  const ActionButton = ({ children, className }) => {
    if (actionLink) {
      return (
        <Link to={createPageUrl(actionLink)} className={className}>
          {children}
        </Link>
      );
    }
    
    if (onAction) {
      return (
        <button onClick={onAction} className={className}>
          {children}
        </button>
      );
    }
    
    return null;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl border border-slate-200 p-12 text-center"
    >
      {showVee ? (
        <div className="flex justify-center mb-6">
          <VeeMascot size="lg" mood={veeMood} animate />
        </div>
      ) : Icon ? (
        <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Icon className="w-8 h-8 text-slate-400" />
        </div>
      ) : null}
      
      <h3 className="text-xl font-bold text-slate-900 mb-2">{title}</h3>
      <p className="text-slate-600 mb-6 max-w-md mx-auto">{description}</p>
      
      {(actionLabel && (actionLink || onAction)) && (
        <ActionButton className="inline-flex items-center gap-2 px-6 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition-all shadow-sm">
          {actionLabel}
        </ActionButton>
      )}
    </motion.div>
  );
}