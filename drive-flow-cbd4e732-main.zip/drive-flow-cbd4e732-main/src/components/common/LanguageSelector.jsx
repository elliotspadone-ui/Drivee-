import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Globe, Check, ChevronDown } from "lucide-react";
import { SUPPORTED_LANGUAGES } from "@/components/utils/localisation";
import { changeLanguage, getCurrentLanguage, onLanguageChange } from "@/components/utils/i18n";

/**
 * In-app language selector for authenticated users.
 * Only changes UI language, not the operating country.
 * Now properly connected to the i18n system.
 */
export default function LanguageSelector({ 
  currentLanguage: propLanguage,
  onLanguageChange: propOnChange,
  variant = "dropdown" // "dropdown" or "inline"
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [language, setLanguage] = useState(propLanguage || getCurrentLanguage());

  // Sync with i18n system
  useEffect(() => {
    const unsubscribe = onLanguageChange((newLang) => {
      setLanguage(newLang);
    });
    return unsubscribe;
  }, []);

  // Update local state when prop changes
  useEffect(() => {
    if (propLanguage && propLanguage !== language) {
      setLanguage(propLanguage);
    }
  }, [propLanguage]);

  const currentLang = SUPPORTED_LANGUAGES.find(l => l.code === language) || SUPPORTED_LANGUAGES[0];

  const handleSelect = (langCode) => {
    // Update i18n system (this is the source of truth)
    changeLanguage(langCode);
    setLanguage(langCode);
    setIsOpen(false);
    
    // Also call parent handler if provided (for persisting to user profile)
    if (propOnChange) {
      propOnChange(langCode);
    }
  };

  if (variant === "inline") {
    return (
      <div className="flex flex-wrap gap-2">
        {SUPPORTED_LANGUAGES.map((lang) => (
          <button
            key={lang.code}
            onClick={() => handleSelect(lang.code)}
            className={`px-3 py-1.5 text-sm rounded-lg transition-all ${
              lang.code === language
                ? "bg-indigo-100 text-indigo-700 font-medium"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {lang.flag} {lang.label}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors text-sm font-medium text-gray-700"
      >
        <Globe className="w-4 h-4 text-gray-500" />
        <span>{currentLang.code.toUpperCase()}</span>
        <ChevronDown className={`w-3 h-3 text-gray-400 transition-transform ${isOpen ? "rotate-180" : ""}`} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <div 
              className="fixed inset-0 z-10" 
              onClick={() => setIsOpen(false)} 
            />
            <motion.div
              initial={{ opacity: 0, y: 8, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.95 }}
              className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden z-20"
            >
              <div className="py-1">
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => handleSelect(lang.code)}
                    className={`w-full px-4 py-2.5 text-left text-sm flex items-center justify-between transition-colors ${
                      lang.code === language
                        ? "bg-indigo-50 text-indigo-700"
                        : "text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span>{lang.flag}</span>
                      <span>{lang.label}</span>
                    </span>
                    {lang.code === language && (
                      <Check className="w-4 h-4 text-indigo-600" />
                    )}
                  </button>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}