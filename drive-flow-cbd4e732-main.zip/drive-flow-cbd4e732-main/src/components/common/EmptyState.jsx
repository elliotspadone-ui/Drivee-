import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import VeeMascot from "./VeeMascot";

/**
 * Reusable empty state component
 * Prevents "no data found" dead ends with clear CTAs
 */
export default function EmptyState({
  icon: Icon,
  title,
  description,
  actionLabel,
  actionTo,
  actionOnClick,
  secondaryActionLabel,
  secondaryActionTo,
  showVee = false,
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-16 px-6 text-center"
    >
      {showVee ? (
        <VeeMascot size="lg" mood="thinking" animate={true} />
      ) : Icon ? (
        <div className="w-16 h-16 bg-zinc-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Icon className="w-8 h-8 text-zinc-400" />
        </div>
      ) : null}

      <h3 className="text-xl font-bold text-zinc-900 mb-2">{title}</h3>
      <p className="text-zinc-600 mb-8 max-w-md">{description}</p>

      <div className="flex gap-3 flex-wrap justify-center">
        {actionTo ? (
          <Link
            to={createPageUrl(actionTo)}
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition shadow-lg"
          >
            {actionLabel}
          </Link>
        ) : actionOnClick ? (
          <button
            onClick={actionOnClick}
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition shadow-lg"
          >
            {actionLabel}
          </button>
        ) : null}

        {secondaryActionTo && (
          <Link
            to={createPageUrl(secondaryActionTo)}
            className="inline-flex items-center gap-2 px-6 py-3 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 rounded-xl font-semibold transition"
          >
            {secondaryActionLabel}
          </Link>
        )}
      </div>
    </motion.div>
  );
}