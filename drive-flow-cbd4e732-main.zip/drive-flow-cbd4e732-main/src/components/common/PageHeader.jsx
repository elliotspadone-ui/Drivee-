import React from "react";
import { motion } from "framer-motion";
import { ArrowLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

/**
 * Unified page header component matching TheoryLearning design
 * 
 * @param {Object} props
 * @param {string} props.title - Main page title
 * @param {string} props.description - Supporting description
 * @param {string} props.gradient - Gradient type: 'admin' | 'instructor' | 'student'
 * @param {string} props.backLink - Optional back button link
 * @param {string} props.backLabel - Optional back button label
 * @param {React.ReactNode} props.actions - Action buttons (right side)
 * @param {React.ReactNode} props.children - Additional content below header
 */
export default function PageHeader({ 
  title, 
  description, 
  gradient = "admin",
  backLink,
  backLabel = "Back",
  actions,
  children 
}) {
  const gradients = {
    admin: "from-[#3b82c4] to-[#a9d5ed]",
    instructor: "from-[#3b82c4] to-[#6c376f]",
    student: "from-[#81da5a] to-[#5cb83a]"
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4 mb-6"
    >
      {backLink && (
        <Link
          to={createPageUrl(backLink)}
          className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          {backLabel}
        </Link>
      )}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className={`text-3xl md:text-4xl font-bold bg-gradient-to-r ${gradients[gradient]} bg-clip-text text-transparent mb-1`}>
            {title}
          </h1>
          {description && (
            <p className="text-gray-600">{description}</p>
          )}
        </div>
        
        {actions && (
          <div className="flex items-center gap-3">
            {actions}
          </div>
        )}
      </div>

      {children}
    </motion.div>
  );
}