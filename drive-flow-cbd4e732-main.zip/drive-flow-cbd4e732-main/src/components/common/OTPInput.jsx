import React from 'react';
import { OTPInput, SlotProps } from 'input-otp';
import { motion } from 'framer-motion';

/**
 * OTP Input Component using input-otp
 * For verification codes, 2FA, etc.
 */

function Slot({ char, isActive, hasFakeCaret }) {
  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className={`relative w-12 h-14 text-2xl font-bold flex items-center justify-center 
        border-2 rounded-xl transition-all duration-200
        ${isActive 
          ? 'border-[#3b82c4] bg-[#e8f4fa] ring-2 ring-[#a9d5ed]' 
          : char 
            ? 'border-[#81da5a] bg-[#eefbe7]' 
            : 'border-gray-300 bg-gray-50'
        }`}
    >
      {char && <span className="text-gray-900">{char}</span>}
      {hasFakeCaret && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-0.5 h-6 bg-[#3b82c4] animate-pulse" />
        </div>
      )}
    </motion.div>
  );
}

export function VerificationCodeInput({
  value,
  onChange,
  maxLength = 6,
  onComplete,
  disabled = false,
  autoFocus = true,
  className = ''
}) {
  return (
    <div className={className}>
      <OTPInput
        value={value}
        onChange={onChange}
        maxLength={maxLength}
        disabled={disabled}
        autoFocus={autoFocus}
        onComplete={onComplete}
        containerClassName="flex gap-2 justify-center"
        render={({ slots }) => (
          <div className="flex gap-2">
            {slots.map((slot, idx) => (
              <Slot key={idx} {...slot} />
            ))}
          </div>
        )}
      />
    </div>
  );
}

/**
 * PIN Input - For 4-digit PINs
 */
export function PINInput({
  value,
  onChange,
  onComplete,
  disabled = false,
  masked = true,
  className = ''
}) {
  return (
    <div className={className}>
      <OTPInput
        value={value}
        onChange={onChange}
        maxLength={4}
        disabled={disabled}
        onComplete={onComplete}
        containerClassName="flex gap-3 justify-center"
        render={({ slots }) => (
          <div className="flex gap-3">
            {slots.map((slot, idx) => (
              <motion.div
                key={idx}
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                className={`w-14 h-16 text-3xl font-bold flex items-center justify-center 
                  border-2 rounded-2xl transition-all duration-200
                  ${slot.isActive 
                    ? 'border-[#3b82c4] bg-[#e8f4fa] shadow-lg' 
                    : slot.char 
                      ? 'border-gray-400 bg-white' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
              >
                {slot.char && (
                  <span className="text-gray-900">
                    {masked ? '•' : slot.char}
                  </span>
                )}
                {slot.hasFakeCaret && (
                  <div className="w-0.5 h-8 bg-[#3b82c4] animate-pulse" />
                )}
              </motion.div>
            ))}
          </div>
        )}
      />
    </div>
  );
}

/**
 * Compact OTP Input
 */
export function CompactOTPInput({
  value,
  onChange,
  maxLength = 6,
  onComplete,
  disabled = false,
  className = ''
}) {
  return (
    <div className={className}>
      <OTPInput
        value={value}
        onChange={onChange}
        maxLength={maxLength}
        disabled={disabled}
        onComplete={onComplete}
        containerClassName="flex gap-1 justify-center"
        render={({ slots }) => (
          <div className="flex">
            {slots.map((slot, idx) => (
              <div
                key={idx}
                className={`w-10 h-12 text-xl font-semibold flex items-center justify-center 
                  border-y-2 border-r-2 first:border-l-2 first:rounded-l-lg last:rounded-r-lg
                  transition-all duration-150
                  ${slot.isActive 
                    ? 'border-[#3b82c4] bg-[#e8f4fa] z-10' 
                    : slot.char 
                      ? 'border-gray-300 bg-white' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
              >
                {slot.char && <span className="text-gray-900">{slot.char}</span>}
                {slot.hasFakeCaret && (
                  <div className="w-0.5 h-5 bg-[#3b82c4] animate-pulse" />
                )}
              </div>
            ))}
          </div>
        )}
      />
    </div>
  );
}

/**
 * Split OTP Input (XXX - XXX format)
 */
export function SplitOTPInput({
  value,
  onChange,
  onComplete,
  disabled = false,
  className = ''
}) {
  return (
    <div className={className}>
      <OTPInput
        value={value}
        onChange={onChange}
        maxLength={6}
        disabled={disabled}
        onComplete={onComplete}
        containerClassName="flex gap-2 justify-center items-center"
        render={({ slots }) => (
          <div className="flex items-center gap-2">
            <div className="flex gap-1">
              {slots.slice(0, 3).map((slot, idx) => (
                <Slot key={idx} {...slot} />
              ))}
            </div>
            <span className="text-2xl text-gray-400 font-bold">-</span>
            <div className="flex gap-1">
              {slots.slice(3).map((slot, idx) => (
                <Slot key={idx + 3} {...slot} />
              ))}
            </div>
          </div>
        )}
      />
    </div>
  );
}

export default VerificationCodeInput;