import React from "react";
import { motion } from "framer-motion";
import { AlertTriangle, RefreshCw, HelpCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

/**
 * Query Error UI Component
 * Shows when a react-query fetch fails
 */
function QueryErrorBoundary({ 
  error, 
  onRetry, 
  title = "Something went wrong",
  showSupport = true 
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-md mx-auto px-4 py-12 text-center"
    >
      <div className="bg-white rounded-2xl border-2 border-rose-200 p-8 shadow-lg">
        <div className="w-16 h-16 bg-rose-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="w-8 h-8 text-rose-600" />
        </div>
        
        <h3 className="text-xl font-bold text-slate-900 mb-2">{title}</h3>
        
        <p className="text-sm text-slate-600 mb-6">
          {error?.message || "We couldn't load the data. Please try again."}
        </p>
        
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          {onRetry && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onRetry}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl font-semibold transition-all shadow-sm"
            >
              <RefreshCw className="w-4 h-4" />
              Try Again
            </motion.button>
          )}
          
          {showSupport && (
            <Link
              to={createPageUrl("Support")}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition-all"
            >
              <HelpCircle className="w-4 h-4" />
              Contact Support
            </Link>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export default QueryErrorBoundary;