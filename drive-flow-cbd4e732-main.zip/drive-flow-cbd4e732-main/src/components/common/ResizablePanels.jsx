import React from 'react';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { GripVertical, GripHorizontal } from 'lucide-react';

/**
 * Resizable Panel Layout Component
 * Uses react-resizable-panels for smooth, accessible panel resizing
 */

/**
 * Horizontal Resizable Layout (side by side)
 */
export function HorizontalResizable({
  leftPanel,
  rightPanel,
  defaultLeftSize = 50,
  minLeftSize = 20,
  minRightSize = 20,
  className = ''
}) {
  return (
    <PanelGroup direction="horizontal" className={`h-full ${className}`}>
      <Panel defaultSize={defaultLeftSize} minSize={minLeftSize}>
        <div className="h-full overflow-auto">
          {leftPanel}
        </div>
      </Panel>
      
      <PanelResizeHandle className="w-2 bg-gray-100 hover:bg-[#a9d5ed] transition-colors flex items-center justify-center group">
        <div className="w-1 h-8 bg-gray-300 group-hover:bg-[#3b82c4] rounded-full transition-colors" />
      </PanelResizeHandle>
      
      <Panel minSize={minRightSize}>
        <div className="h-full overflow-auto">
          {rightPanel}
        </div>
      </Panel>
    </PanelGroup>
  );
}

/**
 * Vertical Resizable Layout (stacked)
 */
export function VerticalResizable({
  topPanel,
  bottomPanel,
  defaultTopSize = 50,
  minTopSize = 20,
  minBottomSize = 20,
  className = ''
}) {
  return (
    <PanelGroup direction="vertical" className={`h-full ${className}`}>
      <Panel defaultSize={defaultTopSize} minSize={minTopSize}>
        <div className="h-full overflow-auto">
          {topPanel}
        </div>
      </Panel>
      
      <PanelResizeHandle className="h-2 bg-gray-100 hover:bg-[#a9d5ed] transition-colors flex items-center justify-center group">
        <div className="w-8 h-1 bg-gray-300 group-hover:bg-[#3b82c4] rounded-full transition-colors" />
      </PanelResizeHandle>
      
      <Panel minSize={minBottomSize}>
        <div className="h-full overflow-auto">
          {bottomPanel}
        </div>
      </Panel>
    </PanelGroup>
  );
}

/**
 * Three Panel Layout (sidebar + main + detail)
 */
export function ThreePanelLayout({
  leftPanel,
  centerPanel,
  rightPanel,
  defaultLeftSize = 20,
  defaultCenterSize = 50,
  minLeftSize = 15,
  minCenterSize = 30,
  minRightSize = 15,
  collapsible = true,
  className = ''
}) {
  return (
    <PanelGroup direction="horizontal" className={`h-full ${className}`}>
      <Panel 
        defaultSize={defaultLeftSize} 
        minSize={minLeftSize}
        collapsible={collapsible}
      >
        <div className="h-full overflow-auto border-r border-gray-200">
          {leftPanel}
        </div>
      </Panel>
      
      <PanelResizeHandle className="w-1 bg-gray-200 hover:bg-[#3b82c4] transition-colors" />
      
      <Panel defaultSize={defaultCenterSize} minSize={minCenterSize}>
        <div className="h-full overflow-auto">
          {centerPanel}
        </div>
      </Panel>
      
      <PanelResizeHandle className="w-1 bg-gray-200 hover:bg-[#3b82c4] transition-colors" />
      
      <Panel 
        minSize={minRightSize}
        collapsible={collapsible}
      >
        <div className="h-full overflow-auto border-l border-gray-200">
          {rightPanel}
        </div>
      </Panel>
    </PanelGroup>
  );
}

/**
 * Dashboard Layout with collapsible sidebar
 */
export function DashboardLayout({
  sidebar,
  main,
  detail,
  showDetail = false,
  sidebarSize = 250,
  detailSize = 350,
  className = ''
}) {
  return (
    <PanelGroup direction="horizontal" className={`h-full ${className}`}>
      <Panel 
        defaultSize={20} 
        minSize={15} 
        maxSize={30}
        collapsible
      >
        <div className="h-full bg-white border-r border-gray-200 overflow-y-auto">
          {sidebar}
        </div>
      </Panel>
      
      <PanelResizeHandle className="w-1 bg-gray-200 hover:bg-[#3b82c4] transition-colors cursor-col-resize" />
      
      <Panel minSize={40}>
        <div className="h-full overflow-auto bg-gray-50">
          {main}
        </div>
      </Panel>
      
      {showDetail && (
        <>
          <PanelResizeHandle className="w-1 bg-gray-200 hover:bg-[#3b82c4] transition-colors cursor-col-resize" />
          <Panel 
            defaultSize={25} 
            minSize={20} 
            maxSize={40}
            collapsible
          >
            <div className="h-full bg-white border-l border-gray-200 overflow-y-auto">
              {detail}
            </div>
          </Panel>
        </>
      )}
    </PanelGroup>
  );
}

/**
 * Code Editor Layout (file tree + editor + preview)
 */
export function EditorLayout({
  fileTree,
  editor,
  preview,
  showPreview = true,
  className = ''
}) {
  return (
    <PanelGroup direction="horizontal" className={`h-full ${className}`}>
      <Panel defaultSize={18} minSize={12} maxSize={30} collapsible>
        <div className="h-full bg-gray-900 text-gray-100 overflow-y-auto">
          {fileTree}
        </div>
      </Panel>
      
      <PanelResizeHandle className="w-1 bg-gray-700 hover:bg-[#3b82c4] transition-colors" />
      
      <Panel minSize={30}>
        <PanelGroup direction="vertical">
          <Panel defaultSize={showPreview ? 60 : 100} minSize={30}>
            <div className="h-full overflow-auto">
              {editor}
            </div>
          </Panel>
          
          {showPreview && (
            <>
              <PanelResizeHandle className="h-1 bg-gray-200 hover:bg-[#3b82c4] transition-colors" />
              <Panel minSize={20} collapsible>
                <div className="h-full overflow-auto bg-white border-t border-gray-200">
                  {preview}
                </div>
              </Panel>
            </>
          )}
        </PanelGroup>
      </Panel>
    </PanelGroup>
  );
}

// Export individual components for custom layouts
export { Panel, PanelGroup, PanelResizeHandle };

export default HorizontalResizable;