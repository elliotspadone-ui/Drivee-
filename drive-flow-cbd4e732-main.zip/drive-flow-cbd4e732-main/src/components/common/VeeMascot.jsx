import React from "react";
import { motion } from "framer-motion";

// Vee mascot image URL (transparent background version)
const VEE_IMAGE = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691b056345d5788acbd4e732/e2dd989dc_53B3DFF2-B1BA-415F-B12B-F728D8B742EC-Photoroom.png";

/**
 * Vee - Drivee's friendly mascot
 * A purple character with a driving instructor cap and blue cape
 * 
 * @param {string} size - 'xs' | 'sm' | 'md' | 'lg' | 'xl'
 * @param {string} mood - 'default' | 'wave' | 'thinking' | 'celebrate'
 * @param {string} message - Optional speech bubble message
 * @param {boolean} animate - Whether to animate Vee
 * @param {number} animationDuration - How long to animate in ms (0 = infinite)
 * @param {string} className - Additional classes
 */
export default function VeeMascot({ 
  size = "md", 
  mood = "default",
  message,
  animate = true,
  animationDuration = 3000,
  className = "",
  messagePosition = "right"
}) {
  // Removed useState/useEffect to prevent hook ordering issues when component is conditionally rendered
  // Animation now always runs if animate prop is true
  const shouldAnimate = animate;

  const sizes = {
    xs: "w-8 h-8",
    sm: "w-12 h-12",
    md: "w-20 h-20",
    lg: "w-32 h-32",
    xl: "w-48 h-48",
  };

  const animations = {
    default: {
      y: [0, -4, 0],
      transition: { duration: 2, repeat: Infinity, ease: "easeInOut" }
    },
    wave: {
      rotate: [-5, 5, -5],
      transition: { duration: 0.5, repeat: Infinity, ease: "easeInOut" }
    },
    thinking: {
      scale: [1, 1.02, 1],
      transition: { duration: 1.5, repeat: Infinity, ease: "easeInOut" }
    },
    celebrate: {
      y: [0, -10, 0],
      rotate: [-3, 3, -3],
      transition: { duration: 0.6, repeat: Infinity, ease: "easeInOut" }
    }
  };

  return (
    <div className={`flex items-center gap-3 ${messagePosition === "left" ? "flex-row-reverse" : ""} ${className}`}>
      <motion.div
        className={`relative flex-shrink-0 ${sizes[size]}`}
        animate={shouldAnimate ? animations[mood] : {}}
      >
        <img 
          src={VEE_IMAGE} 
          alt="Vee - Drivee Mascot" 
          className="w-full h-full object-contain drop-shadow-lg object-top"
        />
      </motion.div>

      {message && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9, x: messagePosition === "left" ? 10 : -10 }}
          animate={{ opacity: 1, scale: 1, x: 0 }}
          className={`relative bg-white rounded-2xl px-4 py-3 shadow-lg border border-purple-100 max-w-xs`}
        >
          <div 
            className={`absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white border-purple-100 rotate-45 ${
              messagePosition === "left" 
                ? "right-[-6px] border-r border-t" 
                : "left-[-6px] border-l border-b"
            }`}
          />
          <p className="text-sm text-gray-700 relative z-10">{message}</p>
        </motion.div>
      )}
    </div>
  );
}

// Pre-configured Vee states for common use cases
export function VeeEmptyState({ title, description, action, actionLabel }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
      <VeeMascot size="lg" mood="thinking" />
      <h3 className="mt-6 text-lg font-semibold text-gray-900">{title}</h3>
      <p className="mt-2 text-sm text-gray-600 max-w-sm">{description}</p>
      {action && (
        <button
          onClick={action}
          className="mt-6 px-5 py-2.5 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}

export function VeeSuccess({ message = "Great job!" }) {
  return (
    <div className="flex flex-col items-center py-8">
      <VeeMascot size="lg" mood="celebrate" />
      <motion.p 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-4 text-lg font-semibold text-gray-900"
      >
        {message}
      </motion.p>
    </div>
  );
}

export function VeeTip({ tip, className = "" }) {
  return (
    <div className={`flex items-start gap-3 p-4 bg-purple-50 rounded-xl border border-purple-100 ${className}`}>
      <VeeMascot size="sm" animate={false} />
      <div>
        <p className="text-xs font-semibold text-purple-700 uppercase tracking-wide mb-1">Vee's Tip</p>
        <p className="text-sm text-purple-900">{tip}</p>
      </div>
    </div>
  );
}

export function VeeOnboarding({ step, totalSteps, title, description }) {
  return (
    <div className="flex items-start gap-4">
      <VeeMascot size="md" mood="wave" />
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs font-bold text-indigo-600 bg-indigo-100 px-2 py-0.5 rounded-full">
            Step {step} of {totalSteps}
          </span>
        </div>
        <h3 className="text-lg font-bold text-gray-900">{title}</h3>
        <p className="text-sm text-gray-600 mt-1">{description}</p>
      </div>
    </div>
  );
}

export function VeeWelcome({ userName }) {
  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  return (
    <VeeMascot 
      size="md" 
      mood="wave" 
      message={`${greeting()}${userName ? `, ${userName}` : ""}! Ready to get started?`}
    />
  );
}

export function VeeLoading({ message = "Loading..." }) {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
      >
        <VeeMascot size="lg" animate={false} />
      </motion.div>
      <p className="mt-4 text-sm text-gray-600">{message}</p>
    </div>
  );
}