import { useEffect } from "react";

/**
 * SEO Head Component
 * Updates page meta tags for better SEO and social sharing
 */
export default function SEOHead({ 
  title = "DRIVEE - Find Your Perfect Driving School",
  description = "Compare driving schools, read reviews, and book lessons online. Trusted by 25,000+ students across Europe.",
  keywords = "driving school, driving lessons, book driving lessons, driving instructor, learn to drive",
  ogImage = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691b056345d5788acbd4e732/8bd9d7a47_ChatGPTImageNov29202511_47_17PM.png",
  ogType = "website",
  canonical
}) {
  useEffect(() => {
    // Update document title
    document.title = title;

    // Helper to update meta tag
    const updateMeta = (selector, attribute, content) => {
      if (!content) return;
      
      let element = document.querySelector(selector);
      if (!element) {
        element = document.createElement("meta");
        const [attr, value] = selector.replace(/[\[\]]/g, "").split("=");
        element.setAttribute(attr, value.replace(/"/g, ""));
        document.head.appendChild(element);
      }
      element.setAttribute(attribute, content);
    };

    // Standard meta tags
    updateMeta('[name="description"]', "content", description);
    updateMeta('[name="keywords"]', "content", keywords);

    // Open Graph tags
    updateMeta('[property="og:title"]', "content", title);
    updateMeta('[property="og:description"]', "content", description);
    updateMeta('[property="og:image"]', "content", ogImage);
    updateMeta('[property="og:type"]', "content", ogType);
    if (canonical) {
      updateMeta('[property="og:url"]', "content", canonical);
    }

    // Twitter Card tags
    updateMeta('[name="twitter:card"]', "content", "summary_large_image");
    updateMeta('[name="twitter:title"]', "content", title);
    updateMeta('[name="twitter:description"]', "content", description);
    updateMeta('[name="twitter:image"]', "content", ogImage);

    // Canonical link
    if (canonical) {
      let link = document.querySelector('link[rel="canonical"]');
      if (!link) {
        link = document.createElement("link");
        link.setAttribute("rel", "canonical");
        document.head.appendChild(link);
      }
      link.setAttribute("href", canonical);
    }
  }, [title, description, keywords, ogImage, ogType, canonical]);

  return null;
}