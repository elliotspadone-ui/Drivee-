import React from "react";
import { motion } from "framer-motion";

/**
 * Morphing Shapes - Abstract animated background
 * 
 * @param {string} variant - 'default' | 'subtle' | 'vibrant' | 'dark'
 * @param {number} count - Number of shapes (default: 4)
 * @param {boolean} blur - Apply blur effect
 * @param {string} className - Additional classes
 */
export default function MorphingShapes({ 
  variant = "default",
  count = 4,
  blur = true,
  className = "",
  opacity = 0.3
}) {
  const variants = {
    default: [
      "bg-[#a9d5ed]",
      "bg-[#3b82c4]",
      "bg-[#81da5a]",
      "bg-[#6c376f]",
      "bg-[#e7d356]"
    ],
    subtle: [
      "bg-[#e8f4fa]",
      "bg-[#d4eaf5]",
      "bg-[#eefbe7]",
      "bg-[#f3e8f4]",
      "bg-[#fdfbe8]"
    ],
    vibrant: [
      "bg-[#3b82c4]",
      "bg-[#81da5a]",
      "bg-[#6c376f]",
      "bg-[#e44138]",
      "bg-[#e7d356]"
    ],
    dark: [
      "bg-[#2563a3]",
      "bg-[#5a2d5d]",
      "bg-[#1e4f8a]",
      "bg-[#4a9c2e]",
      "bg-[#9a8520]"
    ],
    ocean: [
      "bg-[#a9d5ed]",
      "bg-[#3b82c4]",
      "bg-[#2563a3]",
      "bg-[#1e4f8a]",
      "bg-[#d4eaf5]"
    ],
    nature: [
      "bg-[#81da5a]",
      "bg-[#5cb83a]",
      "bg-[#4a9c2e]",
      "bg-[#a9d5ed]",
      "bg-[#e7d356]"
    ]
  };

  const colors = variants[variant] || variants.default;

  const shapes = Array.from({ length: Math.min(count, 6) }, (_, i) => ({
    id: i,
    color: colors[i % colors.length],
    size: 200 + Math.random() * 300,
    initialX: Math.random() * 100,
    initialY: Math.random() * 100,
    duration: 20 + Math.random() * 15
  }));

  const pathVariants = [
    // Blob 1 - organic blob
    {
      d: [
        "M60,30 Q90,50 70,80 Q50,100 30,80 Q10,60 30,30 Q50,10 60,30",
        "M50,20 Q80,30 85,60 Q80,90 50,85 Q20,80 15,50 Q20,20 50,20",
        "M55,25 Q85,45 75,75 Q55,95 35,75 Q15,55 35,35 Q55,15 55,25",
        "M60,30 Q90,50 70,80 Q50,100 30,80 Q10,60 30,30 Q50,10 60,30"
      ]
    },
    // Blob 2 - rounded square
    {
      d: [
        "M30,20 Q50,10 70,20 Q90,40 80,60 Q70,90 50,85 Q20,80 20,50 Q15,30 30,20",
        "M40,15 Q60,5 80,25 Q95,50 85,70 Q65,95 40,90 Q15,85 10,55 Q10,25 40,15",
        "M35,25 Q55,15 75,25 Q90,45 80,65 Q65,90 45,85 Q20,80 15,55 Q15,30 35,25",
        "M30,20 Q50,10 70,20 Q90,40 80,60 Q70,90 50,85 Q20,80 20,50 Q15,30 30,20"
      ]
    },
    // Blob 3 - amoeba
    {
      d: [
        "M50,10 Q80,20 90,50 Q85,80 60,90 Q30,85 15,60 Q10,30 50,10",
        "M45,15 Q75,15 85,45 Q90,75 55,90 Q25,90 10,55 Q15,25 45,15",
        "M55,12 Q82,25 88,55 Q82,85 55,92 Q28,88 12,58 Q18,28 55,12",
        "M50,10 Q80,20 90,50 Q85,80 60,90 Q30,85 15,60 Q10,30 50,10"
      ]
    },
    // Blob 4 - flower-like
    {
      d: [
        "M50,5 Q70,25 95,50 Q70,75 50,95 Q30,75 5,50 Q30,25 50,5",
        "M50,10 Q75,20 90,50 Q75,80 50,90 Q25,80 10,50 Q25,20 50,10",
        "M50,8 Q72,22 92,50 Q72,78 50,92 Q28,78 8,50 Q28,22 50,8",
        "M50,5 Q70,25 95,50 Q70,75 50,95 Q30,75 5,50 Q30,25 50,5"
      ]
    },
    // Blob 5 - cloud
    {
      d: [
        "M25,50 Q10,30 30,20 Q50,5 70,20 Q90,30 85,55 Q90,80 60,85 Q30,90 25,50",
        "M30,55 Q15,35 35,25 Q55,10 75,25 Q92,38 88,60 Q92,85 65,88 Q35,92 30,55",
        "M28,52 Q12,32 32,22 Q52,8 72,22 Q91,34 86,58 Q91,82 62,86 Q32,90 28,52",
        "M25,50 Q10,30 30,20 Q50,5 70,20 Q90,30 85,55 Q90,80 60,85 Q30,90 25,50"
      ]
    },
    // Blob 6 - wave
    {
      d: [
        "M10,50 Q25,30 50,40 Q75,50 90,30 Q95,60 90,80 Q60,90 40,80 Q20,70 10,50",
        "M15,55 Q30,35 55,45 Q80,55 92,35 Q97,65 92,82 Q62,92 42,82 Q22,72 15,55",
        "M12,52 Q27,32 52,42 Q77,52 90,32 Q96,62 90,80 Q60,90 40,80 Q20,70 12,52",
        "M10,50 Q25,30 50,40 Q75,50 90,30 Q95,60 90,80 Q60,90 40,80 Q20,70 10,50"
      ]
    }
  ];

  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}>
      {shapes.map((shape, index) => (
        <motion.div
          key={shape.id}
          className="absolute"
          style={{
            left: `${shape.initialX}%`,
            top: `${shape.initialY}%`,
            width: shape.size,
            height: shape.size,
            transform: "translate(-50%, -50%)"
          }}
          animate={{
            x: [0, 50, -30, 20, 0],
            y: [0, -40, 30, -20, 0],
            rotate: [0, 90, 180, 270, 360],
            scale: [1, 1.2, 0.9, 1.1, 1]
          }}
          transition={{
            duration: shape.duration,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <svg
            viewBox="0 0 100 100"
            className={`w-full h-full ${blur ? "blur-3xl" : ""}`}
            style={{ opacity }}
          >
            <motion.path
              className={shape.color}
              fill="currentColor"
              animate={{
                d: pathVariants[index % pathVariants.length].d
              }}
              transition={{
                duration: shape.duration * 0.8,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </svg>
        </motion.div>
      ))}
    </div>
  );
}

/**
 * Gradient Orbs - Floating gradient circles
 */
export function GradientOrbs({ 
  count = 3,
  blur = true,
  opacity = 0.4
}) {
  const gradients = [
    "from-[#3b82c4] to-[#a9d5ed]",
    "from-[#81da5a] to-[#5cb83a]",
    "from-[#6c376f] to-[#f3e8f4]",
    "from-[#e7d356] to-[#fdfbe8]",
    "from-[#e44138] to-[#fdeeed]"
  ];

  const orbs = Array.from({ length: count }, (_, i) => ({
    id: i,
    gradient: gradients[i % gradients.length],
    size: 150 + Math.random() * 250,
    x: Math.random() * 100,
    y: Math.random() * 100,
    duration: 15 + Math.random() * 10
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {orbs.map((orb) => (
        <motion.div
          key={orb.id}
          className={`
            absolute rounded-full
            bg-gradient-to-br ${orb.gradient}
            ${blur ? "blur-3xl" : ""}
          `}
          style={{
            width: orb.size,
            height: orb.size,
            left: `${orb.x}%`,
            top: `${orb.y}%`,
            opacity,
            transform: "translate(-50%, -50%)"
          }}
          animate={{
            x: [0, 100, -50, 75, 0],
            y: [0, -75, 50, -25, 0],
            scale: [1, 1.3, 0.8, 1.1, 1]
          }}
          transition={{
            duration: orb.duration,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
}

/**
 * Animated Mesh Gradient Background
 */
export function MeshGradient({ variant = "default" }) {
  const variants = {
    default: {
      color1: "#a9d5ed",
      color2: "#3b82c4",
      color3: "#81da5a",
      color4: "#6c376f"
    },
    ocean: {
      color1: "#a9d5ed",
      color2: "#3b82c4",
      color3: "#2563a3",
      color4: "#1e4f8a"
    },
    sunset: {
      color1: "#e44138",
      color2: "#e7d356",
      color3: "#6c376f",
      color4: "#3b82c4"
    },
    nature: {
      color1: "#81da5a",
      color2: "#5cb83a",
      color3: "#a9d5ed",
      color4: "#e7d356"
    }
  };

  const colors = variants[variant] || variants.default;

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <motion.div
        className="absolute inset-0"
        animate={{
          background: [
            `radial-gradient(at 0% 0%, ${colors.color1}40 0px, transparent 50%),
             radial-gradient(at 100% 0%, ${colors.color2}40 0px, transparent 50%),
             radial-gradient(at 100% 100%, ${colors.color3}40 0px, transparent 50%),
             radial-gradient(at 0% 100%, ${colors.color4}40 0px, transparent 50%)`,
            `radial-gradient(at 100% 0%, ${colors.color1}40 0px, transparent 50%),
             radial-gradient(at 100% 100%, ${colors.color2}40 0px, transparent 50%),
             radial-gradient(at 0% 100%, ${colors.color3}40 0px, transparent 50%),
             radial-gradient(at 0% 0%, ${colors.color4}40 0px, transparent 50%)`,
            `radial-gradient(at 100% 100%, ${colors.color1}40 0px, transparent 50%),
             radial-gradient(at 0% 100%, ${colors.color2}40 0px, transparent 50%),
             radial-gradient(at 0% 0%, ${colors.color3}40 0px, transparent 50%),
             radial-gradient(at 100% 0%, ${colors.color4}40 0px, transparent 50%)`,
            `radial-gradient(at 0% 100%, ${colors.color1}40 0px, transparent 50%),
             radial-gradient(at 0% 0%, ${colors.color2}40 0px, transparent 50%),
             radial-gradient(at 100% 0%, ${colors.color3}40 0px, transparent 50%),
             radial-gradient(at 100% 100%, ${colors.color4}40 0px, transparent 50%)`,
            `radial-gradient(at 0% 0%, ${colors.color1}40 0px, transparent 50%),
             radial-gradient(at 100% 0%, ${colors.color2}40 0px, transparent 50%),
             radial-gradient(at 100% 100%, ${colors.color3}40 0px, transparent 50%),
             radial-gradient(at 0% 100%, ${colors.color4}40 0px, transparent 50%)`
          ]
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear"
        }}
      />
    </div>
  );
}

/**
 * Floating Particles
 */
export function FloatingParticles({ count = 20, color = "primary" }) {
  const colors = {
    primary: "bg-[#3b82c4]",
    success: "bg-[#81da5a]",
    accent: "bg-[#6c376f]",
    white: "bg-white"
  };

  const particles = Array.from({ length: count }, (_, i) => ({
    id: i,
    size: 2 + Math.random() * 4,
    x: Math.random() * 100,
    y: Math.random() * 100,
    duration: 10 + Math.random() * 20
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className={`absolute rounded-full ${colors[color]} opacity-40`}
          style={{
            width: particle.size,
            height: particle.size,
            left: `${particle.x}%`,
            top: `${particle.y}%`
          }}
          animate={{
            y: [0, -200],
            x: [0, Math.random() * 50 - 25],
            opacity: [0, 0.6, 0]
          }}
          transition={{
            duration: particle.duration,
            repeat: Infinity,
            ease: "linear",
            delay: Math.random() * particle.duration
          }}
        />
      ))}
    </div>
  );
}