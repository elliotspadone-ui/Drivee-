import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Globe, X } from "lucide-react";

export default function LocaleSuggestionBanner({ 
  suggestedLocale, 
  currentLocale, 
  onAccept, 
  onDismiss,
  isVisible 
}) {
  if (!isVisible || !suggestedLocale || suggestedLocale.id === currentLocale.id) {
    return null;
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -50 }}
        className="fixed top-16 left-0 right-0 z-40 flex justify-center px-4"
      >
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-4 max-w-xl w-full flex items-center gap-4">
          <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
            <Globe className="w-5 h-5 text-indigo-600" />
          </div>
          
          <div className="flex-1">
            <p className="text-sm text-gray-800">
              It looks like you prefer{" "}
              <strong>{suggestedLocale.labelLanguage} ({suggestedLocale.labelCountry})</strong>.
              <br />
              <span className="text-gray-500">
                Switch to {suggestedLocale.labelLanguage} and {suggestedLocale.currencySymbol}?
              </span>
            </p>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={onAccept}
              className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Yes
            </button>
            <button
              onClick={onDismiss}
              className="px-4 py-2 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-200 transition-colors"
            >
              No
            </button>
            <button
              onClick={onDismiss}
              className="p-1 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}