import React from "react";
import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

/**
 * Unified section card component matching TheoryLearning design
 * 
 * @param {Object} props
 * @param {string} props.title - Section title
 * @param {string} props.subtitle - Optional subtitle
 * @param {string} props.viewAllLink - Optional "View All" link
 * @param {string} props.viewAllLabel - Optional "View All" label
 * @param {React.ReactNode} props.children - Card content
 * @param {number} props.delay - Animation delay
 */
export default function SectionCard({ 
  title, 
  subtitle,
  viewAllLink, 
  viewAllLabel = "View All",
  children,
  delay = 0 
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
    >
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-bold text-gray-900">{title}</h2>
          {subtitle && (
            <p className="text-sm text-gray-600 mt-1">{subtitle}</p>
          )}
        </div>
        {viewAllLink && (
          <Link 
            to={createPageUrl(viewAllLink)} 
            className="text-sm font-semibold text-[#3b82c4] hover:text-[#2563a3] flex items-center gap-1 transition"
          >
            {viewAllLabel} <ChevronRight className="w-3 h-3" />
          </Link>
        )}
      </div>
      {children}
    </motion.div>
  );
}