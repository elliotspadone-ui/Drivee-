import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  AlertCircle,
  FileText,
  User,
  MapPin,
  Upload,
  Heart,
  Send,
  Loader2
} from "lucide-react";

import AntsWizardProgress, { STEPS } from "./AntsWizardProgress";
import AntsDisclaimer from "./AntsDisclaimer";
import AntsDocumentUpload from "./AntsDocumentUpload";

const NATIONALITIES = [
  "Française",
  "Algérienne",
  "Marocaine",
  "Tunisienne",
  "Portugaise",
  "Italienne",
  "Espagnole",
  "Autre UE",
  "Autre"
];

export default function StudentAntsWizard({ dossier, student, school, onComplete }) {
  const queryClient = useQueryClient();
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    // Identity
    student_first_name: dossier?.student_first_name || student?.full_name?.split(" ")[0] || "",
    student_last_name: dossier?.student_last_name || student?.full_name?.split(" ").slice(1).join(" ") || "",
    birth_name: dossier?.birth_name || "",
    birth_date: dossier?.birth_date || student?.date_of_birth || "",
    birth_place: dossier?.birth_place || "",
    birth_country: dossier?.birth_country || "France",
    gender: dossier?.gender || "",
    email: dossier?.email || student?.email || "",
    mobile: dossier?.mobile || student?.phone || "",
    
    // Address
    nationality: dossier?.nationality || "",
    address_street: dossier?.address_street || student?.address || "",
    address_postcode: dossier?.address_postcode || "",
    address_city: dossier?.address_city || "",
    address_country: dossier?.address_country || "France",
    
    // Existing file
    has_existing_french_file: dossier?.has_existing_french_file || false,
    existing_neph: dossier?.existing_neph || "",
    existing_licence_categories: dossier?.existing_licence_categories || [],
    
    // Documents
    e_photo_code: dossier?.e_photo_code || "",
    id_document_url: dossier?.id_document_url || "",
    proof_of_address_url: dossier?.proof_of_address_url || "",
    id_photo_url: dossier?.id_photo_url || "",
    assr_document_url: dossier?.assr_document_url || "",
    
    // Health
    has_medical_constraints: dossier?.has_medical_constraints || false,
    medical_details: dossier?.medical_details || "",
    medical_certificate_url: dossier?.medical_certificate_url || "",
    
    // Legal representative
    is_minor: dossier?.is_minor || false,
    legal_representative_name: dossier?.legal_representative_name || "",
    legal_representative_relation: dossier?.legal_representative_relation || "",
    legal_representative_email: dossier?.legal_representative_email || "",
    legal_representative_phone: dossier?.legal_representative_phone || ""
  });

  const [errors, setErrors] = useState({});
  const [completedSteps, setCompletedSteps] = useState([]);

  // Check if student is minor based on birth date
  useEffect(() => {
    if (formData.birth_date) {
      const birthDate = new Date(formData.birth_date);
      const today = new Date();
      const age = today.getFullYear() - birthDate.getFullYear();
      const isMinor = age < 18 || (age === 18 && today < new Date(birthDate.setFullYear(birthDate.getFullYear() + 18)));
      setFormData(prev => ({ ...prev, is_minor: isMinor }));
    }
  }, [formData.birth_date]);

  // Check if ASSR is required (born after 1988)
  const requiresAssr = useMemo(() => {
    if (!formData.birth_date) return false;
    const birthYear = new Date(formData.birth_date).getFullYear();
    return birthYear >= 1988;
  }, [formData.birth_date]);

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      if (dossier?.id) {
        return base44.entities.AntsDossier.update(dossier.id, data);
      } else {
        return base44.entities.AntsDossier.create({
          ...data,
          school_id: school.id,
          student_id: student.id,
          licence_category: student.license_category || "B",
          training_type: "traditional",
          auto_ecole_name: school.name,
          auto_ecole_siret: school.siret || "",
          auto_ecole_address: `${school.address}, ${school.city}`
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["antsDossier"] });
    }
  });

  const submitMutation = useMutation({
    mutationFn: async () => {
      const data = {
        ...formData,
        status: "ready_for_review",
        status_history: [
          ...(dossier?.status_history || []),
          {
            status: "ready_for_review",
            changed_by: student.email,
            changed_at: new Date().toISOString(),
            message: "Dossier soumis par l'élève"
          }
        ]
      };
      
      if (dossier?.id) {
        return base44.entities.AntsDossier.update(dossier.id, data);
      } else {
        return base44.entities.AntsDossier.create({
          ...data,
          school_id: school.id,
          student_id: student.id,
          licence_category: student.license_category || "B",
          training_type: "traditional",
          auto_ecole_name: school.name,
          auto_ecole_siret: school.siret || "",
          auto_ecole_address: `${school.address}, ${school.city}`
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["antsDossier"] });
      toast.success("Dossier envoyé à votre auto-école !");
      onComplete?.();
    },
    onError: (error) => {
      toast.error("Erreur lors de l'envoi du dossier");
      console.error(error);
    }
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  const handleDocumentUpload = (type, url) => {
    handleChange(type, url);
  };

  const validateStep = (step) => {
    const newErrors = {};

    switch (step) {
      case 1: // Identity
        if (!formData.student_first_name) newErrors.student_first_name = "Prénom requis";
        if (!formData.student_last_name) newErrors.student_last_name = "Nom requis";
        if (!formData.birth_date) newErrors.birth_date = "Date de naissance requise";
        if (!formData.birth_place) newErrors.birth_place = "Lieu de naissance requis";
        if (!formData.gender) newErrors.gender = "Genre requis";
        if (!formData.email) newErrors.email = "Email requis";
        if (!formData.mobile) newErrors.mobile = "Téléphone requis";
        break;

      case 2: // Address
        if (!formData.nationality) newErrors.nationality = "Nationalité requise";
        if (!formData.address_street) newErrors.address_street = "Adresse requise";
        if (!formData.address_postcode) newErrors.address_postcode = "Code postal requis";
        if (!formData.address_city) newErrors.address_city = "Ville requise";
        if (formData.has_existing_french_file && !formData.existing_neph) {
          newErrors.existing_neph = "Numéro NEPH requis si vous avez un dossier existant";
        }
        break;

      case 3: // Documents
        if (!formData.id_document_url) newErrors.id_document_url = "Pièce d'identité requise";
        if (!formData.proof_of_address_url) newErrors.proof_of_address_url = "Justificatif de domicile requis";
        if (!formData.e_photo_code && !formData.id_photo_url) {
          newErrors.e_photo_code = "Code e-photo ou photo d'identité requis";
        }
        if (requiresAssr && !formData.assr_document_url) {
          newErrors.assr_document_url = "ASSR2 ou ASR requis";
        }
        break;

      case 4: // Health & Legal
        if (formData.has_medical_constraints && !formData.medical_certificate_url) {
          newErrors.medical_certificate_url = "Certificat médical requis";
        }
        if (formData.is_minor) {
          if (!formData.legal_representative_name) newErrors.legal_representative_name = "Nom du représentant requis";
          if (!formData.legal_representative_relation) newErrors.legal_representative_relation = "Lien requis";
          if (!formData.legal_representative_email && !formData.legal_representative_phone) {
            newErrors.legal_representative_email = "Email ou téléphone du représentant requis";
          }
        }
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = async () => {
    if (currentStep > 0 && !validateStep(currentStep)) {
      toast.error("Veuillez corriger les erreurs");
      return;
    }

    // Save progress
    if (currentStep > 0) {
      await updateMutation.mutateAsync({ ...formData, status: "waiting_student_input" });
      setCompletedSteps(prev => [...new Set([...prev, currentStep])]);
    }

    if (currentStep < STEPS.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = async () => {
    // Validate all required fields
    let allValid = true;
    for (let step = 1; step <= 4; step++) {
      if (!validateStep(step)) {
        allValid = false;
      }
    }

    if (!allValid) {
      toast.error("Veuillez compléter tous les champs obligatoires");
      return;
    }

    submitMutation.mutate();
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-indigo-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-indigo-600" />
              </div>
              <h2 className="text-2xl font-bold text-zinc-900">Dossier ANTS</h2>
              <p className="text-zinc-600 mt-2 max-w-md mx-auto">
                Complétez votre dossier pour obtenir votre numéro NEPH et 
                pouvoir passer votre examen du permis de conduire.
              </p>
            </div>

            <AntsDisclaimer />

            <div className="bg-zinc-50 rounded-xl p-4 space-y-3">
              <h3 className="font-medium text-zinc-900">Documents à préparer :</h3>
              <ul className="space-y-2 text-sm text-zinc-600">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-500" />
                  Pièce d'identité (carte d'identité ou passeport)
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-500" />
                  Justificatif de domicile de moins de 6 mois
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-500" />
                  Code e-photo ou photo d'identité numérique
                </li>
                {requiresAssr && (
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500" />
                    ASSR2 ou ASR
                  </li>
                )}
              </ul>
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                <User className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-zinc-900">Identité</h2>
                <p className="text-sm text-zinc-500">Vérifiez et complétez vos informations personnelles</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Prénom *</Label>
                <Input
                  value={formData.student_first_name}
                  onChange={(e) => handleChange("student_first_name", e.target.value)}
                  className={errors.student_first_name ? "border-red-500" : ""}
                />
                {errors.student_first_name && (
                  <p className="text-xs text-red-500 mt-1">{errors.student_first_name}</p>
                )}
              </div>

              <div>
                <Label>Nom *</Label>
                <Input
                  value={formData.student_last_name}
                  onChange={(e) => handleChange("student_last_name", e.target.value)}
                  className={errors.student_last_name ? "border-red-500" : ""}
                />
                {errors.student_last_name && (
                  <p className="text-xs text-red-500 mt-1">{errors.student_last_name}</p>
                )}
              </div>

              <div>
                <Label>Nom de naissance (si différent)</Label>
                <Input
                  value={formData.birth_name}
                  onChange={(e) => handleChange("birth_name", e.target.value)}
                  placeholder="Laissez vide si identique"
                />
              </div>

              <div>
                <Label>Genre *</Label>
                <Select value={formData.gender} onValueChange={(v) => handleChange("gender", v)}>
                  <SelectTrigger className={errors.gender ? "border-red-500" : ""}>
                    <SelectValue placeholder="Sélectionnez" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="M">Homme</SelectItem>
                    <SelectItem value="F">Femme</SelectItem>
                  </SelectContent>
                </Select>
                {errors.gender && (
                  <p className="text-xs text-red-500 mt-1">{errors.gender}</p>
                )}
              </div>

              <div>
                <Label>Date de naissance *</Label>
                <Input
                  type="date"
                  value={formData.birth_date}
                  onChange={(e) => handleChange("birth_date", e.target.value)}
                  className={errors.birth_date ? "border-red-500" : ""}
                />
                {errors.birth_date && (
                  <p className="text-xs text-red-500 mt-1">{errors.birth_date}</p>
                )}
              </div>

              <div>
                <Label>Lieu de naissance *</Label>
                <Input
                  value={formData.birth_place}
                  onChange={(e) => handleChange("birth_place", e.target.value)}
                  placeholder="Ville"
                  className={errors.birth_place ? "border-red-500" : ""}
                />
                {errors.birth_place && (
                  <p className="text-xs text-red-500 mt-1">{errors.birth_place}</p>
                )}
              </div>

              <div>
                <Label>Pays de naissance</Label>
                <Input
                  value={formData.birth_country}
                  onChange={(e) => handleChange("birth_country", e.target.value)}
                  placeholder="France"
                />
              </div>

              <div>
                <Label>Email *</Label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  className={errors.email ? "border-red-500" : ""}
                />
                {errors.email && (
                  <p className="text-xs text-red-500 mt-1">{errors.email}</p>
                )}
              </div>

              <div>
                <Label>Téléphone mobile *</Label>
                <Input
                  type="tel"
                  value={formData.mobile}
                  onChange={(e) => handleChange("mobile", e.target.value)}
                  placeholder="06 XX XX XX XX"
                  className={errors.mobile ? "border-red-500" : ""}
                />
                {errors.mobile && (
                  <p className="text-xs text-red-500 mt-1">{errors.mobile}</p>
                )}
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                <MapPin className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-zinc-900">Adresse et nationalité</h2>
                <p className="text-sm text-zinc-500">Votre adresse actuelle et informations administratives</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label>Nationalité *</Label>
                <Select value={formData.nationality} onValueChange={(v) => handleChange("nationality", v)}>
                  <SelectTrigger className={errors.nationality ? "border-red-500" : ""}>
                    <SelectValue placeholder="Sélectionnez votre nationalité" />
                  </SelectTrigger>
                  <SelectContent>
                    {NATIONALITIES.map(nat => (
                      <SelectItem key={nat} value={nat}>{nat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.nationality && (
                  <p className="text-xs text-red-500 mt-1">{errors.nationality}</p>
                )}
              </div>

              <div className="md:col-span-2">
                <Label>Adresse *</Label>
                <Input
                  value={formData.address_street}
                  onChange={(e) => handleChange("address_street", e.target.value)}
                  placeholder="Numéro et nom de rue"
                  className={errors.address_street ? "border-red-500" : ""}
                />
                {errors.address_street && (
                  <p className="text-xs text-red-500 mt-1">{errors.address_street}</p>
                )}
              </div>

              <div>
                <Label>Code postal *</Label>
                <Input
                  value={formData.address_postcode}
                  onChange={(e) => handleChange("address_postcode", e.target.value)}
                  placeholder="75001"
                  className={errors.address_postcode ? "border-red-500" : ""}
                />
                {errors.address_postcode && (
                  <p className="text-xs text-red-500 mt-1">{errors.address_postcode}</p>
                )}
              </div>

              <div>
                <Label>Ville *</Label>
                <Input
                  value={formData.address_city}
                  onChange={(e) => handleChange("address_city", e.target.value)}
                  placeholder="Paris"
                  className={errors.address_city ? "border-red-500" : ""}
                />
                {errors.address_city && (
                  <p className="text-xs text-red-500 mt-1">{errors.address_city}</p>
                )}
              </div>
            </div>

            <div className="border-t pt-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <Label className="text-base">Avez-vous déjà un dossier ANTS ou un permis français ?</Label>
                  <p className="text-sm text-zinc-500">Si vous avez déjà un numéro NEPH</p>
                </div>
                <Switch
                  checked={formData.has_existing_french_file}
                  onCheckedChange={(v) => handleChange("has_existing_french_file", v)}
                />
              </div>

              {formData.has_existing_french_file && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-zinc-50 rounded-lg">
                  <div>
                    <Label>Numéro NEPH *</Label>
                    <Input
                      value={formData.existing_neph}
                      onChange={(e) => handleChange("existing_neph", e.target.value)}
                      placeholder="12 caractères"
                      className={errors.existing_neph ? "border-red-500" : ""}
                    />
                    {errors.existing_neph && (
                      <p className="text-xs text-red-500 mt-1">{errors.existing_neph}</p>
                    )}
                  </div>
                  <div>
                    <Label>Catégories de permis détenues</Label>
                    <Input
                      value={formData.existing_licence_categories?.join(", ") || ""}
                      onChange={(e) => handleChange("existing_licence_categories", e.target.value.split(",").map(s => s.trim()))}
                      placeholder="AM, A1, B..."
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                <Upload className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-zinc-900">Documents justificatifs</h2>
                <p className="text-sm text-zinc-500">Téléchargez les documents requis pour votre dossier</p>
              </div>
            </div>

            <div className="space-y-4">
              <AntsDocumentUpload
                label="Pièce d'identité"
                description="Carte d'identité recto-verso ou passeport (pages 2-3)"
                documentType="id_document_url"
                currentUrl={formData.id_document_url}
                onUpload={handleDocumentUpload}
                required
              />
              {errors.id_document_url && (
                <p className="text-xs text-red-500 -mt-2 ml-1">{errors.id_document_url}</p>
              )}

              <AntsDocumentUpload
                label="Justificatif de domicile"
                description="Facture, avis d'imposition ou attestation d'hébergement (moins de 6 mois)"
                documentType="proof_of_address_url"
                currentUrl={formData.proof_of_address_url}
                onUpload={handleDocumentUpload}
                required
              />
              {errors.proof_of_address_url && (
                <p className="text-xs text-red-500 -mt-2 ml-1">{errors.proof_of_address_url}</p>
              )}

              <div className="border border-zinc-200 rounded-xl p-4 bg-white">
                <Label className="text-base">Photo d'identité *</Label>
                <p className="text-sm text-zinc-500 mb-4">
                  Vous pouvez fournir un code e-photo (obtenu en cabine photo agréée ou photographe) 
                  ou télécharger une photo d'identité numérique.
                </p>
                
                <div className="space-y-4">
                  <div>
                    <Label>Code e-photo (22 caractères)</Label>
                    <Input
                      value={formData.e_photo_code}
                      onChange={(e) => handleChange("e_photo_code", e.target.value.toUpperCase())}
                      placeholder="ABC1234567890DEFGHIJ12"
                      maxLength={22}
                    />
                  </div>
                  
                  <div className="text-center text-sm text-zinc-500">ou</div>
                  
                  <AntsDocumentUpload
                    label="Photo d'identité numérique"
                    description="Photo format ANTS (fond clair, visage dégagé)"
                    documentType="id_photo_url"
                    currentUrl={formData.id_photo_url}
                    onUpload={handleDocumentUpload}
                  />
                </div>
                {errors.e_photo_code && (
                  <p className="text-xs text-red-500 mt-2">{errors.e_photo_code}</p>
                )}
              </div>

              {requiresAssr && (
                <>
                  <AntsDocumentUpload
                    label="ASSR2 ou ASR"
                    description="Attestation Scolaire de Sécurité Routière niveau 2 ou Attestation de Sécurité Routière"
                    documentType="assr_document_url"
                    currentUrl={formData.assr_document_url}
                    onUpload={handleDocumentUpload}
                    required
                  />
                  {errors.assr_document_url && (
                    <p className="text-xs text-red-500 -mt-2 ml-1">{errors.assr_document_url}</p>
                  )}
                </>
              )}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                <Heart className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-zinc-900">Santé et représentant légal</h2>
                <p className="text-sm text-zinc-500">Informations complémentaires si nécessaire</p>
              </div>
            </div>

            <div className="space-y-6">
              <div className="border border-zinc-200 rounded-xl p-4 bg-white">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <Label className="text-base">Contrainte médicale</Label>
                    <p className="text-sm text-zinc-500">
                      Avez-vous une affection ou un handicap nécessitant un certificat médical ?
                    </p>
                  </div>
                  <Switch
                    checked={formData.has_medical_constraints}
                    onCheckedChange={(v) => handleChange("has_medical_constraints", v)}
                  />
                </div>

                {formData.has_medical_constraints && (
                  <div className="space-y-4 pt-4 border-t">
                    <div>
                      <Label>Précisions (optionnel)</Label>
                      <Textarea
                        value={formData.medical_details}
                        onChange={(e) => handleChange("medical_details", e.target.value)}
                        placeholder="Décrivez brièvement votre situation..."
                        rows={3}
                      />
                    </div>
                    <AntsDocumentUpload
                      label="Certificat médical"
                      description="Certificat médical délivré par un médecin agréé"
                      documentType="medical_certificate_url"
                      currentUrl={formData.medical_certificate_url}
                      onUpload={handleDocumentUpload}
                      required
                    />
                    {errors.medical_certificate_url && (
                      <p className="text-xs text-red-500">{errors.medical_certificate_url}</p>
                    )}
                  </div>
                )}
              </div>

              {formData.is_minor && (
                <div className="border border-amber-200 bg-amber-50 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-4">
                    <AlertCircle className="w-5 h-5 text-amber-600" />
                    <Label className="text-base text-amber-900">Représentant légal (obligatoire pour les mineurs)</Label>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Nom complet du représentant *</Label>
                      <Input
                        value={formData.legal_representative_name}
                        onChange={(e) => handleChange("legal_representative_name", e.target.value)}
                        className={errors.legal_representative_name ? "border-red-500" : ""}
                      />
                      {errors.legal_representative_name && (
                        <p className="text-xs text-red-500 mt-1">{errors.legal_representative_name}</p>
                      )}
                    </div>

                    <div>
                      <Label>Lien de parenté *</Label>
                      <Select
                        value={formData.legal_representative_relation}
                        onValueChange={(v) => handleChange("legal_representative_relation", v)}
                      >
                        <SelectTrigger className={errors.legal_representative_relation ? "border-red-500" : ""}>
                          <SelectValue placeholder="Sélectionnez" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="parent">Parent</SelectItem>
                          <SelectItem value="guardian">Tuteur légal</SelectItem>
                          <SelectItem value="other">Autre</SelectItem>
                        </SelectContent>
                      </Select>
                      {errors.legal_representative_relation && (
                        <p className="text-xs text-red-500 mt-1">{errors.legal_representative_relation}</p>
                      )}
                    </div>

                    <div>
                      <Label>Email du représentant</Label>
                      <Input
                        type="email"
                        value={formData.legal_representative_email}
                        onChange={(e) => handleChange("legal_representative_email", e.target.value)}
                        className={errors.legal_representative_email ? "border-red-500" : ""}
                      />
                      {errors.legal_representative_email && (
                        <p className="text-xs text-red-500 mt-1">{errors.legal_representative_email}</p>
                      )}
                    </div>

                    <div>
                      <Label>Téléphone du représentant</Label>
                      <Input
                        type="tel"
                        value={formData.legal_representative_phone}
                        onChange={(e) => handleChange("legal_representative_phone", e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                <Send className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-zinc-900">Récapitulatif</h2>
                <p className="text-sm text-zinc-500">Vérifiez vos informations avant envoi</p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Identity Summary */}
              <div className="bg-zinc-50 rounded-xl p-4">
                <h3 className="font-medium text-zinc-900 mb-3">Identité</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div><span className="text-zinc-500">Nom :</span> {formData.student_last_name}</div>
                  <div><span className="text-zinc-500">Prénom :</span> {formData.student_first_name}</div>
                  <div><span className="text-zinc-500">Naissance :</span> {formData.birth_date} à {formData.birth_place}</div>
                  <div><span className="text-zinc-500">Email :</span> {formData.email}</div>
                </div>
              </div>

              {/* Address Summary */}
              <div className="bg-zinc-50 rounded-xl p-4">
                <h3 className="font-medium text-zinc-900 mb-3">Adresse</h3>
                <div className="text-sm">
                  <p>{formData.address_street}</p>
                  <p>{formData.address_postcode} {formData.address_city}</p>
                  <p className="text-zinc-500 mt-2">Nationalité : {formData.nationality}</p>
                </div>
              </div>

              {/* Documents Summary */}
              <div className="bg-zinc-50 rounded-xl p-4">
                <h3 className="font-medium text-zinc-900 mb-3">Documents</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    {formData.id_document_url ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-500" />
                    )}
                    <span>Pièce d'identité</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {formData.proof_of_address_url ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-500" />
                    )}
                    <span>Justificatif de domicile</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {formData.e_photo_code || formData.id_photo_url ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-500" />
                    )}
                    <span>Photo d'identité</span>
                  </div>
                  {requiresAssr && (
                    <div className="flex items-center gap-2">
                      {formData.assr_document_url ? (
                        <Check className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-red-500" />
                      )}
                      <span>ASSR2 / ASR</span>
                    </div>
                  )}
                </div>
              </div>

              <AntsDisclaimer variant="compact" />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const isLoading = updateMutation.isPending || submitMutation.isPending;

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8">
        <AntsWizardProgress currentStep={currentStep} completedSteps={completedSteps} />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
          className="bg-white rounded-2xl border border-zinc-200 p-6 shadow-sm"
        >
          {renderStep()}
        </motion.div>
      </AnimatePresence>

      <div className="flex items-center justify-between mt-6">
        <Button
          variant="outline"
          onClick={handleBack}
          disabled={currentStep === 0 || isLoading}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Précédent
        </Button>

        {currentStep < STEPS.length - 1 ? (
          <Button onClick={handleNext} disabled={isLoading}>
            {isLoading ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <>
                Suivant
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        ) : (
          <Button
            onClick={handleSubmit}
            disabled={isLoading}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Envoyer à mon auto-école
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}