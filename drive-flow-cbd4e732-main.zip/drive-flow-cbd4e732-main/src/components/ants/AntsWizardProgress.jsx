import React from "react";
import { Check } from "lucide-react";

const STEPS = [
  { id: 0, label: "Introduction" },
  { id: 1, label: "Identité" },
  { id: 2, label: "Adresse" },
  { id: 3, label: "Documents" },
  { id: 4, label: "Santé" },
  { id: 5, label: "Récapitulatif" }
];

export default function AntsWizardProgress({ currentStep, completedSteps = [] }) {
  return (
    <div className="w-full">
      <div className="flex items-center justify-between">
        {STEPS.map((step, index) => {
          const isCompleted = completedSteps.includes(step.id);
          const isCurrent = currentStep === step.id;
          const isPast = currentStep > step.id;

          return (
            <React.Fragment key={step.id}>
              <div className="flex flex-col items-center">
                <div
                  className={`
                    w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all
                    ${isCompleted || isPast
                      ? "bg-indigo-600 text-white"
                      : isCurrent
                        ? "bg-indigo-100 text-indigo-600 ring-2 ring-indigo-600"
                        : "bg-zinc-100 text-zinc-400"
                    }
                  `}
                >
                  {isCompleted || isPast ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    step.id + 1
                  )}
                </div>
                <span
                  className={`
                    mt-2 text-xs font-medium hidden sm:block
                    ${isCurrent ? "text-indigo-600" : isPast ? "text-zinc-700" : "text-zinc-400"}
                  `}
                >
                  {step.label}
                </span>
              </div>
              {index < STEPS.length - 1 && (
                <div
                  className={`
                    flex-1 h-0.5 mx-2
                    ${isPast ? "bg-indigo-600" : "bg-zinc-200"}
                  `}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

export { STEPS };