import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Upload, CheckCircle2, X, FileText, Loader2, Eye } from "lucide-react";

export default function AntsDocumentUpload({
  label,
  description,
  documentType,
  currentUrl,
  onUpload,
  required = false,
  disabled = false
}) {
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState(null);

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError("Le fichier ne doit pas dépasser 5 Mo");
      return;
    }

    // Validate file type
    const allowedTypes = ["image/jpeg", "image/png", "image/webp", "application/pdf"];
    if (!allowedTypes.includes(file.type)) {
      setError("Format accepté : JPG, PNG, WebP ou PDF");
      return;
    }

    setIsUploading(true);
    setError(null);

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      onUpload(documentType, file_url);
    } catch (err) {
      console.error("Upload error:", err);
      setError("Erreur lors du téléchargement");
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemove = () => {
    onUpload(documentType, null);
  };

  return (
    <div className="border border-zinc-200 rounded-xl p-4 bg-white">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-zinc-900">{label}</span>
            {required && <span className="text-red-500">*</span>}
            {currentUrl && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 text-xs rounded-full">
                <CheckCircle2 className="w-3 h-3" />
                Fourni
              </span>
            )}
          </div>
          {description && (
            <p className="text-xs text-zinc-500 mt-1">{description}</p>
          )}
        </div>
      </div>

      {currentUrl ? (
        <div className="mt-3 flex items-center gap-2">
          <a
            href={currentUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-3 py-2 bg-zinc-100 hover:bg-zinc-200 rounded-lg text-sm text-zinc-700 transition"
          >
            <Eye className="w-4 h-4" />
            Voir le document
          </a>
          {!disabled && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRemove}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
      ) : (
        <div className="mt-3">
          <label className={`
            flex flex-col items-center justify-center w-full h-24 
            border-2 border-dashed rounded-lg cursor-pointer
            ${disabled ? "bg-zinc-50 border-zinc-200 cursor-not-allowed" : "border-zinc-300 hover:border-indigo-400 hover:bg-indigo-50/50"}
            transition-colors
          `}>
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              {isUploading ? (
                <Loader2 className="w-6 h-6 text-indigo-600 animate-spin" />
              ) : (
                <>
                  <Upload className="w-6 h-6 text-zinc-400 mb-2" />
                  <p className="text-xs text-zinc-500">
                    Cliquez ou glissez-déposez
                  </p>
                  <p className="text-xs text-zinc-400">
                    JPG, PNG, PDF (max 5 Mo)
                  </p>
                </>
              )}
            </div>
            <input
              type="file"
              className="hidden"
              accept="image/jpeg,image/png,image/webp,application/pdf"
              onChange={handleFileChange}
              disabled={disabled || isUploading}
            />
          </label>
          {error && (
            <p className="text-xs text-red-500 mt-2">{error}</p>
          )}
        </div>
      )}
    </div>
  );
}