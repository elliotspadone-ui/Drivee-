import React from "react";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Send,
  UserCheck,
  XCircle,
  Edit3,
  Eye
} from "lucide-react";

const STATUS_CONFIG = {
  draft: {
    label: "Brouillon",
    color: "bg-zinc-100 text-zinc-700",
    icon: FileText
  },
  waiting_student_input: {
    label: "En attente élève",
    color: "bg-amber-100 text-amber-700",
    icon: Clock
  },
  ready_for_review: {
    label: "À vérifier",
    color: "bg-blue-100 text-blue-700",
    icon: Eye
  },
  under_review: {
    label: "En cours de vérification",
    color: "bg-indigo-100 text-indigo-700",
    icon: Eye
  },
  ready_to_send_ants: {
    label: "Prêt pour ANTS",
    color: "bg-purple-100 text-purple-700",
    icon: Send
  },
  sent_to_ants: {
    label: "Envoyé ANTS",
    color: "bg-cyan-100 text-cyan-700",
    icon: Send
  },
  awaiting_student_ants_activation: {
    label: "Activation ANTS requise",
    color: "bg-orange-100 text-orange-700",
    icon: UserCheck
  },
  accepted_by_ants: {
    label: "Accepté ANTS",
    color: "bg-emerald-100 text-emerald-700",
    icon: CheckCircle2
  },
  rejected_by_ants: {
    label: "Refusé ANTS",
    color: "bg-red-100 text-red-700",
    icon: XCircle
  },
  needs_correction: {
    label: "Corrections requises",
    color: "bg-rose-100 text-rose-700",
    icon: Edit3
  }
};

export default function AntsStatusBadge({ status, showIcon = true, size = "default" }) {
  const config = STATUS_CONFIG[status] || STATUS_CONFIG.draft;
  const Icon = config.icon;

  const sizeClasses = size === "small" 
    ? "text-xs px-2 py-0.5" 
    : "text-sm px-3 py-1";

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full font-medium ${config.color} ${sizeClasses}`}>
      {showIcon && <Icon className={size === "small" ? "w-3 h-3" : "w-4 h-4"} />}
      {config.label}
    </span>
  );
}

export { STATUS_CONFIG };