import React from "react";
import { Info } from "lucide-react";

export default function AntsDisclaimer({ variant = "default" }) {
  const bgColor = variant === "compact" ? "bg-blue-50" : "bg-gradient-to-r from-blue-50 to-indigo-50";
  
  return (
    <div className={`${bgColor} border border-blue-200 rounded-xl p-4`}>
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
          <Info className="w-4 h-4 text-blue-600" />
        </div>
        <div>
          <p className="text-sm font-medium text-blue-900">À propos du dossier ANTS</p>
          <p className="text-sm text-blue-700 mt-1">
            Cette fonctionnalité prépare, collecte et suit votre dossier ANTS, 
            mais ne remplace pas le site officiel de l'ANTS. Votre auto-école 
            soumettra la demande via son compte professionnel ANTS, et vous 
            recevrez un email pour activer votre compte ANTS personnel.
          </p>
        </div>
      </div>
    </div>
  );
}