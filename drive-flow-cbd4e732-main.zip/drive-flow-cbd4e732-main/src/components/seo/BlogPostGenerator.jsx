import React, { useState } from "react";
import { Sparkles, FileText, Search, Wand2, Save, Eye } from "lucide-react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function BlogPostGenerator({ schoolId, onGenerated }) {
  const [topic, setTopic] = useState("");
  const [keywords, setKeywords] = useState("");
  const [tone, setTone] = useState("professional");
  const [length, setLength] = useState("medium");
  const [generating, setGenerating] = useState(false);
  const [generatedPost, setGeneratedPost] = useState(null);

  const topicSuggestions = [
    "Top 10 Driving Safety Tips for New Drivers",
    "How to Prepare for Your Driving Test",
    "Understanding Traffic Signs and Signals",
    "Defensive Driving Techniques",
    "Parking Made Easy: A Step-by-Step Guide",
    "Winter Driving Safety Tips",
    "Highway Driving for Beginners",
    "Common Driving Test Mistakes to Avoid"
  ];

  const generateBlogPost = async () => {
    setGenerating(true);
    
    try {
      const prompt = `Write a comprehensive blog post for a driving school website about: "${topic}".

Target keywords: ${keywords}
Tone: ${tone}
Length: ${length === 'short' ? '500-700 words' : length === 'medium' ? '800-1200 words' : '1500-2000 words'}

Include:
- Engaging introduction with a hook
- Well-structured sections with subheadings
- Practical tips and actionable advice
- Examples and scenarios
- Safety considerations
- Call-to-action at the end
- Meta title and description optimized for SEO

Format the response as JSON with these fields:
- title: catchy blog post title
- content: full blog post in HTML format with proper headings
- excerpt: 150-character summary
- meta_title: SEO-optimized title (60 chars max)
- meta_description: SEO description (155 chars max)
- keywords: array of relevant keywords
- read_time: estimated reading time in minutes`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            content: { type: "string" },
            excerpt: { type: "string" },
            meta_title: { type: "string" },
            meta_description: { type: "string" },
            keywords: { type: "array", items: { type: "string" } },
            read_time: { type: "integer" }
          }
        }
      });

      setGeneratedPost(response);
      toast.success("Blog post generated successfully!");
    } catch (error) {
      toast.error("Failed to generate blog post");
      console.error(error);
    } finally {
      setGenerating(false);
    }
  };

  const saveBlogPost = async () => {
    try {
      await base44.entities.BlogPost.create({
        school_id: schoolId,
        title: generatedPost.title,
        slug: generatedPost.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        content: generatedPost.content,
        excerpt: generatedPost.excerpt,
        meta_title: generatedPost.meta_title,
        meta_description: generatedPost.meta_description,
        keywords: generatedPost.keywords,
        category: "driving_tips",
        read_time_minutes: generatedPost.read_time,
        ai_generated: true,
        status: "draft"
      });
      
      toast.success("Blog post saved as draft!");
      if (onGenerated) onGenerated();
    } catch (error) {
      toast.error("Failed to save blog post");
    }
  };

  return (
    <div className="space-y-6">
      <div className="neo-surface p-8 rounded-3xl">
        <div className="flex items-center gap-3 mb-6">
          <div className="neo-inset w-12 h-12 rounded-2xl flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">AI Blog Post Generator</h2>
            <p className="text-sm text-muted">Create SEO-optimized content in seconds</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-sm font-semibold text-gray-900 mb-2 block">Blog Topic</label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., How to parallel park like a pro"
              className="neo-button w-full px-4 py-3 rounded-xl"
            />
            <div className="flex flex-wrap gap-2 mt-2">
              {topicSuggestions.slice(0, 4).map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => setTopic(suggestion)}
                  className="neo-button px-3 py-1 text-xs rounded-lg hover:bg-indigo-50"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-sm font-semibold text-gray-900 mb-2 block">Target Keywords</label>
            <input
              type="text"
              value={keywords}
              onChange={(e) => setKeywords(e.target.value)}
              placeholder="driving tips, safety, beginners"
              className="neo-button w-full px-4 py-3 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold text-gray-900 mb-2 block">Tone</label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="neo-button w-full px-4 py-3 rounded-xl"
              >
                <option value="professional">Professional</option>
                <option value="friendly">Friendly</option>
                <option value="educational">Educational</option>
                <option value="conversational">Conversational</option>
              </select>
            </div>

            <div>
              <label className="text-sm font-semibold text-gray-900 mb-2 block">Length</label>
              <select
                value={length}
                onChange={(e) => setLength(e.target.value)}
                className="neo-button w-full px-4 py-3 rounded-xl"
              >
                <option value="short">Short (500-700 words)</option>
                <option value="medium">Medium (800-1200 words)</option>
                <option value="long">Long (1500-2000 words)</option>
              </select>
            </div>
          </div>

          <button
            onClick={generateBlogPost}
            disabled={!topic || generating}
            className="neo-button w-full py-4 gradient-primary text-white font-bold rounded-2xl disabled:opacity-50"
          >
            {generating ? (
              <>
                <Wand2 className="w-5 h-5 mr-2 inline animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2 inline" />
                Generate Blog Post
              </>
            )}
          </button>
        </div>
      </div>

      {generatedPost && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="neo-surface p-8 rounded-3xl"
        >
          <h3 className="text-xl font-bold text-gray-900 mb-4">{generatedPost.title}</h3>
          
          <div className="neo-inset p-4 rounded-2xl mb-4">
            <p className="text-sm text-gray-700 mb-2"><strong>Meta Title:</strong> {generatedPost.meta_title}</p>
            <p className="text-sm text-gray-700 mb-2"><strong>Meta Description:</strong> {generatedPost.meta_description}</p>
            <p className="text-sm text-gray-700"><strong>Keywords:</strong> {generatedPost.keywords.join(", ")}</p>
          </div>

          <div 
            className="prose max-w-none mb-6"
            dangerouslySetInnerHTML={{ __html: generatedPost.content }}
          />

          <div className="flex gap-3">
            <button
              onClick={saveBlogPost}
              className="neo-button flex-1 py-3 gradient-primary text-white font-semibold rounded-xl"
            >
              <Save className="w-5 h-5 mr-2 inline" />
              Save as Draft
            </button>
            <button className="neo-button px-6 py-3 rounded-xl">
              <Eye className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}