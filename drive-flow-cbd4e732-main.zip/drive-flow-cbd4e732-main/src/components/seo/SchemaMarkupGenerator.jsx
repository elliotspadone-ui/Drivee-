import React, { useState } from "react";
import { Code, Copy, Check, Download } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function SchemaMarkupGenerator({ school }) {
  const [copied, setCopied] = useState(false);

  const generateLocalBusinessSchema = () => {
    return {
      "@context": "https://schema.org",
      "@type": "AutomotiveBusiness",
      "@id": `https://${school.website}#business`,
      "name": school.name,
      "description": school.description,
      "url": `https://${school.website}`,
      "logo": school.logo_url,
      "image": school.cover_image_url,
      "telephone": school.phone,
      "email": school.email,
      "address": {
        "@type": "PostalAddress",
        "streetAddress": school.address,
        "addressLocality": school.city,
        "addressRegion": school.state,
        "postalCode": school.postal_code,
        "addressCountry": school.country
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": school.latitude,
        "longitude": school.longitude
      },
      "openingHoursSpecification": Object.entries(school.operating_hours || {}).map(([day, hours]) => ({
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": day.charAt(0).toUpperCase() + day.slice(1),
        "opens": hours.open,
        "closes": hours.close
      })),
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": school.rating || 5,
        "reviewCount": school.total_reviews || 0,
        "bestRating": 5,
        "worstRating": 1
      },
      "priceRange": "$$"
    };
  };

  const generateServiceSchema = () => {
    return {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "Driving Lessons",
      "provider": {
        "@type": "AutomotiveBusiness",
        "name": school.name
      },
      "areaServed": {
        "@type": "City",
        "name": school.city
      },
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Driving School Services",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Driving Lessons",
              "description": "Professional driving lessons for beginners and advanced learners"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Theory Test Preparation",
              "description": "Comprehensive theory test preparation and practice"
            }
          }
        ]
      }
    };
  };

  const generateBreadcrumbSchema = () => {
    return {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": `https://${school.website}`
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Driving Lessons",
          "item": `https://${school.website}/lessons`
        }
      ]
    };
  };

  const generateOrganizationSchema = () => {
    return {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": school.name,
      "url": `https://${school.website}`,
      "logo": school.logo_url,
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": school.phone,
        "contactType": "Customer Service",
        "email": school.email,
        "availableLanguage": school.languages || ["English"]
      },
      "sameAs": [
        // Social media profiles would go here
      ]
    };
  };

  const allSchemas = [
    { name: "Local Business", schema: generateLocalBusinessSchema() },
    { name: "Service", schema: generateServiceSchema() },
    { name: "Breadcrumb", schema: generateBreadcrumbSchema() },
    { name: "Organization", schema: generateOrganizationSchema() }
  ];

  const copyToClipboard = (schema) => {
    const scriptTag = `<script type="application/ld+json">\n${JSON.stringify(schema, null, 2)}\n</script>`;
    navigator.clipboard.writeText(scriptTag);
    setCopied(true);
    toast.success("Schema markup copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadAll = () => {
    const allMarkup = allSchemas.map(s => 
      `<!-- ${s.name} Schema -->\n<script type="application/ld+json">\n${JSON.stringify(s.schema, null, 2)}\n</script>`
    ).join('\n\n');
    
    const blob = new Blob([allMarkup], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'schema-markup.html';
    a.click();
    toast.success("Schema markup downloaded!");
  };

  return (
    <div className="space-y-6">
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Schema Markup Generator</h2>
            <p className="text-sm text-muted">Boost your search engine visibility with structured data</p>
          </div>
          <button
            onClick={downloadAll}
            className="neo-button px-4 py-2 flex items-center gap-2 font-semibold"
          >
            <Download className="w-4 h-4" />
            Download All
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {allSchemas.map((item, index) => (
            <div key={index} className="neo-inset p-4 rounded-2xl">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Code className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-bold text-gray-900">{item.name}</h3>
                </div>
                <button
                  onClick={() => copyToClipboard(item.schema)}
                  className="neo-button p-2 rounded-lg"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-green-600" />
                  ) : (
                    <Copy className="w-4 h-4 text-gray-600" />
                  )}
                </button>
              </div>
              <pre className="bg-gray-900 text-green-400 p-4 rounded-xl text-xs overflow-x-auto max-h-48">
                {JSON.stringify(item.schema, null, 2)}
              </pre>
            </div>
          ))}
        </div>
      </div>

      <div className="neo-inset p-6 rounded-2xl">
        <h3 className="font-bold text-gray-900 mb-3">Implementation Instructions</h3>
        <ol className="space-y-2 text-sm text-gray-700">
          <li>1. Copy the schema markup code</li>
          <li>2. Paste it in the <code className="bg-gray-200 px-2 py-1 rounded">&lt;head&gt;</code> section of your website</li>
          <li>3. Test your implementation using Google's Rich Results Test</li>
          <li>4. Submit your sitemap to Google Search Console</li>
        </ol>
      </div>
    </div>
  );
}