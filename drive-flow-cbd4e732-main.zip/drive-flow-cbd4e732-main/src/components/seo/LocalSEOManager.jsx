import React, { useState } from "react";
import { MapPin, Phone, Clock, Star, ExternalLink, RefreshCw, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function LocalSEOManager({ localSEO, school, onSync }) {
  const [syncing, setSyncing] = useState(false);

  const syncGoogleBusiness = async () => {
    setSyncing(true);
    try {
      // In production, this would call Google My Business API
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast.success("Google Business Profile synced!");
      if (onSync) onSync();
    } catch (error) {
      toast.error("Failed to sync");
    } finally {
      setSyncing(false);
    }
  };

  const optimizationChecklist = [
    { 
      label: "Business Name", 
      completed: !!school.name,
      tip: "Use your exact business name as it appears offline"
    },
    { 
      label: "Address & Phone", 
      completed: !!(school.address && school.phone),
      tip: "Ensure NAP (Name, Address, Phone) consistency across all platforms"
    },
    { 
      label: "Business Hours", 
      completed: !!school.operating_hours,
      tip: "Keep hours updated, especially for holidays"
    },
    { 
      label: "Business Description", 
      completed: !!school.description,
      tip: "Include relevant keywords naturally in your description"
    },
    { 
      label: "Photos", 
      completed: !!(school.logo_url && school.cover_image_url),
      tip: "Add high-quality photos of your location and services"
    },
    { 
      label: "Reviews", 
      completed: (localSEO?.total_reviews || 0) > 10,
      tip: "Encourage satisfied customers to leave reviews"
    }
  ];

  const completedCount = optimizationChecklist.filter(item => item.completed).length;
  const completionPercentage = (completedCount / optimizationChecklist.length) * 100;

  return (
    <div className="space-y-6">
      {/* Profile Status */}
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Local SEO Manager</h2>
            <p className="text-sm text-muted">Optimize your local search presence</p>
          </div>
          <button
            onClick={syncGoogleBusiness}
            disabled={syncing}
            className="neo-button px-4 py-2 flex items-center gap-2 font-semibold"
          >
            <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Syncing...' : 'Sync Google'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="neo-inset p-6 rounded-2xl">
            <MapPin className="w-8 h-8 text-indigo-600 mb-3" />
            <p className="text-sm text-muted mb-1">Profile Status</p>
            <p className="text-2xl font-bold text-gray-900">
              {localSEO?.is_verified ? "Verified ✓" : "Not Verified"}
            </p>
          </div>

          <div className="neo-inset p-6 rounded-2xl">
            <Star className="w-8 h-8 text-yellow-500 mb-3" />
            <p className="text-sm text-muted mb-1">Average Rating</p>
            <p className="text-2xl font-bold text-gray-900">
              {localSEO?.average_rating?.toFixed(1) || "N/A"}
            </p>
          </div>

          <div className="neo-inset p-6 rounded-2xl">
            <Phone className="w-8 h-8 text-green-600 mb-3" />
            <p className="text-sm text-muted mb-1">Total Reviews</p>
            <p className="text-2xl font-bold text-gray-900">
              {localSEO?.total_reviews || 0}
            </p>
          </div>
        </div>
      </div>

      {/* Optimization Checklist */}
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-gray-900">Optimization Checklist</h3>
          <div className="neo-inset px-4 py-2 rounded-xl">
            <span className="text-sm font-bold text-indigo-600">
              {completedCount}/{optimizationChecklist.length} Complete
            </span>
          </div>
        </div>

        <div className="relative h-3 bg-gray-200 rounded-full overflow-hidden mb-6">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${completionPercentage}%` }}
            className="absolute h-full bg-gradient-to-r from-green-500 to-emerald-500"
          />
        </div>

        <div className="space-y-3">
          {optimizationChecklist.map((item, index) => (
            <div key={index} className="neo-inset p-4 rounded-xl">
              <div className="flex items-start gap-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                  item.completed ? 'bg-green-500' : 'bg-gray-300'
                }`}>
                  {item.completed && <CheckCircle className="w-4 h-4 text-white" />}
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900 mb-1">{item.label}</p>
                  <p className="text-xs text-muted">{item.tip}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Business Details */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Business Information</h3>
        
        <div className="space-y-4">
          <div className="neo-inset p-4 rounded-xl">
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-muted mb-1">Address</p>
                <p className="font-semibold text-gray-900">
                  {school.address}, {school.city}, {school.postal_code}
                </p>
              </div>
            </div>
          </div>

          <div className="neo-inset p-4 rounded-xl">
            <div className="flex items-start gap-3">
              <Phone className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-muted mb-1">Phone</p>
                <p className="font-semibold text-gray-900">{school.phone}</p>
              </div>
            </div>
          </div>

          <div className="neo-inset p-4 rounded-xl">
            <div className="flex items-start gap-3">
              <Clock className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm text-muted mb-2">Hours</p>
                {school.operating_hours && Object.entries(school.operating_hours).map(([day, hours]) => (
                  <div key={day} className="flex justify-between text-sm mb-1">
                    <span className="text-gray-700 capitalize">{day}:</span>
                    <span className="font-semibold text-gray-900">
                      {hours.open} - {hours.close}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {localSEO?.google_business_url && (
            <a
              href={localSEO.google_business_url}
              target="_blank"
              rel="noopener noreferrer"
              className="neo-button w-full py-3 rounded-xl flex items-center justify-center gap-2 font-semibold text-indigo-600"
            >
              <ExternalLink className="w-5 h-5" />
              View Google Business Profile
            </a>
          )}
        </div>
      </div>
    </div>
  );
}