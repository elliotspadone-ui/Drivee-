import React, { useState } from "react";
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Gauge, Search, MapPin, Smartphone } from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { motion } from "framer-motion";

export default function SEODashboard({ audit, keywords = [], localSEO }) {
  const [timeRange, setTimeRange] = useState("30d");

  const performanceIssues = audit?.issues?.filter(i => i.severity === 'critical') || [];
  const warnings = audit?.issues?.filter(i => i.severity === 'warning') || [];

  const keywordRankings = keywords
    .sort((a, b) => a.current_rank - b.current_rank)
    .slice(0, 10);

  const rankingTrend = [
    { date: "Week 1", rank: 15 },
    { date: "Week 2", rank: 12 },
    { date: "Week 3", rank: 10 },
    { date: "Week 4", rank: 8 }
  ];

  const getScoreColor = (score) => {
    if (score >= 90) return "text-green-600";
    if (score >= 70) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreGradient = (score) => {
    if (score >= 90) return "from-green-400 to-emerald-400";
    if (score >= 70) return "from-yellow-400 to-orange-400";
    return "from-red-400 to-pink-400";
  };

  return (
    <div className="space-y-6">
      {/* Score Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <Gauge className="w-8 h-8 text-indigo-500" />
            <span className="text-sm font-semibold text-gray-700">Overall SEO</span>
          </div>
          <p className={`text-5xl font-bold ${getScoreColor(audit?.overall_score || 0)}`}>
            {audit?.overall_score || 0}
          </p>
          <div className="relative h-2 bg-gray-200 rounded-full overflow-hidden mt-3">
            <div 
              className={`absolute h-full bg-gradient-to-r ${getScoreGradient(audit?.overall_score || 0)}`}
              style={{ width: `${audit?.overall_score || 0}%` }}
            />
          </div>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <Gauge className="w-8 h-8 text-blue-500" />
            <span className="text-sm font-semibold text-gray-700">Performance</span>
          </div>
          <p className={`text-5xl font-bold ${getScoreColor(audit?.performance_score || 0)}`}>
            {audit?.performance_score || 0}
          </p>
          <p className="text-xs text-muted mt-2">
            {audit?.page_speed_desktop?.toFixed(1)}s load time
          </p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <Smartphone className="w-8 h-8 text-purple-500" />
            <span className="text-sm font-semibold text-gray-700">Mobile</span>
          </div>
          <p className={`text-5xl font-bold ${getScoreColor(audit?.mobile_score || 0)}`}>
            {audit?.mobile_score || 0}
          </p>
          <p className="text-xs text-muted mt-2">
            {audit?.mobile_friendly ? "Mobile Friendly ✓" : "Needs Work"}
          </p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <MapPin className="w-8 h-8 text-green-500" />
            <span className="text-sm font-semibold text-gray-700">Local SEO</span>
          </div>
          <p className="text-5xl font-bold text-gray-900">
            {localSEO?.average_rating?.toFixed(1) || "N/A"}
          </p>
          <p className="text-xs text-muted mt-2">
            {localSEO?.total_reviews || 0} reviews
          </p>
        </div>
      </div>

      {/* Critical Issues */}
      {performanceIssues.length > 0 && (
        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-red-600" />
            Critical Issues ({performanceIssues.length})
          </h3>
          <div className="space-y-3">
            {performanceIssues.map((issue, index) => (
              <div key={index} className="neo-inset p-4 rounded-xl border-l-4 border-red-500">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-semibold text-gray-900">{issue.title}</h4>
                  <span className="neo-button px-3 py-1 text-xs font-bold text-red-700">
                    CRITICAL
                  </span>
                </div>
                <p className="text-sm text-gray-700 mb-2">{issue.description}</p>
                <p className="text-xs text-indigo-600 font-semibold">💡 {issue.fix}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Keyword Rankings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Keyword Rankings</h3>
          <div className="space-y-2">
            {keywordRankings.map((keyword, index) => (
              <div key={keyword.id} className="neo-inset p-3 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="neo-button w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm">
                    #{keyword.current_rank || '?'}
                  </span>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">{keyword.keyword}</p>
                    <p className="text-xs text-muted">{keyword.search_volume} searches/mo</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {keyword.rank_change > 0 ? (
                    <TrendingUp className="w-4 h-4 text-green-600" />
                  ) : keyword.rank_change < 0 ? (
                    <TrendingDown className="w-4 h-4 text-red-600" />
                  ) : null}
                  <span className={`text-sm font-bold ${
                    keyword.rank_change > 0 ? 'text-green-600' : 
                    keyword.rank_change < 0 ? 'text-red-600' : 'text-gray-600'
                  }`}>
                    {keyword.rank_change > 0 ? '+' : ''}{keyword.rank_change || 0}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Ranking Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={rankingTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="date" stroke="#6b7280" style={{ fontSize: '12px' }} />
              <YAxis 
                stroke="#6b7280" 
                style={{ fontSize: '12px' }}
                reversed
                domain={[1, 20]}
              />
              <Tooltip />
              <Line 
                type="monotone" 
                dataKey="rank" 
                stroke="#667eea" 
                strokeWidth={3}
                dot={{ fill: "#667eea", r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Quick Wins */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
          <CheckCircle className="w-6 h-6 text-green-600" />
          Quick SEO Wins
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {audit?.recommendations?.slice(0, 6).map((rec, index) => (
            <div key={index} className="neo-inset p-4 rounded-xl flex items-start gap-3">
              <div className="neo-button w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-xs font-bold text-indigo-600">{index + 1}</span>
              </div>
              <p className="text-sm text-gray-700">{rec}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}