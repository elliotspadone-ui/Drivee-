import { base44 } from "@/api/base44Client";

export const sendFeedbackRequest = async (booking, student, instructor) => {
  if (!student || !instructor) return;

  const formatDateTime = (datetime) => {
    const date = new Date(datetime);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const subject = "How was your lesson? - DriveSchool";
  const body = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #667eea;">We'd love your feedback!</h2>
      <p>Hi ${student.full_name},</p>
      
      <p>Thank you for completing your driving lesson with ${instructor.full_name} on ${formatDateTime(booking.start_datetime)}.</p>
      
      <p>Your feedback helps us improve our service and helps other students make informed decisions. It only takes a minute!</p>
      
      <div style="background: #f5f5f7; padding: 20px; border-radius: 12px; margin: 20px 0;">
        <h3 style="margin-top: 0; color: #333;">Lesson Details:</h3>
        <ul style="line-height: 1.8;">
          <li><strong>Instructor:</strong> ${instructor.full_name}</li>
          <li><strong>Date:</strong> ${formatDateTime(booking.start_datetime)}</li>
          <li><strong>Duration:</strong> ${Math.round((new Date(booking.end_datetime) - new Date(booking.start_datetime)) / 60000)} minutes</li>
        </ul>
      </div>
      
      <div style="text-align: center; margin: 30px 0;">
        <a href="${window.location.origin}/feedback/${booking.id}" 
           style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                  color: white; 
                  padding: 15px 40px; 
                  text-decoration: none; 
                  border-radius: 12px; 
                  font-weight: bold;
                  display: inline-block;">
          Rate Your Lesson
        </a>
      </div>
      
      <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">
        Thank you for being part of our driving school community!
      </p>
      
      <p style="color: #6b7280; font-size: 14px;">
        Best regards,<br>
        DriveSchool Team
      </p>
    </div>
  `;

  try {
    await base44.integrations.Core.SendEmail({
      to: student.email,
      subject: subject,
      body: body,
    });
  } catch (error) {
    console.error("Failed to send feedback request:", error);
  }
};

export const shouldRequestFeedback = async (booking) => {
  // Check if feedback already exists for this booking
  try {
    const existingReviews = await base44.entities.Review.filter({ 
      booking_id: booking.id 
    });
    return existingReviews.length === 0;
  } catch (error) {
    return true;
  }
};