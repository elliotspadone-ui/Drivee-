import React, { useState, useMemo, useCallback } from "react";
import { Link } from "react-router-dom";
import { 
  Star, 
  MapPin, 
  Check, 
  Users, 
  Car, 
  ChevronRight,
  Clock,
  Calendar,
  Award,
  Shield,
  Heart,
  Phone,
  Mail,
  Globe,
  ExternalLink,
  Navigation,
  Bookmark,
  BookmarkCheck,
  Share2,
  MessageCircle,
  ThumbsUp,
  Eye,
  Zap,
  Target,
  GraduationCap,
  Route,
  Gauge,
  Moon,
  CreditCard,
  Percent,
  Tag,
  CheckCircle,
  XCircle,
  AlertCircle,
  Info,
  ChevronDown,
  ChevronUp,
  Play,
  Sparkles,
  TrendingUp,
  BadgeCheck
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { createPageUrl } from "@/utils";
import { format, differenceInDays, isWithinInterval, addDays } from "date-fns";
import RequireStudentAuth from "@/components/auth/RequireStudentAuth";

const TRANSMISSION_TYPES = {
  manual: { label: "Manual", icon: Gauge, color: "blue" },
  automatic: { label: "Automatic", icon: Zap, color: "purple" }
};

const LICENSE_CATEGORIES = {
  B: { label: "Car (B)", color: "blue" },
  A: { label: "Motorcycle (A)", color: "red" },
  C: { label: "Truck (C)", color: "amber" },
  D: { label: "Bus (D)", color: "purple" },
  BE: { label: "Trailer (BE)", color: "cyan" }
};

const SPECIALIZATIONS = [
  { id: "nervous", label: "Nervous Drivers", icon: Heart },
  { id: "intensive", label: "Intensive Courses", icon: Target },
  { id: "refresher", label: "Refresher", icon: Route },
  { id: "motorway", label: "Motorway", icon: Navigation },
  { id: "night", label: "Night Driving", icon: Moon },
  { id: "defensive", label: "Defensive", icon: Shield }
];

export default function SchoolCard({ 
  school, 
  instructors = [], 
  vehicles = [], 
  packages = [], 
  reviews = [],
  bookings = [],
  onHover,
  onSelect,
  isHighlighted = false,
  isSaved = false,
  onSave,
  viewMode = "list",
  showQuickActions = true,
  showAvailability = true,
  className = ""
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showContact, setShowContact] = useState(false);

  const schoolInstructors = useMemo(() => 
    instructors.filter(i => i.school_id === school.id && i.is_active !== false),
    [instructors, school.id]
  );

  const schoolVehicles = useMemo(() => 
    vehicles.filter(v => v.school_id === school.id && v.is_available !== false),
    [vehicles, school.id]
  );

  const schoolPackages = useMemo(() => 
    packages.filter(p => p.school_id === school.id && p.is_active !== false)
      .sort((a, b) => (a.total_price || 0) - (b.total_price || 0)),
    [packages, school.id]
  );

  const schoolReviews = useMemo(() => 
    reviews.filter(r => r.school_id === school.id),
    [reviews, school.id]
  );

  const schoolBookings = useMemo(() =>
    bookings.filter(b => 
      schoolInstructors.some(i => i.id === b.instructor_id)
    ),
    [bookings, schoolInstructors]
  );

  const stats = useMemo(() => {
    const totalReviews = school.total_reviews || schoolReviews.length;
    const rating = school.rating || (totalReviews > 0 
      ? schoolReviews.reduce((sum, r) => sum + (r.rating || 5), 0) / totalReviews 
      : 5.0);

    const startingPrice = schoolPackages.length > 0 
      ? Math.min(...schoolPackages.map(p => p.total_price || p.price_per_lesson || 45)) 
      : school.starting_price || 45;

    const hasManual = schoolVehicles.some(v => v.transmission === "manual");
    const hasAutomatic = schoolVehicles.some(v => v.transmission === "automatic");

    const certifications = [...new Set(
      schoolInstructors.flatMap(i => i.certifications || [])
    )];

    const languages = [...new Set(
      schoolInstructors.flatMap(i => i.languages || [])
    )];

    const completedLessons = schoolBookings.filter(b => b.status === "completed").length;
    const passRate = school.pass_rate || 92;

    const recentBookings = schoolBookings.filter(b => {
      const date = new Date(b.created_date);
      return differenceInDays(new Date(), date) <= 7;
    }).length;

    const availableSlots = school.available_slots || Math.max(0, 10 - recentBookings);

    const responseTime = school.avg_response_time || "< 1 hour";

    return {
      rating: Math.round(rating * 10) / 10,
      totalReviews,
      startingPrice,
      instructorCount: schoolInstructors.length,
      vehicleCount: schoolVehicles.length,
      packageCount: schoolPackages.length,
      hasManual,
      hasAutomatic,
      certifications,
      languages,
      completedLessons,
      passRate,
      availableSlots,
      responseTime,
      recentBookings
    };
  }, [school, schoolInstructors, schoolVehicles, schoolPackages, schoolReviews, schoolBookings]);

  const story = useMemo(() => {
    if (school.description) return school.description;
    if (school.short_description) return school.short_description;
    return "Professional driving instruction with experienced, certified instructors. We help you become a confident, safe driver.";
  }, [school]);

  const highlights = useMemo(() => {
    const items = [];
    
    if (stats.passRate >= 90) {
      items.push({ icon: Target, label: `${stats.passRate}% Pass Rate`, color: "green" });
    }
    
    if (stats.instructorCount >= 3) {
      items.push({ icon: Users, label: `${stats.instructorCount} Instructors`, color: "blue" });
    }
    
    if (stats.hasManual && stats.hasAutomatic) {
      items.push({ icon: Car, label: "Manual & Auto", color: "purple" });
    }

    if (school.is_verified) {
      items.push({ icon: BadgeCheck, label: "Verified", color: "indigo" });
    }

    if (stats.languages.length > 2) {
      items.push({ icon: Globe, label: `${stats.languages.length} Languages`, color: "cyan" });
    }

    return items.slice(0, 4);
  }, [stats, school]);

  const featuredServices = useMemo(() => {
    if (schoolPackages.length > 0) {
      return schoolPackages.slice(0, 3).map(pkg => ({
        name: pkg.name || pkg.title,
        price: pkg.total_price || pkg.price_per_lesson,
        duration: pkg.lesson_count ? `${pkg.lesson_count} lessons` : null,
        isPopular: pkg.is_popular
      }));
    }

    return [
      { name: "Standard Driving Lesson", price: stats.startingPrice, duration: "60 min" },
      { name: "Test Preparation", price: stats.startingPrice + 15, duration: "90 min" },
      { name: "Intensive Course", price: stats.startingPrice * 10, duration: "10 lessons" }
    ];
  }, [schoolPackages, stats.startingPrice]);

  const handleCardClick = useCallback(() => {
    if (onSelect) {
      onSelect(school);
    }
  }, [onSelect, school]);

  const handleSaveClick = useCallback((e) => {
    e.stopPropagation();
    e.preventDefault();
    if (onSave) {
      onSave(school.id);
    }
  }, [onSave, school.id]);

  const handleShareClick = useCallback((e) => {
    e.stopPropagation();
    e.preventDefault();
    if (navigator.share) {
      navigator.share({
        title: school.name,
        text: `Check out ${school.name} - Driving School`,
        url: `${window.location.origin}${createPageUrl("SchoolProfile")}?id=${school.id}`
      });
    } else {
      navigator.clipboard.writeText(
        `${window.location.origin}${createPageUrl("SchoolProfile")}?id=${school.id}`
      );
    }
  }, [school]);

  const renderRatingStars = (rating) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    return (
      <div className="flex items-center gap-0.5">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`w-3.5 h-3.5 ${
              i < fullStars 
                ? "text-amber-400 fill-amber-400" 
                : i === fullStars && hasHalfStar
                  ? "text-amber-400 fill-amber-200"
                  : "text-gray-300"
            }`}
          />
        ))}
      </div>
    );
  };

  if (viewMode === "compact") {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        onMouseEnter={() => onHover?.(school.id)}
        onMouseLeave={() => onHover?.(null)}
        onClick={handleCardClick}
        className={`bg-white rounded-xl border p-4 transition-all cursor-pointer ${
          isHighlighted 
            ? "border-indigo-500 shadow-lg" 
            : "border-gray-200 hover:border-gray-300 hover:shadow-md"
        } ${className}`}
      >
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
            {school.logo_url || school.cover_image_url ? (
              <img 
                src={school.logo_url || school.cover_image_url} 
                alt={school.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center">
                <span className="text-white text-xl font-bold">
                  {school.name?.charAt(0) || "S"}
                </span>
              </div>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-gray-900 truncate">{school.name}</h3>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <MapPin className="w-3.5 h-3.5" />
              <span className="truncate">{school.city || school.address}</span>
            </div>
            <div className="flex items-center gap-2 mt-1">
              {renderRatingStars(stats.rating)}
              <span className="text-sm font-semibold text-gray-900">{stats.rating}</span>
              <span className="text-xs text-gray-500">({stats.totalReviews})</span>
            </div>
          </div>

          <div className="text-right">
            <p className="text-xs text-gray-500">From</p>
            <p className="text-lg font-bold text-gray-900">€{stats.startingPrice}</p>
          </div>
        </div>
      </motion.div>
    );
  }

  if (viewMode === "grid") {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        onMouseEnter={() => onHover?.(school.id)}
        onMouseLeave={() => onHover?.(null)}
        onClick={handleCardClick}
        className={`bg-white rounded-2xl border overflow-hidden transition-all cursor-pointer group ${
          isHighlighted 
            ? "border-indigo-500 shadow-xl scale-[1.02]" 
            : "border-gray-200 hover:border-gray-300 hover:shadow-lg"
        } ${className}`}
      >
        <div className="relative h-40 overflow-hidden">
          {school.cover_image_url ? (
            <img 
              src={school.cover_image_url} 
              alt={school.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500" />
          )}
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

          <div className="absolute top-3 left-3 flex gap-2">
            {school.is_featured && (
              <span className="px-2 py-1 bg-amber-500 text-white rounded-full text-xs font-bold flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Featured
              </span>
            )}
            {school.is_verified && (
              <span className="px-2 py-1 bg-green-500 text-white rounded-full text-xs font-bold flex items-center gap-1">
                <BadgeCheck className="w-3 h-3" />
                Verified
              </span>
            )}
          </div>

          {showQuickActions && (
            <div className="absolute top-3 right-3 flex gap-2">
              <button
                onClick={handleSaveClick}
                className="p-2 bg-white/90 hover:bg-white rounded-full transition shadow-sm"
              >
                {isSaved ? (
                  <BookmarkCheck className="w-4 h-4 text-indigo-600" />
                ) : (
                  <Bookmark className="w-4 h-4 text-gray-600" />
                )}
              </button>
              <button
                onClick={handleShareClick}
                className="p-2 bg-white/90 hover:bg-white rounded-full transition shadow-sm"
              >
                <Share2 className="w-4 h-4 text-gray-600" />
              </button>
            </div>
          )}

          <div className="absolute bottom-3 left-3 right-3">
            <h3 className="font-bold text-white text-lg mb-1 drop-shadow-md">
              {school.name}
            </h3>
            <div className="flex items-center gap-2 text-white/90 text-sm">
              <MapPin className="w-3.5 h-3.5" />
              <span>{school.city || school.address}</span>
            </div>
          </div>
        </div>

        <div className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 px-2.5 py-1 bg-amber-50 rounded-lg">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span className="font-bold text-gray-900">{stats.rating}</span>
              </div>
              <span className="text-sm text-gray-500">({stats.totalReviews})</span>
            </div>
            {stats.passRate >= 85 && (
              <span className="text-xs font-semibold text-green-700 bg-green-50 px-2.5 py-1 rounded-lg">
                {stats.passRate}% Pass
              </span>
            )}
          </div>

          {highlights.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {highlights.map((highlight, idx) => (
                <span 
                  key={idx}
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-medium`}
                >
                  <highlight.icon className="w-3.5 h-3.5" />
                  {highlight.label}
                </span>
              ))}
            </div>
          )}

          <p className="text-sm text-gray-600 leading-relaxed mb-5 line-clamp-2">{story}</p>

          <div className="flex items-center justify-between pt-4 border-t border-gray-100">
            <div>
              <p className="text-xs text-gray-500 mb-1">Starting from</p>
              <p className="text-xl font-bold text-gray-900">€{stats.startingPrice}</p>
            </div>
            <div className="flex items-center gap-2">
              <RequireStudentAuth
                schoolId={school.id}
                schoolName={school.name}
                action="book"
                onAuthenticated={() => {
                  window.location.href = `${createPageUrl("BookLesson")}?schoolId=${school.id}`;
                }}
              >
                <button className="px-4 py-2 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl text-sm font-semibold transition">
                  Book
                </button>
              </RequireStudentAuth>
              <Link
                to={`${createPageUrl("SchoolProfile")}?id=${school.id}`}
                onClick={(e) => e.stopPropagation()}
                className="px-4 py-2 border-2 border-slate-200 hover:border-slate-300 text-slate-700 rounded-xl text-sm font-semibold transition flex items-center gap-1"
              >
                Details
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onMouseEnter={() => onHover?.(school.id)}
      onMouseLeave={() => onHover?.(null)}
      className={`bg-white rounded-2xl border transition-all cursor-pointer group ${
        isHighlighted 
          ? "border-indigo-500 shadow-xl scale-[1.01]" 
          : "border-gray-200 hover:border-gray-300 hover:shadow-lg"
      } ${className}`}
    >
      <div className="flex flex-col md:flex-row">
        <div className="relative w-full md:w-56 h-48 md:h-auto flex-shrink-0 overflow-hidden rounded-t-2xl md:rounded-l-2xl md:rounded-tr-none">
          {school.cover_image_url ? (
            <img 
              src={school.cover_image_url} 
              alt={school.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500" />
          )}

          <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent md:bg-gradient-to-r" />

          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {school.is_featured && (
              <span className="px-2.5 py-1 bg-amber-500 text-white rounded-full text-xs font-bold flex items-center gap-1 w-fit">
                <Sparkles className="w-3 h-3" />
                Featured
              </span>
            )}
            {school.is_verified && (
              <span className="px-2.5 py-1 bg-green-500 text-white rounded-full text-xs font-bold flex items-center gap-1 w-fit">
                <BadgeCheck className="w-3 h-3" />
                Verified
              </span>
            )}
            {stats.availableSlots > 0 && stats.availableSlots <= 3 && showAvailability && (
              <span className="px-2.5 py-1 bg-red-500 text-white rounded-full text-xs font-bold flex items-center gap-1 w-fit">
                <Zap className="w-3 h-3" />
                {stats.availableSlots} slots left
              </span>
            )}
          </div>

          {showQuickActions && (
            <div className="absolute top-3 right-3 flex gap-2">
              <button
                onClick={handleSaveClick}
                className="p-2 bg-white/90 hover:bg-white rounded-full transition shadow-md"
              >
                {isSaved ? (
                  <BookmarkCheck className="w-4 h-4 text-indigo-600" />
                ) : (
                  <Bookmark className="w-4 h-4 text-gray-600" />
                )}
              </button>
              <button
                onClick={handleShareClick}
                className="p-2 bg-white/90 hover:bg-white rounded-full transition shadow-md"
              >
                <Share2 className="w-4 h-4 text-gray-600" />
              </button>
            </div>
          )}

          {school.logo_url && (
            <div className="absolute bottom-3 left-3 w-12 h-12 bg-white rounded-xl shadow-lg overflow-hidden">
              <img 
                src={school.logo_url} 
                alt={`${school.name} logo`}
                className="w-full h-full object-cover"
              />
            </div>
          )}
        </div>

        <div className="flex-1 p-5 flex flex-col" onClick={handleCardClick}>
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1 min-w-0 pr-3">
              <h3 className="font-bold text-gray-900 text-lg mb-2 group-hover:text-[#3b82c4] transition-colors">
                {school.name}
              </h3>
              <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                <MapPin className="w-4 h-4 flex-shrink-0" />
                <span className="truncate">{school.city || school.address}</span>
                {school.distance && (
                  <>
                    <span className="text-gray-300">•</span>
                    <span className="whitespace-nowrap">{school.distance.toFixed(1)} km</span>
                  </>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1 px-3 py-1.5 bg-amber-50 rounded-xl flex-shrink-0">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span className="text-base font-bold text-gray-900">{stats.rating}</span>
              <span className="text-xs text-gray-500">({stats.totalReviews})</span>
            </div>
          </div>

          {highlights.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {highlights.map((highlight, idx) => (
                <span 
                  key={idx}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-medium"
                >
                  <highlight.icon className="w-3.5 h-3.5" />
                  {highlight.label}
                </span>
              ))}
            </div>
          )}

          <p className="text-sm text-gray-600 leading-relaxed mb-5 line-clamp-2">
            {story}
          </p>

          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-5 space-y-4 overflow-hidden"
              >
                {stats.languages.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-gray-600 mb-2">Languages</p>
                    <div className="flex flex-wrap gap-1.5">
                      {stats.languages.map(lang => (
                        <span key={lang} className="px-2.5 py-1 bg-gray-100 rounded-lg text-xs text-gray-700 font-medium">
                          {lang}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {stats.certifications.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-gray-600 mb-2">Categories</p>
                    <div className="flex flex-wrap gap-1.5">
                      {stats.certifications.slice(0, 6).map(cert => (
                        <span key={cert} className="px-2.5 py-1 bg-blue-50 text-blue-700 rounded-lg text-xs font-semibold">
                          {cert}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-3 gap-3">
                  <div className="p-3 bg-indigo-50 rounded-xl text-center">
                    <p className="text-lg font-bold text-indigo-600">{stats.instructorCount}</p>
                    <p className="text-xs text-indigo-900 font-medium">Instructors</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-xl text-center">
                    <p className="text-lg font-bold text-green-600">{stats.vehicleCount}</p>
                    <p className="text-xs text-green-900 font-medium">Vehicles</p>
                  </div>
                  <div className="p-3 bg-amber-50 rounded-xl text-center">
                    <p className="text-lg font-bold text-amber-600">{stats.completedLessons}</p>
                    <p className="text-xs text-amber-900 font-medium">Lessons</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="mt-auto pt-5 border-t border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-xs text-gray-500 mb-1">Starting from</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-gray-900">€{stats.startingPrice}</span>
                  <span className="text-sm text-gray-500">/lesson</span>
                </div>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsExpanded(!isExpanded);
                }}
                className="p-2.5 border border-gray-200 hover:bg-gray-50 rounded-xl transition"
              >
                {isExpanded ? (
                  <ChevronUp className="w-5 h-5 text-gray-600" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-600" />
                )}
              </button>
            </div>
            
            <div className="flex items-center gap-2">
              <RequireStudentAuth
                schoolId={school.id}
                schoolName={school.name}
                action="book"
                onAuthenticated={() => {
                  window.location.href = `${createPageUrl("BookLesson")}?schoolId=${school.id}`;
                }}
              >
                <button className="flex-1 py-3 bg-[#3b82c4] hover:bg-[#2563a3] text-white rounded-xl text-sm font-semibold transition">
                  Book Lesson
                </button>
              </RequireStudentAuth>
              
              <Link
                to={`${createPageUrl("SchoolProfile")}?id=${school.id}`}
                onClick={(e) => e.stopPropagation()}
                className="flex-1 py-3 border-2 border-slate-200 hover:border-slate-300 text-slate-700 rounded-xl text-sm font-semibold transition text-center"
              >
                Details
              </Link>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}