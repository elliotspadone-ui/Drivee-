import React, { useState, useEffect, useMemo, useCallback } from "react";
import { 
  X, 
  ChevronDown, 
  ChevronUp,
  Star,
  MapPin,
  Car,
  Users,
  Calendar,
  Clock,
  DollarSign,
  Globe,
  Filter,
  RotateCcw,
  Check,
  Sliders,
  Target,
  Zap,
  Shield,
  Heart,
  Route,
  Moon,
  Award,
  BadgeCheck,
  Gauge,
  Navigation,
  Sparkles,
  TrendingUp,
  Search,
  Info,
  AlertCircle,
  CheckCircle,
  XCircle,
  Loader2,
  ChevronRight,
  ChevronLeft
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const LICENSE_CATEGORIES = [
  { id: "all", label: "All Categories" },
  { id: "B", label: "Car (B)", description: "Standard car license" },
  { id: "A", label: "Motorcycle (A)", description: "Motorcycle license" },
  { id: "A1", label: "Light Motorcycle (A1)", description: "Up to 125cc" },
  { id: "A2", label: "Medium Motorcycle (A2)", description: "Up to 35kW" },
  { id: "C", label: "Truck (C)", description: "Heavy goods vehicle" },
  { id: "C1", label: "Light Truck (C1)", description: "Up to 7.5 tonnes" },
  { id: "D", label: "Bus (D)", description: "Passenger transport" },
  { id: "D1", label: "Minibus (D1)", description: "Up to 16 passengers" },
  { id: "BE", label: "Car + Trailer (BE)", description: "Car with trailer" },
  { id: "CE", label: "Truck + Trailer (CE)", description: "Heavy with trailer" }
];

const TRANSMISSION_OPTIONS = [
  { id: "all", label: "Any Transmission" },
  { id: "manual", label: "Manual Only" },
  { id: "automatic", label: "Automatic Only" },
  { id: "both", label: "Both Available" }
];

const PRICE_RANGES = [
  { id: "all", label: "Any Price", min: 0, max: Infinity },
  { id: "budget", label: "Budget (Under €35/hr)", min: 0, max: 35 },
  { id: "standard", label: "Standard (€35-€50/hr)", min: 35, max: 50 },
  { id: "premium", label: "Premium (€50-€75/hr)", min: 50, max: 75 },
  { id: "luxury", label: "Luxury (€75+/hr)", min: 75, max: Infinity }
];

const PACKAGE_PRICE_RANGES = [
  { id: "all", label: "Any Package Price", min: 0, max: Infinity },
  { id: "low", label: "Under €500", min: 0, max: 500 },
  { id: "medium", label: "€500 - €1,000", min: 500, max: 1000 },
  { id: "high", label: "€1,000 - €2,000", min: 1000, max: 2000 },
  { id: "premium", label: "Over €2,000", min: 2000, max: Infinity }
];

const RATING_OPTIONS = [
  { id: 0, label: "Any Rating", stars: 0 },
  { id: 4.5, label: "4.5+ Excellent", stars: 5 },
  { id: 4, label: "4.0+ Very Good", stars: 4 },
  { id: 3.5, label: "3.5+ Good", stars: 3 },
  { id: 3, label: "3.0+ Average", stars: 3 }
];

const SPECIALIZATIONS = [
  { id: "nervous", label: "Nervous Drivers", icon: Heart, description: "Patient instructors for anxious learners" },
  { id: "intensive", label: "Intensive Courses", icon: Target, description: "Fast-track learning programs" },
  { id: "refresher", label: "Refresher Lessons", icon: RotateCcw, description: "For returning drivers" },
  { id: "motorway", label: "Motorway Driving", icon: Route, description: "Highway driving practice" },
  { id: "night", label: "Night Driving", icon: Moon, description: "Evening and night lessons" },
  { id: "defensive", label: "Defensive Driving", icon: Shield, description: "Advanced safety techniques" },
  { id: "eco", label: "Eco Driving", icon: Sparkles, description: "Fuel-efficient driving" },
  { id: "pass_plus", label: "Pass Plus", icon: Award, description: "Post-test advanced course" }
];

const AVAILABILITY_OPTIONS = [
  { id: "all", label: "Any Availability" },
  { id: "today", label: "Available Today" },
  { id: "this_week", label: "This Week" },
  { id: "weekends", label: "Weekends Only" },
  { id: "evenings", label: "Evenings Only" },
  { id: "early_morning", label: "Early Morning" }
];

const DISTANCE_OPTIONS = [
  { id: 5, label: "Within 5 km" },
  { id: 10, label: "Within 10 km" },
  { id: 25, label: "Within 25 km" },
  { id: 50, label: "Within 50 km" },
  { id: 100, label: "Within 100 km" },
  { id: Infinity, label: "Any Distance" }
];

const EXPERIENCE_LEVELS = [
  { id: "all", label: "Any Experience" },
  { id: "beginner", label: "Complete Beginners" },
  { id: "some", label: "Some Experience" },
  { id: "test_ready", label: "Test Ready" },
  { id: "licensed", label: "Licensed Drivers" }
];

const SORT_OPTIONS = [
  { id: "relevance", label: "Most Relevant", icon: Sparkles },
  { id: "rating", label: "Highest Rated", icon: Star },
  { id: "price_low", label: "Price: Low to High", icon: DollarSign },
  { id: "price_high", label: "Price: High to Low", icon: DollarSign },
  { id: "distance", label: "Nearest First", icon: Navigation },
  { id: "reviews", label: "Most Reviews", icon: Users },
  { id: "pass_rate", label: "Best Pass Rate", icon: Target },
  { id: "newest", label: "Recently Added", icon: Clock }
];

const DEFAULT_FILTERS = {
  city: "all",
  transmission: "all",
  priceRange: "all",
  packagePriceRange: "all",
  language: "all",
  category: "all",
  rating: 0,
  hasAvailability: false,
  isVerified: false,
  isFeatured: false,
  specializations: [],
  availability: "all",
  distance: Infinity,
  experienceLevel: "all",
  hasPickup: false,
  acceptsPaymentPlan: false,
  hasOnlineBooking: false,
  minPassRate: 0,
  instructorGender: "all",
  vehicleType: "all"
};

export default function FiltersPanel({ 
  show,
  onClose,
  filters = DEFAULT_FILTERS,
  onFilterChange,
  onFiltersChange,
  cities = [],
  languages = [],
  onReset,
  onApply,
  resultCount = 0,
  isLoading = false,
  sortBy = "relevance",
  onSortChange,
  showSortOptions = true,
  variant = "panel",
  className = ""
}) {
  const [localFilters, setLocalFilters] = useState({ ...DEFAULT_FILTERS, ...filters });
  const [expandedSections, setExpandedSections] = useState({
    location: true,
    vehicle: true,
    price: true,
    rating: false,
    specializations: false,
    availability: false,
    additional: false
  });
  const [searchCity, setSearchCity] = useState("");
  const [searchLanguage, setSearchLanguage] = useState("");

  useEffect(() => {
    setLocalFilters({ ...DEFAULT_FILTERS, ...filters });
  }, [filters]);

  const filteredCities = useMemo(() => {
    if (!searchCity) return cities;
    return cities.filter(city => 
      city.toLowerCase().includes(searchCity.toLowerCase())
    );
  }, [cities, searchCity]);

  const filteredLanguages = useMemo(() => {
    if (!searchLanguage) return languages;
    return languages.filter(lang => 
      lang.toLowerCase().includes(searchLanguage.toLowerCase())
    );
  }, [languages, searchLanguage]);

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (localFilters.city !== "all") count++;
    if (localFilters.transmission !== "all") count++;
    if (localFilters.priceRange !== "all") count++;
    if (localFilters.packagePriceRange !== "all") count++;
    if (localFilters.language !== "all") count++;
    if (localFilters.category !== "all") count++;
    if (localFilters.rating > 0) count++;
    if (localFilters.hasAvailability) count++;
    if (localFilters.isVerified) count++;
    if (localFilters.isFeatured) count++;
    if (localFilters.specializations.length > 0) count += localFilters.specializations.length;
    if (localFilters.availability !== "all") count++;
    if (localFilters.distance < Infinity) count++;
    if (localFilters.experienceLevel !== "all") count++;
    if (localFilters.hasPickup) count++;
    if (localFilters.acceptsPaymentPlan) count++;
    if (localFilters.hasOnlineBooking) count++;
    if (localFilters.minPassRate > 0) count++;
    if (localFilters.instructorGender !== "all") count++;
    if (localFilters.vehicleType !== "all") count++;
    return count;
  }, [localFilters]);

  const handleFilterChange = useCallback((key, value) => {
    setLocalFilters(prev => ({ ...prev, [key]: value }));
    if (onFilterChange) {
      onFilterChange(key, value);
    }
  }, [onFilterChange]);

  const handleToggleSpecialization = useCallback((specId) => {
    setLocalFilters(prev => ({
      ...prev,
      specializations: prev.specializations.includes(specId)
        ? prev.specializations.filter(s => s !== specId)
        : [...prev.specializations, specId]
    }));
  }, []);

  const handleReset = useCallback(() => {
    setLocalFilters(DEFAULT_FILTERS);
    if (onReset) {
      onReset();
    }
  }, [onReset]);

  const handleApply = useCallback(() => {
    if (onFiltersChange) {
      onFiltersChange(localFilters);
    }
    if (onApply) {
      onApply(localFilters);
    }
    if (onClose) {
      onClose();
    }
  }, [localFilters, onFiltersChange, onApply, onClose]);

  const toggleSection = useCallback((section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  }, []);

  const renderSectionHeader = (title, section, icon) => (
    <button
      onClick={() => toggleSection(section)}
      className="w-full flex items-center justify-between py-3 text-left"
    >
      <div className="flex items-center gap-2">
        {icon}
        <span className="font-semibold text-slate-900">{title}</span>
      </div>
      {expandedSections[section] ? (
        <ChevronUp className="w-5 h-5 text-slate-400" />
      ) : (
        <ChevronDown className="w-5 h-5 text-slate-400" />
      )}
    </button>
  );

  const renderSelectField = (label, value, options, onChange, searchable = false, searchValue = "", onSearchChange = null) => (
    <div>
      <label className="block text-sm font-medium text-slate-700 mb-2">{label}</label>
      {searchable && options.length > 10 ? (
        <div className="space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder={`Search ${label.toLowerCase()}...`}
              value={searchValue}
              onChange={(e) => onSearchChange?.(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
            />
          </div>
          <select
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm cursor-pointer"
          >
            {options.map(opt => (
              <option key={typeof opt === "string" ? opt : opt.id} value={typeof opt === "string" ? opt : opt.id}>
                {typeof opt === "string" ? opt : opt.label}
              </option>
            ))}
          </select>
        </div>
      ) : (
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm cursor-pointer"
        >
          {options.map(opt => (
            <option key={typeof opt === "string" ? opt : opt.id} value={typeof opt === "string" ? opt : opt.id}>
              {typeof opt === "string" ? opt : opt.label}
            </option>
          ))}
        </select>
      )}
    </div>
  );

  const renderCheckboxField = (label, description, checked, onChange, icon = null) => (
    <label className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl cursor-pointer hover:bg-slate-100 transition">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="w-5 h-5 text-indigo-600 rounded mt-0.5"
      />
      <div className="flex-1">
        <div className="flex items-center gap-2">
          {icon}
          <span className="text-sm font-medium text-slate-900">{label}</span>
        </div>
        {description && (
          <p className="text-xs text-slate-500 mt-0.5">{description}</p>
        )}
      </div>
    </label>
  );

  const renderRatingButtons = () => (
    <div className="space-y-2">
      {RATING_OPTIONS.map(option => (
        <button
          key={option.id}
          onClick={() => handleFilterChange("rating", option.id)}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition text-left ${
            localFilters.rating === option.id
              ? "bg-indigo-100 text-indigo-700 font-medium border-2 border-indigo-300"
              : "bg-slate-50 text-slate-700 hover:bg-slate-100 border border-transparent"
          }`}
        >
          {option.id > 0 && (
            <div className="flex items-center gap-0.5">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < Math.floor(option.id)
                      ? "text-amber-500 fill-amber-500"
                      : "text-slate-300"
                  }`}
                />
              ))}
            </div>
          )}
          <span className="flex-1">{option.label}</span>
          {localFilters.rating === option.id && (
            <Check className="w-4 h-4 text-indigo-600" />
          )}
        </button>
      ))}
    </div>
  );

  if (!show) return null;

  if (variant === "sidebar") {
    return (
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        className={`bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden ${className}`}
      >
        <div className="sticky top-0 bg-white border-b border-slate-200 p-4 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-indigo-600" />
              <h3 className="font-bold text-slate-900">Filters</h3>
              {activeFilterCount > 0 && (
                <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 text-xs font-bold rounded-full">
                  {activeFilterCount}
                </span>
              )}
            </div>
            {activeFilterCount > 0 && (
              <button
                onClick={handleReset}
                className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
              >
                Reset all
              </button>
            )}
          </div>
        </div>

        <div className="p-4 space-y-4 max-h-[calc(100vh-200px)] overflow-y-auto">
          {renderSelectField(
            "City",
            localFilters.city,
            [{ id: "all", label: "All Cities" }, ...filteredCities.map(c => ({ id: c, label: c }))],
            (value) => handleFilterChange("city", value),
            true,
            searchCity,
            setSearchCity
          )}

          {renderSelectField(
            "License Category",
            localFilters.category,
            LICENSE_CATEGORIES,
            (value) => handleFilterChange("category", value)
          )}

          {renderSelectField(
            "Transmission",
            localFilters.transmission,
            TRANSMISSION_OPTIONS,
            (value) => handleFilterChange("transmission", value)
          )}

          {renderSelectField(
            "Price per Lesson",
            localFilters.priceRange,
            PRICE_RANGES,
            (value) => handleFilterChange("priceRange", value)
          )}

          {renderSelectField(
            "Language",
            localFilters.language,
            [{ id: "all", label: "All Languages" }, ...filteredLanguages.map(l => ({ id: l, label: l }))],
            (value) => handleFilterChange("language", value),
            true,
            searchLanguage,
            setSearchLanguage
          )}

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Minimum Rating</label>
            {renderRatingButtons()}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Quick Filters</label>
            {renderCheckboxField(
              "Verified Schools",
              "Background checked instructors",
              localFilters.isVerified,
              (checked) => handleFilterChange("isVerified", checked),
              <BadgeCheck className="w-4 h-4 text-green-600" />
            )}
            {renderCheckboxField(
              "Available Now",
              "Has slots this week",
              localFilters.hasAvailability,
              (checked) => handleFilterChange("hasAvailability", checked),
              <Calendar className="w-4 h-4 text-blue-600" />
            )}
            {renderCheckboxField(
              "Online Booking",
              "Book instantly online",
              localFilters.hasOnlineBooking,
              (checked) => handleFilterChange("hasOnlineBooking", checked),
              <Zap className="w-4 h-4 text-amber-600" />
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Specializations</label>
            <div className="flex flex-wrap gap-2">
              {SPECIALIZATIONS.map(spec => (
                <button
                  key={spec.id}
                  onClick={() => handleToggleSpecialization(spec.id)}
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
                    localFilters.specializations.includes(spec.id)
                      ? "bg-indigo-100 text-indigo-700 border-2 border-indigo-300"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200 border border-transparent"
                  }`}
                  title={spec.description}
                >
                  <spec.icon className="w-3.5 h-3.5" />
                  {spec.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="sticky bottom-0 bg-white border-t border-slate-200 p-4">
          <button
            onClick={handleApply}
            disabled={isLoading}
            className="w-full px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl transition disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <span>Show {resultCount} Results</span>
              </>
            )}
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      className={`bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden ${className}`}
    >
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center">
              <Sliders className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">Filters</h3>
              <p className="text-sm text-slate-500">
                {activeFilterCount > 0 
                  ? `${activeFilterCount} filter${activeFilterCount !== 1 ? 's' : ''} applied`
                  : "Refine your search results"
                }
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {activeFilterCount > 0 && (
              <button
                onClick={handleReset}
                className="px-3 py-1.5 text-sm text-indigo-600 hover:bg-indigo-50 rounded-lg font-medium transition flex items-center gap-1"
              >
                <RotateCcw className="w-4 h-4" />
                Reset
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-100 rounded-lg transition"
            >
              <X className="w-5 h-5 text-slate-500" />
            </button>
          </div>
        </div>

        <div className="border-b border-slate-200">
          {renderSectionHeader("Location & Category", "location", <MapPin className="w-5 h-5 text-slate-400" />)}
          <AnimatePresence>
            {expandedSections.location && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4"
              >
                {renderSelectField(
                  "City",
                  localFilters.city,
                  [{ id: "all", label: "All Cities" }, ...filteredCities.map(c => ({ id: c, label: c }))],
                  (value) => handleFilterChange("city", value),
                  cities.length > 10,
                  searchCity,
                  setSearchCity
                )}
                {renderSelectField(
                  "License Category",
                  localFilters.category,
                  LICENSE_CATEGORIES,
                  (value) => handleFilterChange("category", value)
                )}
                {renderSelectField(
                  "Maximum Distance",
                  localFilters.distance,
                  DISTANCE_OPTIONS,
                  (value) => handleFilterChange("distance", parseFloat(value))
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="border-b border-slate-200">
          {renderSectionHeader("Vehicle & Transmission", "vehicle", <Car className="w-5 h-5 text-slate-400" />)}
          <AnimatePresence>
            {expandedSections.vehicle && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4"
              >
                {renderSelectField(
                  "Transmission",
                  localFilters.transmission,
                  TRANSMISSION_OPTIONS,
                  (value) => handleFilterChange("transmission", value)
                )}
                {renderSelectField(
                  "Experience Level",
                  localFilters.experienceLevel,
                  EXPERIENCE_LEVELS,
                  (value) => handleFilterChange("experienceLevel", value)
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="border-b border-slate-200">
          {renderSectionHeader("Price Range", "price", <DollarSign className="w-5 h-5 text-slate-400" />)}
          <AnimatePresence>
            {expandedSections.price && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4"
              >
                {renderSelectField(
                  "Price per Lesson",
                  localFilters.priceRange,
                  PRICE_RANGES,
                  (value) => handleFilterChange("priceRange", value)
                )}
                {renderSelectField(
                  "Package Price",
                  localFilters.packagePriceRange,
                  PACKAGE_PRICE_RANGES,
                  (value) => handleFilterChange("packagePriceRange", value)
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="border-b border-slate-200">
          {renderSectionHeader("Rating & Reviews", "rating", <Star className="w-5 h-5 text-slate-400" />)}
          <AnimatePresence>
            {expandedSections.rating && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="pb-4"
              >
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                  {RATING_OPTIONS.map(option => (
                    <button
                      key={option.id}
                      onClick={() => handleFilterChange("rating", option.id)}
                      className={`flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-sm transition ${
                        localFilters.rating === option.id
                          ? "bg-indigo-100 text-indigo-700 font-semibold border-2 border-indigo-300"
                          : "bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200"
                      }`}
                    >
                      {option.id > 0 && <Star className="w-4 h-4 text-amber-500 fill-amber-500" />}
                      {option.label.split(" ")[0]}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="border-b border-slate-200">
          {renderSectionHeader("Specializations", "specializations", <Target className="w-5 h-5 text-slate-400" />)}
          <AnimatePresence>
            {expandedSections.specializations && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="pb-4"
              >
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {SPECIALIZATIONS.map(spec => (
                    <button
                      key={spec.id}
                      onClick={() => handleToggleSpecialization(spec.id)}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm transition text-left ${
                        localFilters.specializations.includes(spec.id)
                          ? "bg-indigo-100 text-indigo-700 font-medium border-2 border-indigo-300"
                          : "bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200"
                      }`}
                      title={spec.description}
                    >
                      <spec.icon className="w-4 h-4 flex-shrink-0" />
                      <span className="truncate">{spec.label}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="border-b border-slate-200">
          {renderSectionHeader("Availability", "availability", <Calendar className="w-5 h-5 text-slate-400" />)}
          <AnimatePresence>
            {expandedSections.availability && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4"
              >
                {renderSelectField(
                  "Availability",
                  localFilters.availability,
                  AVAILABILITY_OPTIONS,
                  (value) => handleFilterChange("availability", value)
                )}
                {renderSelectField(
                  "Language",
                  localFilters.language,
                  [{ id: "all", label: "All Languages" }, ...filteredLanguages.map(l => ({ id: l, label: l }))],
                  (value) => handleFilterChange("language", value),
                  languages.length > 10,
                  searchLanguage,
                  setSearchLanguage
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div>
          {renderSectionHeader("Additional Options", "additional", <Sliders className="w-5 h-5 text-slate-400" />)}
          <AnimatePresence>
            {expandedSections.additional && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-3 pb-4"
              >
                {renderCheckboxField(
                  "Verified Schools",
                  "Background checked & approved",
                  localFilters.isVerified,
                  (checked) => handleFilterChange("isVerified", checked),
                  <BadgeCheck className="w-4 h-4 text-green-600" />
                )}
                {renderCheckboxField(
                  "Available Now",
                  "Has open slots this week",
                  localFilters.hasAvailability,
                  (checked) => handleFilterChange("hasAvailability", checked),
                  <Clock className="w-4 h-4 text-blue-600" />
                )}
                {renderCheckboxField(
                  "Featured Schools",
                  "Top-rated & recommended",
                  localFilters.isFeatured,
                  (checked) => handleFilterChange("isFeatured", checked),
                  <Sparkles className="w-4 h-4 text-amber-600" />
                )}
                {renderCheckboxField(
                  "Pickup Available",
                  "Home or work pickup",
                  localFilters.hasPickup,
                  (checked) => handleFilterChange("hasPickup", checked),
                  <Navigation className="w-4 h-4 text-purple-600" />
                )}
                {renderCheckboxField(
                  "Payment Plans",
                  "Installment options available",
                  localFilters.acceptsPaymentPlan,
                  (checked) => handleFilterChange("acceptsPaymentPlan", checked),
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                )}
                {renderCheckboxField(
                  "Online Booking",
                  "Book instantly online",
                  localFilters.hasOnlineBooking,
                  (checked) => handleFilterChange("hasOnlineBooking", checked),
                  <Zap className="w-4 h-4 text-indigo-600" />
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="sticky bottom-0 bg-white border-t border-slate-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            {showSortOptions && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-600">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => onSortChange?.(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {SORT_OPTIONS.map(option => (
                    <option key={option.id} value={option.id}>{option.label}</option>
                  ))}
                </select>
              </div>
            )}
            <p className="text-sm text-slate-500">
              {resultCount > 0 && `${resultCount} result${resultCount !== 1 ? 's' : ''} found`}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleReset}
              className="px-5 py-2.5 text-slate-700 font-medium hover:bg-slate-50 rounded-xl transition border border-slate-200"
            >
              Reset All
            </button>
            <button
              onClick={handleApply}
              disabled={isLoading}
              className="px-6 py-2.5 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition disabled:opacity-50 flex items-center gap-2"
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Check className="w-5 h-5" />
                  Apply Filters
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}