/**
 * AI Search Hook for Marketplace
 * 
 * This hook handles natural language search queries and translates them into
 * structured filter parameters that work with the existing marketplace search pipeline.
 * 
 * HOW IT WORKS:
 * 1. User types a natural language query (e.g., "patient instructor for beginners in Paris 6e")
 * 2. The query is sent to the LLM via InvokeLLM integration
 * 3. LLM extracts structured filters: location, skills, preferences, etc.
 * 4. These filters are returned and can be applied to the existing search
 * 
 * HOW TO EXTEND:
 * - Add new filter types in the JSON schema below
 * - Update the prompt to extract additional information
 * - Modify the applyAIFilters function to handle new filter types
 */

import { useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";

// Example queries to rotate in the placeholder
export const AI_SEARCH_EXAMPLES = [
  "instructeur patient pour débutants à Paris",
  "automatic car lessons in London",
  "boîte automatique proche métro Nation",
  "female instructor speaking English in Berlin",
  "intensive course this week near me",
  "cours du soir après 18h",
  "école avec bon taux de réussite",
  "cheap driving school with flexible hours"
];

// JSON schema for the AI to extract structured filters
const FILTER_SCHEMA = {
  type: "object",
  properties: {
    // Location filters
    city: {
      type: "string",
      description: "City name extracted from the query (e.g., Paris, London, Berlin)"
    },
    district: {
      type: "string", 
      description: "District, arrondissement, or neighborhood (e.g., '6ème', 'Marais', 'Kreuzberg')"
    },
    near_landmark: {
      type: "string",
      description: "Near a specific landmark or metro station"
    },
    
    // Instructor preferences
    instructor_traits: {
      type: "array",
      items: { type: "string" },
      description: "Desired instructor qualities: patient, calm, experienced, strict, young, female, male"
    },
    languages: {
      type: "array",
      items: { type: "string" },
      description: "Languages the user wants the instructor to speak"
    },
    
    // Course preferences
    transmission: {
      type: "string",
      enum: ["manual", "automatic", "any"],
      description: "Transmission type preference"
    },
    license_category: {
      type: "string",
      enum: ["B", "A", "C", "D", "any"],
      description: "License category (B=car, A=motorcycle, C=truck, D=bus)"
    },
    course_type: {
      type: "string",
      enum: ["standard", "intensive", "refresher", "any"],
      description: "Type of course"
    },
    
    // Schedule preferences
    time_preference: {
      type: "string",
      enum: ["morning", "afternoon", "evening", "weekend", "flexible", "any"],
      description: "Preferred time for lessons"
    },
    urgency: {
      type: "string",
      enum: ["this_week", "this_month", "flexible", "any"],
      description: "How soon the user wants to start"
    },
    
    // Budget and quality
    price_preference: {
      type: "string",
      enum: ["budget", "mid_range", "premium", "any"],
      description: "Price range preference"
    },
    quality_focus: {
      type: "string",
      enum: ["pass_rate", "reviews", "experience", "any"],
      description: "What quality metric matters most"
    },
    
    // Beginner specific
    is_beginner: {
      type: "boolean",
      description: "True if user mentions being a beginner or first-timer"
    },
    is_nervous: {
      type: "boolean",
      description: "True if user mentions being anxious or nervous about driving"
    },
    
    // Confidence and interpretation
    confidence: {
      type: "number",
      description: "0-1 score of how confident the AI is in the interpretation"
    },
    interpretation_summary: {
      type: "string",
      description: "A brief human-readable summary of what was understood"
    }
  },
  required: ["confidence", "interpretation_summary"]
};

// The prompt sent to the LLM
const buildPrompt = (query, availableCities = [], availableLanguages = []) => `
You are a search assistant for a driving school marketplace. Analyze the user's natural language search query and extract structured filters.

User query: "${query}"

Available cities in our database: ${availableCities.slice(0, 20).join(", ")}
Available languages: ${availableLanguages.join(", ")}

Instructions:
1. Extract all relevant filters from the query
2. Be flexible with spelling and language (the query might be in French, English, German, etc.)
3. Map common terms:
   - "débutant", "beginner", "first time" → is_beginner: true
   - "patient", "calm", "gentle" → instructor_traits: ["patient"]
   - "boîte auto", "automatic" → transmission: "automatic"
   - "6ème", "6e" → district (Paris 6th arrondissement)
   - "metro", "station" → near_landmark
   - "pas cher", "cheap", "budget" → price_preference: "budget"
   - "bon taux de réussite", "high pass rate" → quality_focus: "pass_rate"
4. If something is not mentioned, don't include it or use "any"
5. Set confidence based on how clear the query is (0.9+ for clear queries, lower for ambiguous)
6. Write interpretation_summary in the same language as the query

Return ONLY the JSON object matching the schema, nothing else.
`;

export function useAISearch() {
  const [isSearching, setIsSearching] = useState(false);
  const [aiFilters, setAiFilters] = useState(null);
  const [error, setError] = useState(null);
  const [lastQuery, setLastQuery] = useState("");

  /**
   * Determines if a query looks like a natural language search vs a simple keyword
   * Natural language queries typically have 3+ words or contain specific patterns
   */
  const isNaturalLanguageQuery = useCallback((query) => {
    if (!query || query.length < 5) return false;
    
    const words = query.trim().split(/\s+/);
    
    // 3+ words is likely natural language
    if (words.length >= 3) return true;
    
    // Check for specific patterns that indicate natural language
    const nlPatterns = [
      /pour\s/i,           // French: "pour débutants"
      /avec\s/i,           // French: "avec patience"
      /près\s/i,           // French: "près de"
      /proche\s/i,         // French: "proche métro"
      /dans\s(le|la|l')/i, // French: "dans le 6ème"
      /for\s/i,            // English: "for beginners"
      /with\s/i,           // English: "with automatic"
      /near\s/i,           // English: "near station"
      /in\s\w+\s/i,        // English: "in Paris 6th"
      /speaking\s/i,       // "speaking English"
      /débutant/i,
      /beginner/i,
      /patient/i,
      /instructor/i,
      /instructeur/i,
      /moniteur/i,
      /leçon/i,
      /lesson/i,
      /cours/i,
      /automatique/i,
      /automatic/i
    ];
    
    return nlPatterns.some(pattern => pattern.test(query));
  }, []);

  /**
   * Main search function - sends query to AI and returns structured filters
   */
  const performAISearch = useCallback(async (query, availableCities = [], availableLanguages = []) => {
    if (!query || query.trim().length < 3) {
      setAiFilters(null);
      setLastQuery("");
      return null;
    }

    // Skip AI for simple single-word searches
    if (!isNaturalLanguageQuery(query)) {
      setAiFilters(null);
      setLastQuery("");
      return null;
    }

    setIsSearching(true);
    setError(null);
    setLastQuery(query);

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: buildPrompt(query, availableCities, availableLanguages),
        response_json_schema: FILTER_SCHEMA
      });

      // Parse the result if it's a string
      const filters = typeof result === "string" ? JSON.parse(result) : result;
      
      // Validate confidence
      if (filters.confidence < 0.3) {
        setAiFilters(null);
        setError("Query too ambiguous. Try being more specific.");
        return null;
      }

      setAiFilters(filters);
      return filters;
    } catch (err) {
      console.error("AI Search error:", err);
      setError("Could not interpret your search. Try different keywords.");
      setAiFilters(null);
      return null;
    } finally {
      setIsSearching(false);
    }
  }, [isNaturalLanguageQuery]);

  /**
   * Clears the AI search state
   */
  const clearAISearch = useCallback(() => {
    setAiFilters(null);
    setError(null);
    setLastQuery("");
  }, []);

  /**
   * Applies AI filters to the existing filter state
   * This is where AI results are translated into the marketplace's existing filter format
   */
  const applyAIFilters = useCallback((aiFilters, existingFilters, setFilters, setSearchLocation, setSelectedCategory) => {
    if (!aiFilters) return;

    const updates = { ...existingFilters };

    // Location mapping
    if (aiFilters.city) {
      setSearchLocation?.(aiFilters.city);
    }

    // Transmission mapping
    if (aiFilters.transmission && aiFilters.transmission !== "any") {
      updates.transmission = aiFilters.transmission;
    }

    // License category mapping
    if (aiFilters.license_category && aiFilters.license_category !== "any") {
      setSelectedCategory?.(aiFilters.license_category);
    }

    // Language mapping
    if (aiFilters.languages && aiFilters.languages.length > 0) {
      updates.language = aiFilters.languages[0]; // Use first language
    }

    // Price preference mapping
    if (aiFilters.price_preference) {
      const priceMap = {
        budget: "low",
        mid_range: "medium",
        premium: "high"
      };
      if (priceMap[aiFilters.price_preference]) {
        updates.priceRange = priceMap[aiFilters.price_preference];
      }
    }

    // Quality focus → sort preference (returned separately)
    let suggestedSort = "recommended";
    if (aiFilters.quality_focus === "pass_rate") {
      suggestedSort = "pass-rate";
    } else if (aiFilters.quality_focus === "reviews") {
      suggestedSort = "rating";
    }

    setFilters?.(updates);

    return { updatedFilters: updates, suggestedSort };
  }, []);

  return {
    // State
    isSearching,
    aiFilters,
    error,
    lastQuery,
    
    // Functions
    performAISearch,
    clearAISearch,
    applyAIFilters,
    isNaturalLanguageQuery,
    
    // Constants
    examples: AI_SEARCH_EXAMPLES
  };
}

export default useAISearch;