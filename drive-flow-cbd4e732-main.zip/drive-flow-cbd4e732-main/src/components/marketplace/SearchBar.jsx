import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { 
  Search, 
  MapPin, 
  SlidersHorizontal,
  X,
  Clock,
  Star,
  Car,
  Users,
  Calendar,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Loader2,
  Navigation,
  Target,
  Zap,
  Shield,
  Heart,
  Route,
  Moon,
  Globe,
  Filter,
  RotateCcw,
  Check,
  Sparkles,
  TrendingUp,
  Award,
  DollarSign,
  Gauge,
  BadgeCheck,
  History,
  Mic,
  MicOff,
  LocateFixed,
  ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const LICENSE_CATEGORIES = [
  { id: "all", label: "All Types", icon: Car },
  { id: "B", label: "Car (B)", description: "Standard car license", icon: Car },
  { id: "A", label: "Motorcycle (A)", description: "Motorcycle license", icon: Zap },
  { id: "C", label: "Truck (C)", description: "Heavy vehicle license", icon: Car },
  { id: "D", label: "Bus (D)", description: "Passenger transport", icon: Users },
  { id: "BE", label: "Car + Trailer (BE)", description: "Car with trailer", icon: Route },
  { id: "CE", label: "Truck + Trailer (CE)", description: "Heavy with trailer", icon: Route }
];

const TRANSMISSION_TYPES = [
  { id: "all", label: "Any Transmission" },
  { id: "manual", label: "Manual" },
  { id: "automatic", label: "Automatic" },
  { id: "both", label: "Both Available" }
];

const PRICE_RANGES = [
  { id: "all", label: "Any Price", min: 0, max: Infinity },
  { id: "budget", label: "Under €40", min: 0, max: 40 },
  { id: "mid", label: "€40 - €60", min: 40, max: 60 },
  { id: "premium", label: "€60+", min: 60, max: Infinity }
];

const RATING_OPTIONS = [
  { id: 0, label: "Any Rating" },
  { id: 4.5, label: "4.5+ Excellent" },
  { id: 4, label: "4.0+ Very Good" },
  { id: 3.5, label: "3.5+ Good" }
];

const SPECIALIZATIONS = [
  { id: "nervous", label: "Nervous Drivers", icon: Heart },
  { id: "intensive", label: "Intensive Courses", icon: Target },
  { id: "refresher", label: "Refresher Lessons", icon: RotateCcw },
  { id: "motorway", label: "Motorway Driving", icon: Route },
  { id: "night", label: "Night Driving", icon: Moon },
  { id: "defensive", label: "Defensive Driving", icon: Shield }
];

const SORT_OPTIONS = [
  { id: "relevance", label: "Most Relevant", icon: Sparkles },
  { id: "rating", label: "Highest Rated", icon: Star },
  { id: "price_low", label: "Price: Low to High", icon: DollarSign },
  { id: "price_high", label: "Price: High to Low", icon: DollarSign },
  { id: "distance", label: "Nearest First", icon: Navigation },
  { id: "reviews", label: "Most Reviews", icon: Users }
];

const POPULAR_LOCATIONS = [
  { name: "London", postcode: "EC1" },
  { name: "Manchester", postcode: "M1" },
  { name: "Birmingham", postcode: "B1" },
  { name: "Leeds", postcode: "LS1" },
  { name: "Glasgow", postcode: "G1" },
  { name: "Edinburgh", postcode: "EH1" }
];

export default function SearchBar({ 
  searchLocation = "", 
  setSearchLocation,
  searchTerm = "",
  setSearchTerm,
  selectedCategory = "all",
  setSelectedCategory,
  onFilterClick,
  activeFilterCount = 0,
  onSearch,
  onClear,
  filters = {},
  setFilters,
  sortBy = "relevance",
  setSortBy,
  isLoading = false,
  showAdvancedFilters = false,
  setShowAdvancedFilters,
  recentSearches = [],
  suggestions = [],
  userLocation,
  onUseCurrentLocation,
  variant = "default",
  className = ""
}) {
  const [isLocationFocused, setIsLocationFocused] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [showCategoryDropdown, setShowCategoryDropdown] = useState(false);
  const [showSortDropdown, setShowSortDropdown] = useState(false);
  const [showFiltersPanel, setShowFiltersPanel] = useState(false);
  const [localFilters, setLocalFilters] = useState({
    transmission: "all",
    priceRange: "all",
    rating: 0,
    hasAvailability: false,
    isVerified: false,
    specializations: [],
    languages: [],
    distance: 50
  });
  const [isVoiceSearchActive, setIsVoiceSearchActive] = useState(false);
  const [locationSuggestions, setLocationSuggestions] = useState([]);
  const [searchSuggestions, setSearchSuggestions] = useState([]);

  const locationInputRef = useRef(null);
  const searchInputRef = useRef(null);
  const categoryRef = useRef(null);
  const sortRef = useRef(null);

  useEffect(() => {
    if (filters) {
      setLocalFilters(prev => ({ ...prev, ...filters }));
    }
  }, [filters]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (categoryRef.current && !categoryRef.current.contains(event.target)) {
        setShowCategoryDropdown(false);
      }
      if (sortRef.current && !sortRef.current.contains(event.target)) {
        setShowSortDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (searchLocation.length >= 2) {
      const timer = setTimeout(() => {
        const filtered = POPULAR_LOCATIONS.filter(loc =>
          loc.name.toLowerCase().includes(searchLocation.toLowerCase()) ||
          loc.postcode.toLowerCase().includes(searchLocation.toLowerCase())
        );
        setLocationSuggestions(filtered);
      }, 150);
      return () => clearTimeout(timer);
    } else {
      setLocationSuggestions([]);
    }
  }, [searchLocation]);

  useEffect(() => {
    if (searchTerm.length >= 2 && suggestions.length > 0) {
      const filtered = suggestions.filter(s =>
        s.name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setSearchSuggestions(filtered.slice(0, 5));
    } else {
      setSearchSuggestions([]);
    }
  }, [searchTerm, suggestions]);

  const activeFilterCountLocal = useMemo(() => {
    let count = 0;
    if (localFilters.transmission !== "all") count++;
    if (localFilters.priceRange !== "all") count++;
    if (localFilters.rating > 0) count++;
    if (localFilters.hasAvailability) count++;
    if (localFilters.isVerified) count++;
    if (localFilters.specializations.length > 0) count += localFilters.specializations.length;
    if (localFilters.distance < 50) count++;
    return count;
  }, [localFilters]);

  const totalFilterCount = activeFilterCount + activeFilterCountLocal;

  const handleSearch = useCallback(() => {
    if (onSearch) {
      onSearch({
        location: searchLocation,
        term: searchTerm,
        category: selectedCategory,
        filters: localFilters,
        sortBy
      });
    }
  }, [onSearch, searchLocation, searchTerm, selectedCategory, localFilters, sortBy]);

  const handleClearAll = useCallback(() => {
    setSearchLocation?.("");
    setSearchTerm?.("");
    setSelectedCategory?.("all");
    setLocalFilters({
      transmission: "all",
      priceRange: "all",
      rating: 0,
      hasAvailability: false,
      isVerified: false,
      specializations: [],
      languages: [],
      distance: 50
    });
    setSortBy?.("relevance");
    if (onClear) onClear();
  }, [setSearchLocation, setSearchTerm, setSelectedCategory, setSortBy, onClear]);

  const handleApplyFilters = useCallback(() => {
    if (setFilters) {
      setFilters(localFilters);
    }
    setShowFiltersPanel(false);
    handleSearch();
  }, [setFilters, localFilters, handleSearch]);

  const handleUseCurrentLocation = useCallback(() => {
    if (onUseCurrentLocation) {
      onUseCurrentLocation();
    } else if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setSearchLocation?.("Current Location");
        },
        (error) => {
          console.error("Geolocation error:", error);
        }
      );
    }
  }, [onUseCurrentLocation, setSearchLocation]);

  const handleVoiceSearch = useCallback(() => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert("Voice search is not supported in your browser");
      return;
    }

    setIsVoiceSearchActive(true);
    
    setTimeout(() => {
      setIsVoiceSearchActive(false);
    }, 3000);
  }, []);

  const toggleSpecialization = useCallback((specId) => {
    setLocalFilters(prev => ({
      ...prev,
      specializations: prev.specializations.includes(specId)
        ? prev.specializations.filter(s => s !== specId)
        : [...prev.specializations, specId]
    }));
  }, []);

  const handleKeyDown = useCallback((e) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  }, [handleSearch]);

  const selectedCategoryData = LICENSE_CATEGORIES.find(c => c.id === selectedCategory) || LICENSE_CATEGORIES[0];
  const selectedSortData = SORT_OPTIONS.find(s => s.id === sortBy) || SORT_OPTIONS[0];

  if (variant === "compact") {
    return (
      <div className={`bg-white rounded-xl border border-slate-200 shadow-sm p-2 ${className}`}>
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-lg">
            <Search className="w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search schools, locations..."
              value={searchTerm || searchLocation}
              onChange={(e) => {
                setSearchTerm?.(e.target.value);
                setSearchLocation?.(e.target.value);
              }}
              onKeyDown={handleKeyDown}
              className="w-full bg-transparent border-none focus:outline-none text-slate-900 placeholder-slate-400 text-sm"
            />
          </div>
          <button
            onClick={() => setShowFiltersPanel(!showFiltersPanel)}
            className={`p-2 rounded-lg transition ${
              showFiltersPanel || totalFilterCount > 0
                ? "bg-indigo-600 text-white"
                : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            }`}
          >
            <SlidersHorizontal className="w-4 h-4" />
            {totalFilterCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                {totalFilterCount}
              </span>
            )}
          </button>
          <button
            onClick={handleSearch}
            disabled={isLoading}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition disabled:opacity-50"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              "Search"
            )}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`space-y-3 ${className}`}>
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-2">
          <div className="md:col-span-4 relative">
            <div 
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition ${
                isLocationFocused 
                  ? "bg-indigo-50 ring-2 ring-indigo-500" 
                  : "bg-slate-50 hover:bg-slate-100"
              }`}
            >
              <MapPin className={`w-5 h-5 flex-shrink-0 ${isLocationFocused ? "text-indigo-600" : "text-slate-400"}`} />
              <div className="flex-1 min-w-0">
                <label className="block text-xs font-semibold text-slate-500 mb-0.5">Location</label>
                <input
                  ref={locationInputRef}
                  type="text"
                  placeholder="City or postcode"
                  value={searchLocation}
                  onChange={(e) => setSearchLocation?.(e.target.value)}
                  onFocus={() => setIsLocationFocused(true)}
                  onBlur={() => setTimeout(() => setIsLocationFocused(false), 200)}
                  onKeyDown={handleKeyDown}
                  className="w-full bg-transparent border-none focus:outline-none text-slate-900 placeholder-slate-400 font-medium text-sm"
                />
              </div>
              {searchLocation && (
                <button
                  onClick={() => setSearchLocation?.("")}
                  className="p-1 hover:bg-slate-200 rounded-full transition"
                >
                  <X className="w-4 h-4 text-slate-400" />
                </button>
              )}
              <button
                onClick={handleUseCurrentLocation}
                className="p-1.5 hover:bg-slate-200 rounded-lg transition"
                title="Use current location"
              >
                <LocateFixed className="w-4 h-4 text-slate-500" />
              </button>
            </div>

            <AnimatePresence>
              {isLocationFocused && (locationSuggestions.length > 0 || recentSearches.length > 0) && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden z-50"
                >
                  {locationSuggestions.length > 0 ? (
                    <div className="p-2">
                      <p className="text-xs font-semibold text-slate-500 px-2 mb-1">Suggestions</p>
                      {locationSuggestions.map((loc, index) => (
                        <button
                          key={index}
                          onClick={() => {
                            setSearchLocation?.(loc.name);
                            setIsLocationFocused(false);
                          }}
                          className="w-full flex items-center gap-3 px-3 py-2 hover:bg-slate-50 rounded-lg transition text-left"
                        >
                          <MapPin className="w-4 h-4 text-slate-400" />
                          <div>
                            <p className="text-sm font-medium text-slate-900">{loc.name}</p>
                            <p className="text-xs text-slate-500">{loc.postcode}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  ) : recentSearches.length > 0 && (
                    <div className="p-2">
                      <p className="text-xs font-semibold text-slate-500 px-2 mb-1">Recent Searches</p>
                      {recentSearches.slice(0, 5).map((search, index) => (
                        <button
                          key={index}
                          onClick={() => {
                            setSearchLocation?.(search);
                            setIsLocationFocused(false);
                          }}
                          className="w-full flex items-center gap-3 px-3 py-2 hover:bg-slate-50 rounded-lg transition text-left"
                        >
                          <History className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-700">{search}</span>
                        </button>
                      ))}
                    </div>
                  )}

                  <div className="border-t border-slate-100 p-2">
                    <p className="text-xs font-semibold text-slate-500 px-2 mb-1">Popular</p>
                    <div className="flex flex-wrap gap-1 px-2">
                      {POPULAR_LOCATIONS.slice(0, 4).map((loc, index) => (
                        <button
                          key={index}
                          onClick={() => {
                            setSearchLocation?.(loc.name);
                            setIsLocationFocused(false);
                          }}
                          className="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs text-slate-700 transition"
                        >
                          {loc.name}
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="md:col-span-4 relative">
            <div 
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition ${
                isSearchFocused 
                  ? "bg-indigo-50 ring-2 ring-indigo-500" 
                  : "bg-slate-50 hover:bg-slate-100"
              }`}
            >
              <Search className={`w-5 h-5 flex-shrink-0 ${isSearchFocused ? "text-indigo-600" : "text-slate-400"}`} />
              <div className="flex-1 min-w-0">
                <label className="block text-xs font-semibold text-slate-500 mb-0.5">Search</label>
                <input
                  ref={searchInputRef}
                  type="text"
                  placeholder="School or instructor name"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm?.(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                  onKeyDown={handleKeyDown}
                  className="w-full bg-transparent border-none focus:outline-none text-slate-900 placeholder-slate-400 font-medium text-sm"
                />
              </div>
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm?.("")}
                  className="p-1 hover:bg-slate-200 rounded-full transition"
                >
                  <X className="w-4 h-4 text-slate-400" />
                </button>
              )}
              <button
                onClick={handleVoiceSearch}
                className={`p-1.5 rounded-lg transition ${
                  isVoiceSearchActive 
                    ? "bg-red-100 text-red-600" 
                    : "hover:bg-slate-200 text-slate-500"
                }`}
                title="Voice search"
              >
                {isVoiceSearchActive ? (
                  <MicOff className="w-4 h-4 animate-pulse" />
                ) : (
                  <Mic className="w-4 h-4" />
                )}
              </button>
            </div>

            <AnimatePresence>
              {isSearchFocused && searchSuggestions.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden z-50"
                >
                  <div className="p-2">
                    <p className="text-xs font-semibold text-slate-500 px-2 mb-1">Suggestions</p>
                    {searchSuggestions.map((suggestion, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          setSearchTerm?.(suggestion.name);
                          setIsSearchFocused(false);
                        }}
                        className="w-full flex items-center gap-3 px-3 py-2 hover:bg-slate-50 rounded-lg transition text-left"
                      >
                        {suggestion.type === "school" ? (
                          <Car className="w-4 h-4 text-indigo-500" />
                        ) : (
                          <Users className="w-4 h-4 text-purple-500" />
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-slate-900 truncate">{suggestion.name}</p>
                          {suggestion.location && (
                            <p className="text-xs text-slate-500">{suggestion.location}</p>
                          )}
                        </div>
                        {suggestion.rating && (
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                            <span className="text-xs font-semibold text-slate-700">{suggestion.rating}</span>
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="md:col-span-2 relative" ref={categoryRef}>
            <button
              onClick={() => setShowCategoryDropdown(!showCategoryDropdown)}
              className={`w-full h-full flex items-center justify-between gap-2 px-4 py-3 rounded-xl transition ${
                showCategoryDropdown 
                  ? "bg-indigo-50 ring-2 ring-indigo-500" 
                  : "bg-slate-50 hover:bg-slate-100"
              }`}
            >
              <div className="flex-1 min-w-0 text-left">
                <label className="block text-xs font-semibold text-slate-500 mb-0.5">Category</label>
                <p className="text-sm font-medium text-slate-900 truncate">{selectedCategoryData.label}</p>
              </div>
              <ChevronDown className={`w-4 h-4 text-slate-400 transition ${showCategoryDropdown ? "rotate-180" : ""}`} />
            </button>

            <AnimatePresence>
              {showCategoryDropdown && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden z-50 min-w-[200px]"
                >
                  <div className="p-2">
                    {LICENSE_CATEGORIES.map((category) => (
                      <button
                        key={category.id}
                        onClick={() => {
                          setSelectedCategory?.(category.id);
                          setShowCategoryDropdown(false);
                        }}
                        className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition text-left ${
                          selectedCategory === category.id
                            ? "bg-indigo-50 text-indigo-700"
                            : "hover:bg-slate-50 text-slate-700"
                        }`}
                      >
                        <category.icon className="w-4 h-4" />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{category.label}</p>
                          {category.description && (
                            <p className="text-xs text-slate-500">{category.description}</p>
                          )}
                        </div>
                        {selectedCategory === category.id && (
                          <Check className="w-4 h-4 text-indigo-600" />
                        )}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="md:col-span-2 flex gap-2">
            <button
              onClick={() => setShowFiltersPanel(!showFiltersPanel)}
              className={`flex-1 h-full px-4 py-3 rounded-xl text-sm font-semibold transition inline-flex items-center justify-center gap-2 ${
                showFiltersPanel || totalFilterCount > 0
                  ? "bg-indigo-100 text-indigo-700 border-2 border-indigo-300"
                  : "bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200"
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>Filters</span>
              {totalFilterCount > 0 && (
                <span className="px-1.5 py-0.5 bg-indigo-600 text-white text-xs rounded-full font-bold">
                  {totalFilterCount}
                </span>
              )}
            </button>

            <button
              onClick={handleSearch}
              disabled={isLoading}
              className="px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition disabled:opacity-50 flex items-center gap-2"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  <span className="hidden sm:inline">Search</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showFiltersPanel && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
          >
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-slate-900">Advanced Filters</h3>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setLocalFilters({
                      transmission: "all",
                      priceRange: "all",
                      rating: 0,
                      hasAvailability: false,
                      isVerified: false,
                      specializations: [],
                      languages: [],
                      distance: 50
                    })}
                    className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
                  >
                    Reset all
                  </button>
                  <button
                    onClick={() => setShowFiltersPanel(false)}
                    className="p-1 hover:bg-slate-100 rounded-lg transition"
                  >
                    <X className="w-5 h-5 text-slate-400" />
                  </button>
                </div>
              </div>

              <div className="grid md:grid-cols-4 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Transmission</label>
                  <div className="space-y-1">
                    {TRANSMISSION_TYPES.map(type => (
                      <button
                        key={type.id}
                        onClick={() => setLocalFilters(prev => ({ ...prev, transmission: type.id }))}
                        className={`w-full px-3 py-2 rounded-lg text-sm text-left transition ${
                          localFilters.transmission === type.id
                            ? "bg-indigo-100 text-indigo-700 font-medium"
                            : "bg-slate-50 text-slate-700 hover:bg-slate-100"
                        }`}
                      >
                        {type.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Price Range</label>
                  <div className="space-y-1">
                    {PRICE_RANGES.map(range => (
                      <button
                        key={range.id}
                        onClick={() => setLocalFilters(prev => ({ ...prev, priceRange: range.id }))}
                        className={`w-full px-3 py-2 rounded-lg text-sm text-left transition ${
                          localFilters.priceRange === range.id
                            ? "bg-indigo-100 text-indigo-700 font-medium"
                            : "bg-slate-50 text-slate-700 hover:bg-slate-100"
                        }`}
                      >
                        {range.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Minimum Rating</label>
                  <div className="space-y-1">
                    {RATING_OPTIONS.map(option => (
                      <button
                        key={option.id}
                        onClick={() => setLocalFilters(prev => ({ ...prev, rating: option.id }))}
                        className={`w-full px-3 py-2 rounded-lg text-sm text-left transition flex items-center gap-2 ${
                          localFilters.rating === option.id
                            ? "bg-indigo-100 text-indigo-700 font-medium"
                            : "bg-slate-50 text-slate-700 hover:bg-slate-100"
                        }`}
                      >
                        {option.id > 0 && <Star className="w-4 h-4 text-amber-500 fill-amber-500" />}
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Additional Options</label>
                  <div className="space-y-2">
                    <label className="flex items-center gap-3 p-2 bg-slate-50 rounded-lg cursor-pointer hover:bg-slate-100 transition">
                      <input
                        type="checkbox"
                        checked={localFilters.hasAvailability}
                        onChange={(e) => setLocalFilters(prev => ({ ...prev, hasAvailability: e.target.checked }))}
                        className="w-4 h-4 text-indigo-600 rounded"
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-slate-700">Available Now</p>
                        <p className="text-xs text-slate-500">Has open slots this week</p>
                      </div>
                      <Calendar className="w-4 h-4 text-slate-400" />
                    </label>

                    <label className="flex items-center gap-3 p-2 bg-slate-50 rounded-lg cursor-pointer hover:bg-slate-100 transition">
                      <input
                        type="checkbox"
                        checked={localFilters.isVerified}
                        onChange={(e) => setLocalFilters(prev => ({ ...prev, isVerified: e.target.checked }))}
                        className="w-4 h-4 text-indigo-600 rounded"
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-slate-700">Verified Only</p>
                        <p className="text-xs text-slate-500">Background checked</p>
                      </div>
                      <BadgeCheck className="w-4 h-4 text-green-500" />
                    </label>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-semibold text-slate-700 mb-2">Specializations</label>
                <div className="flex flex-wrap gap-2">
                  {SPECIALIZATIONS.map(spec => (
                    <button
                      key={spec.id}
                      onClick={() => toggleSpecialization(spec.id)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition ${
                        localFilters.specializations.includes(spec.id)
                          ? "bg-indigo-100 text-indigo-700 font-medium border-2 border-indigo-300"
                          : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                      }`}
                    >
                      <spec.icon className="w-4 h-4" />
                      {spec.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Maximum Distance: {localFilters.distance} km
                </label>
                <input
                  type="range"
                  min="1"
                  max="50"
                  value={localFilters.distance}
                  onChange={(e) => setLocalFilters(prev => ({ ...prev, distance: parseInt(e.target.value) }))}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
                <div className="flex justify-between text-xs text-slate-500 mt-1">
                  <span>1 km</span>
                  <span>25 km</span>
                  <span>50 km</span>
                </div>
              </div>

              <div className="mt-6 flex items-center justify-between pt-4 border-t border-slate-200">
                <p className="text-sm text-slate-600">
                  {totalFilterCount > 0 ? `${totalFilterCount} filter${totalFilterCount !== 1 ? 's' : ''} applied` : "No filters applied"}
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowFiltersPanel(false)}
                    className="px-4 py-2 text-slate-700 hover:bg-slate-100 rounded-lg text-sm font-medium transition"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleApplyFilters}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition"
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {totalFilterCount > 0 && (
            <button
              onClick={handleClearAll}
              className="flex-shrink-0 inline-flex items-center gap-1 px-2 py-1 text-xs text-red-600 hover:bg-red-50 rounded-lg transition"
            >
              <X className="w-3 h-3" />
              Clear all
            </button>
          )}

          {localFilters.transmission !== "all" && (
            <span className="flex-shrink-0 inline-flex items-center gap-1 px-2 py-1 bg-indigo-100 text-indigo-700 rounded-lg text-xs font-medium">
              {TRANSMISSION_TYPES.find(t => t.id === localFilters.transmission)?.label}
              <button
                onClick={() => setLocalFilters(prev => ({ ...prev, transmission: "all" }))}
                className="hover:bg-indigo-200 rounded-full p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {localFilters.rating > 0 && (
            <span className="flex-shrink-0 inline-flex items-center gap-1 px-2 py-1 bg-amber-100 text-amber-700 rounded-lg text-xs font-medium">
              <Star className="w-3 h-3 fill-amber-500" />
              {localFilters.rating}+
              <button
                onClick={() => setLocalFilters(prev => ({ ...prev, rating: 0 }))}
                className="hover:bg-amber-200 rounded-full p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {localFilters.specializations.map(specId => {
            const spec = SPECIALIZATIONS.find(s => s.id === specId);
            return spec ? (
              <span key={specId} className="flex-shrink-0 inline-flex items-center gap-1 px-2 py-1 bg-purple-100 text-purple-700 rounded-lg text-xs font-medium">
                <spec.icon className="w-3 h-3" />
                {spec.label}
                <button
                  onClick={() => toggleSpecialization(specId)}
                  className="hover:bg-purple-200 rounded-full p-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ) : null;
          })}
        </div>

        <div className="relative flex-shrink-0" ref={sortRef}>
          <button
            onClick={() => setShowSortDropdown(!showSortDropdown)}
            className="inline-flex items-center gap-2 px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-100 rounded-lg transition"
          >
            <selectedSortData.icon className="w-4 h-4 text-slate-400" />
            <span className="hidden sm:inline">{selectedSortData.label}</span>
            <ChevronDown className={`w-4 h-4 text-slate-400 transition ${showSortDropdown ? "rotate-180" : ""}`} />
          </button>

          <AnimatePresence>
            {showSortDropdown && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute top-full right-0 mt-2 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden z-50 min-w-[180px]"
              >
                <div className="p-1">
                  {SORT_OPTIONS.map(option => (
                    <button
                      key={option.id}
                      onClick={() => {
                        setSortBy?.(option.id);
                        setShowSortDropdown(false);
                      }}
                      className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition text-left ${
                        sortBy === option.id
                          ? "bg-indigo-50 text-indigo-700"
                          : "hover:bg-slate-50 text-slate-700"
                      }`}
                    >
                      <option.icon className="w-4 h-4" />
                      {option.label}
                      {sortBy === option.id && (
                        <Check className="w-4 h-4 ml-auto text-indigo-600" />
                      )}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}