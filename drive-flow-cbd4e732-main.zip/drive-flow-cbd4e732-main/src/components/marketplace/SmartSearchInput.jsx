/**
 * Smart Search Input Component
 * 
 * A unified search input that supports both traditional keyword search
 * and AI-powered natural language queries. Designed to integrate seamlessly
 * with the existing Drivee marketplace design system.
 * 
 * Features:
 * - Rotating placeholder examples for natural language queries
 * - Subtle "Smart search" badge (non-intrusive AI branding)
 * - Loading state during AI interpretation
 * - Keyboard accessibility (Enter to search)
 */

import React, { useState, useEffect, useRef, useCallback } from "react";
import { Search, Sparkles, Loader2, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { AI_SEARCH_EXAMPLES } from "./useAISearch";

// Easing for animations (matches Drivee design system)
const easing = {
  premium: [0.22, 1, 0.36, 1]
};

export default function SmartSearchInput({
  value,
  onChange,
  onSearch,
  onClear,
  isSearching = false,
  placeholder = "Search by school, location, instructor or describe what you need...",
  className = ""
}) {
  const inputRef = useRef(null);
  const [isFocused, setIsFocused] = useState(false);
  const [exampleIndex, setExampleIndex] = useState(0);
  const [showExampleHint, setShowExampleHint] = useState(true);

  // Rotate through example queries every 4 seconds when input is empty and focused
  useEffect(() => {
    if (!value && isFocused) {
      const interval = setInterval(() => {
        setExampleIndex((prev) => (prev + 1) % AI_SEARCH_EXAMPLES.length);
      }, 4000);
      return () => clearInterval(interval);
    }
  }, [value, isFocused]);

  // Hide example hint after first interaction
  useEffect(() => {
    if (value) {
      setShowExampleHint(false);
    }
  }, [value]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === "Enter" && value.trim()) {
      e.preventDefault();
      onSearch?.(value);
    }
    if (e.key === "Escape") {
      inputRef.current?.blur();
    }
  }, [value, onSearch]);

  const handleClear = useCallback(() => {
    onChange?.("");
    onClear?.();
    inputRef.current?.focus();
  }, [onChange, onClear]);

  return (
    <div className={`relative ${className}`}>
      {/* Main Input Container */}
      <div 
        className={`relative flex items-center transition-all duration-300 ${
          isFocused 
            ? "ring-2 ring-[#a9d5ed]/30 border-[#3b82c4]" 
            : "border-slate-200 hover:border-slate-300"
        } bg-slate-50 border rounded-2xl overflow-hidden group`}
      >
        {/* Search Icon */}
        <div className="flex items-center justify-center w-12 h-full">
          <Search className={`w-5 h-5 transition-colors duration-200 ${
            isFocused ? "text-[#3b82c4]" : "text-slate-400"
          }`} />
        </div>

        {/* Input Field */}
        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={(e) => onChange?.(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          aria-label="Search driving schools"
          className="flex-1 py-3.5 pr-4 bg-transparent text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none"
        />

        {/* Loading Spinner */}
        <AnimatePresence>
          {isSearching && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex items-center justify-center w-10 h-full"
            >
              <Loader2 className="w-4 h-4 text-[#3b82c4] animate-spin" />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Clear Button */}
        <AnimatePresence>
          {value && !isSearching && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={handleClear}
              className="flex items-center justify-center w-10 h-full text-slate-400 hover:text-slate-600 transition-colors"
              aria-label="Clear search"
            >
              <X className="w-4 h-4" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Smart Search Badge - Subtle AI indicator */}
        <div className="flex items-center pr-3">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200/50">
            <Sparkles className="w-3 h-3 text-[#3b82c4]" />
            <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wide">
              Smart
            </span>
          </div>
        </div>
      </div>

      {/* Rotating Example Hint - Shows when empty and focused */}
      <AnimatePresence>
        {!value && isFocused && showExampleHint && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.2, ease: easing.premium }}
            className="absolute left-0 right-0 top-full mt-2 px-4"
          >
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span className="text-slate-400">Try:</span>
              <AnimatePresence mode="wait">
                <motion.span
                  key={exampleIndex}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.3 }}
                  className="text-slate-600 font-medium italic"
                >
                  "{AI_SEARCH_EXAMPLES[exampleIndex]}"
                </motion.span>
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}