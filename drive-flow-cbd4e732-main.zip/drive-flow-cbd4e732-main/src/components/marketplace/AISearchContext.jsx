/**
 * AI Search Context Display
 * 
 * Shows a subtle context bar above search results when AI search is active.
 * Displays what the AI understood and allows users to clear the AI interpretation.
 * 
 * Design: Follows Drivee's soft blue color palette, non-intrusive styling.
 */

import React from "react";
import { Sparkles, X, MapPin, User, Car, Clock, DollarSign, Star, Check } from "lucide-react";
import { motion } from "framer-motion";

// Map AI filter keys to human-readable labels and icons
const FILTER_DISPLAY = {
  city: { label: "Location", icon: MapPin },
  district: { label: "Area", icon: MapPin },
  transmission: { label: "Transmission", icon: Car },
  license_category: { label: "License", icon: Car },
  languages: { label: "Language", icon: User },
  instructor_traits: { label: "Instructor", icon: User },
  time_preference: { label: "Time", icon: Clock },
  price_preference: { label: "Price", icon: DollarSign },
  quality_focus: { label: "Priority", icon: Star },
  is_beginner: { label: "Beginner-friendly", icon: Check },
  is_nervous: { label: "Patient instructor", icon: Check }
};

// Format values for display
const formatValue = (key, value) => {
  if (Array.isArray(value)) {
    return value.join(", ");
  }
  if (typeof value === "boolean") {
    return value ? "Yes" : "No";
  }
  if (key === "transmission") {
    return value === "automatic" ? "Automatic" : value === "manual" ? "Manual" : value;
  }
  if (key === "price_preference") {
    const labels = { budget: "Budget-friendly", mid_range: "Mid-range", premium: "Premium" };
    return labels[value] || value;
  }
  if (key === "time_preference") {
    const labels = { 
      morning: "Morning", 
      afternoon: "Afternoon", 
      evening: "Evening",
      weekend: "Weekends",
      flexible: "Flexible"
    };
    return labels[value] || value;
  }
  if (key === "quality_focus") {
    const labels = { pass_rate: "High pass rate", reviews: "Top rated", experience: "Experienced" };
    return labels[value] || value;
  }
  return value;
};

export default function AISearchContext({
  aiFilters,
  query,
  resultCount,
  onClear,
  className = ""
}) {
  if (!aiFilters) return null;

  // Extract displayable filters (exclude meta fields)
  const displayableFilters = Object.entries(aiFilters).filter(([key, value]) => {
    // Skip meta fields and empty values
    if (["confidence", "interpretation_summary", "near_landmark", "urgency", "course_type"].includes(key)) return false;
    if (value === null || value === undefined || value === "any") return false;
    if (Array.isArray(value) && value.length === 0) return false;
    if (typeof value === "boolean" && !value) return false;
    return FILTER_DISPLAY[key] !== undefined;
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.3 }}
      className={`bg-gradient-to-r from-[#f8fafc] to-[#f1f5f9] border border-slate-200 rounded-xl p-4 ${className}`}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          {/* Header with AI icon */}
          <div className="flex items-center gap-2 mb-2">
            <div className="flex items-center justify-center w-6 h-6 rounded-lg bg-[#e8f4fa]">
              <Sparkles className="w-3.5 h-3.5 text-[#3b82c4]" />
            </div>
            <span className="text-sm font-semibold text-slate-700">
              Smart search results
            </span>
            <span className="text-sm text-slate-500">
              • {resultCount} {resultCount === 1 ? "school" : "schools"} found
            </span>
          </div>

          {/* Interpretation summary */}
          {aiFilters.interpretation_summary && (
            <p className="text-sm text-slate-600 mb-3">
              {aiFilters.interpretation_summary}
            </p>
          )}

          {/* Applied filters as tags */}
          {displayableFilters.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {displayableFilters.map(([key, value]) => {
                const config = FILTER_DISPLAY[key];
                if (!config) return null;
                
                const Icon = config.icon;
                const displayValue = formatValue(key, value);
                
                return (
                  <span
                    key={key}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-xs font-medium text-slate-700"
                  >
                    <Icon className="w-3 h-3 text-slate-400" />
                    <span>{config.label}:</span>
                    <span className="text-slate-900">{displayValue}</span>
                  </span>
                );
              })}
            </div>
          )}
        </div>

        {/* Clear button */}
        <button
          onClick={onClear}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <X className="w-3.5 h-3.5" />
          Clear
        </button>
      </div>

      {/* Confidence indicator (only show if low) */}
      {aiFilters.confidence && aiFilters.confidence < 0.7 && (
        <div className="mt-3 pt-3 border-t border-slate-200">
          <p className="text-xs text-slate-500">
            <span className="text-amber-600 font-medium">Note:</span> This interpretation may not be exact. 
            Try adding more details or use the filters above to refine your search.
          </p>
        </div>
      )}
    </motion.div>
  );
}