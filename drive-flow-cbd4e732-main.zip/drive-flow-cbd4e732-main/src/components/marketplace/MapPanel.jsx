import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { 
  MapPin, 
  Navigation, 
  ZoomIn, 
  ZoomOut, 
  Locate, 
  Layers,
  Search,
  Filter,
  X,
  Star,
  Phone,
  Globe,
  Clock,
  Car,
  Users,
  ChevronRight,
  ChevronLeft,
  ChevronUp,
  ChevronDown,
  Maximize2,
  Minimize2,
  Route,
  Target,
  Compass,
  Map,
  List,
  Grid3X3,
  Info,
  ExternalLink,
  Share2,
  Bookmark,
  BookmarkCheck,
  Navigation2,
  LocateFixed,
  RotateCcw,
  Settings,
  Eye,
  EyeOff,
  Loader2,
  AlertCircle,
  CheckCircle
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { createPageUrl } from "@/utils";

const MAP_STYLES = [
  { id: "default", label: "Default", icon: Map },
  { id: "satellite", label: "Satellite", icon: Globe },
  { id: "terrain", label: "Terrain", icon: Layers }
];

const ZOOM_LEVELS = {
  min: 8,
  max: 18,
  default: 12,
  city: 13,
  street: 16,
  building: 18
};

const MARKER_COLORS = {
  default: { bg: "bg-indigo-600", border: "border-indigo-600", text: "text-indigo-600" },
  highlighted: { bg: "bg-amber-500", border: "border-amber-500", text: "text-amber-500" },
  selected: { bg: "bg-green-600", border: "border-green-600", text: "text-green-600" },
  cluster: { bg: "bg-purple-600", border: "border-purple-600", text: "text-purple-600" }
};

export default function MapPanel({ 
  schools = [], 
  highlightedSchoolId, 
  selectedSchoolId,
  onMarkerClick,
  onMarkerHover,
  onAreaSearch,
  onSchoolSelect,
  userLocation,
  isLoading = false,
  showControls = true,
  showSearch = true,
  showSchoolList = false,
  initialCenter,
  initialZoom,
  className = ""
}) {
  const mapContainerRef = useRef(null);
  const [mapState, setMapState] = useState({
    zoom: initialZoom || ZOOM_LEVELS.default,
    center: initialCenter || { lat: 51.5074, lng: -0.1278 },
    bounds: null
  });
  
  const [uiState, setUiState] = useState({
    isFullscreen: false,
    showLayers: false,
    showFilters: false,
    showSchoolPopup: null,
    showListPanel: showSchoolList,
    mapStyle: "default",
    showTraffic: false,
    showTransit: false
  });

  const [searchState, setSearchState] = useState({
    query: "",
    isSearching: false,
    suggestions: [],
    recentSearches: []
  });

  const [filters, setFilters] = useState({
    rating: 0,
    priceRange: [0, 200],
    transmissionType: "all",
    hasAvailability: false,
    isVerified: false
  });

  const [savedSchools, setSavedSchools] = useState([]);

  const visibleSchools = useMemo(() => {
    let filtered = [...schools];

    if (filters.rating > 0) {
      filtered = filtered.filter(s => (s.rating || 5) >= filters.rating);
    }

    if (filters.transmissionType !== "all") {
      filtered = filtered.filter(s => 
        s.transmission_types?.includes(filters.transmissionType)
      );
    }

    if (filters.hasAvailability) {
      filtered = filtered.filter(s => s.has_availability !== false);
    }

    if (filters.isVerified) {
      filtered = filtered.filter(s => s.is_verified);
    }

    return filtered;
  }, [schools, filters]);

  const clusteredMarkers = useMemo(() => {
    if (mapState.zoom >= 14 || visibleSchools.length <= 10) {
      return visibleSchools.map(school => ({
        type: "single",
        school,
        position: getSchoolPosition(school)
      }));
    }

    const clusters = [];
    const processed = new Set();
    const clusterRadius = 50 / mapState.zoom;

    visibleSchools.forEach((school, index) => {
      if (processed.has(school.id)) return;

      const position = getSchoolPosition(school);
      const nearbySchools = visibleSchools.filter((s, i) => {
        if (processed.has(s.id) || i === index) return false;
        const sPos = getSchoolPosition(s);
        const distance = Math.sqrt(
          Math.pow(position.x - sPos.x, 2) + Math.pow(position.y - sPos.y, 2)
        );
        return distance < clusterRadius;
      });

      if (nearbySchools.length >= 2) {
        const clusterSchools = [school, ...nearbySchools];
        clusterSchools.forEach(s => processed.add(s.id));
        
        clusters.push({
          type: "cluster",
          schools: clusterSchools,
          count: clusterSchools.length,
          position: {
            x: clusterSchools.reduce((sum, s) => sum + getSchoolPosition(s).x, 0) / clusterSchools.length,
            y: clusterSchools.reduce((sum, s) => sum + getSchoolPosition(s).y, 0) / clusterSchools.length
          }
        });
      } else {
        processed.add(school.id);
        clusters.push({
          type: "single",
          school,
          position
        });
      }
    });

    return clusters;
  }, [visibleSchools, mapState.zoom]);

  function getSchoolPosition(school) {
    if (school.coordinates) {
      return {
        x: ((school.coordinates.lng + 180) / 360) * 100,
        y: ((90 - school.coordinates.lat) / 180) * 100
      };
    }
    
    const hash = school.id.split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a;
    }, 0);
    
    return {
      x: 15 + (Math.abs(hash % 70)),
      y: 15 + (Math.abs((hash * 7) % 70))
    };
  }

  const handleZoomIn = useCallback(() => {
    setMapState(prev => ({
      ...prev,
      zoom: Math.min(prev.zoom + 1, ZOOM_LEVELS.max)
    }));
  }, []);

  const handleZoomOut = useCallback(() => {
    setMapState(prev => ({
      ...prev,
      zoom: Math.max(prev.zoom - 1, ZOOM_LEVELS.min)
    }));
  }, []);

  const handleLocateUser = useCallback(() => {
    if (userLocation) {
      setMapState(prev => ({
        ...prev,
        center: userLocation,
        zoom: ZOOM_LEVELS.city
      }));
    } else if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setMapState(prev => ({
            ...prev,
            center: {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            },
            zoom: ZOOM_LEVELS.city
          }));
        },
        (error) => {
          console.error("Geolocation error:", error);
        }
      );
    }
  }, [userLocation]);

  const handleResetView = useCallback(() => {
    setMapState({
      zoom: initialZoom || ZOOM_LEVELS.default,
      center: initialCenter || { lat: 51.5074, lng: -0.1278 },
      bounds: null
    });
  }, [initialCenter, initialZoom]);

  const handleToggleFullscreen = useCallback(() => {
    setUiState(prev => ({ ...prev, isFullscreen: !prev.isFullscreen }));
  }, []);

  const handleSearchArea = useCallback(() => {
    if (onAreaSearch) {
      onAreaSearch(mapState.bounds || mapState.center);
    }
  }, [onAreaSearch, mapState]);

  const handleMarkerClick = useCallback((schoolId) => {
    setUiState(prev => ({
      ...prev,
      showSchoolPopup: prev.showSchoolPopup === schoolId ? null : schoolId
    }));
    
    if (onMarkerClick) {
      onMarkerClick(schoolId);
    }
  }, [onMarkerClick]);

  const handleClusterClick = useCallback((cluster) => {
    setMapState(prev => ({
      ...prev,
      zoom: Math.min(prev.zoom + 2, ZOOM_LEVELS.max)
    }));
  }, []);

  const handleSaveSchool = useCallback((schoolId) => {
    setSavedSchools(prev => 
      prev.includes(schoolId) 
        ? prev.filter(id => id !== schoolId)
        : [...prev, schoolId]
    );
  }, []);

  const handleSearch = useCallback((query) => {
    setSearchState(prev => ({ ...prev, query, isSearching: true }));
    
    setTimeout(() => {
      setSearchState(prev => ({ ...prev, isSearching: false }));
    }, 500);
  }, []);

  const selectedSchool = useMemo(() => {
    if (!uiState.showSchoolPopup) return null;
    return schools.find(s => s.id === uiState.showSchoolPopup);
  }, [uiState.showSchoolPopup, schools]);

  const renderMarker = (marker, index) => {
    if (marker.type === "cluster") {
      return (
        <motion.div
          key={`cluster-${index}`}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute cursor-pointer"
          style={{
            left: `${marker.position.x}%`,
            top: `${marker.position.y}%`,
            transform: "translate(-50%, -50%)"
          }}
          onClick={() => handleClusterClick(marker)}
        >
          <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center shadow-lg border-2 border-white hover:scale-110 transition-transform">
            <span className="text-white font-bold text-sm">{marker.count}</span>
          </div>
        </motion.div>
      );
    }

    const school = marker.school;
    const isHighlighted = highlightedSchoolId === school.id;
    const isSelected = selectedSchoolId === school.id || uiState.showSchoolPopup === school.id;
    const isSaved = savedSchools.includes(school.id);

    const colors = isSelected 
      ? MARKER_COLORS.selected 
      : isHighlighted 
        ? MARKER_COLORS.highlighted 
        : MARKER_COLORS.default;

    return (
      <motion.div
        key={school.id}
        initial={{ scale: 0, y: 20 }}
        animate={{ 
          scale: isHighlighted || isSelected ? 1.2 : 1,
          y: 0
        }}
        className="absolute cursor-pointer"
        style={{
          left: `${marker.position.x}%`,
          top: `${marker.position.y}%`,
          transform: "translate(-50%, -100%)",
          zIndex: isHighlighted || isSelected ? 100 : 10
        }}
        onMouseEnter={() => onMarkerHover?.(school.id)}
        onMouseLeave={() => onMarkerHover?.(null)}
        onClick={() => handleMarkerClick(school.id)}
      >
        <div className="relative">
          <div className={`w-10 h-10 ${colors.bg} rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-all`}>
            {school.logo_url ? (
              <img 
                src={school.logo_url} 
                alt="" 
                className="w-6 h-6 rounded-full object-cover"
              />
            ) : (
              <MapPin className="w-5 h-5 text-white" />
            )}
          </div>
          
          <div className={`absolute -bottom-1 left-1/2 -translate-x-1/2 w-3 h-3 ${colors.bg} rotate-45 border-r border-b border-white`} />
          
          {school.rating && (
            <div className="absolute -top-2 -right-2 px-1.5 py-0.5 bg-amber-500 text-white text-xs font-bold rounded-full flex items-center gap-0.5">
              <Star className="w-2.5 h-2.5 fill-white" />
              {school.rating.toFixed(1)}
            </div>
          )}

          {isSaved && (
            <div className="absolute -top-2 -left-2 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
              <BookmarkCheck className="w-3 h-3 text-white" />
            </div>
          )}
        </div>

        {(isHighlighted || isSelected) && !uiState.showSchoolPopup && (
          <motion.div
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute top-full left-1/2 -translate-x-1/2 mt-2 whitespace-nowrap"
          >
            <div className="px-3 py-1.5 bg-white rounded-lg shadow-lg border border-gray-200">
              <p className="text-sm font-semibold text-gray-900">{school.name}</p>
              {school.starting_price && (
                <p className="text-xs text-gray-600">From €{school.starting_price}</p>
              )}
            </div>
          </motion.div>
        )}
      </motion.div>
    );
  };

  return (
    <div 
      ref={mapContainerRef}
      className={`relative bg-slate-100 rounded-2xl border border-slate-200 overflow-hidden ${
        uiState.isFullscreen ? "fixed inset-0 z-50 rounded-none" : "sticky top-24 h-[calc(100vh-6rem)]"
      } ${className}`}
    >
      <div className="absolute inset-0">
        <div className={`w-full h-full ${
          uiState.mapStyle === "satellite" 
            ? "bg-gradient-to-br from-slate-700 via-slate-600 to-slate-800" 
            : uiState.mapStyle === "terrain"
              ? "bg-gradient-to-br from-green-100 via-amber-50 to-blue-100"
              : "bg-gradient-to-br from-slate-200 via-slate-100 to-slate-200"
        }`}>
          <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-slate-400" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>

          <svg className="absolute inset-0 w-full h-full opacity-30" xmlns="http://www.w3.org/2000/svg">
            <path d="M0,200 Q100,150 200,180 T400,160 T600,200" fill="none" stroke="#94a3b8" strokeWidth="2" />
            <path d="M50,100 L150,100 L200,150 L350,150 L400,100 L550,100" fill="none" stroke="#cbd5e1" strokeWidth="3" />
            <path d="M100,300 L100,50" fill="none" stroke="#cbd5e1" strokeWidth="3" />
          </svg>
        </div>
      </div>

      {showSearch && (
        <div className="absolute top-4 left-4 right-4 z-20">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                placeholder="Search location..."
                value={searchState.query}
                onChange={(e) => handleSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white rounded-xl shadow-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
              />
              {searchState.isSearching && (
                <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-indigo-600 animate-spin" />
              )}
            </div>

            <button
              onClick={handleSearchArea}
              className="px-4 py-2.5 bg-white rounded-xl shadow-lg border border-slate-200 text-sm font-semibold text-slate-900 hover:bg-slate-50 transition flex items-center gap-2"
            >
              <Navigation className="w-4 h-4" />
              <span className="hidden sm:inline">Search this area</span>
            </button>

            <button
              onClick={() => setUiState(prev => ({ ...prev, showFilters: !prev.showFilters }))}
              className={`p-2.5 rounded-xl shadow-lg border transition ${
                uiState.showFilters 
                  ? "bg-indigo-600 text-white border-indigo-600" 
                  : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
              }`}
            >
              <Filter className="w-5 h-5" />
            </button>
          </div>

          <AnimatePresence>
            {uiState.showFilters && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-2 p-4 bg-white rounded-xl shadow-lg border border-slate-200"
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold text-slate-900">Filters</h4>
                  <button
                    onClick={() => setFilters({
                      rating: 0,
                      priceRange: [0, 200],
                      transmissionType: "all",
                      hasAvailability: false,
                      isVerified: false
                    })}
                    className="text-xs text-indigo-600 hover:text-indigo-700"
                  >
                    Reset all
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-medium text-slate-600 mb-1 block">Minimum Rating</label>
                    <div className="flex gap-1">
                      {[0, 3, 3.5, 4, 4.5].map(rating => (
                        <button
                          key={rating}
                          onClick={() => setFilters(prev => ({ ...prev, rating }))}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                            filters.rating === rating
                              ? "bg-indigo-600 text-white"
                              : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                          }`}
                        >
                          {rating === 0 ? "Any" : `${rating}+`}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-medium text-slate-600 mb-1 block">Transmission</label>
                    <div className="flex gap-1">
                      {[
                        { id: "all", label: "All" },
                        { id: "manual", label: "Manual" },
                        { id: "automatic", label: "Automatic" }
                      ].map(type => (
                        <button
                          key={type.id}
                          onClick={() => setFilters(prev => ({ ...prev, transmissionType: type.id }))}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                            filters.transmissionType === type.id
                              ? "bg-indigo-600 text-white"
                              : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                          }`}
                        >
                          {type.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.hasAvailability}
                        onChange={(e) => setFilters(prev => ({ ...prev, hasAvailability: e.target.checked }))}
                        className="w-4 h-4 text-indigo-600 rounded"
                      />
                      <span className="text-xs text-slate-600">Available now</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.isVerified}
                        onChange={(e) => setFilters(prev => ({ ...prev, isVerified: e.target.checked }))}
                        className="w-4 h-4 text-indigo-600 rounded"
                      />
                      <span className="text-xs text-slate-600">Verified only</span>
                    </label>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      {showControls && (
        <div className="absolute right-4 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-2">
          <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
            <button
              onClick={handleZoomIn}
              disabled={mapState.zoom >= ZOOM_LEVELS.max}
              className="p-2.5 hover:bg-slate-50 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ZoomIn className="w-5 h-5 text-slate-600" />
            </button>
            <div className="h-px bg-slate-200" />
            <button
              onClick={handleZoomOut}
              disabled={mapState.zoom <= ZOOM_LEVELS.min}
              className="p-2.5 hover:bg-slate-50 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ZoomOut className="w-5 h-5 text-slate-600" />
            </button>
          </div>

          <button
            onClick={handleLocateUser}
            className="p-2.5 bg-white rounded-xl shadow-lg border border-slate-200 hover:bg-slate-50 transition"
          >
            <LocateFixed className="w-5 h-5 text-slate-600" />
          </button>

          <button
            onClick={handleResetView}
            className="p-2.5 bg-white rounded-xl shadow-lg border border-slate-200 hover:bg-slate-50 transition"
          >
            <RotateCcw className="w-5 h-5 text-slate-600" />
          </button>

          <div className="relative">
            <button
              onClick={() => setUiState(prev => ({ ...prev, showLayers: !prev.showLayers }))}
              className={`p-2.5 rounded-xl shadow-lg border transition ${
                uiState.showLayers 
                  ? "bg-indigo-600 text-white border-indigo-600" 
                  : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
              }`}
            >
              <Layers className="w-5 h-5" />
            </button>

            <AnimatePresence>
              {uiState.showLayers && (
                <motion.div
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="absolute right-full mr-2 top-0 p-2 bg-white rounded-xl shadow-lg border border-slate-200 min-w-[140px]"
                >
                  <p className="text-xs font-semibold text-slate-500 mb-2 px-2">Map Style</p>
                  {MAP_STYLES.map(style => (
                    <button
                      key={style.id}
                      onClick={() => setUiState(prev => ({ ...prev, mapStyle: style.id }))}
                      className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-sm transition ${
                        uiState.mapStyle === style.id
                          ? "bg-indigo-50 text-indigo-600"
                          : "text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      <style.icon className="w-4 h-4" />
                      {style.label}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <button
            onClick={handleToggleFullscreen}
            className="p-2.5 bg-white rounded-xl shadow-lg border border-slate-200 hover:bg-slate-50 transition"
          >
            {uiState.isFullscreen ? (
              <Minimize2 className="w-5 h-5 text-slate-600" />
            ) : (
              <Maximize2 className="w-5 h-5 text-slate-600" />
            )}
          </button>
        </div>
      )}

      <div className="absolute inset-0 z-10">
        {userLocation && (
          <div
            className="absolute z-20"
            style={{
              left: "50%",
              top: "50%",
              transform: "translate(-50%, -50%)"
            }}
          >
            <div className="relative">
              <div className="w-6 h-6 bg-blue-500 rounded-full border-3 border-white shadow-lg flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full" />
              </div>
              <div className="absolute inset-0 bg-blue-500 rounded-full animate-ping opacity-30" />
            </div>
          </div>
        )}

        {clusteredMarkers.map((marker, index) => renderMarker(marker, index))}
      </div>

      <AnimatePresence>
        {selectedSchool && uiState.showSchoolPopup && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="absolute bottom-4 left-4 right-4 z-30 max-w-md mx-auto"
          >
            <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
              <div className="relative h-32">
                {selectedSchool.cover_image_url ? (
                  <img 
                    src={selectedSchool.cover_image_url} 
                    alt={selectedSchool.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-indigo-500 to-purple-500" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                
                <button
                  onClick={() => setUiState(prev => ({ ...prev, showSchoolPopup: null }))}
                  className="absolute top-2 right-2 p-1.5 bg-black/30 hover:bg-black/50 rounded-full transition"
                >
                  <X className="w-4 h-4 text-white" />
                </button>

                <button
                  onClick={() => handleSaveSchool(selectedSchool.id)}
                  className="absolute top-2 left-2 p-1.5 bg-black/30 hover:bg-black/50 rounded-full transition"
                >
                  {savedSchools.includes(selectedSchool.id) ? (
                    <BookmarkCheck className="w-4 h-4 text-white" />
                  ) : (
                    <Bookmark className="w-4 h-4 text-white" />
                  )}
                </button>

                <div className="absolute bottom-3 left-3 right-3">
                  <h3 className="font-bold text-white text-lg drop-shadow-md line-clamp-1">
                    {selectedSchool.name}
                  </h3>
                  <div className="flex items-center gap-2 text-white/90 text-sm">
                    <MapPin className="w-3.5 h-3.5" />
                    <span className="line-clamp-1">{selectedSchool.city || selectedSchool.address}</span>
                  </div>
                </div>
              </div>

              <div className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 px-2 py-1 bg-amber-50 rounded-lg">
                      <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                      <span className="font-bold text-gray-900">{selectedSchool.rating?.toFixed(1) || "5.0"}</span>
                    </div>
                    <span className="text-sm text-gray-500">({selectedSchool.total_reviews || 0} reviews)</span>
                  </div>
                  {selectedSchool.is_verified && (
                    <span className="px-2 py-1 bg-green-50 text-green-700 text-xs font-semibold rounded-lg flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      Verified
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
                  {selectedSchool.instructor_count && (
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      <span>{selectedSchool.instructor_count} instructors</span>
                    </div>
                  )}
                  {selectedSchool.vehicle_count && (
                    <div className="flex items-center gap-1">
                      <Car className="w-4 h-4" />
                      <span>{selectedSchool.vehicle_count} vehicles</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-gray-500">Starting from</p>
                    <p className="text-xl font-bold text-gray-900">
                      €{selectedSchool.starting_price || 45}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    {selectedSchool.phone && (
                      <a
                        href={`tel:${selectedSchool.phone}`}
                        className="p-2.5 border border-gray-200 rounded-xl hover:bg-gray-50 transition"
                      >
                        <Phone className="w-5 h-5 text-gray-600" />
                      </a>
                    )}
                    <a
                      href={`${createPageUrl("SchoolProfile")}?id=${selectedSchool.id}`}
                      className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition flex items-center gap-1"
                    >
                      View Details
                      <ChevronRight className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="absolute bottom-4 left-4 z-20">
        <div className="px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-lg shadow-sm border border-slate-200 text-xs text-slate-600">
          {visibleSchools.length} schools • Zoom: {mapState.zoom}x
        </div>
      </div>

      {isLoading && (
        <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-40 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-10 h-10 text-indigo-600 animate-spin mx-auto mb-3" />
            <p className="text-sm text-slate-600">Loading map...</p>
          </div>
        </div>
      )}

      {schools.length === 0 && !isLoading && (
        <div className="absolute inset-0 flex items-center justify-center z-30">
          <div className="text-center max-w-xs">
            <MapPin className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-700 mb-2">
              No Schools Found
            </h3>
            <p className="text-sm text-slate-600">
              Try searching a different area or adjusting your filters
            </p>
          </div>
        </div>
      )}
    </div>
  );
}