import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap, useMapEvents, Circle, Rectangle, Polygon } from "react-leaflet";
import { 
  MapPin, 
  Navigation, 
  ZoomIn, 
  ZoomOut, 
  Locate, 
  Layers,
  Search,
  X,
  Star,
  Phone,
  Car,
  Users,
  ChevronRight,
  Maximize2,
  Minimize2,
  RotateCcw,
  Loader2,
  CheckCircle,
  Square,
  Circle as CircleIcon,
  Pentagon,
  Trash2,
  MousePointer,
  Hand,
  Target
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { createPageUrl } from "@/utils";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Fix Leaflet default marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom marker icons
const createCustomIcon = (color, isHighlighted = false, isSelected = false) => {
  const size = isHighlighted || isSelected ? 40 : 32;
  const bgColor = isSelected ? '#5cb83a' : isHighlighted ? '#e7d356' : color;
  
  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        width: ${size}px;
        height: ${size}px;
        background: ${bgColor};
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        border: 3px solid white;
        box-shadow: 0 4px 12px rgba(0,0,0,0.25);
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <div style="
          transform: rotate(45deg);
          color: white;
          font-weight: bold;
          font-size: ${isHighlighted ? '14px' : '12px'};
        ">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
            <circle cx="12" cy="10" r="3"></circle>
          </svg>
        </div>
      </div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size],
    popupAnchor: [0, -size],
  });
};

// Map controller component
function MapController({ center, zoom, onBoundsChange }) {
  const map = useMap();
  
  useEffect(() => {
    if (center) {
      map.setView([center.lat, center.lng], zoom);
    }
  }, [center, zoom, map]);

  useMapEvents({
    moveend: () => {
      const bounds = map.getBounds();
      if (onBoundsChange) {
        onBoundsChange({
          north: bounds.getNorth(),
          south: bounds.getSouth(),
          east: bounds.getEast(),
          west: bounds.getWest(),
        });
      }
    },
  });

  return null;
}

// Drawing tool component
function DrawingLayer({ 
  mode, 
  onDrawComplete, 
  drawingShape, 
  setDrawingShape,
  isDrawing,
  setIsDrawing 
}) {
  const map = useMap();
  const [points, setPoints] = useState([]);
  const [circleCenter, setCircleCenter] = useState(null);
  const [circleRadius, setCircleRadius] = useState(0);

  useMapEvents({
    click: (e) => {
      if (!mode || mode === 'pan') return;
      
      const { lat, lng } = e.latlng;
      
      if (mode === 'circle') {
        if (!circleCenter) {
          setCircleCenter({ lat, lng });
          setIsDrawing(true);
        } else {
          // Calculate radius
          const center = L.latLng(circleCenter.lat, circleCenter.lng);
          const point = L.latLng(lat, lng);
          const radius = center.distanceTo(point);
          
          setDrawingShape({
            type: 'circle',
            center: circleCenter,
            radius: radius
          });
          
          onDrawComplete?.({
            type: 'circle',
            center: circleCenter,
            radius: radius
          });
          
          setCircleCenter(null);
          setCircleRadius(0);
          setIsDrawing(false);
        }
      } else if (mode === 'rectangle') {
        if (points.length === 0) {
          setPoints([{ lat, lng }]);
          setIsDrawing(true);
        } else {
          const bounds = {
            north: Math.max(points[0].lat, lat),
            south: Math.min(points[0].lat, lat),
            east: Math.max(points[0].lng, lng),
            west: Math.min(points[0].lng, lng),
          };
          
          setDrawingShape({
            type: 'rectangle',
            bounds: bounds
          });
          
          onDrawComplete?.({
            type: 'rectangle',
            bounds: bounds
          });
          
          setPoints([]);
          setIsDrawing(false);
        }
      } else if (mode === 'polygon') {
        setPoints(prev => [...prev, { lat, lng }]);
        setIsDrawing(true);
      }
    },
    dblclick: (e) => {
      if (mode === 'polygon' && points.length >= 3) {
        setDrawingShape({
          type: 'polygon',
          points: [...points]
        });
        
        onDrawComplete?.({
          type: 'polygon',
          points: [...points]
        });
        
        setPoints([]);
        setIsDrawing(false);
      }
    },
    mousemove: (e) => {
      if (mode === 'circle' && circleCenter) {
        const center = L.latLng(circleCenter.lat, circleCenter.lng);
        const point = L.latLng(e.latlng.lat, e.latlng.lng);
        setCircleRadius(center.distanceTo(point));
      }
    }
  });

  return (
    <>
      {/* Preview while drawing */}
      {mode === 'circle' && circleCenter && circleRadius > 0 && (
        <Circle
          center={[circleCenter.lat, circleCenter.lng]}
          radius={circleRadius}
          pathOptions={{
            color: '#3b82c4',
            fillColor: '#a9d5ed',
            fillOpacity: 0.3,
            dashArray: '5, 5'
          }}
        />
      )}
      
      {mode === 'rectangle' && points.length === 1 && (
        <Circle
          center={[points[0].lat, points[0].lng]}
          radius={50}
          pathOptions={{
            color: '#3b82c4',
            fillColor: '#a9d5ed',
            fillOpacity: 0.5,
          }}
        />
      )}
      
      {mode === 'polygon' && points.length > 0 && (
        <Polygon
          positions={points.map(p => [p.lat, p.lng])}
          pathOptions={{
            color: '#3b82c4',
            fillColor: '#a9d5ed',
            fillOpacity: 0.3,
            dashArray: '5, 5'
          }}
        />
      )}

      {/* Completed shapes */}
      {drawingShape?.type === 'circle' && (
        <Circle
          center={[drawingShape.center.lat, drawingShape.center.lng]}
          radius={drawingShape.radius}
          pathOptions={{
            color: '#3b82c4',
            fillColor: '#a9d5ed',
            fillOpacity: 0.2,
            weight: 2
          }}
        />
      )}
      
      {drawingShape?.type === 'rectangle' && (
        <Rectangle
          bounds={[
            [drawingShape.bounds.south, drawingShape.bounds.west],
            [drawingShape.bounds.north, drawingShape.bounds.east]
          ]}
          pathOptions={{
            color: '#3b82c4',
            fillColor: '#a9d5ed',
            fillOpacity: 0.2,
            weight: 2
          }}
        />
      )}
      
      {drawingShape?.type === 'polygon' && (
        <Polygon
          positions={drawingShape.points.map(p => [p.lat, p.lng])}
          pathOptions={{
            color: '#3b82c4',
            fillColor: '#a9d5ed',
            fillOpacity: 0.2,
            weight: 2
          }}
        />
      )}
    </>
  );
}

// School popup content
function SchoolPopup({ school, onViewDetails }) {
  return (
    <div className="w-72">
      {school.cover_image_url && (
        <div className="relative h-28 -mx-3 -mt-3 mb-3">
          <img 
            src={school.cover_image_url} 
            alt={school.name}
            className="w-full h-full object-cover rounded-t-lg"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-t-lg" />
        </div>
      )}
      
      <h3 className="font-bold text-slate-900 text-base mb-1">{school.name}</h3>
      
      <div className="flex items-center gap-2 mb-2">
        <div className="flex items-center gap-1 px-2 py-0.5 bg-[#fdfbe8] rounded-lg">
          <Star className="w-3.5 h-3.5 text-[#b8a525] fill-[#e7d356]" />
          <span className="font-bold text-sm text-slate-900">{school.avgRating?.toFixed(1) || "5.0"}</span>
        </div>
        <span className="text-xs text-slate-500">({school.reviewCount || 0} reviews)</span>
        {school.is_verified && (
          <span className="px-1.5 py-0.5 bg-[#eefbe7] text-[#5cb83a] text-xs font-semibold rounded flex items-center gap-0.5">
            <CheckCircle className="w-3 h-3" />
          </span>
        )}
      </div>

      <div className="flex items-center gap-1 text-xs text-slate-500 mb-2">
        <MapPin className="w-3.5 h-3.5" />
        <span className="line-clamp-1">{school.city || school.address}</span>
      </div>

      <div className="flex items-center gap-3 mb-3 text-xs text-slate-600">
        {school.instructorCount > 0 && (
          <div className="flex items-center gap-1">
            <Users className="w-3.5 h-3.5" />
            <span>{school.instructorCount} instructors</span>
          </div>
        )}
        {school.vehicleCount > 0 && (
          <div className="flex items-center gap-1">
            <Car className="w-3.5 h-3.5" />
            <span>{school.vehicleCount} vehicles</span>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between pt-2 border-t border-slate-100">
        <div>
          <p className="text-[10px] text-slate-400 uppercase font-medium">From</p>
          <p className="text-lg font-bold text-slate-900">€{school.minPrice || 45}</p>
        </div>
        <button
          onClick={() => onViewDetails(school.id)}
          className="px-3 py-2 bg-gradient-to-r from-[#3b82c4] to-[#2563a3] hover:from-[#2563a3] hover:to-[#1e4f8a] text-white rounded-lg text-xs font-semibold transition-all flex items-center gap-1"
        >
          View Details
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}

export default function InteractiveMap({ 
  schools = [], 
  highlightedSchoolId, 
  selectedSchoolId,
  onMarkerClick,
  onMarkerHover,
  onAreaSearch,
  onSchoolsInArea,
  userLocation,
  isLoading = false,
  showControls = true,
  showDrawTools = true,
  className = ""
}) {
  const [mapCenter, setMapCenter] = useState({ lat: 48.8566, lng: 2.3522 }); // Paris default
  const [mapZoom, setMapZoom] = useState(12);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [drawMode, setDrawMode] = useState(null); // 'circle', 'rectangle', 'polygon', 'pan'
  const [drawingShape, setDrawingShape] = useState(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [mapBounds, setMapBounds] = useState(null);
  const [showLayerMenu, setShowLayerMenu] = useState(false);
  const [tileLayer, setTileLayer] = useState('default');
  const mapRef = useRef(null);

  // Calculate center from schools
  useEffect(() => {
    if (schools.length > 0) {
      const schoolsWithCoords = schools.filter(s => s.latitude && s.longitude);
      if (schoolsWithCoords.length > 0) {
        const avgLat = schoolsWithCoords.reduce((sum, s) => sum + s.latitude, 0) / schoolsWithCoords.length;
        const avgLng = schoolsWithCoords.reduce((sum, s) => sum + s.longitude, 0) / schoolsWithCoords.length;
        setMapCenter({ lat: avgLat, lng: avgLng });
      }
    }
  }, [schools]);

  // Filter schools in drawn area
  const schoolsInArea = useMemo(() => {
    if (!drawingShape) return schools;

    return schools.filter(school => {
      if (!school.latitude || !school.longitude) return true;

      if (drawingShape.type === 'circle') {
        const center = L.latLng(drawingShape.center.lat, drawingShape.center.lng);
        const point = L.latLng(school.latitude, school.longitude);
        return center.distanceTo(point) <= drawingShape.radius;
      }

      if (drawingShape.type === 'rectangle') {
        const { north, south, east, west } = drawingShape.bounds;
        return (
          school.latitude >= south &&
          school.latitude <= north &&
          school.longitude >= west &&
          school.longitude <= east
        );
      }

      if (drawingShape.type === 'polygon') {
        // Point in polygon check
        const polygon = drawingShape.points;
        let inside = false;
        for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
          const xi = polygon[i].lng, yi = polygon[i].lat;
          const xj = polygon[j].lng, yj = polygon[j].lat;
          
          if (((yi > school.latitude) !== (yj > school.latitude)) &&
              (school.longitude < (xj - xi) * (school.latitude - yi) / (yj - yi) + xi)) {
            inside = !inside;
          }
        }
        return inside;
      }

      return true;
    });
  }, [schools, drawingShape]);

  // Notify parent when schools in area changes
  useEffect(() => {
    if (onSchoolsInArea && drawingShape) {
      onSchoolsInArea(schoolsInArea);
    }
  }, [schoolsInArea, drawingShape, onSchoolsInArea]);

  const handleDrawComplete = useCallback((shape) => {
    setDrawMode(null);
    if (onAreaSearch) {
      onAreaSearch(shape);
    }
  }, [onAreaSearch]);

  const clearDrawing = useCallback(() => {
    setDrawingShape(null);
    setDrawMode(null);
    if (onSchoolsInArea) {
      onSchoolsInArea(schools);
    }
  }, [schools, onSchoolsInArea]);

  const handleViewDetails = useCallback((schoolId) => {
    window.location.href = `${createPageUrl("SchoolProfile")}?id=${schoolId}`;
  }, []);

  const tileLayers = {
    default: {
      url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
      attribution: '© OpenStreetMap'
    },
    satellite: {
      url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      attribution: '© Esri'
    },
    terrain: {
      url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
      attribution: '© OpenTopoMap'
    }
  };

  return (
    <div 
      className={`relative rounded-2xl overflow-hidden border border-slate-200 ${
        isFullscreen ? "fixed inset-0 z-50 rounded-none" : "h-full"
      } ${className}`}
    >
      {/* Drawing Tools Bar */}
      {showDrawTools && (
        <div className="absolute top-4 left-4 z-[1000] flex items-center gap-2">
          <div className="flex bg-white rounded-xl shadow-premium border border-slate-200 overflow-hidden">
            <button
              onClick={() => setDrawMode(drawMode === 'pan' ? null : 'pan')}
              className={`p-2.5 transition-all ${
                !drawMode || drawMode === 'pan' 
                  ? 'bg-[#e8f4fa] text-[#3b82c4]' 
                  : 'hover:bg-slate-50 text-slate-600'
              }`}
              title="Pan"
            >
              <Hand className="w-4 h-4" />
            </button>
            <div className="w-px bg-slate-200" />
            <button
              onClick={() => setDrawMode(drawMode === 'circle' ? null : 'circle')}
              className={`p-2.5 transition-all ${
                drawMode === 'circle' 
                  ? 'bg-[#e8f4fa] text-[#3b82c4]' 
                  : 'hover:bg-slate-50 text-slate-600'
              }`}
              title="Draw circle"
            >
              <CircleIcon className="w-4 h-4" />
            </button>
            <div className="w-px bg-slate-200" />
            <button
              onClick={() => setDrawMode(drawMode === 'rectangle' ? null : 'rectangle')}
              className={`p-2.5 transition-all ${
                drawMode === 'rectangle' 
                  ? 'bg-[#e8f4fa] text-[#3b82c4]' 
                  : 'hover:bg-slate-50 text-slate-600'
              }`}
              title="Draw rectangle"
            >
              <Square className="w-4 h-4" />
            </button>
            <div className="w-px bg-slate-200" />
            <button
              onClick={() => setDrawMode(drawMode === 'polygon' ? null : 'polygon')}
              className={`p-2.5 transition-all ${
                drawMode === 'polygon' 
                  ? 'bg-[#e8f4fa] text-[#3b82c4]' 
                  : 'hover:bg-slate-50 text-slate-600'
              }`}
              title="Draw polygon (double-click to finish)"
            >
              <Pentagon className="w-4 h-4" />
            </button>
          </div>

          {drawingShape && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              onClick={clearDrawing}
              className="p-2.5 bg-[#fdeeed] border border-[#f9d4d2] text-[#e44138] rounded-xl shadow-premium hover:bg-[#f9d4d2] transition-all"
              title="Clear drawing"
            >
              <Trash2 className="w-4 h-4" />
            </motion.button>
          )}

          {isDrawing && (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="px-3 py-2 bg-white rounded-xl shadow-premium border border-slate-200 text-xs font-medium text-slate-600"
            >
              {drawMode === 'circle' && "Click to set center, then click again to set radius"}
              {drawMode === 'rectangle' && "Click to set first corner, then click for opposite corner"}
              {drawMode === 'polygon' && "Click to add points, double-click to finish"}
            </motion.div>
          )}
        </div>
      )}

      {/* Search in area indicator */}
      {drawingShape && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-4 left-1/2 -translate-x-1/2 z-[1000] px-4 py-2 bg-[#e8f4fa] border border-[#d4eaf5] rounded-xl shadow-premium text-sm font-semibold text-[#3b82c4] flex items-center gap-2"
        >
          <Target className="w-4 h-4" />
          {schoolsInArea.length} schools in selected area
        </motion.div>
      )}

      {/* Map Controls */}
      {showControls && (
        <div className="absolute right-4 top-1/2 -translate-y-1/2 z-[1000] flex flex-col gap-2">
          <div className="bg-white rounded-xl shadow-premium border border-slate-200 overflow-hidden">
            <button
              onClick={() => setMapZoom(z => Math.min(z + 1, 18))}
              className="p-2.5 hover:bg-slate-50 transition-colors text-slate-600"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <div className="h-px bg-slate-200" />
            <button
              onClick={() => setMapZoom(z => Math.max(z - 1, 5))}
              className="p-2.5 hover:bg-slate-50 transition-colors text-slate-600"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => {
              if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition((pos) => {
                  setMapCenter({ lat: pos.coords.latitude, lng: pos.coords.longitude });
                  setMapZoom(14);
                });
              }
            }}
            className="p-2.5 bg-white rounded-xl shadow-premium border border-slate-200 hover:bg-slate-50 transition-colors text-slate-600"
          >
            <Locate className="w-4 h-4" />
          </button>

          <div className="relative">
            <button
              onClick={() => setShowLayerMenu(!showLayerMenu)}
              className={`p-2.5 rounded-xl shadow-premium border transition-colors ${
                showLayerMenu 
                  ? 'bg-[#3b82c4] border-[#3b82c4] text-white' 
                  : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-600'
              }`}
            >
              <Layers className="w-4 h-4" />
            </button>

            <AnimatePresence>
              {showLayerMenu && (
                <motion.div
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="absolute right-full mr-2 top-0 p-2 bg-white rounded-xl shadow-premium-lg border border-slate-200 min-w-[120px]"
                >
                  {Object.keys(tileLayers).map(layer => (
                    <button
                      key={layer}
                      onClick={() => {
                        setTileLayer(layer);
                        setShowLayerMenu(false);
                      }}
                      className={`w-full px-3 py-2 rounded-lg text-sm font-medium capitalize transition-colors ${
                        tileLayer === layer 
                          ? 'bg-[#e8f4fa] text-[#3b82c4]' 
                          : 'text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {layer}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2.5 bg-white rounded-xl shadow-premium border border-slate-200 hover:bg-slate-50 transition-colors text-slate-600"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      )}

      {/* Info badge */}
      <div className="absolute bottom-4 left-4 z-[1000]">
        <div className="px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-lg shadow-premium border border-slate-200 text-xs font-medium text-slate-600">
          {drawingShape ? schoolsInArea.length : schools.length} schools • Zoom: {mapZoom}x
        </div>
      </div>

      {/* Leaflet Map */}
      <MapContainer
        ref={mapRef}
        center={[mapCenter.lat, mapCenter.lng]}
        zoom={mapZoom}
        className="w-full h-full z-0"
        zoomControl={false}
        style={{ background: '#f1f5f9' }}
      >
        <TileLayer
          url={tileLayers[tileLayer].url}
          attribution={tileLayers[tileLayer].attribution}
        />
        
        <MapController 
          center={mapCenter} 
          zoom={mapZoom} 
          onBoundsChange={setMapBounds}
        />

        <DrawingLayer
          mode={drawMode}
          onDrawComplete={handleDrawComplete}
          drawingShape={drawingShape}
          setDrawingShape={setDrawingShape}
          isDrawing={isDrawing}
          setIsDrawing={setIsDrawing}
        />

        {/* School markers */}
        {(drawingShape ? schoolsInArea : schools).map(school => {
          if (!school.latitude || !school.longitude) return null;
          
          const isHighlighted = highlightedSchoolId === school.id;
          const isSelected = selectedSchoolId === school.id;
          
          return (
            <Marker
              key={school.id}
              position={[school.latitude, school.longitude]}
              icon={createCustomIcon('#3b82c4', isHighlighted, isSelected)}
              eventHandlers={{
                click: () => onMarkerClick?.(school.id),
                mouseover: () => onMarkerHover?.(school.id),
                mouseout: () => onMarkerHover?.(null),
              }}
            >
              <Popup className="school-popup" maxWidth={300}>
                <SchoolPopup school={school} onViewDetails={handleViewDetails} />
              </Popup>
            </Marker>
          );
        })}

        {/* User location */}
        {userLocation && (
          <Circle
            center={[userLocation.lat, userLocation.lng]}
            radius={100}
            pathOptions={{
              color: '#3b82c4',
              fillColor: '#a9d5ed',
              fillOpacity: 0.3,
            }}
          />
        )}
      </MapContainer>

      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-[2000] flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-10 h-10 text-[#3b82c4] animate-spin mx-auto mb-3" />
            <p className="text-sm font-medium text-slate-600">Loading map...</p>
          </div>
        </div>
      )}

      {/* Custom styles */}
      <style>{`
        .leaflet-popup-content-wrapper {
          border-radius: 12px;
          padding: 0;
          box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        }
        .leaflet-popup-content {
          margin: 12px;
        }
        .leaflet-popup-tip {
          background: white;
        }
        .leaflet-container {
          font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
        }
        .custom-marker {
          background: none !important;
          border: none !important;
        }
      `}</style>
    </div>
  );
}