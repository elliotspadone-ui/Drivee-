import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Bell, Calendar, DollarSign, Save } from "lucide-react";
import { toast } from "sonner";

export default function ReminderSettings({ schoolId }) {
  const queryClient = useQueryClient();
  const [settings, setSettings] = useState({
    lesson_reminder_hours: 24,
    lesson_reminder_enabled: true,
    invoice_reminder_days: 3,
    invoice_reminder_enabled: true,
  });

  const { data: automationRules = [] } = useQuery({
    queryKey: ['automationRules', schoolId],
    queryFn: () => base44.entities.AutomationRule.filter({ school_id: schoolId }),
    enabled: !!schoolId,
  });

  useEffect(() => {
    const lessonRule = automationRules.find(r => r.trigger_type === "lesson_reminder");
    const invoiceRule = automationRules.find(r => r.trigger_type === "invoice_reminder");

    if (lessonRule) {
      setSettings(prev => ({
        ...prev,
        lesson_reminder_hours: lessonRule.trigger_hours_before || 24,
        lesson_reminder_enabled: lessonRule.is_active,
      }));
    }

    if (invoiceRule) {
      setSettings(prev => ({
        ...prev,
        invoice_reminder_days: invoiceRule.trigger_days_before || 3,
        invoice_reminder_enabled: invoiceRule.is_active,
      }));
    }
  }, [automationRules]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const lessonRule = automationRules.find(r => r.trigger_type === "lesson_reminder");
      const invoiceRule = automationRules.find(r => r.trigger_type === "invoice_reminder");

      const promises = [];

      // Lesson reminder
      if (lessonRule) {
        promises.push(
          base44.entities.AutomationRule.update(lessonRule.id, {
            ...lessonRule,
            trigger_hours_before: settings.lesson_reminder_hours,
            is_active: settings.lesson_reminder_enabled,
          })
        );
      } else {
        promises.push(
          base44.entities.AutomationRule.create({
            school_id: schoolId,
            rule_name: "Lesson Reminder",
            trigger_type: "lesson_reminder",
            trigger_hours_before: settings.lesson_reminder_hours,
            action_type: "send_email",
            is_active: settings.lesson_reminder_enabled,
          })
        );
      }

      // Invoice reminder
      if (invoiceRule) {
        promises.push(
          base44.entities.AutomationRule.update(invoiceRule.id, {
            ...invoiceRule,
            trigger_days_before: settings.invoice_reminder_days,
            is_active: settings.invoice_reminder_enabled,
          })
        );
      } else {
        promises.push(
          base44.entities.AutomationRule.create({
            school_id: schoolId,
            rule_name: "Invoice Due Reminder",
            trigger_type: "invoice_reminder",
            trigger_days_before: settings.invoice_reminder_days,
            action_type: "send_email",
            is_active: settings.invoice_reminder_enabled,
          })
        );
      }

      await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['automationRules'] });
      toast.success("Reminder settings saved");
    },
  });

  return (
    <div className="bg-white rounded-2xl shadow-sm p-6 space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
          <Bell className="w-5 h-5 text-indigo-600" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Automated Reminders</h2>
          <p className="text-sm text-gray-600">Configure automatic notifications for students</p>
        </div>
      </div>

      {/* Lesson Reminders */}
      <div className="border-2 border-gray-200 rounded-xl p-4">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <Calendar className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="font-semibold text-gray-900">Lesson Reminders</h3>
              <p className="text-sm text-gray-600">Remind students about upcoming lessons</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.lesson_reminder_enabled}
              onChange={(e) => setSettings({ ...settings, lesson_reminder_enabled: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
          </label>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Send reminder before lesson
          </label>
          <select
            value={settings.lesson_reminder_hours}
            onChange={(e) => setSettings({ ...settings, lesson_reminder_hours: parseInt(e.target.value) })}
            className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-600"
          >
            <option value={1}>1 hour before</option>
            <option value={2}>2 hours before</option>
            <option value={4}>4 hours before</option>
            <option value={12}>12 hours before</option>
            <option value={24}>24 hours before</option>
            <option value={48}>48 hours before</option>
          </select>
        </div>
      </div>

      {/* Invoice Reminders */}
      <div className="border-2 border-gray-200 rounded-xl p-4">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <DollarSign className="w-5 h-5 text-green-600" />
            <div>
              <h3 className="font-semibold text-gray-900">Invoice Reminders</h3>
              <p className="text-sm text-gray-600">Remind students about invoice due dates</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.invoice_reminder_enabled}
              onChange={(e) => setSettings({ ...settings, invoice_reminder_enabled: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
          </label>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Send reminder before due date
          </label>
          <select
            value={settings.invoice_reminder_days}
            onChange={(e) => setSettings({ ...settings, invoice_reminder_days: parseInt(e.target.value) })}
            className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-600"
          >
            <option value={1}>1 day before</option>
            <option value={2}>2 days before</option>
            <option value={3}>3 days before</option>
            <option value={5}>5 days before</option>
            <option value={7}>7 days before</option>
          </select>
        </div>
      </div>

      <button
        onClick={() => saveMutation.mutate()}
        disabled={saveMutation.isPending}
        className="w-full px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
      >
        <Save className="w-5 h-5" />
        {saveMutation.isPending ? "Saving..." : "Save Settings"}
      </button>
    </div>
  );
}