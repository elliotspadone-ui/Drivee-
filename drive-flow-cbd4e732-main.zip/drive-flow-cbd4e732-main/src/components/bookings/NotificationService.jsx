import { base44 } from "@/api/base44Client";

export const sendBookingNotification = async (booking, type, students, instructors) => {
  const student = students.find(s => s.id === booking.student_id);
  const instructor = instructors.find(i => i.id === booking.instructor_id);
  
  if (!student || !instructor) return;

  const formatDateTime = (datetime) => {
    const date = new Date(datetime);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  let studentSubject = "";
  let studentBody = "";
  let instructorSubject = "";
  let instructorBody = "";

  switch (type) {
    case "confirmed":
      studentSubject = "Lesson Confirmed - DriveSchool";
      studentBody = `
        <h2>Your driving lesson has been confirmed!</h2>
        <p>Dear ${student.full_name},</p>
        <p>Great news! Your driving lesson has been confirmed.</p>
        <h3>Lesson Details:</h3>
        <ul>
          <li><strong>Date & Time:</strong> ${formatDateTime(booking.start_datetime)}</li>
          <li><strong>Instructor:</strong> ${instructor.full_name}</li>
          <li><strong>Pickup Location:</strong> ${booking.pickup_location || 'To be confirmed'}</li>
          <li><strong>Duration:</strong> ${Math.round((new Date(booking.end_datetime) - new Date(booking.start_datetime)) / 60000)} minutes</li>
        </ul>
        <p>Please be ready 5 minutes before your scheduled time.</p>
        <p>If you need to cancel or reschedule, please contact us as soon as possible.</p>
        <p>Best regards,<br>DriveSchool Team</p>
      `;

      instructorSubject = "New Lesson Assigned - DriveSchool";
      instructorBody = `
        <h2>New lesson assigned to you</h2>
        <p>Dear ${instructor.full_name},</p>
        <p>A new driving lesson has been assigned to you.</p>
        <h3>Lesson Details:</h3>
        <ul>
          <li><strong>Date & Time:</strong> ${formatDateTime(booking.start_datetime)}</li>
          <li><strong>Student:</strong> ${student.full_name}</li>
          <li><strong>Student Phone:</strong> ${student.phone || 'N/A'}</li>
          <li><strong>Pickup Location:</strong> ${booking.pickup_location || 'To be confirmed'}</li>
          <li><strong>License Category:</strong> ${student.license_category || 'N/A'}</li>
        </ul>
        <p>Please review your schedule and prepare accordingly.</p>
        <p>Best regards,<br>DriveSchool Team</p>
      `;
      break;

    case "cancelled":
      studentSubject = "Lesson Cancelled - DriveSchool";
      studentBody = `
        <h2>Your lesson has been cancelled</h2>
        <p>Dear ${student.full_name},</p>
        <p>We're writing to inform you that your driving lesson scheduled for ${formatDateTime(booking.start_datetime)} has been cancelled.</p>
        ${booking.cancellation_reason ? `<p><strong>Reason:</strong> ${booking.cancellation_reason}</p>` : ''}
        <p>Please contact us to reschedule your lesson at your convenience.</p>
        <p>We apologize for any inconvenience.</p>
        <p>Best regards,<br>DriveSchool Team</p>
      `;

      instructorSubject = "Lesson Cancelled - DriveSchool";
      instructorBody = `
        <h2>Lesson cancellation notification</h2>
        <p>Dear ${instructor.full_name},</p>
        <p>The following lesson has been cancelled:</p>
        <ul>
          <li><strong>Date & Time:</strong> ${formatDateTime(booking.start_datetime)}</li>
          <li><strong>Student:</strong> ${student.full_name}</li>
        </ul>
        ${booking.cancellation_reason ? `<p><strong>Reason:</strong> ${booking.cancellation_reason}</p>` : ''}
        <p>Your schedule has been updated accordingly.</p>
        <p>Best regards,<br>DriveSchool Team</p>
      `;
      break;

    case "rescheduled":
      studentSubject = "Lesson Rescheduled - DriveSchool";
      studentBody = `
        <h2>Your lesson has been rescheduled</h2>
        <p>Dear ${student.full_name},</p>
        <p>Your driving lesson has been rescheduled to a new time.</p>
        <h3>New Lesson Details:</h3>
        <ul>
          <li><strong>New Date & Time:</strong> ${formatDateTime(booking.start_datetime)}</li>
          <li><strong>Instructor:</strong> ${instructor.full_name}</li>
          <li><strong>Pickup Location:</strong> ${booking.pickup_location || 'To be confirmed'}</li>
        </ul>
        <p>Please make note of the new time.</p>
        <p>Best regards,<br>DriveSchool Team</p>
      `;

      instructorSubject = "Lesson Rescheduled - DriveSchool";
      instructorBody = `
        <h2>Lesson rescheduled</h2>
        <p>Dear ${instructor.full_name},</p>
        <p>A lesson with ${student.full_name} has been rescheduled.</p>
        <h3>New Lesson Details:</h3>
        <ul>
          <li><strong>New Date & Time:</strong> ${formatDateTime(booking.start_datetime)}</li>
          <li><strong>Student:</strong> ${student.full_name}</li>
          <li><strong>Pickup Location:</strong> ${booking.pickup_location || 'To be confirmed'}</li>
        </ul>
        <p>Your schedule has been updated.</p>
        <p>Best regards,<br>DriveSchool Team</p>
      `;
      break;
  }

  // Send emails
  try {
    if (student.email && studentSubject && studentBody) {
      await base44.integrations.Core.SendEmail({
        to: student.email,
        subject: studentSubject,
        body: studentBody,
      });
    }

    if (instructor.email && instructorSubject && instructorBody) {
      await base44.integrations.Core.SendEmail({
        to: instructor.email,
        subject: instructorSubject,
        body: instructorBody,
      });
    }
  } catch (error) {
    console.error("Failed to send notification emails:", error);
  }
};