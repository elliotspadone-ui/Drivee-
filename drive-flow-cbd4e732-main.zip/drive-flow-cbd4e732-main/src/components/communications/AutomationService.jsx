import { base44 } from "@/api/base44Client";
import { format, parseISO } from "date-fns";

// Replace template variables with actual data
export const replaceVariables = (text, data) => {
  if (!text) return "";
  
  let result = text;
  
  const replacements = {
    student_name: data.student?.full_name || "Student",
    student_first_name: data.student?.full_name?.split(" ")[0] || "Student",
    instructor_name: data.instructor?.full_name || "Instructor",
    lesson_date: data.booking?.start_datetime ? format(parseISO(data.booking.start_datetime), "EEEE, MMMM d, yyyy") : "",
    lesson_time: data.booking?.start_datetime ? format(parseISO(data.booking.start_datetime), "h:mm a") : "",
    lesson_duration: data.booking?.end_datetime && data.booking?.start_datetime 
      ? `${Math.round((parseISO(data.booking.end_datetime) - parseISO(data.booking.start_datetime)) / 60000)} minutes` 
      : "",
    pickup_location: data.booking?.pickup_location || "",
    vehicle_name: data.vehicle ? `${data.vehicle.make} ${data.vehicle.model}` : "",
    vehicle_plate: data.vehicle?.license_plate || "",
    price: data.booking?.price ? `€${data.booking.price}` : "",
    payment_amount: data.payment?.amount ? `€${data.payment.amount}` : "",
    invoice_number: data.invoice?.invoice_number || "",
    school_name: data.school?.name || "Driving School",
    school_phone: data.school?.phone || "",
    school_email: data.school?.email || "",
    booking_id: data.booking?.id?.substring(0, 8) || "",
    cancellation_reason: data.booking?.cancellation_reason || "",
  };

  Object.entries(replacements).forEach(([key, value]) => {
    result = result.replace(new RegExp(`{{${key}}}`, 'g'), value);
  });

  return result;
};

// Send communication based on template
export const sendCommunication = async (templateId, contextData, instructorNote = null) => {
  try {
    // Fetch template
    const templates = await base44.entities.CommunicationTemplate.filter({ id: templateId });
    if (!templates || templates.length === 0) {
      throw new Error("Template not found");
    }
    
    const template = templates[0];
    
    if (!template.is_active) {
      throw new Error("Template is inactive");
    }

    // Prepare data context
    const data = {
      student: contextData.student,
      instructor: contextData.instructor,
      booking: contextData.booking,
      vehicle: contextData.vehicle,
      payment: contextData.payment,
      invoice: contextData.invoice,
      school: contextData.school,
    };

    // Replace variables
    const subject = replaceVariables(template.subject, data);
    const body = replaceVariables(template.body, data);
    const smsBody = template.sms_body ? replaceVariables(template.sms_body, data) : body.substring(0, 160);

    // Add instructor note if provided
    let finalBody = body;
    if (instructorNote && template.instructor_can_customize) {
      finalBody += `\n\n---\nPersonal Note from ${data.instructor?.full_name || "Your Instructor"}:\n${instructorNote}`;
    }

    // Determine recipient
    let recipientEmail = null;
    let recipientPhone = null;

    if (template.send_to === "student" || template.send_to === "both") {
      recipientEmail = data.student?.email;
      recipientPhone = data.student?.phone;
    } else if (template.send_to === "instructor") {
      recipientEmail = data.instructor?.email;
      recipientPhone = data.instructor?.phone;
    }

    // Send email if channel includes email
    if ((template.channel === "email" || template.channel === "both") && recipientEmail) {
      await base44.integrations.Core.SendEmail({
        to: recipientEmail,
        subject: subject,
        body: finalBody,
        from_name: data.school?.name || "Driving School",
      });

      // Log sent communication
      await base44.entities.SentCommunication.create({
        school_id: template.school_id,
        template_id: template.id,
        booking_id: data.booking?.id,
        student_id: data.student?.id,
        instructor_id: data.instructor?.id,
        recipient_email: recipientEmail,
        channel: "email",
        subject: subject,
        body: finalBody,
        instructor_note: instructorNote,
        status: "sent",
        sent_at: new Date().toISOString(),
        trigger_event: template.trigger_event,
      });
    }

    // Send SMS if channel includes SMS (placeholder - would need SMS integration)
    if ((template.channel === "sms" || template.channel === "both") && recipientPhone) {
      // Log SMS communication (actual sending would require SMS integration)
      await base44.entities.SentCommunication.create({
        school_id: template.school_id,
        template_id: template.id,
        booking_id: data.booking?.id,
        student_id: data.student?.id,
        instructor_id: data.instructor?.id,
        recipient_phone: recipientPhone,
        channel: "sms",
        body: smsBody + (instructorNote ? `\n\nNote: ${instructorNote}` : ""),
        instructor_note: instructorNote,
        status: "sent",
        sent_at: new Date().toISOString(),
        trigger_event: template.trigger_event,
      });
    }

    return true;
  } catch (error) {
    console.error("Error sending communication:", error);
    throw error;
  }
};

// Get templates by trigger event
export const getTemplatesByTrigger = async (triggerEvent, autoSendOnly = true) => {
  const filters = {
    trigger_event: triggerEvent,
    is_active: true,
  };
  
  if (autoSendOnly) {
    filters.auto_send = true;
  }

  return await base44.entities.CommunicationTemplate.filter(filters);
};

// Main automation handler - call this when events occur
export const handleCommunicationTrigger = async (triggerEvent, contextData, instructorNote = null) => {
  try {
    const templates = await getTemplatesByTrigger(triggerEvent, true);
    
    if (templates.length === 0) {
      return;
    }

    const results = [];
    for (const template of templates) {
      try {
        // Apply delay if specified
        if (template.send_delay_minutes > 0) {
          // In production, would schedule this with a job queue
          await new Promise(resolve => setTimeout(resolve, template.send_delay_minutes * 60 * 1000));
        }

        await sendCommunication(template.id, contextData, instructorNote);
        results.push({ template: template.name, success: true });
      } catch (error) {
        console.error(`Failed to send template ${template.name}:`, error);
        results.push({ template: template.name, success: false, error: error.message });
      }
    }

    return results;
  } catch (error) {
    console.error("Error in communication trigger handler:", error);
    throw error;
  }
};

export default function TemplatePreview({ isOpen, onClose, template }) {
  const renderedContent = useMemo(() => {
    if (!template) return { subject: "", body: "", sms_body: "" };

    const replaceVariables = (text) => {
      if (!text) return "";
      let result = text;
      Object.entries(SAMPLE_DATA).forEach(([key, value]) => {
        result = result.replace(new RegExp(`{{${key}}}`, 'g'), value);
      });
      return result;
    };

    return {
      subject: replaceVariables(template.subject),
      body: replaceVariables(template.body),
      sms_body: replaceVariables(template.sms_body),
    };
  }, [template]);

  if (!isOpen || !template) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-white rounded-2xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="px-6 py-4 border-b border-zinc-200 flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50">
            <div>
              <h2 className="text-xl font-bold text-zinc-900">Template Preview</h2>
              <p className="text-sm text-zinc-600">{template.name}</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/80 rounded-lg transition">
              <X className="w-5 h-5 text-zinc-500" />
            </button>
          </div>

          <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6 space-y-6">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl">
              <p className="text-sm text-amber-800">
                Preview with sample data. Real messages use actual booking information.
              </p>
            </div>

            {(template.channel === "email" || template.channel === "both") && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Mail className="w-5 h-5 text-blue-600" />
                  <h3 className="font-semibold text-zinc-900">Email Preview</h3>
                </div>

                <div className="border border-zinc-200 rounded-xl overflow-hidden">
                  <div className="px-4 py-3 bg-zinc-50 border-b border-zinc-200 space-y-2 text-sm">
                    <div className="flex gap-3">
                      <span className="font-medium text-zinc-500 w-16">To:</span>
                      <span className="text-zinc-900">john.smith@email.com</span>
                    </div>
                    <div className="flex gap-3">
                      <span className="font-medium text-zinc-500 w-16">Subject:</span>
                      <span className="text-zinc-900 font-medium">{renderedContent.subject}</span>
                    </div>
                  </div>

                  <div className="p-6 bg-white">
                    <pre className="whitespace-pre-wrap font-sans text-zinc-700 text-sm leading-relaxed">
                      {renderedContent.body}
                    </pre>

                    {template.instructor_can_customize && (
                      <div className="mt-6 pt-4 border-t border-zinc-200">
                        <p className="text-xs font-medium text-zinc-500 mb-2">Instructor's Note:</p>
                        <div className="p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                          <p className="text-sm text-indigo-900 italic">
                            "Looking forward to our lesson!"
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {(template.channel === "sms" || template.channel === "both") && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <MessageSquare className="w-5 h-5 text-purple-600" />
                  <h3 className="font-semibold text-zinc-900">SMS Preview</h3>
                </div>

                <div className="bg-zinc-900 rounded-3xl p-3 max-w-sm mx-auto">
                  <div className="bg-white rounded-2xl overflow-hidden">
                    <div className="px-4 py-2 bg-zinc-50 border-b border-zinc-200 text-center">
                      <p className="text-xs text-zinc-500">To: +353 87 123 4567</p>
                    </div>
                    <div className="p-4 min-h-[150px] bg-gradient-to-b from-white to-zinc-50">
                      <div className="flex justify-end">
                        <div className="max-w-[85%] bg-indigo-600 text-white rounded-2xl rounded-tr-sm px-4 py-2.5">
                          <p className="text-sm">{renderedContent.sms_body || renderedContent.body.substring(0, 160)}</p>
                          <p className="text-xs opacity-75 mt-1 text-right">{format(new Date(), "HH:mm")}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="px-6 py-4 border-t border-zinc-200 bg-zinc-50 flex justify-end">
            <button
              onClick={onClose}
              className="px-5 py-2.5 bg-zinc-900 text-white rounded-xl hover:bg-zinc-800 transition font-medium"
            >
              Close
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}