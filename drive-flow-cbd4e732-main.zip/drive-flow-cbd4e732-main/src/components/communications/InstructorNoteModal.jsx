import React, { useState } from "react";
import { X, Send, Mail, MessageSquare } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { sendCommunication } from "./AutomationService";

export default function InstructorNoteModal({ 
  isOpen, 
  onClose, 
  template, 
  booking,
  student,
  instructor,
  vehicle,
  school,
  onSent 
}) {
  const [note, setNote] = useState("");
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    if (!template) return;

    setSending(true);
    try {
      await sendCommunication(
        template.id,
        { booking, student, instructor, vehicle, school },
        note || null
      );
      
      toast.success("Message sent successfully");
      if (onSent) onSent();
      onClose();
      setNote("");
    } catch (error) {
      toast.error("Failed to send message");
    } finally {
      setSending(false);
    }
  };

  if (!isOpen || !template) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-white rounded-2xl shadow-xl max-w-2xl w-full"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="px-6 py-4 border-b border-zinc-200 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-zinc-900">Add Personal Note</h3>
              <p className="text-sm text-zinc-600">Sending: {template.name}</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-zinc-100 rounded-lg transition">
              <X className="w-5 h-5 text-zinc-500" />
            </button>
          </div>

          <div className="p-6">
            <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                {template.channel === "email" && <Mail className="w-4 h-4 text-blue-600" />}
                {template.channel === "sms" && <MessageSquare className="w-4 h-4 text-purple-600" />}
                {template.channel === "both" && (
                  <>
                    <Mail className="w-4 h-4 text-blue-600" />
                    <MessageSquare className="w-4 h-4 text-purple-600" />
                  </>
                )}
                <p className="text-sm font-medium text-blue-900">
                  To: {student?.full_name || "Student"}
                </p>
              </div>
              <p className="text-xs text-blue-700">
                The standard template will be sent {template.instructor_can_customize ? "with your personal note below" : "as configured"}.
              </p>
            </div>

            {template.instructor_can_customize && (
              <div>
                <label className="block text-sm font-medium text-zinc-700 mb-2">
                  Your Personal Note (Optional)
                </label>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  rows={5}
                  placeholder="Add a personal message to make it more friendly..."
                />
                <p className="text-xs text-zinc-500 mt-1">
                  This note will be added at the end of the template message.
                </p>
              </div>
            )}
          </div>

          <div className="px-6 py-4 border-t border-zinc-200 bg-zinc-50 flex items-center justify-end gap-3">
            <button
              onClick={onClose}
              className="px-5 py-2.5 text-zinc-700 hover:bg-zinc-100 rounded-xl transition font-medium"
              disabled={sending}
            >
              Cancel
            </button>
            <button
              onClick={handleSend}
              disabled={sending}
              className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition font-semibold flex items-center gap-2 disabled:opacity-50"
            >
              {sending ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Send Message
                </>
              )}
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}