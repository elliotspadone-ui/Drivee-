import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Bell, Mail, MessageSquare, Zap, Save, AlertCircle, CheckCircle } from "lucide-react";
import { toast } from "sonner";

const NOTIFICATION_SCENARIOS = [
  {
    id: "booking_created",
    label: "Booking Created",
    description: "When a new lesson is booked",
    defaultEnabled: true,
  },
  {
    id: "booking_confirmed",
    label: "Booking Confirmed",
    description: "When admin confirms a pending booking",
    defaultEnabled: true,
  },
  {
    id: "booking_cancelled",
    label: "Booking Cancelled",
    description: "When a lesson is cancelled",
    defaultEnabled: true,
  },
  {
    id: "booking_24h_before",
    label: "24-Hour Reminder",
    description: "24 hours before the lesson",
    defaultEnabled: true,
  },
  {
    id: "booking_1h_before",
    label: "1-Hour Reminder",
    description: "1 hour before the lesson",
    defaultEnabled: false,
  },
  {
    id: "booking_completed",
    label: "Lesson Completed",
    description: "After lesson is marked complete",
    defaultEnabled: true,
  },
  {
    id: "payment_received",
    label: "Payment Received",
    description: "When payment is processed",
    defaultEnabled: true,
  },
  {
    id: "payment_overdue",
    label: "Payment Overdue",
    description: "When invoice is overdue",
    defaultEnabled: true,
  },
  {
    id: "student_registered",
    label: "Student Registered",
    description: "Welcome message for new students",
    defaultEnabled: true,
  },
];

export default function NotificationSettings() {
  const queryClient = useQueryClient();
  
  const { data: templates = [] } = useQuery({
    queryKey: ["communicationTemplates"],
    queryFn: () => base44.entities.CommunicationTemplate.list(),
    staleTime: 60000,
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CommunicationTemplate.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["communicationTemplates"] });
      toast.success("Settings updated");
    },
  });

  const templatesByTrigger = useMemo(() => {
    const grouped = {};
    templates.forEach(template => {
      if (!grouped[template.trigger_event]) {
        grouped[template.trigger_event] = [];
      }
      grouped[template.trigger_event].push(template);
    });
    return grouped;
  }, [templates]);

  const toggleAutoSend = (templateId, currentValue) => {
    updateMutation.mutate({
      id: templateId,
      data: { auto_send: !currentValue },
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-xl p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center flex-shrink-0">
            <Bell className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <h3 className="font-semibold text-zinc-900 mb-1">Automated Notifications</h3>
            <p className="text-sm text-zinc-600">
              Configure which templates are automatically sent when specific events occur. 
              Templates must be active and have auto-send enabled to trigger automatically.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {NOTIFICATION_SCENARIOS.map(scenario => {
          const scenarioTemplates = templatesByTrigger[scenario.id] || [];
          const activeTemplates = scenarioTemplates.filter(t => t.is_active);
          const autoSendTemplates = activeTemplates.filter(t => t.auto_send);

          return (
            <div key={scenario.id} className="bg-white rounded-xl border border-zinc-200 p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h4 className="font-semibold text-zinc-900">{scenario.label}</h4>
                    {autoSendTemplates.length > 0 && (
                      <span className="flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-xs font-medium">
                        <Zap className="w-3 h-3" />
                        {autoSendTemplates.length} Active
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-zinc-500">{scenario.description}</p>
                </div>
              </div>

              {scenarioTemplates.length === 0 ? (
                <div className="p-4 bg-zinc-50 rounded-lg border border-zinc-200 text-center">
                  <p className="text-sm text-zinc-500">No templates configured for this trigger</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {scenarioTemplates.map(template => (
                    <div
                      key={template.id}
                      className="flex items-center justify-between p-3 bg-zinc-50 rounded-lg border border-zinc-200"
                    >
                      <div className="flex items-center gap-3 flex-1">
                        {template.channel === "email" && <Mail className="w-4 h-4 text-blue-600" />}
                        {template.channel === "sms" && <MessageSquare className="w-4 h-4 text-purple-600" />}
                        {template.channel === "both" && (
                          <div className="flex gap-1">
                            <Mail className="w-4 h-4 text-blue-600" />
                            <MessageSquare className="w-4 h-4 text-purple-600" />
                          </div>
                        )}
                        
                        <div className="flex-1">
                          <p className="text-sm font-medium text-zinc-900">{template.name}</p>
                          {template.description && (
                            <p className="text-xs text-zinc-500">{template.description}</p>
                          )}
                        </div>

                        {!template.is_active && (
                          <span className="px-2 py-1 bg-zinc-200 text-zinc-600 rounded text-xs">
                            Inactive
                          </span>
                        )}
                      </div>

                      <label className="flex items-center gap-2 cursor-pointer">
                        <span className="text-xs text-zinc-600">Auto-send</span>
                        <button
                          type="button"
                          onClick={() => toggleAutoSend(template.id, template.auto_send)}
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                            template.auto_send ? "bg-emerald-600" : "bg-zinc-300"
                          }`}
                          disabled={!template.is_active}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                              template.auto_send ? "translate-x-6" : "translate-x-1"
                            }`}
                          />
                        </button>
                      </label>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-amber-900 mb-1">Important Notes</p>
            <ul className="text-sm text-amber-800 space-y-1 list-disc list-inside">
              <li>Templates must be both Active and have Auto-send enabled to trigger automatically</li>
              <li>Multiple templates can be active for the same trigger event</li>
              <li>SMS requires additional configuration and may incur costs</li>
              <li>Test your templates thoroughly before enabling automation</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}