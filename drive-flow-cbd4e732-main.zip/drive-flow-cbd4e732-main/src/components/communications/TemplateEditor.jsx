import React, { useState, useEffect } from "react";
import { X, Mail, MessageSquare, Info, Zap, User, Globe, Code } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const TEMPLATE_TYPES = [
  { value: "booking_confirmation", label: "Booking Confirmation" },
  { value: "booking_reminder", label: "Booking Reminder" },
  { value: "booking_cancellation", label: "Booking Cancellation" },
  { value: "payment_receipt", label: "Payment Receipt" },
  { value: "payment_reminder", label: "Payment Reminder" },
  { value: "lesson_followup", label: "Lesson Follow-up" },
  { value: "welcome_new_student", label: "Welcome New Student" },
  { value: "exam_reminder", label: "Exam Reminder" },
  { value: "progress_update", label: "Progress Update" },
  { value: "instructor_assignment", label: "Instructor Assignment" },
  { value: "custom", label: "Custom Template" },
];

const TRIGGER_EVENTS = [
  { value: "booking_created", label: "When booking is created" },
  { value: "booking_confirmed", label: "When booking is confirmed" },
  { value: "booking_cancelled", label: "When booking is cancelled" },
  { value: "booking_24h_before", label: "24 hours before lesson" },
  { value: "booking_1h_before", label: "1 hour before lesson" },
  { value: "booking_completed", label: "When lesson is completed" },
  { value: "payment_received", label: "When payment is received" },
  { value: "payment_overdue", label: "When payment is overdue" },
  { value: "invoice_created", label: "When invoice is created" },
  { value: "student_registered", label: "When student registers" },
  { value: "manual", label: "Manual send only" },
];

const AVAILABLE_VARIABLES = [
  { var: "{{student_name}}", desc: "Student's full name" },
  { var: "{{student_first_name}}", desc: "Student's first name" },
  { var: "{{instructor_name}}", desc: "Instructor's name" },
  { var: "{{lesson_date}}", desc: "Lesson date" },
  { var: "{{lesson_time}}", desc: "Lesson time" },
  { var: "{{lesson_duration}}", desc: "Lesson duration" },
  { var: "{{pickup_location}}", desc: "Pickup location" },
  { var: "{{vehicle_name}}", desc: "Vehicle make/model" },
  { var: "{{vehicle_plate}}", desc: "License plate" },
  { var: "{{price}}", desc: "Lesson price" },
  { var: "{{payment_amount}}", desc: "Payment amount" },
  { var: "{{invoice_number}}", desc: "Invoice number" },
  { var: "{{school_name}}", desc: "School name" },
  { var: "{{school_phone}}", desc: "School phone" },
  { var: "{{school_email}}", desc: "School email" },
  { var: "{{booking_id}}", desc: "Booking ID" },
  { var: "{{cancellation_reason}}", desc: "Cancellation reason" },
];

const DEFAULT_TEMPLATES = {
  booking_confirmation: {
    subject: "✅ Lesson Confirmed - {{lesson_date}} at {{lesson_time}}",
    body: `Hi {{student_first_name}},

Your driving lesson is confirmed!

📅 Date: {{lesson_date}}
🕐 Time: {{lesson_time}}
⏱️ Duration: {{lesson_duration}}
📍 Pickup: {{pickup_location}}
👨‍🏫 Instructor: {{instructor_name}}
🚗 Vehicle: {{vehicle_name}} ({{vehicle_plate}})
💰 Price: {{price}}

Please arrive 5 minutes early. If you need to reschedule or cancel, please do so at least 24 hours in advance.

See you soon!
{{school_name}}
{{school_phone}}`,
    sms_body: "Hi {{student_first_name}}! Your lesson is confirmed for {{lesson_date}} at {{lesson_time}}. Instructor: {{instructor_name}}. Pickup: {{pickup_location}}. See you then! - {{school_name}}",
  },
  booking_reminder: {
    subject: "⏰ Reminder: Lesson Tomorrow at {{lesson_time}}",
    body: `Hi {{student_first_name}},

Just a friendly reminder about your upcoming lesson:

📅 Tomorrow, {{lesson_date}}
🕐 {{lesson_time}}
📍 {{pickup_location}}
👨‍🏫 {{instructor_name}}

Please arrive 5 minutes early. Looking forward to seeing you!

{{school_name}}`,
    sms_body: "Hi {{student_first_name}}! Reminder: Lesson tomorrow {{lesson_date}} at {{lesson_time}} with {{instructor_name}}. Pickup: {{pickup_location}}. - {{school_name}}",
  },
  payment_receipt: {
    subject: "💳 Payment Receipt - €{{payment_amount}}",
    body: `Hi {{student_first_name}},

Thank you for your payment!

💰 Amount Paid: €{{payment_amount}}
📄 Invoice: {{invoice_number}}
📅 Date: {{lesson_date}}

Your payment has been successfully processed. You can view your receipt in your student dashboard.

Thank you for choosing {{school_name}}!`,
    sms_body: "Payment received! €{{payment_amount}} for invoice {{invoice_number}}. Thank you! - {{school_name}}",
  },
};

export default function TemplateEditor({ isOpen, onClose, template, onSave }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    template_type: "booking_confirmation",
    channel: "email",
    subject: "",
    body: "",
    sms_body: "",
    trigger_event: "manual",
    auto_send: false,
    send_delay_minutes: 0,
    instructor_can_customize: true,
    is_active: true,
    language: "en",
    send_to: "student",
    variables: [],
  });

  const [showVariables, setShowVariables] = useState(false);

  useEffect(() => {
    if (template) {
      setFormData(template);
    } else {
      setFormData({
        name: "",
        description: "",
        template_type: "booking_confirmation",
        channel: "email",
        subject: "",
        body: "",
        sms_body: "",
        trigger_event: "manual",
        auto_send: false,
        send_delay_minutes: 0,
        instructor_can_customize: true,
        is_active: true,
        language: "en",
        send_to: "student",
        variables: [],
      });
    }
  }, [template, isOpen]);

  const handleTemplateTypeChange = (type) => {
    setFormData(prev => {
      const defaults = DEFAULT_TEMPLATES[type];
      if (defaults && !template) {
        return {
          ...prev,
          template_type: type,
          subject: defaults.subject || "",
          body: defaults.body || "",
          sms_body: defaults.sms_body || "",
        };
      }
      return { ...prev, template_type: type };
    });
  };

  const insertVariable = (variable) => {
    setFormData(prev => ({
      ...prev,
      body: prev.body + variable + " ",
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.body) {
      return;
    }

    const usedVars = new Set();
    AVAILABLE_VARIABLES.forEach(v => {
      if (formData.body.includes(v.var) || formData.sms_body?.includes(v.var)) {
        usedVars.add(v.var);
      }
    });

    onSave({
      ...formData,
      variables: Array.from(usedVars),
    });
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-white rounded-2xl shadow-xl max-w-5xl w-full max-h-[90vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-6 py-4 border-b border-zinc-200 flex items-center justify-between bg-gradient-to-r from-indigo-50 to-purple-50">
            <div>
              <h2 className="text-xl font-bold text-zinc-900">
                {template ? "Edit Template" : "Create Template"}
              </h2>
              <p className="text-sm text-zinc-600">Configure automated communications</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/80 rounded-lg transition"
            >
              <X className="w-5 h-5 text-zinc-500" />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="overflow-y-auto max-h-[calc(90vh-140px)]">
            <div className="p-6 space-y-6">
              {/* Basic Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">
                    Template Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g., Booking Confirmation (Standard)"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">
                    Template Type *
                  </label>
                  <select
                    value={formData.template_type}
                    onChange={(e) => handleTemplateTypeChange(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  >
                    {TEMPLATE_TYPES.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-700 mb-2">
                  Description
                </label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Brief description of this template"
                />
              </div>

              {/* Channel & Settings */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">
                    Channel *
                  </label>
                  <select
                    value={formData.channel}
                    onChange={(e) => setFormData(prev => ({ ...prev, channel: e.target.value }))}
                    className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="email">Email Only</option>
                    <option value="sms">SMS Only</option>
                    <option value="both">Both</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">
                    Send To
                  </label>
                  <select
                    value={formData.send_to}
                    onChange={(e) => setFormData(prev => ({ ...prev, send_to: e.target.value }))}
                    className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="student">Student</option>
                    <option value="instructor">Instructor</option>
                    <option value="both">Both</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">
                    Language
                  </label>
                  <select
                    value={formData.language}
                    onChange={(e) => setFormData(prev => ({ ...prev, language: e.target.value }))}
                    className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="en">English</option>
                    <option value="fr">Français</option>
                    <option value="de">Deutsch</option>
                    <option value="it">Italiano</option>
                    <option value="nl">Nederlands</option>
                  </select>
                </div>
              </div>

              {/* Email Subject (if channel includes email) */}
              {(formData.channel === "email" || formData.channel === "both") && (
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">
                    Email Subject *
                  </label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                    className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g., Lesson Confirmed - {{lesson_date}}"
                    required={formData.channel === "email" || formData.channel === "both"}
                  />
                </div>
              )}

              {/* Email Body (if channel includes email) */}
              {(formData.channel === "email" || formData.channel === "both") && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-zinc-700">
                      Email Body *
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowVariables(!showVariables)}
                      className="text-xs text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
                    >
                      <Code className="w-3 h-3" />
                      {showVariables ? "Hide" : "Show"} Variables
                    </button>
                  </div>
                  <textarea
                    value={formData.body}
                    onChange={(e) => setFormData(prev => ({ ...prev, body: e.target.value }))}
                    className="w-full px-4 py-3 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
                    rows={12}
                    placeholder="Write your email template here. Use {{variable_name}} for dynamic content."
                    required
                  />
                  
                  {showVariables && (
                    <div className="mt-2 p-4 bg-zinc-50 rounded-xl border border-zinc-200">
                      <p className="text-xs font-semibold text-zinc-700 mb-2">Available Variables:</p>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {AVAILABLE_VARIABLES.map(v => (
                          <button
                            key={v.var}
                            type="button"
                            onClick={() => insertVariable(v.var)}
                            className="text-left px-3 py-2 bg-white rounded-lg border border-zinc-200 hover:border-indigo-300 hover:bg-indigo-50 transition group"
                          >
                            <code className="text-xs text-indigo-600 font-mono">{v.var}</code>
                            <p className="text-xs text-zinc-500 mt-0.5">{v.desc}</p>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* SMS Body (if channel includes SMS) */}
              {(formData.channel === "sms" || formData.channel === "both") && (
                <div>
                  <label className="block text-sm font-medium text-zinc-700 mb-2">
                    SMS Body {formData.channel === "both" && "(Optional - falls back to email)"}
                  </label>
                  <textarea
                    value={formData.sms_body}
                    onChange={(e) => setFormData(prev => ({ ...prev, sms_body: e.target.value }))}
                    className="w-full px-4 py-3 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
                    rows={4}
                    placeholder="Keep it short (160 chars max recommended)"
                    maxLength={320}
                  />
                  <p className="text-xs text-zinc-500 mt-1">
                    {formData.sms_body.length}/320 characters
                  </p>
                </div>
              )}

              {/* Automation Settings */}
              <div className="border-t border-zinc-200 pt-6">
                <h3 className="text-sm font-semibold text-zinc-900 mb-4 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-indigo-600" />
                  Automation Settings
                </h3>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-zinc-700 mb-2">
                      Trigger Event
                    </label>
                    <select
                      value={formData.trigger_event}
                      onChange={(e) => setFormData(prev => ({ ...prev, trigger_event: e.target.value }))}
                      className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      {TRIGGER_EVENTS.map(event => (
                        <option key={event.value} value={event.value}>{event.label}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className="flex items-center gap-3 p-4 bg-zinc-50 rounded-xl border border-zinc-200 cursor-pointer hover:bg-zinc-100 transition">
                      <input
                        type="checkbox"
                        checked={formData.auto_send}
                        onChange={(e) => setFormData(prev => ({ ...prev, auto_send: e.target.checked }))}
                        className="w-4 h-4 rounded border-zinc-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-zinc-900">Auto-send</p>
                        <p className="text-xs text-zinc-500">Send automatically when triggered</p>
                      </div>
                    </label>

                    <label className="flex items-center gap-3 p-4 bg-zinc-50 rounded-xl border border-zinc-200 cursor-pointer hover:bg-zinc-100 transition">
                      <input
                        type="checkbox"
                        checked={formData.instructor_can_customize}
                        onChange={(e) => setFormData(prev => ({ ...prev, instructor_can_customize: e.target.checked }))}
                        className="w-4 h-4 rounded border-zinc-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-zinc-900">Instructor Notes</p>
                        <p className="text-xs text-zinc-500">Allow instructors to add notes</p>
                      </div>
                    </label>
                  </div>

                  {formData.auto_send && (
                    <div>
                      <label className="block text-sm font-medium text-zinc-700 mb-2">
                        Send Delay (minutes)
                      </label>
                      <input
                        type="number"
                        value={formData.send_delay_minutes}
                        onChange={(e) => setFormData(prev => ({ ...prev, send_delay_minutes: parseInt(e.target.value) || 0 }))}
                        className="w-full px-4 py-2.5 rounded-xl border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        min="0"
                        placeholder="0 = send immediately"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Status */}
              <div className="border-t border-zinc-200 pt-6">
                <label className="flex items-center gap-3 p-4 bg-zinc-50 rounded-xl border border-zinc-200 cursor-pointer hover:bg-zinc-100 transition">
                  <input
                    type="checkbox"
                    checked={formData.is_active}
                    onChange={(e) => setFormData(prev => ({ ...prev, is_active: e.target.checked }))}
                    className="w-4 h-4 rounded border-zinc-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-zinc-900">Active</p>
                    <p className="text-xs text-zinc-500">Template is available for use</p>
                  </div>
                </label>
              </div>

              {/* Info Box */}
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-blue-900 mb-1">Template Variables</p>
                    <p className="text-xs text-blue-700">
                      Use variables like <code className="px-1 py-0.5 bg-blue-100 rounded">{"{{student_name}}"}</code> to personalize messages. 
                      Variables are automatically replaced with actual values when the message is sent.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-zinc-200 bg-zinc-50 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 text-zinc-700 hover:bg-zinc-100 rounded-xl transition font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition font-semibold flex items-center gap-2"
              >
                {template ? "Update Template" : "Create Template"}
              </button>
            </div>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}