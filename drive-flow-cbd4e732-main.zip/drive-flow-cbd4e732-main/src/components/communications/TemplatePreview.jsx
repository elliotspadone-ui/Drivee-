import React, { useMemo } from "react";
import { X, Mail, MessageSquare, User, Calendar, Car, MapPin } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";

const SAMPLE_DATA = {
  student_name: "John Smith",
  student_first_name: "John",
  instructor_name: "Sarah Johnson",
  lesson_date: format(new Date(), "EEEE, MMMM d, yyyy"),
  lesson_time: "10:00 AM",
  lesson_duration: "60 minutes",
  pickup_location: "Main Street, City Center",
  vehicle_name: "Toyota Corolla",
  vehicle_plate: "ABC-1234",
  price: "€45",
  payment_amount: "€45",
  invoice_number: "INV-2025-001",
  school_name: "DrivePro School",
  school_phone: "+353 1 234 5678",
  school_email: "info@drivepro.ie",
  booking_id: "BK-12345",
  cancellation_reason: "Student requested reschedule",
};

export default function TemplatePreview({ isOpen, onClose, template }) {
  const renderedContent = useMemo(() => {
    if (!template) return { subject: "", body: "", sms_body: "" };

    const replaceVariables = (text) => {
      if (!text) return "";
      let result = text;
      Object.entries(SAMPLE_DATA).forEach(([key, value]) => {
        result = result.replace(new RegExp(`{{${key}}}`, 'g'), value);
      });
      return result;
    };

    return {
      subject: replaceVariables(template.subject),
      body: replaceVariables(template.body),
      sms_body: replaceVariables(template.sms_body),
    };
  }, [template]);

  if (!isOpen || !template) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-white rounded-2xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-6 py-4 border-b border-zinc-200 flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50">
            <div>
              <h2 className="text-xl font-bold text-zinc-900">Template Preview</h2>
              <p className="text-sm text-zinc-600">{template.name}</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/80 rounded-lg transition"
            >
              <X className="w-5 h-5 text-zinc-500" />
            </button>
          </div>

          {/* Content */}
          <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6">
            <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-xl">
              <p className="text-sm text-amber-800">
                This is a preview with sample data. Actual messages will use real student and booking information.
              </p>
            </div>

            {/* Email Preview */}
            {(template.channel === "email" || template.channel === "both") && (
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <Mail className="w-5 h-5 text-blue-600" />
                  <h3 className="font-semibold text-zinc-900">Email Preview</h3>
                </div>

                <div className="border border-zinc-200 rounded-xl overflow-hidden">
                  {/* Email Header */}
                  <div className="px-4 py-3 bg-zinc-50 border-b border-zinc-200">
                    <div className="flex items-center gap-3 text-sm mb-2">
                      <span className="font-medium text-zinc-500">To:</span>
                      <span className="text-zinc-900">john.smith@email.com</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <span className="font-medium text-zinc-500">Subject:</span>
                      <span className="text-zinc-900 font-medium">{renderedContent.subject}</span>
                    </div>
                  </div>

                  {/* Email Body */}
                  <div className="p-6 bg-white">
                    <div className="prose prose-sm max-w-none">
                      <pre className="whitespace-pre-wrap font-sans text-zinc-700 text-sm leading-relaxed">
                        {renderedContent.body}
                      </pre>
                    </div>

                    {template.instructor_can_customize && (
                      <div className="mt-6 pt-4 border-t border-zinc-200">
                        <p className="text-xs font-medium text-zinc-500 mb-2">Instructor's Personal Note:</p>
                        <div className="p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                          <p className="text-sm text-indigo-900 italic">
                            "Looking forward to our lesson! Feel free to bring any questions you have."
                          </p>
                          <p className="text-xs text-indigo-600 mt-1">- Sarah Johnson</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* SMS Preview */}
            {(template.channel === "sms" || template.channel === "both") && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <MessageSquare className="w-5 h-5 text-purple-600" />
                  <h3 className="font-semibold text-zinc-900">SMS Preview</h3>
                </div>

                <div className="flex justify-center">
                  <div className="w-full max-w-sm">
                    {/* Phone mockup */}
                    <div className="bg-zinc-900 rounded-[3rem] p-3 shadow-2xl">
                      <div className="bg-white rounded-[2.5rem] overflow-hidden">
                        {/* Phone header */}
                        <div className="px-4 py-3 bg-zinc-50 border-b border-zinc-200">
                          <p className="text-xs font-medium text-zinc-500 text-center">
                            {template.send_to === "student" ? "To: John Smith" : "To: Sarah Johnson"}
                          </p>
                        </div>

                        {/* SMS bubble */}
                        <div className="p-4 min-h-[200px] bg-gradient-to-b from-white to-zinc-50">
                          <div className="flex justify-end mb-2">
                            <div className="max-w-[85%] bg-indigo-600 text-white rounded-2xl rounded-tr-sm px-4 py-3 shadow-sm">
                              <p className="text-sm leading-relaxed">
                                {renderedContent.sms_body || renderedContent.body.substring(0, 160) + "..."}
                              </p>
                              <p className="text-xs opacity-75 mt-1 text-right">
                                {format(new Date(), "HH:mm")}
                              </p>
                            </div>
                          </div>

                          {template.instructor_can_customize && (
                            <div className="flex justify-end">
                              <div className="max-w-[85%] bg-indigo-600 text-white rounded-2xl rounded-tr-sm px-4 py-3 shadow-sm">
                                <p className="text-sm leading-relaxed italic">
                                  "Looking forward to our lesson! 😊"
                                </p>
                                <p className="text-xs opacity-75 mt-1 text-right">
                                  {format(new Date(), "HH:mm")}
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-zinc-200 bg-zinc-50 flex justify-end">
            <button
              onClick={onClose}
              className="px-5 py-2.5 bg-zinc-900 text-white rounded-xl hover:bg-zinc-800 transition font-medium"
            >
              Close Preview
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}