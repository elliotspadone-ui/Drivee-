import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { CheckCircle, XCircle, AlertTriangle, Loader2, Shield, Database, Zap, Globe, Settings, Users, Lock } from "lucide-react";
import { motion } from "framer-motion";
import { APP_CONFIG, ENABLE_DEV_AUTH, ENABLE_ANALYTICS } from "@/components/utils/config";

/**
 * Production Readiness Checklist
 * Displays system status and deployment readiness
 * Only visible to admin users
 */
export default function ProductionChecklist() {
  const [checks, setChecks] = useState({
    auth: { status: "checking", message: "Verifying authentication system..." },
    database: { status: "checking", message: "Testing database connectivity..." },
    env: { status: "checking", message: "Checking environment configuration..." },
    devFlags: { status: "checking", message: "Validating production flags..." },
    entities: { status: "checking", message: "Verifying data model..." },
  });

  useEffect(() => {
    const runChecks = async () => {
      // Check 1: Auth System
      try {
        const user = await base44.auth.me();
        setChecks(prev => ({
          ...prev,
          auth: user 
            ? { status: "pass", message: "Authentication working correctly" }
            : { status: "fail", message: "Auth check failed - user not found" }
        }));
      } catch (err) {
        setChecks(prev => ({
          ...prev,
          auth: { status: "fail", message: `Auth error: ${err.message}` }
        }));
      }

      // Check 2: Database
      try {
        const schools = await base44.entities.School.filter({}, "-created_date", 1);
        setChecks(prev => ({
          ...prev,
          database: { status: "pass", message: `Database connected (${schools.length} schools found)` }
        }));
      } catch (err) {
        setChecks(prev => ({
          ...prev,
          database: { status: "fail", message: `Database error: ${err.message}` }
        }));
      }

      // Check 3: Environment
      const envStatus = APP_CONFIG.IS_PRODUCTION ? "pass" : "warn";
      const envMessage = APP_CONFIG.IS_PRODUCTION 
        ? "✓ Running in PRODUCTION mode"
        : "⚠ Running in DEVELOPMENT mode";
      
      setChecks(prev => ({
        ...prev,
        env: { status: envStatus, message: envMessage }
      }));

      // Check 4: Dev Flags (CRITICAL)
      const devFlagsStatus = (APP_CONFIG.IS_PRODUCTION && ENABLE_DEV_AUTH) ? "fail" : "pass";
      const devFlagsMessage = ENABLE_DEV_AUTH
        ? "❌ DEV_AUTH is ENABLED - SECURITY RISK!"
        : "✓ Dev auth properly disabled";
      
      setChecks(prev => ({
        ...prev,
        devFlags: { status: devFlagsStatus, message: devFlagsMessage }
      }));

      // Check 5: Critical Entities
      try {
        const [students, instructors, bookings] = await Promise.all([
          base44.entities.Student.filter({}, "-created_date", 1),
          base44.entities.Instructor.filter({}, "-created_date", 1),
          base44.entities.Booking.filter({}, "-created_date", 1),
        ]);
        
        const hasSchoolId = (
          (students[0]?.school_id ? 1 : 0) +
          (instructors[0]?.school_id ? 1 : 0) +
          (bookings[0]?.school_id ? 1 : 0)
        ) >= 2;

        setChecks(prev => ({
          ...prev,
          entities: hasSchoolId
            ? { status: "pass", message: "✓ Multi-tenant isolation configured" }
            : { status: "warn", message: "⚠ Some entities missing school_id" }
        }));
      } catch (err) {
        setChecks(prev => ({
          ...prev,
          entities: { status: "warn", message: "Unable to verify entity structure" }
        }));
      }
    };

    runChecks();
  }, []);

  const getStatusIcon = (status) => {
    switch (status) {
      case "pass":
        return <CheckCircle className="w-5 h-5 text-emerald-600" />;
      case "fail":
        return <XCircle className="w-5 h-5 text-red-600" />;
      case "warn":
        return <AlertTriangle className="w-5 h-5 text-amber-600" />;
      default:
        return <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />;
    }
  };

  const getStatusBg = (status) => {
    switch (status) {
      case "pass":
        return "bg-emerald-50 border-emerald-200";
      case "fail":
        return "bg-red-50 border-red-200";
      case "warn":
        return "bg-amber-50 border-amber-200";
      default:
        return "bg-blue-50 border-blue-200";
    }
  };

  const allPassed = Object.values(checks).every(c => c.status === "pass");
  const anyFailed = Object.values(checks).some(c => c.status === "fail");

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl border-2 border-slate-200 p-8 shadow-lg">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Production Readiness</h2>
            <p className="text-slate-600">System health and deployment status</p>
          </div>
          <div className={`px-4 py-2 rounded-xl font-bold text-sm ${
            allPassed ? "bg-emerald-100 text-emerald-700" :
            anyFailed ? "bg-red-100 text-red-700" :
            "bg-amber-100 text-amber-700"
          }`}>
            {allPassed ? "✓ READY" : anyFailed ? "✗ NOT READY" : "⚠ WARNINGS"}
          </div>
        </div>

        <div className="space-y-4 mb-8">
          {[
            { key: "auth", icon: Lock, label: "Authentication" },
            { key: "database", icon: Database, label: "Database" },
            { key: "env", icon: Settings, label: "Environment" },
            { key: "devFlags", icon: Shield, label: "Security Flags" },
            { key: "entities", icon: Users, label: "Data Model" },
          ].map(({ key, icon: Icon, label }) => {
            const check = checks[key];
            return (
              <motion.div
                key={key}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className={`p-4 rounded-xl border-2 ${getStatusBg(check.status)}`}
              >
                <div className="flex items-center gap-4">
                  <div className="flex-shrink-0">
                    {getStatusIcon(check.status)}
                  </div>
                  <div className="flex-shrink-0">
                    <Icon className="w-5 h-5 text-slate-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-900">{label}</p>
                    <p className="text-sm text-slate-600">{check.message}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="border-t-2 border-slate-200 pt-6">
          <h3 className="font-bold text-slate-900 mb-4">Configuration</h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-slate-600">App Version</p>
              <p className="font-semibold text-slate-900">{APP_CONFIG.APP_VERSION}</p>
            </div>
            <div>
              <p className="text-slate-600">Environment</p>
              <p className="font-semibold text-slate-900">{APP_CONFIG.APP_ENV}</p>
            </div>
            <div>
              <p className="text-slate-600">Analytics</p>
              <p className="font-semibold text-slate-900">{ENABLE_ANALYTICS ? "Enabled" : "Disabled"}</p>
            </div>
            <div>
              <p className="text-slate-600">Dev Auth</p>
              <p className={`font-semibold ${ENABLE_DEV_AUTH ? "text-red-600" : "text-emerald-600"}`}>
                {ENABLE_DEV_AUTH ? "⚠ Enabled (UNSAFE)" : "✓ Disabled"}
              </p>
            </div>
          </div>
        </div>

        {anyFailed && (
          <div className="mt-6 p-4 bg-red-50 border-2 border-red-200 rounded-xl">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-red-900 mb-1">Critical Issues Detected</p>
                <p className="text-sm text-red-700">
                  This application has critical issues that must be resolved before production deployment.
                  Contact support if you need assistance.
                </p>
              </div>
            </div>
          </div>
        )}

        {allPassed && (
          <div className="mt-6 p-4 bg-emerald-50 border-2 border-emerald-200 rounded-xl">
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-emerald-900 mb-1">System Ready for Production</p>
                <p className="text-sm text-emerald-700">
                  All critical checks passed. The application is ready for deployment.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="mt-6 bg-slate-50 rounded-xl border border-slate-200 p-6">
        <h3 className="font-bold text-slate-900 mb-4">Pre-Launch Checklist</h3>
        <div className="space-y-2 text-sm">
          {[
            "Set VITE_APP_ENV=production in environment",
            "Ensure VITE_ENABLE_DEV_AUTH is false or unset",
            "Configure VITE_ENABLE_ANALYTICS if needed",
            "Test student signup → onboarding → booking flow",
            "Test instructor login → dashboard → schedule",
            "Test admin login → school setup → data management",
            "Verify multi-tenant isolation (create 2 test schools)",
            "Test all authentication redirects",
            "Verify no console logs in production build",
            "Test error boundaries and retry mechanisms"
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-2">
              <div className="w-5 h-5 rounded border-2 border-slate-300 flex-shrink-0 mt-0.5" />
              <span className="text-slate-700">{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}