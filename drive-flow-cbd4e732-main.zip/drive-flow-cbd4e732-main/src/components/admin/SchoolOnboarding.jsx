import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Building2, Globe, MapPin, Phone, Mail, Loader2, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import VeeMascot from "@/components/common/VeeMascot";
import { logger } from "@/components/utils/config";

function normalizeEmail(email) {
  return email?.trim().toLowerCase() || "";
}

export default function SchoolOnboarding({ user, onComplete }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    city: "",
    postal_code: "",
    country: "France",
    operating_country: "FR",
    phone: "",
    email: normalizeEmail(user?.email) || "",
  });

  const createSchoolMutation = useMutation({
    mutationFn: async (data) => {
      const normalizedEmail = normalizeEmail(data.email);
      
      // Check for existing school to prevent duplicates
      try {
        const existing = await base44.entities.School.filter({ email: normalizedEmail }, "-created_date", 1);
        if (existing && existing.length > 0) {
          logger.warn("School already exists for email:", normalizedEmail);
          const school = existing[0];
          
          // Link to user if not already linked
          if (user?.email) {
            try {
              await base44.auth.updateMe({ school_id: school.id });
            } catch (err) {
              logger.warn("Could not link existing school to user:", err);
            }
          }
          
          return school;
        }
      } catch (err) {
        logger.warn("Could not check for existing school:", err);
      }

      // Create new school
      const school = await base44.entities.School.create({
        name: data.name.trim(),
        address: data.address.trim(),
        city: data.city.trim(),
        postal_code: data.postal_code?.trim() || "",
        country: data.country,
        operating_country: data.operating_country,
        phone: data.phone?.trim() || "",
        email: normalizedEmail,
        is_active: true,
        is_featured: false,
      });

      if (school?.id && user?.email) {
        try {
          await base44.auth.updateMe({ school_id: school.id });
        } catch (err) {
          logger.warn("Could not link school_id to user:", err);
        }
      }

      return school;
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
      toast.success("School created successfully!");
      setTimeout(() => onComplete?.(), 500);
    },
    onError: (error) => {
      logger.error("Failed to create school:", error);
      toast.error(error?.message || "Failed to create school. Please try again.");
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.address || !formData.city) {
      toast.error("Please fill in all required fields");
      return;
    }
    createSchoolMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-50 to-white flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-2xl"
      >
        <div className="bg-white rounded-3xl border border-zinc-200 shadow-xl p-8 md:p-12">
          <div className="flex flex-col items-center mb-8">
            <VeeMascot size="lg" mood="wave" animate={true} />
            <h1 className="text-3xl font-bold text-zinc-900 mt-6 mb-2">Set up your school</h1>
            <p className="text-zinc-600 text-center max-w-md">
              Let's create your school profile to start managing students, instructors, and bookings.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-zinc-700 mb-2">
                School Name <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                  placeholder="My Driving School"
                  required
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-2">
                  Address <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                    placeholder="123 Main Street"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-2">
                  City <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                  placeholder="Paris"
                  required
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-2">Postal Code</label>
                <input
                  type="text"
                  value={formData.postal_code}
                  onChange={(e) => setFormData({ ...formData, postal_code: e.target.value })}
                  className="w-full px-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                  placeholder="75001"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-2">Country</label>
                <div className="relative">
                  <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  <select
                    value={formData.operating_country}
                    onChange={(e) => setFormData({ ...formData, operating_country: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                  >
                    <option value="FR">France</option>
                    <option value="GB">United Kingdom</option>
                    <option value="ES">Spain</option>
                    <option value="DE">Germany</option>
                    <option value="IT">Italy</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-2">Phone</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                    placeholder="+33 1 23 45 67 89"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-2">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3b82c4]/20 focus:border-[#3b82c4]"
                    placeholder="contact@school.com"
                  />
                </div>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={createSchoolMutation.isPending}
              className="w-full py-4 bg-gradient-to-r from-[#3b82c4] to-[#2563a3] hover:from-[#2563a3] hover:to-[#1e4f8a] text-white rounded-xl font-bold shadow-lg transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {createSchoolMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Creating School...
                </>
              ) : (
                <>
                  Complete Setup
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </motion.button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}