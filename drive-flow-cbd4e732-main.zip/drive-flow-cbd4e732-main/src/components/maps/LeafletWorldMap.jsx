import React, { useState, useEffect, useRef, useMemo } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap, useMapEvents, Circle, Polyline, Polygon, ZoomControl, ScaleControl, AttributionControl } from "react-leaflet";
import { motion, AnimatePresence } from "framer-motion";
import {
  MapPin,
  Navigation,
  Layers,
  ZoomIn,
  ZoomOut,
  Locate,
  Search,
  X,
  Filter,
  List,
  Grid,
  ChevronDown,
  Phone,
  Mail,
  Clock,
  Star,
  ExternalLink,
  Route,
  Maximize2,
  Minimize2
} from "lucide-react";
import L from "leaflet";

// Fix default marker icon issue in React-Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png"
});

// Custom marker icons
const createCustomIcon = (color = "#3b82c4", size = 32) => {
  return L.divIcon({
    className: "custom-marker",
    html: `
      <div style="
        width: ${size}px;
        height: ${size}px;
        background: ${color};
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        border: 3px solid white;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <div style="
          width: ${size * 0.4}px;
          height: ${size * 0.4}px;
          background: white;
          border-radius: 50%;
          transform: rotate(45deg);
        "></div>
      </div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size],
    popupAnchor: [0, -size]
  });
};

// Marker type configurations
const markerTypes = {
  default: { color: "#3b82c4", label: "Location" },
  school: { color: "#6c376f", label: "Driving School" },
  pickup: { color: "#81da5a", label: "Pickup Point" },
  student: { color: "#e7d356", label: "Student" },
  instructor: { color: "#3b82c4", label: "Instructor" },
  vehicle: { color: "#a9d5ed", label: "Vehicle" },
  exam: { color: "#e44138", label: "Exam Center" }
};

// Map tile layers
const tileLayers = {
  default: {
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
  },
  satellite: {
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attribution: "&copy; Esri"
  },
  dark: {
    url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
    attribution: '&copy; <a href="https://carto.com/">CARTO</a>'
  },
  light: {
    url: "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
    attribution: '&copy; <a href="https://carto.com/">CARTO</a>'
  }
};

/**
 * Map Controls Component
 */
function MapControls({ onZoomIn, onZoomOut, onLocate, onToggleFullscreen, isFullscreen }) {
  return (
    <div className="absolute right-4 top-4 z-[1000] flex flex-col gap-2">
      <motion.button
        onClick={onZoomIn}
        className="w-10 h-10 bg-white rounded-xl shadow-lg flex items-center justify-center text-gray-700 hover:bg-gray-50 transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <ZoomIn className="w-5 h-5" />
      </motion.button>
      <motion.button
        onClick={onZoomOut}
        className="w-10 h-10 bg-white rounded-xl shadow-lg flex items-center justify-center text-gray-700 hover:bg-gray-50 transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <ZoomOut className="w-5 h-5" />
      </motion.button>
      <motion.button
        onClick={onLocate}
        className="w-10 h-10 bg-white rounded-xl shadow-lg flex items-center justify-center text-gray-700 hover:bg-gray-50 transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Locate className="w-5 h-5" />
      </motion.button>
      <motion.button
        onClick={onToggleFullscreen}
        className="w-10 h-10 bg-white rounded-xl shadow-lg flex items-center justify-center text-gray-700 hover:bg-gray-50 transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
      </motion.button>
    </div>
  );
}

/**
 * Layer Selector Component
 */
function LayerSelector({ currentLayer, onLayerChange }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="absolute left-4 top-4 z-[1000]">
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="w-10 h-10 bg-white rounded-xl shadow-lg flex items-center justify-center text-gray-700 hover:bg-gray-50 transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Layers className="w-5 h-5" />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-12 left-0 bg-white rounded-xl shadow-lg p-2 min-w-[140px]"
          >
            {Object.keys(tileLayers).map((key) => (
              <button
                key={key}
                onClick={() => {
                  onLayerChange(key);
                  setIsOpen(false);
                }}
                className={`w-full px-3 py-2 text-left text-sm rounded-lg capitalize transition-colors ${
                  currentLayer === key
                    ? "bg-[#e8f4fa] text-[#3b82c4] font-medium"
                    : "hover:bg-gray-100 text-gray-700"
                }`}
              >
                {key}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/**
 * Search Box Component
 */
function SearchBox({ onSearch, markers }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (query.length > 1) {
      const filtered = markers.filter((m) =>
        m.title?.toLowerCase().includes(query.toLowerCase()) ||
        m.description?.toLowerCase().includes(query.toLowerCase())
      );
      setResults(filtered);
      setIsOpen(true);
    } else {
      setResults([]);
      setIsOpen(false);
    }
  }, [query, markers]);

  return (
    <div className="absolute left-4 bottom-4 z-[1000] w-72">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search locations..."
          className="w-full pl-10 pr-4 py-3 bg-white rounded-xl shadow-lg border-none outline-none text-sm text-gray-700 placeholder-gray-400"
        />
        {query && (
          <button
            onClick={() => {
              setQuery("");
              setIsOpen(false);
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <AnimatePresence>
        {isOpen && results.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="mt-2 bg-white rounded-xl shadow-lg max-h-60 overflow-y-auto"
          >
            {results.map((marker, idx) => (
              <button
                key={idx}
                onClick={() => {
                  onSearch(marker);
                  setQuery("");
                  setIsOpen(false);
                }}
                className="w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-b-0"
              >
                <p className="text-sm font-medium text-gray-900">{marker.title}</p>
                {marker.description && (
                  <p className="text-xs text-gray-500 truncate">{marker.description}</p>
                )}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/**
 * Custom Popup Content
 */
function PopupContent({ marker, onGetDirections }) {
  const typeConfig = markerTypes[marker.type] || markerTypes.default;

  return (
    <div className="min-w-[200px] max-w-[280px]">
      {marker.image && (
        <img
          src={marker.image}
          alt={marker.title}
          className="w-full h-32 object-cover rounded-t-lg -mt-3 -mx-3 mb-3"
          style={{ width: "calc(100% + 24px)" }}
        />
      )}
      
      <div className="space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-bold text-gray-900">{marker.title}</h3>
          <span
            className="px-2 py-0.5 text-xs font-medium rounded-full text-white"
            style={{ backgroundColor: typeConfig.color }}
          >
            {typeConfig.label}
          </span>
        </div>

        {marker.description && (
          <p className="text-sm text-gray-600">{marker.description}</p>
        )}

        {marker.rating && (
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-[#e7d356] fill-[#e7d356]" />
            <span className="text-sm font-medium text-gray-900">{marker.rating}</span>
            {marker.reviews && (
              <span className="text-xs text-gray-500">({marker.reviews} reviews)</span>
            )}
          </div>
        )}

        {marker.address && (
          <div className="flex items-start gap-2 text-sm text-gray-600">
            <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{marker.address}</span>
          </div>
        )}

        {marker.phone && (
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Phone className="w-4 h-4" />
            <a href={`tel:${marker.phone}`} className="hover:text-[#3b82c4]">
              {marker.phone}
            </a>
          </div>
        )}

        {marker.hours && (
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Clock className="w-4 h-4" />
            <span>{marker.hours}</span>
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <motion.button
            onClick={() => onGetDirections?.(marker)}
            className="flex-1 px-3 py-2 bg-[#3b82c4] text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1 hover:bg-[#2563a3] transition-colors"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Route className="w-3 h-3" />
            Directions
          </motion.button>
          {marker.url && (
            <motion.a
              href={marker.url}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2 bg-gray-100 text-gray-700 text-xs font-semibold rounded-lg flex items-center justify-center gap-1 hover:bg-gray-200 transition-colors"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <ExternalLink className="w-3 h-3" />
            </motion.a>
          )}
        </div>
      </div>
    </div>
  );
}

/**
 * Map Event Handler
 */
function MapEventHandler({ onMapClick, onMoveEnd }) {
  useMapEvents({
    click: (e) => onMapClick?.(e.latlng),
    moveend: (e) => onMoveEnd?.(e.target.getCenter(), e.target.getZoom())
  });
  return null;
}

/**
 * Map Controller for programmatic access
 */
function MapController({ center, zoom, flyTo }) {
  const map = useMap();

  useEffect(() => {
    if (flyTo) {
      map.flyTo([flyTo.lat, flyTo.lng], flyTo.zoom || 15, {
        duration: 1.5
      });
    }
  }, [flyTo, map]);

  return null;
}

/**
 * LeafletWorldMap - Main Component
 */
export default function LeafletWorldMap({
  markers = [],
  center = [48.8566, 2.3522], // Paris default
  zoom = 12,
  height = "500px",
  className = "",
  showControls = true,
  showSearch = true,
  showLayerSelector = true,
  showScale = true,
  onMarkerClick,
  onMapClick,
  onGetDirections,
  routes = [],
  circles = [],
  polygons = []
}) {
  const [currentLayer, setCurrentLayer] = useState("default");
  const [flyTo, setFlyTo] = useState(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [userLocation, setUserLocation] = useState(null);
  const mapRef = useRef(null);

  // Get user location
  const handleLocate = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation([latitude, longitude]);
          setFlyTo({ lat: latitude, lng: longitude, zoom: 15 });
        },
        (error) => console.error("Geolocation error:", error)
      );
    }
  };

  // Handle search selection
  const handleSearch = (marker) => {
    setFlyTo({ lat: marker.position[0], lng: marker.position[1], zoom: 16 });
    onMarkerClick?.(marker);
  };

  // Handle directions
  const handleGetDirections = (marker) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${marker.position[0]},${marker.position[1]}`;
    window.open(url, "_blank");
    onGetDirections?.(marker);
  };

  // Toggle fullscreen
  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  // Memoize marker icons
  const markerIcons = useMemo(() => {
    const icons = {};
    Object.keys(markerTypes).forEach((type) => {
      icons[type] = createCustomIcon(markerTypes[type].color);
    });
    return icons;
  }, []);

  return (
    <motion.div
      className={`relative rounded-2xl overflow-hidden shadow-lg ${className} ${
        isFullscreen ? "fixed inset-0 z-50 rounded-none" : ""
      }`}
      style={{ height: isFullscreen ? "100vh" : height }}
      layout
    >
      {/* Leaflet CSS */}
      <style>{`
        @import url('https://unpkg.com/leaflet@1.9.4/dist/leaflet.css');
        
        .leaflet-container {
          font-family: inherit;
        }
        
        .custom-marker {
          background: transparent;
          border: none;
        }
        
        .leaflet-popup-content-wrapper {
          border-radius: 12px;
          padding: 0;
          overflow: hidden;
        }
        
        .leaflet-popup-content {
          margin: 12px;
        }
        
        .leaflet-popup-tip {
          background: white;
        }
        
        .leaflet-control-attribution {
          background: rgba(255,255,255,0.8) !important;
          padding: 2px 8px !important;
          border-radius: 8px !important;
          margin: 8px !important;
        }
      `}</style>

      <MapContainer
        ref={mapRef}
        center={center}
        zoom={zoom}
        className="w-full h-full"
        zoomControl={false}
        attributionControl={false}
      >
        {/* Tile Layer */}
        <TileLayer {...tileLayers[currentLayer]} />

        {/* Map Controller */}
        <MapController flyTo={flyTo} />

        {/* Event Handler */}
        <MapEventHandler onMapClick={onMapClick} />

        {/* Scale Control */}
        {showScale && <ScaleControl position="bottomright" />}

        {/* Attribution */}
        <AttributionControl position="bottomright" prefix={false} />

        {/* User Location Marker */}
        {userLocation && (
          <Circle
            center={userLocation}
            radius={50}
            pathOptions={{
              color: "#3b82c4",
              fillColor: "#3b82c4",
              fillOpacity: 0.3
            }}
          />
        )}

        {/* Routes/Polylines */}
        {routes.map((route, idx) => (
          <Polyline
            key={idx}
            positions={route.positions}
            pathOptions={{
              color: route.color || "#3b82c4",
              weight: route.weight || 4,
              opacity: route.opacity || 0.8,
              dashArray: route.dashed ? "10, 10" : undefined
            }}
          />
        ))}

        {/* Circles */}
        {circles.map((circle, idx) => (
          <Circle
            key={idx}
            center={circle.center}
            radius={circle.radius}
            pathOptions={{
              color: circle.color || "#3b82c4",
              fillColor: circle.fillColor || circle.color || "#3b82c4",
              fillOpacity: circle.fillOpacity || 0.2
            }}
          />
        ))}

        {/* Polygons */}
        {polygons.map((polygon, idx) => (
          <Polygon
            key={idx}
            positions={polygon.positions}
            pathOptions={{
              color: polygon.color || "#3b82c4",
              fillColor: polygon.fillColor || polygon.color || "#3b82c4",
              fillOpacity: polygon.fillOpacity || 0.2
            }}
          />
        ))}

        {/* Markers */}
        {markers.map((marker, idx) => (
          <Marker
            key={marker.id || idx}
            position={marker.position}
            icon={markerIcons[marker.type] || markerIcons.default}
            eventHandlers={{
              click: () => onMarkerClick?.(marker)
            }}
          >
            <Popup>
              <PopupContent
                marker={marker}
                onGetDirections={handleGetDirections}
              />
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Custom Controls */}
      {showControls && (
        <MapControls
          onZoomIn={() => mapRef.current?.setZoom(mapRef.current.getZoom() + 1)}
          onZoomOut={() => mapRef.current?.setZoom(mapRef.current.getZoom() - 1)}
          onLocate={handleLocate}
          onToggleFullscreen={toggleFullscreen}
          isFullscreen={isFullscreen}
        />
      )}

      {/* Layer Selector */}
      {showLayerSelector && (
        <LayerSelector
          currentLayer={currentLayer}
          onLayerChange={setCurrentLayer}
        />
      )}

      {/* Search Box */}
      {showSearch && markers.length > 0 && (
        <SearchBox markers={markers} onSearch={handleSearch} />
      )}
    </motion.div>
  );
}

/**
 * MarkerList - Side panel list of markers
 */
export function MarkerList({
  markers,
  onMarkerSelect,
  selectedMarkerId,
  className = ""
}) {
  return (
    <div className={`bg-white rounded-2xl shadow-lg overflow-hidden ${className}`}>
      <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
        <h3 className="font-semibold text-gray-900 flex items-center gap-2">
          <List className="w-4 h-4" />
          Locations ({markers.length})
        </h3>
      </div>
      <div className="max-h-[400px] overflow-y-auto">
        {markers.map((marker, idx) => {
          const typeConfig = markerTypes[marker.type] || markerTypes.default;
          const isSelected = marker.id === selectedMarkerId;

          return (
            <motion.button
              key={marker.id || idx}
              onClick={() => onMarkerSelect?.(marker)}
              className={`w-full px-4 py-3 text-left border-b border-gray-100 transition-colors ${
                isSelected ? "bg-[#e8f4fa]" : "hover:bg-gray-50"
              }`}
              whileHover={{ x: 4 }}
            >
              <div className="flex items-start gap-3">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${typeConfig.color}20` }}
                >
                  <MapPin className="w-4 h-4" style={{ color: typeConfig.color }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900 truncate">{marker.title}</p>
                  {marker.address && (
                    <p className="text-xs text-gray-500 truncate">{marker.address}</p>
                  )}
                </div>
                {marker.rating && (
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-[#e7d356] fill-[#e7d356]" />
                    <span className="text-xs font-medium">{marker.rating}</span>
                  </div>
                )}
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}