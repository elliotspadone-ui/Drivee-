import React, { useRef } from "react";
import { motion, useScroll, useTransform, useSpring, useInView } from "framer-motion";

/**
 * FadeSection - Single section that fades in/out based on scroll position
 * 
 * @param {React.ReactNode} children - Section content
 * @param {string} className - Additional CSS classes
 * @param {number} fadeInStart - When to start fading in (0-1)
 * @param {number} fadeInEnd - When to complete fade in (0-1)
 * @param {number} fadeOutStart - When to start fading out (0-1)
 * @param {number} fadeOutEnd - When to complete fade out (0-1)
 */
export function FadeSection({
  children,
  className = "",
  fadeInStart = 0,
  fadeInEnd = 0.3,
  fadeOutStart = 0.7,
  fadeOutEnd = 1,
  scale = true,
  blur = false
}) {
  const ref = useRef(null);
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  // Opacity: fade in then fade out
  const opacity = useTransform(
    smoothProgress,
    [fadeInStart, fadeInEnd, fadeOutStart, fadeOutEnd],
    [0, 1, 1, 0]
  );

  // Scale effect
  const scaleValue = useTransform(
    smoothProgress,
    [fadeInStart, fadeInEnd, fadeOutStart, fadeOutEnd],
    scale ? [0.9, 1, 1, 0.9] : [1, 1, 1, 1]
  );

  // Y translation
  const y = useTransform(
    smoothProgress,
    [fadeInStart, fadeInEnd, fadeOutStart, fadeOutEnd],
    [50, 0, 0, -50]
  );

  // Blur effect
  const blurValue = useTransform(
    smoothProgress,
    [fadeInStart, fadeInEnd, fadeOutStart, fadeOutEnd],
    blur ? [10, 0, 0, 10] : [0, 0, 0, 0]
  );

  return (
    <motion.div
      ref={ref}
      className={className}
      style={{
        opacity,
        scale: scaleValue,
        y,
        filter: blur ? useTransform(blurValue, (v) => `blur(${v}px)`) : undefined
      }}
    >
      {children}
    </motion.div>
  );
}

/**
 * CrossFadeSections - Container for sections that cross-fade as you scroll
 */
export function CrossFadeSections({
  children,
  className = "",
  sectionHeight = "100vh",
  sticky = true
}) {
  const containerRef = useRef(null);
  const childArray = React.Children.toArray(children);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  return (
    <div
      ref={containerRef}
      className={`relative ${className}`}
      style={{ height: `${childArray.length * 100}vh` }}
    >
      {sticky && (
        <div className="sticky top-0 h-screen overflow-hidden">
          {childArray.map((child, index) => {
            const start = index / childArray.length;
            const end = (index + 1) / childArray.length;
            
            return (
              <CrossFadeItem
                key={index}
                progress={scrollYProgress}
                start={start}
                end={end}
                index={index}
                total={childArray.length}
              >
                {child}
              </CrossFadeItem>
            );
          })}
        </div>
      )}
    </div>
  );
}

function CrossFadeItem({ children, progress, start, end, index, total }) {
  const isFirst = index === 0;
  const isLast = index === total - 1;

  const opacity = useTransform(progress, (p) => {
    const sectionProgress = (p - start) / (end - start);
    
    if (p < start) return isFirst ? 1 : 0;
    if (p > end) return isLast ? 1 : 0;
    
    // Fade in during first half, fade out during second half
    if (sectionProgress < 0.5) {
      return isFirst ? 1 : sectionProgress * 2;
    } else {
      return isLast ? 1 : 1 - (sectionProgress - 0.5) * 2;
    }
  });

  const scale = useTransform(progress, (p) => {
    const sectionProgress = (p - start) / (end - start);
    
    if (p < start || p > end) return 1;
    
    if (sectionProgress < 0.5) {
      return 0.95 + sectionProgress * 0.1;
    } else {
      return 1 - (sectionProgress - 0.5) * 0.1;
    }
  });

  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center"
      style={{ opacity, scale }}
    >
      {children}
    </motion.div>
  );
}

/**
 * ScrollFadeIn - Simple fade in on scroll into view
 */
export function ScrollFadeIn({
  children,
  className = "",
  direction = "up",
  delay = 0,
  duration = 0.6,
  once = true,
  amount = 0.3
}) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once, amount });

  const directions = {
    up: { y: 40 },
    down: { y: -40 },
    left: { x: 40 },
    right: { x: -40 },
    none: {}
  };

  return (
    <motion.div
      ref={ref}
      className={className}
      initial={{ opacity: 0, ...directions[direction] }}
      animate={isInView ? { opacity: 1, x: 0, y: 0 } : { opacity: 0, ...directions[direction] }}
      transition={{ duration, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

/**
 * ParallaxFade - Parallax effect with fade
 */
export function ParallaxFade({
  children,
  className = "",
  speed = 0.5,
  fadeOut = true
}) {
  const ref = useRef(null);
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], [100 * speed, -100 * speed]);
  const opacity = useTransform(
    scrollYProgress,
    fadeOut ? [0, 0.2, 0.8, 1] : [0, 0.3, 1, 1],
    fadeOut ? [0, 1, 1, 0] : [0, 1, 1, 1]
  );

  return (
    <motion.div
      ref={ref}
      className={className}
      style={{ y, opacity }}
    >
      {children}
    </motion.div>
  );
}

/**
 * StaggerFadeIn - Stagger children fade in on scroll
 */
export function StaggerFadeIn({
  children,
  className = "",
  staggerDelay = 0.1,
  once = true
}) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once, amount: 0.2 });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: staggerDelay,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] }
    }
  };

  return (
    <motion.div
      ref={ref}
      className={className}
      variants={containerVariants}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
    >
      {React.Children.map(children, (child, index) => (
        <motion.div key={index} variants={itemVariants}>
          {child}
        </motion.div>
      ))}
    </motion.div>
  );
}

/**
 * ScrollProgress - Visual scroll progress indicator
 */
export function ScrollProgress({
  color = "#3b82c4",
  height = 4,
  position = "top",
  zIndex = 50
}) {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });

  return (
    <motion.div
      className={`fixed left-0 right-0 origin-left`}
      style={{
        [position]: 0,
        height,
        backgroundColor: color,
        scaleX,
        zIndex
      }}
    />
  );
}

export default FadeSection;