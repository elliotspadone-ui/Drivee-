import React, { useState, useEffect, useMemo } from "react";
import { X, Clock, User, Car, MapPin, DollarSign, FileText, AlertTriangle, Calendar } from "lucide-react";
import { format, parseISO, setHours, setMinutes, differenceInMinutes } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import ConflictChecker from "./ConflictChecker";

const LESSON_TYPES = [
  { id: "standard", name: "Standard Lesson", duration: 60, color: "bg-indigo-500", price: 50 },
  { id: "extended", name: "Extended Lesson", duration: 90, color: "bg-purple-500", price: 70 },
  { id: "highway", name: "Highway Driving", duration: 120, color: "bg-blue-500", price: 90 },
  { id: "night", name: "Night Driving", duration: 60, color: "bg-slate-700", price: 60 },
  { id: "parking", name: "Parking Practice", duration: 45, color: "bg-emerald-500", price: 40 },
  { id: "exam_prep", name: "Exam Preparation", duration: 90, color: "bg-amber-500", price: 75 },
  { id: "refresher", name: "Refresher Course", duration: 60, color: "bg-teal-500", price: 50 },
  { id: "theory", name: "Theory", duration: 60, color: "bg-cyan-500", price: 45 },
];

const STATUS_OPTIONS = [
  { value: "pending", label: "Pending" },
  { value: "confirmed", label: "Confirmed" },
  { value: "completed", label: "Completed" },
  { value: "cancelled", label: "Cancelled" },
  { value: "no_show", label: "No Show" },
];

export default function EnhancedBookingForm({
  isOpen,
  onClose,
  booking,
  selectedSlot,
  students,
  instructors,
  vehicles,
  existingBookings,
  schools,
  onSave,
  onUpdate,
}) {
  const [formData, setFormData] = useState({
    student_id: "",
    instructor_id: "",
    vehicle_id: "",
    lesson_type: "standard",
    price: 50,
    status: "pending",
    pickup_location: "",
    notes: "",
  });

  const [selectedDate, setSelectedDate] = useState("");
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("10:00");
  const [conflicts, setConflicts] = useState([]);
  const [showConflictOverride, setShowConflictOverride] = useState(false);

  const currentSchool = schools?.[0];

  useEffect(() => {
    if (booking) {
      const start = parseISO(booking.start_datetime);
      const end = parseISO(booking.end_datetime);
      setFormData({
        student_id: booking.student_id || "",
        instructor_id: booking.instructor_id || "",
        vehicle_id: booking.vehicle_id || "",
        lesson_type: booking.lesson_type || "standard",
        price: booking.price || 50,
        status: booking.status || "pending",
        pickup_location: booking.pickup_location || "",
        notes: booking.notes || "",
      });
      setSelectedDate(format(start, "yyyy-MM-dd"));
      setStartTime(format(start, "HH:mm"));
      setEndTime(format(end, "HH:mm"));
    } else if (selectedSlot) {
      const startDate = setHours(
        setMinutes(selectedSlot.day, selectedSlot.minute || 0),
        selectedSlot.hour
      );
      const defaultType = LESSON_TYPES.find(t => t.id === "standard");
      const endDate = new Date(startDate.getTime() + (defaultType?.duration || 60) * 60 * 1000);
      setSelectedDate(format(selectedSlot.day, "yyyy-MM-dd"));
      setStartTime(format(startDate, "HH:mm"));
      setEndTime(format(endDate, "HH:mm"));
      setFormData((prev) => ({
        ...prev,
        instructor_id: selectedSlot.instructor_id || "",
        price: defaultType?.price || 50,
      }));
    } else {
      const defaultType = LESSON_TYPES.find(t => t.id === "standard");
      setFormData({
        student_id: "",
        instructor_id: "",
        vehicle_id: "",
        lesson_type: "standard",
        price: defaultType?.price || 50,
        status: "pending",
        pickup_location: "",
        notes: "",
      });
      setSelectedDate(format(new Date(), "yyyy-MM-dd"));
      setStartTime("09:00");
      setEndTime("10:00");
    }
    setConflicts([]);
    setShowConflictOverride(false);
  }, [booking, selectedSlot, isOpen]);

  const checkConflicts = useMemo(() => {
    if (!selectedDate || !startTime || !endTime) return [];
    
    const [startHour, startMinute] = startTime.split(":").map(Number);
    const [endHour, endMinute] = endTime.split(":").map(Number);
    const proposedStart = setMinutes(setHours(parseISO(selectedDate), startHour), startMinute);
    const proposedEnd = setMinutes(setHours(parseISO(selectedDate), endHour), endMinute);

    const foundConflicts = [];

    existingBookings
      .filter(b => booking ? b.id !== booking.id : true)
      .filter(b => b.status !== "cancelled" && b.status !== "no_show")
      .forEach(existingBooking => {
        const existingStart = parseISO(existingBooking.start_datetime);
        const existingEnd = parseISO(existingBooking.end_datetime);

        const hasOverlap = proposedStart < existingEnd && proposedEnd > existingStart;
        if (!hasOverlap) return;

        if (formData.instructor_id && existingBooking.instructor_id === formData.instructor_id) {
          const instructor = instructors.find(i => i.id === formData.instructor_id);
          foundConflicts.push({
            type: "instructor",
            name: instructor?.full_name || "Instructor",
            existingBooking,
          });
        }

        if (formData.student_id && existingBooking.student_id === formData.student_id) {
          const student = students.find(s => s.id === formData.student_id);
          foundConflicts.push({
            type: "student",
            name: student?.full_name || "Student",
            existingBooking,
          });
        }

        if (formData.vehicle_id && existingBooking.vehicle_id === formData.vehicle_id) {
          const vehicle = vehicles.find(v => v.id === formData.vehicle_id);
          foundConflicts.push({
            type: "vehicle",
            name: `${vehicle?.make} ${vehicle?.model}` || "Vehicle",
            existingBooking,
          });
        }
      });

    return foundConflicts;
  }, [selectedDate, startTime, endTime, formData.instructor_id, formData.student_id, formData.vehicle_id, existingBookings, booking, instructors, students, vehicles]);

  useEffect(() => {
    setConflicts(checkConflicts);
    setShowConflictOverride(checkConflicts.length > 0);
  }, [checkConflicts]);

  const duration = useMemo(() => {
    if (!startTime || !endTime) return 0;
    const [sh, sm] = startTime.split(":").map(Number);
    const [eh, em] = endTime.split(":").map(Number);
    const start = setMinutes(setHours(new Date(), sh), sm);
    const end = setMinutes(setHours(new Date(), eh), em);
    return differenceInMinutes(end, start);
  }, [startTime, endTime]);

  const handleLessonTypeChange = (typeId) => {
    const lessonType = LESSON_TYPES.find((t) => t.id === typeId);
    if (lessonType) {
      setFormData((prev) => ({ 
        ...prev, 
        lesson_type: typeId,
        price: lessonType.price 
      }));
      
      const [hour, minute] = startTime.split(":").map(Number);
      const startDate = setMinutes(setHours(new Date(), hour), minute);
      const endDate = new Date(startDate.getTime() + lessonType.duration * 60 * 1000);
      setEndTime(format(endDate, "HH:mm"));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.student_id || !formData.instructor_id || !formData.vehicle_id || !selectedDate) {
      return;
    }

    if (conflicts.length > 0 && !showConflictOverride) {
      setShowConflictOverride(true);
      return;
    }

    const [startHour, startMinute] = startTime.split(":").map(Number);
    const [endHour, endMinute] = endTime.split(":").map(Number);
    const startDateTime = setMinutes(setHours(parseISO(selectedDate), startHour), startMinute);
    const endDateTime = setMinutes(setHours(parseISO(selectedDate), endHour), endMinute);

    const bookingData = {
      ...formData,
      school_id: currentSchool?.id || "",
      start_datetime: startDateTime.toISOString(),
      end_datetime: endDateTime.toISOString(),
    };

    if (booking && onUpdate) {
      onUpdate(booking.id, bookingData);
    } else if (onSave) {
      onSave(bookingData);
    }

    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[95vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between p-6 border-b border-zinc-200 bg-gradient-to-r from-indigo-50 to-purple-50">
            <div>
              <h2 className="text-xl font-bold text-zinc-900">
                {booking ? "Edit Lesson" : "New Lesson"}
              </h2>
              <p className="text-sm text-zinc-600 mt-0.5">
                {duration > 0 && `Duration: ${duration} minutes`}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-white/50 transition"
            >
              <X className="w-5 h-5 text-zinc-500" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto max-h-[calc(95vh-140px)]">
            {showConflictOverride && conflicts.length > 0 && (
              <ConflictChecker
                conflicts={conflicts}
                onOverride={() => setShowConflictOverride(false)}
                onCancel={onClose}
              />
            )}

            {/* Student & Instructor */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-zinc-700 mb-2">
                  <User className="w-4 h-4 text-zinc-400" />
                  Student *
                </label>
                <select
                  value={formData.student_id}
                  onChange={(e) => setFormData((prev) => ({ ...prev, student_id: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
                  required
                >
                  <option value="">Select student</option>
                  {students.filter((s) => s.is_active).map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.full_name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-zinc-700 mb-2">
                  <User className="w-4 h-4 text-zinc-400" />
                  Instructor *
                </label>
                <select
                  value={formData.instructor_id}
                  onChange={(e) => setFormData((prev) => ({ ...prev, instructor_id: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
                  required
                >
                  <option value="">Select instructor</option>
                  {instructors.filter((i) => i.is_active).map((instructor) => (
                    <option key={instructor.id} value={instructor.id}>
                      {instructor.full_name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Date & Time */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-zinc-700 mb-2">
                  <Calendar className="w-4 h-4 text-zinc-400" />
                  Date *
                </label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
                  required
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-zinc-700 mb-2">
                  <Clock className="w-4 h-4 text-zinc-400" />
                  Start Time *
                </label>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
                  required
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-zinc-700 mb-2">
                  <Clock className="w-4 h-4 text-zinc-400" />
                  End Time *
                </label>
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
                  required
                />
              </div>
            </div>

            {/* Lesson Type */}
            <div>
              <label className="block text-sm font-semibold text-zinc-700 mb-3">
                Lesson Type
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {LESSON_TYPES.map((type) => (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => handleLessonTypeChange(type.id)}
                    className={`p-4 rounded-xl border-2 text-left transition ${
                      formData.lesson_type === type.id
                        ? "border-indigo-500 bg-indigo-50 shadow-md"
                        : "border-zinc-200 hover:border-zinc-300 hover:shadow-sm"
                    }`}
                  >
                    <div className={`w-4 h-4 rounded-full ${type.color} mb-2`} />
                    <p className="text-sm font-semibold text-zinc-900">{type.name}</p>
                    <p className="text-xs text-zinc-500 mt-1">{type.duration} min • €{type.price}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Vehicle & Price */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-zinc-700 mb-2">
                  <Car className="w-4 h-4 text-zinc-400" />
                  Vehicle *
                </label>
                <select
                  value={formData.vehicle_id}
                  onChange={(e) => setFormData((prev) => ({ ...prev, vehicle_id: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
                  required
                >
                  <option value="">Select vehicle</option>
                  {vehicles.filter((v) => v.is_available).map((vehicle) => (
                    <option key={vehicle.id} value={vehicle.id}>
                      {vehicle.make} {vehicle.model} ({vehicle.license_plate})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-zinc-700 mb-2">
                  <DollarSign className="w-4 h-4 text-zinc-400" />
                  Price (€) *
                </label>
                <input
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData((prev) => ({ ...prev, price: Number(e.target.value) }))}
                  className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
                  min="0"
                  step="0.01"
                  required
                />
              </div>
            </div>

            {/* Pickup Location */}
            <div>
              <label className="flex items-center gap-2 text-sm font-semibold text-zinc-700 mb-2">
                <MapPin className="w-4 h-4 text-zinc-400" />
                Pickup Location
              </label>
              <input
                type="text"
                value={formData.pickup_location}
                onChange={(e) => setFormData((prev) => ({ ...prev, pickup_location: e.target.value }))}
                placeholder="Enter pickup address"
                className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
              />
            </div>

            {/* Notes */}
            <div>
              <label className="flex items-center gap-2 text-sm font-semibold text-zinc-700 mb-2">
                <FileText className="w-4 h-4 text-zinc-400" />
                Notes
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                placeholder="Additional notes, special requirements, areas to focus on..."
                rows={3}
                className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition resize-none"
              />
            </div>

            {/* Status (only for editing) */}
            {booking && (
              <div>
                <label className="block text-sm font-semibold text-zinc-700 mb-2">
                  Status
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData((prev) => ({ ...prev, status: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl border-2 border-zinc-200 focus:border-indigo-500 focus:outline-none transition"
                >
                  {STATUS_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center justify-between gap-3 pt-4 border-t-2 border-zinc-100">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 rounded-xl border-2 border-zinc-200 font-semibold text-zinc-700 hover:bg-zinc-50 transition"
              >
                Cancel
              </button>
              
              <div className="flex items-center gap-3">
                {conflicts.length > 0 && !showConflictOverride && (
                  <div className="flex items-center gap-2 text-amber-600 text-sm font-medium">
                    <AlertTriangle className="w-4 h-4" />
                    {conflicts.length} conflict{conflicts.length > 1 ? 's' : ''}
                  </div>
                )}
                <button
                  type="submit"
                  className={`px-6 py-3 rounded-xl font-semibold transition ${
                    conflicts.length > 0 && showConflictOverride
                      ? "bg-amber-600 hover:bg-amber-700 text-white"
                      : "bg-indigo-600 hover:bg-indigo-700 text-white"
                  }`}
                >
                  {conflicts.length > 0 && showConflictOverride
                    ? "Override & Save"
                    : booking
                    ? "Update Lesson"
                    : "Create Lesson"}
                </button>
              </div>
            </div>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}