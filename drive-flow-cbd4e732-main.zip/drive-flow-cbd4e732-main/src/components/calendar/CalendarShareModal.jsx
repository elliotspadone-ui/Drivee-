import React, { useState } from "react";
import { X, Share2, Eye, Edit, Lock, Users } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function CalendarShareModal({ 
  isOpen, 
  onClose, 
  currentUser,
  users = [],
  existingShares = [],
  onShare,
  onRevoke
}) {
  const [selectedUser, setSelectedUser] = useState("");
  const [permissions, setPermissions] = useState({
    permission_level: "view_only",
    can_view_bookings: true,
    can_view_blocks: false,
    can_create_bookings: false,
    can_edit_bookings: false
  });

  const permissionLevels = [
    { 
      value: "view_only", 
      label: "View Only", 
      icon: Eye,
      description: "Can see free/busy times only"
    },
    { 
      value: "view_details", 
      label: "View Details", 
      icon: Users,
      description: "Can see booking details"
    },
    { 
      value: "edit", 
      label: "Edit", 
      icon: Edit,
      description: "Can create and edit bookings"
    },
    { 
      value: "manage", 
      label: "Manage", 
      icon: Lock,
      description: "Full access including sharing"
    }
  ];

  const handleShare = () => {
    if (!selectedUser) {
      toast.error("Please select a user");
      return;
    }

    onShare({
      shared_with_id: selectedUser,
      ...permissions
    });

    setSelectedUser("");
    toast.success("Calendar shared successfully");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="neo-surface p-8 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="neo-inset w-12 h-12 rounded-2xl flex items-center justify-center">
              <Share2 className="w-6 h-6 text-indigo-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Share Calendar</h2>
          </div>
          <button onClick={onClose} className="neo-button p-3 rounded-xl">
            <X className="w-5 h-5 text-gray-700" />
          </button>
        </div>

        {/* Add New Share */}
        <div className="neo-inset p-6 rounded-2xl mb-6">
          <h3 className="font-semibold text-gray-900 mb-4">Share With</h3>
          
          <select
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
            className="neo-button w-full px-4 py-3 rounded-xl mb-4"
          >
            <option value="">Select user...</option>
            {users
              .filter(u => u.id !== currentUser.id)
              .filter(u => !existingShares.some(s => s.shared_with_id === u.id))
              .map(user => (
                <option key={user.id} value={user.id}>
                  {user.full_name} ({user.email})
                </option>
              ))}
          </select>

          <p className="text-sm font-semibold text-gray-900 mb-3">Permission Level</p>
          <div className="grid grid-cols-2 gap-3 mb-4">
            {permissionLevels.map(level => (
              <button
                key={level.value}
                onClick={() => setPermissions({ 
                  ...permissions, 
                  permission_level: level.value,
                  can_view_bookings: true,
                  can_view_blocks: level.value !== 'view_only',
                  can_create_bookings: level.value === 'edit' || level.value === 'manage',
                  can_edit_bookings: level.value === 'edit' || level.value === 'manage'
                })}
                className={`neo-button p-4 rounded-xl text-left ${
                  permissions.permission_level === level.value ? 'active bg-indigo-50' : ''
                }`}
              >
                <level.icon className="w-5 h-5 text-indigo-600 mb-2" />
                <p className="font-semibold text-gray-900 text-sm">{level.label}</p>
                <p className="text-xs text-muted mt-1">{level.description}</p>
              </button>
            ))}
          </div>

          <button
            onClick={handleShare}
            className="neo-button w-full py-3 gradient-primary text-white font-semibold"
          >
            Share Calendar
          </button>
        </div>

        {/* Existing Shares */}
        {existingShares.length > 0 && (
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Shared With</h3>
            <div className="space-y-2">
              {existingShares.map((share) => {
                const sharedUser = users.find(u => u.id === share.shared_with_id);
                const level = permissionLevels.find(l => l.value === share.permission_level);
                
                return (
                  <div key={share.id} className="neo-inset p-4 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-indigo-400 to-purple-400 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">
                          {sharedUser?.full_name?.charAt(0) || '?'}
                        </span>
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{sharedUser?.full_name}</p>
                        <p className="text-xs text-muted">{level?.label}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => onRevoke(share.id)}
                      className="neo-button px-4 py-2 text-sm font-semibold text-red-700"
                    >
                      Revoke
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}