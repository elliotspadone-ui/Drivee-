import React from "react";
import { CheckSquare, Trash2, Calendar, Copy, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function BatchOperationsBar({ 
  selectedBookings = [],
  onClearSelection,
  onBatchDelete,
  onBatchReschedule,
  onBatchDuplicate,
  onBatchStatusChange
}) {
  if (selectedBookings.length === 0) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-40"
      >
        <div className="neo-surface p-4 rounded-2xl shadow-2xl">
          <div className="flex items-center gap-4">
            <div className="neo-inset px-4 py-2 rounded-xl">
              <p className="text-sm font-semibold text-gray-900">
                {selectedBookings.length} selected
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onBatchStatusChange}
                className="neo-button p-3 rounded-xl hover:bg-green-50"
                title="Mark as completed"
              >
                <CheckSquare className="w-5 h-5 text-green-700" />
              </button>

              <button
                onClick={onBatchReschedule}
                className="neo-button p-3 rounded-xl hover:bg-blue-50"
                title="Reschedule"
              >
                <Calendar className="w-5 h-5 text-blue-700" />
              </button>

              <button
                onClick={onBatchDuplicate}
                className="neo-button p-3 rounded-xl hover:bg-purple-50"
                title="Duplicate"
              >
                <Copy className="w-5 h-5 text-purple-700" />
              </button>

              <button
                onClick={onBatchDelete}
                className="neo-button p-3 rounded-xl hover:bg-red-50"
                title="Delete"
              >
                <Trash2 className="w-5 h-5 text-red-700" />
              </button>
            </div>

            <button
              onClick={onClearSelection}
              className="neo-button p-3 rounded-xl"
              title="Clear selection"
            >
              <X className="w-5 h-5 text-gray-700" />
            </button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}