import React from "react";
import { AlertTriangle, User, Car, Users } from "lucide-react";
import { format, parseISO } from "date-fns";

export default function ConflictChecker({ conflicts, onOverride, onCancel }) {
  if (!conflicts || conflicts.length === 0) return null;

  return (
    <div className="mb-6 p-5 bg-amber-50 border-2 border-amber-300 rounded-xl">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0">
          <AlertTriangle className="w-5 h-5 text-amber-600" />
        </div>
        <div className="flex-1">
          <h4 className="font-bold text-amber-900 mb-1">Booking Conflict Detected</h4>
          <p className="text-sm text-amber-800">
            {conflicts.length} conflict{conflicts.length > 1 ? 's' : ''} found with existing bookings
          </p>
        </div>
      </div>

      <div className="space-y-3 mb-4">
        {conflicts.map((conflict, index) => (
          <div key={index} className="bg-white rounded-lg border border-amber-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              {conflict.type === 'instructor' && <User className="w-4 h-4 text-amber-600" />}
              {conflict.type === 'student' && <Users className="w-4 h-4 text-amber-600" />}
              {conflict.type === 'vehicle' && <Car className="w-4 h-4 text-amber-600" />}
              <p className="text-sm font-semibold text-amber-900 capitalize">
                {conflict.type} already booked
              </p>
            </div>
            <p className="text-sm text-gray-700">
              {conflict.name} is already scheduled from{' '}
              <span className="font-medium">
                {format(parseISO(conflict.existingBooking.start_datetime), "h:mm a")}
              </span>
              {' '}to{' '}
              <span className="font-medium">
                {format(parseISO(conflict.existingBooking.end_datetime), "h:mm a")}
              </span>
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Booking ID: {conflict.existingBooking.id?.substring(0, 8)}
            </p>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={onCancel}
          className="flex-1 px-4 py-2.5 bg-white border-2 border-amber-300 rounded-xl font-semibold text-amber-900 hover:bg-amber-50 transition"
        >
          Cancel & Adjust
        </button>
        <button
          onClick={onOverride}
          className="flex-1 px-4 py-2.5 bg-amber-600 text-white rounded-xl font-semibold hover:bg-amber-700 transition"
        >
          Override & Book Anyway
        </button>
      </div>
    </div>
  );
}