import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Clock, Plus, Trash2, RepeatIcon } from "lucide-react";
import { toast } from "sonner";

export default function RecurringSlotManager({ instructorId, schoolId }) {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    day_of_week: 1,
    start_time: "09:00",
    end_time: "17:00",
    slot_duration: 60,
  });

  const { data: availability = [] } = useQuery({
    queryKey: ['instructorAvailability', instructorId],
    queryFn: () => base44.entities.InstructorAvailability.filter({ instructor_id: instructorId }),
    enabled: !!instructorId,
  });

  const createSlotMutation = useMutation({
    mutationFn: async () => {
      const existingPattern = availability.find(a => a.weekly_pattern);
      const weeklyPattern = existingPattern?.weekly_pattern || {
        monday: [], tuesday: [], wednesday: [], thursday: [],
        friday: [], saturday: [], sunday: []
      };

      const dayName = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'][formData.day_of_week];
      
      if (!weeklyPattern[dayName]) {
        weeklyPattern[dayName] = [];
      }

      weeklyPattern[dayName].push({
        start_time: formData.start_time,
        end_time: formData.end_time,
        slot_duration: formData.slot_duration,
      });

      if (existingPattern) {
        return base44.entities.InstructorAvailability.update(existingPattern.id, {
          ...existingPattern,
          weekly_pattern: weeklyPattern,
        });
      } else {
        return base44.entities.InstructorAvailability.create({
          school_id: schoolId,
          instructor_id: instructorId,
          weekly_pattern: weeklyPattern,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorAvailability'] });
      toast.success("Recurring slot added");
      setShowForm(false);
      setFormData({
        day_of_week: 1,
        start_time: "09:00",
        end_time: "17:00",
        slot_duration: 60,
      });
    },
  });

  const deleteSlotMutation = useMutation({
    mutationFn: async ({ availId, dayName, slotIndex }) => {
      const avail = availability.find(a => a.id === availId);
      const updatedPattern = { ...avail.weekly_pattern };
      updatedPattern[dayName].splice(slotIndex, 1);
      
      return base44.entities.InstructorAvailability.update(availId, {
        ...avail,
        weekly_pattern: updatedPattern,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instructorAvailability'] });
      toast.success("Slot removed");
    },
  });

  const weeklyPattern = availability.find(a => a.weekly_pattern)?.weekly_pattern || {};
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  return (
    <div className="bg-white rounded-2xl shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
          <RepeatIcon className="w-5 h-5 text-indigo-600" />
          Recurring Availability
        </h3>
        <button
          onClick={() => setShowForm(!showForm)}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Slot
        </button>
      </div>

      {showForm && (
        <div className="bg-gray-50 rounded-xl p-4 mb-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Day</label>
              <select
                value={formData.day_of_week}
                onChange={(e) => setFormData({ ...formData, day_of_week: parseInt(e.target.value) })}
                className="w-full px-3 py-2 rounded-lg border border-gray-200"
              >
                {days.map((day, idx) => (
                  <option key={idx} value={idx}>{day}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Duration</label>
              <select
                value={formData.slot_duration}
                onChange={(e) => setFormData({ ...formData, slot_duration: parseInt(e.target.value) })}
                className="w-full px-3 py-2 rounded-lg border border-gray-200"
              >
                <option value={30}>30 minutes</option>
                <option value={60}>1 hour</option>
                <option value={90}>1.5 hours</option>
                <option value={120}>2 hours</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Time</label>
              <input
                type="time"
                value={formData.start_time}
                onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-gray-200"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Time</label>
              <input
                type="time"
                value={formData.end_time}
                onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-gray-200"
              />
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => createSlotMutation.mutate()}
              disabled={createSlotMutation.isPending}
              className="flex-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium"
            >
              {createSlotMutation.isPending ? "Adding..." : "Add Slot"}
            </button>
            <button
              onClick={() => setShowForm(false)}
              className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg font-medium"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {days.map((day, dayIdx) => {
          const dayKey = day.toLowerCase();
          const slots = weeklyPattern[dayKey] || [];
          
          if (slots.length === 0) return null;

          return (
            <div key={day} className="border-2 border-gray-200 rounded-xl p-4">
              <p className="font-semibold text-gray-900 mb-2">{day}</p>
              <div className="space-y-2">
                {slots.map((slot, slotIdx) => (
                  <div
                    key={slotIdx}
                    className="flex items-center justify-between bg-gray-50 rounded-lg p-3"
                  >
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-gray-600" />
                      <span className="text-sm font-medium">
                        {slot.start_time} - {slot.end_time}
                      </span>
                      <span className="text-xs text-gray-500">
                        ({slot.slot_duration} min slots)
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        const availId = availability.find(a => a.weekly_pattern)?.id;
                        deleteSlotMutation.mutate({ availId, dayName: dayKey, slotIndex: slotIdx });
                      }}
                      className="p-2 hover:bg-red-100 rounded-lg text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {Object.values(weeklyPattern).every(slots => !slots || slots.length === 0) && (
          <p className="text-center text-gray-500 py-8">
            No recurring slots configured. Add your first slot to get started.
          </p>
        )}
      </div>
    </div>
  );
}