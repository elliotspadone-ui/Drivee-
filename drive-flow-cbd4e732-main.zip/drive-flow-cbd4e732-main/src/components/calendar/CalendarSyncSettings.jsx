import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Calendar, RefreshCw, Trash2, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function CalendarSyncSettings({ instructorId }) {
  const queryClient = useQueryClient();
  const [syncing, setSyncing] = useState(false);

  const { data: syncSettings = [] } = useQuery({
    queryKey: ['calendarSync', instructorId],
    queryFn: () => base44.entities.CalendarSync.filter({ instructor_id: instructorId }),
    enabled: !!instructorId,
  });

  const connectGoogleCalendar = async () => {
    setSyncing(true);
    try {
      // In production, this would redirect to Google OAuth
      await base44.entities.CalendarSync.create({
        instructor_id: instructorId,
        provider: "google",
        sync_enabled: true,
        sync_direction: "bidirectional",
        last_sync: new Date().toISOString(),
      });
      
      queryClient.invalidateQueries({ queryKey: ['calendarSync'] });
      toast.success("Google Calendar connected successfully");
    } catch (error) {
      toast.error("Failed to connect calendar");
    } finally {
      setSyncing(false);
    }
  };

  const disconnectMutation = useMutation({
    mutationFn: (syncId) => base44.entities.CalendarSync.delete(syncId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendarSync'] });
      toast.success("Calendar disconnected");
    },
  });

  const syncNowMutation = useMutation({
    mutationFn: async (sync) => {
      await base44.entities.CalendarSync.update(sync.id, {
        ...sync,
        last_sync: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendarSync'] });
      toast.success("Calendar synced");
    },
  });

  const googleSync = syncSettings.find(s => s.provider === "google");

  return (
    <div className="bg-white rounded-2xl shadow-sm p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
        <Calendar className="w-5 h-5 text-indigo-600" />
        Calendar Synchronization
      </h3>

      {googleSync ? (
        <div className="border-2 border-green-200 bg-green-50 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <div>
                <p className="font-semibold text-gray-900">Google Calendar Connected</p>
                <p className="text-sm text-gray-600">
                  Last synced: {new Date(googleSync.last_sync).toLocaleString()}
                </p>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => syncNowMutation.mutate(googleSync)}
              disabled={syncNowMutation.isPending}
              className="flex-1 px-4 py-2 bg-white border border-gray-200 rounded-lg font-medium hover:bg-gray-50 flex items-center justify-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${syncNowMutation.isPending ? 'animate-spin' : ''}`} />
              Sync Now
            </button>
            <button
              onClick={() => disconnectMutation.mutate(googleSync.id)}
              className="px-4 py-2 bg-white border border-red-200 text-red-600 rounded-lg font-medium hover:bg-red-50 flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Disconnect
            </button>
          </div>
        </div>
      ) : (
        <div className="border-2 border-gray-200 rounded-xl p-6 text-center">
          <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-600 mb-4">
            Connect your Google Calendar to automatically sync your availability
          </p>
          <button
            onClick={connectGoogleCalendar}
            disabled={syncing}
            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold"
          >
            {syncing ? "Connecting..." : "Connect Google Calendar"}
          </button>
        </div>
      )}

      <div className="mt-4 text-sm text-gray-600">
        <p className="font-medium mb-2">How it works:</p>
        <ul className="space-y-1 list-disc list-inside">
          <li>Your DRIVEE lessons sync to your Google Calendar</li>
          <li>Blocked time in Google Calendar prevents double bookings</li>
          <li>Changes sync automatically every 15 minutes</li>
        </ul>
      </div>
    </div>
  );
}