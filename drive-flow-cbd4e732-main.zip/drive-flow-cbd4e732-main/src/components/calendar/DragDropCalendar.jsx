import React, { useState, useCallback, useMemo } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { parseISO, setHours, setMinutes, format, differenceInMinutes, isSameDay, getHours } from "date-fns";
import { Clock, User, Car, MapPin, AlertTriangle, GripVertical } from "lucide-react";
import { toast } from "sonner";

const STATUS_CONFIG = {
  pending: { color: "bg-amber-100 border-amber-300 text-amber-700" },
  confirmed: { color: "bg-emerald-100 border-emerald-300 text-emerald-700" },
  completed: { color: "bg-blue-100 border-blue-300 text-blue-700" },
  cancelled: { color: "bg-red-100 border-red-300 text-red-700" },
  no_show: { color: "bg-zinc-100 border-zinc-300 text-zinc-700" },
};

const INSTRUCTOR_COLORS = [
  "bg-indigo-500",
  "bg-purple-500",
  "bg-blue-500",
  "bg-emerald-500",
  "bg-amber-500",
  "bg-rose-500",
  "bg-cyan-500",
  "bg-orange-500",
];

const getInstructorColor = (instructorId, instructors) => {
  const index = instructors.findIndex((i) => i.id === instructorId);
  return INSTRUCTOR_COLORS[index % INSTRUCTOR_COLORS.length];
};

export default function DragDropCalendar({
  bookings,
  students,
  instructors,
  vehicles,
  timeSlots,
  days,
  onBookingDrop,
  onBookingClick,
  onSlotClick,
  filterInstructor,
  filterStatus,
  isCompact = false,
}) {
  const [draggedBooking, setDraggedBooking] = useState(null);
  const [hoveredSlot, setHoveredSlot] = useState(null);

  const studentMap = useMemo(() => new Map(students.map((s) => [s.id, s])), [students]);
  const instructorMap = useMemo(() => new Map(instructors.map((i) => [i.id, i])), [instructors]);
  const vehicleMap = useMemo(() => new Map(vehicles.map((v) => [v.id, v])), [vehicles]);

  const getBookingsForSlot = useCallback(
    (day, hour) => {
      return bookings.filter((booking) => {
        const bookingDate = parseISO(booking.start_datetime);
        const matchesDay = isSameDay(bookingDate, day);
        const matchesHour = getHours(bookingDate) === hour;
        const matchesInstructor = filterInstructor === "all" || booking.instructor_id === filterInstructor;
        const matchesStatus = filterStatus === "all" || booking.status === filterStatus;
        return matchesDay && matchesHour && matchesInstructor && matchesStatus;
      });
    },
    [bookings, filterInstructor, filterStatus]
  );

  const handleDragStart = (result) => {
    const booking = bookings.find(b => b.id === result.draggableId);
    setDraggedBooking(booking);
  };

  const handleDragEnd = (result) => {
    setDraggedBooking(null);
    setHoveredSlot(null);

    if (!result.destination) return;

    const { draggableId, destination } = result;
    const [dayIndex, hour] = destination.droppableId.split("-").slice(1).map(Number);
    
    if (isNaN(dayIndex) || isNaN(hour)) return;

    const booking = bookings.find(b => b.id === draggableId);
    if (!booking) return;

    const targetDay = days[dayIndex];
    const startTime = parseISO(booking.start_datetime);
    const endTime = parseISO(booking.end_datetime);
    const duration = differenceInMinutes(endTime, startTime);

    const newStart = setMinutes(setHours(targetDay, hour), 0);
    const newEnd = new Date(newStart.getTime() + duration * 60 * 1000);

    const hasConflict = bookings.some(b => {
      if (b.id === booking.id) return false;
      if (b.status === "cancelled" || b.status === "no_show") return false;
      
      const existingStart = parseISO(b.start_datetime);
      const existingEnd = parseISO(b.end_datetime);
      
      const overlap = newStart < existingEnd && newEnd > existingStart;
      if (!overlap) return false;
      
      return b.instructor_id === booking.instructor_id || 
             b.student_id === booking.student_id || 
             b.vehicle_id === booking.vehicle_id;
    });

    if (hasConflict) {
      toast.error("Cannot reschedule: time slot conflicts with existing booking");
      return;
    }

    onBookingDrop(booking.id, {
      start_datetime: newStart.toISOString(),
      end_datetime: newEnd.toISOString(),
    });
  };

  const renderBookingCard = (booking, isDragging = false) => {
    const student = studentMap.get(booking.student_id);
    const instructor = instructorMap.get(booking.instructor_id);
    const startTime = parseISO(booking.start_datetime);
    const instructorColor = getInstructorColor(booking.instructor_id, instructors);
    const statusConfig = STATUS_CONFIG[booking.status] || STATUS_CONFIG.pending;

    return (
      <div
        className={`group px-3 py-2 rounded-lg border-l-4 ${instructorColor.replace("bg-", "border-")} ${
          statusConfig.color
        } cursor-move hover:shadow-md transition-all ${isDragging ? "opacity-50 rotate-2" : ""}`}
        onClick={(e) => {
          e.stopPropagation();
          onBookingClick(booking);
        }}
      >
        <div className="flex items-center gap-2">
          <GripVertical className="w-3 h-3 text-zinc-400 group-hover:text-zinc-600" />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold truncate text-zinc-900">
              {format(startTime, "HH:mm")} - {student?.full_name || "Student"}
            </p>
            {!isCompact && (
              <p className="text-xs text-zinc-600 truncate">{instructor?.full_name}</p>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <DragDropContext onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
      <div className="space-y-1">
        {timeSlots.filter((_, i) => i % 2 === 0).map((slot) => (
          <div key={`${slot.hour}-${slot.minute}`} className="grid grid-cols-8 gap-2">
            <div className="p-2 rounded-lg bg-zinc-50 border border-zinc-100 flex items-center justify-center">
              <p className="text-sm font-medium text-zinc-600">
                {slot.hour.toString().padStart(2, "0")}:{slot.minute.toString().padStart(2, "0")}
              </p>
            </div>

            {days.map((day, dayIndex) => {
              const slotBookings = getBookingsForSlot(day, slot.hour);
              const slotId = `slot-${dayIndex}-${slot.hour}`;
              const isHovered = hoveredSlot === slotId;
              const isPastSlot = new Date(setHours(setMinutes(day, slot.minute), slot.hour)) < new Date();

              return (
                <Droppable key={slotId} droppableId={slotId}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={`min-h-[70px] p-1.5 rounded-xl border transition-all ${
                        snapshot.isDraggingOver
                          ? "bg-indigo-100 border-indigo-400 ring-2 ring-indigo-200"
                          : isPastSlot
                          ? "bg-zinc-50 border-zinc-100 opacity-50"
                          : "bg-white border-zinc-100 hover:border-zinc-200 hover:shadow-sm"
                      } ${!isPastSlot && slotBookings.length === 0 ? "cursor-pointer" : ""}`}
                      onClick={() => {
                        if (!isPastSlot && slotBookings.length === 0) {
                          onSlotClick({ day, hour: slot.hour, minute: slot.minute });
                        }
                      }}
                      onMouseEnter={() => setHoveredSlot(slotId)}
                      onMouseLeave={() => setHoveredSlot(null)}
                    >
                      <div className="space-y-1">
                        {slotBookings.map((booking, index) => (
                          <Draggable
                            key={booking.id}
                            draggableId={booking.id}
                            index={index}
                            isDragDisabled={booking.status === "completed" || booking.status === "cancelled"}
                          >
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                              >
                                {renderBookingCard(booking, snapshot.isDragging)}
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>

                      {slotBookings.length === 0 && !isPastSlot && (
                        <div className={`h-full flex items-center justify-center transition ${
                          isHovered ? "opacity-100" : "opacity-0"
                        }`}>
                          <div className="text-xs text-zinc-400 font-medium">+ Add</div>
                        </div>
                      )}
                    </div>
                  )}
                </Droppable>
              );
            })}
          </div>
        ))}
      </div>
    </DragDropContext>
  );
}