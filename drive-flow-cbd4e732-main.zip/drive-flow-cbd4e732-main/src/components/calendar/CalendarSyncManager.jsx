/**
 * Calendar Synchronization Manager
 * Handles two-way sync with external calendars
 */

export class CalendarSyncManager {
  constructor(syncConfig, bookings, blocks) {
    this.syncConfig = syncConfig;
    this.bookings = bookings;
    this.blocks = blocks;
  }

  /**
   * Generate iCal feed for bookings
   */
  generateICalFeed(instructorId, bookingsToExport, blocksToExport = []) {
    const events = [];

    // Add bookings
    bookingsToExport.forEach(booking => {
      events.push({
        uid: `booking-${booking.id}@driveschool.app`,
        start: booking.start_datetime,
        end: booking.end_datetime,
        summary: `Driving Lesson - ${booking.student_name || 'Student'}`,
        description: `Instructor: ${booking.instructor_name}\nVehicle: ${booking.vehicle_name}\nPickup: ${booking.pickup_location}`,
        location: booking.pickup_location,
        status: booking.status === 'confirmed' ? 'CONFIRMED' : 'TENTATIVE',
        categories: ['DRIVING_LESSON']
      });
    });

    // Add blocks
    blocksToExport.forEach(block => {
      events.push({
        uid: `block-${block.id}@driveschool.app`,
        start: block.start_datetime,
        end: block.end_datetime,
        summary: block.title || 'Blocked Time',
        description: block.notes,
        status: 'CONFIRMED',
        categories: [block.reason.toUpperCase()]
      });
    });

    return this.buildICalString(events);
  }

  buildICalString(events) {
    let ical = 'BEGIN:VCALENDAR\r\n';
    ical += 'VERSION:2.0\r\n';
    ical += 'PRODID:-//DriveSchool//Calendar//EN\r\n';
    ical += 'CALSCALE:GREGORIAN\r\n';
    ical += 'METHOD:PUBLISH\r\n';
    ical += 'X-WR-CALNAME:Driving School Schedule\r\n';
    ical += `X-WR-TIMEZONE:${this.syncConfig.timezone || 'UTC'}\r\n`;

    events.forEach(event => {
      ical += 'BEGIN:VEVENT\r\n';
      ical += `UID:${event.uid}\r\n`;
      ical += `DTSTAMP:${this.formatICalDate(new Date())}\r\n`;
      ical += `DTSTART:${this.formatICalDate(new Date(event.start))}\r\n`;
      ical += `DTEND:${this.formatICalDate(new Date(event.end))}\r\n`;
      ical += `SUMMARY:${this.escapeICalText(event.summary)}\r\n`;
      
      if (event.description) {
        ical += `DESCRIPTION:${this.escapeICalText(event.description)}\r\n`;
      }
      
      if (event.location) {
        ical += `LOCATION:${this.escapeICalText(event.location)}\r\n`;
      }
      
      if (event.status) {
        ical += `STATUS:${event.status}\r\n`;
      }
      
      if (event.categories) {
        ical += `CATEGORIES:${event.categories.join(',')}\r\n`;
      }

      ical += 'END:VEVENT\r\n';
    });

    ical += 'END:VCALENDAR\r\n';
    return ical;
  }

  formatICalDate(date) {
    return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  }

  escapeICalText(text) {
    if (!text) return '';
    return text.replace(/\\/g, '\\\\')
               .replace(/;/g, '\\;')
               .replace(/,/g, '\\,')
               .replace(/\n/g, '\\n');
  }

  /**
   * Convert external calendar event to CalendarBlock
   */
  externalEventToBlock(externalEvent, instructorId, schoolId, provider) {
    return {
      instructor_id: instructorId,
      school_id: schoolId,
      title: externalEvent.summary || 'Blocked Time',
      start_datetime: this.convertToUTC(externalEvent.start, externalEvent.timeZone),
      end_datetime: this.convertToUTC(externalEvent.end, externalEvent.timeZone),
      reason: this.categorizeEvent(externalEvent),
      notes: externalEvent.description,
      is_all_day: externalEvent.allDay || false,
      external_event_id: externalEvent.id,
      synced_from: provider
    };
  }

  categorizeEvent(event) {
    const summary = (event.summary || '').toLowerCase();
    if (summary.includes('vacation') || summary.includes('holiday')) return 'vacation';
    if (summary.includes('sick') || summary.includes('doctor')) return 'sick_leave';
    if (summary.includes('meeting')) return 'meeting';
    if (summary.includes('training')) return 'training';
    return 'personal';
  }

  convertToUTC(dateString, timezone) {
    // In production, use a proper timezone library like date-fns-tz or luxon
    const date = new Date(dateString);
    return date.toISOString();
  }

  /**
   * Detect conflicts between external events and bookings
   */
  detectExternalConflicts(externalEvents, instructorId) {
    const conflicts = [];

    externalEvents.forEach(extEvent => {
      const extStart = new Date(extEvent.start);
      const extEnd = new Date(extEvent.end);

      this.bookings
        .filter(b => b.instructor_id === instructorId && b.status !== 'cancelled')
        .forEach(booking => {
          const bookingStart = new Date(booking.start_datetime);
          const bookingEnd = new Date(booking.end_datetime);

          if (this.hasOverlap(extStart, extEnd, bookingStart, bookingEnd)) {
            conflicts.push({
              type: 'external_conflict',
              externalEvent: extEvent,
              booking: booking,
              message: `External event "${extEvent.summary}" conflicts with booking`
            });
          }
        });
    });

    return conflicts;
  }

  hasOverlap(start1, end1, start2, end2) {
    return start1 < end2 && end1 > start2;
  }

  /**
   * Prepare booking data for external calendar
   */
  bookingToExternalEvent(booking, timezone = 'UTC') {
    return {
      summary: `Driving Lesson - ${booking.student_name || 'Student'}`,
      description: `Instructor: ${booking.instructor_name}\nVehicle: ${booking.vehicle_name}\nPickup: ${booking.pickup_location}\n\nBooked via DriveSchool`,
      start: {
        dateTime: booking.start_datetime,
        timeZone: timezone
      },
      end: {
        dateTime: booking.end_datetime,
        timeZone: timezone
      },
      location: booking.pickup_location,
      colorId: this.getColorForCategory('lesson'),
      reminders: {
        useDefault: false,
        overrides: [
          { method: 'popup', minutes: 60 }
        ]
      }
    };
  }

  getColorForCategory(category) {
    const colorMap = this.syncConfig.color_mapping || {
      lesson: '9', // Blue
      personal: '5', // Yellow
      meeting: '6', // Orange
      vacation: '11' // Red
    };
    return colorMap[category] || '1';
  }

  /**
   * Generate OAuth URL for calendar provider
   */
  getOAuthURL(provider, redirectUri, state) {
    const scopes = {
      google: 'https://www.googleapis.com/auth/calendar',
      outlook: 'https://graph.microsoft.com/Calendars.ReadWrite'
    };

    const authUrls = {
      google: 'https://accounts.google.com/o/oauth2/v2/auth',
      outlook: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize'
    };

    const params = new URLSearchParams({
      client_id: this.getClientId(provider),
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: scopes[provider],
      state: state,
      access_type: 'offline',
      prompt: 'consent'
    });

    return `${authUrls[provider]}?${params.toString()}`;
  }

  getClientId(provider) {
    // In production, these would be environment variables
    return provider === 'google' ? 'YOUR_GOOGLE_CLIENT_ID' : 'YOUR_OUTLOOK_CLIENT_ID';
  }
}

export default CalendarSyncManager;