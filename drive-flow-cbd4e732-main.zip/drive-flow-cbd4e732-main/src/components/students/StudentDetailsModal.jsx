import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Mail, Phone, Calendar, Award, TrendingUp, MapPin } from "lucide-react";
import { format } from "date-fns";

export default function StudentDetailsModal({ student, bookings, onClose }) {
  if (!student) return null;

  const studentBookings = bookings.filter(b => b.student_id === student.id);
  const completedLessons = studentBookings.filter(b => b.status === "completed");
  const upcomingLessons = studentBookings.filter(b => 
    new Date(b.start_datetime) > new Date() && b.status === "confirmed"
  );

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Student Details</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition">
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-2xl flex items-center justify-center">
                <span className="text-white text-2xl font-bold">
                  {student.full_name?.charAt(0) || "S"}
                </span>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900">{student.full_name}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                    student.is_active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"
                  }`}>
                    {student.is_active ? "Active" : "Inactive"}
                  </span>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {student.email && (
                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                  <Mail className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-xs text-gray-600">Email</p>
                    <p className="text-sm font-semibold text-gray-900">{student.email}</p>
                  </div>
                </div>
              )}
              {student.phone && (
                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                  <Phone className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-xs text-gray-600">Phone</p>
                    <p className="text-sm font-semibold text-gray-900">{student.phone}</p>
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-indigo-50 rounded-xl text-center">
                <p className="text-2xl font-bold text-indigo-600">{completedLessons.length}</p>
                <p className="text-xs text-indigo-900">Completed</p>
              </div>
              <div className="p-4 bg-green-50 rounded-xl text-center">
                <p className="text-2xl font-bold text-green-600">{student.total_hours_completed || 0}</p>
                <p className="text-xs text-green-900">Hours</p>
              </div>
              <div className="p-4 bg-purple-50 rounded-xl text-center">
                <p className="text-2xl font-bold text-purple-600">{student.progress_percentage || 0}%</p>
                <p className="text-xs text-purple-900">Progress</p>
              </div>
            </div>

            {upcomingLessons.length > 0 && (
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Upcoming Lessons</h4>
                <div className="space-y-2">
                  {upcomingLessons.slice(0, 3).map(booking => (
                    <div key={booking.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-900">
                          {format(new Date(booking.start_datetime), "MMM d, h:mm a")}
                        </span>
                      </div>
                      <span className="text-xs text-gray-600">{booking.status}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}