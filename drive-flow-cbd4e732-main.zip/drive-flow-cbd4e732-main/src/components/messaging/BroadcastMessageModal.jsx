import React, { useState } from "react";
import { motion } from "framer-motion";
import { X, Send, Users, Mail, MessageSquare } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function BroadcastMessageModal({ students, onClose }) {
  const [message, setMessage] = useState("");
  const [subject, setSubject] = useState("");
  const [method, setMethod] = useState("email");
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    if (!message.trim()) {
      toast.error("Please enter a message");
      return;
    }

    setSending(true);
    try {
      const sendPromises = students.map(student => {
        if (method === "email" && student.email) {
          return base44.integrations.Core.SendEmail({
            to: student.email,
            subject: subject || "Message from your instructor",
            body: message
          });
        }
        return Promise.resolve();
      });

      await Promise.all(sendPromises);
      toast.success(`Message sent to ${students.length} students`);
      onClose();
    } catch (error) {
      toast.error("Failed to send messages");
      console.error(error);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full"
      >
        <div className="p-6 border-b flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Broadcast Message</h2>
              <p className="text-sm text-gray-600">{students.length} students</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Method Selector */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Send via</label>
            <div className="flex gap-2">
              <button
                onClick={() => setMethod("email")}
                className={`flex-1 p-3 rounded-lg border-2 transition flex items-center justify-center gap-2 ${
                  method === "email"
                    ? "border-indigo-600 bg-indigo-50 text-indigo-700"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <Mail className="w-5 h-5" />
                <span className="font-medium">Email</span>
              </button>
              <button
                onClick={() => setMethod("sms")}
                className={`flex-1 p-3 rounded-lg border-2 transition flex items-center justify-center gap-2 ${
                  method === "sms"
                    ? "border-indigo-600 bg-indigo-50 text-indigo-700"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <MessageSquare className="w-5 h-5" />
                <span className="font-medium">SMS (Coming Soon)</span>
              </button>
            </div>
          </div>

          {/* Subject (Email only) */}
          {method === "email" && (
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">Subject</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Enter email subject..."
                className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
            </div>
          )}

          {/* Message */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Message</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message here..."
              className="w-full h-40 px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-600 resize-none"
            />
          </div>

          {/* Recipients Preview */}
          <div className="bg-gray-50 rounded-lg p-4">
            <p className="text-sm font-medium text-gray-700 mb-2">Recipients:</p>
            <div className="flex flex-wrap gap-2">
              {students.slice(0, 5).map(student => (
                <span
                  key={student.id}
                  className="px-3 py-1 bg-white rounded-full text-xs font-medium text-gray-700 border"
                >
                  {student.full_name}
                </span>
              ))}
              {students.length > 5 && (
                <span className="px-3 py-1 bg-white rounded-full text-xs font-medium text-gray-500 border">
                  +{students.length - 5} more
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="p-6 border-t flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-6 py-3 rounded-lg border-2 border-gray-200 font-semibold text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            onClick={handleSend}
            disabled={sending || !message.trim()}
            className="flex-1 px-6 py-3 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {sending ? (
              "Sending..."
            ) : (
              <>
                <Send className="w-5 h-5" />
                Send Message
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
}