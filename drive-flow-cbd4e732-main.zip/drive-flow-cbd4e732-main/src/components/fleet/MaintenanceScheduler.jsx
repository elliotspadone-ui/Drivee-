import React, { useState } from "react";
import { motion } from "framer-motion";
import { Calendar, X, Wrench } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

export default function MaintenanceScheduler({ vehicle, onClose, onSave }) {
  const [schedule, setSchedule] = useState({
    schedule_type: "date",
    date_interval_days: 90,
    mileage_interval: 5000,
    alert_days_before: 7,
    alert_mileage_before: 500,
  });

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="neo-surface p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded-3xl"
      >
        <div className="flex items-start justify-between mb-6">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-1">Maintenance Schedule</h3>
            <p className="text-sm text-muted">
              {vehicle.make} {vehicle.model} - {vehicle.license_plate}
            </p>
          </div>
          <button onClick={onClose} className="neo-button p-3 rounded-xl">
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Schedule Type</label>
            <Select
              value={schedule.schedule_type}
              onValueChange={(value) => setSchedule({ ...schedule, schedule_type: value })}
            >
              <SelectTrigger className="neo-inset">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Time-Based (Days)</SelectItem>
                <SelectItem value="mileage">Mileage-Based</SelectItem>
                <SelectItem value="both">Both</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {(schedule.schedule_type === "date" || schedule.schedule_type === "both") && (
            <div className="neo-inset p-6 rounded-2xl space-y-4">
              <h4 className="font-semibold text-gray-900 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-indigo-600" />
                Time-Based Schedule
              </h4>
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Maintenance Interval (Days)
                </label>
                <Input
                  type="number"
                  value={schedule.date_interval_days}
                  onChange={(e) => setSchedule({ ...schedule, date_interval_days: parseInt(e.target.value) })}
                  className="neo-inset"
                  placeholder="90"
                />
                <p className="text-xs text-muted mt-1">Service every X days</p>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Alert Before (Days)
                </label>
                <Input
                  type="number"
                  value={schedule.alert_days_before}
                  onChange={(e) => setSchedule({ ...schedule, alert_days_before: parseInt(e.target.value) })}
                  className="neo-inset"
                  placeholder="7"
                />
                <p className="text-xs text-muted mt-1">Notify instructors X days before service due</p>
              </div>
            </div>
          )}

          {(schedule.schedule_type === "mileage" || schedule.schedule_type === "both") && (
            <div className="neo-inset p-6 rounded-2xl space-y-4">
              <h4 className="font-semibold text-gray-900 flex items-center gap-2">
                <Wrench className="w-5 h-5 text-orange-600" />
                Mileage-Based Schedule
              </h4>
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Maintenance Interval (km)
                </label>
                <Input
                  type="number"
                  value={schedule.mileage_interval}
                  onChange={(e) => setSchedule({ ...schedule, mileage_interval: parseInt(e.target.value) })}
                  className="neo-inset"
                  placeholder="5000"
                />
                <p className="text-xs text-muted mt-1">Service every X kilometers</p>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Alert Before (km)
                </label>
                <Input
                  type="number"
                  value={schedule.alert_mileage_before}
                  onChange={(e) => setSchedule({ ...schedule, alert_mileage_before: parseInt(e.target.value) })}
                  className="neo-inset"
                  placeholder="500"
                />
                <p className="text-xs text-muted mt-1">Notify instructors X km before service due</p>
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <Button onClick={onClose} className="neo-button flex-1 py-3 font-semibold">
              Cancel
            </Button>
            <Button
              onClick={() => onSave(schedule)}
              className="neo-button flex-1 py-3 gradient-primary text-white font-semibold"
            >
              Save Schedule
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}