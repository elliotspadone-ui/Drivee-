import React, { useState } from "react";
import { motion } from "framer-motion";
import { AlertTriangle, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

export default function MaintenanceIssueReport({ vehicle, onClose, onSubmit }) {
  const [issue, setIssue] = useState({
    severity: "medium",
    description: "",
    current_mileage: vehicle?.mileage || 0,
  });

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="neo-surface p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded-3xl"
      >
        <div className="flex items-start justify-between mb-6">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-1">Report Maintenance Issue</h3>
            <p className="text-sm text-muted">
              {vehicle?.make} {vehicle?.model} - {vehicle?.license_plate}
            </p>
          </div>
          <button onClick={onClose} className="neo-button p-3 rounded-xl">
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Issue Severity</label>
            <Select
              value={issue.severity}
              onValueChange={(value) => setIssue({ ...issue, severity: value })}
            >
              <SelectTrigger className="neo-inset">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low - Can wait for next service</SelectItem>
                <SelectItem value="medium">Medium - Address within a week</SelectItem>
                <SelectItem value="high">High - Urgent attention needed</SelectItem>
                <SelectItem value="critical">Critical - Vehicle unsafe to drive</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Current Mileage (km)</label>
            <Input
              type="number"
              value={issue.current_mileage}
              onChange={(e) => setIssue({ ...issue, current_mileage: parseInt(e.target.value) })}
              className="neo-inset"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Issue Description</label>
            <Textarea
              value={issue.description}
              onChange={(e) => setIssue({ ...issue, description: e.target.value })}
              className="neo-inset h-32 resize-none"
              placeholder="Describe the issue in detail (e.g., strange noise from engine, brake feels soft, tire pressure low...)"
            />
          </div>

          <div className="neo-inset p-4 rounded-xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-gray-900 mb-1">Important</p>
              <p className="text-xs text-muted">
                If the vehicle is unsafe to drive (Critical severity), please stop using it immediately and contact the school office.
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <Button onClick={onClose} className="neo-button flex-1 py-3 font-semibold">
              Cancel
            </Button>
            <Button
              onClick={() => onSubmit(issue)}
              disabled={!issue.description.trim()}
              className="neo-button flex-1 py-3 gradient-primary text-white font-semibold disabled:opacity-50"
            >
              Submit Report
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}