import React, { useMemo, useState } from "react";
import { Group } from "@visx/group";
import { LinearGradient } from "@visx/gradient";
import { Text } from "@visx/text";
import { useTooltip, TooltipWithBounds, defaultStyles } from "@visx/tooltip";
import { localPoint } from "@visx/event";
import { motion } from "framer-motion";

const tooltipStyles = {
  ...defaultStyles,
  background: "white",
  border: "1px solid #e2e8f0",
  borderRadius: "12px",
  boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
  padding: "12px",
  fontFamily: "Plus Jakarta Sans, system-ui, sans-serif",
};

// Color palette for nodes
const NODE_COLORS = {
  source: "#3b82c4",
  stage1: "#6c376f",
  stage2: "#81da5a",
  stage3: "#e7d356",
  target: "#5cb83a",
  dropout: "#e44138"
};

/**
 * Sankey Flow Chart - Visualizes user journeys and conversion funnels
 * 
 * @param {Array} nodes - Array of { id, label, value, stage, color? }
 * @param {Array} links - Array of { source, target, value }
 * @param {number} width - Chart width
 * @param {number} height - Chart height
 * @param {Function} onNodeClick - Click handler for nodes
 * @param {Function} onLinkClick - Click handler for links
 */
export default function SankeyFlowChart({
  nodes = [],
  links = [],
  width = 900,
  height = 500,
  margin = { top: 40, right: 40, bottom: 40, left: 40 },
  nodeWidth = 24,
  nodePadding = 16,
  onNodeClick,
  onLinkClick,
  title = "User Journey Flow",
  subtitle = "Conversion funnel visualization",
  showValues = true,
  showPercentages = true,
  animated = true
}) {
  const [hoveredNode, setHoveredNode] = useState(null);
  const [hoveredLink, setHoveredLink] = useState(null);

  const {
    tooltipData,
    tooltipLeft,
    tooltipTop,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip();

  // Calculate Sankey layout
  const { sankeyNodes, sankeyLinks, stages } = useMemo(() => {
    if (nodes.length === 0 || links.length === 0) {
      return { sankeyNodes: [], sankeyLinks: [], stages: [] };
    }

    // Group nodes by stage
    const stageGroups = {};
    nodes.forEach(node => {
      const stage = node.stage || 0;
      if (!stageGroups[stage]) stageGroups[stage] = [];
      stageGroups[stage].push({ ...node });
    });

    const stageKeys = Object.keys(stageGroups).map(Number).sort((a, b) => a - b);
    const numStages = stageKeys.length;

    // Calculate positions
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    const stageWidth = innerWidth / Math.max(numStages - 1, 1);

    // Position nodes
    const positionedNodes = [];
    const nodeMap = {};

    stageKeys.forEach((stage, stageIndex) => {
      const stageNodes = stageGroups[stage];
      const totalValue = stageNodes.reduce((sum, n) => sum + (n.value || 0), 0);
      const availableHeight = innerHeight - (stageNodes.length - 1) * nodePadding;
      
      let currentY = 0;
      stageNodes.forEach((node, nodeIndex) => {
        const nodeHeight = totalValue > 0 
          ? Math.max((node.value / totalValue) * availableHeight, 30)
          : availableHeight / stageNodes.length;
        
        const positionedNode = {
          ...node,
          x: stageIndex * stageWidth,
          y: currentY,
          width: nodeWidth,
          height: nodeHeight,
          stageIndex
        };
        
        positionedNodes.push(positionedNode);
        nodeMap[node.id] = positionedNode;
        currentY += nodeHeight + nodePadding;
      });
    });

    // Calculate links with positions
    const sourceOffsets = {};
    const targetOffsets = {};

    const positionedLinks = links.map(link => {
      const sourceNode = nodeMap[link.source];
      const targetNode = nodeMap[link.target];

      if (!sourceNode || !targetNode) return null;

      // Calculate link thickness based on value
      const maxLinkValue = Math.max(...links.map(l => l.value || 0));
      const linkThickness = maxLinkValue > 0 
        ? Math.max((link.value / maxLinkValue) * 40, 4)
        : 10;

      // Track offsets for multiple links from same source/target
      if (!sourceOffsets[link.source]) sourceOffsets[link.source] = 0;
      if (!targetOffsets[link.target]) targetOffsets[link.target] = 0;

      const sourceY = sourceNode.y + sourceOffsets[link.source] + linkThickness / 2;
      const targetY = targetNode.y + targetOffsets[link.target] + linkThickness / 2;

      sourceOffsets[link.source] += linkThickness + 2;
      targetOffsets[link.target] += linkThickness + 2;

      return {
        ...link,
        sourceNode,
        targetNode,
        sourceX: sourceNode.x + nodeWidth,
        sourceY: Math.min(sourceY, sourceNode.y + sourceNode.height - linkThickness / 2),
        targetX: targetNode.x,
        targetY: Math.min(targetY, targetNode.y + targetNode.height - linkThickness / 2),
        thickness: linkThickness
      };
    }).filter(Boolean);

    return {
      sankeyNodes: positionedNodes,
      sankeyLinks: positionedLinks,
      stages: stageKeys
    };
  }, [nodes, links, width, height, margin, nodeWidth, nodePadding]);

  // Generate curved path for links
  const generateLinkPath = (link) => {
    const { sourceX, sourceY, targetX, targetY, thickness } = link;
    const curvature = 0.5;
    const xi = (targetX - sourceX) * curvature;

    return `
      M ${sourceX} ${sourceY - thickness / 2}
      C ${sourceX + xi} ${sourceY - thickness / 2},
        ${targetX - xi} ${targetY - thickness / 2},
        ${targetX} ${targetY - thickness / 2}
      L ${targetX} ${targetY + thickness / 2}
      C ${targetX - xi} ${targetY + thickness / 2},
        ${sourceX + xi} ${sourceY + thickness / 2},
        ${sourceX} ${sourceY + thickness / 2}
      Z
    `;
  };

  // Get node color
  const getNodeColor = (node) => {
    if (node.color) return node.color;
    if (node.id.includes("drop") || node.id.includes("churn")) return NODE_COLORS.dropout;
    const stageColors = ["#3b82c4", "#6c376f", "#81da5a", "#e7d356", "#5cb83a"];
    return stageColors[node.stageIndex % stageColors.length];
  };

  // Handle tooltip
  const handleNodeHover = (event, node) => {
    const coords = localPoint(event);
    setHoveredNode(node.id);
    showTooltip({
      tooltipData: { type: "node", data: node },
      tooltipLeft: coords?.x || 0,
      tooltipTop: coords?.y || 0,
    });
  };

  const handleLinkHover = (event, link) => {
    const coords = localPoint(event);
    setHoveredLink(`${link.source}-${link.target}`);
    showTooltip({
      tooltipData: { type: "link", data: link },
      tooltipLeft: coords?.x || 0,
      tooltipTop: coords?.y || 0,
    });
  };

  const handleMouseLeave = () => {
    setHoveredNode(null);
    setHoveredLink(null);
    hideTooltip();
  };

  // Calculate total for percentages
  const totalSourceValue = useMemo(() => {
    const sourceNodes = sankeyNodes.filter(n => n.stageIndex === 0);
    return sourceNodes.reduce((sum, n) => sum + (n.value || 0), 0);
  }, [sankeyNodes]);

  if (nodes.length === 0 || links.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-50 rounded-2xl border border-gray-200">
        <p className="text-gray-500">No flow data available</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6">
      {/* Header */}
      <div className="mb-6">
        <h3 className="text-lg font-bold text-gray-900">{title}</h3>
        <p className="text-sm text-gray-600">{subtitle}</p>
      </div>

      {/* Chart */}
      <svg width={width} height={height}>
        {/* Gradients for links */}
        {sankeyLinks.map((link, i) => (
          <LinearGradient
            key={`gradient-${i}`}
            id={`link-gradient-${link.source}-${link.target}`}
            from={getNodeColor(link.sourceNode)}
            to={getNodeColor(link.targetNode)}
            fromOpacity={0.5}
            toOpacity={0.5}
          />
        ))}

        <Group left={margin.left} top={margin.top}>
          {/* Links */}
          {sankeyLinks.map((link, i) => {
            const isHovered = hoveredLink === `${link.source}-${link.target}`;
            const isConnected = hoveredNode === link.source || hoveredNode === link.target;
            const opacity = hoveredNode || hoveredLink
              ? (isHovered || isConnected ? 0.8 : 0.15)
              : 0.5;

            return (
              <motion.path
                key={`link-${i}`}
                d={generateLinkPath(link)}
                fill={`url(#link-gradient-${link.source}-${link.target})`}
                opacity={opacity}
                initial={animated ? { opacity: 0 } : false}
                animate={{ opacity }}
                transition={{ duration: 0.3 }}
                style={{ cursor: "pointer" }}
                onMouseEnter={(e) => handleLinkHover(e, link)}
                onMouseLeave={handleMouseLeave}
                onClick={() => onLinkClick?.(link)}
              />
            );
          })}

          {/* Nodes */}
          {sankeyNodes.map((node, i) => {
            const isHovered = hoveredNode === node.id;
            const nodeColor = getNodeColor(node);
            const percentage = totalSourceValue > 0 
              ? Math.round((node.value / totalSourceValue) * 100) 
              : 0;

            return (
              <Group key={`node-${i}`}>
                <motion.rect
                  x={node.x}
                  y={node.y}
                  width={node.width}
                  height={node.height}
                  fill={nodeColor}
                  rx={6}
                  opacity={hoveredNode && !isHovered ? 0.5 : 1}
                  initial={animated ? { scaleY: 0, opacity: 0 } : false}
                  animate={{ scaleY: 1, opacity: hoveredNode && !isHovered ? 0.5 : 1 }}
                  transition={{ duration: 0.4, delay: i * 0.05 }}
                  style={{ cursor: "pointer", transformOrigin: `${node.x}px ${node.y}px` }}
                  onMouseEnter={(e) => handleNodeHover(e, node)}
                  onMouseLeave={handleMouseLeave}
                  onClick={() => onNodeClick?.(node)}
                />

                {/* Node label */}
                <Text
                  x={node.stageIndex === stages.length - 1 ? node.x - 8 : node.x + node.width + 8}
                  y={node.y + node.height / 2}
                  textAnchor={node.stageIndex === stages.length - 1 ? "end" : "start"}
                  verticalAnchor="middle"
                  fill="#1e293b"
                  fontSize={12}
                  fontWeight={600}
                  fontFamily="Plus Jakarta Sans, system-ui, sans-serif"
                >
                  {node.label}
                </Text>

                {/* Value label */}
                {showValues && (
                  <Text
                    x={node.stageIndex === stages.length - 1 ? node.x - 8 : node.x + node.width + 8}
                    y={node.y + node.height / 2 + 16}
                    textAnchor={node.stageIndex === stages.length - 1 ? "end" : "start"}
                    verticalAnchor="middle"
                    fill="#64748b"
                    fontSize={11}
                    fontFamily="Plus Jakarta Sans, system-ui, sans-serif"
                  >
                    {node.value?.toLocaleString()}{showPercentages && ` (${percentage}%)`}
                  </Text>
                )}
              </Group>
            );
          })}
        </Group>
      </svg>

      {/* Legend / Summary */}
      <div className="mt-6 pt-4 border-t border-gray-100">
        <div className="flex flex-wrap gap-4 justify-center">
          {sankeyNodes.filter(n => n.stageIndex === 0).map((node, i) => (
            <div key={i} className="flex items-center gap-2">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: getNodeColor(node) }}
              />
              <span className="text-sm text-gray-600">{node.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Tooltip */}
      {tooltipOpen && tooltipData && (
        <TooltipWithBounds
          top={tooltipTop}
          left={tooltipLeft}
          style={tooltipStyles}
        >
          {tooltipData.type === "node" ? (
            <div>
              <p className="text-sm font-bold text-gray-900 mb-1">
                {tooltipData.data.label}
              </p>
              <p className="text-sm text-gray-600">
                Value: {tooltipData.data.value?.toLocaleString()}
              </p>
              {showPercentages && (
                <p className="text-sm text-gray-600">
                  {Math.round((tooltipData.data.value / totalSourceValue) * 100)}% of total
                </p>
              )}
            </div>
          ) : (
            <div>
              <p className="text-sm font-bold text-gray-900 mb-1">
                {tooltipData.data.sourceNode?.label} → {tooltipData.data.targetNode?.label}
              </p>
              <p className="text-sm text-gray-600">
                Flow: {tooltipData.data.value?.toLocaleString()}
              </p>
              <p className="text-sm text-gray-600">
                Conversion: {Math.round((tooltipData.data.value / tooltipData.data.sourceNode?.value) * 100)}%
              </p>
            </div>
          )}
        </TooltipWithBounds>
      )}
    </div>
  );
}

/**
 * Pre-configured Student Journey Sankey
 */
export function StudentJourneySankey({ data, ...props }) {
  const defaultNodes = [
    { id: "visitors", label: "Website Visitors", value: 10000, stage: 0 },
    { id: "inquiries", label: "Inquiries", value: 3500, stage: 1 },
    { id: "registered", label: "Registered", value: 2000, stage: 2 },
    { id: "first_lesson", label: "First Lesson", value: 1800, stage: 3 },
    { id: "active", label: "Active Students", value: 1500, stage: 4 },
    { id: "completed", label: "Completed", value: 1200, stage: 5 },
    { id: "dropout_early", label: "Early Dropout", value: 200, stage: 3, color: "#e44138" },
    { id: "dropout_late", label: "Late Dropout", value: 300, stage: 4, color: "#e44138" },
  ];

  const defaultLinks = [
    { source: "visitors", target: "inquiries", value: 3500 },
    { source: "inquiries", target: "registered", value: 2000 },
    { source: "registered", target: "first_lesson", value: 1800 },
    { source: "first_lesson", target: "active", value: 1500 },
    { source: "first_lesson", target: "dropout_early", value: 200 },
    { source: "active", target: "completed", value: 1200 },
    { source: "active", target: "dropout_late", value: 300 },
  ];

  return (
    <SankeyFlowChart
      nodes={data?.nodes || defaultNodes}
      links={data?.links || defaultLinks}
      title="Student Journey Flow"
      subtitle="From website visitor to course completion"
      {...props}
    />
  );
}

/**
 * Pre-configured Conversion Funnel Sankey
 */
export function ConversionFunnelSankey({ data, ...props }) {
  const defaultNodes = [
    { id: "leads", label: "Leads", value: 5000, stage: 0 },
    { id: "qualified", label: "Qualified", value: 2500, stage: 1 },
    { id: "proposal", label: "Proposal Sent", value: 1500, stage: 2 },
    { id: "negotiation", label: "Negotiation", value: 800, stage: 3 },
    { id: "won", label: "Won", value: 500, stage: 4, color: "#81da5a" },
    { id: "lost", label: "Lost", value: 300, stage: 4, color: "#e44138" },
  ];

  const defaultLinks = [
    { source: "leads", target: "qualified", value: 2500 },
    { source: "qualified", target: "proposal", value: 1500 },
    { source: "proposal", target: "negotiation", value: 800 },
    { source: "negotiation", target: "won", value: 500 },
    { source: "negotiation", target: "lost", value: 300 },
  ];

  return (
    <SankeyFlowChart
      nodes={data?.nodes || defaultNodes}
      links={data?.links || defaultLinks}
      title="Conversion Funnel"
      subtitle="Lead to customer conversion flow"
      {...props}
    />
  );
}