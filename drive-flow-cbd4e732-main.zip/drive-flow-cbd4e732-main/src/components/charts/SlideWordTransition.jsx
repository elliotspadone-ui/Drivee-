import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * SlideWordTransition - Animated text transitions with sliding effects
 * 
 * @param {string|number} text - Text to display and animate
 * @param {string} direction - 'up' | 'down' | 'left' | 'right'
 * @param {number} duration - Animation duration in seconds
 * @param {string} className - Additional CSS classes
 * @param {boolean} inline - Display inline or block
 */
export default function SlideWordTransition({
  text,
  direction = "up",
  duration = 0.35,
  delay = 0,
  className = "",
  inline = false,
  springConfig = { stiffness: 300, damping: 30 }
}) {
  // Direction-based animation variants
  const getVariants = () => {
    const distance = 20;
    const directions = {
      up: { enter: { y: distance }, exit: { y: -distance } },
      down: { enter: { y: -distance }, exit: { y: distance } },
      left: { enter: { x: distance }, exit: { x: -distance } },
      right: { enter: { x: -distance }, exit: { x: distance } }
    };
    
    const dir = directions[direction] || directions.up;
    
    return {
      initial: { ...dir.enter, opacity: 0 },
      animate: { x: 0, y: 0, opacity: 1 },
      exit: { ...dir.exit, opacity: 0 }
    };
  };

  const variants = getVariants();

  return (
    <span className={`relative overflow-hidden ${inline ? "inline-flex" : "flex"}`}>
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.span
          key={text}
          className={className}
          initial="initial"
          animate="animate"
          exit="exit"
          variants={variants}
          transition={{
            type: "spring",
            ...springConfig,
            delay
          }}
        >
          {text}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}

/**
 * SlideNumber - Animated number counter with slide effect
 */
export function SlideNumber({
  value,
  format = "number",
  currency = "€",
  direction = "up",
  duration = 0.35,
  className = "",
  prefix = "",
  suffix = ""
}) {
  const formatValue = (val) => {
    if (format === "currency") return `${currency}${val.toLocaleString()}`;
    if (format === "percentage") return `${val}%`;
    if (format === "decimal") return val.toFixed(1);
    return val.toLocaleString();
  };

  return (
    <span className="inline-flex items-center">
      {prefix && <span>{prefix}</span>}
      <SlideWordTransition
        text={formatValue(value)}
        direction={direction}
        duration={duration}
        className={className}
        inline
      />
      {suffix && <span>{suffix}</span>}
    </span>
  );
}

/**
 * SlideWords - Cycle through array of words
 */
export function SlideWords({
  words = [],
  interval = 2000,
  direction = "up",
  duration = 0.35,
  className = "",
  loop = true,
  paused = false
}) {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (paused || words.length <= 1) return;

    const timer = setInterval(() => {
      setIndex(prev => {
        if (prev >= words.length - 1) {
          return loop ? 0 : prev;
        }
        return prev + 1;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [words.length, interval, loop, paused]);

  if (words.length === 0) return null;

  return (
    <SlideWordTransition
      text={words[index]}
      direction={direction}
      duration={duration}
      className={className}
      inline
    />
  );
}

/**
 * SlideCharacters - Animate each character individually
 */
export function SlideCharacters({
  text,
  direction = "up",
  staggerDelay = 0.03,
  duration = 0.3,
  className = "",
  charClassName = ""
}) {
  const characters = text.split("");
  
  const getVariants = () => {
    const distance = 15;
    const directions = {
      up: { enter: { y: distance }, exit: { y: -distance } },
      down: { enter: { y: -distance }, exit: { y: distance } },
      left: { enter: { x: distance }, exit: { x: -distance } },
      right: { enter: { x: -distance }, exit: { x: distance } }
    };
    
    const dir = directions[direction] || directions.up;
    
    return {
      initial: { ...dir.enter, opacity: 0 },
      animate: { x: 0, y: 0, opacity: 1 },
      exit: { ...dir.exit, opacity: 0 }
    };
  };

  const variants = getVariants();

  return (
    <AnimatePresence mode="popLayout">
      <motion.span key={text} className={`inline-flex ${className}`}>
        {characters.map((char, i) => (
          <motion.span
            key={`${char}-${i}`}
            className={charClassName}
            initial="initial"
            animate="animate"
            exit="exit"
            variants={variants}
            transition={{
              type: "spring",
              stiffness: 300,
              damping: 25,
              delay: i * staggerDelay
            }}
          >
            {char === " " ? "\u00A0" : char}
          </motion.span>
        ))}
      </motion.span>
    </AnimatePresence>
  );
}

/**
 * SlideStatCard - Stat card with animated value transitions
 */
export function SlideStatCard({
  title,
  value,
  previousValue,
  format = "number",
  currency = "€",
  icon: Icon,
  color = "blue",
  direction = "up"
}) {
  const change = previousValue 
    ? ((value - previousValue) / previousValue) * 100 
    : 0;
  const isPositive = change >= 0;

  const colorSchemes = {
    blue: { bg: "bg-[#e8f4fa]", text: "text-[#3b82c4]" },
    green: { bg: "bg-[#eefbe7]", text: "text-[#5cb83a]" },
    purple: { bg: "bg-[#f3e8f4]", text: "text-[#6c376f]" },
    amber: { bg: "bg-[#fdfbe8]", text: "text-[#b8a525]" }
  };
  const scheme = colorSchemes[color] || colorSchemes.blue;

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center gap-3 mb-4">
        {Icon && (
          <div className={`w-10 h-10 ${scheme.bg} rounded-xl flex items-center justify-center`}>
            <Icon className={`w-5 h-5 ${scheme.text}`} />
          </div>
        )}
        <p className="text-sm font-medium text-gray-600">{title}</p>
      </div>
      
      <div className="flex items-end justify-between">
        <div className="text-3xl font-bold text-gray-900">
          <SlideNumber
            value={value}
            format={format}
            currency={currency}
            direction={direction}
          />
        </div>
        
        {previousValue !== undefined && (
          <div className={`flex items-center gap-1 text-sm font-semibold ${
            isPositive ? "text-[#5cb83a]" : "text-[#e44138]"
          }`}>
            <SlideWordTransition
              text={`${isPositive ? "+" : ""}${change.toFixed(1)}%`}
              direction={isPositive ? "up" : "down"}
              className="tabular-nums"
              inline
            />
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * TypewriterSlide - Typewriter effect with slide animations
 */
export function TypewriterSlide({
  texts = [],
  typingSpeed = 80,
  deletingSpeed = 50,
  pauseDuration = 2000,
  className = ""
}) {
  const [currentTextIndex, setCurrentTextIndex] = useState(0);
  const [displayText, setDisplayText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentFullText = texts[currentTextIndex] || "";
    
    const timer = setTimeout(() => {
      if (!isDeleting) {
        if (displayText.length < currentFullText.length) {
          setDisplayText(currentFullText.slice(0, displayText.length + 1));
        } else {
          setTimeout(() => setIsDeleting(true), pauseDuration);
        }
      } else {
        if (displayText.length > 0) {
          setDisplayText(displayText.slice(0, -1));
        } else {
          setIsDeleting(false);
          setCurrentTextIndex((prev) => (prev + 1) % texts.length);
        }
      }
    }, isDeleting ? deletingSpeed : typingSpeed);

    return () => clearTimeout(timer);
  }, [displayText, isDeleting, currentTextIndex, texts, typingSpeed, deletingSpeed, pauseDuration]);

  return (
    <span className={className}>
      {displayText}
      <motion.span
        className="inline-block w-0.5 h-[1em] bg-current ml-0.5 align-middle"
        animate={{ opacity: [1, 0] }}
        transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
      />
    </span>
  );
}