import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title } from 'chart.js';
import { Pie, Bar, Line, Doughnut } from 'react-chartjs-2';
import { motion } from 'framer-motion';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title);

/**
 * Enhanced Pie Chart with animations and custom styling
 */
export function EnhancedPieChart({ data, title, subtitle, colors = ['#3b82c4', '#81da5a', '#e7d356', '#6c376f', '#a9d5ed'] }) {
  const chartData = {
    labels: data.map(d => d.label),
    datasets: [{
      data: data.map(d => d.value),
      backgroundColor: colors,
      borderColor: '#ffffff',
      borderWidth: 2,
      hoverOffset: 10
    }]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          padding: 15,
          font: { size: 12, weight: '600' },
          usePointStyle: true,
          pointStyle: 'circle'
        }
      },
      tooltip: {
        backgroundColor: '#1e293b',
        padding: 12,
        titleFont: { size: 14, weight: 'bold' },
        bodyFont: { size: 13 },
        borderColor: '#e2e8f0',
        borderWidth: 1,
        callbacks: {
          label: (context) => {
            const total = context.dataset.data.reduce((a, b) => a + b, 0);
            const percentage = ((context.parsed / total) * 100).toFixed(1);
            return ` ${context.label}: €${context.parsed.toLocaleString()} (${percentage}%)`;
          }
        }
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
    >
      {title && (
        <div className="mb-4">
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          {subtitle && <p className="text-sm text-gray-600">{subtitle}</p>}
        </div>
      )}
      <div className="h-80">
        <Pie data={chartData} options={options} />
      </div>
    </motion.div>
  );
}

/**
 * Enhanced Bar Chart with animations
 */
export function EnhancedBarChart({ data, title, subtitle, color = '#3b82c4', showGrid = true }) {
  const chartData = {
    labels: data.map(d => d.label),
    datasets: [{
      label: 'Value',
      data: data.map(d => d.value),
      backgroundColor: color,
      borderRadius: 8,
      barThickness: 40
    }]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#1e293b',
        padding: 12,
        titleFont: { size: 14, weight: 'bold' },
        bodyFont: { size: 13 },
        callbacks: {
          label: (context) => ` €${context.parsed.y.toLocaleString()}`
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: { display: showGrid, color: '#f1f5f9' },
        ticks: {
          callback: (value) => `€${value.toLocaleString()}`,
          font: { size: 11, weight: '500' },
          color: '#64748b'
        }
      },
      x: {
        grid: { display: false },
        ticks: {
          font: { size: 11, weight: '500' },
          color: '#64748b'
        }
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
    >
      {title && (
        <div className="mb-4">
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          {subtitle && <p className="text-sm text-gray-600">{subtitle}</p>}
        </div>
      )}
      <div className="h-80">
        <Bar data={chartData} options={options} />
      </div>
    </motion.div>
  );
}

/**
 * Enhanced Line Chart with trend analysis
 */
export function EnhancedLineChart({ data, title, subtitle, colors = ['#3b82c4', '#81da5a'], smooth = true }) {
  const chartData = {
    labels: data.labels,
    datasets: data.datasets.map((dataset, idx) => ({
      label: dataset.label,
      data: dataset.data,
      borderColor: colors[idx % colors.length],
      backgroundColor: colors[idx % colors.length] + '20',
      borderWidth: 3,
      fill: true,
      tension: smooth ? 0.4 : 0,
      pointRadius: 4,
      pointHoverRadius: 6,
      pointBackgroundColor: colors[idx % colors.length],
      pointBorderColor: '#ffffff',
      pointBorderWidth: 2
    }))
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: 'index',
      intersect: false
    },
    plugins: {
      legend: {
        position: 'top',
        labels: {
          padding: 15,
          font: { size: 12, weight: '600' },
          usePointStyle: true,
          pointStyle: 'circle'
        }
      },
      tooltip: {
        backgroundColor: '#1e293b',
        padding: 12,
        titleFont: { size: 14, weight: 'bold' },
        bodyFont: { size: 13 },
        callbacks: {
          label: (context) => ` ${context.dataset.label}: €${context.parsed.y.toLocaleString()}`
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: { color: '#f1f5f9' },
        ticks: {
          callback: (value) => `€${value.toLocaleString()}`,
          font: { size: 11, weight: '500' },
          color: '#64748b'
        }
      },
      x: {
        grid: { display: false },
        ticks: {
          font: { size: 11, weight: '500' },
          color: '#64748b'
        }
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm"
    >
      {title && (
        <div className="mb-4">
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          {subtitle && <p className="text-sm text-gray-600">{subtitle}</p>}
        </div>
      )}
      <div className="h-80">
        <Line data={chartData} options={options} />
      </div>
    </motion.div>
  );
}

/**
 * Doughnut Chart with center metric
 */
export function DoughnutChartWithMetric({ data, centerMetric, title, colors = ['#3b82c4', '#81da5a', '#e7d356', '#6c376f'] }) {
  const chartData = {
    labels: data.map(d => d.label),
    datasets: [{
      data: data.map(d => d.value),
      backgroundColor: colors,
      borderColor: '#ffffff',
      borderWidth: 3,
      hoverOffset: 8
    }]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '70%',
    plugins: {
      legend: {
        position: 'right',
        labels: {
          padding: 20,
          font: { size: 12, weight: '600' },
          usePointStyle: true
        }
      },
      tooltip: {
        backgroundColor: '#1e293b',
        padding: 12,
        callbacks: {
          label: (context) => {
            const total = context.dataset.data.reduce((a, b) => a + b, 0);
            const percentage = ((context.parsed / total) * 100).toFixed(1);
            return ` ${context.label}: ${context.parsed} (${percentage}%)`;
          }
        }
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm relative"
    >
      {title && <h3 className="text-lg font-bold text-gray-900 mb-4">{title}</h3>}
      <div className="h-80 relative">
        <Doughnut data={chartData} options={options} />
        {centerMetric && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center">
              <p className="text-3xl font-bold text-gray-900">{centerMetric.value}</p>
              <p className="text-sm text-gray-600">{centerMetric.label}</p>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}

export default EnhancedPieChart;