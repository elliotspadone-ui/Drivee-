import React, { useState, useMemo, useRef } from "react";
import { scaleTime, scaleLinear } from "@visx/scale";
import { Brush } from "@visx/brush";
import { PatternLines } from "@visx/pattern";
import { Group } from "@visx/group";
import { LinearGradient } from "@visx/gradient";
import { AreaClosed, LinePath, Bar } from "@visx/shape";
import { AxisBottom, AxisLeft } from "@visx/axis";
import { curveMonotoneX } from "@visx/curve";
import { GridRows } from "@visx/grid";
import { localPoint } from "@visx/event";
import { useTooltip, TooltipWithBounds, defaultStyles } from "@visx/tooltip";
import { bisector } from "d3-array";
import { format } from "date-fns";

// Accessors
const getDate = (d) => new Date(d.date);
const getValue = (d) => d.value;
const getSecondaryValue = (d) => d.secondaryValue;
const bisectDate = bisector((d) => new Date(d.date)).left;

// Styling
const GRADIENT_ID = "brush-gradient";
const GRADIENT_ID_SECONDARY = "brush-gradient-secondary";
const PATTERN_ID = "brush-pattern";
const SELECTED_BRUSH_STYLE = {
  fill: `url(#${PATTERN_ID})`,
  stroke: "#3b82c4",
  strokeWidth: 1,
};

const tooltipStyles = {
  ...defaultStyles,
  background: "white",
  border: "1px solid #e2e8f0",
  borderRadius: "12px",
  boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
  padding: "12px",
  fontFamily: "Plus Jakarta Sans, system-ui, sans-serif",
};

/**
 * Brush Timeline Chart - Area chart with brush selection for time range zoom
 * 
 * @param {Array} data - Array of { date: string, value: number, secondaryValue?: number }
 * @param {number} width - Chart width
 * @param {number} height - Chart height (main chart)
 * @param {number} brushHeight - Brush area height
 * @param {string} primaryColor - Primary area color
 * @param {string} secondaryColor - Secondary area color (optional)
 * @param {string} valueLabel - Label for primary value
 * @param {string} secondaryLabel - Label for secondary value
 * @param {Function} onBrushChange - Callback when brush selection changes
 * @param {string} dateFormat - Date format string
 * @param {string} currency - Currency symbol for formatting
 */
export default function BrushTimelineChart({
  data = [],
  width = 800,
  height = 400,
  brushHeight = 80,
  margin = { top: 20, right: 20, bottom: 20, left: 60 },
  brushMargin = { top: 10, right: 20, bottom: 20, left: 60 },
  primaryColor = "#3b82c4",
  secondaryColor = "#81da5a",
  valueLabel = "Value",
  secondaryLabel = "Secondary",
  onBrushChange,
  dateFormat = "MMM d",
  currency = "€",
  showSecondary = false,
  title,
  subtitle
}) {
  const brushRef = useRef(null);
  const [filteredData, setFilteredData] = useState(data);

  const {
    tooltipData,
    tooltipLeft,
    tooltipTop,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip();

  // Dimensions
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;
  const brushInnerWidth = width - brushMargin.left - brushMargin.right;
  const brushInnerHeight = brushHeight - brushMargin.top - brushMargin.bottom;

  // Bounds
  const xMax = Math.max(innerWidth, 0);
  const yMax = Math.max(innerHeight, 0);
  const xBrushMax = Math.max(brushInnerWidth, 0);
  const yBrushMax = Math.max(brushInnerHeight, 0);

  // Scales for main chart
  const dateScale = useMemo(
    () =>
      scaleTime({
        range: [0, xMax],
        domain: filteredData.length > 0 
          ? [Math.min(...filteredData.map(getDate)), Math.max(...filteredData.map(getDate))]
          : [new Date(), new Date()],
      }),
    [xMax, filteredData]
  );

  const valueScale = useMemo(
    () =>
      scaleLinear({
        range: [yMax, 0],
        domain: [0, Math.max(...filteredData.map(getValue), ...filteredData.map(d => getSecondaryValue(d) || 0)) * 1.1 || 100],
        nice: true,
      }),
    [yMax, filteredData]
  );

  // Scales for brush chart
  const brushDateScale = useMemo(
    () =>
      scaleTime({
        range: [0, xBrushMax],
        domain: data.length > 0
          ? [Math.min(...data.map(getDate)), Math.max(...data.map(getDate))]
          : [new Date(), new Date()],
      }),
    [xBrushMax, data]
  );

  const brushValueScale = useMemo(
    () =>
      scaleLinear({
        range: [yBrushMax, 0],
        domain: [0, Math.max(...data.map(getValue)) * 1.1 || 100],
        nice: true,
      }),
    [yBrushMax, data]
  );

  // Initial brush position
  const initialBrushPosition = useMemo(
    () => {
      if (data.length === 0) return null;
      const dates = data.map(getDate);
      const startDate = new Date(Math.min(...dates));
      const endDate = new Date(Math.max(...dates));
      return {
        start: { x: brushDateScale(startDate) },
        end: { x: brushDateScale(endDate) },
      };
    },
    [brushDateScale, data]
  );

  // Handle brush change
  const onBrushChangeHandler = (domain) => {
    if (!domain) {
      setFilteredData(data);
      onBrushChange?.(null);
      return;
    }
    
    const { x0, x1 } = domain;
    const filtered = data.filter((d) => {
      const date = getDate(d);
      return date >= x0 && date <= x1;
    });
    
    setFilteredData(filtered.length > 0 ? filtered : data);
    onBrushChange?.({ start: x0, end: x1 });
  };

  // Handle tooltip
  const handleTooltip = (event) => {
    if (filteredData.length === 0) return;
    
    const { x } = localPoint(event) || { x: 0 };
    const x0 = dateScale.invert(x - margin.left);
    const index = bisectDate(filteredData, x0, 1);
    const d0 = filteredData[index - 1];
    const d1 = filteredData[index];
    
    let d = d0;
    if (d1 && getDate(d1)) {
      d = x0 - getDate(d0) > getDate(d1) - x0 ? d1 : d0;
    }
    
    if (d) {
      showTooltip({
        tooltipData: d,
        tooltipLeft: dateScale(getDate(d)) + margin.left,
        tooltipTop: valueScale(getValue(d)) + margin.top,
      });
    }
  };

  // Reset brush
  const handleClearBrush = () => {
    if (brushRef.current) {
      setFilteredData(data);
      brushRef.current.reset();
    }
  };

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-50 rounded-2xl border border-gray-200">
        <p className="text-gray-500">No data available</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6">
      {/* Header */}
      {(title || subtitle) && (
        <div className="mb-6 flex items-center justify-between">
          <div>
            {title && <h3 className="text-lg font-bold text-gray-900">{title}</h3>}
            {subtitle && <p className="text-sm text-gray-600">{subtitle}</p>}
          </div>
          <button
            onClick={handleClearBrush}
            className="px-3 py-1.5 text-xs font-semibold text-[#3b82c4] bg-[#e8f4fa] hover:bg-[#d4eaf5] rounded-lg transition-colors"
          >
            Reset Zoom
          </button>
        </div>
      )}

      {/* Legend */}
      <div className="flex items-center gap-6 mb-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: primaryColor }} />
          <span className="text-sm text-gray-600">{valueLabel}</span>
        </div>
        {showSecondary && (
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: secondaryColor }} />
            <span className="text-sm text-gray-600">{secondaryLabel}</span>
          </div>
        )}
      </div>

      {/* Main Chart */}
      <svg width={width} height={height + brushHeight + 40}>
        <LinearGradient
          id={GRADIENT_ID}
          from={primaryColor}
          fromOpacity={0.4}
          to={primaryColor}
          toOpacity={0.05}
        />
        <LinearGradient
          id={GRADIENT_ID_SECONDARY}
          from={secondaryColor}
          fromOpacity={0.4}
          to={secondaryColor}
          toOpacity={0.05}
        />
        <PatternLines
          id={PATTERN_ID}
          height={8}
          width={8}
          stroke={primaryColor}
          strokeWidth={1}
          orientation={["diagonal"]}
        />

        {/* Main chart group */}
        <Group left={margin.left} top={margin.top}>
          {/* Grid */}
          <GridRows
            scale={valueScale}
            width={xMax}
            strokeDasharray="3,3"
            stroke="#e2e8f0"
            strokeOpacity={0.8}
          />

          {/* Secondary Area */}
          {showSecondary && (
            <AreaClosed
              data={filteredData.filter(d => getSecondaryValue(d) !== undefined)}
              x={(d) => dateScale(getDate(d))}
              y={(d) => valueScale(getSecondaryValue(d) || 0)}
              yScale={valueScale}
              curve={curveMonotoneX}
              fill={`url(#${GRADIENT_ID_SECONDARY})`}
              strokeWidth={0}
            />
          )}
          {showSecondary && (
            <LinePath
              data={filteredData.filter(d => getSecondaryValue(d) !== undefined)}
              x={(d) => dateScale(getDate(d))}
              y={(d) => valueScale(getSecondaryValue(d) || 0)}
              curve={curveMonotoneX}
              stroke={secondaryColor}
              strokeWidth={2}
              strokeOpacity={0.8}
            />
          )}

          {/* Primary Area */}
          <AreaClosed
            data={filteredData}
            x={(d) => dateScale(getDate(d))}
            y={(d) => valueScale(getValue(d))}
            yScale={valueScale}
            curve={curveMonotoneX}
            fill={`url(#${GRADIENT_ID})`}
            strokeWidth={0}
          />

          {/* Primary Line */}
          <LinePath
            data={filteredData}
            x={(d) => dateScale(getDate(d))}
            y={(d) => valueScale(getValue(d))}
            curve={curveMonotoneX}
            stroke={primaryColor}
            strokeWidth={2.5}
          />

          {/* Axes */}
          <AxisBottom
            top={yMax}
            scale={dateScale}
            tickFormat={(d) => format(d, dateFormat)}
            stroke="#e2e8f0"
            tickStroke="#e2e8f0"
            tickLabelProps={() => ({
              fill: "#64748b",
              fontSize: 11,
              fontFamily: "Plus Jakarta Sans, system-ui, sans-serif",
              textAnchor: "middle",
            })}
            numTicks={Math.min(6, filteredData.length)}
          />
          <AxisLeft
            scale={valueScale}
            stroke="#e2e8f0"
            tickStroke="#e2e8f0"
            tickFormat={(v) => `${currency}${v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v}`}
            tickLabelProps={() => ({
              fill: "#64748b",
              fontSize: 11,
              fontFamily: "Plus Jakarta Sans, system-ui, sans-serif",
              textAnchor: "end",
              dx: -4,
              dy: 4,
            })}
            numTicks={5}
          />

          {/* Tooltip overlay */}
          <Bar
            x={0}
            y={0}
            width={xMax}
            height={yMax}
            fill="transparent"
            onMouseMove={handleTooltip}
            onMouseLeave={hideTooltip}
            onTouchStart={handleTooltip}
            onTouchMove={handleTooltip}
          />

          {/* Tooltip indicator */}
          {tooltipData && (
            <>
              <circle
                cx={dateScale(getDate(tooltipData))}
                cy={valueScale(getValue(tooltipData))}
                r={6}
                fill={primaryColor}
                stroke="white"
                strokeWidth={2}
                pointerEvents="none"
              />
              <line
                x1={dateScale(getDate(tooltipData))}
                y1={0}
                x2={dateScale(getDate(tooltipData))}
                y2={yMax}
                stroke={primaryColor}
                strokeWidth={1}
                strokeDasharray="4,4"
                strokeOpacity={0.5}
                pointerEvents="none"
              />
            </>
          )}
        </Group>

        {/* Brush section label */}
        <text
          x={margin.left}
          y={height + 30}
          fill="#64748b"
          fontSize={11}
          fontFamily="Plus Jakarta Sans, system-ui, sans-serif"
        >
          Drag to zoom • Double-click to reset
        </text>

        {/* Brush chart group */}
        <Group left={brushMargin.left} top={height + 40}>
          {/* Brush background area */}
          <AreaClosed
            data={data}
            x={(d) => brushDateScale(getDate(d))}
            y={(d) => brushValueScale(getValue(d))}
            yScale={brushValueScale}
            curve={curveMonotoneX}
            fill={`${primaryColor}30`}
            strokeWidth={0}
          />
          <LinePath
            data={data}
            x={(d) => brushDateScale(getDate(d))}
            y={(d) => brushValueScale(getValue(d))}
            curve={curveMonotoneX}
            stroke={primaryColor}
            strokeWidth={1.5}
            strokeOpacity={0.6}
          />

          {/* Brush component */}
          <Brush
            innerRef={brushRef}
            xScale={brushDateScale}
            yScale={brushValueScale}
            width={xBrushMax}
            height={yBrushMax}
            margin={brushMargin}
            handleSize={8}
            resizeTriggerAreas={["left", "right"]}
            brushDirection="horizontal"
            initialBrushPosition={initialBrushPosition}
            onChange={onBrushChangeHandler}
            onClick={handleClearBrush}
            selectedBoxStyle={SELECTED_BRUSH_STYLE}
            useWindowMoveEvents
            renderBrushHandle={(props) => <BrushHandle {...props} />}
          />
        </Group>
      </svg>

      {/* Tooltip */}
      {tooltipOpen && tooltipData && (
        <TooltipWithBounds
          top={tooltipTop}
          left={tooltipLeft}
          style={tooltipStyles}
        >
          <div className="space-y-1">
            <p className="text-xs font-semibold text-gray-600">
              {format(getDate(tooltipData), "MMM d, yyyy")}
            </p>
            <p className="text-sm font-bold text-gray-900">
              {valueLabel}: {currency}{getValue(tooltipData).toLocaleString()}
            </p>
            {showSecondary && getSecondaryValue(tooltipData) !== undefined && (
              <p className="text-sm font-medium" style={{ color: secondaryColor }}>
                {secondaryLabel}: {currency}{getSecondaryValue(tooltipData).toLocaleString()}
              </p>
            )}
          </div>
        </TooltipWithBounds>
      )}
    </div>
  );
}

// Custom brush handle component
function BrushHandle({ x, height, isBrushActive }) {
  const pathWidth = 8;
  const pathHeight = 15;
  
  if (!isBrushActive) return null;
  
  return (
    <Group left={x - pathWidth / 2} top={(height - pathHeight) / 2}>
      <rect
        fill="#fff"
        stroke="#3b82c4"
        strokeWidth={1}
        width={pathWidth}
        height={pathHeight}
        rx={4}
        style={{ cursor: "ew-resize" }}
      />
      <line
        x1={pathWidth / 2}
        y1={4}
        x2={pathWidth / 2}
        y2={pathHeight - 4}
        stroke="#3b82c4"
        strokeWidth={1.5}
        strokeLinecap="round"
      />
    </Group>
  );
}

/**
 * Responsive wrapper for BrushTimelineChart
 */
export function ResponsiveBrushTimeline(props) {
  const containerRef = useRef(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 400 });

  React.useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.offsetWidth,
          height: props.height || 400
        });
      }
    };

    updateDimensions();
    window.addEventListener("resize", updateDimensions);
    return () => window.removeEventListener("resize", updateDimensions);
  }, [props.height]);

  return (
    <div ref={containerRef} className="w-full">
      <BrushTimelineChart
        {...props}
        width={dimensions.width}
        height={dimensions.height}
      />
    </div>
  );
}