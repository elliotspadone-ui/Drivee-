import React, { useRef, useEffect } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from "chart.js";
import { Chart } from "react-chartjs-2";

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

/**
 * Sales vs Targets Mixed Chart
 * Combines bar chart (actual sales) with line chart (targets)
 * 
 * @param {Array} labels - X-axis labels (e.g., months)
 * @param {Array} salesData - Actual sales values
 * @param {Array} targetData - Target values
 * @param {Array} previousPeriodData - Previous period comparison (optional)
 * @param {string} currency - Currency symbol
 * @param {string} title - Chart title
 * @param {Function} onBarClick - Click handler for bars
 */
export default function SalesTargetChart({
  labels = [],
  salesData = [],
  targetData = [],
  previousPeriodData = [],
  currency = "€",
  title = "Sales vs Targets",
  subtitle = "Monthly performance overview",
  onBarClick,
  height = 400,
  showPreviousPeriod = false,
  showForecast = false,
  forecastData = []
}) {
  const chartRef = useRef(null);

  // Calculate achievement percentages
  const achievements = salesData.map((sales, i) => 
    targetData[i] ? Math.round((sales / targetData[i]) * 100) : 0
  );

  // Gradient for bars
  const getGradient = (ctx, chartArea, colorStart, colorEnd) => {
    if (!chartArea) return colorStart;
    const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
    gradient.addColorStop(0, colorStart);
    gradient.addColorStop(1, colorEnd);
    return gradient;
  };

  const data = {
    labels,
    datasets: [
      // Actual Sales (Bar)
      {
        type: "bar",
        label: "Actual Sales",
        data: salesData,
        backgroundColor: (context) => {
          const chart = context.chart;
          const { ctx, chartArea } = chart;
          if (!chartArea) return "#3b82c4";
          return getGradient(ctx, chartArea, "#a9d5ed", "#3b82c4");
        },
        borderColor: "#3b82c4",
        borderWidth: 0,
        borderRadius: 8,
        borderSkipped: false,
        barPercentage: 0.6,
        categoryPercentage: 0.7,
        order: 2
      },
      // Target Line
      {
        type: "line",
        label: "Target",
        data: targetData,
        borderColor: "#e44138",
        backgroundColor: "rgba(228, 65, 56, 0.1)",
        borderWidth: 3,
        borderDash: [8, 4],
        pointBackgroundColor: "#e44138",
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
        pointRadius: 6,
        pointHoverRadius: 8,
        tension: 0.3,
        fill: false,
        order: 1
      },
      // Previous Period (optional)
      ...(showPreviousPeriod && previousPeriodData.length > 0 ? [{
        type: "bar",
        label: "Previous Period",
        data: previousPeriodData,
        backgroundColor: "rgba(148, 163, 184, 0.5)",
        borderColor: "#94a3b8",
        borderWidth: 0,
        borderRadius: 8,
        borderSkipped: false,
        barPercentage: 0.6,
        categoryPercentage: 0.7,
        order: 3
      }] : []),
      // Forecast (optional)
      ...(showForecast && forecastData.length > 0 ? [{
        type: "line",
        label: "Forecast",
        data: forecastData,
        borderColor: "#81da5a",
        backgroundColor: "rgba(129, 218, 90, 0.1)",
        borderWidth: 2,
        borderDash: [4, 4],
        pointBackgroundColor: "#81da5a",
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
        tension: 0.4,
        fill: true,
        order: 0
      }] : [])
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: "index",
      intersect: false
    },
    plugins: {
      legend: {
        position: "top",
        align: "end",
        labels: {
          usePointStyle: true,
          pointStyle: "circle",
          padding: 20,
          font: {
            family: "Plus Jakarta Sans, system-ui, sans-serif",
            size: 12,
            weight: "600"
          },
          color: "#64748b"
        }
      },
      title: {
        display: false
      },
      tooltip: {
        backgroundColor: "white",
        titleColor: "#1e293b",
        bodyColor: "#475569",
        borderColor: "#e2e8f0",
        borderWidth: 1,
        cornerRadius: 12,
        padding: 16,
        boxPadding: 6,
        usePointStyle: true,
        titleFont: {
          family: "Plus Jakarta Sans, system-ui, sans-serif",
          size: 14,
          weight: "700"
        },
        bodyFont: {
          family: "Plus Jakarta Sans, system-ui, sans-serif",
          size: 13
        },
        callbacks: {
          title: (items) => items[0]?.label || "",
          label: (context) => {
            const value = context.parsed.y;
            const label = context.dataset.label;
            return `${label}: ${currency}${value.toLocaleString()}`;
          },
          afterBody: (items) => {
            const index = items[0]?.dataIndex;
            if (index !== undefined && achievements[index]) {
              const achievement = achievements[index];
              const status = achievement >= 100 ? "✓ Target Met" : "○ Below Target";
              return [`\nAchievement: ${achievement}%`, status];
            }
            return [];
          }
        }
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            family: "Plus Jakarta Sans, system-ui, sans-serif",
            size: 12,
            weight: "500"
          },
          color: "#64748b"
        },
        border: {
          display: false
        }
      },
      y: {
        beginAtZero: true,
        grid: {
          color: "#f1f5f9",
          drawBorder: false
        },
        ticks: {
          font: {
            family: "Plus Jakarta Sans, system-ui, sans-serif",
            size: 11
          },
          color: "#94a3b8",
          callback: (value) => `${currency}${value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}`
        },
        border: {
          display: false
        }
      }
    },
    onClick: (event, elements) => {
      if (elements.length > 0 && onBarClick) {
        const index = elements[0].index;
        onBarClick({
          label: labels[index],
          sales: salesData[index],
          target: targetData[index],
          achievement: achievements[index],
          index
        });
      }
    }
  };

  // Summary stats
  const totalSales = salesData.reduce((a, b) => a + b, 0);
  const totalTarget = targetData.reduce((a, b) => a + b, 0);
  const overallAchievement = totalTarget > 0 ? Math.round((totalSales / totalTarget) * 100) : 0;
  const monthsOnTarget = achievements.filter(a => a >= 100).length;

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
        <div>
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          <p className="text-sm text-gray-600">{subtitle}</p>
        </div>

        {/* Summary Stats */}
        <div className="flex flex-wrap gap-4">
          <div className="px-4 py-2 bg-[#e8f4fa] rounded-xl">
            <p className="text-xs text-gray-600 mb-0.5">Total Sales</p>
            <p className="text-lg font-bold text-[#3b82c4]">
              {currency}{totalSales.toLocaleString()}
            </p>
          </div>
          <div className="px-4 py-2 bg-[#fdeeed] rounded-xl">
            <p className="text-xs text-gray-600 mb-0.5">Total Target</p>
            <p className="text-lg font-bold text-[#e44138]">
              {currency}{totalTarget.toLocaleString()}
            </p>
          </div>
          <div className={`px-4 py-2 rounded-xl ${
            overallAchievement >= 100 ? "bg-[#eefbe7]" : "bg-[#fdfbe8]"
          }`}>
            <p className="text-xs text-gray-600 mb-0.5">Achievement</p>
            <p className={`text-lg font-bold ${
              overallAchievement >= 100 ? "text-[#5cb83a]" : "text-[#b8a525]"
            }`}>
              {overallAchievement}%
            </p>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div style={{ height }}>
        <Chart ref={chartRef} type="bar" data={data} options={options} />
      </div>

      {/* Achievement Indicators */}
      <div className="mt-6 pt-4 border-t border-gray-100">
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm font-semibold text-gray-700">Monthly Achievement</p>
          <p className="text-xs text-gray-500">
            {monthsOnTarget} of {labels.length} months on target
          </p>
        </div>
        <div className="flex gap-1.5">
          {achievements.map((achievement, i) => (
            <div
              key={i}
              className="flex-1 group relative"
            >
              <div
                className={`h-2 rounded-full transition-all ${
                  achievement >= 100
                    ? "bg-[#81da5a]"
                    : achievement >= 80
                    ? "bg-[#e7d356]"
                    : "bg-[#e44138]"
                }`}
              />
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                <div className="bg-gray-900 text-white text-xs rounded-lg px-2 py-1 whitespace-nowrap">
                  {labels[i]}: {achievement}%
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center gap-6 mt-3">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-[#81da5a]" />
            <span className="text-xs text-gray-500">≥100%</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-[#e7d356]" />
            <span className="text-xs text-gray-500">80-99%</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-[#e44138]" />
            <span className="text-xs text-gray-500">&lt;80%</span>
          </div>
        </div>
      </div>
    </div>
  );
}