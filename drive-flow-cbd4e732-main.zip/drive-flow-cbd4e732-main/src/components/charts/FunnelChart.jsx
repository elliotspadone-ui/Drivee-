import React, { useState } from "react";
import {
  FunnelChart as RechartsFunnel,
  Funnel,
  LabelList,
  Tooltip,
  Cell,
  ResponsiveContainer
} from "recharts";
import { motion, AnimatePresence } from "framer-motion";
import { TrendingDown, TrendingUp, Users, Target, ArrowRight } from "lucide-react";

// Default color palette
const COLORS = ["#3b82c4", "#6c376f", "#81da5a", "#e7d356", "#5cb83a", "#a9d5ed"];

/**
 * Funnel Chart - Visualizes conversion funnels with stage-by-stage breakdown
 * 
 * @param {Array} data - Array of { name, value, fill?, conversionRate? }
 * @param {string} title - Chart title
 * @param {string} subtitle - Chart subtitle
 * @param {boolean} showConversionRates - Show conversion rates between stages
 * @param {boolean} showPercentages - Show percentage of initial value
 * @param {boolean} animated - Enable animations
 * @param {Function} onStageClick - Click handler for stages
 */
export default function FunnelChart({
  data = [],
  title = "Conversion Funnel",
  subtitle = "Stage-by-stage breakdown",
  showConversionRates = true,
  showPercentages = true,
  animated = true,
  onStageClick,
  height = 400,
  colors = COLORS
}) {
  const [activeIndex, setActiveIndex] = useState(null);

  // Calculate conversion rates and percentages
  const enrichedData = data.map((item, index) => {
    const initialValue = data[0]?.value || 1;
    const previousValue = index > 0 ? data[index - 1].value : item.value;
    const conversionRate = previousValue > 0 
      ? Math.round((item.value / previousValue) * 100) 
      : 100;
    const percentOfInitial = Math.round((item.value / initialValue) * 100);
    
    return {
      ...item,
      fill: item.fill || colors[index % colors.length],
      conversionRate,
      percentOfInitial,
      dropoff: index > 0 ? previousValue - item.value : 0,
      dropoffRate: index > 0 ? Math.round(((previousValue - item.value) / previousValue) * 100) : 0
    };
  });

  // Summary stats
  const totalConversion = data.length > 1 && data[0].value > 0
    ? Math.round((data[data.length - 1].value / data[0].value) * 100)
    : 100;
  const totalDropoff = data.length > 0 ? data[0].value - data[data.length - 1].value : 0;
  const biggestDropoffStage = enrichedData.reduce((max, item, idx) => 
    idx > 0 && item.dropoff > (max?.dropoff || 0) ? item : max, null
  );

  // Custom tooltip
  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload || !payload.length) return null;
    
    const item = payload[0].payload;
    return (
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-4 min-w-[200px]">
        <p className="text-sm font-bold text-gray-900 mb-2">{item.name}</p>
        <div className="space-y-1.5">
          <div className="flex justify-between">
            <span className="text-sm text-gray-600">Value:</span>
            <span className="text-sm font-semibold text-gray-900">{item.value.toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-gray-600">% of Total:</span>
            <span className="text-sm font-semibold text-gray-900">{item.percentOfInitial}%</span>
          </div>
          {item.dropoff > 0 && (
            <>
              <div className="border-t border-gray-100 pt-1.5 mt-1.5">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Dropoff:</span>
                  <span className="text-sm font-semibold text-[#e44138]">-{item.dropoff.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Conversion:</span>
                  <span className="text-sm font-semibold text-[#5cb83a]">{item.conversionRate}%</span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    );
  };

  // Custom label renderer
  const renderCustomLabel = (props) => {
    const { x, y, width, height, value, name, index } = props;
    const item = enrichedData[index];
    
    return (
      <g>
        <text
          x={x + width / 2}
          y={y + height / 2 - 8}
          textAnchor="middle"
          dominantBaseline="middle"
          fill="white"
          fontSize={14}
          fontWeight={700}
          fontFamily="Plus Jakarta Sans, system-ui, sans-serif"
        >
          {value.toLocaleString()}
        </text>
        {showPercentages && (
          <text
            x={x + width / 2}
            y={y + height / 2 + 12}
            textAnchor="middle"
            dominantBaseline="middle"
            fill="rgba(255,255,255,0.8)"
            fontSize={11}
            fontFamily="Plus Jakarta Sans, system-ui, sans-serif"
          >
            {item.percentOfInitial}% of total
          </text>
        )}
      </g>
    );
  };

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-50 rounded-2xl border border-gray-200">
        <p className="text-gray-500">No funnel data available</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
        <div>
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          <p className="text-sm text-gray-600">{subtitle}</p>
        </div>

        {/* Summary Stats */}
        <div className="flex flex-wrap gap-3">
          <div className="px-4 py-2 bg-[#e8f4fa] rounded-xl">
            <p className="text-xs text-gray-600 mb-0.5">Total Conversion</p>
            <p className="text-lg font-bold text-[#3b82c4]">{totalConversion}%</p>
          </div>
          <div className="px-4 py-2 bg-[#fdeeed] rounded-xl">
            <p className="text-xs text-gray-600 mb-0.5">Total Dropoff</p>
            <p className="text-lg font-bold text-[#e44138]">{totalDropoff.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Funnel Chart */}
      <div style={{ height }}>
        <ResponsiveContainer width="100%" height="100%">
          <RechartsFunnel>
            <Tooltip content={<CustomTooltip />} />
            <Funnel
              dataKey="value"
              data={enrichedData}
              isAnimationActive={animated}
              animationDuration={800}
              animationEasing="ease-out"
              onClick={(data, index) => onStageClick?.(data, index)}
            >
              {enrichedData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.fill}
                  stroke={activeIndex === index ? "#1e293b" : "transparent"}
                  strokeWidth={2}
                  style={{ cursor: onStageClick ? "pointer" : "default" }}
                  onMouseEnter={() => setActiveIndex(index)}
                  onMouseLeave={() => setActiveIndex(null)}
                />
              ))}
              <LabelList
                dataKey="name"
                position="right"
                fill="#374151"
                fontSize={13}
                fontWeight={600}
                fontFamily="Plus Jakarta Sans, system-ui, sans-serif"
                offset={16}
              />
              <LabelList
                dataKey="value"
                position="center"
                content={renderCustomLabel}
              />
            </Funnel>
          </RechartsFunnel>
        </ResponsiveContainer>
      </div>

      {/* Conversion Rates Between Stages */}
      {showConversionRates && enrichedData.length > 1 && (
        <div className="mt-6 pt-4 border-t border-gray-100">
          <p className="text-sm font-semibold text-gray-700 mb-3">Stage Conversion Rates</p>
          <div className="flex flex-wrap items-center gap-2">
            {enrichedData.map((item, index) => (
              <React.Fragment key={index}>
                <div 
                  className={`px-3 py-2 rounded-lg border-2 transition-all ${
                    activeIndex === index 
                      ? "border-gray-400 bg-gray-50" 
                      : "border-gray-200 bg-white"
                  }`}
                >
                  <p className="text-xs text-gray-500 mb-0.5">{item.name}</p>
                  <p className="text-sm font-bold text-gray-900">{item.value.toLocaleString()}</p>
                </div>
                {index < enrichedData.length - 1 && (
                  <div className="flex flex-col items-center px-2">
                    <ArrowRight className="w-4 h-4 text-gray-400" />
                    <span className={`text-xs font-bold ${
                      enrichedData[index + 1].conversionRate >= 70 
                        ? "text-[#5cb83a]" 
                        : enrichedData[index + 1].conversionRate >= 50 
                        ? "text-[#e7d356]" 
                        : "text-[#e44138]"
                    }`}>
                      {enrichedData[index + 1].conversionRate}%
                    </span>
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      )}

      {/* Biggest Dropoff Insight */}
      {biggestDropoffStage && biggestDropoffStage.dropoff > 0 && (
        <div className="mt-4 p-4 bg-[#fdfbe8] border border-[#f9f3c8] rounded-xl">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-[#e7d356] rounded-lg flex items-center justify-center flex-shrink-0">
              <TrendingDown className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-900">Biggest Dropoff Point</p>
              <p className="text-sm text-gray-600 mt-0.5">
                <strong>{biggestDropoffStage.name}</strong> has the highest dropoff with{" "}
                <span className="text-[#e44138] font-semibold">
                  {biggestDropoffStage.dropoff.toLocaleString()} ({biggestDropoffStage.dropoffRate}%)
                </span>{" "}
                lost from the previous stage.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * Pre-configured Student Enrollment Funnel
 */
export function StudentEnrollmentFunnel({ data, ...props }) {
  const defaultData = [
    { name: "Website Visits", value: 10000 },
    { name: "Inquiries", value: 3500 },
    { name: "Trial Booked", value: 2000 },
    { name: "Trial Completed", value: 1600 },
    { name: "Enrolled", value: 1200 },
  ];

  return (
    <FunnelChart
      data={data || defaultData}
      title="Student Enrollment Funnel"
      subtitle="From website visit to enrollment"
      {...props}
    />
  );
}

/**
 * Pre-configured Lesson Completion Funnel
 */
export function LessonCompletionFunnel({ data, ...props }) {
  const defaultData = [
    { name: "Enrolled", value: 500, fill: "#3b82c4" },
    { name: "Started Lessons", value: 480, fill: "#6c376f" },
    { name: "50% Complete", value: 400, fill: "#e7d356" },
    { name: "Theory Passed", value: 350, fill: "#81da5a" },
    { name: "Practical Passed", value: 300, fill: "#5cb83a" },
  ];

  return (
    <FunnelChart
      data={data || defaultData}
      title="Lesson Completion Funnel"
      subtitle="Student progress through the program"
      {...props}
    />
  );
}

/**
 * Pre-configured Sales Funnel
 */
export function SalesFunnel({ data, ...props }) {
  const defaultData = [
    { name: "Leads", value: 5000, fill: "#3b82c4" },
    { name: "Qualified", value: 2500, fill: "#a9d5ed" },
    { name: "Proposal", value: 1200, fill: "#6c376f" },
    { name: "Negotiation", value: 600, fill: "#e7d356" },
    { name: "Closed Won", value: 400, fill: "#5cb83a" },
  ];

  return (
    <FunnelChart
      data={data || defaultData}
      title="Sales Funnel"
      subtitle="Lead to customer conversion"
      {...props}
    />
  );
}