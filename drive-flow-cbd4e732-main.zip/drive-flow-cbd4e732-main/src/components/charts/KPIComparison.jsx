import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  ArrowRight,
  Calendar,
  ChevronDown,
  Info
} from "lucide-react";

/**
 * KPI Comparison Card - Period-over-period metrics with animations
 * 
 * @param {string} title - KPI title
 * @param {number} currentValue - Current period value
 * @param {number} previousValue - Previous period value
 * @param {string} currentLabel - Label for current period
 * @param {string} previousLabel - Label for previous period
 * @param {string} format - 'number' | 'currency' | 'percentage'
 * @param {string} currency - Currency symbol
 * @param {React.Component} icon - Icon component
 * @param {string} color - 'blue' | 'green' | 'purple' | 'amber'
 */
export function KPIComparisonCard({
  title,
  currentValue,
  previousValue,
  currentLabel = "This Period",
  previousLabel = "Last Period",
  format = "number",
  currency = "€",
  icon: Icon,
  color = "blue",
  description,
  onClick
}) {
  const [isHovered, setIsHovered] = useState(false);

  // Calculate change
  const change = previousValue > 0 
    ? ((currentValue - previousValue) / previousValue) * 100 
    : currentValue > 0 ? 100 : 0;
  const isPositive = change > 0;
  const isNeutral = change === 0;
  const absoluteChange = Math.abs(currentValue - previousValue);

  // Format value
  const formatValue = (value) => {
    if (format === "currency") return `${currency}${value.toLocaleString()}`;
    if (format === "percentage") return `${value.toFixed(1)}%`;
    return value.toLocaleString();
  };

  // Color schemes
  const colorSchemes = {
    blue: { bg: "bg-[#e8f4fa]", text: "text-[#3b82c4]", gradient: "from-[#3b82c4] to-[#a9d5ed]" },
    green: { bg: "bg-[#eefbe7]", text: "text-[#5cb83a]", gradient: "from-[#81da5a] to-[#5cb83a]" },
    purple: { bg: "bg-[#f3e8f4]", text: "text-[#6c376f]", gradient: "from-[#6c376f] to-[#9b5b9e]" },
    amber: { bg: "bg-[#fdfbe8]", text: "text-[#b8a525]", gradient: "from-[#e7d356] to-[#b8a525]" }
  };
  const scheme = colorSchemes[color] || colorSchemes.blue;

  return (
    <motion.div
      className="bg-white rounded-2xl border border-gray-200 p-6 cursor-pointer overflow-hidden relative"
      whileHover={{ y: -4, boxShadow: "0 12px 24px -8px rgba(0,0,0,0.1)" }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={onClick}
      layout
    >
      {/* Background gradient on hover */}
      <motion.div
        className={`absolute inset-0 bg-gradient-to-br ${scheme.gradient} opacity-0`}
        animate={{ opacity: isHovered ? 0.03 : 0 }}
        transition={{ duration: 0.3 }}
      />

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            {Icon && (
              <motion.div 
                className={`w-12 h-12 ${scheme.bg} rounded-xl flex items-center justify-center`}
                animate={{ scale: isHovered ? 1.1 : 1 }}
                transition={{ type: "spring", stiffness: 400, damping: 17 }}
              >
                <Icon className={`w-6 h-6 ${scheme.text}`} />
              </motion.div>
            )}
            <div>
              <p className="text-sm font-medium text-gray-600">{title}</p>
              {description && (
                <p className="text-xs text-gray-400 mt-0.5">{description}</p>
              )}
            </div>
          </div>

          {/* Change indicator */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${
              isPositive 
                ? "bg-[#eefbe7] text-[#5cb83a]" 
                : isNeutral 
                ? "bg-gray-100 text-gray-500"
                : "bg-[#fdeeed] text-[#e44138]"
            }`}
          >
            {isPositive ? (
              <TrendingUp className="w-3 h-3" />
            ) : isNeutral ? (
              <Minus className="w-3 h-3" />
            ) : (
              <TrendingDown className="w-3 h-3" />
            )}
            <span>{Math.abs(change).toFixed(1)}%</span>
          </motion.div>
        </div>

        {/* Current Value */}
        <motion.div
          className="mb-4"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <motion.p 
            className="text-3xl font-bold text-gray-900"
            key={currentValue}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {formatValue(currentValue)}
          </motion.p>
          <p className="text-xs text-gray-500 mt-1">{currentLabel}</p>
        </motion.div>

        {/* Comparison Bar */}
        <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden mb-3">
          <motion.div
            className={`absolute inset-y-0 left-0 bg-gradient-to-r ${scheme.gradient} rounded-full`}
            initial={{ width: 0 }}
            animate={{ 
              width: `${Math.min((currentValue / Math.max(currentValue, previousValue)) * 100, 100)}%` 
            }}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
          />
          <motion.div
            className="absolute inset-y-0 bg-gray-300 rounded-full"
            style={{ left: `${Math.min((previousValue / Math.max(currentValue, previousValue)) * 100, 100)}%` }}
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 3, opacity: 0.8 }}
            transition={{ delay: 0.5 }}
          />
        </div>

        {/* Previous Value */}
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <span className="text-gray-500">{previousLabel}:</span>
            <span className="font-semibold text-gray-700">{formatValue(previousValue)}</span>
          </div>
          <motion.span
            className={`text-xs font-medium ${
              isPositive ? "text-[#5cb83a]" : isNeutral ? "text-gray-500" : "text-[#e44138]"
            }`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            {isPositive ? "+" : ""}{formatValue(absoluteChange)} {isPositive ? "↑" : isNeutral ? "–" : "↓"}
          </motion.span>
        </div>
      </div>
    </motion.div>
  );
}

/**
 * KPI Comparison Grid - Multiple KPIs in a responsive grid
 */
export function KPIComparisonGrid({ 
  metrics = [],
  columns = 4,
  animated = true
}) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div
      className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-${columns} gap-6`}
      variants={animated ? containerVariants : undefined}
      initial={animated ? "hidden" : undefined}
      animate={animated ? "visible" : undefined}
    >
      {metrics.map((metric, index) => (
        <motion.div key={index} variants={animated ? itemVariants : undefined}>
          <KPIComparisonCard {...metric} />
        </motion.div>
      ))}
    </motion.div>
  );
}

/**
 * Detailed KPI Comparison Panel - Side-by-side period comparison
 */
export function KPIComparisonPanel({
  title = "Period Comparison",
  currentPeriod = { label: "This Month", data: {} },
  previousPeriod = { label: "Last Month", data: {} },
  metrics = [],
  currency = "€"
}) {
  const [selectedMetric, setSelectedMetric] = useState(null);

  // Format value based on type
  const formatValue = (value, type) => {
    if (type === "currency") return `${currency}${value?.toLocaleString() || 0}`;
    if (type === "percentage") return `${value?.toFixed(1) || 0}%`;
    return value?.toLocaleString() || "0";
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-gray-900">{title}</h3>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-[#3b82c4]" />
            <span className="text-gray-600">{currentPeriod.label}</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-gray-300" />
            <span className="text-gray-600">{previousPeriod.label}</span>
          </div>
        </div>
      </div>

      {/* Metrics List */}
      <div className="space-y-4">
        {metrics.map((metric, index) => {
          const currentVal = currentPeriod.data[metric.key] || 0;
          const previousVal = previousPeriod.data[metric.key] || 0;
          const change = previousVal > 0 
            ? ((currentVal - previousVal) / previousVal) * 100 
            : currentVal > 0 ? 100 : 0;
          const isPositive = change > 0;
          const isSelected = selectedMetric === metric.key;
          const maxVal = Math.max(currentVal, previousVal, 1);

          return (
            <motion.div
              key={metric.key}
              className={`p-4 rounded-xl border-2 transition-colors cursor-pointer ${
                isSelected ? "border-[#3b82c4] bg-[#e8f4fa]/30" : "border-gray-100 hover:border-gray-200"
              }`}
              onClick={() => setSelectedMetric(isSelected ? null : metric.key)}
              layout
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  {metric.icon && <metric.icon className="w-4 h-4 text-gray-500" />}
                  <span className="text-sm font-semibold text-gray-700">{metric.label}</span>
                </div>
                <motion.div
                  className={`flex items-center gap-1 text-xs font-bold ${
                    isPositive ? "text-[#5cb83a]" : change === 0 ? "text-gray-500" : "text-[#e44138]"
                  }`}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 500, damping: 25 }}
                >
                  {isPositive ? <TrendingUp className="w-3 h-3" /> : change < 0 ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                  {Math.abs(change).toFixed(1)}%
                </motion.div>
              </div>

              {/* Comparison Bars */}
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="w-20 text-right">
                    <span className="text-sm font-bold text-gray-900">
                      {formatValue(currentVal, metric.type)}
                    </span>
                  </div>
                  <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed] rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${(currentVal / maxVal) * 100}%` }}
                      transition={{ duration: 0.6, ease: "easeOut" }}
                    />
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-20 text-right">
                    <span className="text-sm font-medium text-gray-500">
                      {formatValue(previousVal, metric.type)}
                    </span>
                  </div>
                  <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gray-300 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${(previousVal / maxVal) * 100}%` }}
                      transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
                    />
                  </div>
                </div>
              </div>

              {/* Expanded Details */}
              <AnimatePresence>
                {isSelected && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="mt-4 pt-4 border-t border-gray-100 grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <p className="text-xs text-gray-500 mb-1">Change</p>
                        <p className={`text-sm font-bold ${isPositive ? "text-[#5cb83a]" : "text-[#e44138]"}`}>
                          {isPositive ? "+" : ""}{formatValue(currentVal - previousVal, metric.type)}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-gray-500 mb-1">Growth Rate</p>
                        <p className={`text-sm font-bold ${isPositive ? "text-[#5cb83a]" : "text-[#e44138]"}`}>
                          {isPositive ? "+" : ""}{change.toFixed(1)}%
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-gray-500 mb-1">Trend</p>
                        <p className="text-sm font-bold text-gray-700">
                          {isPositive ? "📈 Up" : change < 0 ? "📉 Down" : "➖ Flat"}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

/**
 * Animated Counter Component
 */
export function AnimatedCounter({ 
  value, 
  duration = 1000, 
  format = "number",
  currency = "€",
  className = ""
}) {
  const [displayValue, setDisplayValue] = React.useState(0);

  React.useEffect(() => {
    let startTime;
    const startValue = displayValue;
    const diff = value - startValue;

    const animate = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // Ease out cubic
      setDisplayValue(startValue + diff * eased);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [value, duration]);

  const formatValue = (val) => {
    const rounded = Math.round(val);
    if (format === "currency") return `${currency}${rounded.toLocaleString()}`;
    if (format === "percentage") return `${val.toFixed(1)}%`;
    return rounded.toLocaleString();
  };

  return <span className={className}>{formatValue(displayValue)}</span>;
}

export default KPIComparisonCard;