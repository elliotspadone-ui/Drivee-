import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Dot
} from "recharts";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Activity, 
  Pause, 
  Play, 
  RefreshCw, 
  TrendingUp, 
  TrendingDown,
  Wifi,
  WifiOff,
  Zap,
  Circle
} from "lucide-react";

/**
 * Live Data Chart - Real-time data visualization with streaming updates
 * 
 * @param {Function} dataFetcher - Async function that returns new data point
 * @param {Array} initialData - Initial dataset
 * @param {number} interval - Update interval in ms (default: 2000)
 * @param {number} maxPoints - Maximum data points to display (default: 20)
 * @param {string} type - 'line' | 'area'
 * @param {string} dataKey - Key for the value in data objects
 * @param {string} xAxisKey - Key for x-axis values
 */
export default function LiveDataChart({
  dataFetcher,
  initialData = [],
  interval = 2000,
  maxPoints = 20,
  type = "area",
  dataKey = "value",
  xAxisKey = "time",
  title = "Live Data",
  subtitle = "Real-time updates",
  unit = "",
  currency = "",
  color = "#3b82c4",
  gradientFrom = "#a9d5ed",
  gradientTo = "#3b82c4",
  showControls = true,
  showStats = true,
  thresholds = { warning: null, danger: null },
  height = 300,
  onDataUpdate
}) {
  const [data, setData] = useState(initialData);
  const [isLive, setIsLive] = useState(true);
  const [isPaused, setIsPaused] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [latestValue, setLatestValue] = useState(null);
  const [previousValue, setPreviousValue] = useState(null);
  const [isConnected, setIsConnected] = useState(true);
  const [updateCount, setUpdateCount] = useState(0);
  const intervalRef = useRef(null);

  // Generate mock data point if no fetcher provided
  const generateMockData = useCallback(() => {
    const lastValue = data.length > 0 ? data[data.length - 1][dataKey] : 50;
    const change = (Math.random() - 0.5) * 20;
    const newValue = Math.max(0, Math.min(100, lastValue + change));
    
    return {
      [xAxisKey]: new Date().toLocaleTimeString('en-US', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
      }),
      [dataKey]: Math.round(newValue * 10) / 10,
      timestamp: Date.now()
    };
  }, [data, dataKey, xAxisKey]);

  // Fetch or generate new data
  const fetchData = useCallback(async () => {
    try {
      setIsConnected(true);
      const newPoint = dataFetcher ? await dataFetcher() : generateMockData();
      
      setData(prevData => {
        const updated = [...prevData, newPoint];
        if (updated.length > maxPoints) {
          return updated.slice(-maxPoints);
        }
        return updated;
      });

      setPreviousValue(latestValue);
      setLatestValue(newPoint[dataKey]);
      setLastUpdate(new Date());
      setUpdateCount(prev => prev + 1);
      onDataUpdate?.(newPoint);
    } catch (error) {
      console.error("Failed to fetch data:", error);
      setIsConnected(false);
    }
  }, [dataFetcher, generateMockData, maxPoints, dataKey, latestValue, onDataUpdate]);

  // Start/stop interval
  useEffect(() => {
    if (isLive && !isPaused) {
      fetchData(); // Initial fetch
      intervalRef.current = setInterval(fetchData, interval);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isLive, isPaused, interval, fetchData]);

  // Calculate stats
  const stats = React.useMemo(() => {
    if (data.length === 0) return { min: 0, max: 0, avg: 0, trend: 0 };
    
    const values = data.map(d => d[dataKey]).filter(v => typeof v === 'number');
    const min = Math.min(...values);
    const max = Math.max(...values);
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    
    // Calculate trend (last 5 points)
    const recent = values.slice(-5);
    const trend = recent.length > 1 
      ? ((recent[recent.length - 1] - recent[0]) / recent[0]) * 100 
      : 0;

    return { min, max, avg, trend };
  }, [data, dataKey]);

  // Format value
  const formatValue = (value) => {
    if (value === null || value === undefined) return "--";
    const formatted = typeof value === 'number' ? value.toLocaleString() : value;
    return `${currency}${formatted}${unit}`;
  };

  // Custom tooltip
  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;
    
    const value = payload[0].value;
    const isWarning = thresholds.warning && value >= thresholds.warning;
    const isDanger = thresholds.danger && value >= thresholds.danger;
    
    return (
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-3 min-w-[140px]">
        <p className="text-xs text-gray-500 mb-1">{label}</p>
        <p className={`text-lg font-bold ${
          isDanger ? "text-[#e44138]" : isWarning ? "text-[#e7d356]" : "text-gray-900"
        }`}>
          {formatValue(value)}
        </p>
      </div>
    );
  };

  // Custom animated dot for latest point
  const CustomDot = (props) => {
    const { cx, cy, index } = props;
    const isLatest = index === data.length - 1;
    
    if (!isLatest) return null;
    
    return (
      <g>
        {/* Pulse animation */}
        <motion.circle
          cx={cx}
          cy={cy}
          r={12}
          fill={color}
          opacity={0.3}
          initial={{ r: 6, opacity: 0.5 }}
          animate={{ r: 16, opacity: 0 }}
          transition={{ duration: 1.5, repeat: Infinity }}
        />
        {/* Solid dot */}
        <circle
          cx={cx}
          cy={cy}
          r={5}
          fill={color}
          stroke="white"
          strokeWidth={2}
        />
      </g>
    );
  };

  // Determine value change direction
  const valueChange = latestValue !== null && previousValue !== null 
    ? latestValue - previousValue 
    : 0;
  const isIncreasing = valueChange > 0;

  const ChartComponent = type === "area" ? AreaChart : LineChart;
  const DataComponent = type === "area" ? Area : Line;

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
        <div className="flex items-start gap-3">
          <motion.div 
            className={`w-12 h-12 rounded-xl flex items-center justify-center ${
              isConnected ? "bg-[#eefbe7]" : "bg-[#fdeeed]"
            }`}
            animate={{ scale: isLive && !isPaused ? [1, 1.05, 1] : 1 }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {isConnected ? (
              <Activity className={`w-6 h-6 ${isLive && !isPaused ? "text-[#5cb83a]" : "text-gray-400"}`} />
            ) : (
              <WifiOff className="w-6 h-6 text-[#e44138]" />
            )}
          </motion.div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-gray-900">{title}</h3>
              {isLive && !isPaused && (
                <motion.div
                  className="flex items-center gap-1 px-2 py-0.5 bg-[#eefbe7] rounded-full"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <motion.div
                    className="w-2 h-2 bg-[#5cb83a] rounded-full"
                    animate={{ scale: [1, 1.3, 1], opacity: [1, 0.5, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  />
                  <span className="text-xs font-semibold text-[#5cb83a]">LIVE</span>
                </motion.div>
              )}
            </div>
            <p className="text-sm text-gray-600">{subtitle}</p>
          </div>
        </div>

        {/* Current Value Display */}
        <div className="flex items-center gap-4">
          <div className="text-right">
            <AnimatePresence mode="wait">
              <motion.p
                key={latestValue}
                className="text-3xl font-bold text-gray-900"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.2 }}
              >
                {formatValue(latestValue)}
              </motion.p>
            </AnimatePresence>
            <div className="flex items-center justify-end gap-1 mt-1">
              {valueChange !== 0 && (
                <motion.span
                  className={`flex items-center text-xs font-semibold ${
                    isIncreasing ? "text-[#5cb83a]" : "text-[#e44138]"
                  }`}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                >
                  {isIncreasing ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
                  {Math.abs(valueChange).toFixed(1)}
                </motion.span>
              )}
              <span className="text-xs text-gray-400">
                {lastUpdate.toLocaleTimeString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      {showControls && (
        <div className="flex items-center gap-2 mb-4">
          <button
            onClick={() => setIsPaused(!isPaused)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              isPaused 
                ? "bg-[#eefbe7] text-[#5cb83a] hover:bg-[#d4f4c3]" 
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {isPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
            {isPaused ? "Resume" : "Pause"}
          </button>
          <button
            onClick={fetchData}
            disabled={!isPaused}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg text-xs font-semibold text-gray-600 transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            Refresh
          </button>
          <div className="ml-auto flex items-center gap-2 text-xs text-gray-500">
            <Zap className="w-3 h-3" />
            <span>{updateCount} updates</span>
          </div>
        </div>
      )}

      {/* Chart */}
      <div style={{ height }}>
        <ResponsiveContainer width="100%" height="100%">
          <ChartComponent data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <defs>
              <linearGradient id="liveGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={gradientFrom} stopOpacity={0.4} />
                <stop offset="95%" stopColor={gradientTo} stopOpacity={0.05} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis 
              dataKey={xAxisKey} 
              tick={{ fontSize: 11, fill: "#94a3b8" }}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              tick={{ fontSize: 11, fill: "#94a3b8" }}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => `${currency}${v}${unit}`}
            />
            <Tooltip content={<CustomTooltip />} />
            
            {/* Threshold lines */}
            {thresholds.warning && (
              <ReferenceLine 
                y={thresholds.warning} 
                stroke="#e7d356" 
                strokeDasharray="5 5" 
                label={{ value: "Warning", fill: "#b8a525", fontSize: 10 }}
              />
            )}
            {thresholds.danger && (
              <ReferenceLine 
                y={thresholds.danger} 
                stroke="#e44138" 
                strokeDasharray="5 5"
                label={{ value: "Danger", fill: "#e44138", fontSize: 10 }}
              />
            )}

            {type === "area" ? (
              <Area
                type="monotone"
                dataKey={dataKey}
                stroke={color}
                strokeWidth={2.5}
                fill="url(#liveGradient)"
                dot={<CustomDot />}
                isAnimationActive={true}
                animationDuration={300}
              />
            ) : (
              <Line
                type="monotone"
                dataKey={dataKey}
                stroke={color}
                strokeWidth={2.5}
                dot={<CustomDot />}
                isAnimationActive={true}
                animationDuration={300}
              />
            )}
          </ChartComponent>
        </ResponsiveContainer>
      </div>

      {/* Stats Footer */}
      {showStats && (
        <div className="mt-4 pt-4 border-t border-gray-100 grid grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-xs text-gray-500 mb-1">Min</p>
            <p className="text-sm font-bold text-gray-900">{formatValue(stats.min)}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500 mb-1">Max</p>
            <p className="text-sm font-bold text-gray-900">{formatValue(stats.max)}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500 mb-1">Average</p>
            <p className="text-sm font-bold text-gray-900">{formatValue(Math.round(stats.avg * 10) / 10)}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500 mb-1">Trend</p>
            <p className={`text-sm font-bold flex items-center justify-center gap-1 ${
              stats.trend > 0 ? "text-[#5cb83a]" : stats.trend < 0 ? "text-[#e44138]" : "text-gray-500"
            }`}>
              {stats.trend > 0 ? <TrendingUp className="w-3 h-3" /> : stats.trend < 0 ? <TrendingDown className="w-3 h-3" /> : null}
              {Math.abs(stats.trend).toFixed(1)}%
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * Multi-Series Live Chart - Multiple data streams
 */
export function MultiSeriesLiveChart({
  series = [],
  interval = 2000,
  maxPoints = 20,
  title = "Multi-Series Live Data",
  subtitle = "Real-time comparison",
  height = 300
}) {
  const [data, setData] = useState([]);
  const [isLive, setIsLive] = useState(true);

  useEffect(() => {
    if (!isLive) return;

    const fetchAllSeries = () => {
      const timestamp = new Date().toLocaleTimeString('en-US', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
      });

      const newPoint = { time: timestamp };
      series.forEach(s => {
        const lastValue = data.length > 0 ? data[data.length - 1][s.key] || 50 : 50;
        const change = (Math.random() - 0.5) * 15;
        newPoint[s.key] = Math.max(0, Math.min(100, lastValue + change));
      });

      setData(prev => {
        const updated = [...prev, newPoint];
        return updated.length > maxPoints ? updated.slice(-maxPoints) : updated;
      });
    };

    fetchAllSeries();
    const intervalId = setInterval(fetchAllSeries, interval);
    return () => clearInterval(intervalId);
  }, [isLive, series, maxPoints, interval, data]);

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          <p className="text-sm text-gray-600">{subtitle}</p>
        </div>
        <div className="flex items-center gap-4">
          {series.map((s, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: s.color }} />
              <span className="text-sm text-gray-600">{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ height }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="time" tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} />
            <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickLine={false} axisLine={false} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: "white", 
                border: "1px solid #e2e8f0", 
                borderRadius: "12px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.1)"
              }} 
            />
            {series.map((s, i) => (
              <Line
                key={i}
                type="monotone"
                dataKey={s.key}
                stroke={s.color}
                strokeWidth={2}
                dot={false}
                isAnimationActive={true}
                animationDuration={300}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}