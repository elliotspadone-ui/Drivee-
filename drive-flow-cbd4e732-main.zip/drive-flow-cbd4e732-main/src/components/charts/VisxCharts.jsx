import React, { useMemo } from 'react';
import { Group } from '@visx/group';
import { Bar } from '@visx/shape';
import { scaleLinear, scaleBand } from '@visx/scale';
import { AxisBottom, AxisLeft } from '@visx/axis';
import { GridRows } from '@visx/grid';
import { useTooltip, TooltipWithBounds, defaultStyles } from '@visx/tooltip';
import { localPoint } from '@visx/event';
import { LinearGradient } from '@visx/gradient';
import { motion } from 'framer-motion';

const tooltipStyles = {
  ...defaultStyles,
  backgroundColor: '#1e293b',
  color: 'white',
  padding: '12px 16px',
  borderRadius: '12px',
  fontSize: '13px',
  fontWeight: '500',
  boxShadow: '0 10px 40px rgba(0,0,0,0.2)',
};

/**
 * Visx Bar Chart - High performance bar chart
 */
export function VisxBarChart({
  data = [],
  width = 500,
  height = 300,
  margin = { top: 20, right: 20, bottom: 40, left: 60 },
  xKey = 'label',
  yKey = 'value',
  color = '#3b82c4',
  title,
  subtitle,
  currency = '€',
  animate = true
}) {
  const {
    tooltipData,
    tooltipLeft,
    tooltipTop,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip();

  const xMax = width - margin.left - margin.right;
  const yMax = height - margin.top - margin.bottom;

  const xScale = useMemo(
    () =>
      scaleBand({
        range: [0, xMax],
        domain: data.map(d => d[xKey]),
        padding: 0.3,
      }),
    [xMax, data, xKey]
  );

  const yScale = useMemo(
    () =>
      scaleLinear({
        range: [yMax, 0],
        domain: [0, Math.max(...data.map(d => d[yKey]), 1) * 1.1],
        nice: true,
      }),
    [yMax, data, yKey]
  );

  const handleMouseMove = (event, datum) => {
    const coords = localPoint(event);
    showTooltip({
      tooltipData: datum,
      tooltipLeft: coords?.x,
      tooltipTop: coords?.y,
    });
  };

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-400">
        <p>No data available</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={animate ? { opacity: 0, y: 20 } : {}}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm relative"
    >
      {title && (
        <div className="mb-4">
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          {subtitle && <p className="text-sm text-gray-600">{subtitle}</p>}
        </div>
      )}
      
      <svg width={width} height={height}>
        <LinearGradient id="bar-gradient" from="#3b82c4" to="#a9d5ed" vertical />
        <Group left={margin.left} top={margin.top}>
          <GridRows
            scale={yScale}
            width={xMax}
            strokeDasharray="3,3"
            stroke="#e2e8f0"
            strokeOpacity={0.8}
          />
          
          {data.map((d, i) => {
            const barWidth = xScale.bandwidth();
            const barHeight = yMax - yScale(d[yKey]);
            const barX = xScale(d[xKey]);
            const barY = yScale(d[yKey]);

            return (
              <motion.g
                key={`bar-${i}`}
                initial={animate ? { scaleY: 0 } : {}}
                animate={{ scaleY: 1 }}
                transition={{ delay: i * 0.05, duration: 0.4 }}
                style={{ transformOrigin: 'bottom' }}
              >
                <Bar
                  x={barX}
                  y={barY}
                  width={barWidth}
                  height={barHeight}
                  fill="url(#bar-gradient)"
                  rx={6}
                  onMouseMove={(e) => handleMouseMove(e, d)}
                  onMouseLeave={hideTooltip}
                  style={{ cursor: 'pointer' }}
                />
              </motion.g>
            );
          })}

          <AxisBottom
            top={yMax}
            scale={xScale}
            tickLabelProps={() => ({
              fill: '#64748b',
              fontSize: 11,
              fontWeight: 500,
              textAnchor: 'middle',
            })}
            stroke="#e2e8f0"
            tickStroke="#e2e8f0"
          />
          
          <AxisLeft
            scale={yScale}
            tickFormat={(v) => `${currency}${v.toLocaleString()}`}
            tickLabelProps={() => ({
              fill: '#64748b',
              fontSize: 11,
              fontWeight: 500,
              textAnchor: 'end',
              dx: -4,
            })}
            stroke="#e2e8f0"
            tickStroke="#e2e8f0"
          />
        </Group>
      </svg>

      {tooltipOpen && tooltipData && (
        <TooltipWithBounds
          top={tooltipTop}
          left={tooltipLeft}
          style={tooltipStyles}
        >
          <div>
            <strong>{tooltipData[xKey]}</strong>
            <div>{currency}{tooltipData[yKey].toLocaleString()}</div>
          </div>
        </TooltipWithBounds>
      )}
    </motion.div>
  );
}

/**
 * Visx Horizontal Bar Chart
 */
export function VisxHorizontalBarChart({
  data = [],
  width = 500,
  height = 300,
  margin = { top: 20, right: 30, bottom: 20, left: 100 },
  xKey = 'value',
  yKey = 'label',
  colors = ['#3b82c4', '#81da5a', '#e7d356', '#6c376f', '#a9d5ed'],
  title,
  subtitle
}) {
  const {
    tooltipData,
    tooltipLeft,
    tooltipTop,
    tooltipOpen,
    showTooltip,
    hideTooltip,
  } = useTooltip();

  const xMax = width - margin.left - margin.right;
  const yMax = height - margin.top - margin.bottom;

  const xScale = useMemo(
    () =>
      scaleLinear({
        range: [0, xMax],
        domain: [0, Math.max(...data.map(d => d[xKey]), 1) * 1.1],
        nice: true,
      }),
    [xMax, data, xKey]
  );

  const yScale = useMemo(
    () =>
      scaleBand({
        range: [0, yMax],
        domain: data.map(d => d[yKey]),
        padding: 0.3,
      }),
    [yMax, data, yKey]
  );

  const handleMouseMove = (event, datum) => {
    const coords = localPoint(event);
    showTooltip({
      tooltipData: datum,
      tooltipLeft: coords?.x,
      tooltipTop: coords?.y,
    });
  };

  if (data.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm relative"
    >
      {title && (
        <div className="mb-4">
          <h3 className="text-lg font-bold text-gray-900">{title}</h3>
          {subtitle && <p className="text-sm text-gray-600">{subtitle}</p>}
        </div>
      )}
      
      <svg width={width} height={height}>
        <Group left={margin.left} top={margin.top}>
          <GridRows
            scale={yScale}
            width={xMax}
            strokeDasharray="3,3"
            stroke="#e2e8f0"
            strokeOpacity={0.5}
          />
          
          {data.map((d, i) => {
            const barHeight = yScale.bandwidth();
            const barWidth = xScale(d[xKey]);
            const barY = yScale(d[yKey]);

            return (
              <motion.g
                key={`bar-${i}`}
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ delay: i * 0.08, duration: 0.5 }}
                style={{ transformOrigin: 'left' }}
              >
                <Bar
                  x={0}
                  y={barY}
                  width={barWidth}
                  height={barHeight}
                  fill={colors[i % colors.length]}
                  rx={4}
                  onMouseMove={(e) => handleMouseMove(e, d)}
                  onMouseLeave={hideTooltip}
                  style={{ cursor: 'pointer' }}
                />
                <text
                  x={barWidth + 8}
                  y={barY + barHeight / 2}
                  dy=".35em"
                  fontSize={12}
                  fontWeight={600}
                  fill="#374151"
                >
                  {d[xKey].toLocaleString()}
                </text>
              </motion.g>
            );
          })}

          <AxisLeft
            scale={yScale}
            hideAxisLine
            hideTicks
            tickLabelProps={() => ({
              fill: '#64748b',
              fontSize: 12,
              fontWeight: 500,
              textAnchor: 'end',
              dx: -8,
            })}
          />
        </Group>
      </svg>

      {tooltipOpen && tooltipData && (
        <TooltipWithBounds
          top={tooltipTop}
          left={tooltipLeft}
          style={tooltipStyles}
        >
          <div>
            <strong>{tooltipData[yKey]}</strong>
            <div>{tooltipData[xKey].toLocaleString()}</div>
          </div>
        </TooltipWithBounds>
      )}
    </motion.div>
  );
}

/**
 * Simple Stat Sparkline using Visx
 */
export function VisxSparkline({
  data = [],
  width = 100,
  height = 30,
  color = '#3b82c4',
  showArea = true
}) {
  const xScale = useMemo(
    () =>
      scaleLinear({
        range: [0, width],
        domain: [0, data.length - 1],
      }),
    [width, data.length]
  );

  const yScale = useMemo(
    () =>
      scaleLinear({
        range: [height, 0],
        domain: [Math.min(...data) * 0.9, Math.max(...data) * 1.1],
      }),
    [height, data]
  );

  if (data.length < 2) return null;

  const points = data.map((d, i) => ({
    x: xScale(i),
    y: yScale(d),
  }));

  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaPath = `${linePath} L ${width} ${height} L 0 ${height} Z`;

  return (
    <svg width={width} height={height}>
      {showArea && (
        <path d={areaPath} fill={color} opacity={0.1} />
      )}
      <path d={linePath} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" />
      <circle cx={points[points.length - 1].x} cy={points[points.length - 1].y} r={3} fill={color} />
    </svg>
  );
}

export default VisxBarChart;