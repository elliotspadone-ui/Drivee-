import React, { useState } from "react";
import { Beaker, Play, Pause, TrendingUp, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function ABTestingManager({ tests = [], onCreateTest, onUpdateTest }) {
  const [showCreate, setShowCreate] = useState(false);

  const calculateConversionRate = (views, conversions) => {
    return views > 0 ? ((conversions / views) * 100).toFixed(2) : 0;
  };

  const determineWinner = (test) => {
    const rateA = calculateConversionRate(test.metrics.variant_a_views, test.metrics.variant_a_conversions);
    const rateB = calculateConversionRate(test.metrics.variant_b_views, test.metrics.variant_b_conversions);
    
    if (rateA > rateB) return 'a';
    if (rateB > rateA) return 'b';
    return 'tie';
  };

  return (
    <div className="space-y-6">
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">A/B Testing</h2>
            <p className="text-sm text-muted">Optimize conversions with split testing</p>
          </div>
          <button
            onClick={() => setShowCreate(true)}
            className="neo-button px-6 py-3 gradient-primary text-white font-semibold rounded-xl"
          >
            Create Test
          </button>
        </div>

        {/* Active Tests */}
        <div className="space-y-4">
          {tests.map((test, index) => {
            const winner = determineWinner(test);
            const rateA = calculateConversionRate(test.metrics.variant_a_views, test.metrics.variant_a_conversions);
            const rateB = calculateConversionRate(test.metrics.variant_b_views, test.metrics.variant_b_conversions);

            return (
              <div key={test.id} className="neo-inset p-6 rounded-2xl">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">{test.name}</h3>
                    <p className="text-sm text-muted capitalize">{test.page_type} page</p>
                  </div>
                  <span className={`neo-button px-4 py-2 text-xs font-bold ${
                    test.status === 'running' ? 'text-green-700' : 'text-gray-700'
                  }`}>
                    {test.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Variant A */}
                  <div className={`neo-button p-4 rounded-xl ${winner === 'a' ? 'bg-green-50 border-2 border-green-500' : ''}`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-semibold text-gray-900">Variant A (Control)</span>
                      {winner === 'a' && <CheckCircle className="w-5 h-5 text-green-600" />}
                    </div>
                    <p className="text-3xl font-bold text-gray-900">{rateA}%</p>
                    <p className="text-xs text-muted mt-1">
                      {test.metrics.variant_a_conversions} / {test.metrics.variant_a_views} conversions
                    </p>
                  </div>

                  {/* Variant B */}
                  <div className={`neo-button p-4 rounded-xl ${winner === 'b' ? 'bg-green-50 border-2 border-green-500' : ''}`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-semibold text-gray-900">Variant B (Test)</span>
                      {winner === 'b' && <CheckCircle className="w-5 h-5 text-green-600" />}
                    </div>
                    <p className="text-3xl font-bold text-gray-900">{rateB}%</p>
                    <p className="text-xs text-muted mt-1">
                      {test.metrics.variant_b_conversions} / {test.metrics.variant_b_views} conversions
                    </p>
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => onUpdateTest(test.id, { status: test.status === 'running' ? 'paused' : 'running' })}
                    className="neo-button px-4 py-2 text-sm flex items-center gap-2"
                  >
                    {test.status === 'running' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    {test.status === 'running' ? 'Pause' : 'Resume'}
                  </button>
                  <button className="neo-button px-4 py-2 text-sm">
                    View Details
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}