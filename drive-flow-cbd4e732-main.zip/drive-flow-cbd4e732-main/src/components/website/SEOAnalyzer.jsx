import React from "react";
import { CheckCircle, AlertCircle, XCircle, TrendingUp, Zap } from "lucide-react";

export default function SEOAnalyzer({ website, sections, school }) {
  const analyzeMetaDescription = () => {
    const desc = website.meta_description || '';
    const length = desc.length;
    const optimal = length >= 120 && length <= 160;
    const hasKeywords = desc.toLowerCase().includes('driving') || desc.toLowerCase().includes('school');
    
    return {
      score: optimal && hasKeywords ? 100 : length > 0 ? 60 : 0,
      optimal,
      length,
      hasKeywords,
      message: !desc ? 'Meta description is missing' : 
               !optimal ? `Length is ${length} chars (optimal: 120-160)` :
               !hasKeywords ? 'Consider adding relevant keywords' :
               'Meta description looks great!'
    };
  };

  const analyzeTitle = () => {
    const title = website.meta_title || school.name;
    const length = title.length;
    const optimal = length >= 50 && length <= 60;
    
    return {
      score: optimal ? 100 : length > 0 ? 70 : 0,
      optimal,
      length,
      message: !title ? 'Title is missing' :
               !optimal ? `Length is ${length} chars (optimal: 50-60)` :
               'Title length is perfect!'
    };
  };

  const analyzeContent = () => {
    let wordCount = 0;
    sections.forEach(section => {
      if (section.content) wordCount += section.content.split(/\s+/).length;
      if (section.title) wordCount += section.title.split(/\s+/).length;
    });
    
    const hasEnoughContent = wordCount >= 300;
    
    return {
      score: hasEnoughContent ? 100 : (wordCount / 300) * 100,
      wordCount,
      hasEnoughContent,
      message: hasEnoughContent ? 
               `Great! You have ${wordCount} words of content` :
               `Add more content (${wordCount}/300 words minimum)`
    };
  };

  const analyzeImages = () => {
    const imagesWithAlt = sections.filter(s => s.image_url).length;
    const totalSections = sections.length;
    const score = totalSections > 0 ? (imagesWithAlt / totalSections) * 100 : 0;
    
    return {
      score,
      imagesWithAlt,
      totalSections,
      message: imagesWithAlt >= 3 ? 
               'Good use of images throughout the site' :
               'Add images to more sections for better engagement'
    };
  };

  const analyzeKeywords = (text) => {
    const commonDrivingKeywords = [
      'driving school', 'driving lessons', 'learn to drive', 'driving instructor',
      'driving test', 'driving course', 'driver education', 'license',
      'certified', 'professional', 'experienced'
    ];
    
    const textLower = text.toLowerCase();
    const foundKeywords = commonDrivingKeywords.filter(keyword => 
      textLower.includes(keyword)
    );
    
    return {
      score: Math.min((foundKeywords.length / 5) * 100, 100),
      foundKeywords,
      totalKeywords: commonDrivingKeywords.length,
      message: foundKeywords.length >= 5 ?
               'Excellent keyword optimization' :
               `Found ${foundKeywords.length}/5+ relevant keywords`
    };
  };

  const analyzePageSpeed = () => {
    const issues = [];
    const recommendations = [];
    
    // Check for large images
    const largeImages = sections.filter(s => s.image_url).length;
    if (largeImages > 10) {
      issues.push('Many images detected');
      recommendations.push('Compress and optimize images');
    }
    
    // Check content length
    const totalContent = sections.reduce((acc, s) => acc + (s.content?.length || 0), 0);
    if (totalContent > 10000) {
      issues.push('Large amount of content');
      recommendations.push('Consider pagination or lazy loading');
    }
    
    // Social media embeds
    if (website.social_facebook || website.social_instagram || website.social_twitter) {
      recommendations.push('Load social media widgets asynchronously');
    }
    
    const score = 100 - (issues.length * 15);
    
    return {
      score: Math.max(score, 50),
      issues,
      recommendations,
      message: issues.length === 0 ? 
               'Site structure looks optimized' :
               `${issues.length} potential performance issues`
    };
  };

  const metaDesc = analyzeMetaDescription();
  const titleAnalysis = analyzeTitle();
  const contentAnalysis = analyzeContent();
  const imageAnalysis = analyzeImages();
  const allContent = sections.map(s => `${s.title || ''} ${s.content || ''}`).join(' ');
  const keywordAnalysis = analyzeKeywords(allContent);
  const speedAnalysis = analyzePageSpeed();

  const overallScore = Math.round(
    (metaDesc.score + titleAnalysis.score + contentAnalysis.score + 
     imageAnalysis.score + keywordAnalysis.score + speedAnalysis.score) / 6
  );

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreIcon = (score) => {
    if (score >= 80) return CheckCircle;
    if (score >= 60) return AlertCircle;
    return XCircle;
  };

  const ScoreCard = ({ title, score, message, details }) => {
    const Icon = getScoreIcon(score);
    return (
      <div className="neo-inset p-6 rounded-2xl">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <Icon className={`w-6 h-6 ${getScoreColor(score)}`} />
            <h3 className="font-semibold text-gray-900">{title}</h3>
          </div>
          <span className={`text-2xl font-bold ${getScoreColor(score)}`}>
            {Math.round(score)}%
          </span>
        </div>
        <p className="text-sm text-gray-700 mb-2">{message}</p>
        {details && <p className="text-xs text-gray-500">{details}</p>}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Overall Score */}
      <div className="neo-surface p-8 text-center">
        <div className="w-32 h-32 mx-auto mb-4 rounded-full border-8 flex items-center justify-center" 
             style={{ borderColor: overallScore >= 80 ? '#10b981' : overallScore >= 60 ? '#f59e0b' : '#ef4444' }}>
          <div>
            <div className={`text-4xl font-bold ${getScoreColor(overallScore)}`}>
              {overallScore}
            </div>
            <div className="text-sm text-gray-600">SEO Score</div>
          </div>
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          {overallScore >= 80 ? 'Excellent!' : overallScore >= 60 ? 'Good Progress' : 'Needs Improvement'}
        </h2>
        <p className="text-gray-600">
          {overallScore >= 80 ? 'Your website is well optimized for search engines' :
           overallScore >= 60 ? 'A few improvements will boost your rankings' :
           'Follow the recommendations below to improve SEO'}
        </p>
      </div>

      {/* Analysis Cards */}
      <div className="grid md:grid-cols-2 gap-6">
        <ScoreCard
          title="Meta Title"
          score={titleAnalysis.score}
          message={titleAnalysis.message}
          details={`Current length: ${titleAnalysis.length} characters`}
        />

        <ScoreCard
          title="Meta Description"
          score={metaDesc.score}
          message={metaDesc.message}
          details={`Current length: ${metaDesc.length} characters`}
        />

        <ScoreCard
          title="Content Quality"
          score={contentAnalysis.score}
          message={contentAnalysis.message}
          details={`Total word count: ${contentAnalysis.wordCount}`}
        />

        <ScoreCard
          title="Image Usage"
          score={imageAnalysis.score}
          message={imageAnalysis.message}
          details={`${imageAnalysis.imagesWithAlt} sections with images`}
        />

        <ScoreCard
          title="Keyword Optimization"
          score={keywordAnalysis.score}
          message={keywordAnalysis.message}
          details={keywordAnalysis.foundKeywords.length > 0 ? 
                   `Keywords found: ${keywordAnalysis.foundKeywords.slice(0, 3).join(', ')}` :
                   'No relevant keywords detected'}
        />

        <ScoreCard
          title="Page Speed"
          score={speedAnalysis.score}
          message={speedAnalysis.message}
          details={speedAnalysis.issues.length > 0 ? 
                   speedAnalysis.issues.join(', ') :
                   'No major performance issues detected'}
        />
      </div>

      {/* Recommendations */}
      {(speedAnalysis.recommendations.length > 0 || keywordAnalysis.foundKeywords.length < 5) && (
        <div className="neo-surface p-6">
          <div className="flex items-center gap-3 mb-4">
            <Zap className="w-6 h-6 text-indigo-600" />
            <h3 className="text-xl font-bold text-gray-900">Quick Wins</h3>
          </div>
          <ul className="space-y-2">
            {metaDesc.score < 80 && (
              <li className="flex items-start gap-2 text-sm text-gray-700">
                <TrendingUp className="w-4 h-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                <span>Optimize your meta description to be 120-160 characters and include keywords like "driving school" or "driving lessons"</span>
              </li>
            )}
            {contentAnalysis.score < 80 && (
              <li className="flex items-start gap-2 text-sm text-gray-700">
                <TrendingUp className="w-4 h-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                <span>Add more detailed content to your sections - aim for at least 300 words total</span>
              </li>
            )}
            {keywordAnalysis.foundKeywords.length < 5 && (
              <li className="flex items-start gap-2 text-sm text-gray-700">
                <TrendingUp className="w-4 h-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                <span>Include more relevant keywords naturally throughout your content</span>
              </li>
            )}
            {speedAnalysis.recommendations.map((rec, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                <TrendingUp className="w-4 h-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                <span>{rec}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Keyword Suggestions */}
      <div className="neo-surface p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Suggested Keywords</h3>
        <div className="flex flex-wrap gap-2">
          {[
            'driving school ' + school.city,
            'driving lessons ' + school.city,
            'learn to drive',
            'driving instructor',
            'driving test preparation',
            'certified driving school',
            'professional driving lessons',
            'driver education',
            'driving course',
            'get your license'
          ].map((keyword) => (
            <span key={keyword} className="neo-inset px-4 py-2 rounded-full text-sm text-gray-700">
              {keyword}
            </span>
          ))}
        </div>
        <p className="text-sm text-gray-600 mt-4">
          Use these keywords naturally throughout your content to improve search rankings
        </p>
      </div>
    </div>
  );
}