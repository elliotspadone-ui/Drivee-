import React, { useState } from "react";
import { Languages, Sparkles, Save, Trash2, Plus } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { LANGUAGES } from "./LanguageSwitcher";

export default function TranslationManager({ 
  website, 
  sections = [],
  translations = [],
  onUpdate 
}) {
  const [selectedLanguage, setSelectedLanguage] = useState('es');
  const [translating, setTranslating] = useState(false);
  const [editingTranslations, setEditingTranslations] = useState({});

  const enabledLanguages = website.enabled_languages || ['en'];
  const availableToAdd = Object.keys(LANGUAGES).filter(
    code => !enabledLanguages.includes(code)
  );

  const getTranslation = (fieldName, sectionId = null) => {
    return translations.find(
      t => t.language_code === selectedLanguage && 
           t.field_name === fieldName && 
           (sectionId ? t.section_id === sectionId : !t.section_id)
    );
  };

  const handleSaveTranslation = async (fieldName, value, sectionId = null) => {
    try {
      const existing = getTranslation(fieldName, sectionId);
      
      if (existing) {
        await base44.entities.WebsiteTranslation.update(existing.id, {
          translated_text: value
        });
      } else {
        await base44.entities.WebsiteTranslation.create({
          website_id: website.id,
          section_id: sectionId,
          language_code: selectedLanguage,
          field_name: fieldName,
          translated_text: value,
          is_auto_translated: false
        });
      }
      
      toast.success("Translation saved!");
      onUpdate();
    } catch (error) {
      toast.error("Failed to save translation");
    }
  };

  const handleAutoTranslate = async () => {
    if (translating) return;
    setTranslating(true);

    try {
      const fieldsToTranslate = [
        { name: 'meta_title', value: website.meta_title },
        { name: 'meta_description', value: website.meta_description },
      ];

      sections.forEach(section => {
        fieldsToTranslate.push(
          { name: 'title', value: section.title, sectionId: section.id },
          { name: 'content', value: section.content, sectionId: section.id },
          { name: 'cta_text', value: section.cta_text, sectionId: section.id }
        );
      });

      for (const field of fieldsToTranslate) {
        if (!field.value) continue;
        
        const existing = getTranslation(field.name, field.sectionId);
        if (existing) continue;

        const response = await base44.integrations.Core.InvokeLLM({
          prompt: `Translate the following text to ${LANGUAGES[selectedLanguage].name}. Return only the translation, no explanations:\n\n${field.value}`,
          response_json_schema: null
        });

        await base44.entities.WebsiteTranslation.create({
          website_id: website.id,
          section_id: field.sectionId,
          language_code: selectedLanguage,
          field_name: field.name,
          translated_text: response,
          is_auto_translated: true
        });
      }

      toast.success("Auto-translation completed!");
      onUpdate();
    } catch (error) {
      toast.error("Auto-translation failed");
    } finally {
      setTranslating(false);
    }
  };

  const handleAddLanguage = async (code) => {
    await base44.entities.Website.update(website.id, {
      enabled_languages: [...enabledLanguages, code]
    });
    toast.success(`${LANGUAGES[code].name} added!`);
    onUpdate();
  };

  const handleRemoveLanguage = async (code) => {
    if (code === 'en') {
      toast.error("Cannot remove default language");
      return;
    }
    await base44.entities.Website.update(website.id, {
      enabled_languages: enabledLanguages.filter(l => l !== code)
    });
    toast.success(`${LANGUAGES[code].name} removed!`);
    onUpdate();
  };

  return (
    <div className="space-y-6">
      {/* Enabled Languages */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Enabled Languages</h3>
        <div className="flex flex-wrap gap-3 mb-4">
          {enabledLanguages.map(code => (
            <div key={code} className="neo-inset px-4 py-2 rounded-xl flex items-center gap-3">
              <span className="text-2xl">{LANGUAGES[code]?.flag}</span>
              <span className="font-medium text-gray-700">{LANGUAGES[code]?.name}</span>
              {code !== 'en' && (
                <button
                  onClick={() => handleRemoveLanguage(code)}
                  className="ml-2 text-red-600 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>
        
        {availableToAdd.length > 0 && (
          <details className="mt-4">
            <summary className="cursor-pointer text-sm font-semibold text-indigo-600 flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add Language
            </summary>
            <div className="mt-3 grid grid-cols-3 gap-2">
              {availableToAdd.slice(0, 12).map(code => (
                <button
                  key={code}
                  onClick={() => handleAddLanguage(code)}
                  className="neo-button px-3 py-2 rounded-xl text-sm flex items-center gap-2"
                >
                  <span>{LANGUAGES[code]?.flag}</span>
                  <span>{LANGUAGES[code]?.name}</span>
                </button>
              ))}
            </div>
          </details>
        )}
      </div>

      {/* Translation Editor */}
      {enabledLanguages.length > 1 && (
        <div className="neo-surface p-6 rounded-3xl">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-900">Manage Translations</h3>
            <div className="flex items-center gap-3">
              <select
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
                className="neo-button px-4 py-2 rounded-xl"
              >
                {enabledLanguages.filter(l => l !== 'en').map(code => (
                  <option key={code} value={code}>
                    {LANGUAGES[code]?.flag} {LANGUAGES[code]?.name}
                  </option>
                ))}
              </select>
              <button
                onClick={handleAutoTranslate}
                disabled={translating}
                className="neo-button px-4 py-2 rounded-xl flex items-center gap-2 gradient-primary text-white"
              >
                <Sparkles className="w-4 h-4" />
                {translating ? "Translating..." : "Auto-Translate"}
              </button>
            </div>
          </div>

          <div className="space-y-6">
            {/* Website Meta */}
            <div className="neo-inset p-4 rounded-2xl">
              <h4 className="font-semibold text-gray-900 mb-3">Website Meta</h4>
              <div className="space-y-3">
                <div>
                  <label className="text-sm text-gray-600 mb-1 block">Meta Title</label>
                  <Textarea
                    value={getTranslation('meta_title')?.translated_text || ''}
                    onChange={(e) => handleSaveTranslation('meta_title', e.target.value)}
                    placeholder={website.meta_title}
                    rows={1}
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-600 mb-1 block">Meta Description</label>
                  <Textarea
                    value={getTranslation('meta_description')?.translated_text || ''}
                    onChange={(e) => handleSaveTranslation('meta_description', e.target.value)}
                    placeholder={website.meta_description}
                    rows={2}
                  />
                </div>
              </div>
            </div>

            {/* Sections */}
            {sections.map(section => (
              <div key={section.id} className="neo-inset p-4 rounded-2xl">
                <h4 className="font-semibold text-gray-900 mb-3 capitalize">
                  {section.section_type} Section
                </h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-gray-600 mb-1 block">Title</label>
                    <Textarea
                      value={getTranslation('title', section.id)?.translated_text || ''}
                      onChange={(e) => handleSaveTranslation('title', e.target.value, section.id)}
                      placeholder={section.title}
                      rows={1}
                    />
                  </div>
                  <div>
                    <label className="text-sm text-gray-600 mb-1 block">Content</label>
                    <Textarea
                      value={getTranslation('content', section.id)?.translated_text || ''}
                      onChange={(e) => handleSaveTranslation('content', e.target.value, section.id)}
                      placeholder={section.content}
                      rows={3}
                    />
                  </div>
                  {section.cta_text && (
                    <div>
                      <label className="text-sm text-gray-600 mb-1 block">Button Text</label>
                      <Textarea
                        value={getTranslation('cta_text', section.id)?.translated_text || ''}
                        onChange={(e) => handleSaveTranslation('cta_text', e.target.value, section.id)}
                        placeholder={section.cta_text}
                        rows={1}
                      />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}