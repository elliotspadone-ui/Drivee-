import React, { useState } from "react";
import { MessageSquare, Users, Clock, Settings } from "lucide-react";

export default function LiveChatConfig({ settings, onUpdate }) {
  const [config, setConfig] = useState(settings || {
    enabled: false,
    position: 'bottom-right',
    primaryColor: '#667eea',
    greeting: 'Hi! How can we help you today?',
    offlineMessage: "We're currently offline. Leave us a message!",
    showAgentPhotos: true,
    autoOpenDelay: 5
  });

  return (
    <div className="space-y-6">
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex items-center gap-3 mb-6">
          <MessageSquare className="w-8 h-8 text-indigo-600" />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Live Chat Widget</h2>
            <p className="text-sm text-muted">Connect with visitors in real-time</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Enable/Disable */}
          <div className="flex items-center justify-between neo-inset p-4 rounded-xl">
            <div>
              <p className="font-semibold text-gray-900">Enable Live Chat</p>
              <p className="text-sm text-muted">Show chat widget on your website</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={config.enabled}
                onChange={(e) => setConfig({ ...config, enabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-14 h-7 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>

          {/* Position */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-3">Widget Position</label>
            <div className="grid grid-cols-2 gap-3">
              {['bottom-right', 'bottom-left', 'top-right', 'top-left'].map(pos => (
                <button
                  key={pos}
                  onClick={() => setConfig({ ...config, position: pos })}
                  className={`neo-button p-4 rounded-xl text-sm font-semibold ${
                    config.position === pos ? 'active bg-indigo-50' : ''
                  }`}
                >
                  {pos.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Greeting */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Welcome Message</label>
            <textarea
              value={config.greeting}
              onChange={(e) => setConfig({ ...config, greeting: e.target.value })}
              className="neo-button w-full px-4 py-3 rounded-xl"
              rows={2}
            />
          </div>

          {/* Color */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Widget Color</label>
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={config.primaryColor}
                onChange={(e) => setConfig({ ...config, primaryColor: e.target.value })}
                className="neo-button h-12 w-24 cursor-pointer"
              />
              <input
                type="text"
                value={config.primaryColor}
                onChange={(e) => setConfig({ ...config, primaryColor: e.target.value })}
                className="neo-button flex-1 px-4 py-3 rounded-xl"
              />
            </div>
          </div>

          {/* Auto Open */}
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">
              Auto-open after (seconds)
            </label>
            <input
              type="number"
              value={config.autoOpenDelay}
              onChange={(e) => setConfig({ ...config, autoOpenDelay: parseInt(e.target.value) })}
              className="neo-button w-32 px-4 py-3 rounded-xl"
            />
          </div>

          <button
            onClick={() => onUpdate(config)}
            className="neo-button w-full py-4 gradient-primary text-white font-bold rounded-2xl"
          >
            Save Settings
          </button>
        </div>
      </div>

      {/* Preview */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Widget Preview</h3>
        <div className="neo-inset rounded-2xl h-96 relative overflow-hidden">
          <div 
            className={`absolute ${config.position.replace('-', ' ')} m-4`}
            style={{ backgroundColor: config.primaryColor }}
          >
            <div className="w-16 h-16 rounded-full shadow-lg flex items-center justify-center">
              <MessageSquare className="w-8 h-8 text-white" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}