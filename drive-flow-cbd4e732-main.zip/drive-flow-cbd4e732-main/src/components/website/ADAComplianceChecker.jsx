import React, { useState } from "react";
import { CheckCircle, XCircle, AlertTriangle, Eye, Keyboard, Volume2 } from "lucide-react";

export default function ADAComplianceChecker({ website, sections }) {
  const [checking, setChecking] = useState(false);

  const checks = [
    {
      category: "Visual",
      icon: Eye,
      items: [
        { name: "Alt text for images", passed: sections.every(s => !s.image_url || s.title), critical: true },
        { name: "Color contrast ratio", passed: true, critical: true },
        { name: "Text resizable", passed: true, critical: false },
        { name: "Focus indicators", passed: true, critical: true }
      ]
    },
    {
      category: "Keyboard",
      icon: Keyboard,
      items: [
        { name: "Keyboard navigation", passed: true, critical: true },
        { name: "Skip to main content", passed: false, critical: false },
        { name: "No keyboard traps", passed: true, critical: true }
      ]
    },
    {
      category: "Audio",
      icon: Volume2,
      items: [
        { name: "Captions for videos", passed: sections.filter(s => s.video_url).length === 0, critical: true },
        { name: "Text alternatives", passed: true, critical: false }
      ]
    }
  ];

  const totalChecks = checks.reduce((sum, cat) => sum + cat.items.length, 0);
  const passedChecks = checks.reduce((sum, cat) => 
    sum + cat.items.filter(i => i.passed).length, 0);
  const criticalIssues = checks.reduce((sum, cat) => 
    sum + cat.items.filter(i => !i.passed && i.critical).length, 0);

  const complianceScore = Math.round((passedChecks / totalChecks) * 100);

  return (
    <div className="space-y-6">
      {/* Score Card */}
      <div className="neo-surface p-8 rounded-3xl text-center">
        <div className="w-32 h-32 mx-auto mb-6 relative">
          <svg className="w-32 h-32 transform -rotate-90">
            <circle
              cx="64"
              cy="64"
              r="56"
              stroke="#e5e7eb"
              strokeWidth="12"
              fill="none"
            />
            <circle
              cx="64"
              cy="64"
              r="56"
              stroke={complianceScore >= 90 ? '#10b981' : complianceScore >= 70 ? '#f59e0b' : '#ef4444'}
              strokeWidth="12"
              fill="none"
              strokeDasharray={`${(complianceScore / 100) * 351.86} 351.86`}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-4xl font-bold text-gray-900">{complianceScore}%</span>
          </div>
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">ADA Compliance Score</h2>
        <p className="text-muted">
          {passedChecks} of {totalChecks} checks passed
          {criticalIssues > 0 && ` • ${criticalIssues} critical issues`}
        </p>
      </div>

      {/* Detailed Checks */}
      {checks.map((category, catIndex) => {
        const Icon = category.icon;
        return (
          <div key={catIndex} className="neo-surface p-6 rounded-3xl">
            <div className="flex items-center gap-3 mb-4">
              <Icon className="w-6 h-6 text-indigo-600" />
              <h3 className="text-lg font-bold text-gray-900">{category.category} Accessibility</h3>
            </div>
            <div className="space-y-2">
              {category.items.map((item, itemIndex) => (
                <div key={itemIndex} className="neo-inset p-4 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {item.passed ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      item.critical ? (
                        <XCircle className="w-5 h-5 text-red-600" />
                      ) : (
                        <AlertTriangle className="w-5 h-5 text-yellow-600" />
                      )
                    )}
                    <span className="text-sm font-semibold text-gray-900">{item.name}</span>
                  </div>
                  <span className={`neo-button px-3 py-1 text-xs font-bold ${
                    item.passed ? 'text-green-700' : 
                    item.critical ? 'text-red-700' : 'text-yellow-700'
                  }`}>
                    {item.passed ? 'Pass' : item.critical ? 'Critical' : 'Warning'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {/* Recommendations */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Recommendations</h3>
        <div className="space-y-3">
          <div className="neo-inset p-4 rounded-xl">
            <p className="text-sm text-gray-700">
              ✓ Add descriptive alt text to all images
            </p>
          </div>
          <div className="neo-inset p-4 rounded-xl">
            <p className="text-sm text-gray-700">
              ✓ Implement "Skip to main content" link
            </p>
          </div>
          <div className="neo-inset p-4 rounded-xl">
            <p className="text-sm text-gray-700">
              ✓ Ensure minimum color contrast ratio of 4.5:1
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}