import React, { useState } from "react";
import { Calendar as CalendarIcon, MapPin, Users, DollarSign, Plus } from "lucide-react";
import { format } from "date-fns";

export default function EventCalendarWidget({ events = [], onCreateEvent }) {
  const [showCreate, setShowCreate] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date());

  const upcomingEvents = events
    .filter(e => new Date(e.start_datetime) >= new Date())
    .sort((a, b) => new Date(a.start_datetime) - new Date(b.start_datetime))
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Event Calendar</h2>
            <p className="text-sm text-muted">Manage your school events</p>
          </div>
          <button
            onClick={() => setShowCreate(true)}
            className="neo-button px-6 py-3 gradient-primary text-white font-semibold rounded-xl"
          >
            <Plus className="w-5 h-5 mr-2 inline" />
            Add Event
          </button>
        </div>

        {/* Upcoming Events */}
        <div className="space-y-3">
          {upcomingEvents.map(event => (
            <div key={event.id} className="neo-inset p-4 rounded-xl">
              <div className="flex items-start gap-4">
                <div className="neo-button w-16 h-16 rounded-xl flex flex-col items-center justify-center flex-shrink-0">
                  <span className="text-xs text-muted">
                    {format(new Date(event.start_datetime), 'MMM')}
                  </span>
                  <span className="text-2xl font-bold text-gray-900">
                    {format(new Date(event.start_datetime), 'd')}
                  </span>
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-gray-900 mb-1">{event.title}</h3>
                  <p className="text-sm text-gray-700 mb-2">{event.description}</p>
                  <div className="flex flex-wrap gap-3 text-xs text-muted">
                    <span className="flex items-center gap-1">
                      <CalendarIcon className="w-3 h-3" />
                      {format(new Date(event.start_datetime), 'h:mm a')}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {event.location}
                    </span>
                    {event.max_attendees && (
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {event.current_attendees}/{event.max_attendees}
                      </span>
                    )}
                    {event.price > 0 && (
                      <span className="flex items-center gap-1">
                        <DollarSign className="w-3 h-3" />
                        ${event.price}
                      </span>
                    )}
                  </div>
                </div>
                <span className={`neo-button px-3 py-1 text-xs font-bold ${
                  event.is_published ? 'text-green-700' : 'text-gray-700'
                }`}>
                  {event.is_published ? 'Published' : 'Draft'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Event Types */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Event Types</h3>
        <div className="grid grid-cols-3 gap-3">
          {['class', 'webinar', 'test_day', 'open_house', 'workshop'].map(type => (
            <div key={type} className="neo-inset p-3 rounded-xl text-center">
              <p className="text-sm font-semibold capitalize">{type.replace('_', ' ')}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}