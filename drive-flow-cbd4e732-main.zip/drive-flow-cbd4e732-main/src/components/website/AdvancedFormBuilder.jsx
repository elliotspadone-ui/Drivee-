import React, { useState } from "react";
import { Plus, Trash2, Settings, Eye } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

export default function AdvancedFormBuilder({ form, onUpdate }) {
  const [fields, setFields] = useState(form?.fields || []);
  const [previewMode, setPreviewMode] = useState(false);

  const fieldTypes = [
    { id: "text", label: "Text Input", icon: "T" },
    { id: "email", label: "Email", icon: "@" },
    { id: "phone", label: "Phone", icon: "☎" },
    { id: "select", label: "Dropdown", icon: "▼" },
    { id: "radio", label: "Radio", icon: "○" },
    { id: "checkbox", label: "Checkbox", icon: "☑" },
    { id: "textarea", label: "Text Area", icon: "¶" },
    { id: "date", label: "Date", icon: "📅" }
  ];

  const addField = (type) => {
    const newField = {
      id: `field_${Date.now()}`,
      type,
      label: `New ${type} field`,
      placeholder: "",
      required: false,
      options: type === 'select' || type === 'radio' ? ['Option 1', 'Option 2'] : [],
      conditional_logic: null
    };
    setFields([...fields, newField]);
  };

  const updateField = (id, updates) => {
    setFields(fields.map(f => f.id === id ? { ...f, ...updates } : f));
  };

  const removeField = (id) => {
    setFields(fields.filter(f => f.id !== id));
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const items = Array.from(fields);
    const [reordered] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reordered);
    setFields(items);
  };

  return (
    <div className="space-y-6">
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Form Builder</h2>
            <p className="text-sm text-muted">Drag and drop to reorder fields</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setPreviewMode(!previewMode)}
              className="neo-button px-4 py-2 flex items-center gap-2"
            >
              <Eye className="w-4 h-4" />
              {previewMode ? 'Edit' : 'Preview'}
            </button>
            <button
              onClick={() => onUpdate({ ...form, fields })}
              className="neo-button px-6 py-3 gradient-primary text-white font-semibold rounded-xl"
            >
              Save Form
            </button>
          </div>
        </div>

        {!previewMode ? (
          <>
            {/* Field Types */}
            <div className="grid grid-cols-4 gap-2 mb-6">
              {fieldTypes.map(type => (
                <button
                  key={type.id}
                  onClick={() => addField(type.id)}
                  className="neo-button p-3 rounded-xl text-sm font-semibold hover:bg-indigo-50"
                >
                  <span className="text-lg mr-2">{type.icon}</span>
                  {type.label}
                </button>
              ))}
            </div>

            {/* Fields */}
            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="fields">
                {(provided) => (
                  <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-3">
                    {fields.map((field, index) => (
                      <Draggable key={field.id} draggableId={field.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className="neo-inset p-4 rounded-xl"
                          >
                            <div className="grid grid-cols-3 gap-4">
                              <input
                                type="text"
                                value={field.label}
                                onChange={(e) => updateField(field.id, { label: e.target.value })}
                                className="neo-button px-3 py-2 rounded-lg"
                                placeholder="Field Label"
                              />
                              <input
                                type="text"
                                value={field.placeholder}
                                onChange={(e) => updateField(field.id, { placeholder: e.target.value })}
                                className="neo-button px-3 py-2 rounded-lg"
                                placeholder="Placeholder"
                              />
                              <div className="flex gap-2">
                                <label className="flex items-center gap-2">
                                  <input
                                    type="checkbox"
                                    checked={field.required}
                                    onChange={(e) => updateField(field.id, { required: e.target.checked })}
                                  />
                                  <span className="text-sm">Required</span>
                                </label>
                                <button
                                  onClick={() => removeField(field.id)}
                                  className="neo-button p-2 rounded-lg text-red-600 ml-auto"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>

                            {/* Options for select/radio */}
                            {(field.type === 'select' || field.type === 'radio') && (
                              <div className="mt-3">
                                <label className="text-xs text-muted mb-2 block">Options (comma separated)</label>
                                <input
                                  type="text"
                                  value={field.options.join(', ')}
                                  onChange={(e) => updateField(field.id, { options: e.target.value.split(',').map(o => o.trim()) })}
                                  className="neo-button w-full px-3 py-2 rounded-lg text-sm"
                                />
                              </div>
                            )}
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          </>
        ) : (
          /* Preview */
          <div className="neo-inset p-8 rounded-2xl">
            <h3 className="text-xl font-bold text-gray-900 mb-6">{form.name}</h3>
            <div className="space-y-4">
              {fields.map(field => (
                <div key={field.id}>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    {field.label} {field.required && <span className="text-red-600">*</span>}
                  </label>
                  {field.type === 'textarea' ? (
                    <textarea
                      placeholder={field.placeholder}
                      className="neo-button w-full px-4 py-3 rounded-xl"
                      rows={3}
                    />
                  ) : field.type === 'select' ? (
                    <select className="neo-button w-full px-4 py-3 rounded-xl">
                      <option value="">Select...</option>
                      {field.options.map((opt, i) => (
                        <option key={i} value={opt}>{opt}</option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type={field.type}
                      placeholder={field.placeholder}
                      className="neo-button w-full px-4 py-3 rounded-xl"
                    />
                  )}
                </div>
              ))}
              <button className="neo-button w-full py-4 gradient-primary text-white font-bold rounded-2xl">
                {form.submit_button_text || 'Submit'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}