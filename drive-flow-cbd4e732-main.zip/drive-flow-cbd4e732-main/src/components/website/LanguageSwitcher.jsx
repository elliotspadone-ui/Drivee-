import React, { useState, useEffect } from "react";
import { Globe, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const LANGUAGES = {
  en: { name: "English", flag: "🇺🇸" },
  es: { name: "Español", flag: "🇪🇸" },
  fr: { name: "Français", flag: "🇫🇷" },
  de: { name: "Deutsch", flag: "🇩🇪" },
  it: { name: "Italiano", flag: "🇮🇹" },
  pt: { name: "Português", flag: "🇵🇹" },
  ar: { name: "العربية", flag: "🇸🇦", rtl: true },
  he: { name: "עברית", flag: "🇮🇱", rtl: true },
  zh: { name: "中文", flag: "🇨🇳" },
  ja: { name: "日本語", flag: "🇯🇵" },
  ko: { name: "한국어", flag: "🇰🇷" },
  ru: { name: "Русский", flag: "🇷🇺" },
};

export default function LanguageSwitcher({ 
  availableLanguages = ['en'], 
  currentLanguage = 'en', 
  onLanguageChange,
  className = ""
}) {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const lang = LANGUAGES[currentLanguage];
    if (lang?.rtl) {
      document.documentElement.dir = 'rtl';
    } else {
      document.documentElement.dir = 'ltr';
    }
  }, [currentLanguage]);

  const handleLanguageSelect = (code) => {
    onLanguageChange(code);
    setIsOpen(false);
    localStorage.setItem('preferredLanguage', code);
  };

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="neo-button px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-gray-50 transition-colors"
      >
        <Globe className="w-5 h-5 text-gray-600" />
        <span className="text-2xl">{LANGUAGES[currentLanguage]?.flag}</span>
        <span className="font-medium text-gray-700">{LANGUAGES[currentLanguage]?.name}</span>
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <div 
              className="fixed inset-0 z-40" 
              onClick={() => setIsOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute right-0 mt-2 neo-surface rounded-2xl shadow-xl z-50 overflow-hidden"
              style={{ minWidth: '200px' }}
            >
              {availableLanguages.map((code) => (
                <button
                  key={code}
                  onClick={() => handleLanguageSelect(code)}
                  className={`w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 transition-colors ${
                    code === currentLanguage ? 'bg-indigo-50' : ''
                  }`}
                >
                  <span className="text-2xl">{LANGUAGES[code]?.flag}</span>
                  <span className="flex-1 text-left font-medium text-gray-700">
                    {LANGUAGES[code]?.name}
                  </span>
                  {code === currentLanguage && (
                    <Check className="w-5 h-5 text-indigo-600" />
                  )}
                </button>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

export { LANGUAGES };