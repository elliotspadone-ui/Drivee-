import React from "react";
import { TrendingDown, Users, MousePointer, ShoppingCart, CheckCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

export default function ConversionFunnelTracker({ funnels = [] }) {
  const steps = [
    { name: "Landing Page", key: "landing", icon: MousePointer },
    { name: "Services View", key: "services", icon: Users },
    { name: "Booking Started", key: "booking", icon: ShoppingCart },
    { name: "Converted", key: "converted", icon: CheckCircle }
  ];

  const funnelData = steps.map((step, index) => {
    const count = funnels.filter(f => f.steps?.length > index).length;
    const percentage = (count / funnels.length) * 100;
    return {
      name: step.name,
      value: count,
      percentage: percentage.toFixed(1)
    };
  });

  const dropOffRates = funnelData.map((step, index) => {
    if (index === 0) return 0;
    const prev = funnelData[index - 1].value;
    const dropOff = ((prev - step.value) / prev) * 100;
    return dropOff.toFixed(1);
  });

  return (
    <div className="space-y-6">
      <div className="neo-surface p-6 rounded-3xl">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Conversion Funnel</h2>

        {/* Funnel Visualization */}
        <div className="space-y-3 mb-8">
          {funnelData.map((step, index) => {
            const Icon = steps[index].icon;
            return (
              <div key={index} className="relative">
                <div
                  className="neo-inset p-4 rounded-xl transition-all"
                  style={{ width: `${100 - index * 15}%` }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Icon className="w-5 h-5 text-indigo-600" />
                      <div>
                        <p className="font-semibold text-gray-900">{step.name}</p>
                        <p className="text-xs text-muted">{step.value} visitors</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-gray-900">{step.percentage}%</p>
                      {index > 0 && (
                        <p className="text-xs text-red-600">-{dropOffRates[index]}% drop</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Chart */}
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={funnelData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="name" stroke="#6b7280" />
            <YAxis stroke="#6b7280" />
            <Tooltip />
            <Bar dataKey="value" radius={[8, 8, 0, 0]}>
              {funnelData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={`hsl(${250 - index * 30}, 70%, 60%)`} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Insights */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Key Insights</h3>
        <div className="space-y-3">
          <div className="neo-inset p-4 rounded-xl">
            <p className="text-sm text-gray-700">
              💡 Biggest drop-off occurs at <strong>{steps[dropOffRates.indexOf(Math.max(...dropOffRates.filter((_, i) => i > 0)))].name}</strong>
            </p>
          </div>
          <div className="neo-inset p-4 rounded-xl">
            <p className="text-sm text-gray-700">
              🎯 Overall conversion rate: <strong>{funnelData[funnelData.length - 1].percentage}%</strong>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}