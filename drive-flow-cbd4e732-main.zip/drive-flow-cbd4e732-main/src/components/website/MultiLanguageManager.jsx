import React, { useState } from "react";
import { Globe, Plus, Trash2, CheckCircle } from "lucide-react";

export default function MultiLanguageManager({ website, onUpdate }) {
  const [languages, setLanguages] = useState(website?.languages || [
    { code: 'en', name: 'English', isDefault: true }
  ]);

  const availableLanguages = [
    { code: 'es', name: 'Spanish' },
    { code: 'fr', name: 'French' },
    { code: 'de', name: 'German' },
    { code: 'zh', name: 'Chinese' },
    { code: 'ar', name: 'Arabic' },
    { code: 'pt', name: 'Portuguese' },
    { code: 'ru', name: 'Russian' },
    { code: 'ja', name: 'Japanese' }
  ];

  const addLanguage = (lang) => {
    if (!languages.find(l => l.code === lang.code)) {
      setLanguages([...languages, { ...lang, isDefault: false }]);
    }
  };

  const removeLanguage = (code) => {
    setLanguages(languages.filter(l => l.code !== code));
  };

  const setDefault = (code) => {
    setLanguages(languages.map(l => ({ ...l, isDefault: l.code === code })));
  };

  return (
    <div className="space-y-6">
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex items-center gap-3 mb-6">
          <Globe className="w-8 h-8 text-indigo-600" />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Multi-Language Support</h2>
            <p className="text-sm text-muted">Reach a global audience</p>
          </div>
        </div>

        {/* Active Languages */}
        <div className="space-y-3 mb-6">
          <h3 className="text-sm font-semibold text-gray-900">Active Languages</h3>
          {languages.map(lang => (
            <div key={lang.code} className="neo-inset p-4 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-400 to-purple-400 flex items-center justify-center">
                  <span className="text-white font-bold text-sm">{lang.code.toUpperCase()}</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{lang.name}</p>
                  {lang.isDefault && (
                    <span className="text-xs text-green-600 flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      Default
                    </span>
                  )}
                </div>
              </div>
              <div className="flex gap-2">
                {!lang.isDefault && (
                  <>
                    <button
                      onClick={() => setDefault(lang.code)}
                      className="neo-button px-4 py-2 text-sm"
                    >
                      Set Default
                    </button>
                    <button
                      onClick={() => removeLanguage(lang.code)}
                      className="neo-button p-2 text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Add Language */}
        <div>
          <h3 className="text-sm font-semibold text-gray-900 mb-3">Add Language</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {availableLanguages
              .filter(al => !languages.find(l => l.code === al.code))
              .map(lang => (
                <button
                  key={lang.code}
                  onClick={() => addLanguage(lang)}
                  className="neo-button p-3 rounded-xl text-sm font-semibold hover:bg-indigo-50"
                >
                  <Plus className="w-4 h-4 inline mr-1" />
                  {lang.name}
                </button>
              ))}
          </div>
        </div>

        <button
          onClick={() => onUpdate({ ...website, languages })}
          className="neo-button w-full py-4 gradient-primary text-white font-bold rounded-2xl mt-6"
        >
          Save Languages
        </button>
      </div>

      {/* Translation Tips */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Translation Guidelines</h3>
        <div className="space-y-3">
          <div className="neo-inset p-4 rounded-xl">
            <p className="text-sm text-gray-700">
              📝 All website content will need to be translated for each active language
            </p>
          </div>
          <div className="neo-inset p-4 rounded-xl">
            <p className="text-sm text-gray-700">
              🌍 RTL (Right-to-Left) layout is automatically applied for Arabic
            </p>
          </div>
          <div className="neo-inset p-4 rounded-xl">
            <p className="text-sm text-gray-700">
              🔄 Language switcher will appear in your website header
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}