import React, { useState } from "react";
import { Download, Copy, CheckCircle, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function SitemapGenerator({ website, sections, school }) {
  const [copied, setCopied] = useState(false);

  const generateSitemap = () => {
    const baseUrl = website.custom_domain || `${website.subdomain}.driveschool.com`;
    const protocol = 'https://';
    
    const pages = [
      { url: `${protocol}${baseUrl}`, priority: '1.0', changefreq: 'weekly' },
      { url: `${protocol}${baseUrl}#about`, priority: '0.8', changefreq: 'monthly' },
      { url: `${protocol}${baseUrl}#services`, priority: '0.9', changefreq: 'weekly' },
      { url: `${protocol}${baseUrl}#instructors`, priority: '0.8', changefreq: 'monthly' },
      { url: `${protocol}${baseUrl}#contact`, priority: '0.7', changefreq: 'monthly' },
    ];

    const today = new Date().toISOString().split('T')[0];

    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${pages.map(page => `  <url>
    <loc>${page.url}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
  </url>`).join('\n')}
</urlset>`;

    return sitemap;
  };

  const handleCopy = () => {
    const sitemap = generateSitemap();
    navigator.clipboard.writeText(sitemap);
    setCopied(true);
    toast.success("Sitemap copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const sitemap = generateSitemap();
    const blob = new Blob([sitemap], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sitemap.xml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Sitemap downloaded!");
  };

  const sitemap = generateSitemap();

  return (
    <div className="space-y-6">
      <div className="neo-surface p-6">
        <div className="flex items-center gap-3 mb-4">
          <Globe className="w-6 h-6 text-indigo-600" />
          <h3 className="text-xl font-bold text-gray-900">XML Sitemap</h3>
        </div>
        <p className="text-gray-600 mb-6">
          A sitemap helps search engines discover and index your website pages. Upload this file to Google Search Console.
        </p>

        <div className="flex gap-3 mb-6">
          <Button onClick={handleCopy} className="neo-button px-6 py-3 flex items-center gap-2">
            {copied ? <CheckCircle className="w-5 h-5 text-green-600" /> : <Copy className="w-5 h-5" />}
            {copied ? 'Copied!' : 'Copy Sitemap'}
          </Button>
          <Button onClick={handleDownload} className="neo-button px-6 py-3 flex items-center gap-2">
            <Download className="w-5 h-5" />
            Download XML
          </Button>
        </div>

        <div className="neo-inset p-4 rounded-2xl">
          <pre className="text-xs text-gray-700 overflow-x-auto whitespace-pre-wrap font-mono">
            {sitemap}
          </pre>
        </div>
      </div>

      <div className="neo-surface p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">How to Submit Your Sitemap</h3>
        <ol className="space-y-3 text-sm text-gray-700">
          <li className="flex gap-3">
            <span className="font-bold text-indigo-600 flex-shrink-0">1.</span>
            <span>Download the sitemap.xml file using the button above</span>
          </li>
          <li className="flex gap-3">
            <span className="font-bold text-indigo-600 flex-shrink-0">2.</span>
            <span>Go to <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer" className="text-indigo-600 underline">Google Search Console</a></span>
          </li>
          <li className="flex gap-3">
            <span className="font-bold text-indigo-600 flex-shrink-0">3.</span>
            <span>Select your property (website)</span>
          </li>
          <li className="flex gap-3">
            <span className="font-bold text-indigo-600 flex-shrink-0">4.</span>
            <span>Navigate to Sitemaps in the left menu</span>
          </li>
          <li className="flex gap-3">
            <span className="font-bold text-indigo-600 flex-shrink-0">5.</span>
            <span>Submit your sitemap URL or upload the file</span>
          </li>
        </ol>
      </div>

      <div className="neo-surface p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Pages Included</h3>
        <div className="space-y-2">
          {sections.filter(s => s.is_visible).map((section) => (
            <div key={section.id} className="flex items-center gap-3 p-3 neo-inset rounded-xl">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-semibold text-gray-900 capitalize">{section.section_type}</p>
                <p className="text-sm text-gray-600">{section.title}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}