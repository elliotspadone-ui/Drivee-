// ============================================
// I18N CONFIGURATION MODULE
// ============================================
// Lightweight i18n solution for Drivee driving school platform

import React from 'react';

// ============================================
// LANGUAGE CONFIGURATION
// ============================================

export const LANGUAGE_CODES = ['en', 'fr', 'de', 'it', 'nl'];

export const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧', direction: 'ltr' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷', direction: 'ltr' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪', direction: 'ltr' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', flag: '🇮🇹', direction: 'ltr' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands', flag: '🇳🇱', direction: 'ltr' },
];

// ============================================
// HELPER FUNCTIONS
// ============================================

function isLanguageCode(value) {
  return typeof value === 'string' && LANGUAGE_CODES.includes(value);
}

function isPluralForms(value) {
  if (typeof value !== 'object' || value === null) return false;
  return typeof value.one === 'string' && typeof value.other === 'string';
}

// ============================================
// TRANSLATION STORE
// ============================================

const translations = {
  en: {},
  fr: {},
  de: {},
  it: {},
  nl: {},
};

// ============================================
// STATE MANAGEMENT
// ============================================

let currentLanguage = (() => {
  if (typeof window === 'undefined') return 'en';
  try {
    const saved = localStorage.getItem('drivee_language');
    if (saved && isLanguageCode(saved)) return saved;
  } catch (e) {}
  return 'en';
})();

let listeners = new Set();

// ============================================
// ENGLISH TRANSLATIONS
// ============================================

translations.en = {
  common: {
    loading: "Loading...",
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    create: "Create",
    search: "Search",
    filter: "Filter",
    viewAll: "View All",
    back: "Back",
    next: "Next",
    submit: "Submit",
    confirm: "Confirm",
    close: "Close",
    yes: "Yes",
    no: "No",
    or: "or",
    and: "and",
    error: "Error",
    success: "Success",
    warning: "Warning",
    info: "Info",
    required: "Required",
    optional: "Optional",
    lesson: { one: "{{count}} lesson", other: "{{count}} lessons" },
    hour: { one: "{{count}} hour", other: "{{count}} hours" },
    student: { one: "{{count}} student", other: "{{count}} students" },
    instructor: { one: "{{count}} instructor", other: "{{count}} instructors" },
    vehicle: { one: "{{count}} vehicle", other: "{{count}} vehicles" },
    day: { one: "{{count}} day", other: "{{count}} days" },
  },

  nav: {
    dashboard: "Dashboard",
    schedule: "Schedule",
    students: "Students",
    instructors: "Instructors",
    fleet: "Fleet",
    finance: "Finance",
    packages: "Packages",
    invoices: "Invoices",
    theory: "Theory",
    courses: "Courses",
    marketing: "Marketing",
    website: "Website",
    reviews: "Reviews",
    settings: "Settings",
    reports: "Reports",
    analytics: "Analytics",
    messages: "Messages",
    profile: "Profile",
    logout: "Sign out",
    support: "Support",
  },

  landing: {
    hero: {
      badge: "Europe's #1 Driving School Marketplace",
      title: "Find your perfect",
      titleHighlight: "driving school",
      subtitle: "Compare 850+ verified schools, read real reviews, and book your first lesson in minutes. All at the best prices.",
      searchPlaceholder: "City or postcode",
      schoolPlaceholder: "School or instructor",
      allTypes: "All Types",
      searchButton: "Search",
      freeToUse: "Free to use",
      verifiedSchools: "Verified schools",
      bestPrices: "Best prices",
    },
    quickFilters: {
      topRated: "Top Rated",
      bestValue: "Best Value",
      availableThisWeek: "Available This Week",
      beginnerFriendly: "Beginner Friendly",
      englishSpeaking: "English Speaking",
      automaticOnly: "Automatic Only",
      intensiveCourses: "Intensive Courses",
      nearMe: "Near Me",
    },
    categories: {
      title: "Find the perfect course for you",
      subtitle: "Browse by Category",
      carLicense: "Car License (B)",
      motorcycle: "Motorcycle (A)",
      automatic: "Automatic",
      intensiveCourses: "Intensive Courses",
      theoryTraining: "Theory Training",
      fullPackages: "Full Packages",
      schools: "schools",
    },
    locations: {
      title: "Schools near you",
      subtitle: "Popular Locations",
    },
    howItWorks: {
      title: "How DRIVEE works",
      subtitle: "Your journey to getting licensed in 3 simple steps",
      step1Title: "Search & Compare",
      step1Desc: "Find schools by location, price, vehicle type, instructor language, and availability. Filter by ratings and reviews.",
      step1Tip: "Use advanced filters to find your perfect match",
      step2Title: "Book & Pay Securely",
      step2Desc: "Reserve lessons online 24/7 with instant confirmation. Flexible payment options and secure checkout.",
      step2Tip: "Get instant booking confirmation via email & SMS",
      step3Title: "Learn & Track Progress",
      step3Desc: "Attend lessons, track your progress in real-time, and prepare for your test with confidence.",
      step3Tip: "Access your learning dashboard anytime, anywhere",
      cta: "Start Your Journey",
    },
    features: {
      title: "Why students choose DRIVEE",
      subtitle: "Everything you need to find, book, and complete your driving course with confidence",
      verified: "Verified driving schools",
      verifiedDesc: "Only licensed, certified, and professionally vetted schools with insurance coverage.",
      verifiedBenefit: "100% safety guaranteed",
      transparent: "Transparent pricing",
      transparentDesc: "Compare package prices, hourly rates, and special offers. No hidden fees or surprises.",
      transparentBenefit: "Save up to 30%",
      flexible: "Flexible booking",
      flexibleDesc: "Book or reschedule your lessons in one tap. Free cancellation up to 24h before.",
      flexibleBenefit: "24/7 availability",
      progress: "Progress tracking",
      progressDesc: "Track completed lessons, upcoming sessions, exam preparation, and performance analytics.",
      progressBenefit: "Data-driven learning",
      communication: "Instant communication",
      communicationDesc: "Chat directly with instructors, get quick responses, and coordinate seamlessly.",
      communicationBenefit: "Real-time support",
      quality: "Quality assurance",
      qualityDesc: "Verified reviews, instructor ratings, and pass rate statistics for informed decisions.",
      qualityBenefit: "95%+ satisfaction",
    },
    testimonials: {
      title: "What our students say",
      basedOn: "Based on 12,450+ verified reviews",
      real: "Real students, real experiences",
      readAll: "Read all 12,450+ reviews",
    },
    faq: {
      title: "Frequently Asked Questions",
      subtitle: "Everything you need to know about using DRIVEE",
      stillHaveQuestions: "Still have questions?",
      contactSupport: "Contact Support",
      q1: "How do I find and book a driving school?",
      a1: "Simply enter your location, browse verified schools, compare prices and reviews, then book online instantly. You'll receive confirmation within minutes.",
      q2: "Is DRIVEE free to use?",
      a2: "Yes! DRIVEE is completely free for students. We partner with driving schools who pay a small fee for the booking platform.",
      q3: "Can I cancel or reschedule my lessons?",
      a3: "Yes, you can cancel or reschedule up to 24 hours before your lesson for free. Check each school's specific cancellation policy for details.",
      q4: "How do I track my learning progress?",
      a4: "Your personal dashboard shows completed lessons, upcoming bookings, skill assessments, and exam readiness all in one place.",
      q5: "Are all driving schools verified?",
      a5: "Yes, every school on DRIVEE is verified for proper licensing, insurance, and professional standards before being listed.",
      q6: "What payment methods are accepted?",
      a6: "We accept all major credit/debit cards, bank transfers, and popular digital payment methods. All transactions are secured with bank-level encryption.",
    },
    cta: {
      schoolsTitle: "Own a driving school?",
      schoolsDesc: "Join 850+ schools using DRIVEE to manage bookings, instructors, payments, and fleet. Grow your revenue by 40%.",
      exploreForSchools: "Explore Drivee for Schools",
      watchDemo: "Watch Demo",
      readyTitle: "Ready to start driving?",
      readyDesc: "Join 25,000+ students who found their perfect driving school on DRIVEE",
      findSchool: "Find Your School Now",
      noCard: "✓ Free to use  ✓ No credit card required  ✓ 2 minutes to book",
    },
    footer: {
      description: "Europe's leading driving school marketplace. Compare, book, and learn with confidence.",
      forStudents: "For Students",
      findSchools: "Find Schools",
      howItWorks: "How It Works",
      pricing: "Pricing",
      forSchools: "For Schools",
      businessSolutions: "Business Solutions",
      schoolLogin: "School Login",
      features: "Features",
      successStories: "Success Stories",
      support: "Support",
      helpCenter: "Help Center",
      contactUs: "Contact Us",
      privacyPolicy: "Privacy Policy",
      termsOfService: "Terms of Service",
      cookies: "Cookies",
      copyright: "© 2025 Drivee. All rights reserved. Made with ❤️ in Europe.",
    },
    navbar: {
      forSchools: "For Schools",
      signIn: "Sign In",
    },
  },

  studentDashboard: {
    greeting: {
      morning: "Good morning",
      afternoon: "Good afternoon",
      evening: "Good evening",
    },
    licenseGoal: "License Goal: Category B (Car)",
    courseComplete: "Course Complete",
    bookLesson: "Book Lesson",
    noLessons: {
      title: "Ready to drive?",
      subtitle: "You have no upcoming lessons scheduled. Maintain your momentum by booking a slot today.",
    },
    nextLesson: "Next Lesson",
    instructor: "Instructor",
    pickup: "Pickup",
    contactInstructor: "Contact Instructor",
    startLesson: "Start Lesson",
    stats: {
      hoursDriven: "Hours Driven",
      remaining: "remaining",
      lessonsDone: "Lessons Done",
      thisWeek: "this week",
      creditsLeft: "Credits Left",
      prepaidLessons: "Prepaid lessons",
      outstanding: "Outstanding",
    },
    competencies: {
      title: "Driving Competencies",
      viewReport: "View Report",
      vehicleControl: "Vehicle Control",
      clutchControl: "Clutch Control",
      steering: "Steering",
      gearChanging: "Gear Changing",
      roadProcedure: "Road Procedure",
      junctions: "Junctions",
      roundabouts: "Roundabouts",
      hazardPerception: "Hazard Perception",
    },
    progress: {
      registration: "Registration",
      theoryTest: "Theory Test",
      lessonHours: "Lesson Hours",
      preTest: "Pre-Test",
      practicalTest: "Practical Test",
    },
    schedule: {
      title: "Upcoming Schedule",
      noLessons: "No upcoming lessons",
      practicalLesson: "Practical Lesson",
    },
    theory: {
      dailyGoal: "Daily Goal",
      title: "Theory Refresh",
      subtitle: "Complete today's mock questions to keep your knowledge sharp.",
      startPractice: "Start Practice",
    },
    quickLinks: {
      invoices: "Invoices",
      profile: "Profile",
      topUp: "Top Up",
      certificates: "Certificates",
    },
  },

  auth: {
    welcomeBack: "Welcome back",
    signInSubtitle: "Sign in to access your driving school dashboard",
    createAccount: "Create your account",
    createAccountSubtitle: "Start your 14-day free trial, no credit card required",
    resetPassword: "Reset your password",
    resetPasswordSubtitle: "Enter your email to receive a reset link",
    email: "Email Address",
    password: "Password",
    confirmPassword: "Confirm Password",
    fullName: "Full Name",
    phone: "Phone Number",
    schoolName: "School Name",
    operatingCountry: "Country of Operation",
    operatingCountryHelp: "This determines tax settings, currency, and available features",
    preferredLanguage: "Preferred Language",
    rememberMe: "Remember me",
    forgotPassword: "Forgot password?",
    signIn: "Sign in",
    signingIn: "Signing in...",
    createAccountBtn: "Create account",
    creatingAccount: "Creating account...",
    sendResetLink: "Send reset link",
    sendingEmail: "Sending email...",
    orContinueWith: "Or continue with",
    noAccount: "Don't have an account?",
    signUpFree: "Sign up for free",
    hasAccount: "Already have an account?",
    rememberPassword: "Remember your password?",
    termsAgree: "I agree to the",
    termsOfService: "Terms of Service",
    privacyPolicy: "Privacy Policy",
    checkInbox: "Check your inbox",
    resetEmailSent: "We've sent a password reset link to",
    backToSignIn: "Back to sign in",
    securityInfo: "256-bit SSL encryption • GDPR compliant • SOC 2 certified",
  },

  settings: {
    title: "Settings",
    subtitle: "Configure your school and platform preferences",
    tabs: {
      general: "General",
      generalDesc: "School information and contact details",
      booking: "Booking",
      bookingDesc: "Scheduling and availability settings",
      modules: "Modules",
      modulesDesc: "Enable or disable platform features",
      notifications: "Notifications",
      notificationsDesc: "Email and SMS preferences",
      branding: "Branding",
      brandingDesc: "Customize your brand appearance",
      billing: "Billing",
      billingDesc: "Subscription and payment history",
      security: "Security",
      securityDesc: "Account and data security",
      integrations: "Integrations",
      integrationsDesc: "Third-party connections",
    },
    location: {
      title: "Location of Operation",
      subtitle: "This setting controls tax behavior, currency, and country-specific features",
      operatingCountry: "Operating Country",
    },
    school: {
      title: "School Information",
      subtitle: "Basic details about your driving school",
      name: "School Name",
      email: "Email",
      phone: "Phone",
      website: "Website",
      address: "Address",
      city: "City",
      postalCode: "Postal Code",
      country: "Country",
      taxId: "Tax ID / VAT Number",
      currency: "Currency",
      description: "Description",
      descriptionPlaceholder: "Tell students about your driving school...",
    },
    businessHours: {
      title: "Business Hours",
      subtitle: "Set your operating hours for each day",
      open: "Open",
      closed: "Closed",
      to: "to",
    },
    saveChanges: "Save Changes",
    saving: "Saving...",
  },

  booking: {
    rulesTitle: "Booking Rules",
    rulesSubtitle: "Configure how students can book lessons",
    allowOnline: "Allow Online Booking",
    allowOnlineDesc: "Let students book lessons through your booking page",
    autoConfirm: "Auto-Confirm Bookings",
    autoConfirmDesc: "Automatically confirm new bookings without manual approval",
    requirePayment: "Require Payment Upfront",
    requirePaymentDesc: "Students must pay when booking a lesson",
    minNotice: "Minimum Notice (hours)",
    minNoticeHelp: "How far in advance students must book",
    maxAdvance: "Maximum Advance Booking (days)",
    maxAdvanceHelp: "How far ahead students can book",
    cancellationNotice: "Cancellation Notice (hours)",
    cancellationNoticeHelp: "Minimum notice for cancellations",
    defaultDuration: "Default Lesson Duration",
    defaultDurationSuffix: "min",
    defaultDurationHelp: "Standard lesson length",
    buffer: "Buffer Between Lessons",
    bufferSuffix: "min",
    bufferHelp: "Break time between lessons",
  },

  payments: {
    title: "Payment Settings",
    subtitle: "Configure payment methods and terms",
    acceptCash: "Accept Cash",
    acceptCashDesc: "Allow cash payments for lessons",
    acceptCard: "Accept Card Payments",
    acceptCardDesc: "Accept credit/debit cards",
    acceptBank: "Accept Bank Transfer",
    acceptBankDesc: "Allow direct bank transfers",
    terms: "Payment Terms",
    termsSuffix: "days",
    lateFee: "Late Fee",
    lateFeeSuffix: "%",
    taxRate: "Tax Rate",
    taxRateSuffix: "%",
  },

  localeSelector: {
    title: "Select your country and language",
    subtitle: "This affects currency, formatting, and available features",
    saved: "Your preference will be saved for future visits",
  },

  languageSelector: {
    label: "Language",
  },

  ants: {
    title: "ANTS Dossiers",
    subtitle: "Manage NEPH number requests for your students",
    disclaimer: "This feature prepares, collects and tracks your ANTS dossier, but does not replace the official ANTS website.",
    statuses: {
      draft: "Draft",
      waitingStudentInput: "Waiting for Student",
      readyForReview: "Ready for Review",
      readyToSend: "Ready to Send to ANTS",
      sentToAnts: "Sent to ANTS",
      awaitingActivation: "Awaiting Student Activation",
      accepted: "Accepted by ANTS",
      rejected: "Rejected by ANTS",
      needsCorrection: "Needs Correction",
    },
  },

  finance: {
    title: "Finance",
    revenue: "Revenue",
    expenses: "Expenses",
    profit: "Profit",
    invoices: "Invoices",
    payments: "Payments",
    taxSummary: "Tax Summary",
    vat: "VAT",
    salesTax: "Sales Tax",
  },

  days: {
    monday: "Monday",
    tuesday: "Tuesday",
    wednesday: "Wednesday",
    thursday: "Thursday",
    friday: "Friday",
    saturday: "Saturday",
    sunday: "Sunday",
    mon: "Mon",
    tue: "Tue",
    wed: "Wed",
    thu: "Thu",
    fri: "Fri",
    sat: "Sat",
    sun: "Sun",
  },

  dashboard: {
    title: "Business Overview",
    subtitle: "Real-time insights into your driving school operations",
    live: "Live",
    reports: "Reports",
    alerts: {
      overdueInvoice: "Overdue Invoice",
      overdueInvoices: "Overdue Invoices",
      paymentFollowup: "Payment follow-up required",
      pendingPayment: "Pending Payment",
      pendingPayments: "Pending Payments",
      awaitingConfirmation: "Awaiting confirmation",
      studentExamReady: "Student Exam Ready",
      studentsExamReady: "Students Exam Ready",
      progressOver80: "Progress over 80% - ready for practical exam",
      vehicleNeedService: "Vehicle Needs Service",
      vehiclesNeedService: "Vehicles Need Service",
      maintenanceDue: "Scheduled maintenance due within 7 days",
      viewInvoices: "View Invoices",
      viewPayments: "View Payments",
      viewStudents: "View Students",
      viewFleet: "View Fleet",
    },
    stats: {
      monthlyRevenue: "Monthly Revenue",
      todaysLessons: "Today's Lessons",
      activeStudents: "Active Students",
      fleetAvailable: "Fleet Available",
      completionRate: "Completion Rate",
      monthlyBookings: "Monthly Bookings",
      activeInstructors: "Active Instructors",
      avgRating: "Avg. Rating",
      pendingPayments: "Pending Payments",
    },
    quickActions: {
      title: "Quick Actions",
      scheduleLesson: "Schedule Lesson",
      scheduleLessonDesc: "Book a new driving lesson",
      addStudent: "Add Student",
      addStudentDesc: "Register a new student",
      recordPayment: "Record Payment",
      recordPaymentDesc: "Log a payment received",
      createInvoice: "Create Invoice",
      createInvoiceDesc: "Generate a new invoice",
    },
    topInstructors: "Top Instructors",
    fleetStatus: "Fleet Status",
    manageFleet: "Manage Fleet",
    allVehiclesReady: "All Vehicles Ready",
    noMaintenancePending: "No maintenance or issues pending",
    thisWeek: "This Week",
    viewCalendar: "View Calendar",
    upcomingLessons: "Upcoming Lessons",
    viewAll: "View All",
    noUpcomingLessons: "No upcoming lessons scheduled",
    scheduleALesson: "Schedule a Lesson",
    today: "Today",
    tomorrow: "Tomorrow",
    lesson: "lesson",
    lessons: "lessons",
    viewDetails: "View Details",
  },

  layout: {
    searchPlaceholder: "Search pages, students, or bookings...",
    esc: "ESC",
    typeToSearch: "Type to search across the platform",
    noResults: "No results found for",
    currentView: "Current View",
    instructorPortal: "Instructor Portal",
    studentPortal: "Student Portal",
    adminConsole: "Admin Console",
    collapseSidebar: "Collapse sidebar",
    expandSidebar: "Expand sidebar",
    search: "Search...",
    create: "Create",
    newBooking: "New Booking",
    addStudent: "Add Student",
    createInvoice: "Create Invoice",
    sendMessage: "Send Message",
    loadingUser: "Loading...",
    backToHome: "Back to Home",
    markedAsRead: "Marked as read",
    failedToMarkRead: "Failed to mark notification as read",
    failedToLogout: "Failed to logout",
    failedToUpdateLang: "Failed to update language preference",
    notifications: "Notifications",
  },

  businessSolutions: {
    navbar: {
      forSchools: "For Schools",
      signIn: "Sign In",
    },
    hero: {
      badge: "Trusted by 1,200+ schools • 98% retention rate",
      title: "The Complete Platform",
      titleHighlight: "for Modern Driving Schools",
      subtitle: "Automate scheduling, payments, and student management. Grow your revenue by 40% while saving 20+ hours every week.",
      startTrial: "Start Free 30-Day Trial",
      watchDemo: "Watch 2-Min Demo",
      noCreditCard: "No credit card required",
      setupTime: "Setup in 30 minutes",
      moneyBack: "30-day money-back guarantee",
    },
    stats: {
      activeSchools: "Active Schools",
      studentsDaily: "Students Daily",
      retentionRate: "Retention Rate",
      avgRevenueGrowth: "Avg Revenue Growth",
    },
    problem: {
      title: "Running a driving school shouldn't feel this chaotic",
      subtitle: "You started your school to teach driving, not to drown in spreadsheets and admin work.",
      doubleBookings: "Double bookings and scheduling conflicts",
      endlessCalls: "Endless phone calls for bookings and changes",
      chasingPayments: "Chasing payments and messy invoicing",
      lostProgress: "Lost student progress and incomplete records",
      noVisibility: "No visibility into business performance",
      hoursWasted: "Hours wasted on spreadsheets and paperwork",
      costingYou: "Costing you time and money every day",
      averageLoss: "The average school loses €2,000+ monthly to these inefficiencies",
    },
    solution: {
      title: "Everything your driving school needs in one powerful platform",
      subtitle: "DRIVEE automates the busywork so you can focus on teaching and growing your business.",
      keyFeatures: "Key Features:",
    },
    results: {
      title: "Real Results from Real Schools",
      subtitle: "See the measurable impact DRIVEE has on driving schools like yours",
      revenueIncrease: "Revenue Increase",
      revenueSubtitle: "average in first 6 months",
      fewerNoShows: "Fewer No-Shows",
      noShowsSubtitle: "with automated reminders",
      hoursSaved: "Hours Saved",
      hoursSavedSubtitle: "every week on admin",
      customerSatisfaction: "Customer Satisfaction",
      satisfactionSubtitle: "from our school partners",
      avgROI: "Average ROI achieved in under 30 days",
    },
    roles: {
      title: "Built for everyone in your driving school",
      subtitle: "From owners to instructors to students, DRIVEE makes everyone's job easier",
      forOwners: "For School Owners",
      forInstructors: "For Instructors",
      forStudents: "For Students",
    },
    onboarding: {
      title: "Up and running in 30 minutes, not 30 days",
      subtitle: "Our guided setup process makes onboarding a breeze. No technical skills required.",
      step1Title: "Import Your Data",
      step1Desc: "Easily migrate your existing student records, instructor schedules, and vehicle information with our guided import wizard or CSV upload.",
      step2Title: "Customize Your Setup",
      step2Desc: "Configure your pricing, availability, booking rules, and branding. Our team helps you get everything perfect for your school.",
      step3Title: "Go Live & Grow",
      step3Desc: "Launch your online booking system, invite your team, and start accepting bookings. We'll be with you every step of the way.",
      freeOnboarding: "Free guided onboarding included • No credit card required",
    },
    testimonials: {
      title: "What school owners are saying",
      subtitle: "Join 1,200+ successful schools already using DRIVEE",
    },
    pricing: {
      title: "Simple, transparent pricing",
      subtitle: "Choose the plan that fits your school. All plans include a 30-day free trial.",
      monthly: "Monthly",
      annual: "Annual",
      save17: "Save 17%",
      perMonth: "per month",
      perYear: "per year",
      mostPopular: "MOST POPULAR",
      startTrial: "Start Free Trial",
      scheduleDemo: "Schedule Demo",
      allPlansInclude: "All plans include:",
      freeTrial: "30-day free trial",
      noCreditCard: "No credit card required",
      cancelAnytime: "Cancel anytime",
      support247: "24/7 customer support",
      regularUpdates: "Regular updates",
    },
    faq: {
      title: "Frequently Asked Questions",
      subtitle: "Everything you need to know about DRIVEE",
      stillHaveQuestions: "Still have questions?",
      talkToTeam: "Talk to Our Team",
    },
    security: {
      title: "Enterprise-grade security for schools of all sizes",
      subtitle: "Your data is protected by the same security standards used by banks and healthcare providers",
      gdprCompliant: "GDPR Compliant",
      gdprDesc: "Full EU data protection",
      encryption: "Bank-Level Encryption",
      encryptionDesc: "256-bit SSL/TLS",
      backups: "Daily Backups",
      backupsDesc: "Automated & secure",
      soc2: "SOC 2 Certified",
      soc2Desc: "Type II compliant",
      uptime: "99.9% Uptime",
      uptimeDesc: "Guaranteed SLA",
      iso: "ISO 27001",
      isoDesc: "Information security",
    },
    cta: {
      title: "Ready to transform your driving school?",
      subtitle: "Join 1,200+ successful schools already using DRIVEE. Start your free 30-day trial today—no credit card required.",
      startTrial: "Start Free Trial",
      scheduleDemo: "Schedule a Demo",
    },
    footer: {
      description: "The complete platform for modern driving schools across Europe.",
      product: "Product",
      pricing: "Pricing",
      scheduleDemo: "Schedule Demo",
      features: "Features",
      company: "Company",
      aboutUs: "About Us",
      contact: "Contact",
      careers: "Careers",
      legal: "Legal",
      privacyPolicy: "Privacy Policy",
      termsOfService: "Terms of Service",
      gdpr: "GDPR",
      copyright: "© 2025 Drivee. All rights reserved. Made with ❤️ for driving schools across Europe.",
    },
  },

  validation: {
    required: "This field is required",
    email: "Please enter a valid email address",
    phone: "Please enter a valid phone number",
    minLength: "Must be at least {{min}} characters",
    maxLength: "Must be no more than {{max}} characters",
    passwordMatch: "Passwords do not match",
    invalidDate: "Please enter a valid date",
    futureDate: "Date must be in the future",
    pastDate: "Date must be in the past",
  },

  errors: {
    generic: "Something went wrong. Please try again.",
    network: "Network error. Please check your connection.",
    unauthorized: "You are not authorized to perform this action.",
    notFound: "The requested resource was not found.",
    serverError: "Server error. Please try again later.",
    timeout: "Request timed out. Please try again.",
  },
};

// ============================================
// FRENCH TRANSLATIONS
// ============================================

translations.fr = {
  common: {
    loading: "Chargement...",
    save: "Enregistrer",
    cancel: "Annuler",
    delete: "Supprimer",
    edit: "Modifier",
    create: "Créer",
    search: "Rechercher",
    filter: "Filtrer",
    viewAll: "Voir tout",
    back: "Retour",
    next: "Suivant",
    submit: "Soumettre",
    confirm: "Confirmer",
    close: "Fermer",
    yes: "Oui",
    no: "Non",
    or: "ou",
    and: "et",
    error: "Erreur",
    success: "Succès",
    warning: "Attention",
    info: "Info",
    required: "Obligatoire",
    optional: "Facultatif",
    lesson: { one: "{{count}} leçon", other: "{{count}} leçons" },
    hour: { one: "{{count}} heure", other: "{{count}} heures" },
    student: { one: "{{count}} élève", other: "{{count}} élèves" },
    instructor: { one: "{{count}} moniteur", other: "{{count}} moniteurs" },
    vehicle: { one: "{{count}} véhicule", other: "{{count}} véhicules" },
    day: { one: "{{count}} jour", other: "{{count}} jours" },
  },

  nav: {
    dashboard: "Tableau de bord",
    schedule: "Planning",
    students: "Élèves",
    instructors: "Moniteurs",
    fleet: "Flotte",
    finance: "Finances",
    packages: "Forfaits",
    invoices: "Factures",
    theory: "Code",
    courses: "Formations",
    marketing: "Marketing",
    website: "Site web",
    reviews: "Avis",
    settings: "Paramètres",
    reports: "Rapports",
    analytics: "Analyses",
    messages: "Messages",
    profile: "Profil",
    logout: "Déconnexion",
    support: "Support",
  },

  landing: {
    hero: {
      badge: "La plateforme #1 des auto-écoles en Europe",
      title: "Trouvez votre",
      titleHighlight: "auto-école idéale",
      subtitle: "Comparez plus de 850 auto-écoles vérifiées, lisez de vrais avis et réservez votre première leçon en quelques minutes. Aux meilleurs prix.",
      searchPlaceholder: "Ville ou code postal",
      schoolPlaceholder: "École ou moniteur",
      allTypes: "Tous types",
      searchButton: "Rechercher",
      freeToUse: "Gratuit",
      verifiedSchools: "Écoles vérifiées",
      bestPrices: "Meilleurs prix",
    },
    quickFilters: {
      topRated: "Mieux notées",
      bestValue: "Meilleur rapport qualité-prix",
      availableThisWeek: "Disponible cette semaine",
      beginnerFriendly: "Adapté aux débutants",
      englishSpeaking: "Anglophone",
      automaticOnly: "Boîte automatique",
      intensiveCourses: "Formations intensives",
      nearMe: "Près de moi",
    },
    categories: {
      title: "Trouvez la formation parfaite",
      subtitle: "Parcourir par catégorie",
    },
    locations: {
      title: "Auto-écoles près de chez vous",
      subtitle: "Villes populaires",
    },
    howItWorks: {
      title: "Comment fonctionne DRIVEE",
      subtitle: "Votre parcours vers le permis en 3 étapes simples",
      step1Title: "Recherchez & Comparez",
      step1Desc: "Trouvez des auto-écoles par lieu, prix, type de véhicule, langue du moniteur et disponibilité.",
      step1Tip: "Utilisez les filtres avancés pour trouver votre match parfait",
      step2Title: "Réservez & Payez en sécurité",
      step2Desc: "Réservez des leçons en ligne 24h/24 avec confirmation instantanée.",
      step2Tip: "Recevez une confirmation instantanée par email et SMS",
      step3Title: "Apprenez & Suivez vos progrès",
      step3Desc: "Suivez vos leçons, votre progression en temps réel et préparez votre examen en toute confiance.",
      step3Tip: "Accédez à votre tableau de bord n'importe où",
      cta: "Commencez votre parcours",
    },
    features: {
      title: "Pourquoi les élèves choisissent DRIVEE",
      subtitle: "Tout ce dont vous avez besoin pour trouver, réserver et réussir votre formation",
      verified: "Auto-écoles vérifiées",
      verifiedDesc: "Uniquement des écoles agréées, certifiées et vérifiées professionnellement.",
      verifiedBenefit: "Sécurité 100% garantie",
      transparent: "Tarifs transparents",
      transparentDesc: "Comparez les prix des forfaits, tarifs horaires et offres spéciales.",
      transparentBenefit: "Économisez jusqu'à 30%",
      flexible: "Réservation flexible",
      flexibleDesc: "Réservez ou reportez vos leçons en un clic. Annulation gratuite jusqu'à 24h avant.",
      flexibleBenefit: "Disponibilité 24h/24",
      progress: "Suivi de progression",
      progressDesc: "Suivez les leçons effectuées, les séances à venir et vos performances.",
      progressBenefit: "Apprentissage basé sur les données",
      communication: "Communication instantanée",
      communicationDesc: "Discutez directement avec les moniteurs.",
      communicationBenefit: "Support en temps réel",
      quality: "Assurance qualité",
      qualityDesc: "Avis vérifiés, notes des moniteurs et statistiques de réussite.",
      qualityBenefit: "95%+ de satisfaction",
    },
    testimonials: {
      title: "Ce que disent nos élèves",
      basedOn: "Basé sur plus de 12 450 avis vérifiés",
      real: "De vrais élèves, de vraies expériences",
      readAll: "Lire tous les avis",
    },
    faq: {
      title: "Questions fréquentes",
      subtitle: "Tout ce que vous devez savoir sur DRIVEE",
      stillHaveQuestions: "Vous avez encore des questions ?",
      contactSupport: "Contacter le support",
    },
    cta: {
      schoolsTitle: "Vous êtes une auto-école ?",
      schoolsDesc: "Rejoignez plus de 850 auto-écoles qui utilisent DRIVEE.",
      exploreForSchools: "Découvrir Drivee pour les écoles",
      watchDemo: "Voir la démo",
      readyTitle: "Prêt à conduire ?",
      readyDesc: "Rejoignez plus de 25 000 élèves qui ont trouvé leur auto-école idéale",
      findSchool: "Trouvez votre école maintenant",
      noCard: "✓ Gratuit  ✓ Pas de carte bancaire requise  ✓ 2 minutes pour réserver",
    },
    footer: {
      description: "La première marketplace d'auto-écoles en Europe.",
      forStudents: "Pour les élèves",
      findSchools: "Trouver une école",
      howItWorks: "Comment ça marche",
      pricing: "Tarifs",
      forSchools: "Pour les écoles",
      businessSolutions: "Solutions professionnelles",
      schoolLogin: "Connexion école",
      features: "Fonctionnalités",
      successStories: "Témoignages",
      support: "Support",
      helpCenter: "Centre d'aide",
      contactUs: "Nous contacter",
      privacyPolicy: "Politique de confidentialité",
      termsOfService: "Conditions d'utilisation",
      cookies: "Cookies",
      copyright: "© 2025 Drivee. Tous droits réservés.",
    },
    navbar: {
      forSchools: "Pour les écoles",
      signIn: "Connexion",
    },
  },

  studentDashboard: {
    greeting: {
      morning: "Bonjour",
      afternoon: "Bon après-midi",
      evening: "Bonsoir",
    },
    licenseGoal: "Objectif : Permis B (Voiture)",
    courseComplete: "Formation terminée",
    bookLesson: "Réserver une leçon",
    noLessons: {
      title: "Prêt à conduire ?",
      subtitle: "Vous n'avez pas de leçon programmée. Réservez un créneau dès aujourd'hui.",
    },
    nextLesson: "Prochaine leçon",
    instructor: "Moniteur",
    pickup: "Point de rendez-vous",
    contactInstructor: "Contacter le moniteur",
    startLesson: "Démarrer la leçon",
    stats: {
      hoursDriven: "Heures de conduite",
      remaining: "restantes",
      lessonsDone: "Leçons effectuées",
      thisWeek: "cette semaine",
      creditsLeft: "Crédits restants",
      prepaidLessons: "Leçons prépayées",
      outstanding: "À payer",
    },
    competencies: {
      title: "Compétences de conduite",
      viewReport: "Voir le rapport",
    },
    progress: {
      registration: "Inscription",
      theoryTest: "Examen du code",
      lessonHours: "Heures de conduite",
      preTest: "Pré-examen",
      practicalTest: "Examen pratique",
    },
    schedule: {
      title: "Planning à venir",
      noLessons: "Aucune leçon à venir",
      practicalLesson: "Leçon de conduite",
    },
    theory: {
      dailyGoal: "Objectif du jour",
      title: "Révision du code",
      subtitle: "Complétez les questions d'entraînement du jour.",
      startPractice: "Commencer l'entraînement",
    },
    quickLinks: {
      invoices: "Factures",
      profile: "Profil",
      topUp: "Recharger",
      certificates: "Certificats",
    },
  },

  auth: {
    welcomeBack: "Bon retour",
    signInSubtitle: "Connectez-vous pour accéder à votre tableau de bord",
    createAccount: "Créez votre compte",
    createAccountSubtitle: "Commencez votre essai gratuit de 14 jours",
    resetPassword: "Réinitialiser votre mot de passe",
    resetPasswordSubtitle: "Entrez votre email pour recevoir un lien de réinitialisation",
    email: "Adresse email",
    password: "Mot de passe",
    confirmPassword: "Confirmer le mot de passe",
    fullName: "Nom complet",
    phone: "Numéro de téléphone",
    schoolName: "Nom de l'école",
    operatingCountry: "Pays d'activité",
    operatingCountryHelp: "Cela détermine les paramètres fiscaux et la devise",
    preferredLanguage: "Langue préférée",
    rememberMe: "Se souvenir de moi",
    forgotPassword: "Mot de passe oublié ?",
    signIn: "Se connecter",
    signingIn: "Connexion...",
    createAccountBtn: "Créer un compte",
    creatingAccount: "Création du compte...",
    sendResetLink: "Envoyer le lien",
    sendingEmail: "Envoi en cours...",
    orContinueWith: "Ou continuer avec",
    noAccount: "Pas encore de compte ?",
    signUpFree: "Inscrivez-vous gratuitement",
    hasAccount: "Déjà un compte ?",
    rememberPassword: "Vous vous souvenez de votre mot de passe ?",
    termsAgree: "J'accepte les",
    termsOfService: "Conditions d'utilisation",
    privacyPolicy: "Politique de confidentialité",
    checkInbox: "Vérifiez votre boîte mail",
    resetEmailSent: "Nous avons envoyé un lien de réinitialisation à",
    backToSignIn: "Retour à la connexion",
    securityInfo: "Chiffrement SSL 256 bits • Conforme RGPD • Certifié SOC 2",
  },

  settings: {
    title: "Paramètres",
    subtitle: "Configurez votre école et vos préférences",
    saveChanges: "Enregistrer",
    saving: "Enregistrement...",
  },

  layout: {
    searchPlaceholder: "Rechercher pages, élèves, ou réservations...",
    esc: "ESC",
    typeToSearch: "Tapez pour rechercher sur la plateforme",
    noResults: "Aucun résultat trouvé pour",
    currentView: "Vue actuelle",
    instructorPortal: "Portail Moniteur",
    studentPortal: "Portail Élève",
    adminConsole: "Console d'administration",
    collapseSidebar: "Réduire la barre latérale",
    search: "Rechercher...",
    create: "Créer",
    newBooking: "Nouvelle réservation",
    addStudent: "Ajouter un élève",
    createInvoice: "Créer une facture",
    sendMessage: "Envoyer un message",
    loadingUser: "Chargement...",
    markedAsRead: "Marqué comme lu",
    failedToMarkRead: "Échec de la mise à jour",
    failedToLogout: "Échec de la déconnexion",
    failedToUpdateLang: "Échec de la mise à jour de la langue",
    notifications: "Notifications",
  },

  days: {
    monday: "Lundi",
    tuesday: "Mardi",
    wednesday: "Mercredi",
    thursday: "Jeudi",
    friday: "Vendredi",
    saturday: "Samedi",
    sunday: "Dimanche",
  },
};

// ============================================
// GERMAN TRANSLATIONS (PARTIAL)
// ============================================

translations.de = {
  common: {
    loading: "Laden...",
    save: "Speichern",
    cancel: "Abbrechen",
    search: "Suchen",
  },
  nav: {
    dashboard: "Dashboard",
    schedule: "Zeitplan",
    students: "Fahrschüler",
    instructors: "Fahrlehrer",
    settings: "Einstellungen",
    logout: "Abmelden",
  },
  landing: {
    hero: {
      title: "Finde deine perfekte",
      titleHighlight: "Fahrschule",
      searchButton: "Suchen",
    },
    navbar: { forSchools: "Für Fahrschulen", signIn: "Anmelden" },
  },
  studentDashboard: {
    greeting: { morning: "Guten Morgen", afternoon: "Guten Tag", evening: "Guten Abend" },
    bookLesson: "Fahrstunde buchen",
  },
};

// ============================================
// ITALIAN TRANSLATIONS (PARTIAL)
// ============================================

translations.it = {
  common: { loading: "Caricamento...", save: "Salva", cancel: "Annulla" },
  nav: { dashboard: "Pannello", settings: "Impostazioni", logout: "Esci" },
  landing: {
    hero: { title: "Trova la tua", titleHighlight: "autoscuola perfetta", searchButton: "Cerca" },
    navbar: { forSchools: "Per le autoscuole", signIn: "Accedi" },
  },
};

// ============================================
// DUTCH TRANSLATIONS (PARTIAL)
// ============================================

translations.nl = {
  common: { loading: "Laden...", save: "Opslaan", cancel: "Annuleren" },
  nav: { dashboard: "Dashboard", settings: "Instellingen", logout: "Uitloggen" },
  landing: {
    hero: { title: "Vind jouw perfecte", titleHighlight: "rijschool", searchButton: "Zoeken" },
    navbar: { forSchools: "Voor Rijscholen", signIn: "Inloggen" },
  },
};

// ============================================
// CORE I18N FUNCTIONS
// ============================================

const INTERPOLATION_PATTERN = /\{\{(\w+)\}\}/g;

function getNestedValue(obj, path) {
  const keys = path.split('.');
  let result = obj;
  
  for (const key of keys) {
    if (result === undefined || result === null) return undefined;
    if (typeof result !== 'object' || isPluralForms(result)) return undefined;
    result = result[key];
  }
  
  return result;
}

function getPluralCategory(count, language) {
  const absCount = Math.abs(count);
  if (absCount === 0) return 'zero';
  if (language === 'fr') {
    return absCount < 2 ? 'one' : 'other';
  }
  return absCount === 1 ? 'one' : 'other';
}

function interpolate(template, params) {
  if (!params || Object.keys(params).length === 0) return template;
  
  return template.replace(INTERPOLATION_PATTERN, (match, key) => {
    const value = params[key];
    return value !== undefined ? String(value) : match;
  });
}

export function t(key, params = {}, count) {
  let value = getNestedValue(translations[currentLanguage], key);
  
  if (value === undefined && currentLanguage !== 'en') {
    value = getNestedValue(translations.en, key);
  }
  
  if (value === undefined) {
    return key;
  }
  
  if (isPluralForms(value)) {
    const category = getPluralCategory(count ?? 1, currentLanguage);
    const form = value[category] ?? value.one ?? value.other;
    return interpolate(form, { ...params, count: count ?? 1 });
  }
  
  if (typeof value === 'object') {
    return key;
  }
  
  return interpolate(value, params);
}

export function getCurrentLanguage() {
  return currentLanguage;
}

export function getSupportedLanguages() {
  return [...LANGUAGE_CODES];
}

export function isLanguageSupported(lang) {
  return isLanguageCode(lang);
}

export function getLanguageInfo(lang) {
  const code = lang ?? currentLanguage;
  return SUPPORTED_LANGUAGES.find(l => l.code === code);
}

export function changeLanguage(lang) {
  if (!isLanguageCode(lang)) {
    return;
  }
  
  if (lang === currentLanguage) return;
  
  currentLanguage = lang;
  
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem('drivee_language', lang);
    } catch (e) {}
  }
  
  if (typeof document !== 'undefined') {
    document.documentElement.lang = lang;
  }
  
  listeners.forEach(listener => {
    try {
      listener(lang);
    } catch (error) {
      console.error('[i18n] Error in language change listener:', error);
    }
  });
}

export function onLanguageChange(listener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function initI18n(userPreferredLanguage) {
  let detectedLang = 'en';
  
  if (userPreferredLanguage && isLanguageCode(userPreferredLanguage)) {
    detectedLang = userPreferredLanguage;
  } else if (typeof window !== 'undefined') {
    try {
      const savedLang = localStorage.getItem('drivee_language');
      if (savedLang && isLanguageCode(savedLang)) {
        detectedLang = savedLang;
      } else {
        const browserLang = (navigator.language || '').split('-')[0];
        if (isLanguageCode(browserLang)) {
          detectedLang = browserLang;
        }
      }
    } catch (e) {}
  }
  
  currentLanguage = detectedLang;
  
  if (typeof document !== 'undefined') {
    document.documentElement.lang = currentLanguage;
  }
  
  return currentLanguage;
}

// ============================================
// REACT HOOK
// ============================================

export function useTranslation() {
  const [, setUpdate] = React.useState(0);
  
  React.useEffect(() => {
    const unsubscribe = onLanguageChange(() => {
      setUpdate(prev => prev + 1);
    });
    return unsubscribe;
  }, []);
  
  return {
    t,
    language: currentLanguage,
    changeLanguage,
    getLanguageInfo,
  };
}

// ============================================
// FORMATTERS
// ============================================

const LOCALE_MAP = {
  en: 'en-GB', fr: 'fr-FR', de: 'de-DE', it: 'it-IT', nl: 'nl-NL',
};

const CURRENCY_MAP = {
  en: 'GBP', fr: 'EUR', de: 'EUR', it: 'EUR', nl: 'EUR',
};

export function formatDate(date, options) {
  const dateObj = date instanceof Date ? date : new Date(date);
  if (Number.isNaN(dateObj.getTime())) return '—';
  
  const defaultOptions = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Intl.DateTimeFormat(LOCALE_MAP[currentLanguage], options ?? defaultOptions).format(dateObj);
}

export function formatTime(date) {
  const dateObj = date instanceof Date ? date : new Date(date);
  if (Number.isNaN(dateObj.getTime())) return '—';
  
  return new Intl.DateTimeFormat(LOCALE_MAP[currentLanguage], {
    hour: '2-digit', minute: '2-digit', hour12: false,
  }).format(dateObj);
}

export function formatCurrency(amount, currencyOverride) {
  const currency = currencyOverride ?? CURRENCY_MAP[currentLanguage];
  return new Intl.NumberFormat(LOCALE_MAP[currentLanguage], {
    style: 'currency', currency, minimumFractionDigits: 2, maximumFractionDigits: 2,
  }).format(amount);
}

export function formatDuration(minutes) {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (currentLanguage === 'fr') {
    if (hours === 0) return `${mins} min`;
    if (mins === 0) return `${hours}h`;
    return `${hours}h${mins.toString().padStart(2, '0')}`;
  }
  
  if (hours === 0) return `${mins} min`;
  if (mins === 0) return hours === 1 ? `${hours} hour` : `${hours} hours`;
  return `${hours}h ${mins}min`;
}

export function getTimeOfDayGreeting(date = new Date()) {
  const hour = date.getHours();
  if (hour < 12) return 'morning';
  if (hour < 18) return 'afternoon';
  return 'evening';
}

// Initialize on module load
initI18n();