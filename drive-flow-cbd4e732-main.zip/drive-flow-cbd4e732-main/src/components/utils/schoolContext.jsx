/**
 * School Context and Multi-Tenant Utilities
 * Production-ready helpers for school scoping and data isolation
 */

import { base44 } from "@/api/base44Client";
import { logger } from "./config";

/**
 * Get the effective school ID for the current user
 * Handles admin, instructor, and student roles
 * 
 * @param {Object} user - Current authenticated user
 * @returns {Promise<string|null>} School ID or null
 */
export async function getEffectiveSchoolId(user) {
  if (!user) {
    logger.warn("getEffectiveSchoolId called with no user");
    return null;
  }

  // Priority 1: User has school_id in metadata
  if (user.school_id) {
    logger.data("Using school_id from user metadata:", user.school_id);
    return user.school_id;
  }

  // Priority 1.5: Check for school_id in user data object (alternate storage)
  if (user.data?.school_id) {
    logger.data("Using school_id from user.data:", user.data.school_id);
    return user.data.school_id;
  }

  // Priority 2: Admin role - get first active school they own
  if (user.role === "admin") {
    try {
      const schools = await base44.entities.School.filter(
        { created_by: user.email, is_active: true },
        "-created_date",
        1
      );
      
      if (schools && schools.length > 0) {
        const schoolId = schools[0].id;
        logger.data("Admin using school:", schoolId);
        
        // Update user metadata with school_id for future lookups
        try {
          await base44.auth.updateMe({ school_id: schoolId });
        } catch (err) {
          logger.warn("Could not update user school_id:", err);
        }
        
        return schoolId;
      }
      
      // No school found - admin needs to create one
      logger.warn("Admin has no school - needs onboarding");
      return null;
    } catch (err) {
      logger.error("Failed to fetch admin's school:", err);
      return null;
    }
  }

  // Priority 3: Instructor - get school from instructor record
  if (user.instructor_id) {
    try {
      const instructors = await base44.entities.Instructor.filter({ id: user.instructor_id }, "-created_date", 1);
      if (instructors && instructors.length > 0 && instructors[0].school_id) {
        const schoolId = instructors[0].school_id;
        logger.data("Using school_id from instructor record:", schoolId);
        
        // Update user metadata
        try {
          await base44.auth.updateMe({ school_id: schoolId });
        } catch (err) {
          logger.warn("Could not update user school_id:", err);
        }
        
        return schoolId;
      }
    } catch (err) {
      logger.error("Failed to fetch instructor's school:", err);
    }
  }

  // Priority 4: Student - get school from student record
  if (user.student_id) {
    try {
      const students = await base44.entities.Student.filter({ id: user.student_id }, "-created_date", 1);
      if (students && students.length > 0 && students[0].school_id) {
        const schoolId = students[0].school_id;
        logger.data("Using school_id from student record:", schoolId);
        
        // Update user metadata
        try {
          await base44.auth.updateMe({ school_id: schoolId });
        } catch (err) {
          logger.warn("Could not update user school_id:", err);
        }
        
        return schoolId;
      }
    } catch (err) {
      logger.error("Failed to fetch student's school:", err);
    }
  }

  // Priority 5: Lookup by email (last resort)
  try {
    const normalizedEmail = user.email?.trim().toLowerCase();
    if (!normalizedEmail) return null;

    // Try instructor
    const instructors = await base44.entities.Instructor.filter({ email: normalizedEmail }, "-created_date", 1);
    if (instructors && instructors.length > 0 && instructors[0].school_id) {
      const schoolId = instructors[0].school_id;
      logger.data("Found school via instructor email lookup:", schoolId);
      
      // Update user metadata
      try {
        await base44.auth.updateMe({ 
          school_id: schoolId,
          instructor_id: instructors[0].id 
        });
      } catch (err) {
        logger.warn("Could not update user metadata:", err);
      }
      
      return schoolId;
    }

    // Try student
    const students = await base44.entities.Student.filter({ email: normalizedEmail }, "-created_date", 1);
    if (students && students.length > 0 && students[0].school_id) {
      const schoolId = students[0].school_id;
      logger.data("Found school via student email lookup:", schoolId);
      
      // Update user metadata
      try {
        await base44.auth.updateMe({ 
          school_id: schoolId,
          student_id: students[0].id 
        });
      } catch (err) {
        logger.warn("Could not update user metadata:", err);
      }
      
      return schoolId;
    }
  } catch (err) {
    logger.error("Email lookup failed:", err);
  }

  // No school found
  logger.warn("No school ID found for user:", user.email);
  return null;
}

/**
 * Check if user has a specific permission
 * @param {Object} user - Current user
 * @param {string} permission - Permission to check (e.g., 'view_all_students', 'edit_bookings')
 * @returns {boolean}
 */
export function hasPermission(user, permission) {
  if (!user) return false;
  
  const role = user.role;
  
  // Admin has all permissions
  if (role === "admin") return true;
  
  // Instructor permissions
  if (role === "instructor") {
    const instructorPermissions = [
      "view_own_schedule",
      "view_own_students",
      "view_own_earnings",
      "edit_own_bookings",
      "view_own_messages",
      "create_lesson_notes",
    ];
    return instructorPermissions.includes(permission);
  }
  
  // Student permissions
  if (role === "user") {
    const studentPermissions = [
      "view_own_bookings",
      "view_own_invoices",
      "view_own_progress",
      "book_lessons",
      "view_own_messages",
    ];
    return studentPermissions.includes(permission);
  }
  
  return false;
}

/**
 * Build query filter scoped to school
 * @param {string} schoolId - School ID to scope to
 * @param {Object} additionalFilters - Additional filter criteria
 * @returns {Object} Combined filter object
 */
export function buildSchoolScopedQuery(schoolId, additionalFilters = {}) {
  if (!schoolId) {
    logger.warn("buildSchoolScopedQuery called with no schoolId");
    return additionalFilters;
  }
  
  return {
    school_id: schoolId,
    ...additionalFilters,
  };
}

/**
 * Check if user is admin
 */
export function isAdmin(user) {
  return user?.role === "admin";
}

/**
 * Check if user is instructor
 */
export function isInstructor(user) {
  return user?.role === "instructor";
}

/**
 * Check if user is student
 */
export function isStudent(user) {
  return user?.role === "user";
}