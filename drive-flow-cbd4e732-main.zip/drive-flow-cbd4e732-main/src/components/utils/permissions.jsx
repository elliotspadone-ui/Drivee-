// Permission definitions for role-based access control

export const ROLES = {
  OWNER: 'owner',
  ADMIN: 'admin',
  MANAGER: 'manager',
  INSTRUCTOR: 'instructor',
  RECEPTIONIST: 'receptionist',
  STUDENT: 'student',
};

// Permission matrix: defines what each role can do
export const PERMISSIONS = {
  [ROLES.OWNER]: ['*'], // All permissions
  
  [ROLES.ADMIN]: [
    'instructors.*',
    'students.*',
    'vehicles.*',
    'schedule.*',
    'expenses.*',
    'payments.*',
    'reports.view',
    'settings.view',
    'theory.*',
    'packages.*',
  ],
  
  [ROLES.MANAGER]: [
    'instructors.view',
    'instructors.edit',
    'students.*',
    'schedule.*',
    'expenses.view',
    'expenses.approve',
    'payments.view',
    'reports.view',
    'vehicles.view',
  ],
  
  [ROLES.INSTRUCTOR]: [
    'schedule.view',
    'schedule.own',
    'students.view',
    'students.edit',
    'expenses.create',
    'expenses.view_own',
    'profile.edit_own',
    'earnings.view_own',
  ],
  
  [ROLES.RECEPTIONIST]: [
    'schedule.view',
    'schedule.create',
    'schedule.edit',
    'students.view',
    'students.create',
    'students.edit',
    'payments.create',
    'payments.view',
  ],
  
  [ROLES.STUDENT]: [
    'schedule.view_own',
    'lessons.book',
    'lessons.view_own',
    'profile.edit_own',
    'payments.create',
    'payments.view_own',
    'theory.view',
  ],
};

/**
 * Check if a role has a specific permission
 * @param {string} role - User's role
 * @param {string} permission - Permission to check (e.g., 'instructors.view')
 * @returns {boolean}
 */
export function hasPermission(role, permission) {
  if (!role || !permission) return false;
  
  const allowedPermissions = PERMISSIONS[role] || [];
  
  return allowedPermissions.some(p => {
    if (p === '*') return true; // Full access
    if (p === permission) return true; // Exact match
    if (p.endsWith('.*')) {
      // Wildcard match (e.g., 'instructors.*' matches 'instructors.view')
      const prefix = p.slice(0, -2);
      return permission.startsWith(prefix);
    }
    return false;
  });
}

/**
 * Check if a role has any of the specified permissions
 * @param {string} role - User's role
 * @param {string[]} permissions - Array of permissions
 * @returns {boolean}
 */
export function hasAnyPermission(role, permissions) {
  return permissions.some(permission => hasPermission(role, permission));
}

/**
 * Check if a role has all of the specified permissions
 * @param {string} role - User's role
 * @param {string[]} permissions - Array of permissions
 * @returns {boolean}
 */
export function hasAllPermissions(role, permissions) {
  return permissions.every(permission => hasPermission(role, permission));
}

/**
 * Get user-friendly role name
 * @param {string} role - Role identifier
 * @returns {string}
 */
export function getRoleDisplayName(role) {
  const names = {
    [ROLES.OWNER]: 'Owner',
    [ROLES.ADMIN]: 'Administrator',
    [ROLES.MANAGER]: 'Manager',
    [ROLES.INSTRUCTOR]: 'Instructor',
    [ROLES.RECEPTIONIST]: 'Receptionist',
    [ROLES.STUDENT]: 'Student',
  };
  return names[role] || 'User';
}

/**
 * Check if role is management (can access admin portal)
 * @param {string} role - User's role
 * @returns {boolean}
 */
export function isManagement(role) {
  return [ROLES.OWNER, ROLES.ADMIN, ROLES.MANAGER, ROLES.RECEPTIONIST].includes(role);
}

/**
 * Check if role is instructor
 * @param {string} role - User's role
 * @returns {boolean}
 */
export function isInstructor(role) {
  return role === ROLES.INSTRUCTOR;
}

/**
 * Check if role is student
 * @param {string} role - User's role
 * @returns {boolean}
 */
export function isStudent(role) {
  return role === ROLES.STUDENT;
}

/**
 * Get default dashboard route for role
 * @param {string} role - User's role
 * @returns {string}
 */
export function getDefaultRoute(role) {
  const routes = {
    [ROLES.OWNER]: 'Dashboard',
    [ROLES.ADMIN]: 'Dashboard',
    [ROLES.MANAGER]: 'Dashboard',
    [ROLES.RECEPTIONIST]: 'Calendar',
    [ROLES.INSTRUCTOR]: 'InstructorDashboard',
    [ROLES.STUDENT]: 'StudentDashboard',
  };
  return routes[role] || 'Landing';
}