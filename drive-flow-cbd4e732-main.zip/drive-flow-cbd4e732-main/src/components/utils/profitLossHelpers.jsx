import { format, eachMonthOfInterval, eachQuarterOfInterval, startOfMonth, endOfMonth, startOfQuarter, endOfQuarter } from "date-fns";

export const filterTransactions = (transactions, filters, dateField = "created_date") => {
  return transactions.filter((tx) => {
    const date = new Date(tx[dateField] || tx.created_date);
    if (date < new Date(filters.startDate) || date > new Date(filters.endDate)) return false;
    if (filters.studentId && tx.student_id !== filters.studentId) return false;
    if (filters.instructorId && tx.instructor_id !== filters.instructorId) return false;
    if (filters.vehicleId && tx.vehicle_id !== filters.vehicleId) return false;
    if (filters.serviceType && tx.payment_type !== filters.serviceType) return false;
    return true;
  });
};

export const buildIncomeBreakdown = (payments) => {
  const breakdown = { lessons: 0, packages: 0, exams: 0, theory: 0, other: 0 };
  payments.forEach((p) => {
    const amount = p.amount || 0;
    if (p.payment_type === "lesson") breakdown.lessons += amount;
    else if (p.payment_type === "package") breakdown.packages += amount;
    else if (p.payment_type === "exam_fee") breakdown.exams += amount;
    else if (p.payment_type === "theory") breakdown.theory += amount;
    else breakdown.other += amount;
  });
  return breakdown;
};

export const calculateCOGS = (bookings, config = { commissionRate: 0.3 }) => {
  const instructorCommissions = bookings.reduce((sum, b) => sum + (b.price || 0) * config.commissionRate, 0);
  return { instructorCommissions, vehicleCosts: 0, total: instructorCommissions };
};

export const aggregateExpenses = (expenses) => {
  return expenses.reduce((acc, e) => {
    const category = e.category || "Uncategorized";
    acc[category] = (acc[category] || 0) + (e.amount || 0);
    return acc;
  }, {});
};

export const buildProfitLossData = (payments, bookings, expenses, filters, basis, config = {}) => {
  const dateField = basis === "cash" ? "payment_date" : "created_date";
  const filteredPayments = filterTransactions(payments.filter((p) => p.status === "completed"), filters, dateField);
  const filteredBookings = filterTransactions(bookings.filter((b) => b.status === "completed"), filters, "start_datetime");
  const filteredExpenses = filterTransactions(expenses, filters, "expense_date");

  const income = buildIncomeBreakdown(filteredPayments);
  const totalIncome = Object.values(income).reduce((sum, val) => sum + val, 0);

  const cogs = calculateCOGS(filteredBookings, config);
  const grossProfit = totalIncome - cogs.total;
  const grossMargin = totalIncome > 0 ? (grossProfit / totalIncome) * 100 : 0;

  const expensesByCategory = aggregateExpenses(filteredExpenses);
  const totalExpenses = Object.values(expensesByCategory).reduce((sum, val) => sum + val, 0);

  const netIncome = grossProfit - totalExpenses;
  const netMargin = totalIncome > 0 ? (netIncome / totalIncome) * 100 : 0;

  return {
    income,
    totalIncome,
    cogs,
    grossProfit,
    grossMargin,
    expensesByCategory,
    totalExpenses,
    netIncome,
    netMargin,
    transactions: { income: filteredPayments, cogs: filteredBookings, expenses: filteredExpenses },
  };
};

export const groupByPeriod = (payments, bookings, expenses, filters, basis, groupBy) => {
  const startDate = new Date(filters.startDate);
  const endDate = new Date(filters.endDate);
  
  let periods = [];
  if (groupBy === "month") {
    periods = eachMonthOfInterval({ start: startDate, end: endDate }).map((date) => ({
      start: startOfMonth(date),
      end: endOfMonth(date),
      label: format(date, "MMM yyyy"),
    }));
  } else if (groupBy === "quarter") {
    periods = eachQuarterOfInterval({ start: startDate, end: endDate }).map((date) => ({
      start: startOfQuarter(date),
      end: endOfQuarter(date),
      label: `Q${Math.ceil((date.getMonth() + 1) / 3)} ${format(date, "yyyy")}`,
    }));
  } else {
    return [buildProfitLossData(payments, bookings, expenses, filters, basis)];
  }

  return periods.map((period) => {
    const periodFilters = { ...filters, startDate: format(period.start, "yyyy-MM-dd"), endDate: format(period.end, "yyyy-MM-dd") };
    return { label: period.label, data: buildProfitLossData(payments, bookings, expenses, periodFilters, basis) };
  });
};

export const buildPnLTree = (data, previousData = null) => {
  const rows = [];
  rows.push({ id: "income-header", type: "section-header", label: "INCOME", amount: data.totalIncome, previousAmount: previousData?.totalIncome, level: 0 });
  rows.push({ id: "income-lessons", type: "line-item", label: "Driving Lessons", amount: data.income.lessons, previousAmount: previousData?.income.lessons, level: 1, transactions: data.transactions.income.filter((p) => p.payment_type === "lesson") });
  rows.push({ id: "income-packages", type: "line-item", label: "Lesson Packages", amount: data.income.packages, previousAmount: previousData?.income.packages, level: 1, transactions: data.transactions.income.filter((p) => p.payment_type === "package") });
  rows.push({ id: "income-exams", type: "line-item", label: "Exam Fees", amount: data.income.exams, previousAmount: previousData?.income.exams, level: 1, transactions: data.transactions.income.filter((p) => p.payment_type === "exam_fee") });
  rows.push({ id: "income-theory", type: "line-item", label: "Theory Training", amount: data.income.theory, previousAmount: previousData?.income.theory, level: 1, transactions: data.transactions.income.filter((p) => p.payment_type === "theory") });
  rows.push({ id: "income-other", type: "line-item", label: "Other Income", amount: data.income.other, previousAmount: previousData?.income.other, level: 1, transactions: data.transactions.income.filter((p) => !p.payment_type || p.payment_type === "other") });
  rows.push({ id: "total-income", type: "subtotal", label: "Total Income", amount: data.totalIncome, previousAmount: previousData?.totalIncome, level: 0 });
  rows.push({ id: "cogs-header", type: "section-header", label: "COST OF REVENUE", amount: data.cogs.total, previousAmount: previousData?.cogs.total, level: 0 });
  rows.push({ id: "cogs-commissions", type: "line-item", label: "Instructor Commissions", amount: data.cogs.instructorCommissions, previousAmount: previousData?.cogs.instructorCommissions, level: 1, transactions: data.transactions.cogs });
  rows.push({ id: "gross-profit", type: "subtotal", label: "Gross Profit", amount: data.grossProfit, previousAmount: previousData?.grossProfit, level: 0, metadata: { margin: data.grossMargin } });
  rows.push({ id: "expenses-header", type: "section-header", label: "OPERATING EXPENSES", amount: data.totalExpenses, previousAmount: previousData?.totalExpenses, level: 0 });
  Object.entries(data.expensesByCategory).forEach(([category, amount]) => {
    rows.push({ id: `expense-${category}`, type: "line-item", label: category, amount, previousAmount: previousData?.expensesByCategory[category], level: 1, transactions: data.transactions.expenses.filter((e) => (e.category || "Uncategorized") === category) });
  });
  rows.push({ id: "net-income", type: "total", label: "NET INCOME", amount: data.netIncome, previousAmount: previousData?.netIncome, level: 0, metadata: { margin: data.netMargin } });
  return rows;
};