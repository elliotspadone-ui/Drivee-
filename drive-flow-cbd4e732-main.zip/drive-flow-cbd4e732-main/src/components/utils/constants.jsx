/**
 * Application-wide constants and enums
 * Centralized source of truth for status values, categories, and configuration
 */

// ============================================================================
// BOOKING STATUS ENUM
// ============================================================================
export const BOOKING_STATUS = {
  PENDING: "pending",
  CONFIRMED: "confirmed",
  IN_PROGRESS: "in_progress",
  COMPLETED: "completed",
  CANCELLED: "cancelled",
  NO_SHOW: "no_show",
};

export const BOOKING_STATUS_LABELS = {
  [BOOKING_STATUS.PENDING]: "Pending",
  [BOOKING_STATUS.CONFIRMED]: "Confirmed",
  [BOOKING_STATUS.IN_PROGRESS]: "In Progress",
  [BOOKING_STATUS.COMPLETED]: "Completed",
  [BOOKING_STATUS.CANCELLED]: "Cancelled",
  [BOOKING_STATUS.NO_SHOW]: "No Show",
};

export const BOOKING_STATUS_COLORS = {
  [BOOKING_STATUS.PENDING]: { bg: "bg-[#fdfbe8]", text: "text-[#b8a525]", border: "border-[#f9f3c8]" },
  [BOOKING_STATUS.CONFIRMED]: { bg: "bg-[#eefbe7]", text: "text-[#5cb83a]", border: "border-[#d4f4c3]" },
  [BOOKING_STATUS.IN_PROGRESS]: { bg: "bg-[#e8f4fa]", text: "text-[#3b82c4]", border: "border-[#d4eaf5]" },
  [BOOKING_STATUS.COMPLETED]: { bg: "bg-zinc-100", text: "text-zinc-700", border: "border-zinc-200" },
  [BOOKING_STATUS.CANCELLED]: { bg: "bg-[#fdeeed]", text: "text-[#e44138]", border: "border-[#f9d4d2]" },
  [BOOKING_STATUS.NO_SHOW]: { bg: "bg-[#fdeeed]", text: "text-[#c9342c]", border: "border-[#f9d4d2]" },
};

// ============================================================================
// INVOICE STATUS ENUM
// ============================================================================
export const INVOICE_STATUS = {
  DRAFT: "draft",
  SENT: "sent",
  PAID: "paid",
  OVERDUE: "overdue",
  CANCELLED: "cancelled",
  VOID: "void",
};

export const INVOICE_STATUS_LABELS = {
  [INVOICE_STATUS.DRAFT]: "Draft",
  [INVOICE_STATUS.SENT]: "Sent",
  [INVOICE_STATUS.PAID]: "Paid",
  [INVOICE_STATUS.OVERDUE]: "Overdue",
  [INVOICE_STATUS.CANCELLED]: "Cancelled",
  [INVOICE_STATUS.VOID]: "Void",
};

export const INVOICE_STATUS_COLORS = {
  [INVOICE_STATUS.DRAFT]: { bg: "bg-zinc-100", text: "text-zinc-600", border: "border-zinc-200" },
  [INVOICE_STATUS.SENT]: { bg: "bg-[#e8f4fa]", text: "text-[#3b82c4]", border: "border-[#d4eaf5]" },
  [INVOICE_STATUS.PAID]: { bg: "bg-[#eefbe7]", text: "text-[#5cb83a]", border: "border-[#d4f4c3]" },
  [INVOICE_STATUS.OVERDUE]: { bg: "bg-[#fdeeed]", text: "text-[#e44138]", border: "border-[#f9d4d2]" },
  [INVOICE_STATUS.CANCELLED]: { bg: "bg-zinc-100", text: "text-zinc-500", border: "border-zinc-200" },
  [INVOICE_STATUS.VOID]: { bg: "bg-zinc-50", text: "text-zinc-400", border: "border-zinc-100" },
};

// ============================================================================
// PAYMENT STATUS ENUM
// ============================================================================
export const PAYMENT_STATUS = {
  PENDING: "pending",
  COMPLETED: "completed",
  FAILED: "failed",
  REFUNDED: "refunded",
};

export const PAYMENT_STATUS_LABELS = {
  [PAYMENT_STATUS.PENDING]: "Pending",
  [PAYMENT_STATUS.COMPLETED]: "Completed",
  [PAYMENT_STATUS.FAILED]: "Failed",
  [PAYMENT_STATUS.REFUNDED]: "Refunded",
};

// ============================================================================
// LICENSE CATEGORIES
// ============================================================================
export const LICENSE_CATEGORIES = ["B", "A", "C", "D", "BE", "CE", "DE"];

export const LICENSE_CATEGORY_LABELS = {
  B: "Car (B)",
  A: "Motorcycle (A)",
  C: "Truck (C)",
  D: "Bus (D)",
  BE: "Car with Trailer (BE)",
  CE: "Truck with Trailer (CE)",
  DE: "Bus with Trailer (DE)",
};

// ============================================================================
// LESSON TYPES
// ============================================================================
export const LESSON_TYPES = {
  STANDARD: "standard",
  EXTENDED: "extended",
  HIGHWAY: "highway",
  NIGHT: "night",
  PARKING: "parking",
  EXAM_PREP: "exam_prep",
  REFRESHER: "refresher",
  THEORY: "theory",
  TEST_PREP: "test_prep",
};

export const LESSON_TYPE_LABELS = {
  [LESSON_TYPES.STANDARD]: "Standard Lesson",
  [LESSON_TYPES.EXTENDED]: "Extended Session",
  [LESSON_TYPES.HIGHWAY]: "Motorway Driving",
  [LESSON_TYPES.NIGHT]: "Night Driving",
  [LESSON_TYPES.PARKING]: "Parking Practice",
  [LESSON_TYPES.EXAM_PREP]: "Exam Preparation",
  [LESSON_TYPES.REFRESHER]: "Refresher Course",
  [LESSON_TYPES.THEORY]: "Theory Class",
  [LESSON_TYPES.TEST_PREP]: "Test Preparation",
};

// ============================================================================
// PAYMENT METHODS
// ============================================================================
export const PAYMENT_METHODS = {
  CARD: "card",
  CASH: "cash",
  BANK_TRANSFER: "bank_transfer",
  DIGITAL_WALLET: "digital_wallet",
};

export const PAYMENT_METHOD_LABELS = {
  [PAYMENT_METHODS.CARD]: "Credit/Debit Card",
  [PAYMENT_METHODS.CASH]: "Cash",
  [PAYMENT_METHODS.BANK_TRANSFER]: "Bank Transfer",
  [PAYMENT_METHODS.DIGITAL_WALLET]: "Digital Wallet",
};

// ============================================================================
// USER ROLES
// ============================================================================
export const USER_ROLES = {
  ADMIN: "admin",
  INSTRUCTOR: "instructor",
  USER: "user", // student role
};

// ============================================================================
// PAGINATION DEFAULTS
// ============================================================================
export const DEFAULT_PAGE_SIZE = 50;
export const MAX_PAGE_SIZE = 200;

// ============================================================================
// DATE/TIME CONSTANTS
// ============================================================================
export const DEFAULT_LESSON_DURATION = 60; // minutes
export const DEFAULT_BUFFER_TIME = 15; // minutes between lessons
export const BUSINESS_HOURS_START = 8; // 8 AM
export const BUSINESS_HOURS_END = 20; // 8 PM

// ============================================================================
// VALIDATION RULES
// ============================================================================
export const MIN_PASSWORD_LENGTH = 8;
export const MIN_LESSON_HOURS = 20;
export const MAX_LESSON_HOURS = 100;
export const CANCELLATION_NOTICE_HOURS = 24;

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get human-readable status label
 */
export function getStatusLabel(status, type = "booking") {
  if (type === "booking") return BOOKING_STATUS_LABELS[status] || status;
  if (type === "invoice") return INVOICE_STATUS_LABELS[status] || status;
  if (type === "payment") return PAYMENT_STATUS_LABELS[status] || status;
  return status;
}

/**
 * Get status color classes
 */
export function getStatusColors(status, type = "booking") {
  if (type === "booking") return BOOKING_STATUS_COLORS[status] || BOOKING_STATUS_COLORS.pending;
  if (type === "invoice") return INVOICE_STATUS_COLORS[status] || INVOICE_STATUS_COLORS.draft;
  return { bg: "bg-zinc-100", text: "text-zinc-600", border: "border-zinc-200" };
}

/**
 * Validate booking status transition
 */
export function canTransitionBookingStatus(from, to) {
  const validTransitions = {
    [BOOKING_STATUS.PENDING]: [BOOKING_STATUS.CONFIRMED, BOOKING_STATUS.CANCELLED],
    [BOOKING_STATUS.CONFIRMED]: [BOOKING_STATUS.IN_PROGRESS, BOOKING_STATUS.CANCELLED, BOOKING_STATUS.NO_SHOW],
    [BOOKING_STATUS.IN_PROGRESS]: [BOOKING_STATUS.COMPLETED, BOOKING_STATUS.CANCELLED],
    [BOOKING_STATUS.COMPLETED]: [], // final state
    [BOOKING_STATUS.CANCELLED]: [], // final state
    [BOOKING_STATUS.NO_SHOW]: [], // final state
  };

  return validTransitions[from]?.includes(to) || false;
}

/**
 * Validate invoice status transition
 */
export function canTransitionInvoiceStatus(from, to) {
  const validTransitions = {
    [INVOICE_STATUS.DRAFT]: [INVOICE_STATUS.SENT, INVOICE_STATUS.VOID],
    [INVOICE_STATUS.SENT]: [INVOICE_STATUS.PAID, INVOICE_STATUS.OVERDUE, INVOICE_STATUS.VOID],
    [INVOICE_STATUS.OVERDUE]: [INVOICE_STATUS.PAID, INVOICE_STATUS.VOID],
    [INVOICE_STATUS.PAID]: [INVOICE_STATUS.REFUNDED], // can only refund paid invoices
    [INVOICE_STATUS.CANCELLED]: [], // final state
    [INVOICE_STATUS.VOID]: [], // final state
  };

  return validTransitions[from]?.includes(to) || false;
}