/**
 * Centralized routing and navigation utilities
 * Handles role-based default routes and auth redirects
 */

import { createPageUrl } from "@/utils";
import { USER_ROLES } from "./constants";

/**
 * Get the default landing page for a user based on their role
 * @param {Object} user - Authenticated user object
 * @returns {string} Page name to redirect to
 */
export function getDefaultRoute(user) {
  if (!user) return "Landing";

  const role = user.role;

  switch (role) {
    case USER_ROLES.ADMIN:
      return "Dashboard";
    
    case USER_ROLES.INSTRUCTOR:
      return "InstructorDashboard";
    
    case USER_ROLES.USER: // student
      return "StudentDashboard";
    
    default:
      return "Landing";
  }
}

/**
 * Get the appropriate login page for a portal type
 * @param {string} portalType - 'student', 'instructor', or 'admin'
 * @returns {string} Login page name
 */
export function getLoginPage(portalType) {
  if (portalType === "student") return "StudentAuth";
  return "SchoolLogin"; // admin and instructor use same login
}

/**
 * Check if a page is public (doesn't require auth)
 * @param {string} pageName - Name of the page
 * @returns {boolean}
 */
export function isPublicPage(pageName) {
  const PUBLIC_PAGES = [
    "Landing",
    "BusinessSolutions",
    "SchoolLogin",
    "SchoolWebsite",
    "Marketplace",
    "SchoolProfile",
    "Register",
    "ForgotPassword",
    "VerifyEmail",
    "ResetPassword",
    "AutoRedirect",
    "StudentAuth",
    "TheoryTestPrep",
    "NotFound",
    "Unauthorized",
    "Health",
    "Support",
    "SeedCatAccount",
    "AcceptInvitation",
  ];

  return PUBLIC_PAGES.includes(pageName);
}

/**
 * Check if a page requires a specific role
 * @param {string} pageName - Name of the page
 * @returns {string|null} Required role or null if no specific role required
 */
export function getRequiredRole(pageName) {
  // Student pages
  if (pageName.startsWith("Student")) return USER_ROLES.USER;
  
  // Instructor pages
  if (pageName.startsWith("Instructor")) return USER_ROLES.INSTRUCTOR;
  
  // Admin pages (most pages without prefix)
  const adminPages = [
    "Dashboard",
    "Calendar",
    "Students",
    "Instructors",
    "Fleet",
    "Finance",
    "Analytics",
    "Settings",
    "Reports",
    "Packages",
    "Invoices",
    "Payments",
    "Marketing",
    "WebsiteBuilder",
    "TheoryManagement",
    "Courses",
    "Reviews",
    "Messages",
    "AdminAntsDossiers",
    "AdminAntsDossierDetail",
    "AutomatedPayments",
    "Notifications",
  ];
  
  if (adminPages.includes(pageName)) return USER_ROLES.ADMIN;
  
  return null;
}

/**
 * Build redirect URL with next parameter
 * @param {string} loginPage - Login page to redirect to
 * @param {string} nextPage - Page to redirect to after login
 * @returns {string} Full URL with redirect parameter
 */
export function buildLoginRedirect(loginPage, nextPage) {
  if (!nextPage) return createPageUrl(loginPage);
  return `${createPageUrl(loginPage)}?redirect=${encodeURIComponent(nextPage)}`;
}