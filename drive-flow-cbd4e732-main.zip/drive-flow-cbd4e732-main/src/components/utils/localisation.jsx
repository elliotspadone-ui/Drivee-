// ============================================
// CORE LOCALISATION MODULE
// ============================================

export const VAT_RATES = {
  FR: 0.20,
  GB: 0.20,
  IE: 0.23,
  CH: 0.081,
  DE: 0.19,
  US: null,
  BE: 0.21,
  LU: 0.17,
  NL: 0.21,
  AT: 0.20,
};

// Supported languages for the app (for in-app language selector)
export const SUPPORTED_LANGUAGES = [
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "fr", label: "Français", flag: "🇫🇷" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
  { code: "it", label: "Italiano", flag: "🇮🇹" },
  { code: "nl", label: "Nederlands", flag: "🇳🇱" },
];

// Full locale definitions for country + language combinations
export const SUPPORTED_LOCALES = [
  {
    id: "en-INT",
    countryCode: "INT",
    labelCountry: "International",
    labelLanguage: "English",
    languageCode: "en",
    currency: "EUR",
    currencySymbol: "€",
    vatLabel: "",
    usesVat: false,
    defaultVatRate: null,
    dateFormat: "dd/MM/yyyy",
    features: [],
    flag: "🌍",
  },
  {
    id: "fr-FR",
    countryCode: "FR",
    labelCountry: "France",
    labelLanguage: "Français",
    languageCode: "fr",
    currency: "EUR",
    currencySymbol: "€",
    vatLabel: "TVA",
    usesVat: true,
    defaultVatRate: VAT_RATES.FR,
    dateFormat: "dd/MM/yyyy",
    features: ["ants"],
    flag: "🇫🇷",
  },
  {
    id: "en-GB",
    countryCode: "GB",
    labelCountry: "United Kingdom",
    labelLanguage: "English",
    languageCode: "en",
    currency: "GBP",
    currencySymbol: "£",
    vatLabel: "VAT",
    usesVat: true,
    defaultVatRate: VAT_RATES.GB,
    dateFormat: "dd/MM/yyyy",
    features: [],
    flag: "🇬🇧",
  },
  {
    id: "en-US",
    countryCode: "US",
    labelCountry: "United States",
    labelLanguage: "English",
    languageCode: "en",
    currency: "USD",
    currencySymbol: "$",
    vatLabel: "Sales Tax",
    usesVat: false,
    defaultVatRate: null,
    dateFormat: "MM/dd/yyyy",
    features: [],
    flag: "🇺🇸",
  },
  {
    id: "fr-CH",
    countryCode: "CH",
    labelCountry: "Switzerland",
    labelLanguage: "Français",
    languageCode: "fr",
    currency: "CHF",
    currencySymbol: "CHF",
    vatLabel: "TVA",
    usesVat: true,
    defaultVatRate: VAT_RATES.CH,
    dateFormat: "dd.MM.yyyy",
    features: [],
    flag: "🇨🇭",
  },
  {
    id: "de-CH",
    countryCode: "CH",
    labelCountry: "Switzerland",
    labelLanguage: "Deutsch",
    languageCode: "de",
    currency: "CHF",
    currencySymbol: "CHF",
    vatLabel: "MWST",
    usesVat: true,
    defaultVatRate: VAT_RATES.CH,
    dateFormat: "dd.MM.yyyy",
    features: [],
    flag: "🇨🇭",
  },
  {
    id: "it-CH",
    countryCode: "CH",
    labelCountry: "Switzerland",
    labelLanguage: "Italiano",
    languageCode: "it",
    currency: "CHF",
    currencySymbol: "CHF",
    vatLabel: "IVA",
    usesVat: true,
    defaultVatRate: VAT_RATES.CH,
    dateFormat: "dd/MM/yyyy",
    features: [],
    flag: "🇨🇭",
  },
  {
    id: "fr-BE",
    countryCode: "BE",
    labelCountry: "Belgium",
    labelLanguage: "Français",
    languageCode: "fr",
    currency: "EUR",
    currencySymbol: "€",
    vatLabel: "TVA",
    usesVat: true,
    defaultVatRate: VAT_RATES.BE,
    dateFormat: "dd/MM/yyyy",
    features: [],
    flag: "🇧🇪",
  },
  {
    id: "nl-BE",
    countryCode: "BE",
    labelCountry: "Belgium",
    labelLanguage: "Nederlands",
    languageCode: "nl",
    currency: "EUR",
    currencySymbol: "€",
    vatLabel: "BTW",
    usesVat: true,
    defaultVatRate: VAT_RATES.BE,
    dateFormat: "dd/MM/yyyy",
    features: [],
    flag: "🇧🇪",
  },
  {
    id: "fr-LU",
    countryCode: "LU",
    labelCountry: "Luxembourg",
    labelLanguage: "Français",
    languageCode: "fr",
    currency: "EUR",
    currencySymbol: "€",
    vatLabel: "TVA",
    usesVat: true,
    defaultVatRate: VAT_RATES.LU,
    dateFormat: "dd.MM.yyyy",
    features: [],
    flag: "🇱🇺",
  },
  {
    id: "de-LU",
    countryCode: "LU",
    labelCountry: "Luxembourg",
    labelLanguage: "Deutsch",
    languageCode: "de",
    currency: "EUR",
    currencySymbol: "€",
    vatLabel: "TVA",
    usesVat: true,
    defaultVatRate: VAT_RATES.LU,
    dateFormat: "dd.MM.yyyy",
    features: [],
    flag: "🇱🇺",
  },
  {
    id: "de-DE",
    countryCode: "DE",
    labelCountry: "Germany",
    labelLanguage: "Deutsch",
    languageCode: "de",
    currency: "EUR",
    currencySymbol: "€",
    vatLabel: "MwSt",
    usesVat: true,
    defaultVatRate: VAT_RATES.DE,
    dateFormat: "dd.MM.yyyy",
    features: [],
    flag: "🇩🇪",
  },
  {
    id: "de-AT",
    countryCode: "AT",
    labelCountry: "Austria",
    labelLanguage: "Deutsch",
    languageCode: "de",
    currency: "EUR",
    currencySymbol: "€",
    vatLabel: "USt",
    usesVat: true,
    defaultVatRate: VAT_RATES.AT,
    dateFormat: "dd.MM.yyyy",
    features: [],
    flag: "🇦🇹",
  },
  {
    id: "nl-NL",
    countryCode: "NL",
    labelCountry: "Netherlands",
    labelLanguage: "Nederlands",
    languageCode: "nl",
    currency: "EUR",
    currencySymbol: "€",
    vatLabel: "BTW",
    usesVat: true,
    defaultVatRate: VAT_RATES.NL,
    dateFormat: "dd-MM-yyyy",
    features: [],
    flag: "🇳🇱",
  },
  {
    id: "en-IE",
    countryCode: "IE",
    labelCountry: "Ireland",
    labelLanguage: "English",
    languageCode: "en",
    currency: "EUR",
    currencySymbol: "€",
    vatLabel: "VAT",
    usesVat: true,
    defaultVatRate: VAT_RATES.IE,
    dateFormat: "dd/MM/yyyy",
    features: [],
    flag: "🇮🇪",
  },
];

// Default locale (International English)
const DEFAULT_LOCALE = SUPPORTED_LOCALES[0];

// ============================================
// LOCALE LOOKUP FUNCTIONS
// ============================================

export const getLocaleById = (id) => {
  if (!id) return DEFAULT_LOCALE;
  return SUPPORTED_LOCALES.find((l) => l.id === id) || DEFAULT_LOCALE;
};

export const getLocaleByCountryAndLanguage = (countryCode, languageCode) => {
  if (!countryCode) return DEFAULT_LOCALE;
  const match = SUPPORTED_LOCALES.find(
    (l) => l.countryCode === countryCode && l.languageCode === languageCode
  );
  return match || getDefaultLocaleForCountry(countryCode);
};

export const getDefaultLocaleForCountry = (countryCode) => {
  if (!countryCode) return DEFAULT_LOCALE;
  return SUPPORTED_LOCALES.find((l) => l.countryCode === countryCode) || DEFAULT_LOCALE;
};

// ============================================
// BROWSER DETECTION
// ============================================

export const detectBrowserLocale = () => {
  if (typeof navigator === "undefined") return DEFAULT_LOCALE;
  
  const browserLang = navigator.language || navigator.userLanguage;
  if (!browserLang) return DEFAULT_LOCALE;

  // Try direct match first (e.g., "fr-FR")
  const directMatch = SUPPORTED_LOCALES.find(
    (l) => l.id.toLowerCase() === browserLang.toLowerCase()
  );
  if (directMatch) return directMatch;

  // Try matching language code only (e.g., "fr" -> "fr-FR")
  const langCode = browserLang.split("-")[0].toLowerCase();
  const langMatch = SUPPORTED_LOCALES.find(
    (l) => l.languageCode === langCode
  );
  if (langMatch) return langMatch;

  // Try matching by country from browser locale (e.g., "en-GB" -> GB)
  const countryCode = browserLang.split("-")[1]?.toUpperCase();
  if (countryCode) {
    const countryMatch = SUPPORTED_LOCALES.find(
      (l) => l.countryCode === countryCode
    );
    if (countryMatch) return countryMatch;
  }

  return DEFAULT_LOCALE;
};

// ============================================
// COUNTRY OPTIONS (for selectors)
// ============================================

export const getCountryOptions = () => {
  const countries = SUPPORTED_LOCALES.reduce((acc, locale) => {
    if (!acc[locale.countryCode]) {
      acc[locale.countryCode] = {
        code: locale.countryCode,
        name: locale.labelCountry,
        flag: locale.flag,
        languages: [],
      };
    }
    // Avoid duplicate languages for same country
    if (!acc[locale.countryCode].languages.find((l) => l.code === locale.languageCode)) {
      acc[locale.countryCode].languages.push({
        code: locale.languageCode,
        name: locale.labelLanguage,
        id: locale.id,
      });
    }
    return acc;
  }, {});
  return Object.values(countries);
};

// ============================================
// PERSISTENCE (localStorage + cookie)
// ============================================

const LOCALE_STORAGE_KEY = "drivee_locale";
const LOCALE_COOKIE_NAME = "drivee_locale";

export const saveLocalePreference = (localeId) => {
  if (typeof window === "undefined") return;
  
  // Save to localStorage
  try {
    localStorage.setItem(LOCALE_STORAGE_KEY, localeId);
  } catch (e) {
    console.warn("Could not save locale to localStorage:", e);
  }

  // Save to cookie (for potential SSR)
  try {
    const maxAge = 365 * 24 * 60 * 60; // 1 year
    document.cookie = `${LOCALE_COOKIE_NAME}=${localeId};path=/;max-age=${maxAge};SameSite=Lax`;
  } catch (e) {
    console.warn("Could not save locale to cookie:", e);
  }
};

export const getSavedLocalePreference = () => {
  if (typeof window === "undefined") return null;
  
  // Try localStorage first
  try {
    const saved = localStorage.getItem(LOCALE_STORAGE_KEY);
    if (saved && getLocaleById(saved).id !== DEFAULT_LOCALE.id) {
      return saved;
    }
  } catch (e) {
    console.warn("Could not read locale from localStorage:", e);
  }

  // Fallback to cookie
  try {
    const cookies = document.cookie.split(";");
    for (const cookie of cookies) {
      const [name, value] = cookie.trim().split("=");
      if (name === LOCALE_COOKIE_NAME && value) {
        return value;
      }
    }
  } catch (e) {
    console.warn("Could not read locale from cookie:", e);
  }

  return null;
};

export const clearLocalePreference = () => {
  if (typeof window === "undefined") return;
  
  try {
    localStorage.removeItem(LOCALE_STORAGE_KEY);
    document.cookie = `${LOCALE_COOKIE_NAME}=;path=/;max-age=0`;
  } catch (e) {
    console.warn("Could not clear locale preference:", e);
  }
};

// ============================================
// FEATURE FLAGS (like ANTS)
// ============================================

export const shouldShowAnts = (countryCode) => {
  if (!countryCode) return false;
  const locale = getDefaultLocaleForCountry(countryCode);
  return locale.features?.includes("ants") ?? false;
};

export const isFeatureEnabled = (countryCode, featureName) => {
  if (!countryCode || !featureName) return false;
  const locale = getDefaultLocaleForCountry(countryCode);
  return locale.features?.includes(featureName) ?? false;
};

// ============================================
// COMPATIBILITY FUNCTIONS (for existing code)
// ============================================

// Alias for backward compatibility
export const getCountryConfig = (countryCode) => {
  return getDefaultLocaleForCountry(countryCode);
};

// ============================================
// FORMATTING FUNCTIONS
// ============================================

export const formatCurrencyByCountry = (value, countryCode) => {
  if (value === null || value === undefined) return "—";
  const config = getCountryConfig(countryCode);
  return new Intl.NumberFormat(config.id || "en-INT", {
    style: "currency",
    currency: config.currency || "EUR",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
};

export const formatCurrencyByLocale = (value, localeId) => {
  if (value === null || value === undefined) return "—";
  const locale = getLocaleById(localeId);
  return new Intl.NumberFormat(locale.id, {
    style: "currency",
    currency: locale.currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
};

export const formatDateByCountry = (date, countryCode) => {
  if (!date) return "—";
  const config = getCountryConfig(countryCode);
  return new Intl.DateTimeFormat(config.id || "en-INT").format(new Date(date));
};

// ============================================
// INITIALISATION HELPER
// ============================================

/**
 * Get the initial locale for anonymous visitors on the marketing site.
 * Priority: URL param > saved preference > browser detection > default
 */
export const getInitialMarketingLocale = () => {
  if (typeof window === "undefined") return DEFAULT_LOCALE;

  // 1. Check URL for locale param or path
  const urlParams = new URLSearchParams(window.location.search);
  const localeParam = urlParams.get("locale");
  if (localeParam) {
    const paramLocale = getLocaleById(localeParam);
    if (paramLocale.id !== DEFAULT_LOCALE.id || localeParam === DEFAULT_LOCALE.id) {
      saveLocalePreference(paramLocale.id);
      return paramLocale;
    }
  }

  // 2. Check saved preference
  const saved = getSavedLocalePreference();
  if (saved) {
    return getLocaleById(saved);
  }

  // 3. Browser detection
  return detectBrowserLocale();
};

/**
 * Get the locale for authenticated users.
 * Uses user's preferredLanguage + school's operatingCountry
 */
export const getAuthenticatedLocale = (user, school) => {
  const preferredLang = user?.preferredLanguage || user?.preferred_language;
  const operatingCountry = school?.operatingCountry || school?.operating_country;

  if (preferredLang && operatingCountry) {
    return getLocaleByCountryAndLanguage(operatingCountry, preferredLang);
  }

  if (operatingCountry) {
    return getDefaultLocaleForCountry(operatingCountry);
  }

  // Fallback to marketing locale
  return getInitialMarketingLocale();
};