import { format } from "date-fns";

export const downloadExcelFile = (buffer, filename) => {
  const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
};

export const exportProfitLossToExcel = async (pnlData, filters) => {
  const csvRows = [];
  csvRows.push(["Profit & Loss Statement"]);
  csvRows.push([`${format(new Date(filters.startDate), "MMM d, yyyy")} - ${format(new Date(filters.endDate), "MMM d, yyyy")}`]);
  csvRows.push([]);
  csvRows.push(["Account", "Amount", filters.showComparison ? "Previous" : "", filters.showComparison ? "Change %" : ""].filter(Boolean));
  
  csvRows.push(["INCOME", `€${pnlData.totalIncome.toLocaleString()}`]);
  csvRows.push(["  Driving Lessons", `€${pnlData.income.lessons.toLocaleString()}`]);
  csvRows.push(["  Lesson Packages", `€${pnlData.income.packages.toLocaleString()}`]);
  csvRows.push(["  Exam Fees", `€${pnlData.income.exams.toLocaleString()}`]);
  csvRows.push(["  Theory Training", `€${pnlData.income.theory.toLocaleString()}`]);
  csvRows.push(["  Other Income", `€${pnlData.income.other.toLocaleString()}`]);
  csvRows.push(["Total Income", `€${pnlData.totalIncome.toLocaleString()}`]);
  csvRows.push([]);
  
  csvRows.push(["COST OF REVENUE", `€${pnlData.cogs.total.toLocaleString()}`]);
  csvRows.push(["  Instructor Commissions", `€${pnlData.cogs.instructorCommissions.toLocaleString()}`]);
  csvRows.push(["Gross Profit", `€${pnlData.grossProfit.toLocaleString()}`, `${pnlData.grossMargin.toFixed(1)}% margin`]);
  csvRows.push([]);
  
  csvRows.push(["OPERATING EXPENSES", `€${pnlData.totalExpenses.toLocaleString()}`]);
  Object.entries(pnlData.expensesByCategory).forEach(([category, amount]) => {
    csvRows.push([`  ${category}`, `€${amount.toLocaleString()}`]);
  });
  csvRows.push([]);
  
  csvRows.push(["NET INCOME", `€${pnlData.netIncome.toLocaleString()}`, `${pnlData.netMargin.toFixed(1)}% margin`]);
  
  const csvContent = csvRows.map(row => row.join(",")).join("\n");
  const blob = new Blob([csvContent], { type: "text/csv" });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `Profit_and_Loss_${format(new Date(), "yyyy-MM-dd")}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
};