// Role-Based Access Control utility

export const ROLES = {
  SUPER_ADMIN: 'admin',  // Management - FULL ACCESS TO EVERYTHING
  INSTRUCTOR: 'instructor',
  STUDENT: 'user'
};

// PERMISSION MATRIX
// 'admin' = MANAGEMENT with FULL UNRESTRICTED ACCESS to all features, data, and settings
// 'instructor' = Limited access to own students, schedule, and earnings
// 'user' = Student access only

export const PERMISSIONS = {
  // ==================== MANAGEMENT: FULL ACCESS ====================
  // Student Management - FULL ACCESS
  VIEW_ALL_STUDENTS: ['admin'],
  EDIT_ALL_STUDENTS: ['admin'],
  DELETE_STUDENTS: ['admin'],
  VIEW_ASSIGNED_STUDENTS: ['admin', 'instructor'],
  EDIT_ASSIGNED_STUDENTS: ['admin', 'instructor'],
  
  // Booking Management - FULL ACCESS
  VIEW_ALL_BOOKINGS: ['admin'],
  CREATE_ANY_BOOKING: ['admin'],
  CREATE_OWN_BOOKING: ['admin', 'instructor'],
  EDIT_ANY_BOOKING: ['admin'],
  EDIT_OWN_BOOKING: ['admin', 'instructor'],
  CANCEL_ANY_BOOKING: ['admin'],
  CANCEL_OWN_BOOKING: ['admin', 'instructor'],
  MANAGE_OWN_SCHEDULE: ['admin', 'instructor'],
  
  // Financial Access - School-Wide (MANAGEMENT ONLY)
  VIEW_SCHOOL_FINANCIAL_REPORTS: ['admin'],
  VIEW_SCHOOL_REVENUE: ['admin'],
  VIEW_ALL_INSTRUCTOR_EARNINGS: ['admin'],
  MANAGE_SCHOOL_PAYMENTS: ['admin'],
  VIEW_SCHOOL_ACCOUNTING: ['admin'],
  MANAGE_PAYROLL: ['admin'],
  EDIT_PRICING: ['admin'],
  MANAGE_REFUNDS_ALL: ['admin'],
  EDIT_FINANCIAL_SETTINGS: ['admin'],
  SET_COMMISSION_RATES: ['admin'],
  
  // Financial Access - Own Activity (Instructors can manage their own)
  CREATE_OWN_INVOICES: ['admin', 'instructor'],
  SEND_OWN_PAYMENT_REQUESTS: ['admin', 'instructor'],
  ACCEPT_OWN_PAYMENTS: ['admin', 'instructor'],
  VIEW_OWN_REVENUE: ['admin', 'instructor'],
  VIEW_OWN_PNL: ['admin', 'instructor'],
  TRACK_OWN_OUTSTANDING: ['admin', 'instructor'],
  VIEW_OWN_COMMISSION: ['admin', 'instructor'],
  EXPORT_OWN_EARNINGS: ['admin', 'instructor'],
  VIEW_OWN_STUDENTS_INVOICES: ['admin', 'instructor'],
  
  // Staff Management - FULL ACCESS
  VIEW_ALL_INSTRUCTORS: ['admin'],
  MANAGE_INSTRUCTORS: ['admin'],
  MANAGE_STAFF_ACCOUNTS: ['admin'],
  ASSIGN_STUDENTS_TO_INSTRUCTORS: ['admin'],
  VIEW_INSTRUCTOR_SCHEDULES: ['admin'],
  
  // Fleet Management - FULL ACCESS
  VIEW_ALL_FLEET: ['admin'],
  MANAGE_FLEET: ['admin'],
  VIEW_ASSIGNED_VEHICLES: ['admin', 'instructor'],
  REPORT_VEHICLE_ISSUES: ['admin', 'instructor'],
  MANAGE_MAINTENANCE: ['admin'],
  ASSIGN_VEHICLES: ['admin'],
  
  // Theory & Education - FULL ACCESS
  MANAGE_THEORY_LESSONS: ['admin'],
  TEACH_THEORY_SESSIONS: ['admin', 'instructor'],
  MANAGE_EXAMS: ['admin'],
  
  // Pricing & Services - FULL ACCESS
  MANAGE_PRICING: ['admin'],
  MANAGE_PACKAGES: ['admin'],
  MANAGE_SERVICE_TEMPLATES: ['admin'],
  
  // Communication - FULL ACCESS
  SEND_SCHOOL_ANNOUNCEMENTS: ['admin'],
  MESSAGE_OWN_STUDENTS: ['admin', 'instructor'],
  MESSAGE_ALL_STUDENTS: ['admin'],
  
  // Marketing & Website - FULL ACCESS
  MANAGE_MARKETING: ['admin'],
  MANAGE_CAMPAIGNS: ['admin'],
  MANAGE_PROMO_CODES: ['admin'],
  MANAGE_GIFT_CARDS: ['admin'],
  MANAGE_WEBSITE: ['admin'],
  MANAGE_SEO: ['admin'],
  
  // Settings & Analytics - FULL ACCESS
  MANAGE_SCHOOL_SETTINGS: ['admin'],
  MANAGE_BRANCH_SETTINGS: ['admin'],
  VIEW_ALL_ANALYTICS: ['admin'],
  VIEW_OWN_PERFORMANCE: ['admin', 'instructor'],
  EXPORT_SCHOOL_REPORTS: ['admin'],
  ACCESS_AUDIT_LOGS: ['admin'],
  CONFIGURE_INTEGRATIONS: ['admin'],
  MANAGE_USER_ROLES: ['admin'],
  
  // Lesson Management
  MARK_ATTENDANCE: ['admin', 'instructor'],
  UPDATE_LESSON_NOTES: ['admin', 'instructor'],
  UPDATE_STUDENT_PROGRESS: ['admin', 'instructor'],
  UPLOAD_LESSON_DOCUMENTS: ['admin', 'instructor'],
  
  // Calendar Management
  BLOCK_OWN_TIME: ['admin', 'instructor'],
  REPORT_NO_SHOW: ['admin', 'instructor'],
  VIEW_OWN_FEEDBACK: ['admin', 'instructor'],
};

export const hasPermission = (userRole, permission) => {
  if (!userRole || !permission) return false;
  const allowedRoles = PERMISSIONS[permission];
  return allowedRoles && allowedRoles.includes(userRole);
};

export const hasAnyPermission = (userRole, permissions) => {
  return permissions.some(permission => hasPermission(userRole, permission));
};

export const getRoleDisplayName = (role) => {
  switch(role) {
    case ROLES.SUPER_ADMIN:
      return 'Management';
    case ROLES.INSTRUCTOR:
      return 'Instructor';
    case ROLES.STUDENT:
      return 'Student';
    default:
      return 'User';
  }
};

export const getDefaultRoute = (userRole) => {
  switch(userRole) {
    case ROLES.SUPER_ADMIN:
      return 'Dashboard';  // Full Management Dashboard
    case ROLES.INSTRUCTOR:
      return 'InstructorSchedule';
    case ROLES.STUDENT:
      return 'StudentDashboard';
    default:
      return 'Landing';
  }
};

// Helper to check if user has full system access
export const isManagement = (userRole) => {
  return userRole === ROLES.SUPER_ADMIN;
};

export const canViewOwnFinances = (userRole) => {
  return userRole === ROLES.SUPER_ADMIN || userRole === ROLES.INSTRUCTOR;
};

export const canViewSchoolFinances = (userRole) => {
  return userRole === ROLES.SUPER_ADMIN;
};