
/**
 * Application Configuration
 * Centralized environment and feature flags
 */

// Environment configuration
const APP_ENV = import.meta.env.VITE_APP_ENV || import.meta.env.MODE || "production";
const IS_PRODUCTION = APP_ENV === "production";
const IS_DEVELOPMENT = !IS_PRODUCTION; // Safe default: production unless explicitly set to development

// Feature Flags - DEV-only features must be false in production
// CRITICAL: ENABLE_DEV_AUTH can ONLY be true in development mode
export const ENABLE_DEV_AUTH = IS_DEVELOPMENT && import.meta.env.VITE_ENABLE_DEV_AUTH === "true";
export const ENABLE_ANALYTICS = import.meta.env.VITE_ENABLE_ANALYTICS === "true";
export const ENABLE_DEBUG_LOGS = IS_DEVELOPMENT;

export const APP_CONFIG = {
  // Environment
  APP_ENV,
  IS_PRODUCTION,
  IS_DEVELOPMENT,

  // App Info
  APP_VERSION: "1.0.0",
  APP_NAME: "DRIVEE",
  
  // API Configuration
  API_BASE_URL: import.meta.env.VITE_API_BASE_URL || "",
  
  // Feature Flags
  ENABLE_DEV_AUTH,
  ENABLE_ANALYTICS,
  ENABLE_DEBUG_LOGS,
  
  // Support
  SUPPORT_EMAIL: "support@drivee.com",
  SUPPORT_PHONE: "+33 1 23 45 67 89",
};

// Safe logger that respects production mode
export const logger = {
  log: (...args) => {
    if (ENABLE_DEBUG_LOGS) {
      console.log(...args);
    }
  },
  warn: (...args) => {
    if (ENABLE_DEBUG_LOGS) {
      console.warn(...args);
    }
  },
  error: (...args) => {
    // Always log errors, but sanitize in production
    if (IS_PRODUCTION) {
      console.error("[ERROR]", args[0]); // Only log first arg in production
    } else {
      console.error(...args);
    }
  },
  auth: (...args) => {
    if (ENABLE_DEBUG_LOGS) {
      console.log("[AUTH]", ...args);
    }
    // NEVER log auth info in production
  },
  data: (...args) => {
    if (ENABLE_DEBUG_LOGS) {
      console.log("[DATA]", ...args);
    }
    // NEVER log user data in production
  },
};
