import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Loader2 } from "lucide-react";

/**
 * Protected Route Component
 * Redirects to login if user is not authenticated
 * 
 * Usage: Wrap your protected pages with this component
 */
export default function ProtectedRoute({ children, redirectTo = "Login" }) {
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        await base44.auth.me();
        setAuthenticated(true);
      } catch (error) {
        // User not authenticated - redirect to login
        window.location.href = createPageUrl(redirectTo);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, [redirectTo]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!authenticated) {
    return null;
  }

  return <>{children}</>;
}

/**
 * Hook to check authentication status
 * @returns {Object} { user, loading, authenticated }
 */
export function useAuth() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        setAuthenticated(true);
      } catch (error) {
        setUser(null);
        setAuthenticated(false);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  return { user, loading, authenticated };
}