import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Loader2 } from "lucide-react";

/**
 * RequireStudentAuth - Auth gate for student booking actions
 * 
 * Wraps booking buttons/actions and checks if user is authenticated as a student.
 * If not, redirects to StudentAuth page with context preserved.
 * 
 * Usage:
 * <RequireStudentAuth
 *   schoolId="abc123"
 *   schoolName="Premier Driving"
 *   action="book"
 *   onAuthenticated={() => navigate("/book")}
 * >
 *   <button>Book Now</button>
 * </RequireStudentAuth>
 */
export default function RequireStudentAuth({
  children,
  schoolId,
  schoolName,
  action = "book", // book | availability
  returnTo,
  onAuthenticated,
  className
}) {
  const navigate = useNavigate();
  const [isChecking, setIsChecking] = useState(false);

  const redirectToAuth = useCallback(() => {
    const params = new URLSearchParams();
    if (schoolId) params.set("schoolId", schoolId);
    if (schoolName) params.set("schoolName", schoolName);
    if (action) params.set("action", action);
    if (returnTo) params.set("returnTo", returnTo);
    
    navigate(`${createPageUrl("StudentAuth")}?${params.toString()}`);
  }, [schoolId, schoolName, action, returnTo, navigate]);

  const checkAuthAndProceed = useCallback(async () => {
    setIsChecking(true);
    
    try {
      // Check dev session first
      const devUser = sessionStorage.getItem("dev_auth_user");
      if (devUser) {
        try {
          const user = JSON.parse(devUser);
          if (user.role === "user") {
            // Authenticated as student, proceed
            if (onAuthenticated) {
              onAuthenticated();
            }
            setIsChecking(false);
            return;
          }
        } catch (err) {
          // Invalid dev session
        }
      }

      // Check real auth
      const isAuth = await base44.auth.isAuthenticated();
      
      if (!isAuth) {
        // Not authenticated - redirect to StudentAuth
        redirectToAuth();
        setIsChecking(false);
        return;
      }

      const user = await base44.auth.me();
      
      if (user && user.role === "user") {
        // Authenticated as student
        if (onAuthenticated) {
          onAuthenticated();
        }
        setIsChecking(false);
        return;
      }

      // Logged in but not as student - redirect to student auth
      redirectToAuth();
    } catch (error) {
      // Auth error - redirect
      redirectToAuth();
    } finally {
      setIsChecking(false);
    }
  }, [schoolId, schoolName, action, returnTo, onAuthenticated, redirectToAuth]);

  const handleClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    checkAuthAndProceed();
  };

  // Clone children and attach click handler
  if (React.isValidElement(children)) {
    return React.cloneElement(children, {
      onClick: handleClick,
      disabled: isChecking || children.props.disabled,
      className: `${children.props.className || ""} ${className || ""}`.trim(),
      children: isChecking ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin" />
          {typeof children.props.children === "string" ? children.props.children : null}
        </>
      ) : children.props.children
    });
  }

  // Fallback: wrap in a span
  return (
    <span onClick={handleClick} className={className}>
      {children}
    </span>
  );
}

/**
 * Hook to check if user is authenticated as a student
 * Returns { isStudent, isLoading, user, redirectToAuth }
 */
export function useStudentAuth() {
  const navigate = useNavigate();
  const [state, setState] = useState({
    isStudent: false,
    isLoading: true,
    user: null
  });

  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Check dev session
        const devUser = sessionStorage.getItem("dev_auth_user");
        if (devUser) {
          const user = JSON.parse(devUser);
          setState({
            isStudent: user.role === "user",
            isLoading: false,
            user
          });
          return;
        }

        const user = await base44.auth.me();
        setState({
          isStudent: user?.role === "user",
          isLoading: false,
          user
        });
      } catch {
        setState({
          isStudent: false,
          isLoading: false,
          user: null
        });
      }
    };

    checkAuth();
  }, []);

  const redirectToAuth = useCallback((options = {}) => {
    const params = new URLSearchParams();
    if (options.schoolId) params.set("schoolId", options.schoolId);
    if (options.schoolName) params.set("schoolName", options.schoolName);
    if (options.action) params.set("action", options.action);
    if (options.returnTo) params.set("returnTo", options.returnTo);
    
    navigate(`${createPageUrl("StudentAuth")}?${params.toString()}`);
  }, [navigate]);

  return {
    ...state,
    redirectToAuth
  };
}