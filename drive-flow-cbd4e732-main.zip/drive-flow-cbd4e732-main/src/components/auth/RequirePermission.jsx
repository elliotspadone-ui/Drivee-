import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { hasPermission } from "@/components/utils/permissions";
import { createPageUrl } from "@/utils";
import { Loader2, AlertCircle } from "lucide-react";

/**
 * Higher-order component to protect pages/routes with permissions
 * Redirects to unauthorized page if user doesn't have permission
 * 
 * Usage:
 * export default RequirePermission(YourComponent, 'instructors.view');
 */
export default function RequirePermission(Component, requiredPermission) {
  return function ProtectedComponent(props) {
    const [authorized, setAuthorized] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
      const checkAccess = async () => {
        try {
          const user = await base44.auth.me();
          
          if (!user || !user.role) {
            setAuthorized(false);
            setLoading(false);
            return;
          }

          // Check permission
          const hasAccess = hasPermission(user.role, requiredPermission);
          setAuthorized(hasAccess);
        } catch (error) {
          setAuthorized(false);
        } finally {
          setLoading(false);
        }
      };

      checkAccess();
    }, []);

    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mx-auto mb-4" />
            <p className="text-gray-600">Checking permissions...</p>
          </div>
        </div>
      );
    }

    if (!authorized) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8 text-red-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h1>
            <p className="text-gray-600 mb-6">
              You don't have permission to access this page.
            </p>
            <button
              onClick={() => window.history.back()}
              className="px-6 py-3 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 transition"
            >
              Go Back
            </button>
          </div>
        </div>
      );
    }

    return <Component {...props} />;
  };
}

/**
 * Hook to check if current user has a permission
 * @param {string} permission - Permission to check
 * @returns {boolean}
 */
export function usePermission(permission) {
  const [hasAccess, setHasAccess] = useState(false);

  useEffect(() => {
    const checkPermission = async () => {
      try {
        const user = await base44.auth.me();
        if (user && user.role) {
          setHasAccess(hasPermission(user.role, permission));
        }
      } catch (error) {
        setHasAccess(false);
      }
    };

    checkPermission();
  }, [permission]);

  return hasAccess;
}