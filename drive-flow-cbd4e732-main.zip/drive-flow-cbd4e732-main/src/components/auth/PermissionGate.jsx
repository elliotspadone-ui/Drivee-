import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { hasPermission } from "@/components/utils/permissions";
import { AlertCircle } from "lucide-react";

/**
 * Permission Gate Component
 * Shows children only if user has required permission
 * 
 * @param {string|string[]} requires - Required permission(s)
 * @param {React.ReactNode} children - Content to show if authorized
 * @param {React.ReactNode} fallback - Content to show if not authorized
 */
export default function PermissionGate({ 
  requires, 
  children, 
  fallback = null 
}) {
  const [hasAccess, setHasAccess] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkPermission = async () => {
      try {
        const user = await base44.auth.me();
        const userRole = user.role;
        
        if (!userRole) {
          setHasAccess(false);
          setLoading(false);
          return;
        }

        // Check if user has required permission(s)
        if (Array.isArray(requires)) {
          // User needs ANY of these permissions
          const allowed = requires.some(perm => hasPermission(userRole, perm));
          setHasAccess(allowed);
        } else {
          // User needs this specific permission
          setHasAccess(hasPermission(userRole, requires));
        }
      } catch (error) {
        setHasAccess(false);
      } finally {
        setLoading(false);
      }
    };

    checkPermission();
  }, [requires]);

  if (loading) {
    return null;
  }

  if (!hasAccess) {
    return fallback;
  }

  return <>{children}</>;
}

/**
 * No Permission Fallback Component
 */
export function NoPermission({ message = "You don't have permission to access this." }) {
  return (
    <div className="flex items-center justify-center p-8">
      <div className="text-center max-w-md">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertCircle className="w-8 h-8 text-red-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Access Denied</h3>
        <p className="text-gray-600">{message}</p>
      </div>
    </div>
  );
}