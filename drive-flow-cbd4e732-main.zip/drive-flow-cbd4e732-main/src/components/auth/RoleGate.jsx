import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

/**
 * Role Gate Component
 * Shows children only if user has one of the allowed roles
 * 
 * @param {string|string[]} allowedRoles - Role(s) that can see content
 * @param {React.ReactNode} children - Content to show if authorized
 * @param {React.ReactNode} fallback - Content to show if not authorized
 */
export default function RoleGate({ allowedRoles, children, fallback = null }) {
  const [hasAccess, setHasAccess] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkRole = async () => {
      try {
        const user = await base44.auth.me();
        const userRole = user.role;
        
        if (!userRole) {
          setHasAccess(false);
          setLoading(false);
          return;
        }

        // Check if user's role is in allowed roles
        const rolesArray = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];
        setHasAccess(rolesArray.includes(userRole));
      } catch (error) {
        setHasAccess(false);
      } finally {
        setLoading(false);
      }
    };

    checkRole();
  }, [allowedRoles]);

  if (loading) {
    return null;
  }

  if (!hasAccess) {
    return fallback;
  }

  return <>{children}</>;
}

/**
 * Hook to check if current user has a specific role
 * @param {string} role - Role to check
 * @returns {boolean}
 */
export function useRole(role) {
  const [hasRole, setHasRole] = useState(false);

  useEffect(() => {
    const checkRole = async () => {
      try {
        const user = await base44.auth.me();
        setHasRole(user && user.role === role);
      } catch (error) {
        setHasRole(false);
      }
    };

    checkRole();
  }, [role]);

  return hasRole;
}