import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { isPublicPage, getDefaultRoute } from "@/components/utils/routing";
import { logger } from "@/components/utils/config";
import { Loader2 } from "lucide-react";

/**
 * RouteGuard - Production-ready route protection
 * Ensures proper authentication and redirects for all pages
 */
export default function RouteGuard({ children, currentPageName }) {
  const location = useLocation();
  const [checking, setChecking] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const checkAuth = async () => {
      // Skip auth check for public pages
      if (isPublicPage(currentPageName)) {
        setChecking(false);
        return;
      }

      try {
        const currentUser = await base44.auth.me();
        
        if (!currentUser) {
          // Not authenticated - redirect to appropriate login
          logger.auth("User not authenticated, redirecting to login");
          
          // Preserve current page for post-login redirect
          const redirectUrl = `${currentPageName}${location.search}`;
          
          if (currentPageName.startsWith("Student")) {
            window.location.href = `${createPageUrl("StudentAuth")}?redirect=${encodeURIComponent(redirectUrl)}`;
          } else {
            window.location.href = `${createPageUrl("SchoolLogin")}?redirect=${encodeURIComponent(redirectUrl)}`;
          }
          return;
        }

        setUser(currentUser);
        setChecking(false);
        
      } catch (err) {
        logger.error("Auth check failed:", err);
        
        // On auth error, redirect to appropriate login
        if (currentPageName.startsWith("Student")) {
          window.location.href = createPageUrl("StudentAuth");
        } else {
          window.location.href = createPageUrl("SchoolLogin");
        }
      }
    };

    checkAuth();
  }, [currentPageName, location.search]);

  // Show loading for protected pages during auth check
  if (checking && !isPublicPage(currentPageName)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-[#3b82c4] mx-auto mb-4" />
          <p className="text-zinc-600 font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  return children;
}