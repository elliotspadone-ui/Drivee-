import React from "react";
import { X } from "lucide-react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";

export default function DrilldownPanel({ isOpen, onClose, section, label, transactions }) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-gray-50">
            <div>
              <h2 className="text-xl font-bold text-gray-900">{label}</h2>
              <p className="text-sm text-gray-600 mt-1">{transactions.length} transactions</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-200 rounded-lg transition"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    <th className="text-left py-2 px-3 text-xs font-semibold text-gray-700">Date</th>
                    <th className="text-left py-2 px-3 text-xs font-semibold text-gray-700">Type</th>
                    <th className="text-left py-2 px-3 text-xs font-semibold text-gray-700">Reference</th>
                    <th className="text-right py-2 px-3 text-xs font-semibold text-gray-700">Amount</th>
                    <th className="text-left py-2 px-3 text-xs font-semibold text-gray-700">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((tx) => (
                    <tr key={tx.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-2 px-3 text-sm">
                        {format(new Date(tx.payment_date || tx.start_datetime || tx.expense_date || tx.created_date), "MMM d, yyyy")}
                      </td>
                      <td className="py-2 px-3 text-sm capitalize">
                        {tx.payment_type || tx.category || "Transaction"}
                      </td>
                      <td className="py-2 px-3 text-sm font-mono text-xs text-gray-600">
                        {tx.transaction_id || tx.invoice_number || tx.id?.slice(0, 8)}
                      </td>
                      <td className="py-2 px-3 text-sm text-right font-semibold">
                        €{(tx.amount || tx.price || 0).toLocaleString()}
                      </td>
                      <td className="py-2 px-3 text-sm">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          tx.status === "completed" || tx.status === "paid"
                            ? "bg-green-100 text-green-700"
                            : "bg-gray-100 text-gray-700"
                        }`}>
                          {tx.status || "completed"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {transactions.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-gray-500">No transactions found</p>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}