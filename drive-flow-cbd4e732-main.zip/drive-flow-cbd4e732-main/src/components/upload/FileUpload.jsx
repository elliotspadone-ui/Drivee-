import React, { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload,
  X,
  File,
  FileImage,
  FileText,
  FileVideo,
  FileAudio,
  CheckCircle,
  AlertCircle,
  Loader2,
  Trash2,
  Eye,
  Download,
  Cloud,
  CloudUpload
} from "lucide-react";
import { base44 } from "@/api/base44Client";

/**
 * FileUpload - Animated file upload with progress tracking
 * 
 * @param {Function} onUpload - Callback when file is uploaded successfully
 * @param {Function} onError - Callback on upload error
 * @param {string[]} accept - Accepted file types
 * @param {number} maxSize - Max file size in MB
 * @param {boolean} multiple - Allow multiple files
 * @param {string} uploadEndpoint - Custom upload endpoint
 */
export default function FileUpload({
  onUpload,
  onError,
  accept = ["image/*", "application/pdf", ".doc", ".docx"],
  maxSize = 10,
  multiple = false,
  className = "",
  title = "Upload Files",
  description = "Drag and drop or click to browse"
}) {
  const [files, setFiles] = useState([]);
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef(null);

  // Get file icon based on type
  const getFileIcon = (type) => {
    if (type.startsWith("image/")) return FileImage;
    if (type.startsWith("video/")) return FileVideo;
    if (type.startsWith("audio/")) return FileAudio;
    if (type.includes("pdf") || type.includes("document")) return FileText;
    return File;
  };

  // Format file size
  const formatSize = (bytes) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // Handle file selection
  const handleFiles = useCallback((selectedFiles) => {
    const newFiles = Array.from(selectedFiles).map((file) => ({
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      file,
      name: file.name,
      size: file.size,
      type: file.type,
      progress: 0,
      status: "pending", // pending, uploading, success, error
      url: null,
      error: null
    }));

    // Validate file size
    const validFiles = newFiles.filter((f) => {
      if (f.size > maxSize * 1024 * 1024) {
        f.status = "error";
        f.error = `File exceeds ${maxSize}MB limit`;
        return true;
      }
      return true;
    });

    setFiles((prev) => (multiple ? [...prev, ...validFiles] : validFiles));

    // Auto-start upload for valid files
    validFiles.forEach((f) => {
      if (f.status === "pending") {
        uploadFile(f);
      }
    });
  }, [maxSize, multiple]);

  // Upload single file
  const uploadFile = async (fileObj) => {
    setFiles((prev) =>
      prev.map((f) =>
        f.id === fileObj.id ? { ...f, status: "uploading", progress: 0 } : f
      )
    );

    try {
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setFiles((prev) =>
          prev.map((f) => {
            if (f.id === fileObj.id && f.status === "uploading") {
              const newProgress = Math.min(f.progress + Math.random() * 15, 90);
              return { ...f, progress: newProgress };
            }
            return f;
          })
        );
      }, 200);

      // Actual upload
      const result = await base44.integrations.Core.UploadFile({
        file: fileObj.file
      });

      clearInterval(progressInterval);

      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileObj.id
            ? { ...f, status: "success", progress: 100, url: result.file_url }
            : f
        )
      );

      onUpload?.({ ...fileObj, url: result.file_url });
    } catch (error) {
      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileObj.id
            ? { ...f, status: "error", error: error.message || "Upload failed" }
            : f
        )
      );
      onError?.(error);
    }
  };

  // Retry failed upload
  const retryUpload = (fileObj) => {
    setFiles((prev) =>
      prev.map((f) =>
        f.id === fileObj.id ? { ...f, status: "pending", progress: 0, error: null } : f
      )
    );
    uploadFile(fileObj);
  };

  // Remove file
  const removeFile = (id) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };

  // Drag handlers
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Drop Zone */}
      <motion.div
        className={`relative border-2 border-dashed rounded-2xl p-8 transition-colors cursor-pointer ${
          isDragging
            ? "border-[#3b82c4] bg-[#e8f4fa]"
            : "border-gray-300 hover:border-[#a9d5ed] hover:bg-gray-50"
        }`}
        onClick={() => inputRef.current?.click()}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
        animate={isDragging ? { scale: 1.02 } : { scale: 1 }}
      >
        <input
          ref={inputRef}
          type="file"
          accept={accept.join(",")}
          multiple={multiple}
          onChange={(e) => handleFiles(e.target.files)}
          className="hidden"
        />

        <div className="flex flex-col items-center text-center">
          <motion.div
            className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-4 ${
              isDragging ? "bg-[#3b82c4]" : "bg-[#e8f4fa]"
            }`}
            animate={isDragging ? { y: [0, -8, 0] } : { y: 0 }}
            transition={{ duration: 0.5, repeat: isDragging ? Infinity : 0 }}
          >
            <CloudUpload
              className={`w-8 h-8 ${isDragging ? "text-white" : "text-[#3b82c4]"}`}
            />
          </motion.div>

          <h3 className="text-lg font-semibold text-gray-900 mb-1">{title}</h3>
          <p className="text-sm text-gray-600 mb-2">{description}</p>
          <p className="text-xs text-gray-400">
            Max file size: {maxSize}MB
          </p>
        </div>

        {/* Drag overlay */}
        <AnimatePresence>
          {isDragging && (
            <motion.div
              className="absolute inset-0 bg-[#3b82c4]/10 rounded-2xl flex items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.div
                className="text-[#3b82c4] font-semibold text-lg"
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 0.5, repeat: Infinity }}
              >
                Drop files here
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* File List */}
      <AnimatePresence mode="popLayout">
        {files.map((fileObj) => (
          <FileItem
            key={fileObj.id}
            fileObj={fileObj}
            onRemove={() => removeFile(fileObj.id)}
            onRetry={() => retryUpload(fileObj)}
            getFileIcon={getFileIcon}
            formatSize={formatSize}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}

/**
 * FileItem - Individual file with progress animation
 */
function FileItem({ fileObj, onRemove, onRetry, getFileIcon, formatSize }) {
  const Icon = getFileIcon(fileObj.type);
  const isUploading = fileObj.status === "uploading";
  const isSuccess = fileObj.status === "success";
  const isError = fileObj.status === "error";

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, x: -100, scale: 0.9 }}
      transition={{ type: "spring", stiffness: 500, damping: 30 }}
      className={`relative bg-white rounded-xl border-2 p-4 overflow-hidden ${
        isError ? "border-[#fdeeed]" : isSuccess ? "border-[#d4f4c3]" : "border-gray-200"
      }`}
    >
      {/* Progress Background */}
      <motion.div
        className="absolute inset-0 bg-[#e8f4fa]"
        initial={{ scaleX: 0 }}
        animate={{ scaleX: fileObj.progress / 100 }}
        style={{ originX: 0 }}
        transition={{ duration: 0.3 }}
      />

      <div className="relative z-10 flex items-center gap-4">
        {/* File Icon */}
        <motion.div
          className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
            isError
              ? "bg-[#fdeeed]"
              : isSuccess
              ? "bg-[#eefbe7]"
              : "bg-[#e8f4fa]"
          }`}
          animate={isUploading ? { rotate: [0, 5, -5, 0] } : {}}
          transition={{ duration: 0.5, repeat: isUploading ? Infinity : 0 }}
        >
          {isUploading ? (
            <Loader2 className="w-6 h-6 text-[#3b82c4] animate-spin" />
          ) : isSuccess ? (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 500, damping: 25 }}
            >
              <CheckCircle className="w-6 h-6 text-[#5cb83a]" />
            </motion.div>
          ) : isError ? (
            <AlertCircle className="w-6 h-6 text-[#e44138]" />
          ) : (
            <Icon className="w-6 h-6 text-[#3b82c4]" />
          )}
        </motion.div>

        {/* File Info */}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-gray-900 truncate">
            {fileObj.name}
          </p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs text-gray-500">{formatSize(fileObj.size)}</span>
            
            {isUploading && (
              <motion.span
                className="text-xs font-medium text-[#3b82c4]"
                key={Math.round(fileObj.progress)}
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
              >
                {Math.round(fileObj.progress)}%
              </motion.span>
            )}
            
            {isSuccess && (
              <motion.span
                className="text-xs font-medium text-[#5cb83a]"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                Uploaded
              </motion.span>
            )}
            
            {isError && (
              <span className="text-xs font-medium text-[#e44138]">
                {fileObj.error}
              </span>
            )}
          </div>

          {/* Progress Bar */}
          {isUploading && (
            <div className="mt-2 h-1.5 bg-gray-200 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-[#3b82c4] to-[#a9d5ed] rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${fileObj.progress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1">
          {isError && (
            <motion.button
              onClick={onRetry}
              className="p-2 text-[#3b82c4] hover:bg-[#e8f4fa] rounded-lg transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Loader2 className="w-4 h-4" />
            </motion.button>
          )}
          
          {isSuccess && fileObj.url && (
            <motion.a
              href={fileObj.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Eye className="w-4 h-4" />
            </motion.a>
          )}

          <motion.button
            onClick={onRemove}
            className="p-2 text-gray-400 hover:text-[#e44138] hover:bg-[#fdeeed] rounded-lg transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <X className="w-4 h-4" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}

/**
 * CompactFileUpload - Smaller inline upload button
 */
export function CompactFileUpload({
  onUpload,
  accept = ["image/*"],
  label = "Upload",
  className = ""
}) {
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const inputRef = useRef(null);

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setProgress(0);

    const progressInterval = setInterval(() => {
      setProgress((p) => Math.min(p + Math.random() * 20, 90));
    }, 200);

    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      clearInterval(progressInterval);
      setProgress(100);
      onUpload?.({ file, url: result.file_url });
      
      setTimeout(() => {
        setIsUploading(false);
        setProgress(0);
      }, 500);
    } catch (error) {
      clearInterval(progressInterval);
      setIsUploading(false);
      setProgress(0);
    }
  };

  return (
    <motion.label
      className={`relative inline-flex items-center gap-2 px-4 py-2 bg-[#e8f4fa] hover:bg-[#d4eaf5] text-[#3b82c4] rounded-xl cursor-pointer transition-colors overflow-hidden ${className}`}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept.join(",")}
        onChange={handleUpload}
        className="hidden"
      />
      
      {/* Progress overlay */}
      {isUploading && (
        <motion.div
          className="absolute inset-0 bg-[#3b82c4]"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: progress / 100 }}
          style={{ originX: 0 }}
        />
      )}

      <span className="relative z-10 flex items-center gap-2">
        {isUploading ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <Upload className="w-4 h-4" />
        )}
        <span className="text-sm font-semibold">
          {isUploading ? `${Math.round(progress)}%` : label}
        </span>
      </span>
    </motion.label>
  );
}