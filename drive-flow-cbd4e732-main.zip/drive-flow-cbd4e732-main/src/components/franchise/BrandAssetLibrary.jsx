import React, { useState } from "react";
import { Image, FileText, Video, Download, Search, Filter, Upload } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function BrandAssetLibrary({ assets = [] }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const categories = [
    { id: "all", label: "All Assets", icon: FileText },
    { id: "logo", label: "Logos", icon: Image },
    { id: "template", label: "Templates", icon: FileText },
    { id: "social_media", label: "Social Media", icon: Image },
    { id: "video", label: "Videos", icon: Video }
  ];

  const filteredAssets = assets.filter(asset => {
    const matchesSearch = asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         asset.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || asset.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleDownload = (asset) => {
    // In production, track download
    toast.success(`Downloading ${asset.name}`);
    window.open(asset.file_url, '_blank');
  };

  const getCategoryIcon = (category) => {
    const cat = categories.find(c => c.id === category);
    return cat ? cat.icon : FileText;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Brand Asset Library</h2>
            <p className="text-sm text-muted">Corporate-approved marketing materials</p>
          </div>
          <button className="neo-button px-6 py-3 gradient-primary text-white font-semibold rounded-xl">
            <Upload className="w-5 h-5 mr-2 inline" />
            Request Asset
          </button>
        </div>

        {/* Search & Filter */}
        <div className="flex flex-col md:flex-row gap-3">
          <div className="flex-1 neo-inset px-4 py-3 rounded-xl flex items-center gap-3">
            <Search className="w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search assets..."
              className="flex-1 bg-transparent border-none focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {categories.map(category => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`neo-button p-4 rounded-xl ${
              selectedCategory === category.id ? 'active bg-indigo-50' : ''
            }`}
          >
            <category.icon className="w-6 h-6 mx-auto mb-2 text-indigo-600" />
            <p className="text-sm font-semibold">{category.label}</p>
          </button>
        ))}
      </div>

      {/* Asset Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filteredAssets.map((asset, index) => {
          const Icon = getCategoryIcon(asset.category);
          
          return (
            <motion.div
              key={asset.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="neo-surface p-4 rounded-2xl hover:shadow-lg transition-shadow"
            >
              {/* Thumbnail */}
              <div className="neo-inset rounded-xl mb-3 h-48 flex items-center justify-center overflow-hidden">
                {asset.thumbnail_url ? (
                  <img src={asset.thumbnail_url} alt={asset.name} className="w-full h-full object-cover" />
                ) : (
                  <Icon className="w-16 h-16 text-gray-400" />
                )}
              </div>

              {/* Info */}
              <h3 className="font-semibold text-gray-900 mb-1 truncate">{asset.name}</h3>
              <p className="text-xs text-muted mb-3 line-clamp-2">{asset.description}</p>

              {/* Tags */}
              {asset.tags && (
                <div className="flex flex-wrap gap-1 mb-3">
                  {asset.tags.slice(0, 2).map((tag, idx) => (
                    <span key={idx} className="neo-inset px-2 py-1 text-xs rounded-lg">
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2">
                <button
                  onClick={() => handleDownload(asset)}
                  className="neo-button flex-1 py-2 rounded-xl font-semibold text-sm flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Download
                </button>
              </div>

              {/* Meta */}
              <div className="mt-3 pt-3 border-t border-gray-200">
                <div className="flex items-center justify-between text-xs text-muted">
                  <span>{asset.file_type?.toUpperCase()}</span>
                  <span>{(asset.file_size / 1024 / 1024).toFixed(1)} MB</span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Usage Guidelines */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Brand Guidelines</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="neo-inset p-4 rounded-xl">
            <h4 className="font-semibold text-gray-900 mb-2">Logo Usage</h4>
            <p className="text-sm text-gray-700">Maintain minimum clear space. Never distort or rotate the logo.</p>
          </div>
          <div className="neo-inset p-4 rounded-xl">
            <h4 className="font-semibold text-gray-900 mb-2">Color Palette</h4>
            <p className="text-sm text-gray-700">Use only approved brand colors. No color substitutions.</p>
          </div>
          <div className="neo-inset p-4 rounded-xl">
            <h4 className="font-semibold text-gray-900 mb-2">Typography</h4>
            <p className="text-sm text-gray-700">Use designated fonts only. Maintain hierarchy standards.</p>
          </div>
        </div>
      </div>
    </div>
  );
}