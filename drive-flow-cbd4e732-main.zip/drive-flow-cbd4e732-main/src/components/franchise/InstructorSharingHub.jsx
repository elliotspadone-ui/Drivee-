import React, { useState } from "react";
import { UserCheck, ArrowRightLeft, Calendar, DollarSign, CheckCircle, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function InstructorSharingHub({ 
  instructors = [], 
  schools = [], 
  sharingAgreements = [],
  onCreateSharing,
  onApprove 
}) {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedInstructor, setSelectedInstructor] = useState(null);

  const pendingRequests = sharingAgreements.filter(s => s.status === 'pending_approval');
  const activeSharing = sharingAgreements.filter(s => s.status === 'active');

  const getSchoolName = (id) => schools.find(s => s.id === id)?.name || 'Unknown';
  const getInstructorName = (id) => instructors.find(i => i.id === id)?.full_name || 'Unknown';

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="neo-surface p-6 rounded-2xl">
          <UserCheck className="w-8 h-8 text-indigo-500 mb-3" />
          <p className="text-sm text-muted mb-1">Active Shares</p>
          <p className="text-4xl font-bold text-gray-900">{activeSharing.length}</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <Clock className="w-8 h-8 text-orange-500 mb-3" />
          <p className="text-sm text-muted mb-1">Pending</p>
          <p className="text-4xl font-bold text-gray-900">{pendingRequests.length}</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <Calendar className="w-8 h-8 text-green-500 mb-3" />
          <p className="text-sm text-muted mb-1">Lessons Shared</p>
          <p className="text-4xl font-bold text-gray-900">
            {sharingAgreements.reduce((sum, s) => sum + (s.lessons_completed || 0), 0)}
          </p>
        </div>
      </div>

      {/* Pending Requests */}
      {pendingRequests.length > 0 && (
        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Pending Requests</h3>
          <div className="space-y-3">
            {pendingRequests.map((request, index) => (
              <div key={index} className="neo-inset p-4 rounded-xl">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <ArrowRightLeft className="w-5 h-5 text-indigo-600 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">
                        {getInstructorName(request.instructor_id)}
                      </p>
                      <p className="text-sm text-gray-700 mt-1">
                        {getSchoolName(request.home_school_id)} → {getSchoolName(request.shared_with_school_id)}
                      </p>
                      <p className="text-xs text-muted mt-2">
                        {format(new Date(request.start_date), 'MMM d')} - {format(new Date(request.end_date), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => onApprove(request.id, true)}
                      className="neo-button p-2 rounded-lg text-green-600"
                    >
                      <CheckCircle className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => onApprove(request.id, false)}
                      className="neo-button p-2 rounded-lg text-red-600"
                    >
                      <Clock className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Active Sharing */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Active Instructor Sharing</h3>
        <div className="space-y-3">
          {activeSharing.map((agreement, index) => (
            <div key={index} className="neo-inset p-4 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-indigo-400 to-purple-400 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold">
                      {getInstructorName(agreement.instructor_id).charAt(0)}
                    </span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">
                      {getInstructorName(agreement.instructor_id)}
                    </p>
                    <p className="text-xs text-muted">
                      {getSchoolName(agreement.home_school_id)} → {getSchoolName(agreement.shared_with_school_id)}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-gray-900">{agreement.lessons_completed || 0}</p>
                  <p className="text-xs text-muted">lessons</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div className="neo-button p-2 rounded-lg text-center">
                  <p className="text-muted">Revenue Split</p>
                  <p className="font-bold text-gray-900">{agreement.revenue_split_percentage}%</p>
                </div>
                <div className="neo-button p-2 rounded-lg text-center">
                  <p className="text-muted">Start</p>
                  <p className="font-bold text-gray-900">{format(new Date(agreement.start_date), 'MMM d')}</p>
                </div>
                <div className="neo-button p-2 rounded-lg text-center">
                  <p className="text-muted">End</p>
                  <p className="font-bold text-gray-900">{format(new Date(agreement.end_date), 'MMM d')}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}