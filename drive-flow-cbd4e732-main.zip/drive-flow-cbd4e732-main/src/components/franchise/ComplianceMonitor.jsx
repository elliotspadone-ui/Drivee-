import React from "react";
import { Shield, CheckCircle, XCircle, AlertTriangle, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

export default function ComplianceMonitor({ checks = [], franchises }) {
  const getOverallCompliance = (franchiseId) => {
    const franchiseChecks = checks.filter(c => c.franchise_id === franchiseId);
    if (franchiseChecks.length === 0) return 100;
    
    const totalScore = franchiseChecks.reduce((sum, c) => sum + (c.score || 0), 0);
    return totalScore / franchiseChecks.length;
  };

  const criticalIssues = checks.filter(c => c.overall_status === 'non_compliant');
  const warnings = checks.filter(c => c.overall_status === 'needs_attention');

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="neo-surface p-6 rounded-2xl">
          <Shield className="w-8 h-8 text-green-500 mb-3" />
          <p className="text-sm text-muted mb-1">Compliant</p>
          <p className="text-4xl font-bold text-gray-900">
            {checks.filter(c => c.overall_status === 'compliant').length}
          </p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <AlertTriangle className="w-8 h-8 text-orange-500 mb-3" />
          <p className="text-sm text-muted mb-1">Warnings</p>
          <p className="text-4xl font-bold text-gray-900">{warnings.length}</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <XCircle className="w-8 h-8 text-red-500 mb-3" />
          <p className="text-sm text-muted mb-1">Critical</p>
          <p className="text-4xl font-bold text-gray-900">{criticalIssues.length}</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <TrendingUp className="w-8 h-8 text-indigo-500 mb-3" />
          <p className="text-sm text-muted mb-1">Avg Score</p>
          <p className="text-4xl font-bold text-gray-900">
            {(checks.reduce((sum, c) => sum + (c.score || 0), 0) / checks.length).toFixed(0)}%
          </p>
        </div>
      </div>

      {/* Franchise Compliance */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Franchise Compliance Scores</h3>
        <div className="space-y-3">
          {franchises.map((franchise, index) => {
            const score = getOverallCompliance(franchise.id);
            
            return (
              <div key={franchise.id} className="neo-inset p-4 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${
                      score >= 90 ? 'bg-green-500' :
                      score >= 70 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}>
                      {score.toFixed(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{franchise.franchise_name}</p>
                      <p className="text-xs text-muted">{franchise.franchisee_name}</p>
                    </div>
                  </div>
                  <span className={`neo-button px-4 py-2 text-sm font-bold ${
                    score >= 90 ? 'text-green-700' :
                    score >= 70 ? 'text-yellow-700' : 'text-red-700'
                  }`}>
                    {score >= 90 ? 'Excellent' :
                     score >= 70 ? 'Good' : 'Needs Attention'}
                  </span>
                </div>
                <div className="relative h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`absolute h-full ${
                      score >= 90 ? 'bg-green-500' :
                      score >= 70 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${score}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Checks */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Compliance Checks</h3>
        <div className="space-y-3">
          {checks.slice(0, 5).map((check, index) => (
            <div key={index} className="neo-inset p-4 rounded-xl">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-semibold text-gray-900 capitalize">{check.check_type.replace('_', ' ')}</p>
                  <p className="text-xs text-muted">
                    {franchises.find(f => f.id === check.franchise_id)?.franchise_name}
                  </p>
                </div>
                <span className={`neo-button px-3 py-1 text-xs font-bold ${
                  check.overall_status === 'compliant' ? 'text-green-700' :
                  check.overall_status === 'needs_attention' ? 'text-orange-700' : 'text-red-700'
                }`}>
                  {check.overall_status.replace('_', ' ').toUpperCase()}
                </span>
              </div>
              {check.action_items && check.action_items.length > 0 && (
                <div className="space-y-1">
                  {check.action_items.map((item, idx) => (
                    <p key={idx} className="text-sm text-gray-700">• {item}</p>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}