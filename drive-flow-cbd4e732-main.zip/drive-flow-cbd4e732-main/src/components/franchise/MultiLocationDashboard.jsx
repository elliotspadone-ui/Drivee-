import React, { useState } from "react";
import { TrendingUp, Users, DollarSign, Calendar, MapPin, Award, AlertTriangle } from "lucide-react";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function MultiLocationDashboard({ franchises, schools, bookings, payments }) {
  const [selectedPeriod, setSelectedPeriod] = useState("month");

  // Aggregate metrics across all locations
  const totalRevenue = payments.reduce((sum, p) => sum + (p.amount || 0), 0);
  const totalBookings = bookings.length;
  const totalStudents = [...new Set(bookings.map(b => b.student_id))].length;
  const avgRating = schools.reduce((sum, s) => sum + (s.rating || 0), 0) / schools.length;

  // Revenue by location
  const revenueByLocation = schools.map(school => ({
    name: school.name,
    revenue: payments.filter(p => p.school_id === school.id).reduce((sum, p) => sum + p.amount, 0),
    bookings: bookings.filter(b => b.school_id === school.id).length
  })).sort((a, b) => b.revenue - a.revenue);

  // Monthly trend
  const monthlyData = Array.from({ length: 6 }, (_, i) => {
    const month = new Date();
    month.setMonth(month.getMonth() - (5 - i));
    return {
      month: month.toLocaleString('default', { month: 'short' }),
      revenue: Math.floor(Math.random() * 50000) + 30000,
      bookings: Math.floor(Math.random() * 300) + 200
    };
  });

  // Performance tiers
  const tierDistribution = [
    { name: "Platinum", value: franchises.filter(f => f.performance_tier === 'platinum').length, color: "#c084fc" },
    { name: "Gold", value: franchises.filter(f => f.performance_tier === 'gold').length, color: "#fbbf24" },
    { name: "Silver", value: franchises.filter(f => f.performance_tier === 'silver').length, color: "#94a3b8" },
    { name: "Bronze", value: franchises.filter(f => f.performance_tier === 'bronze').length, color: "#cd7f32" }
  ];

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <DollarSign className="w-8 h-8 text-green-500" />
            <span className="text-sm font-semibold text-green-700">Revenue</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">${(totalRevenue / 1000).toFixed(0)}K</p>
          <p className="text-xs text-muted mt-2">
            <TrendingUp className="w-3 h-3 inline mr-1" />
            +12.5% vs last period
          </p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <Calendar className="w-8 h-8 text-indigo-500" />
            <span className="text-sm font-semibold text-indigo-700">Bookings</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">{totalBookings}</p>
          <p className="text-xs text-muted mt-2">Across all locations</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <Users className="w-8 h-8 text-purple-500" />
            <span className="text-sm font-semibold text-purple-700">Students</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">{totalStudents}</p>
          <p className="text-xs text-muted mt-2">Active learners</p>
        </div>

        <div className="neo-surface p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-3">
            <MapPin className="w-8 h-8 text-blue-500" />
            <span className="text-sm font-semibold text-blue-700">Locations</span>
          </div>
          <p className="text-4xl font-bold text-gray-900">{schools.length}</p>
          <p className="text-xs text-muted mt-2">{franchises.length} franchises</p>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Trend */}
        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Network Revenue Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip />
              <Line type="monotone" dataKey="revenue" stroke="#667eea" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Performance Tiers */}
        <div className="neo-surface p-6 rounded-3xl">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Franchise Performance Tiers</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={tierDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {tierDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Location Rankings */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Location Performance Rankings</h3>
        <div className="space-y-3">
          {revenueByLocation.slice(0, 10).map((location, index) => (
            <div key={index} className="neo-inset p-4 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${
                  index === 0 ? 'bg-yellow-500' :
                  index === 1 ? 'bg-gray-400' :
                  index === 2 ? 'bg-orange-600' : 'bg-indigo-600'
                }`}>
                  {index + 1}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{location.name}</p>
                  <p className="text-xs text-muted">{location.bookings} bookings</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-gray-900">${(location.revenue / 1000).toFixed(1)}K</p>
                <p className="text-xs text-muted">revenue</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Compliance Alerts */}
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex items-center gap-3 mb-4">
          <AlertTriangle className="w-6 h-6 text-orange-600" />
          <h3 className="text-lg font-bold text-gray-900">Compliance Alerts</h3>
        </div>
        <div className="space-y-2">
          {franchises.filter(f => f.compliance_score < 90).map((franchise, index) => (
            <div key={index} className="neo-inset p-4 rounded-xl flex items-center justify-between border-l-4 border-orange-500">
              <div>
                <p className="font-semibold text-gray-900">{franchise.franchise_name}</p>
                <p className="text-sm text-gray-700">Compliance score below threshold</p>
              </div>
              <span className="neo-button px-4 py-2 font-bold text-orange-700">
                {franchise.compliance_score}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}