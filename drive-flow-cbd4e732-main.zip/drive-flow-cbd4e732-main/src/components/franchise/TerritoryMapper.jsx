import React, { useState } from "react";
import { MapPin, Plus, Edit, Trash2, Navigation } from "lucide-react";
import { motion } from "framer-motion";

export default function TerritoryMapper({ franchises, onUpdate }) {
  const [selectedFranchise, setSelectedFranchise] = useState(null);
  const [editMode, setEditMode] = useState(false);

  const territoryColors = [
    "from-red-400 to-pink-400",
    "from-blue-400 to-indigo-400",
    "from-green-400 to-emerald-400",
    "from-yellow-400 to-orange-400",
    "from-purple-400 to-pink-400",
    "from-cyan-400 to-blue-400"
  ];

  return (
    <div className="space-y-6">
      {/* Map View */}
      <div className="neo-surface p-6 rounded-3xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Territory Map</h2>
            <p className="text-sm text-muted">Franchise coverage and boundaries</p>
          </div>
          <button className="neo-button px-4 py-2 flex items-center gap-2 font-semibold">
            <Plus className="w-4 h-4" />
            Add Territory
          </button>
        </div>

        {/* Map Placeholder */}
        <div className="neo-inset rounded-2xl h-[500px] flex items-center justify-center mb-4">
          <div className="text-center">
            <MapPin className="w-16 h-16 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-600">Interactive map view</p>
            <p className="text-sm text-muted">Integration with mapping service</p>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-3">
          {franchises.map((franchise, index) => (
            <button
              key={franchise.id}
              onClick={() => setSelectedFranchise(franchise)}
              className={`neo-button px-4 py-2 rounded-xl flex items-center gap-2 ${
                selectedFranchise?.id === franchise.id ? 'active bg-indigo-50' : ''
              }`}
            >
              <div className={`w-4 h-4 rounded bg-gradient-to-br ${territoryColors[index % territoryColors.length]}`} />
              <span className="text-sm font-semibold">{franchise.franchise_name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Territory Details */}
      {selectedFranchise && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="neo-surface p-6 rounded-3xl"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-900">{selectedFranchise.franchise_name}</h3>
            <button className="neo-button px-4 py-2 flex items-center gap-2">
              <Edit className="w-4 h-4" />
              Edit Territory
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Regions */}
            <div className="neo-inset p-4 rounded-2xl">
              <h4 className="font-semibold text-gray-900 mb-3">Covered Regions</h4>
              <div className="space-y-2">
                {selectedFranchise.territory?.regions?.map((region, index) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <span className="text-gray-700">{region}</span>
                    <button className="text-red-600 hover:text-red-700">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Cities */}
            <div className="neo-inset p-4 rounded-2xl">
              <h4 className="font-semibold text-gray-900 mb-3">Cities</h4>
              <div className="space-y-2">
                {selectedFranchise.territory?.cities?.map((city, index) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <span className="text-gray-700">{city}</span>
                    <button className="text-red-600 hover:text-red-700">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Postal Codes */}
            <div className="neo-inset p-4 rounded-2xl">
              <h4 className="font-semibold text-gray-900 mb-3">Postal Codes</h4>
              <div className="flex flex-wrap gap-2">
                {selectedFranchise.territory?.postal_codes?.map((code, index) => (
                  <span key={index} className="neo-button px-3 py-1 text-xs rounded-lg">
                    {code}
                  </span>
                ))}
              </div>
            </div>

            {/* Radius */}
            <div className="neo-inset p-4 rounded-2xl">
              <h4 className="font-semibold text-gray-900 mb-3">Service Radius</h4>
              <div className="flex items-center gap-3">
                <Navigation className="w-8 h-8 text-indigo-600" />
                <div>
                  <p className="text-3xl font-bold text-gray-900">
                    {selectedFranchise.territory?.radius_miles || 0}
                  </p>
                  <p className="text-sm text-muted">miles from center</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Territory Conflicts */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Territory Alerts</h3>
        <div className="neo-inset p-4 rounded-xl">
          <p className="text-sm text-gray-700">No territory conflicts detected</p>
        </div>
      </div>
    </div>
  );
}