import React, { useState } from "react";
import { Calculator, DollarSign, TrendingUp, FileText, Download } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function FranchiseFeeCalculator({ franchise, revenue, onGenerate }) {
  const [period, setPeriod] = useState("monthly");
  const [customRevenue, setCustomRevenue] = useState(revenue || 0);

  const calculateFees = () => {
    const royalty = customRevenue * (franchise.royalty_percentage / 100);
    const marketing = customRevenue * (franchise.marketing_fee_percentage / 100);
    const technology = 99; // Fixed monthly tech fee
    const total = royalty + marketing + technology;

    return {
      grossRevenue: customRevenue,
      royaltyFee: royalty,
      marketingFee: marketing,
      technologyFee: technology,
      totalDue: total
    };
  };

  const fees = calculateFees();

  const feeBreakdown = [
    { 
      label: "Royalty Fee", 
      amount: fees.royaltyFee, 
      percentage: franchise.royalty_percentage,
      color: "from-indigo-400 to-purple-400" 
    },
    { 
      label: "Marketing Fee", 
      amount: fees.marketingFee, 
      percentage: franchise.marketing_fee_percentage,
      color: "from-pink-400 to-rose-400" 
    },
    { 
      label: "Technology Fee", 
      amount: fees.technologyFee, 
      percentage: null,
      color: "from-blue-400 to-cyan-400" 
    }
  ];

  const handleGenerate = () => {
    const feeData = {
      franchise_id: franchise.id,
      period_start: new Date().toISOString().split('T')[0],
      period_end: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
      ...fees,
      due_date: new Date(new Date().setDate(15)).toISOString().split('T')[0]
    };
    
    onGenerate(feeData);
  };

  return (
    <div className="space-y-6">
      <div className="neo-surface p-8 rounded-3xl">
        <div className="flex items-center gap-3 mb-6">
          <div className="neo-inset w-12 h-12 rounded-2xl flex items-center justify-center">
            <Calculator className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Franchise Fee Calculator</h2>
            <p className="text-sm text-muted">{franchise.franchise_name}</p>
          </div>
        </div>

        {/* Revenue Input */}
        <div className="neo-inset p-6 rounded-2xl mb-6">
          <label className="text-sm font-semibold text-gray-900 mb-3 block">Gross Revenue</label>
          <div className="flex items-center gap-3">
            <DollarSign className="w-6 h-6 text-gray-600" />
            <input
              type="number"
              value={customRevenue}
              onChange={(e) => setCustomRevenue(parseFloat(e.target.value))}
              className="flex-1 neo-button px-4 py-3 rounded-xl text-2xl font-bold"
              placeholder="0.00"
            />
          </div>
        </div>

        {/* Fee Breakdown */}
        <div className="space-y-3 mb-6">
          {feeBreakdown.map((fee, index) => (
            <div key={index} className="neo-inset p-4 rounded-2xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${fee.color} flex items-center justify-center`}>
                    <span className="text-white font-bold text-sm">
                      {fee.percentage ? `${fee.percentage}%` : '$'}
                    </span>
                  </div>
                  <span className="font-semibold text-gray-900">{fee.label}</span>
                </div>
                <span className="text-2xl font-bold text-gray-900">
                  ${fee.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
              {fee.percentage && (
                <div className="relative h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`absolute h-full bg-gradient-to-r ${fee.color}`}
                    style={{ width: `${(fee.amount / fees.totalDue) * 100}%` }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Total */}
        <div className="neo-surface p-6 rounded-2xl bg-gradient-to-br from-indigo-50 to-purple-50">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted mb-1">Total Due</p>
              <p className="text-4xl font-bold text-gray-900">
                ${fees.totalDue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
            <TrendingUp className="w-12 h-12 text-indigo-600" />
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="grid grid-cols-2 gap-4">
        <button
          onClick={handleGenerate}
          className="neo-button py-4 gradient-primary text-white font-bold rounded-2xl"
        >
          <FileText className="w-5 h-5 mr-2 inline" />
          Generate Invoice
        </button>
        <button className="neo-button py-4 rounded-2xl font-semibold">
          <Download className="w-5 h-5 mr-2 inline" />
          Export Report
        </button>
      </div>

      {/* Fee Schedule */}
      <div className="neo-surface p-6 rounded-3xl">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Fee Schedule</h3>
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted">Royalty Rate:</span>
            <span className="font-semibold text-gray-900">{franchise.royalty_percentage}% of gross revenue</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted">Marketing Fee:</span>
            <span className="font-semibold text-gray-900">{franchise.marketing_fee_percentage}% of gross revenue</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted">Technology Fee:</span>
            <span className="font-semibold text-gray-900">$99/month (fixed)</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted">Payment Due:</span>
            <span className="font-semibold text-gray-900">15th of each month</span>
          </div>
        </div>
      </div>
    </div>
  );
}